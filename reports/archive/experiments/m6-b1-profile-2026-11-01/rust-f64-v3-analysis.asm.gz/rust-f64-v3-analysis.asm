
diagnostics-b1-current-255/rust-f64-parent-rebuilt-255:     file format elf64-x86-64


Disassembly of section .text:

00000000001c3d10 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>>:
  1c3d10:	push   %rbp
  1c3d11:	push   %r15
  1c3d13:	push   %r14
  1c3d15:	push   %r13
  1c3d17:	push   %r12
  1c3d19:	push   %rbx
  1c3d1a:	sub    $0x1f8,%rsp
  1c3d21:	mov    %rdi,0x80(%rsp)
  1c3d29:	mov    0xd8(%rsi),%rax
  1c3d30:	mov    %rax,0x18(%rsp)
  1c3d35:	mov    0xe0(%rsi),%rdi
  1c3d3c:	movzbl 0xe8(%rsi),%ecx
  1c3d43:	mov    (%rsi),%rax
  1c3d46:	mov    %rax,0x188(%rsp)
  1c3d4e:	mov    0x8(%rsi),%rax
  1c3d52:	mov    %rax,0x110(%rsp)
  1c3d5a:	mov    0x10(%rsi),%r13
  1c3d5e:	mov    0x18(%rsi),%r14
  1c3d62:	mov    0x20(%rsi),%r8
  1c3d66:	mov    0x28(%rsi),%rbp
  1c3d6a:	mov    0x30(%rsi),%r15
  1c3d6e:	mov    0x38(%rsi),%r11
  1c3d72:	mov    0x40(%rsi),%r10
  1c3d76:	mov    0x58(%rsi),%rax
  1c3d7a:	mov    %rax,0x120(%rsp)
  1c3d82:	mov    0x60(%rsi),%rbx
  1c3d86:	mov    0x68(%rsi),%rax
  1c3d8a:	mov    %rax,0xd0(%rsp)
  1c3d92:	mov    0x70(%rsi),%rax
  1c3d96:	mov    %rax,0x90(%rsp)
  1c3d9e:	mov    0x78(%rsi),%rax
  1c3da2:	mov    %rax,0xc8(%rsp)
  1c3daa:	mov    0x80(%rsi),%rax
  1c3db1:	mov    %rax,0x88(%rsp)
  1c3db9:	mov    0x88(%rsi),%rdx
  1c3dc0:	mov    0x90(%rsi),%rax
  1c3dc7:	mov    %rax,0x78(%rsp)
  1c3dcc:	mov    0x98(%rsi),%rax
  1c3dd3:	mov    %rax,0xf8(%rsp)
  1c3ddb:	mov    0xa0(%rsi),%rax
  1c3de2:	mov    %rax,0x20(%rsp)
  1c3de7:	mov    0xa8(%rsi),%r12
  1c3dee:	mov    0xb0(%rsi),%rax
  1c3df5:	mov    %rax,0x50(%rsp)
  1c3dfa:	mov    0xb8(%rsi),%rax
  1c3e01:	mov    %rax,0x30(%rsp)
  1c3e06:	mov    0xc0(%rsi),%rax
  1c3e0d:	mov    %rax,0x10(%rsp)
  1c3e12:	mov    0xc8(%rsi),%r9
  1c3e19:	mov    0xd0(%rsi),%rax
  1c3e20:	movb   $0x1,0xf(%rsp)
  1c3e25:	mov    %rdi,0x130(%rsp)
  1c3e2d:	cmp    $0x1fe,%rdi
  1c3e34:	mov    %r11,0xf0(%rsp)
  1c3e3c:	mov    %rdx,0x70(%rsp)
  1c3e41:	ja     1c3f21 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x211>
  1c3e47:	mov    %rbx,0x40(%rsp)
  1c3e4c:	mov    %rbp,0x100(%rsp)
  1c3e54:	mov    %r10,0xd8(%rsp)
  1c3e5c:	mov    %r14,0x108(%rsp)
  1c3e64:	mov    %r15,0xe0(%rsp)
  1c3e6c:	mov    %r8,%rbx
  1c3e6f:	mov    %ecx,%r14d
  1c3e72:	mov    %rax,(%rsp)
  1c3e76:	lea    0x1a8(%rsp),%rdi
  1c3e7e:	mov    0xf8(%rsp),%rsi
  1c3e86:	mov    0x20(%rsp),%rdx
  1c3e8b:	mov    %r12,%rcx
  1c3e8e:	mov    0x50(%rsp),%r8
  1c3e93:	mov    %r9,%rbp
  1c3e96:	mov    %rax,%r15
  1c3e99:	call   *0xe6249(%rip)        # 2aa0e8 <_DYNAMIC+0x5d8>
  1c3e9f:	mov    0x1a8(%rsp),%rax
  1c3ea7:	movzbl 0x1b0(%rsp),%edx
  1c3eaf:	cmp    $0xffffffffffffffff,%rax
  1c3eb3:	je     1c3ee4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1d4>
  1c3eb5:	vmovupd 0x1b1(%rsp),%xmm0
  1c3ebe:	vmovupd 0x1c0(%rsp),%xmm1
  1c3ec7:	mov    0x80(%rsp),%rcx
  1c3ecf:	vmovupd %xmm1,0x18(%rcx)
  1c3ed4:	vmovupd %xmm0,0x9(%rcx)
  1c3ed9:	mov    %rax,(%rcx)
  1c3edc:	mov    %dl,0x8(%rcx)
  1c3edf:	jmp    1c3fc0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x2b0>
  1c3ee4:	mov    %r14d,%ecx
  1c3ee7:	mov    %rbx,%r8
  1c3eea:	mov    %r15,%rax
  1c3eed:	mov    0xe0(%rsp),%r15
  1c3ef5:	mov    0x108(%rsp),%r14
  1c3efd:	mov    0xd8(%rsp),%r10
  1c3f05:	mov    %rbp,%r9
  1c3f08:	mov    0x100(%rsp),%rbp
  1c3f10:	mov    0xf0(%rsp),%r11
  1c3f18:	mov    0x40(%rsp),%rbx
  1c3f1d:	mov    %dl,0xf(%rsp)
  1c3f21:	mov    %r9,0x118(%rsp)
  1c3f29:	mov    %cl,0x2f(%rsp)
  1c3f2d:	mov    %rax,0xe8(%rsp)
  1c3f35:	mov    %r13,%rdi
  1c3f38:	shr    $0x2,%rdi
  1c3f3c:	mov    %r8,%rax
  1c3f3f:	shr    $0x2,%rax
  1c3f43:	mov    %r15,%rcx
  1c3f46:	shr    $0x2,%rcx
  1c3f4a:	mov    %r10,%rdx
  1c3f4d:	shr    $0x2,%rdx
  1c3f51:	mov    %rbx,%rsi
  1c3f54:	shr    $0x2,%rsi
  1c3f58:	xor    %rdi,%rax
  1c3f5b:	xor    %rdi,%rcx
  1c3f5e:	or     %rax,%rcx
  1c3f61:	xor    %rdi,%rdx
  1c3f64:	or     %rcx,%rdx
  1c3f67:	mov    %rdi,0x58(%rsp)
  1c3f6c:	xor    %rdi,%rsi
  1c3f6f:	or     %rdx,%rsi
  1c3f72:	jne    1c3fad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x29d>
  1c3f74:	mov    %r13d,%edi
  1c3f77:	and    $0x3,%edi
  1c3f7a:	mov    %ebx,%eax
  1c3f7c:	and    $0x3,%eax
  1c3f7f:	mov    %r10d,%ecx
  1c3f82:	and    $0x3,%ecx
  1c3f85:	mov    %r15d,%edx
  1c3f88:	and    $0x3,%edx
  1c3f8b:	mov    %r8d,%esi
  1c3f8e:	and    $0x3,%esi
  1c3f91:	xor    %rdi,%rsi
  1c3f94:	xor    %rdi,%rdx
  1c3f97:	or     %rsi,%rdx
  1c3f9a:	xor    %rdi,%rcx
  1c3f9d:	or     %rdx,%rcx
  1c3fa0:	mov    %rdi,0x48(%rsp)
  1c3fa5:	xor    %rdi,%rax
  1c3fa8:	or     %rcx,%rax
  1c3fab:	je     1c3fd5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x2c5>
  1c3fad:	mov    0x80(%rsp),%rax
  1c3fb5:	movb   $0x0,0x8(%rax)
  1c3fb9:	movq   $0xffffffffffffffff,(%rax)
  1c3fc0:	add    $0x1f8,%rsp
  1c3fc7:	pop    %rbx
  1c3fc8:	pop    %r12
  1c3fca:	pop    %r13
  1c3fcc:	pop    %r14
  1c3fce:	pop    %r15
  1c3fd0:	pop    %rbp
  1c3fd1:	vzeroupper
  1c3fd4:	ret
  1c3fd5:	mov    %rbx,0x40(%rsp)
  1c3fda:	mov    %r10,0xd8(%rsp)
  1c3fe2:	mov    %r15,0xe0(%rsp)
  1c3fea:	mov    %r8,0x150(%rsp)
  1c3ff2:	mov    0x130(%rsp),%r9
  1c3ffa:	sub    0x18(%rsp),%r9
  1c3fff:	mov    %r9d,%ecx
  1c4002:	not    %ecx
  1c4004:	inc    %r9
  1c4007:	mov    %r9,%rax
  1c400a:	shr    $1,%rax
  1c400d:	and    $0x1,%ecx
  1c4010:	add    %rax,%rcx
  1c4013:	mov    %rcx,0x68(%rsp)
  1c4018:	mov    %r13,0x128(%rsp)
  1c4020:	mov    0x120(%rsp),%r10
  1c4028:	mov    0x50(%rsp),%rbx
  1c402d:	mov    0xf8(%rsp),%r13
  1c4035:	mov    0x30(%rsp),%rdx
  1c403a:	movzbl 0xf(%rsp),%r15d
  1c4040:	je     1c55dd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x18cd>
  1c4046:	movabs $0xffffffffffffffc,%rsi
  1c4050:	mov    0x128(%rsp),%rax
  1c4058:	and    %rsi,%rax
  1c405b:	mov    0x110(%rsp),%rcx
  1c4063:	lea    (%rcx,%rax,8),%rax
  1c4067:	mov    %rax,0x98(%rsp)
  1c406f:	mov    0x150(%rsp),%rax
  1c4077:	and    %rsi,%rax
  1c407a:	lea    (%r14,%rax,8),%rax
  1c407e:	mov    %rax,0xb0(%rsp)
  1c4086:	mov    0xe0(%rsp),%rax
  1c408e:	and    %rsi,%rax
  1c4091:	lea    0x0(,%rax,8),%rax
  1c4099:	add    %rbp,%rax
  1c409c:	mov    %rax,0xa8(%rsp)
  1c40a4:	mov    0xd8(%rsp),%rax
  1c40ac:	and    %rsi,%rax
  1c40af:	lea    (%r11,%rax,8),%rax
  1c40b3:	mov    %rax,0xa0(%rsp)
  1c40bb:	and    %rsi,0x40(%rsp)
  1c40c0:	movabs $0x3ffffffffffffffc,%r8
  1c40ca:	mov    0xe8(%rsp),%rax
  1c40d2:	mov    %rax,%rcx
  1c40d5:	shr    $0x2,%rcx
  1c40d9:	mov    %eax,%edi
  1c40db:	and    $0x3,%edi
  1c40de:	mov    %rdi,0x158(%rsp)
  1c40e6:	and    %rsi,%rax
  1c40e9:	mov    0x118(%rsp),%rsi
  1c40f1:	lea    (%rsi,%rax,8),%rax
  1c40f5:	mov    %rax,0x190(%rsp)
  1c40fd:	mov    0x58(%rsp),%rax
  1c4102:	cmp    %rcx,%rax
  1c4105:	mov    %rcx,0x140(%rsp)
  1c410d:	cmovb  %rax,%rcx
  1c4111:	mov    %rcx,0x178(%rsp)
  1c4119:	mov    %eax,%ecx
  1c411b:	and    $0x3,%ecx
  1c411e:	and    $0xfffffffffffffffc,%rax
  1c4122:	mov    %rax,0x168(%rsp)
  1c412a:	mov    %rcx,0x170(%rsp)
  1c4132:	shl    $0x5,%ecx
  1c4135:	mov    %rcx,0x180(%rsp)
  1c413d:	xor    %ecx,%ecx
  1c413f:	add    $0x2,%r8
  1c4143:	mov    %r8,0x160(%rsp)
  1c414b:	vpxor  %xmm15,%xmm15,%xmm15
  1c4150:	vbroadcastsd -0x1a2089(%rip),%ymm9        # 220d0 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x590>
  1c4159:	vbroadcastsd -0x1a2122(%rip),%ymm10        # 22040 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x500>
  1c4162:	mov    %r9,0x130(%rsp)
  1c416a:	vmovupd %ymm10,0x1d0(%rsp)
  1c4173:	mov    %r14,0x108(%rsp)
  1c417b:	mov    %rbp,0x100(%rsp)
  1c4183:	jmp    1c41e1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x4d1>
  1c4185:	data16 cs nopw 0x0(%rax,%rax,1)
  1c4190:	mov    0x50(%rsp),%rax
  1c4195:	mov    %r12,%rdi
  1c4198:	mov    0x10(%rsp),%rbx
  1c419d:	mov    %r8,%r12
  1c41a0:	vbroadcastsd -0x1a20d9(%rip),%ymm9        # 220d0 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x590>
  1c41a9:	vmovupd 0x1d0(%rsp),%ymm10
  1c41b2:	mov    %r13,%rdx
  1c41b5:	mov    %r12,%r13
  1c41b8:	mov    %rbx,0x20(%rsp)
  1c41bd:	mov    %rdx,%r12
  1c41c0:	mov    %rsi,%rbx
  1c41c3:	mov    %rdi,%rdx
  1c41c6:	mov    %rax,0x10(%rsp)
  1c41cb:	mov    0x148(%rsp),%rax
  1c41d3:	mov    %rax,%rcx
  1c41d6:	cmp    0x68(%rsp),%rax
  1c41db:	jae    1c55dd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x18cd>
  1c41e1:	mov    %rdx,0x30(%rsp)
  1c41e6:	movzbl 0x2f(%rsp),%r9d
  1c41ec:	and    %r15b,%r9b
  1c41ef:	lea    0x1(%rcx),%rdi
  1c41f3:	cmp    $0x1,%r9b
  1c41f7:	mov    %rcx,0x60(%rsp)
  1c41fc:	mov    %rbx,0x50(%rsp)
  1c4201:	jne    1c4380 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x670>
  1c4207:	cmp    0x68(%rsp),%rdi
  1c420c:	jae    1c4380 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x670>
  1c4212:	cmp    0x90(%rsp),%rcx
  1c421a:	mov    0x110(%rsp),%r9
  1c4222:	jae    1c578a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1a7a>
  1c4228:	cmp    0x88(%rsp),%rcx
  1c4230:	jae    1c57a5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1a95>
  1c4236:	cmp    0x90(%rsp),%rdi
  1c423e:	jae    1c57c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1ab0>
  1c4244:	cmp    0x88(%rsp),%rdi
  1c424c:	jae    1c57d8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1ac8>
  1c4252:	lea    0x2(%rcx),%rbx
  1c4256:	mov    0x50(%rsp),%rax
  1c425b:	shr    $0x2,%rax
  1c425f:	mov    %rcx,%rdi
  1c4262:	mov    0xd0(%rsp),%rcx
  1c426a:	vbroadcastsd (%rcx,%rdi,8),%ymm3
  1c4270:	mov    0xc8(%rsp),%rdx
  1c4278:	vbroadcastsd (%rdx,%rdi,8),%ymm0
  1c427e:	vbroadcastsd 0x8(%rcx,%rdi,8),%ymm2
  1c4285:	vbroadcastsd 0x8(%rdx,%rdi,8),%ymm1
  1c428c:	je     1c452b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x81b>
  1c4292:	mov    0x20(%rsp),%rdi
  1c4297:	shr    $0x2,%rdi
  1c429b:	mov    0x10(%rsp),%r8
  1c42a0:	shr    $0x2,%r8
  1c42a4:	vxorpd %xmm6,%xmm6,%xmm6
  1c42a8:	xor    %ecx,%ecx
  1c42aa:	xor    %edx,%edx
  1c42ac:	vxorpd %xmm9,%xmm9,%xmm9
  1c42b1:	vxorpd %xmm5,%xmm5,%xmm5
  1c42b5:	vxorpd %xmm11,%xmm11,%xmm11
  1c42ba:	vxorpd %xmm7,%xmm7,%xmm7
  1c42be:	vxorpd %xmm8,%xmm8,%xmm8
  1c42c3:	vxorpd %xmm4,%xmm4,%xmm4
  1c42c7:	vxorpd %xmm10,%xmm10,%xmm10
  1c42cc:	jmp    1c42e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x5d0>
  1c42ce:	xchg   %ax,%ax
  1c42d0:	inc    %rdx
  1c42d3:	add    $0x20,%rcx
  1c42d7:	cmp    %rdx,%rax
  1c42da:	je     1c454f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x83f>
  1c42e0:	cmp    %rdx,%rdi
  1c42e3:	je     1c564b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x193b>
  1c42e9:	cmp    %rdx,0x58(%rsp)
  1c42ee:	je     1c5633 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1923>
  1c42f4:	cmp    %rdx,%r8
  1c42f7:	je     1c561d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x190d>
  1c42fd:	vmovupd (%r12,%rcx,1),%ymm12
  1c4303:	vfmadd231pd (%r9,%rcx,1),%ymm12,%ymm4
  1c4309:	vfmadd231pd (%r14,%rcx,1),%ymm12,%ymm8
  1c430f:	vfmadd231pd 0x0(%rbp,%rcx,1),%ymm12,%ymm7
  1c4316:	vfmadd231pd (%r11,%rcx,1),%ymm12,%ymm11
  1c431c:	vmovupd (%r10,%rcx,1),%ymm13
  1c4322:	vfmadd213pd %ymm0,%ymm3,%ymm13
  1c4327:	vfmadd213pd 0x0(%r13,%rcx,1),%ymm12,%ymm13
  1c432e:	mov    0x30(%rsp),%r15
  1c4333:	vmovupd %ymm13,(%r15,%rcx,1)
  1c4339:	vfmadd231pd (%r9,%rcx,1),%ymm13,%ymm5
  1c433f:	vfmadd231pd (%r14,%rcx,1),%ymm13,%ymm9
  1c4345:	vfmadd231pd 0x0(%rbp,%rcx,1),%ymm13,%ymm6
  1c434c:	vfmadd231pd (%r11,%rcx,1),%ymm13,%ymm10
  1c4352:	cmp    0x68(%rsp),%rbx
  1c4357:	jae    1c42d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x5c0>
  1c435d:	vmovupd (%r10,%rcx,1),%ymm14
  1c4363:	vfmadd213pd %ymm1,%ymm2,%ymm14
  1c4368:	vfmadd213pd %ymm12,%ymm14,%ymm13
  1c436d:	vmovupd %ymm13,0x0(%r13,%rcx,1)
  1c4374:	jmp    1c42d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x5c0>
  1c4379:	nopl   0x0(%rax)
  1c4380:	mov    %rdi,0x148(%rsp)
  1c4388:	test   $0x1,%r15b
  1c438c:	mov    0x110(%rsp),%rsi
  1c4394:	mov    %r15b,0xf(%rsp)
  1c4399:	mov    %r13,0xf8(%rsp)
  1c43a1:	mov    %r9b,0x2e(%rsp)
  1c43a6:	je     1c4450 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x740>
  1c43ac:	mov    %rbx,%rcx
  1c43af:	shr    $0x2,%rcx
  1c43b3:	je     1c48d4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xbc4>
  1c43b9:	lea    -0x1(%rcx),%rax
  1c43bd:	cmp    %rax,0x58(%rsp)
  1c43c2:	jbe    1c586b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1b5b>
  1c43c8:	test   %rax,%rax
  1c43cb:	je     1c4e1f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x110f>
  1c43d1:	and    0x160(%rsp),%rcx
  1c43d9:	vxorpd %xmm1,%xmm1,%xmm1
  1c43dd:	mov    $0x20,%edx
  1c43e2:	xor    %eax,%eax
  1c43e4:	vxorpd %xmm3,%xmm3,%xmm3
  1c43e8:	vxorpd %xmm2,%xmm2,%xmm2
  1c43ec:	vxorpd %xmm0,%xmm0,%xmm0
  1c43f0:	vmovupd -0x20(%r12,%rdx,1),%ymm4
  1c43f7:	vfmadd231pd -0x20(%rsi,%rdx,1),%ymm4,%ymm1
  1c43fe:	vfmadd231pd -0x20(%r14,%rdx,1),%ymm4,%ymm3
  1c4405:	vfmadd231pd -0x20(%rbp,%rdx,1),%ymm4,%ymm2
  1c440c:	vfmadd231pd -0x20(%r11,%rdx,1),%ymm4,%ymm0
  1c4413:	vmovupd (%r12,%rdx,1),%ymm4
  1c4419:	add    $0x2,%rax
  1c441d:	vfmadd231pd (%rsi,%rdx,1),%ymm4,%ymm1
  1c4423:	vfmadd231pd (%r14,%rdx,1),%ymm4,%ymm3
  1c4429:	vfmadd231pd 0x0(%rbp,%rdx,1),%ymm4,%ymm2
  1c4430:	vfmadd231pd (%r11,%rdx,1),%ymm4,%ymm0
  1c4436:	add    $0x40,%rdx
  1c443a:	cmp    %rax,%rcx
  1c443d:	jne    1c43f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x6e0>
  1c443f:	test   $0x4,%bl
  1c4442:	jne    1c4e31 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1121>
  1c4448:	jmp    1c4e54 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1144>
  1c444d:	nopl   (%rax)
  1c4450:	mov    %rbx,%rax
  1c4453:	shr    $0x2,%rax
  1c4457:	je     1c48e9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xbd9>
  1c445d:	lea    -0x1(%rax),%rcx
  1c4461:	mov    0x178(%rsp),%rdx
  1c4469:	cmp    %rdx,%rcx
  1c446c:	cmovae %rdx,%rcx
  1c4470:	cmp    %rcx,0x140(%rsp)
  1c4478:	je     1c58b3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1ba3>
  1c447e:	cmp    %rcx,0x58(%rsp)
  1c4483:	je     1c589b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1b8b>
  1c4489:	vxorpd %xmm0,%xmm0,%xmm0
  1c448d:	xor    %ecx,%ecx
  1c448f:	vxorpd %xmm1,%xmm1,%xmm1
  1c4493:	vxorpd %xmm2,%xmm2,%xmm2
  1c4497:	vxorpd %xmm3,%xmm3,%xmm3
  1c449b:	vbroadcastsd -0x1a234c(%rip),%ymm11        # 22158 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x618>
  1c44a4:	mov    0x118(%rsp),%rdi
  1c44ac:	nopl   0x0(%rax)
  1c44b0:	vpcmpeqq (%rdi,%rcx,1),%ymm15,%ymm4
  1c44b6:	vmovupd (%r12,%rcx,1),%ymm5
  1c44bc:	vandpd %ymm5,%ymm10,%ymm6
  1c44c0:	vcmpge_oqpd %ymm11,%ymm6,%ymm7
  1c44c6:	vcmpeqpd %ymm6,%ymm15,%ymm8
  1c44cb:	vorpd  %ymm7,%ymm8,%ymm7
  1c44cf:	vcmple_oqpd %ymm9,%ymm6,%ymm6
  1c44d5:	vandpd %ymm6,%ymm7,%ymm6
  1c44d9:	vpcmpgtq %ymm6,%ymm15,%ymm6
  1c44de:	vpand  %ymm6,%ymm4,%ymm4
  1c44e2:	vpand  %ymm5,%ymm4,%ymm5
  1c44e6:	vpand  (%rsi,%rcx,1),%ymm4,%ymm6
  1c44eb:	vpand  (%r14,%rcx,1),%ymm4,%ymm7
  1c44f1:	vpand  0x0(%rbp,%rcx,1),%ymm4,%ymm8
  1c44f7:	vpand  (%r11,%rcx,1),%ymm4,%ymm4
  1c44fd:	vmulpd %ymm6,%ymm5,%ymm6
  1c4501:	vaddpd %ymm6,%ymm3,%ymm3
  1c4505:	vmulpd %ymm7,%ymm5,%ymm6
  1c4509:	vaddpd %ymm6,%ymm2,%ymm2
  1c450d:	vmulpd %ymm5,%ymm8,%ymm6
  1c4511:	vaddpd %ymm6,%ymm1,%ymm1
  1c4515:	vmulpd %ymm4,%ymm5,%ymm4
  1c4519:	vaddpd %ymm4,%ymm0,%ymm0
  1c451d:	add    $0x20,%rcx
  1c4521:	dec    %rax
  1c4524:	jne    1c44b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x7a0>
  1c4526:	jmp    1c48f9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xbe9>
  1c452b:	vxorpd %xmm10,%xmm10,%xmm10
  1c4530:	vxorpd %xmm4,%xmm4,%xmm4
  1c4534:	vxorpd %xmm8,%xmm8,%xmm8
  1c4539:	vxorpd %xmm7,%xmm7,%xmm7
  1c453d:	vxorpd %xmm11,%xmm11,%xmm11
  1c4542:	vxorpd %xmm5,%xmm5,%xmm5
  1c4546:	vxorpd %xmm9,%xmm9,%xmm9
  1c454b:	vxorpd %xmm6,%xmm6,%xmm6
  1c454f:	mov    0x50(%rsp),%rax
  1c4554:	vextractf128 $0x1,%ymm4,%xmm12
  1c455a:	vaddpd %xmm4,%xmm12,%xmm4
  1c455e:	vshufpd $0x1,%xmm4,%xmm4,%xmm12
  1c4563:	vaddsd %xmm4,%xmm12,%xmm4
  1c4567:	vextractf128 $0x1,%ymm8,%xmm12
  1c456d:	vaddpd %xmm12,%xmm8,%xmm8
  1c4572:	vshufpd $0x1,%xmm8,%xmm8,%xmm12
  1c4578:	vaddsd %xmm12,%xmm8,%xmm8
  1c457d:	vextractf128 $0x1,%ymm7,%xmm12
  1c4583:	vaddpd %xmm7,%xmm12,%xmm7
  1c4587:	vshufpd $0x1,%xmm7,%xmm7,%xmm12
  1c458c:	vaddsd %xmm7,%xmm12,%xmm7
  1c4590:	vextractf128 $0x1,%ymm11,%xmm12
  1c4596:	vaddpd %xmm12,%xmm11,%xmm11
  1c459b:	vshufpd $0x1,%xmm11,%xmm11,%xmm12
  1c45a1:	vaddsd %xmm12,%xmm11,%xmm11
  1c45a6:	vextractf128 $0x1,%ymm5,%xmm12
  1c45ac:	vaddpd %xmm5,%xmm12,%xmm5
  1c45b0:	vshufpd $0x1,%xmm5,%xmm5,%xmm12
  1c45b5:	vaddsd %xmm5,%xmm12,%xmm5
  1c45b9:	vextractf128 $0x1,%ymm9,%xmm12
  1c45bf:	vaddpd %xmm12,%xmm9,%xmm9
  1c45c4:	vshufpd $0x1,%xmm9,%xmm9,%xmm12
  1c45ca:	vaddsd %xmm12,%xmm9,%xmm9
  1c45cf:	vextractf128 $0x1,%ymm6,%xmm12
  1c45d5:	vaddpd %xmm6,%xmm12,%xmm6
  1c45d9:	vshufpd $0x1,%xmm6,%xmm6,%xmm12
  1c45de:	vaddsd %xmm6,%xmm12,%xmm6
  1c45e2:	vextractf128 $0x1,%ymm10,%xmm12
  1c45e8:	vaddpd %xmm12,%xmm10,%xmm10
  1c45ed:	vshufpd $0x1,%xmm10,%xmm10,%xmm12
  1c45f3:	vaddsd %xmm12,%xmm10,%xmm10
  1c45f8:	and    $0x3,%eax
  1c45fb:	mov    %rbx,0x148(%rsp)
  1c4603:	je     1c4814 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xb04>
  1c4609:	mov    0x20(%rsp),%rdi
  1c460e:	and    $0x3,%edi
  1c4611:	je     1c5777 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1a67>
  1c4617:	cmpq   $0x0,0x48(%rsp)
  1c461d:	je     1c575f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1a4f>
  1c4623:	mov    0x10(%rsp),%r9
  1c4628:	and    $0x3,%r9d
  1c462c:	je     1c5749 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1a39>
  1c4632:	mov    %rax,0x38(%rsp)
  1c4637:	mov    0x20(%rsp),%rax
  1c463c:	movabs $0xffffffffffffffc,%r15
  1c4646:	and    %r15,%rax
  1c4649:	mov    0x50(%rsp),%rcx
  1c464e:	and    %r15,%rcx
  1c4651:	mov    0x10(%rsp),%r8
  1c4656:	and    %r15,%r8
  1c4659:	mov    %rcx,0xc0(%rsp)
  1c4661:	vmovsd (%r12,%rcx,8),%xmm12
  1c4667:	mov    0x98(%rsp),%rdx
  1c466f:	vfmadd231sd (%rdx),%xmm12,%xmm4
  1c4674:	mov    0xb0(%rsp),%rbx
  1c467c:	vfmadd231sd (%rbx),%xmm12,%xmm8
  1c4681:	mov    0xa8(%rsp),%rsi
  1c4689:	vfmadd231sd (%rsi),%xmm12,%xmm7
  1c468e:	mov    0xa0(%rsp),%rcx
  1c4696:	vfmadd231sd (%rcx),%xmm12,%xmm11
  1c469b:	mov    0x40(%rsp),%r15
  1c46a0:	vmovsd (%r10,%r15,8),%xmm13
  1c46a6:	vfmadd213sd %xmm0,%xmm3,%xmm13
  1c46ab:	mov    %rax,0x18(%rsp)
  1c46b0:	vfmadd213sd 0x0(%r13,%rax,8),%xmm12,%xmm13
  1c46b7:	mov    0x30(%rsp),%r15
  1c46bc:	mov    %r8,0xb8(%rsp)
  1c46c4:	vmovsd %xmm13,(%r15,%r8,8)
  1c46ca:	vfmadd231sd (%rdx),%xmm13,%xmm5
  1c46cf:	vfmadd231sd (%rbx),%xmm13,%xmm9
  1c46d4:	vfmadd231sd (%rsi),%xmm13,%xmm6
  1c46d9:	vfmadd231sd (%rcx),%xmm13,%xmm10
  1c46de:	mov    0x60(%rsp),%rcx
  1c46e3:	lea    0x2(%rcx),%rbx
  1c46e7:	cmp    0x68(%rsp),%rbx
  1c46ec:	jae    1c470f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x9ff>
  1c46ee:	mov    0x40(%rsp),%r15
  1c46f3:	vmovsd (%r10,%r15,8),%xmm14
  1c46f9:	vfmadd213sd %xmm1,%xmm2,%xmm14
  1c46fe:	vfmadd213sd %xmm12,%xmm14,%xmm13
  1c4703:	mov    0x18(%rsp),%rdx
  1c4708:	vmovsd %xmm13,0x0(%r13,%rdx,8)
  1c470f:	mov    0x38(%rsp),%r8
  1c4714:	cmp    $0x1,%r8d
  1c4718:	je     1c4808 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xaf8>
  1c471e:	cmp    $0x1,%edi
  1c4721:	mov    0xc0(%rsp),%rax
  1c4729:	je     1c5777 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1a67>
  1c472f:	cmpl   $0x1,0x48(%rsp)
  1c4734:	je     1c575f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1a4f>
  1c473a:	cmp    $0x1,%r9d
  1c473e:	je     1c5749 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1a39>
  1c4744:	vmovsd 0x8(%r12,%rax,8),%xmm12
  1c474b:	mov    0x98(%rsp),%rdx
  1c4753:	vfmadd231sd 0x8(%rdx),%xmm12,%xmm4
  1c4759:	mov    0xb0(%rsp),%rbx
  1c4761:	vfmadd231sd 0x8(%rbx),%xmm12,%xmm8
  1c4767:	mov    0xa8(%rsp),%rsi
  1c476f:	vfmadd231sd 0x8(%rsi),%xmm12,%xmm7
  1c4775:	mov    0xa0(%rsp),%rcx
  1c477d:	vfmadd231sd 0x8(%rcx),%xmm12,%xmm11
  1c4783:	mov    0x40(%rsp),%r15
  1c4788:	vmovsd 0x8(%r10,%r15,8),%xmm13
  1c478f:	vfmadd213sd %xmm0,%xmm3,%xmm13
  1c4794:	mov    0x18(%rsp),%r15
  1c4799:	vfmadd213sd 0x8(%r13,%r15,8),%xmm12,%xmm13
  1c47a0:	mov    0x30(%rsp),%r15
  1c47a5:	mov    0xb8(%rsp),%rax
  1c47ad:	vmovsd %xmm13,0x8(%r15,%rax,8)
  1c47b4:	vfmadd231sd 0x8(%rdx),%xmm13,%xmm5
  1c47ba:	vfmadd231sd 0x8(%rbx),%xmm13,%xmm9
  1c47c0:	vfmadd231sd 0x8(%rsi),%xmm13,%xmm6
  1c47c6:	vfmadd231sd 0x8(%rcx),%xmm13,%xmm10
  1c47cc:	mov    0x60(%rsp),%rcx
  1c47d1:	lea    0x2(%rcx),%rbx
  1c47d5:	cmp    0x68(%rsp),%rbx
  1c47da:	jae    1c47fe <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xaee>
  1c47dc:	mov    0x40(%rsp),%r15
  1c47e1:	vmovsd 0x8(%r10,%r15,8),%xmm14
  1c47e8:	vfmadd213sd %xmm1,%xmm2,%xmm14
  1c47ed:	vfmadd213sd %xmm12,%xmm14,%xmm13
  1c47f2:	mov    0x18(%rsp),%rdx
  1c47f7:	vmovsd %xmm13,0x8(%r13,%rdx,8)
  1c47fe:	cmp    $0x2,%r8d
  1c4802:	jne    1c4d4a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x103a>
  1c4808:	mov    0x70(%rsp),%rdx
  1c480d:	mov    0x30(%rsp),%r8
  1c4812:	jmp    1c4823 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xb13>
  1c4814:	mov    0x30(%rsp),%r8
  1c4819:	mov    0x60(%rsp),%rcx
  1c481e:	mov    0x70(%rsp),%rdx
  1c4823:	mov    0x78(%rsp),%rsi
  1c4828:	lea    (%rcx,%rcx,1),%rdi
  1c482c:	cmp    %rsi,%rdi
  1c482f:	jae    1c5800 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1af0>
  1c4835:	mov    %rdi,%rax
  1c4838:	shl    $0x4,%rax
  1c483c:	vmovsd %xmm4,(%rdx,%rax,1)
  1c4841:	vmovsd %xmm8,0x8(%rdx,%rax,1)
  1c4847:	lea    0x1(%rdi),%rax
  1c484b:	cmp    %rsi,%rax
  1c484e:	jae    1c485f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xb4f>
  1c4850:	shl    $0x4,%rax
  1c4854:	vmovsd %xmm7,(%rdx,%rax,1)
  1c4859:	vmovsd %xmm11,0x8(%rdx,%rax,1)
  1c485f:	lea    0x2(,%rcx,2),%rax
  1c4867:	cmp    %rsi,%rax
  1c486a:	jae    1c5810 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1b00>
  1c4870:	shl    $0x4,%rax
  1c4874:	vmovsd %xmm5,(%rdx,%rax,1)
  1c4879:	vmovsd %xmm9,0x8(%rdx,%rax,1)
  1c487f:	add    $0x3,%rdi
  1c4883:	cmp    %rsi,%rdi
  1c4886:	jae    1c4897 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xb87>
  1c4888:	shl    $0x4,%rdi
  1c488c:	vmovsd %xmm6,(%rdx,%rdi,1)
  1c4891:	vmovsd %xmm10,0x8(%rdx,%rdi,1)
  1c4897:	mov    $0x1,%r15b
  1c489a:	cmp    0x68(%rsp),%rbx
  1c489f:	mov    0x20(%rsp),%rsi
  1c48a4:	jb     1c4190 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x480>
  1c48aa:	mov    %rsi,%rax
  1c48ad:	mov    %r13,%rdi
  1c48b0:	mov    0x10(%rsp),%rsi
  1c48b5:	mov    %r8,%r13
  1c48b8:	vbroadcastsd -0x1a27f1(%rip),%ymm9        # 220d0 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x590>
  1c48c1:	vmovupd 0x1d0(%rsp),%ymm10
  1c48ca:	mov    0x50(%rsp),%rbx
  1c48cf:	jmp    1c41b2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x4a2>
  1c48d4:	vxorpd %xmm0,%xmm0,%xmm0
  1c48d8:	vxorpd %xmm2,%xmm2,%xmm2
  1c48dc:	vxorpd %xmm3,%xmm3,%xmm3
  1c48e0:	vxorpd %xmm1,%xmm1,%xmm1
  1c48e4:	jmp    1c4e54 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1144>
  1c48e9:	vxorpd %xmm3,%xmm3,%xmm3
  1c48ed:	vxorpd %xmm2,%xmm2,%xmm2
  1c48f1:	vxorpd %xmm1,%xmm1,%xmm1
  1c48f5:	vxorpd %xmm0,%xmm0,%xmm0
  1c48f9:	vextractf128 $0x1,%ymm3,%xmm4
  1c48ff:	vaddpd %xmm4,%xmm3,%xmm3
  1c4903:	vshufpd $0x1,%xmm3,%xmm3,%xmm4
  1c4908:	vaddsd %xmm4,%xmm3,%xmm3
  1c490c:	vmovsd %xmm3,0x38(%rsp)
  1c4912:	vextractf128 $0x1,%ymm2,%xmm3
  1c4918:	vaddpd %xmm3,%xmm2,%xmm2
  1c491c:	vshufpd $0x1,%xmm2,%xmm2,%xmm3
  1c4921:	vaddsd %xmm3,%xmm2,%xmm2
  1c4925:	vmovsd %xmm2,0x18(%rsp)
  1c492b:	vextractf128 $0x1,%ymm1,%xmm2
  1c4931:	vaddpd %xmm2,%xmm1,%xmm1
  1c4935:	vshufpd $0x1,%xmm1,%xmm1,%xmm2
  1c493a:	vaddsd %xmm2,%xmm1,%xmm3
  1c493e:	vextractf128 $0x1,%ymm0,%xmm1
  1c4944:	vaddpd %xmm1,%xmm0,%xmm0
  1c4948:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1c494d:	vaddsd %xmm1,%xmm0,%xmm4
  1c4951:	mov    %rbx,%r13
  1c4954:	and    $0xfffffffffffffffc,%r13
  1c4958:	je     1c4b40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xe30>
  1c495e:	xor    %r15d,%r15d
  1c4961:	mov    0xe8(%rsp),%rax
  1c4969:	mov    0x128(%rsp),%rbp
  1c4971:	jmp    1c4994 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xc84>
  1c4973:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1c4980:	inc    %r15
  1c4983:	cmp    %r15,%r13
  1c4986:	mov    0xe8(%rsp),%rax
  1c498e:	je     1c4b40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xe30>
  1c4994:	cmp    %r15,%rax
  1c4997:	je     1c565e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x194e>
  1c499d:	mov    0x118(%rsp),%rax
  1c49a5:	mov    (%rax,%r15,8),%r14
  1c49a9:	test   %r14,%r14
  1c49ac:	je     1c4ad0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xdc0>
  1c49b2:	cmp    %rbp,%r15
  1c49b5:	jae    1c56ac <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x199c>
  1c49bb:	mov    0x150(%rsp),%rsi
  1c49c3:	cmp    %rsi,%r15
  1c49c6:	jae    1c56f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x19e0>
  1c49cc:	vmovsd %xmm4,0xb8(%rsp)
  1c49d5:	vmovsd %xmm3,0xc0(%rsp)
  1c49de:	cmp    %rbx,%r15
  1c49e1:	jae    1c56c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x19b2>
  1c49e7:	mov    0x110(%rsp),%rax
  1c49ef:	vmovsd (%rax,%r15,8),%xmm0
  1c49f5:	mov    0x108(%rsp),%rax
  1c49fd:	vmovsd (%rax,%r15,8),%xmm1
  1c4a03:	vmovsd (%r12,%r15,8),%xmm2
  1c4a09:	vmovsd %xmm2,0x138(%rsp)
  1c4a12:	mov    %r14,%rdi
  1c4a15:	vzeroupper
  1c4a18:	call   *0xe5b4a(%rip)        # 2aa568 <_DYNAMIC+0xa58>
  1c4a1e:	cmp    0xe0(%rsp),%r15
  1c4a26:	jae    1c5694 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1984>
  1c4a2c:	cmp    0xd8(%rsp),%r15
  1c4a34:	mov    0xf0(%rsp),%rcx
  1c4a3c:	vmovsd 0x18(%rsp),%xmm3
  1c4a42:	jae    1c56d8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x19c8>
  1c4a48:	vmovsd 0x38(%rsp),%xmm2
  1c4a4e:	vaddsd %xmm0,%xmm2,%xmm2
  1c4a52:	vmovsd %xmm2,0x38(%rsp)
  1c4a58:	vaddsd %xmm1,%xmm3,%xmm3
  1c4a5c:	vmovsd %xmm3,0x18(%rsp)
  1c4a62:	mov    0x100(%rsp),%rax
  1c4a6a:	vmovsd (%rax,%r15,8),%xmm0
  1c4a70:	vmovsd (%rcx,%r15,8),%xmm1
  1c4a76:	vmovsd 0x138(%rsp),%xmm2
  1c4a7f:	mov    %r14,%rdi
  1c4a82:	call   *0xe5ae0(%rip)        # 2aa568 <_DYNAMIC+0xa58>
  1c4a88:	mov    0xf0(%rsp),%r11
  1c4a90:	vmovsd 0xc0(%rsp),%xmm3
  1c4a99:	vaddsd %xmm0,%xmm3,%xmm3
  1c4a9d:	vmovsd 0xb8(%rsp),%xmm4
  1c4aa6:	vaddsd %xmm1,%xmm4,%xmm4
  1c4aaa:	mov    0x120(%rsp),%r10
  1c4ab2:	vxorpd %xmm15,%xmm15,%xmm15
  1c4ab7:	vbroadcastsd -0x1a29f0(%rip),%ymm9        # 220d0 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x590>
  1c4ac0:	vmovupd 0x1d0(%rsp),%ymm10
  1c4ac9:	jmp    1c4980 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xc70>
  1c4ace:	xchg   %ax,%ax
  1c4ad0:	cmp    %rbx,%r15
  1c4ad3:	jae    1c571b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1a0b>
  1c4ad9:	vmovsd (%r12,%r15,8),%xmm1
  1c4adf:	vxorpd %xmm0,%xmm0,%xmm0
  1c4ae3:	vucomisd %xmm0,%xmm1
  1c4ae7:	jne    1c4aef <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xddf>
  1c4ae9:	jnp    1c4980 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xc70>
  1c4aef:	vandpd -0x1a3697(%rip),%xmm1,%xmm0        # 21460 <__abi_tag+0x21164>
  1c4af7:	vmovq  %xmm1,%rax
  1c4afc:	shr    $0x34,%rax
  1c4b00:	and    $0x7ff,%eax
  1c4b05:	cmp    $0x7ff,%eax
  1c4b0a:	setb   %al
  1c4b0d:	vucomisd -0x1a29bd(%rip),%xmm0        # 22158 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x618>
  1c4b15:	jb     1c49b2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xca2>
  1c4b1b:	test   %al,%al
  1c4b1d:	je     1c49b2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xca2>
  1c4b23:	vmovsd -0x1a2a5b(%rip),%xmm1        # 220d0 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x590>
  1c4b2b:	vucomisd %xmm0,%xmm1
  1c4b2f:	jae    1c4980 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xc70>
  1c4b35:	jmp    1c49b2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xca2>
  1c4b3a:	nopw   0x0(%rax,%rax,1)
  1c4b40:	mov    %ebx,%r13d
  1c4b43:	and    $0x3,%r13d
  1c4b47:	je     1c4f80 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1270>
  1c4b4d:	movabs $0xffffffffffffffc,%rcx
  1c4b57:	and    %rcx,%rbx
  1c4b5a:	lea    (%r12,%rbx,8),%rbx
  1c4b5e:	xor    %r15d,%r15d
  1c4b61:	mov    0x98(%rsp),%rcx
  1c4b69:	jmp    1c4bf9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xee9>
  1c4b6e:	xchg   %ax,%ax
  1c4b70:	vmovsd (%rbx,%r15,8),%xmm1
  1c4b76:	vxorpd %xmm0,%xmm0,%xmm0
  1c4b7a:	vucomisd %xmm0,%xmm1
  1c4b7e:	jne    1c4cff <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xfef>
  1c4b84:	jp     1c4cff <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xfef>
  1c4b8a:	cmp    0x48(%rsp),%r15
  1c4b8f:	jae    1c5731 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1a21>
  1c4b95:	vmulsd (%rcx,%r15,8),%xmm1,%xmm5
  1c4b9b:	mov    0xb0(%rsp),%rax
  1c4ba3:	vmulsd (%rax,%r15,8),%xmm1,%xmm6
  1c4ba9:	mov    0xa8(%rsp),%rax
  1c4bb1:	vmulsd (%rax,%r15,8),%xmm1,%xmm0
  1c4bb7:	mov    0xa0(%rsp),%rax
  1c4bbf:	vmulsd (%rax,%r15,8),%xmm1,%xmm1
  1c4bc5:	vmovsd 0x38(%rsp),%xmm2
  1c4bcb:	vaddsd %xmm5,%xmm2,%xmm2
  1c4bcf:	vmovsd %xmm2,0x38(%rsp)
  1c4bd5:	vmovsd 0x18(%rsp),%xmm2
  1c4bdb:	vaddsd %xmm6,%xmm2,%xmm2
  1c4bdf:	vmovsd %xmm2,0x18(%rsp)
  1c4be5:	vaddsd %xmm0,%xmm3,%xmm3
  1c4be9:	vaddsd %xmm1,%xmm4,%xmm4
  1c4bed:	inc    %r15
  1c4bf0:	cmp    %r15,%r13
  1c4bf3:	je     1c4f80 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1270>
  1c4bf9:	cmp    %r15,0x158(%rsp)
  1c4c01:	je     1c5679 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1969>
  1c4c07:	mov    0x190(%rsp),%rax
  1c4c0f:	mov    (%rax,%r15,8),%r14
  1c4c13:	test   %r14,%r14
  1c4c16:	je     1c4b70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xe60>
  1c4c1c:	vmovsd %xmm4,0xb8(%rsp)
  1c4c25:	vmovsd %xmm3,0xc0(%rsp)
  1c4c2e:	cmp    0x48(%rsp),%r15
  1c4c33:	jae    1c5703 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x19f3>
  1c4c39:	vmovsd (%rcx,%r15,8),%xmm0
  1c4c3f:	mov    0xb0(%rsp),%rax
  1c4c47:	vmovsd (%rax,%r15,8),%xmm1
  1c4c4d:	vmovsd (%rbx,%r15,8),%xmm2
  1c4c53:	vmovsd %xmm2,0x138(%rsp)
  1c4c5c:	mov    %r14,%rdi
  1c4c5f:	mov    0xe5902(%rip),%rbp        # 2aa568 <_DYNAMIC+0xa58>
  1c4c66:	vzeroupper
  1c4c69:	call   *%rbp
  1c4c6b:	vmovsd %xmm0,0x1a0(%rsp)
  1c4c74:	vmovsd %xmm1,0x198(%rsp)
  1c4c7d:	mov    0xa8(%rsp),%rax
  1c4c85:	vmovsd (%rax,%r15,8),%xmm0
  1c4c8b:	mov    0xa0(%rsp),%rax
  1c4c93:	vmovsd (%rax,%r15,8),%xmm1
  1c4c99:	vmovsd 0x138(%rsp),%xmm2
  1c4ca2:	mov    %r14,%rdi
  1c4ca5:	call   *%rbp
  1c4ca7:	vmovsd 0x198(%rsp),%xmm6
  1c4cb0:	vmovsd 0x1a0(%rsp),%xmm5
  1c4cb9:	mov    0x98(%rsp),%rcx
  1c4cc1:	mov    0xf0(%rsp),%r11
  1c4cc9:	mov    0x120(%rsp),%r10
  1c4cd1:	vxorpd %xmm15,%xmm15,%xmm15
  1c4cd6:	vbroadcastsd -0x1a2c0f(%rip),%ymm9        # 220d0 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x590>
  1c4cdf:	vmovupd 0x1d0(%rsp),%ymm10
  1c4ce8:	vmovsd 0xc0(%rsp),%xmm3
  1c4cf1:	vmovsd 0xb8(%rsp),%xmm4
  1c4cfa:	jmp    1c4bc5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xeb5>
  1c4cff:	vandpd -0x1a38a7(%rip),%xmm1,%xmm0        # 21460 <__abi_tag+0x21164>
  1c4d07:	vmovq  %xmm1,%rax
  1c4d0c:	shr    $0x34,%rax
  1c4d10:	and    $0x7ff,%eax
  1c4d15:	cmp    $0x7ff,%eax
  1c4d1a:	setb   %al
  1c4d1d:	vucomisd -0x1a2bcd(%rip),%xmm0        # 22158 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x618>
  1c4d25:	jb     1c4c1c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xf0c>
  1c4d2b:	test   %al,%al
  1c4d2d:	je     1c4c1c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xf0c>
  1c4d33:	vmovsd -0x1a2c6b(%rip),%xmm2        # 220d0 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x590>
  1c4d3b:	vucomisd %xmm0,%xmm2
  1c4d3f:	jae    1c4b8a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xe7a>
  1c4d45:	jmp    1c4c1c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xf0c>
  1c4d4a:	cmp    $0x2,%edi
  1c4d4d:	mov    0xc0(%rsp),%rax
  1c4d55:	je     1c5777 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1a67>
  1c4d5b:	cmpl   $0x2,0x48(%rsp)
  1c4d60:	je     1c575f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1a4f>
  1c4d66:	cmp    $0x2,%r9d
  1c4d6a:	je     1c5749 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1a39>
  1c4d70:	vmovsd 0x10(%r12,%rax,8),%xmm12
  1c4d77:	mov    0x98(%rsp),%rdx
  1c4d7f:	vfmadd231sd 0x10(%rdx),%xmm12,%xmm4
  1c4d85:	mov    0xb0(%rsp),%rdi
  1c4d8d:	vfmadd231sd 0x10(%rdi),%xmm12,%xmm8
  1c4d93:	mov    0xa8(%rsp),%rsi
  1c4d9b:	vfmadd231sd 0x10(%rsi),%xmm12,%xmm7
  1c4da1:	mov    0xa0(%rsp),%rcx
  1c4da9:	vfmadd231sd 0x10(%rcx),%xmm12,%xmm11
  1c4daf:	mov    0x40(%rsp),%rax
  1c4db4:	vfmadd231sd 0x10(%r10,%rax,8),%xmm3,%xmm0
  1c4dbb:	mov    0x18(%rsp),%r9
  1c4dc0:	vfmadd213sd 0x10(%r13,%r9,8),%xmm12,%xmm0
  1c4dc7:	mov    0x30(%rsp),%r8
  1c4dcc:	mov    0xb8(%rsp),%rbx
  1c4dd4:	vmovsd %xmm0,0x10(%r8,%rbx,8)
  1c4ddb:	vfmadd231sd 0x10(%rdx),%xmm0,%xmm5
  1c4de1:	vfmadd231sd 0x10(%rdi),%xmm0,%xmm9
  1c4de7:	vfmadd231sd 0x10(%rsi),%xmm0,%xmm6
  1c4ded:	vfmadd231sd 0x10(%rcx),%xmm0,%xmm10
  1c4df3:	mov    0x60(%rsp),%rcx
  1c4df8:	lea    0x2(%rcx),%rbx
  1c4dfc:	cmp    0x68(%rsp),%rbx
  1c4e01:	jae    1c481e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xb0e>
  1c4e07:	vfmadd231sd 0x10(%r10,%rax,8),%xmm2,%xmm1
  1c4e0e:	vfmadd213sd %xmm12,%xmm1,%xmm0
  1c4e13:	vmovsd %xmm0,0x10(%r13,%r9,8)
  1c4e1a:	jmp    1c481e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0xb0e>
  1c4e1f:	vxorpd %xmm1,%xmm1,%xmm1
  1c4e23:	xor    %eax,%eax
  1c4e25:	vxorpd %xmm3,%xmm3,%xmm3
  1c4e29:	vxorpd %xmm2,%xmm2,%xmm2
  1c4e2d:	vxorpd %xmm0,%xmm0,%xmm0
  1c4e31:	shl    $0x5,%rax
  1c4e35:	vmovupd (%r12,%rax,1),%ymm4
  1c4e3b:	vfmadd231pd (%rsi,%rax,1),%ymm4,%ymm1
  1c4e41:	vfmadd231pd (%r14,%rax,1),%ymm4,%ymm3
  1c4e47:	vfmadd231pd 0x0(%rbp,%rax,1),%ymm4,%ymm2
  1c4e4e:	vfmadd231pd (%r11,%rax,1),%ymm4,%ymm0
  1c4e54:	mov    %ebx,%eax
  1c4e56:	vextractf128 $0x1,%ymm1,%xmm4
  1c4e5c:	vaddpd %xmm4,%xmm1,%xmm1
  1c4e60:	vshufpd $0x1,%xmm1,%xmm1,%xmm4
  1c4e65:	vaddsd %xmm4,%xmm1,%xmm1
  1c4e69:	vmovsd %xmm1,0x38(%rsp)
  1c4e6f:	vextractf128 $0x1,%ymm3,%xmm1
  1c4e75:	vaddpd %xmm1,%xmm3,%xmm1
  1c4e79:	vshufpd $0x1,%xmm1,%xmm1,%xmm3
  1c4e7e:	vaddsd %xmm3,%xmm1,%xmm1
  1c4e82:	vmovsd %xmm1,0x18(%rsp)
  1c4e88:	vextractf128 $0x1,%ymm2,%xmm1
  1c4e8e:	vaddpd %xmm1,%xmm2,%xmm1
  1c4e92:	vshufpd $0x1,%xmm1,%xmm1,%xmm2
  1c4e97:	vaddsd %xmm2,%xmm1,%xmm3
  1c4e9b:	vextractf128 $0x1,%ymm0,%xmm1
  1c4ea1:	vaddpd %xmm1,%xmm0,%xmm0
  1c4ea5:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1c4eaa:	vaddsd %xmm1,%xmm0,%xmm4
  1c4eae:	and    $0x3,%eax
  1c4eb1:	je     1c4f80 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1270>
  1c4eb7:	lea    -0x1(%rax),%ecx
  1c4eba:	cmp    %ecx,0x48(%rsp)
  1c4ebe:	jbe    1c5883 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1b73>
  1c4ec4:	mov    %rbx,%rcx
  1c4ec7:	movabs $0xffffffffffffffc,%rdx
  1c4ed1:	and    %rdx,%rcx
  1c4ed4:	vmovsd (%r12,%rcx,8),%xmm0
  1c4eda:	mov    0x98(%rsp),%rdx
  1c4ee2:	vmovsd 0x38(%rsp),%xmm1
  1c4ee8:	vfmadd231sd (%rdx),%xmm0,%xmm1
  1c4eed:	mov    0xb0(%rsp),%rsi
  1c4ef5:	vmovsd 0x18(%rsp),%xmm2
  1c4efb:	vfmadd231sd (%rsi),%xmm0,%xmm2
  1c4f00:	mov    0xa8(%rsp),%rdi
  1c4f08:	vfmadd231sd (%rdi),%xmm0,%xmm3
  1c4f0d:	mov    0xa0(%rsp),%r8
  1c4f15:	vfmadd231sd (%r8),%xmm0,%xmm4
  1c4f1a:	cmp    $0x1,%eax
  1c4f1d:	je     1c4f43 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1233>
  1c4f1f:	vmovsd 0x8(%r12,%rcx,8),%xmm0
  1c4f26:	vfmadd231sd 0x8(%rdx),%xmm0,%xmm1
  1c4f2c:	vfmadd231sd 0x8(%rsi),%xmm0,%xmm2
  1c4f32:	vfmadd231sd 0x8(%rdi),%xmm0,%xmm3
  1c4f38:	vfmadd231sd 0x8(%r8),%xmm0,%xmm4
  1c4f3e:	cmp    $0x2,%eax
  1c4f41:	jne    1c4f51 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1241>
  1c4f43:	vmovsd %xmm2,0x18(%rsp)
  1c4f49:	vmovsd %xmm1,0x38(%rsp)
  1c4f4f:	jmp    1c4f80 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1270>
  1c4f51:	vmovsd 0x10(%r12,%rcx,8),%xmm0
  1c4f58:	vfmadd231sd 0x10(%rdx),%xmm0,%xmm1
  1c4f5e:	vmovsd %xmm1,0x38(%rsp)
  1c4f64:	vfmadd231sd 0x10(%rsi),%xmm0,%xmm2
  1c4f6a:	vmovsd %xmm2,0x18(%rsp)
  1c4f70:	vfmadd231sd 0x10(%rdi),%xmm0,%xmm3
  1c4f76:	vfmadd231sd 0x10(%r8),%xmm0,%xmm4
  1c4f7c:	nopl   0x0(%rax)
  1c4f80:	mov    0x60(%rsp),%rcx
  1c4f85:	lea    (%rcx,%rcx,1),%rdi
  1c4f89:	mov    0x78(%rsp),%rsi
  1c4f8e:	cmp    %rsi,%rdi
  1c4f91:	jae    1c57f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1ae0>
  1c4f97:	mov    %rdi,%rax
  1c4f9a:	shl    $0x4,%rax
  1c4f9e:	mov    0x70(%rsp),%rdx
  1c4fa3:	vmovsd 0x38(%rsp),%xmm0
  1c4fa9:	vmovsd %xmm0,(%rdx,%rax,1)
  1c4fae:	vmovsd 0x18(%rsp),%xmm0
  1c4fb4:	vmovsd %xmm0,0x8(%rdx,%rax,1)
  1c4fba:	inc    %rdi
  1c4fbd:	cmp    0x130(%rsp),%rdi
  1c4fc5:	mov    0x108(%rsp),%r14
  1c4fcd:	mov    0x100(%rsp),%rbp
  1c4fd5:	mov    0x50(%rsp),%rbx
  1c4fda:	mov    0xf8(%rsp),%r13
  1c4fe2:	jae    1c4ffc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x12ec>
  1c4fe4:	cmp    %rsi,%rdi
  1c4fe7:	jae    1c585b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1b4b>
  1c4fed:	shl    $0x4,%rdi
  1c4ff1:	vmovsd %xmm3,(%rdx,%rdi,1)
  1c4ff6:	vmovsd %xmm4,0x8(%rdx,%rdi,1)
  1c4ffc:	lea    0x1(%rcx),%rax
  1c5000:	cmp    0x68(%rsp),%rax
  1c5005:	je     1c55dd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x18cd>
  1c500b:	cmp    0x90(%rsp),%rcx
  1c5013:	jae    1c5823 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1b13>
  1c5019:	cmp    0x88(%rsp),%rcx
  1c5021:	mov    0x20(%rsp),%rdx
  1c5026:	jae    1c583e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1b2e>
  1c502c:	mov    %edx,%ecx
  1c502e:	and    $0x3,%ecx
  1c5031:	mov    0x10(%rsp),%rax
  1c5036:	and    $0x3,%eax
  1c5039:	cmp    %rax,%rcx
  1c503c:	jne    1c3fad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x29d>
  1c5042:	cmp    0x48(%rsp),%ecx
  1c5046:	jne    1c3fad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x29d>
  1c504c:	mov    %ebx,%eax
  1c504e:	and    $0x3,%eax
  1c5051:	cmp    %eax,%ecx
  1c5053:	jne    1c3fad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x29d>
  1c5059:	shr    $0x2,%rdx
  1c505d:	cmp    0x58(%rsp),%rdx
  1c5062:	jne    1c3fad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x29d>
  1c5068:	mov    %rbx,%r15
  1c506b:	shr    $0x2,%r15
  1c506f:	cmp    %r15,%rdx
  1c5072:	jne    1c3fad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x29d>
  1c5078:	mov    0x10(%rsp),%rsi
  1c507d:	shr    $0x2,%rsi
  1c5081:	cmp    %rsi,%rdx
  1c5084:	jne    1c3fad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x29d>
  1c508a:	cmpq   $0x0,0x58(%rsp)
  1c5090:	je     1c51c6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x14b6>
  1c5096:	mov    0xd0(%rsp),%rdx
  1c509e:	mov    0x60(%rsp),%rcx
  1c50a3:	vbroadcastsd (%rdx,%rcx,8),%ymm0
  1c50a9:	mov    0xc8(%rsp),%rdx
  1c50b1:	vbroadcastsd (%rdx,%rcx,8),%ymm1
  1c50b7:	cmpq   $0x10,0x128(%rsp)
  1c50c0:	jae    1c50c9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x13b9>
  1c50c2:	xor    %edx,%edx
  1c50c4:	jmp    1c5179 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1469>
  1c50c9:	mov    $0x60,%esi
  1c50ce:	xor    %edx,%edx
  1c50d0:	mov    0x30(%rsp),%rcx
  1c50d5:	mov    0x168(%rsp),%rdi
  1c50dd:	nopl   (%rax)
  1c50e0:	vmovupd -0x60(%r10,%rsi,1),%ymm2
  1c50e7:	vfmadd213pd %ymm1,%ymm0,%ymm2
  1c50ec:	vmovupd -0x60(%r12,%rsi,1),%ymm3
  1c50f3:	vfmadd213pd -0x60(%r13,%rsi,1),%ymm2,%ymm3
  1c50fa:	vmovupd %ymm3,-0x60(%rcx,%rsi,1)
  1c5100:	vmovupd -0x40(%r10,%rsi,1),%ymm2
  1c5107:	vfmadd213pd %ymm1,%ymm0,%ymm2
  1c510c:	vmovupd -0x40(%r12,%rsi,1),%ymm3
  1c5113:	vfmadd213pd -0x40(%r13,%rsi,1),%ymm2,%ymm3
  1c511a:	vmovupd %ymm3,-0x40(%rcx,%rsi,1)
  1c5120:	vmovupd -0x20(%r10,%rsi,1),%ymm2
  1c5127:	vfmadd213pd %ymm1,%ymm0,%ymm2
  1c512c:	vmovupd -0x20(%r12,%rsi,1),%ymm3
  1c5133:	vfmadd213pd -0x20(%r13,%rsi,1),%ymm2,%ymm3
  1c513a:	vmovupd %ymm3,-0x20(%rcx,%rsi,1)
  1c5140:	add    $0x4,%rdx
  1c5144:	vmovupd (%r10,%rsi,1),%ymm2
  1c514a:	vfmadd213pd %ymm1,%ymm0,%ymm2
  1c514f:	vmovupd (%r12,%rsi,1),%ymm3
  1c5155:	vfmadd213pd 0x0(%r13,%rsi,1),%ymm2,%ymm3
  1c515c:	vmovupd %ymm3,(%rcx,%rsi,1)
  1c5161:	sub    $0xffffffffffffff80,%rsi
  1c5165:	cmp    %rdx,%rdi
  1c5168:	jne    1c50e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x13d0>
  1c516e:	cmpq   $0x0,0x170(%rsp)
  1c5177:	je     1c51c6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x14b6>
  1c5179:	shl    $0x5,%rdx
  1c517d:	mov    0x30(%rsp),%rcx
  1c5182:	lea    (%rcx,%rdx,1),%rsi
  1c5186:	mov    0x180(%rsp),%rcx
  1c518e:	lea    (%rdx,%r13,1),%rdi
  1c5192:	lea    (%r12,%rdx,1),%r8
  1c5196:	add    %r10,%rdx
  1c5199:	xor    %r9d,%r9d
  1c519c:	nopl   0x0(%rax)
  1c51a0:	vmovupd (%rdx,%r9,1),%ymm2
  1c51a6:	vfmadd213pd %ymm1,%ymm0,%ymm2
  1c51ab:	vmovupd (%r8,%r9,1),%ymm3
  1c51b1:	vfmadd213pd (%rdi,%r9,1),%ymm2,%ymm3
  1c51b7:	vmovupd %ymm3,(%rsi,%r9,1)
  1c51bd:	add    $0x20,%r9
  1c51c1:	cmp    %r9,%rcx
  1c51c4:	jne    1c51a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1490>
  1c51c6:	mov    %rbx,%rdx
  1c51c9:	movabs $0xffffffffffffffc,%rcx
  1c51d3:	and    %rcx,%rdx
  1c51d6:	mov    0x10(%rsp),%rsi
  1c51db:	and    %rcx,%rsi
  1c51de:	test   %rax,%rax
  1c51e1:	mov    0x30(%rsp),%rcx
  1c51e6:	mov    0x60(%rsp),%r9
  1c51eb:	je     1c52d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x15c0>
  1c51f1:	mov    0x20(%rsp),%rdi
  1c51f6:	mov    0xd0(%rsp),%r8
  1c51fe:	vmovsd (%r8,%r9,8),%xmm0
  1c5204:	mov    0x40(%rsp),%r8
  1c5209:	vmovsd (%r10,%r8,8),%xmm1
  1c520f:	mov    0xc8(%rsp),%r8
  1c5217:	vfmadd213sd (%r8,%r9,8),%xmm0,%xmm1
  1c521d:	movabs $0xffffffffffffffc,%r8
  1c5227:	and    %r8,%rdi
  1c522a:	vmovsd (%r12,%rdx,8),%xmm0
  1c5230:	vfmadd213sd 0x0(%r13,%rdi,8),%xmm1,%xmm0
  1c5237:	vmovsd %xmm0,(%rcx,%rsi,8)
  1c523c:	cmp    $0x1,%eax
  1c523f:	je     1c52d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x15c0>
  1c5245:	mov    0xd0(%rsp),%r8
  1c524d:	vmovsd (%r8,%r9,8),%xmm0
  1c5253:	mov    0x40(%rsp),%r8
  1c5258:	vmovsd 0x8(%r10,%r8,8),%xmm1
  1c525f:	mov    0xc8(%rsp),%r8
  1c5267:	vfmadd213sd (%r8,%r9,8),%xmm0,%xmm1
  1c526d:	vmovsd 0x8(%r12,%rdx,8),%xmm0
  1c5274:	vfmadd213sd 0x8(%r13,%rdi,8),%xmm1,%xmm0
  1c527b:	vmovsd %xmm0,0x8(%rcx,%rsi,8)
  1c5281:	cmp    $0x2,%eax
  1c5284:	je     1c52d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x15c0>
  1c5286:	mov    0xd0(%rsp),%r8
  1c528e:	vmovsd (%r8,%r9,8),%xmm0
  1c5294:	mov    0x40(%rsp),%r8
  1c5299:	vmovsd 0x10(%r10,%r8,8),%xmm1
  1c52a0:	mov    0xc8(%rsp),%r8
  1c52a8:	vfmadd213sd (%r8,%r9,8),%xmm0,%xmm1
  1c52ae:	vmovsd 0x10(%r12,%rdx,8),%xmm0
  1c52b5:	vfmadd213sd 0x10(%r13,%rdi,8),%xmm1,%xmm0
  1c52bc:	vmovsd %xmm0,0x10(%rcx,%rsi,8)
  1c52c2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1c52d0:	cmpb   $0x0,0x2e(%rsp)
  1c52d5:	je     1c52e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x15d0>
  1c52d7:	mov    $0x1,%r15b
  1c52da:	jmp    1c5500 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x17f0>
  1c52df:	nop
  1c52e0:	mov    0x188(%rsp),%rdi
  1c52e8:	movb   $0x1,(%rdi)
  1c52eb:	test   %r15,%r15
  1c52ee:	je     1c5369 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1659>
  1c52f0:	xor    %edi,%edi
  1c52f2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1c5300:	vandpd (%r12,%rdi,1),%ymm10,%ymm0
  1c5306:	vandpd (%rcx,%rdi,1),%ymm10,%ymm1
  1c530b:	vcmpeqpd %ymm0,%ymm0,%ymm2
  1c5310:	vcmpeqpd %ymm1,%ymm1,%ymm3
  1c5315:	vmaxpd %ymm1,%ymm0,%ymm4
  1c5319:	vblendvpd %ymm3,%ymm4,%ymm0,%ymm0
  1c531f:	vblendvpd %ymm2,%ymm0,%ymm1,%ymm0
  1c5325:	vcmpeqpd %ymm0,%ymm15,%ymm1
  1c532a:	vblendvpd %ymm1,%ymm9,%ymm0,%ymm1
  1c5330:	vcmple_oqpd %ymm9,%ymm0,%ymm0
  1c5336:	vpcmpgtq %ymm0,%ymm15,%ymm0
  1c533b:	vpand  %ymm1,%ymm0,%ymm0
  1c533f:	vextracti128 $0x1,%ymm0,%xmm1
  1c5345:	vminpd %xmm1,%xmm0,%xmm0
  1c5349:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1c534e:	vminsd %xmm1,%xmm0,%xmm0
  1c5352:	vmovsd -0x1a3202(%rip),%xmm1        # 22158 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x618>
  1c535a:	vucomisd %xmm0,%xmm1
  1c535e:	ja     1c53d8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x16c8>
  1c5360:	add    $0x20,%rdi
  1c5364:	dec    %r15
  1c5367:	jne    1c5300 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x15f0>
  1c5369:	test   %rax,%rax
  1c536c:	movzbl 0xf(%rsp),%r15d
  1c5372:	je     1c5500 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x17f0>
  1c5378:	vmovsd (%r12,%rdx,8),%xmm0
  1c537e:	vmovddup -0x1a3346(%rip),%xmm2        # 22040 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x500>
  1c5386:	vandpd %xmm2,%xmm0,%xmm0
  1c538a:	vmovsd (%rcx,%rsi,8),%xmm1
  1c538f:	vandpd %xmm2,%xmm1,%xmm1
  1c5393:	vmaxsd %xmm1,%xmm0,%xmm2
  1c5397:	vcmpunordsd %xmm1,%xmm1,%xmm1
  1c539c:	vblendvpd %xmm1,%xmm0,%xmm2,%xmm0
  1c53a2:	vmovsd -0x1a32da(%rip),%xmm1        # 220d0 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x590>
  1c53aa:	vucomisd %xmm0,%xmm1
  1c53ae:	jb     1c53ce <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x16be>
  1c53b0:	vxorpd %xmm1,%xmm1,%xmm1
  1c53b4:	vucomisd %xmm1,%xmm0
  1c53b8:	jne    1c53c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x16b0>
  1c53ba:	jnp    1c54f5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x17e5>
  1c53c0:	vucomisd -0x1a3270(%rip),%xmm0        # 22158 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x618>
  1c53c8:	jae    1c54f5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x17e5>
  1c53ce:	xor    %edi,%edi
  1c53d0:	cmp    %eax,%edi
  1c53d2:	jae    1c54da <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x17ca>
  1c53d8:	test   %rbx,%rbx
  1c53db:	mov    0x10(%rsp),%r15
  1c53e0:	je     1c5413 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1703>
  1c53e2:	lea    0x0(,%rbx,8),%rax
  1c53ea:	xor    %esi,%esi
  1c53ec:	nopl   0x0(%rax)
  1c53f0:	mov    (%r12,%rsi,1),%rdx
  1c53f4:	shr    $0x34,%rdx
  1c53f8:	and    $0x7ff,%edx
  1c53fe:	cmp    $0x7fe,%edx
  1c5404:	ja     1c3fad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x29d>
  1c540a:	add    $0x8,%rsi
  1c540e:	cmp    %rsi,%rax
  1c5411:	jne    1c53f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x16e0>
  1c5413:	test   %r15,%r15
  1c5416:	je     1c5453 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1743>
  1c5418:	lea    0x0(,%r15,8),%rax
  1c5420:	xor    %esi,%esi
  1c5422:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1c5430:	mov    (%rcx,%rsi,1),%rdx
  1c5434:	shr    $0x34,%rdx
  1c5438:	and    $0x7ff,%edx
  1c543e:	cmp    $0x7fe,%edx
  1c5444:	ja     1c3fad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x29d>
  1c544a:	add    $0x8,%rsi
  1c544e:	cmp    %rsi,%rax
  1c5451:	jne    1c5430 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1720>
  1c5453:	mov    0xe8(%rsp),%rax
  1c545b:	mov    %rax,(%rsp)
  1c545f:	lea    0x1a8(%rsp),%rdi
  1c5467:	mov    %r12,%rsi
  1c546a:	mov    %rbx,%rdx
  1c546d:	mov    %r15,%r8
  1c5470:	mov    0x118(%rsp),%r9
  1c5478:	vzeroupper
  1c547b:	call   *0xe4c67(%rip)        # 2aa0e8 <_DYNAMIC+0x5d8>
  1c5481:	mov    0x1a8(%rsp),%rax
  1c5489:	movzbl 0x1b0(%rsp),%ecx
  1c5491:	cmp    $0xffffffffffffffff,%rax
  1c5495:	jne    1c55ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x18de>
  1c549b:	mov    0x20(%rsp),%rax
  1c54a0:	mov    %r13,%rdi
  1c54a3:	mov    %r15,%rsi
  1c54a6:	mov    0x30(%rsp),%r13
  1c54ab:	mov    0xf0(%rsp),%r11
  1c54b3:	mov    0x120(%rsp),%r10
  1c54bb:	vpxor  %xmm15,%xmm15,%xmm15
  1c54c0:	vbroadcastsd -0x1a33f9(%rip),%ymm9        # 220d0 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x590>
  1c54c9:	vmovupd 0x1d0(%rsp),%ymm10
  1c54d2:	mov    %ecx,%r15d
  1c54d5:	jmp    1c41b2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x4a2>
  1c54da:	mov    0x20(%rsp),%rax
  1c54df:	mov    %r13,%rdi
  1c54e2:	mov    0x10(%rsp),%rsi
  1c54e7:	mov    %rcx,%r13
  1c54ea:	movzbl 0xf(%rsp),%r15d
  1c54f0:	jmp    1c41b2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x4a2>
  1c54f5:	cmp    $0x1,%eax
  1c54f8:	jne    1c5515 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1805>
  1c54fa:	nopw   0x0(%rax,%rax,1)
  1c5500:	mov    0x20(%rsp),%rax
  1c5505:	mov    %r13,%rdi
  1c5508:	mov    0x10(%rsp),%rsi
  1c550d:	mov    %rcx,%r13
  1c5510:	jmp    1c41b2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x4a2>
  1c5515:	vmovsd 0x8(%r12,%rdx,8),%xmm0
  1c551c:	vmovddup -0x1a34e4(%rip),%xmm2        # 22040 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x500>
  1c5524:	vandpd %xmm2,%xmm0,%xmm0
  1c5528:	vmovsd 0x8(%rcx,%rsi,8),%xmm1
  1c552e:	vandpd %xmm2,%xmm1,%xmm1
  1c5532:	vmaxsd %xmm1,%xmm0,%xmm2
  1c5536:	vcmpunordsd %xmm1,%xmm1,%xmm1
  1c553b:	vblendvpd %xmm1,%xmm0,%xmm2,%xmm0
  1c5541:	mov    $0x1,%edi
  1c5546:	vmovsd -0x1a347e(%rip),%xmm1        # 220d0 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x590>
  1c554e:	vucomisd %xmm0,%xmm1
  1c5552:	jb     1c53d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x16c0>
  1c5558:	vxorpd %xmm1,%xmm1,%xmm1
  1c555c:	vucomisd %xmm1,%xmm0
  1c5560:	jne    1c5564 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1854>
  1c5562:	jnp    1c5572 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1862>
  1c5564:	vucomisd -0x1a3414(%rip),%xmm0        # 22158 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x618>
  1c556c:	jb     1c53d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x16c0>
  1c5572:	cmp    $0x2,%eax
  1c5575:	je     1c5500 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x17f0>
  1c5577:	vmovsd 0x10(%r12,%rdx,8),%xmm0
  1c557e:	vmovddup -0x1a3546(%rip),%xmm2        # 22040 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x500>
  1c5586:	vandpd %xmm2,%xmm0,%xmm0
  1c558a:	vmovsd 0x10(%rcx,%rsi,8),%xmm1
  1c5590:	vandpd %xmm2,%xmm1,%xmm1
  1c5594:	vmaxsd %xmm1,%xmm0,%xmm2
  1c5598:	vcmpunordsd %xmm1,%xmm1,%xmm1
  1c559d:	vblendvpd %xmm1,%xmm0,%xmm2,%xmm0
  1c55a3:	mov    $0x2,%edi
  1c55a8:	vmovsd -0x1a34e0(%rip),%xmm1        # 220d0 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x590>
  1c55b0:	vucomisd %xmm0,%xmm1
  1c55b4:	jb     1c53d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x16c0>
  1c55ba:	vxorpd %xmm1,%xmm1,%xmm1
  1c55be:	vucomisd %xmm1,%xmm0
  1c55c2:	jne    1c55ca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x18ba>
  1c55c4:	jnp    1c5500 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x17f0>
  1c55ca:	vucomisd -0x1a347a(%rip),%xmm0        # 22158 <anon.b142ac114ed83575cb0007479b883929.83.llvm.18333025889273256457+0x618>
  1c55d2:	jb     1c53d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x16c0>
  1c55d8:	jmp    1c5500 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x17f0>
  1c55dd:	mov    0x80(%rsp),%rax
  1c55e5:	movb   $0x1,0x8(%rax)
  1c55e9:	jmp    1c3fb9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x2a9>
  1c55ee:	vmovups 0x1b1(%rsp),%xmm0
  1c55f7:	vmovups 0x1c0(%rsp),%xmm1
  1c5600:	mov    0x80(%rsp),%rdx
  1c5608:	vmovups %xmm1,0x18(%rdx)
  1c560d:	vmovups %xmm0,0x9(%rdx)
  1c5612:	mov    %rax,(%rdx)
  1c5615:	mov    %cl,0x8(%rdx)
  1c5618:	jmp    1c3fc0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x2b0>
  1c561d:	lea    0xd9d2c(%rip),%rdx        # 29f350 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x740>
  1c5624:	mov    %r8,%rdi
  1c5627:	mov    %r8,%rsi
  1c562a:	vzeroupper
  1c562d:	call   *0xe4795(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c5633:	lea    0xd9cfe(%rip),%rdx        # 29f338 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x728>
  1c563a:	mov    0x58(%rsp),%rdi
  1c563f:	mov    %rdi,%rsi
  1c5642:	vzeroupper
  1c5645:	call   *0xe477d(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c564b:	lea    0xd9cce(%rip),%rdx        # 29f320 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x710>
  1c5652:	mov    %rdi,%rsi
  1c5655:	vzeroupper
  1c5658:	call   *0xe476a(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c565e:	lea    0xda4cb(%rip),%rdx        # 29fb30 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf20>
  1c5665:	mov    0xe8(%rsp),%rdi
  1c566d:	mov    %rdi,%rsi
  1c5670:	vzeroupper
  1c5673:	call   *0xe474f(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c5679:	lea    0xda3d8(%rip),%rdx        # 29fa58 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe48>
  1c5680:	mov    0x158(%rsp),%rdi
  1c5688:	mov    %rdi,%rsi
  1c568b:	vzeroupper
  1c568e:	call   *0xe4734(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c5694:	lea    0xda53d(%rip),%rdx        # 29fbd8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xfc8>
  1c569b:	mov    %r15,%rdi
  1c569e:	mov    0xe0(%rsp),%rsi
  1c56a6:	call   *0xe471c(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c56ac:	lea    0xda4dd(%rip),%rdx        # 29fb90 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf80>
  1c56b3:	mov    %r15,%rdi
  1c56b6:	mov    %rbp,%rsi
  1c56b9:	vzeroupper
  1c56bc:	call   *0xe4706(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c56c2:	lea    0xda4f7(%rip),%rdx        # 29fbc0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xfb0>
  1c56c9:	mov    %r15,%rdi
  1c56cc:	mov    %rbx,%rsi
  1c56cf:	vzeroupper
  1c56d2:	call   *0xe46f0(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c56d8:	lea    0xda511(%rip),%rdx        # 29fbf0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xfe0>
  1c56df:	mov    %r15,%rdi
  1c56e2:	mov    0xd8(%rsp),%rsi
  1c56ea:	call   *0xe46d8(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c56f0:	lea    0xda4b1(%rip),%rdx        # 29fba8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf98>
  1c56f7:	mov    %r15,%rdi
  1c56fa:	vzeroupper
  1c56fd:	call   *0xe46c5(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c5703:	lea    0xda3c6(%rip),%rdx        # 29fad0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xec0>
  1c570a:	mov    %r15,%rdi
  1c570d:	mov    0x48(%rsp),%rsi
  1c5712:	vzeroupper
  1c5715:	call   *0xe46ad(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c571b:	lea    0xda426(%rip),%rdx        # 29fb48 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf38>
  1c5722:	mov    %r15,%rdi
  1c5725:	mov    %rbx,%rsi
  1c5728:	vzeroupper
  1c572b:	call   *0xe4697(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c5731:	lea    0xda338(%rip),%rdx        # 29fa70 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe60>
  1c5738:	mov    %r15,%rdi
  1c573b:	mov    0x48(%rsp),%rsi
  1c5740:	vzeroupper
  1c5743:	call   *0xe467f(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c5749:	lea    0xd9bb8(%rip),%rdx        # 29f308 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x6f8>
  1c5750:	mov    %r9,%rdi
  1c5753:	mov    %r9,%rsi
  1c5756:	vzeroupper
  1c5759:	call   *0xe4669(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c575f:	lea    0xd9b8a(%rip),%rdx        # 29f2f0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x6e0>
  1c5766:	mov    0x48(%rsp),%rdi
  1c576b:	mov    %rdi,%rsi
  1c576e:	vzeroupper
  1c5771:	call   *0xe4651(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c5777:	lea    0xd9b5a(%rip),%rdx        # 29f2d8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x6c8>
  1c577e:	mov    %rdi,%rsi
  1c5781:	vzeroupper
  1c5784:	call   *0xe463e(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c578a:	lea    0xd9ab7(%rip),%rdx        # 29f248 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x638>
  1c5791:	mov    %rcx,%rdi
  1c5794:	mov    0x90(%rsp),%rsi
  1c579c:	vzeroupper
  1c579f:	call   *0xe4623(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c57a5:	lea    0xd9ab4(%rip),%rdx        # 29f260 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x650>
  1c57ac:	mov    %rcx,%rdi
  1c57af:	mov    0x88(%rsp),%rsi
  1c57b7:	vzeroupper
  1c57ba:	call   *0xe4608(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c57c0:	lea    0xd9ab1(%rip),%rdx        # 29f278 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x668>
  1c57c7:	mov    0x90(%rsp),%rsi
  1c57cf:	vzeroupper
  1c57d2:	call   *0xe45f0(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c57d8:	lea    0xd9ab1(%rip),%rdx        # 29f290 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x680>
  1c57df:	mov    0x88(%rsp),%rsi
  1c57e7:	vzeroupper
  1c57ea:	call   *0xe45d8(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c57f0:	lea    0xd9b71(%rip),%rdx        # 29f368 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x758>
  1c57f7:	vzeroupper
  1c57fa:	call   *0xe45c8(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c5800:	lea    0xd9aa1(%rip),%rdx        # 29f2a8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x698>
  1c5807:	vzeroupper
  1c580a:	call   *0xe45b8(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c5810:	lea    0xd9aa9(%rip),%rdx        # 29f2c0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x6b0>
  1c5817:	mov    %rax,%rdi
  1c581a:	vzeroupper
  1c581d:	call   *0xe45a5(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c5823:	lea    0xd9b6e(%rip),%rdx        # 29f398 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x788>
  1c582a:	mov    %rcx,%rdi
  1c582d:	mov    0x90(%rsp),%rsi
  1c5835:	vzeroupper
  1c5838:	call   *0xe458a(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c583e:	lea    0xd9b6b(%rip),%rdx        # 29f3b0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x7a0>
  1c5845:	mov    0x60(%rsp),%rdi
  1c584a:	mov    0x88(%rsp),%rsi
  1c5852:	vzeroupper
  1c5855:	call   *0xe456d(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c585b:	lea    0xd9b1e(%rip),%rdx        # 29f380 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x770>
  1c5862:	vzeroupper
  1c5865:	call   *0xe455d(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c586b:	lea    0xd9b6e(%rip),%rdx        # 29f3e0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x7d0>
  1c5872:	mov    0x58(%rsp),%rdi
  1c5877:	mov    %rdi,%rsi
  1c587a:	vzeroupper
  1c587d:	call   *0xe4545(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c5883:	lea    0xd9b3e(%rip),%rdx        # 29f3c8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x7b8>
  1c588a:	mov    0x48(%rsp),%rdi
  1c588f:	mov    %rdi,%rsi
  1c5892:	vzeroupper
  1c5895:	call   *0xe452d(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c589b:	lea    0xda37e(%rip),%rdx        # 29fc20 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1010>
  1c58a2:	mov    0x58(%rsp),%rdi
  1c58a7:	mov    %rdi,%rsi
  1c58aa:	vzeroupper
  1c58ad:	call   *0xe4515(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
  1c58b3:	lea    0xda34e(%rip),%rdx        # 29fc08 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xff8>
  1c58ba:	mov    0x140(%rsp),%rdi
  1c58c2:	mov    %rdi,%rsi
  1c58c5:	vzeroupper
  1c58c8:	call   *0xe44fa(%rip)        # 2a9dc8 <_DYNAMIC+0x2b8>
