
/home/albert/m6-parity-baseline-20261030/ducc-f32/ducc_f32_full_transform_parity:     file format elf64-x86-64


Disassembly of section .text:

000000000068d350 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)>:
  68d350:	lea    0x8(%rsp),%r10
  68d355:	and    $0xffffffffffffffe0,%rsp
  68d359:	push   -0x8(%r10)
  68d35d:	push   %rbp
  68d35e:	mov    %rsp,%rbp
  68d361:	push   %r15
  68d363:	push   %r14
  68d365:	push   %r13
  68d367:	push   %r12
  68d369:	push   %r10
  68d36b:	push   %rbx
  68d36c:	lea    -0x5000(%rsp),%r11
  68d374:	sub    $0x1000,%rsp
  68d37b:	orq    $0x0,(%rsp)
  68d380:	cmp    %r11,%rsp
  68d383:	jne    68d374 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x24>
  68d385:	sub    $0x100,%rsp
  68d38c:	movabs $0xaaaaaaaaaaaaaaab,%r15
  68d396:	mov    %rdx,-0x50e8(%rbp)
  68d39d:	mov    %rsi,%r12
  68d3a0:	mov    (%rcx),%rdx
  68d3a3:	mov    %r8,%rbx
  68d3a6:	mov    %edi,-0x511c(%rbp)
  68d3ac:	mov    0x8(%rcx),%rsi
  68d3b0:	mov    %rcx,-0x50f8(%rbp)
  68d3b7:	mov    %r9,-0x50f0(%rbp)
  68d3be:	mov    %rsi,%rax
  68d3c1:	sub    %rdx,%rax
  68d3c4:	sar    $0x4,%rax
  68d3c8:	mov    %fs:0x28,%r9
  68d3d1:	mov    %r9,-0x38(%rbp)
  68d3d5:	mov    (%r8),%r9
  68d3d8:	imul   %rax,%r15
  68d3dc:	mov    %rsi,-0x50e0(%rbp)
  68d3e3:	mov    %rdx,-0x50d8(%rbp)
  68d3ea:	lea    0x1(%r9),%rax
  68d3ee:	mov    %rax,-0x5100(%rbp)
  68d3f5:	cmpq   $0x0,0x10(%r8)
  68d3fa:	jne    68d590 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x240>
  68d400:	mov    0xc0(%r8),%r13
  68d407:	sub    %r13,%rax
  68d40a:	cmp    $0x1000,%rax
  68d410:	jbe    68d8ea <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x59a>
  68d416:	movq   $0x0,-0x5090(%rbp)
  68d421:	xor    %r13d,%r13d
  68d424:	xor    %r15d,%r15d
  68d427:	xor    %r14d,%r14d
  68d42a:	movq   $0x0,-0x5110(%rbp)
  68d435:	movq   $0x0,-0x5108(%rbp)
  68d440:	movq   $0x0,-0x5118(%rbp)
  68d44b:	jmp    68d4e8 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x198>
  68d450:	mov    %r14,%rdi
  68d453:	mov    $0x5000,%edx
  68d458:	xor    %esi,%esi
  68d45a:	add    $0x5000,%r14
  68d461:	call   1cbe0 <memset@plt>
  68d466:	movq   $0x0,-0x5070(%rbp)
  68d471:	cmp    -0x5110(%rbp),%r13
  68d478:	je     68da70 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x720>
  68d47e:	movq   $0x0,0x0(%r13)
  68d486:	mov    %r13,%rdx
  68d489:	add    $0x8,%r13
  68d48d:	mov    -0x50f8(%rbp),%rdi
  68d494:	lea    -0x5000(%r14),%rax
  68d49b:	mov    -0x50f0(%rbp),%r8
  68d4a2:	lea    -0x5090(%rbp),%r9
  68d4a9:	mov    -0x50e8(%rbp),%rcx
  68d4b0:	mov    (%rdi),%rsi
  68d4b3:	mov    0x8(%rdi),%rdi
  68d4b7:	mov    %rsi,-0x50d8(%rbp)
  68d4be:	mov    %rdi,-0x50e0(%rbp)
  68d4c5:	push   %rdx
  68d4c6:	mov    %rdi,%rdx
  68d4c9:	mov    %rbx,%rdi
  68d4cc:	push   %rax
  68d4cd:	mov    %rax,-0x5100(%rbp)
  68d4d4:	call   683e40 <void ducc0::detail_sht::detail_sht_inner_loop::fill_m2a<float>(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, unsigned long, unsigned long&, ducc0::detail_sht::detail_sht_inner_loop::s0data_u&, unsigned long&) [clone .isra.0]>
  68d4d9:	cmpq   $0x0,-0x8(%r13)
  68d4de:	pop    %rax
  68d4df:	cmove  -0x5100(%rbp),%r14
  68d4e7:	pop    %rdx
  68d4e8:	mov    -0x50e0(%rbp),%rax
  68d4ef:	sub    -0x50d8(%rbp),%rax
  68d4f6:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  68d500:	sar    $0x4,%rax
  68d504:	imul   %rdx,%rax
  68d508:	cmp    %rax,-0x5090(%rbp)
  68d50f:	jae    68dc56 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x906>
  68d515:	xor    %esi,%esi
  68d517:	mov    $0x5000,%edx
  68d51c:	lea    -0x5050(%rbp),%rdi
  68d523:	call   1cbe0 <memset@plt>
  68d528:	cmp    %r14,-0x5108(%rbp)
  68d52f:	jne    68d450 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x100>
  68d535:	mov    %rax,%rsi
  68d538:	mov    -0x5118(%rbp),%rax
  68d53f:	lea    -0x50d0(%rbp),%rdi
  68d546:	mov    %rax,-0x50d0(%rbp)
  68d54d:	mov    -0x5108(%rbp),%rax
  68d554:	mov    %rax,-0x50c8(%rbp)
  68d55b:	mov    %rax,-0x50c0(%rbp)
  68d562:	call   6c0760 <void std::vector<ducc0::detail_sht::detail_sht_inner_loop::s0data_u, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::s0data_u> >::_M_realloc_append<ducc0::detail_sht::detail_sht_inner_loop::s0data_u>(ducc0::detail_sht::detail_sht_inner_loop::s0data_u&&)>
  68d567:	mov    -0x50d0(%rbp),%rax
  68d56e:	mov    -0x50c8(%rbp),%r14
  68d575:	mov    %rax,-0x5118(%rbp)
  68d57c:	mov    -0x50c0(%rbp),%rax
  68d583:	mov    %rax,-0x5108(%rbp)
  68d58a:	jmp    68d466 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x116>
  68d58f:	nop
  68d590:	mov    0x130(%r8),%rsi
  68d597:	sub    %rsi,%rax
  68d59a:	cmp    $0x1000,%rax
  68d5a0:	jbe    68d71d <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x3cd>
  68d5a6:	movq   $0x0,-0x50d0(%rbp)
  68d5b1:	xor    %r13d,%r13d
  68d5b4:	xor    %r15d,%r15d
  68d5b7:	xor    %r14d,%r14d
  68d5ba:	movq   $0x0,-0x5110(%rbp)
  68d5c5:	movq   $0x0,-0x5108(%rbp)
  68d5d0:	movq   $0x0,-0x5118(%rbp)
  68d5db:	jmp    68d67a <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x32a>
  68d5e0:	mov    %r14,%rdi
  68d5e3:	mov    $0x4800,%edx
  68d5e8:	xor    %esi,%esi
  68d5ea:	add    $0x4800,%r14
  68d5f1:	call   1cbe0 <memset@plt>
  68d5f6:	movq   $0x0,-0x50b0(%rbp)
  68d601:	cmp    -0x5110(%rbp),%r13
  68d608:	je     68dac0 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x770>
  68d60e:	movq   $0x0,0x0(%r13)
  68d616:	mov    %r13,%rdx
  68d619:	add    $0x8,%r13
  68d61d:	mov    -0x50f8(%rbp),%rcx
  68d624:	lea    -0x4800(%r14),%rax
  68d62b:	mov    -0x50f0(%rbp),%r8
  68d632:	lea    -0x50d0(%rbp),%r9
  68d639:	mov    0x8(%rcx),%rdi
  68d63d:	mov    (%rcx),%rsi
  68d640:	mov    -0x50e8(%rbp),%rcx
  68d647:	mov    %rdi,-0x50e0(%rbp)
  68d64e:	mov    %rsi,-0x50d8(%rbp)
  68d655:	push   %rdx
  68d656:	mov    %rdi,%rdx
  68d659:	mov    %rbx,%rdi
  68d65c:	push   %rax
  68d65d:	mov    %rax,-0x5100(%rbp)
  68d664:	call   6859f0 <void ducc0::detail_sht::detail_sht_inner_loop::fill_m2a_spin<float>(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, unsigned long, unsigned long&, ducc0::detail_sht::detail_sht_inner_loop::sxdata_u&, unsigned long&) [clone .isra.0]>
  68d669:	cmpq   $0x0,-0x8(%r13)
  68d66e:	pop    %r8
  68d670:	cmove  -0x5100(%rbp),%r14
  68d678:	pop    %r9
  68d67a:	mov    -0x50e0(%rbp),%rax
  68d681:	sub    -0x50d8(%rbp),%rax
  68d688:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  68d692:	sar    $0x4,%rax
  68d696:	imul   %rdx,%rax
  68d69a:	cmp    %rax,-0x50d0(%rbp)
  68d6a1:	jae    68db3f <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x7ef>
  68d6a7:	mov    $0x4800,%edx
  68d6ac:	xor    %esi,%esi
  68d6ae:	lea    -0x5050(%rbp),%rdi
  68d6b5:	call   1cbe0 <memset@plt>
  68d6ba:	mov    %rax,%rcx
  68d6bd:	cmp    -0x5108(%rbp),%r14
  68d6c4:	jne    68d5e0 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x290>
  68d6ca:	mov    -0x5118(%rbp),%rax
  68d6d1:	lea    -0x5090(%rbp),%rdi
  68d6d8:	mov    %rcx,%rsi
  68d6db:	mov    %r14,-0x5088(%rbp)
  68d6e2:	mov    %r14,-0x5080(%rbp)
  68d6e9:	mov    %rax,-0x5090(%rbp)
  68d6f0:	call   6c0940 <void std::vector<ducc0::detail_sht::detail_sht_inner_loop::sxdata_u, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::sxdata_u> >::_M_realloc_append<ducc0::detail_sht::detail_sht_inner_loop::sxdata_u>(ducc0::detail_sht::detail_sht_inner_loop::sxdata_u&&)>
  68d6f5:	mov    -0x5090(%rbp),%rax
  68d6fc:	mov    -0x5088(%rbp),%r14
  68d703:	mov    %rax,-0x5118(%rbp)
  68d70a:	mov    -0x5080(%rbp),%rax
  68d711:	mov    %rax,-0x5108(%rbp)
  68d718:	jmp    68d5f6 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x2a6>
  68d71d:	movq   $0x0,-0x5070(%rbp)
  68d728:	mov    %rsi,-0x50f8(%rbp)
  68d72f:	mov    %r9,-0x5108(%rbp)
  68d736:	jmp    68d78e <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x43e>
  68d738:	nopl   0x0(%rax,%rax,1)
  68d740:	lea    -0x5090(%rbp),%rax
  68d747:	lea    -0x5050(%rbp),%r14
  68d74e:	mov    -0x50e8(%rbp),%rcx
  68d755:	mov    -0x50e0(%rbp),%rdx
  68d75c:	push   %rax
  68d75d:	mov    -0x50d8(%rbp),%rsi
  68d764:	mov    %rbx,%rdi
  68d767:	lea    -0x5070(%rbp),%r9
  68d76e:	push   %r14
  68d770:	mov    -0x50f0(%rbp),%r8
  68d777:	call   6859f0 <void ducc0::detail_sht::detail_sht_inner_loop::fill_m2a_spin<float>(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, unsigned long, unsigned long&, ducc0::detail_sht::detail_sht_inner_loop::sxdata_u&, unsigned long&) [clone .isra.0]>
  68d77c:	mov    -0x5090(%rbp),%rcx
  68d783:	pop    %rdx
  68d784:	pop    %rsi
  68d785:	test   %rcx,%rcx
  68d788:	jne    68dd57 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xa07>
  68d78e:	cmp    %r15,-0x5070(%rbp)
  68d795:	jb     68d740 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x3f0>
  68d797:	mov    -0x50f8(%rbp),%rsi
  68d79e:	mov    -0x5108(%rbp),%r9
  68d7a5:	cmp    %rsi,%r9
  68d7a8:	jb     68da43 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x6f3>
  68d7ae:	mov    0x8(%r12),%rdi
  68d7b3:	test   %rdi,%rdi
  68d7b6:	je     68da43 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x6f3>
  68d7bc:	mov    0x18(%r12),%r14
  68d7c1:	lea    -0x1(%rdi),%rax
  68d7c5:	mov    $0x0,%edx
  68d7ca:	mov    0x10(%r12),%r15
  68d7cf:	mov    0xc8(%rbx),%r13
  68d7d6:	mov    %rdi,%rbx
  68d7d9:	mov    0x48(%r12),%r8
  68d7de:	imul   %r14,%rax
  68d7e2:	mov    %r14,%r10
  68d7e5:	mov    %r14,-0x50e0(%rbp)
  68d7ec:	lea    0x0(%r13,%rsi,8),%rcx
  68d7f1:	shl    $0x4,%rax
  68d7f5:	shl    $0x4,%r10
  68d7f9:	cmovs  %rax,%rdx
  68d7fd:	add    $0x8,%rax
  68d801:	test   %r10,%r10
  68d804:	mov    %rdx,-0x50d8(%rbp)
  68d80b:	mov    $0x8,%edx
  68d810:	mov    -0x50d8(%rbp),%r12
  68d817:	cmovns %rax,%rdx
  68d81b:	shr    $1,%rbx
  68d81e:	mov    %rdx,%r11
  68d821:	mov    %r15,%rdx
  68d824:	imul   %rsi,%rdx
  68d828:	cmp    $0x1,%r14
  68d82c:	jne    68df80 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xc30>
  68d832:	nopl   (%rax)
  68d835:	data16 cs nopw 0x0(%rax,%rax,1)
  68d840:	mov    %rdx,%rax
  68d843:	shl    $0x4,%rax
  68d847:	lea    (%rax,%r11,1),%r10
  68d84b:	add    %r8,%r10
  68d84e:	cmp    %r10,%rcx
  68d851:	ja     68d863 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x513>
  68d853:	lea    (%r12,%rax,1),%r10
  68d857:	add    %r8,%r10
  68d85a:	cmp    %r10,%rcx
  68d85d:	jae    68db10 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x7c0>
  68d863:	cmp    $0x1,%rdi
  68d867:	je     68dda3 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xa53>
  68d86d:	vbroadcastsd (%rcx),%ymm1
  68d872:	add    %r8,%rax
  68d875:	xor    %r10d,%r10d
  68d878:	nopl   0x0(%rax,%rax,1)
  68d880:	vmovupd (%rax),%xmm0
  68d884:	vinsertf128 $0x1,0x10(%rax),%ymm0,%ymm0
  68d88b:	add    $0x1,%r10
  68d88f:	add    $0x20,%rax
  68d893:	vmulpd %ymm1,%ymm0,%ymm0
  68d897:	vmovupd %xmm0,-0x20(%rax)
  68d89c:	vextractf128 $0x1,%ymm0,-0x10(%rax)
  68d8a3:	cmp    %rbx,%r10
  68d8a6:	jne    68d880 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x530>
  68d8a8:	test   $0x1,%dil
  68d8ac:	je     68d8cc <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x57c>
  68d8ae:	mov    %rdi,%rax
  68d8b1:	and    $0xfffffffffffffffe,%rax
  68d8b5:	add    %rdx,%rax
  68d8b8:	vmovddup (%rcx),%xmm0
  68d8bc:	shl    $0x4,%rax
  68d8c0:	vmulpd (%r8,%rax,1),%xmm0,%xmm0
  68d8c6:	vmovupd %xmm0,(%r8,%rax,1)
  68d8cc:	add    $0x1,%rsi
  68d8d0:	cmp    %rsi,%r9
  68d8d3:	jb     68da40 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x6f0>
  68d8d9:	mov    %r15,%rdx
  68d8dc:	lea    0x0(%r13,%rsi,8),%rcx
  68d8e1:	imul   %rsi,%rdx
  68d8e5:	jmp    68d840 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x4f0>
  68d8ea:	lea    -0x5070(%rbp),%rax
  68d8f1:	mov    %r9,-0x5108(%rbp)
  68d8f8:	movq   $0x0,-0x5070(%rbp)
  68d903:	mov    %rax,-0x50f8(%rbp)
  68d90a:	jmp    68d960 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x610>
  68d90c:	nopl   0x0(%rax)
  68d910:	lea    -0x5090(%rbp),%rax
  68d917:	lea    -0x5050(%rbp),%r14
  68d91e:	mov    -0x50e8(%rbp),%rcx
  68d925:	mov    -0x50f8(%rbp),%r9
  68d92c:	push   %rax
  68d92d:	mov    -0x50f0(%rbp),%r8
  68d934:	mov    %rbx,%rdi
  68d937:	mov    -0x50e0(%rbp),%rdx
  68d93e:	mov    -0x50d8(%rbp),%rsi
  68d945:	push   %r14
  68d947:	call   683e40 <void ducc0::detail_sht::detail_sht_inner_loop::fill_m2a<float>(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, unsigned long, unsigned long&, ducc0::detail_sht::detail_sht_inner_loop::s0data_u&, unsigned long&) [clone .isra.0]>
  68d94c:	mov    -0x5090(%rbp),%rcx
  68d953:	pop    %r10
  68d955:	pop    %r11
  68d957:	test   %rcx,%rcx
  68d95a:	jne    68dd84 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xa34>
  68d960:	cmp    %r15,-0x5070(%rbp)
  68d967:	jb     68d910 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x5c0>
  68d969:	mov    -0x5108(%rbp),%r9
  68d970:	cmp    %r13,%r9
  68d973:	jb     68da43 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x6f3>
  68d979:	vxorpd %xmm6,%xmm6,%xmm6
  68d97d:	mov    %r13,%rax
  68d980:	mov    0xf8(%rbx),%rsi
  68d987:	mov    0xc8(%rbx),%rcx
  68d98e:	shl    $0x4,%rax
  68d992:	vmovapd %xmm6,%xmm4
  68d996:	add    0x48(%r12),%rax
  68d99b:	vmovapd %xmm6,%xmm0
  68d99f:	jmp    68da0b <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x6bb>
  68d9a1:	nopl   0x0(%rax)
  68d9a8:	vmovsd 0x10(%rax),%xmm2
  68d9ad:	vmovsd 0x18(%rax),%xmm5
  68d9b2:	vmovhpd (%rcx),%xmm0,%xmm0
  68d9b6:	vmulpd (%rsi,%r13,8),%xmm0,%xmm0
  68d9bc:	add    $0x2,%r13
  68d9c0:	add    $0x20,%rax
  68d9c4:	add    $0x8,%rcx
  68d9c8:	vmulpd %xmm0,%xmm1,%xmm1
  68d9cc:	vmulpd %xmm3,%xmm0,%xmm0
  68d9d0:	vunpckhpd %xmm0,%xmm0,%xmm3
  68d9d4:	vaddpd %xmm0,%xmm3,%xmm0
  68d9d8:	vmovlpd %xmm0,-0x20(%rax)
  68d9dd:	vunpckhpd %xmm1,%xmm1,%xmm0
  68d9e1:	vaddpd %xmm1,%xmm0,%xmm0
  68d9e5:	vmovlpd %xmm0,-0x18(%rax)
  68d9ea:	vmovsd -0x8(%rcx),%xmm0
  68d9ef:	vmulsd %xmm2,%xmm0,%xmm2
  68d9f3:	vmulsd %xmm5,%xmm0,%xmm0
  68d9f7:	vmovsd %xmm2,-0x10(%rax)
  68d9fc:	vmovsd %xmm0,-0x8(%rax)
  68da01:	vmovsd -0x8(%rcx),%xmm0
  68da06:	cmp    %r13,%r9
  68da09:	jb     68da43 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x6f3>
  68da0b:	vmovapd %xmm4,%xmm3
  68da0f:	vmovapd %xmm6,%xmm1
  68da13:	vmovsd (%rax),%xmm4
  68da17:	lea    0x1(%r13),%rdx
  68da1b:	vmovsd 0x8(%rax),%xmm6
  68da20:	vunpcklpd %xmm4,%xmm3,%xmm3
  68da24:	vunpcklpd %xmm6,%xmm1,%xmm1
  68da28:	cmp    %rdx,%r9
  68da2b:	jae    68d9a8 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x658>
  68da31:	vxorpd %xmm5,%xmm5,%xmm5
  68da35:	vmovapd %xmm5,%xmm2
  68da39:	jmp    68d9b2 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x662>
  68da3e:	xchg   %ax,%ax
  68da40:	vzeroupper
  68da43:	mov    -0x38(%rbp),%rax
  68da47:	sub    %fs:0x28,%rax
  68da50:	jne    68e0d0 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xd80>
  68da56:	lea    -0x30(%rbp),%rsp
  68da5a:	pop    %rbx
  68da5b:	pop    %r10
  68da5d:	pop    %r12
  68da5f:	pop    %r13
  68da61:	pop    %r14
  68da63:	pop    %r15
  68da65:	pop    %rbp
  68da66:	lea    -0x8(%r10),%rsp
  68da6a:	ret
  68da6b:	nopl   0x0(%rax,%rax,1)
  68da70:	lea    -0x5070(%rbp),%rsi
  68da77:	lea    -0x50b0(%rbp),%rdi
  68da7e:	mov    %r15,-0x50b0(%rbp)
  68da85:	mov    %r13,-0x50a8(%rbp)
  68da8c:	mov    %r13,-0x50a0(%rbp)
  68da93:	call   11daa0 <void std::vector<unsigned long, std::allocator<unsigned long> >::_M_realloc_append<unsigned long>(unsigned long&&)>
  68da98:	mov    -0x50a8(%rbp),%r13
  68da9f:	mov    -0x50a0(%rbp),%rax
  68daa6:	mov    -0x50b0(%rbp),%r15
  68daad:	mov    %rax,-0x5110(%rbp)
  68dab4:	lea    -0x8(%r13),%rdx
  68dab8:	jmp    68d48d <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x13d>
  68dabd:	nopl   (%rax)
  68dac0:	lea    -0x50b0(%rbp),%rsi
  68dac7:	lea    -0x5070(%rbp),%rdi
  68dace:	mov    %r15,-0x5070(%rbp)
  68dad5:	mov    %r13,-0x5068(%rbp)
  68dadc:	mov    %r13,-0x5060(%rbp)
  68dae3:	call   11daa0 <void std::vector<unsigned long, std::allocator<unsigned long> >::_M_realloc_append<unsigned long>(unsigned long&&)>
  68dae8:	mov    -0x5068(%rbp),%r13
  68daef:	mov    -0x5060(%rbp),%rax
  68daf6:	mov    -0x5070(%rbp),%r15
  68dafd:	mov    %rax,-0x5110(%rbp)
  68db04:	lea    -0x8(%r13),%rdx
  68db08:	jmp    68d61d <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x2cd>
  68db0d:	nopl   (%rax)
  68db10:	add    %r8,%rax
  68db13:	xor    %edx,%edx
  68db15:	data16 cs nopw 0x0(%rax,%rax,1)
  68db20:	vmovddup (%rcx),%xmm0
  68db24:	vmulpd (%rax),%xmm0,%xmm0
  68db28:	add    $0x1,%rdx
  68db2c:	add    $0x10,%rax
  68db30:	vmovupd %xmm0,-0x10(%rax)
  68db35:	cmp    %rdi,%rdx
  68db38:	jne    68db20 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x7d0>
  68db3a:	jmp    68d8cc <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x57c>
  68db3f:	mov    0x130(%rbx),%rdx
  68db46:	mov    (%rbx),%rsi
  68db49:	cmp    %rdx,%rsi
  68db4c:	jb     68df70 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xc20>
  68db52:	mov    %r14,%r10
  68db55:	lea    0x1(%rsi),%rcx
  68db59:	sub    -0x5118(%rbp),%r10
  68db60:	mov    -0x511c(%rbp),%edi
  68db66:	mov    %r10,%r13
  68db69:	lea    0x1000(%rdx),%r9
  68db70:	movabs $0x8e38e38e38e38e39,%rax
  68db7a:	mov    %rsi,-0x50f0(%rbp)
  68db81:	sar    $0xb,%r13
  68db85:	mov    %r10,-0x50f8(%rbp)
  68db8c:	imul   %rax,%r13
  68db90:	cmp    %rcx,%r9
  68db93:	cmova  %rcx,%r9
  68db97:	test   %edi,%edi
  68db99:	je     68ddb4 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xa64>
  68db9f:	mov    %rcx,-0x5100(%rbp)
  68dba6:	mov    %r9,%r14
  68dba9:	mov    %r13,-0x50e8(%rbp)
  68dbb0:	mov    %rbx,-0x50e0(%rbp)
  68dbb7:	nopw   0x0(%rax,%rax,1)
  68dbc0:	cmpq   $0x0,-0x50f8(%rbp)
  68dbc8:	je     68e09e <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xd4e>
  68dbce:	mov    -0x5118(%rbp),%rbx
  68dbd5:	mov    %rdx,-0x50d8(%rbp)
  68dbdc:	mov    %r15,%rax
  68dbdf:	xor    %r13d,%r13d
  68dbe2:	mov    %rbx,%r15
  68dbe5:	mov    %rax,%rbx
  68dbe8:	nopl   0x0(%rax,%rax,1)
  68dbf0:	mov    (%rbx,%r13,8),%rcx
  68dbf4:	mov    0x48(%r12),%rdi
  68dbf9:	mov    %r15,%rdx
  68dbfc:	mov    %r14,%r9
  68dbff:	mov    -0x50d8(%rbp),%r8
  68dc06:	mov    -0x50e0(%rbp),%rsi
  68dc0d:	add    $0x1,%r13
  68dc11:	add    $0x4800,%r15
  68dc18:	call   682da0 <ducc0::detail_sht::detail_sht_inner_loop::calc_map2alm_spin_gradonly(std::complex<double>*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::sxdata_v&, unsigned long, unsigned long, unsigned long)>
  68dc1d:	cmp    -0x50e8(%rbp),%r13
  68dc24:	jb     68dbf0 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x8a0>
  68dc26:	mov    %rbx,%r15
  68dc29:	cmp    %r14,-0x50f0(%rbp)
  68dc30:	jb     68deb0 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xb60>
  68dc36:	mov    -0x5100(%rbp),%rbx
  68dc3d:	lea    0x1000(%r14),%rax
  68dc44:	mov    %r14,%rdx
  68dc47:	cmp    %rbx,%rax
  68dc4a:	cmova  %rbx,%rax
  68dc4e:	mov    %rax,%r14
  68dc51:	jmp    68dbc0 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x870>
  68dc56:	mov    0xc0(%rbx),%rsi
  68dc5d:	mov    (%rbx),%r8
  68dc60:	cmp    %rsi,%r8
  68dc63:	jb     68df28 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xbd8>
  68dc69:	mov    %r14,%r10
  68dc6c:	lea    0x1(%r8),%rcx
  68dc70:	sub    -0x5118(%rbp),%r10
  68dc77:	movabs $0xcccccccccccccccd,%rax
  68dc81:	mov    %r10,%r13
  68dc84:	lea    0x1000(%rsi),%rdx
  68dc8b:	mov    %rsi,-0x50d8(%rbp)
  68dc92:	mov    %r15,%r14
  68dc95:	sar    $0xc,%r13
  68dc99:	mov    %r10,-0x50f8(%rbp)
  68dca0:	imul   %rax,%r13
  68dca4:	cmp    %rcx,%rdx
  68dca7:	mov    %r8,-0x50f0(%rbp)
  68dcae:	cmova  %rcx,%rdx
  68dcb2:	mov    %rcx,-0x5100(%rbp)
  68dcb9:	mov    %rbx,-0x50e0(%rbp)
  68dcc0:	mov    %r13,-0x50e8(%rbp)
  68dcc7:	mov    %rdx,%r15
  68dcca:	nopw   0x0(%rax,%rax,1)
  68dcd0:	cmpq   $0x0,-0x50f8(%rbp)
  68dcd8:	je     68def8 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xba8>
  68dcde:	mov    -0x5118(%rbp),%rbx
  68dce5:	xor    %r13d,%r13d
  68dce8:	nopl   0x0(%rax,%rax,1)
  68dcf0:	mov    (%r14,%r13,8),%rcx
  68dcf4:	mov    0x48(%r12),%rdi
  68dcf9:	mov    %rbx,%rdx
  68dcfc:	mov    %r15,%r9
  68dcff:	mov    -0x50d8(%rbp),%r8
  68dd06:	mov    -0x50e0(%rbp),%rsi
  68dd0d:	add    $0x1,%r13
  68dd11:	add    $0x5000,%rbx
  68dd18:	call   681030 <ducc0::detail_sht::detail_sht_inner_loop::calc_map2alm(std::complex<double>*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)>
  68dd1d:	cmp    -0x50e8(%rbp),%r13
  68dd24:	jb     68dcf0 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x9a0>
  68dd26:	cmp    %r15,-0x50f0(%rbp)
  68dd2d:	jb     68de62 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xb12>
  68dd33:	mov    -0x5100(%rbp),%rbx
  68dd3a:	lea    0x1000(%r15),%rax
  68dd41:	mov    %r15,-0x50d8(%rbp)
  68dd48:	cmp    %rbx,%rax
  68dd4b:	cmova  %rbx,%rax
  68dd4f:	mov    %rax,%r15
  68dd52:	jmp    68dcd0 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x980>
  68dd57:	mov    -0x511c(%rbp),%eax
  68dd5d:	mov    0x48(%r12),%rdi
  68dd62:	mov    %r14,%rdx
  68dd65:	mov    %rbx,%rsi
  68dd68:	mov    -0x5100(%rbp),%r9
  68dd6f:	mov    -0x50f8(%rbp),%r8
  68dd76:	test   %eax,%eax
  68dd78:	jne    68ddaa <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xa5a>
  68dd7a:	call   682710 <ducc0::detail_sht::detail_sht_inner_loop::calc_map2alm_spin(std::complex<double>*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::sxdata_v&, unsigned long, unsigned long, unsigned long)>
  68dd7f:	jmp    68d78e <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x43e>
  68dd84:	mov    0x48(%r12),%rdi
  68dd89:	mov    %r13,%r8
  68dd8c:	mov    %r14,%rdx
  68dd8f:	mov    %rbx,%rsi
  68dd92:	mov    -0x5100(%rbp),%r9
  68dd99:	call   681030 <ducc0::detail_sht::detail_sht_inner_loop::calc_map2alm(std::complex<double>*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)>
  68dd9e:	jmp    68d960 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x610>
  68dda3:	xor    %eax,%eax
  68dda5:	jmp    68d8b5 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x565>
  68ddaa:	call   682da0 <ducc0::detail_sht::detail_sht_inner_loop::calc_map2alm_spin_gradonly(std::complex<double>*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::sxdata_v&, unsigned long, unsigned long, unsigned long)>
  68ddaf:	jmp    68d78e <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x43e>
  68ddb4:	mov    %rcx,-0x5100(%rbp)
  68ddbb:	mov    %r15,%r14
  68ddbe:	mov    %r9,%r15
  68ddc1:	mov    %r13,-0x50e8(%rbp)
  68ddc8:	mov    %rbx,-0x50e0(%rbp)
  68ddcf:	nop
  68ddd0:	cmpq   $0x0,-0x50f8(%rbp)
  68ddd8:	je     68df40 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xbf0>
  68ddde:	mov    -0x5118(%rbp),%rbx
  68dde5:	mov    %rdx,-0x50d8(%rbp)
  68ddec:	mov    %r14,%rax
  68ddef:	xor    %r13d,%r13d
  68ddf2:	mov    %rbx,%r14
  68ddf5:	mov    %rax,%rbx
  68ddf8:	nopl   0x0(%rax,%rax,1)
  68de00:	mov    (%rbx,%r13,8),%rcx
  68de04:	mov    0x48(%r12),%rdi
  68de09:	mov    %r14,%rdx
  68de0c:	mov    %r15,%r9
  68de0f:	mov    -0x50d8(%rbp),%r8
  68de16:	mov    -0x50e0(%rbp),%rsi
  68de1d:	add    $0x1,%r13
  68de21:	add    $0x4800,%r14
  68de28:	call   682710 <ducc0::detail_sht::detail_sht_inner_loop::calc_map2alm_spin(std::complex<double>*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::sxdata_v&, unsigned long, unsigned long, unsigned long)>
  68de2d:	cmp    -0x50e8(%rbp),%r13
  68de34:	jb     68de00 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xab0>
  68de36:	mov    %rbx,%r14
  68de39:	cmp    %r15,-0x50f0(%rbp)
  68de40:	jb     68dead <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xb5d>
  68de42:	mov    -0x5100(%rbp),%rbx
  68de49:	lea    0x1000(%r15),%rax
  68de50:	mov    %r15,%rdx
  68de53:	cmp    %rbx,%rax
  68de56:	cmova  %rbx,%rax
  68de5a:	mov    %rax,%r15
  68de5d:	jmp    68ddd0 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xa80>
  68de62:	mov    -0x50e0(%rbp),%rbx
  68de69:	mov    %r14,%r15
  68de6c:	mov    -0x5110(%rbp),%rsi
  68de73:	mov    %r15,%rdi
  68de76:	sub    %r15,%rsi
  68de79:	call   1ce30 <operator delete(void*, unsigned long)@plt>
  68de7e:	mov    -0x5118(%rbp),%rdi
  68de85:	test   %rdi,%rdi
  68de88:	je     68de9e <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xb4e>
  68de8a:	mov    -0x5108(%rbp),%rsi
  68de91:	mov    $0x20,%edx
  68de96:	sub    %rdi,%rsi
  68de99:	call   1ca20 <operator delete(void*, unsigned long, std::align_val_t)@plt>
  68de9e:	mov    0xc0(%rbx),%r13
  68dea5:	mov    (%rbx),%r9
  68dea8:	jmp    68d970 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x620>
  68dead:	mov    %rbx,%r15
  68deb0:	mov    -0x50e0(%rbp),%rbx
  68deb7:	mov    -0x5110(%rbp),%rsi
  68debe:	mov    %r15,%rdi
  68dec1:	sub    %r15,%rsi
  68dec4:	call   1ce30 <operator delete(void*, unsigned long)@plt>
  68dec9:	mov    -0x5118(%rbp),%rdi
  68ded0:	test   %rdi,%rdi
  68ded3:	je     68dee9 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xb99>
  68ded5:	mov    -0x5108(%rbp),%rsi
  68dedc:	mov    $0x20,%edx
  68dee1:	sub    %rdi,%rsi
  68dee4:	call   1ca20 <operator delete(void*, unsigned long, std::align_val_t)@plt>
  68dee9:	mov    0x130(%rbx),%rsi
  68def0:	mov    (%rbx),%r9
  68def3:	jmp    68d7a5 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x455>
  68def8:	mov    %r15,%rdx
  68defb:	mov    -0x50f0(%rbp),%r8
  68df02:	mov    %r14,%r15
  68df05:	mov    -0x5100(%rbp),%rcx
  68df0c:	mov    -0x50e0(%rbp),%rbx
  68df13:	jmp    68df23 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xbd3>
  68df15:	add    $0x1000,%rdx
  68df1c:	cmp    %rcx,%rdx
  68df1f:	cmova  %rcx,%rdx
  68df23:	cmp    %rdx,%r8
  68df26:	jae    68df15 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xbc5>
  68df28:	test   %r15,%r15
  68df2b:	je     68de7e <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xb2e>
  68df31:	jmp    68de6c <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xb1c>
  68df36:	cs nopw 0x0(%rax,%rax,1)
  68df40:	mov    %r15,%r9
  68df43:	mov    -0x50f0(%rbp),%rsi
  68df4a:	mov    %r14,%r15
  68df4d:	mov    -0x5100(%rbp),%rcx
  68df54:	mov    -0x50e0(%rbp),%rbx
  68df5b:	jmp    68df6b <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xc1b>
  68df5d:	add    $0x1000,%r9
  68df64:	cmp    %rcx,%r9
  68df67:	cmova  %rcx,%r9
  68df6b:	cmp    %r9,%rsi
  68df6e:	jae    68df5d <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xc0d>
  68df70:	test   %r15,%r15
  68df73:	je     68dec9 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xb79>
  68df79:	jmp    68deb7 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xb67>
  68df7e:	xchg   %ax,%ax
  68df80:	mov    %r9,-0x50e8(%rbp)
  68df87:	test   %r10,%r10
  68df8a:	mov    %r14,%r12
  68df8d:	mov    %rdi,%rbx
  68df90:	setne  -0x50f0(%rbp)
  68df97:	shl    $0x5,%r12
  68df9b:	shr    $1,%rbx
  68df9e:	xchg   %ax,%ax
  68dfa0:	mov    %rdx,%rax
  68dfa3:	shl    $0x4,%rax
  68dfa7:	lea    (%rax,%r11,1),%r9
  68dfab:	add    %r8,%r9
  68dfae:	cmp    %rcx,%r9
  68dfb1:	mov    -0x50d8(%rbp),%r9
  68dfb8:	setb   %r14b
  68dfbc:	add    %rax,%r9
  68dfbf:	add    %r8,%r9
  68dfc2:	cmp    %r9,%rcx
  68dfc5:	setb   %r9b
  68dfc9:	or     %r14b,%r9b
  68dfcc:	je     68e073 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xd23>
  68dfd2:	cmpb   $0x0,-0x50f0(%rbp)
  68dfd9:	je     68e073 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xd23>
  68dfdf:	cmp    $0x1,%rdi
  68dfe3:	je     68e09a <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xd4a>
  68dfe9:	vbroadcastsd (%rcx),%ymm1
  68dfee:	add    %r8,%rax
  68dff1:	xor    %r9d,%r9d
  68dff4:	nop
  68dff5:	data16 cs nopw 0x0(%rax,%rax,1)
  68e000:	vmovupd (%rax),%xmm0
  68e004:	vinsertf128 $0x1,(%rax,%r10,1),%ymm0,%ymm0
  68e00b:	add    $0x1,%r9
  68e00f:	vmulpd %ymm1,%ymm0,%ymm0
  68e013:	vmovupd %xmm0,(%rax)
  68e017:	vextractf128 $0x1,%ymm0,(%rax,%r10,1)
  68e01e:	add    %r12,%rax
  68e021:	cmp    %rbx,%r9
  68e024:	jne    68e000 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xcb0>
  68e026:	test   $0x1,%dil
  68e02a:	je     68e051 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xd01>
  68e02c:	mov    %rdi,%rax
  68e02f:	and    $0xfffffffffffffffe,%rax
  68e033:	imul   -0x50e0(%rbp),%rax
  68e03b:	vmovddup (%rcx),%xmm0
  68e03f:	add    %rdx,%rax
  68e042:	shl    $0x4,%rax
  68e046:	add    %r8,%rax
  68e049:	vmulpd (%rax),%xmm0,%xmm0
  68e04d:	vmovupd %xmm0,(%rax)
  68e051:	add    $0x1,%rsi
  68e055:	cmp    %rsi,-0x50e8(%rbp)
  68e05c:	jb     68da40 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0x6f0>
  68e062:	mov    %rsi,%rdx
  68e065:	lea    0x0(%r13,%rsi,8),%rcx
  68e06a:	imul   %r15,%rdx
  68e06e:	jmp    68dfa0 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xc50>
  68e073:	add    %r8,%rax
  68e076:	xor    %edx,%edx
  68e078:	nopl   0x0(%rax,%rax,1)
  68e080:	vmovddup (%rcx),%xmm0
  68e084:	vmulpd (%rax),%xmm0,%xmm0
  68e088:	add    $0x1,%rdx
  68e08c:	vmovupd %xmm0,(%rax)
  68e090:	add    %r10,%rax
  68e093:	cmp    %rdx,%rdi
  68e096:	jne    68e080 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xd30>
  68e098:	jmp    68e051 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xd01>
  68e09a:	xor    %eax,%eax
  68e09c:	jmp    68e033 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xce3>
  68e09e:	mov    -0x50f0(%rbp),%rsi
  68e0a5:	mov    -0x5100(%rbp),%rcx
  68e0ac:	mov    %r14,%r9
  68e0af:	mov    -0x50e0(%rbp),%rbx
  68e0b6:	jmp    68e0c6 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xd76>
  68e0b8:	add    $0x1000,%r9
  68e0bf:	cmp    %rcx,%r9
  68e0c2:	cmova  %rcx,%r9
  68e0c6:	cmp    %r9,%rsi
  68e0c9:	jae    68e0b8 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xd68>
  68e0cb:	jmp    68df70 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long)+0xc20>
  68e0d0:	call   1cea0 <__stack_chk_fail@plt>
  68e0d5:	endbr64
  68e0d9:	mov    %rax,%rbx
  68e0dc:	jmp    2557b <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long) [clone .cold]>
  68e0e1:	endbr64
  68e0e5:	mov    %rax,%rbx
  68e0e8:	jmp    255dc <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long) [clone .cold]+0x61>
  68e0ed:	endbr64
  68e0f1:	mov    %rax,%rbx
  68e0f4:	jmp    2565f <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long) [clone .cold]+0xe4>
  68e0f9:	endbr64
  68e0fd:	mov    %rax,%rbx
  68e100:	jmp    25676 <void ducc0::detail_sht::detail_sht_inner_loop::inner_loop_m2a<float>(ducc0::detail_sht::SHT_mode, ducc0::detail_mav::vmav<std::complex<double>, 2ul> const&, ducc0::detail_mav::cmav<std::complex<float>, 3ul> const&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::ringdata, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::ringdata> > const&, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen&, unsigned long) [clone .cold]+0xfb>
