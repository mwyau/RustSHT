
diagnostics-b1-current-255/rust-f32-seed-init-candidate:     file format elf64-x86-64


Disassembly of section .text:

00000000001e6e70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>>:
  1e6e70:	55                   	push   %rbp
  1e6e71:	41 57                	push   %r15
  1e6e73:	41 56                	push   %r14
  1e6e75:	41 55                	push   %r13
  1e6e77:	41 54                	push   %r12
  1e6e79:	53                   	push   %rbx
  1e6e7a:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  1e6e81:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  1e6e88:	00 
  1e6e89:	48 81 ec e8 07 00 00 	sub    $0x7e8,%rsp
  1e6e90:	48 89 bc 24 88 00 00 	mov    %rdi,0x88(%rsp)
  1e6e97:	00 
  1e6e98:	48 8b 86 d8 00 00 00 	mov    0xd8(%rsi),%rax
  1e6e9f:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  1e6ea6:	00 
  1e6ea7:	48 8b 86 e0 00 00 00 	mov    0xe0(%rsi),%rax
  1e6eae:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  1e6eb5:	00 
  1e6eb6:	0f b6 86 e8 00 00 00 	movzbl 0xe8(%rsi),%eax
  1e6ebd:	88 44 24 0f          	mov    %al,0xf(%rsp)
  1e6ec1:	48 8b 06             	mov    (%rsi),%rax
  1e6ec4:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
  1e6ecb:	00 
  1e6ecc:	4c 8b 4e 08          	mov    0x8(%rsi),%r9
  1e6ed0:	48 8b 46 10          	mov    0x10(%rsi),%rax
  1e6ed4:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
  1e6edb:	00 
  1e6edc:	48 8b 46 18          	mov    0x18(%rsi),%rax
  1e6ee0:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  1e6ee7:	00 
  1e6ee8:	48 8b 46 20          	mov    0x20(%rsi),%rax
  1e6eec:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
  1e6ef3:	00 
  1e6ef4:	48 8b 46 28          	mov    0x28(%rsi),%rax
  1e6ef8:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  1e6efd:	48 8b 46 30          	mov    0x30(%rsi),%rax
  1e6f01:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  1e6f08:	00 
  1e6f09:	48 8b 46 38          	mov    0x38(%rsi),%rax
  1e6f0d:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  1e6f14:	00 
  1e6f15:	48 8b 46 40          	mov    0x40(%rsi),%rax
  1e6f19:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
  1e6f20:	00 
  1e6f21:	48 8b 46 58          	mov    0x58(%rsi),%rax
  1e6f25:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  1e6f2a:	48 8b 46 60          	mov    0x60(%rsi),%rax
  1e6f2e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  1e6f33:	48 8b 46 68          	mov    0x68(%rsi),%rax
  1e6f37:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  1e6f3e:	00 
  1e6f3f:	4c 8b 5e 70          	mov    0x70(%rsi),%r11
  1e6f43:	48 8b 46 78          	mov    0x78(%rsi),%rax
  1e6f47:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  1e6f4e:	00 
  1e6f4f:	48 8b 86 80 00 00 00 	mov    0x80(%rsi),%rax
  1e6f56:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
  1e6f5d:	00 
  1e6f5e:	48 8b 86 88 00 00 00 	mov    0x88(%rsi),%rax
  1e6f65:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  1e6f6a:	48 8b 86 90 00 00 00 	mov    0x90(%rsi),%rax
  1e6f71:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  1e6f78:	00 
  1e6f79:	48 8b be 98 00 00 00 	mov    0x98(%rsi),%rdi
  1e6f80:	48 8b 86 a0 00 00 00 	mov    0xa0(%rsi),%rax
  1e6f87:	48 8b 8e a8 00 00 00 	mov    0xa8(%rsi),%rcx
  1e6f8e:	4c 8b 86 b0 00 00 00 	mov    0xb0(%rsi),%r8
  1e6f95:	48 8b ae b8 00 00 00 	mov    0xb8(%rsi),%rbp
  1e6f9c:	48 8b 96 c0 00 00 00 	mov    0xc0(%rsi),%rdx
  1e6fa3:	48 89 94 24 90 00 00 	mov    %rdx,0x90(%rsp)
  1e6faa:	00 
  1e6fab:	4c 8b a6 c8 00 00 00 	mov    0xc8(%rsi),%r12
  1e6fb2:	4c 8b b6 d0 00 00 00 	mov    0xd0(%rsi),%r14
  1e6fb9:	48 89 c6             	mov    %rax,%rsi
  1e6fbc:	48 c1 ee 03          	shr    $0x3,%rsi
  1e6fc0:	89 c2                	mov    %eax,%edx
  1e6fc2:	83 e2 07             	and    $0x7,%edx
  1e6fc5:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  1e6fca:	48 ba f8 ff ff ff ff 	movabs $0x1ffffffffffffff8,%rdx
  1e6fd1:	ff ff 1f 
  1e6fd4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  1e6fd9:	48 21 d0             	and    %rdx,%rax
  1e6fdc:	48 89 7c 24 50       	mov    %rdi,0x50(%rsp)
  1e6fe1:	48 8d 1c 87          	lea    (%rdi,%rax,4),%rbx
  1e6fe5:	44 89 c0             	mov    %r8d,%eax
  1e6fe8:	83 e0 07             	and    $0x7,%eax
  1e6feb:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  1e6ff2:	00 
  1e6ff3:	4c 89 c0             	mov    %r8,%rax
  1e6ff6:	48 21 d0             	and    %rdx,%rax
  1e6ff9:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
  1e6ffe:	4c 8d 2c 81          	lea    (%rcx,%rax,4),%r13
  1e7002:	48 89 b4 24 98 00 00 	mov    %rsi,0x98(%rsp)
  1e7009:	00 
  1e700a:	48 85 f6             	test   %rsi,%rsi
  1e700d:	4c 89 5c 24 30       	mov    %r11,0x30(%rsp)
  1e7012:	4c 89 4c 24 78       	mov    %r9,0x78(%rsp)
  1e7017:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  1e701c:	0f 84 74 03 00 00    	je     1e7396 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x526>
  1e7022:	4c 89 c1             	mov    %r8,%rcx
  1e7025:	48 c1 e9 03          	shr    $0x3,%rcx
  1e7029:	b2 01                	mov    $0x1,%dl
  1e702b:	45 31 d2             	xor    %r10d,%r10d
  1e702e:	c4 e2 7d 18 1d 01 e2 	vbroadcastss -0x1c1dff(%rip),%ymm3        # 25238 <__abi_tag+0x24f3c>
  1e7035:	e3 ff 
  1e7037:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
  1e703b:	c4 e2 7d 18 35 8c df 	vbroadcastss -0x1c2074(%rip),%ymm6        # 24fd0 <__abi_tag+0x24cd4>
  1e7042:	e3 ff 
  1e7044:	c5 c0 57 ff          	vxorps %xmm7,%xmm7,%xmm7
  1e7048:	c4 62 7d 18 05 c7 e1 	vbroadcastss -0x1c1e39(%rip),%ymm8        # 25218 <__abi_tag+0x24f1c>
  1e704f:	e3 ff 
  1e7051:	c4 62 7d 18 0d 7e de 	vbroadcastss -0x1c2182(%rip),%ymm9        # 24ed8 <__abi_tag+0x24bdc>
  1e7058:	e3 ff 
  1e705a:	4c 8b 3d 37 c6 13 00 	mov    0x13c637(%rip),%r15        # 323698 <_DYNAMIC+0x448>
  1e7061:	48 8d 84 24 b0 05 00 	lea    0x5b0(%rsp),%rax
  1e7068:	00 
  1e7069:	c5 7d 6f 15 0f e8 e3 	vmovdqa -0x1c17f1(%rip),%ymm10        # 25880 <__abi_tag+0x25584>
  1e7070:	ff 
  1e7071:	c5 7d 6f 1d 07 ea e3 	vmovdqa -0x1c15f9(%rip),%ymm11        # 25a80 <__abi_tag+0x25784>
  1e7078:	ff 
  1e7079:	c4 62 7d 18 25 1e df 	vbroadcastss -0x1c20e2(%rip),%ymm12        # 24fa0 <__abi_tag+0x24ca4>
  1e7080:	e3 ff 
  1e7082:	c4 62 7d 18 2d ad e0 	vbroadcastss -0x1c1f53(%rip),%ymm13        # 25138 <__abi_tag+0x24e3c>
  1e7089:	e3 ff 
  1e708b:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
  1e7090:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
  1e7095:	49 39 ca             	cmp    %rcx,%r10
  1e7098:	0f 84 2e 52 00 00    	je     1ec2cc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x545c>
  1e709e:	4d 89 d0             	mov    %r10,%r8
  1e70a1:	49 ff c2             	inc    %r10
  1e70a4:	4c 89 c1             	mov    %r8,%rcx
  1e70a7:	48 c1 e1 05          	shl    $0x5,%rcx
  1e70ab:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  1e70b0:	48 8d 2c 0e          	lea    (%rsi,%rcx,1),%rbp
  1e70b4:	c5 fc 10 14 0e       	vmovups (%rsi,%rcx,1),%ymm2
  1e70b9:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  1e70be:	4c 8d 0c 0e          	lea    (%rsi,%rcx,1),%r9
  1e70c2:	c5 7c 10 34 0e       	vmovups (%rsi,%rcx,1),%ymm14
  1e70c7:	c5 ec 54 c3          	vandps %ymm3,%ymm2,%ymm0
  1e70cb:	c5 8c 54 cb          	vandps %ymm3,%ymm14,%ymm1
  1e70cf:	c5 fc 5f c1          	vmaxps %ymm1,%ymm0,%ymm0
  1e70d3:	c4 e2 7d 18 0d 6c de 	vbroadcastss -0x1c2194(%rip),%ymm1        # 24f48 <__abi_tag+0x24c4c>
  1e70da:	e3 ff 
  1e70dc:	c5 fc c2 c9 12       	vcmple_oqps %ymm1,%ymm0,%ymm1
  1e70e1:	c5 6c c2 fa 00       	vcmpeqps %ymm2,%ymm2,%ymm15
  1e70e6:	c4 c1 0c c2 e6 00    	vcmpeqps %ymm14,%ymm14,%ymm4
  1e70ec:	c5 84 54 e4          	vandps %ymm4,%ymm15,%ymm4
  1e70f0:	c5 dc 54 c9          	vandps %ymm1,%ymm4,%ymm1
  1e70f4:	c4 e2 7d 17 cd       	vptest %ymm5,%ymm1
  1e70f9:	0f 83 c3 06 00 00    	jae    1e77c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x952>
  1e70ff:	49 c1 e0 03          	shl    $0x3,%r8
  1e7103:	eb 2c                	jmp    1e7131 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2c1>
  1e7105:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  1e710c:	00 00 00 00 
  1e7110:	c5 94 59 c2          	vmulps %ymm2,%ymm13,%ymm0
  1e7114:	c4 e3 6d 4a d0 f0    	vblendvps %ymm15,%ymm0,%ymm2,%ymm2
  1e711a:	c4 c1 0c 59 c5       	vmulps %ymm13,%ymm14,%ymm0
  1e711f:	c4 63 0d 4a f0 f0    	vblendvps %ymm15,%ymm0,%ymm14,%ymm14
  1e7125:	c5 ec 54 c3          	vandps %ymm3,%ymm2,%ymm0
  1e7129:	c5 8c 54 cb          	vandps %ymm3,%ymm14,%ymm1
  1e712d:	c5 fc 5f c1          	vmaxps %ymm1,%ymm0,%ymm0
  1e7131:	c5 7c c2 fe 1e       	vcmpgt_oqps %ymm6,%ymm0,%ymm15
  1e7136:	c4 42 7d 17 ff       	vptest %ymm15,%ymm15
  1e713b:	0f 84 d0 00 00 00    	je     1e7211 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3a1>
  1e7141:	c5 fc 11 bc 24 10 06 	vmovups %ymm7,0x610(%rsp)
  1e7148:	00 00 
  1e714a:	c5 fc 11 bc 24 f0 05 	vmovups %ymm7,0x5f0(%rsp)
  1e7151:	00 00 
  1e7153:	c5 fc 11 bc 24 d0 05 	vmovups %ymm7,0x5d0(%rsp)
  1e715a:	00 00 
  1e715c:	c5 fc 11 bc 24 b0 05 	vmovups %ymm7,0x5b0(%rsp)
  1e7163:	00 00 
  1e7165:	c4 c1 04 54 c1       	vandps %ymm9,%ymm15,%ymm0
  1e716a:	49 8b b7 08 08 00 00 	mov    0x808(%r15),%rsi
  1e7171:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e717a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x30a>
  1e7178:	ff e6                	jmp    *%rsi
  1e717a:	c5 fe 6f 84 24 b0 05 	vmovdqu 0x5b0(%rsp),%ymm0
  1e7181:	00 00 
  1e7183:	c4 c2 7d 45 c2       	vpsrlvd %ymm10,%ymm0,%ymm0
  1e7188:	c5 a5 db c0          	vpand  %ymm0,%ymm11,%ymm0
  1e718c:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
  1e7192:	c5 f9 eb c1          	vpor   %xmm1,%xmm0,%xmm0
  1e7196:	c5 f9 70 c8 ee       	vpshufd $0xee,%xmm0,%xmm1
  1e719b:	c5 f9 eb c1          	vpor   %xmm1,%xmm0,%xmm0
  1e719f:	c5 f9 70 c8 55       	vpshufd $0x55,%xmm0,%xmm1
  1e71a4:	c5 f9 eb c1          	vpor   %xmm1,%xmm0,%xmm0
  1e71a8:	c5 f9 7e c6          	vmovd  %xmm0,%esi
  1e71ac:	85 f6                	test   %esi,%esi
  1e71ae:	0f 84 5c ff ff ff    	je     1e7110 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2a0>
  1e71b4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e71bb:	00 00 00 00 00 
  1e71c0:	31 c9                	xor    %ecx,%ecx
  1e71c2:	f3 0f bc ce          	tzcnt  %esi,%ecx
  1e71c6:	4c 01 c1             	add    %r8,%rcx
  1e71c9:	4c 39 f1             	cmp    %r14,%rcx
  1e71cc:	0f 83 e6 4e 00 00    	jae    1ec0b8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5248>
  1e71d2:	49 8b 3c cc          	mov    (%r12,%rcx,8),%rdi
  1e71d6:	48 83 c7 50          	add    $0x50,%rdi
  1e71da:	0f 80 59 4e 00 00    	jo     1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1e71e0:	49 89 3c cc          	mov    %rdi,(%r12,%rcx,8)
  1e71e4:	c4 e2 48 f3 ce       	blsr   %esi,%esi
  1e71e9:	75 d5                	jne    1e71c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x350>
  1e71eb:	e9 20 ff ff ff       	jmp    1e7110 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2a0>
  1e71f0:	c5 9c 59 c2          	vmulps %ymm2,%ymm12,%ymm0
  1e71f4:	c4 e3 6d 4a d0 f0    	vblendvps %ymm15,%ymm0,%ymm2,%ymm2
  1e71fa:	c4 c1 0c 59 c4       	vmulps %ymm12,%ymm14,%ymm0
  1e71ff:	c4 63 0d 4a f0 f0    	vblendvps %ymm15,%ymm0,%ymm14,%ymm14
  1e7205:	c5 ec 54 c3          	vandps %ymm3,%ymm2,%ymm0
  1e7209:	c5 8c 54 cb          	vandps %ymm3,%ymm14,%ymm1
  1e720d:	c5 fc 5f c1          	vmaxps %ymm1,%ymm0,%ymm0
  1e7211:	c5 fc c2 cf 00       	vcmpeqps %ymm7,%ymm0,%ymm1
  1e7216:	c4 c1 7c c2 e0 11    	vcmplt_oqps %ymm8,%ymm0,%ymm4
  1e721c:	c5 74 55 fc          	vandnps %ymm4,%ymm1,%ymm15
  1e7220:	c4 42 7d 17 ff       	vptest %ymm15,%ymm15
  1e7225:	0f 84 a5 00 00 00    	je     1e72d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x460>
  1e722b:	c5 fc 11 bc 24 10 06 	vmovups %ymm7,0x610(%rsp)
  1e7232:	00 00 
  1e7234:	c5 fc 11 bc 24 f0 05 	vmovups %ymm7,0x5f0(%rsp)
  1e723b:	00 00 
  1e723d:	c5 fc 11 bc 24 d0 05 	vmovups %ymm7,0x5d0(%rsp)
  1e7244:	00 00 
  1e7246:	c5 fc 11 bc 24 b0 05 	vmovups %ymm7,0x5b0(%rsp)
  1e724d:	00 00 
  1e724f:	c4 c1 04 54 c1       	vandps %ymm9,%ymm15,%ymm0
  1e7254:	49 8b b7 08 08 00 00 	mov    0x808(%r15),%rsi
  1e725b:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e7264 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3f4>
  1e7262:	ff e6                	jmp    *%rsi
  1e7264:	c5 fe 6f 84 24 b0 05 	vmovdqu 0x5b0(%rsp),%ymm0
  1e726b:	00 00 
  1e726d:	c4 c2 7d 45 c2       	vpsrlvd %ymm10,%ymm0,%ymm0
  1e7272:	c5 a5 db c0          	vpand  %ymm0,%ymm11,%ymm0
  1e7276:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
  1e727c:	c5 f9 eb c1          	vpor   %xmm1,%xmm0,%xmm0
  1e7280:	c5 f9 70 c8 ee       	vpshufd $0xee,%xmm0,%xmm1
  1e7285:	c5 f9 eb c1          	vpor   %xmm1,%xmm0,%xmm0
  1e7289:	c5 f9 70 c8 55       	vpshufd $0x55,%xmm0,%xmm1
  1e728e:	c5 f9 eb c1          	vpor   %xmm1,%xmm0,%xmm0
  1e7292:	c5 f9 7e c6          	vmovd  %xmm0,%esi
  1e7296:	85 f6                	test   %esi,%esi
  1e7298:	0f 84 52 ff ff ff    	je     1e71f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x380>
  1e729e:	66 90                	xchg   %ax,%ax
  1e72a0:	31 c9                	xor    %ecx,%ecx
  1e72a2:	f3 0f bc ce          	tzcnt  %esi,%ecx
  1e72a6:	4c 01 c1             	add    %r8,%rcx
  1e72a9:	4c 39 f1             	cmp    %r14,%rcx
  1e72ac:	0f 83 06 4e 00 00    	jae    1ec0b8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5248>
  1e72b2:	49 8b 3c cc          	mov    (%r12,%rcx,8),%rdi
  1e72b6:	48 83 c7 b0          	add    $0xffffffffffffffb0,%rdi
  1e72ba:	0f 80 79 4d 00 00    	jo     1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1e72c0:	49 89 3c cc          	mov    %rdi,(%r12,%rcx,8)
  1e72c4:	c4 e2 48 f3 ce       	blsr   %esi,%esi
  1e72c9:	75 d5                	jne    1e72a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x430>
  1e72cb:	e9 20 ff ff ff       	jmp    1e71f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x380>
  1e72d0:	c5 fc 11 55 00       	vmovups %ymm2,0x0(%rbp)
  1e72d5:	c4 41 7c 11 31       	vmovups %ymm14,(%r9)
  1e72da:	f6 c2 01             	test   $0x1,%dl
  1e72dd:	74 31                	je     1e7310 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4a0>
  1e72df:	4e 8d 0c d5 00 00 00 	lea    0x0(,%r10,8),%r9
  1e72e6:	00 
  1e72e7:	4d 39 f1             	cmp    %r14,%r9
  1e72ea:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  1e72ef:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1e72f4:	0f 87 d4 4d 00 00    	ja     1ec0ce <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x525e>
  1e72fa:	4b 83 3c c4 00       	cmpq   $0x0,(%r12,%r8,8)
  1e72ff:	74 30                	je     1e7331 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4c1>
  1e7301:	31 d2                	xor    %edx,%edx
  1e7303:	49 89 c9             	mov    %rcx,%r9
  1e7306:	eb 14                	jmp    1e731c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4ac>
  1e7308:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1e730f:	00 
  1e7310:	31 d2                	xor    %edx,%edx
  1e7312:	4c 8b 4c 24 78       	mov    0x78(%rsp),%r9
  1e7317:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1e731c:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
  1e7321:	4c 3b 94 24 98 00 00 	cmp    0x98(%rsp),%r10
  1e7328:	00 
  1e7329:	0f 85 66 fd ff ff    	jne    1e7095 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x225>
  1e732f:	eb 67                	jmp    1e7398 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x528>
  1e7331:	4b 83 7c c4 08 00    	cmpq   $0x0,0x8(%r12,%r8,8)
  1e7337:	49 89 c9             	mov    %rcx,%r9
  1e733a:	74 04                	je     1e7340 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4d0>
  1e733c:	31 d2                	xor    %edx,%edx
  1e733e:	eb dc                	jmp    1e731c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4ac>
  1e7340:	4b 83 7c c4 10 00    	cmpq   $0x0,0x10(%r12,%r8,8)
  1e7346:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
  1e734b:	75 28                	jne    1e7375 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x505>
  1e734d:	4b 83 7c c4 18 00    	cmpq   $0x0,0x18(%r12,%r8,8)
  1e7353:	75 20                	jne    1e7375 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x505>
  1e7355:	4b 83 7c c4 20 00    	cmpq   $0x0,0x20(%r12,%r8,8)
  1e735b:	75 18                	jne    1e7375 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x505>
  1e735d:	4b 83 7c c4 28 00    	cmpq   $0x0,0x28(%r12,%r8,8)
  1e7363:	75 10                	jne    1e7375 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x505>
  1e7365:	4b 83 7c c4 30 00    	cmpq   $0x0,0x30(%r12,%r8,8)
  1e736b:	75 08                	jne    1e7375 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x505>
  1e736d:	4b 83 7c c4 38 00    	cmpq   $0x0,0x38(%r12,%r8,8)
  1e7373:	74 04                	je     1e7379 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x509>
  1e7375:	31 d2                	xor    %edx,%edx
  1e7377:	eb a8                	jmp    1e7321 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4b1>
  1e7379:	c5 fc c2 d6 12       	vcmple_oqps %ymm6,%ymm0,%ymm2
  1e737e:	c4 c1 7c c2 c0 1d    	vcmpge_oqps %ymm8,%ymm0,%ymm0
  1e7384:	c5 fc 56 c1          	vorps  %ymm1,%ymm0,%ymm0
  1e7388:	c5 fc 54 c2          	vandps %ymm2,%ymm0,%ymm0
  1e738c:	c4 e2 7d 17 c5       	vptest %ymm5,%ymm0
  1e7391:	0f 92 c2             	setb   %dl
  1e7394:	eb 8b                	jmp    1e7321 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4b1>
  1e7396:	b2 01                	mov    $0x1,%dl
  1e7398:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  1e739d:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
  1e73a1:	4c 89 f6             	mov    %r14,%rsi
  1e73a4:	48 29 c6             	sub    %rax,%rsi
  1e73a7:	0f 82 7a 4d 00 00    	jb     1ec127 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x52b7>
  1e73ad:	48 83 7c 24 28 00    	cmpq   $0x0,0x28(%rsp)
  1e73b3:	0f 84 d1 01 00 00    	je     1e758a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x71a>
  1e73b9:	49 8d 0c c4          	lea    (%r12,%rax,8),%rcx
  1e73bd:	31 c0                	xor    %eax,%eax
  1e73bf:	c5 fa 10 05 71 dd e3 	vmovss -0x1c228f(%rip),%xmm0        # 25138 <__abi_tag+0x24e3c>
  1e73c6:	ff 
  1e73c7:	c5 fa 10 0d d1 db e3 	vmovss -0x1c242f(%rip),%xmm1        # 24fa0 <__abi_tag+0x24ca4>
  1e73ce:	ff 
  1e73cf:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1e73d4:	eb 1e                	jmp    1e73f4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x584>
  1e73d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1e73dd:	00 00 00 
  1e73e0:	4d 89 f9             	mov    %r15,%r9
  1e73e3:	40 20 fa             	and    %dil,%dl
  1e73e6:	48 ff c0             	inc    %rax
  1e73e9:	48 3b 44 24 28       	cmp    0x28(%rsp),%rax
  1e73ee:	0f 84 9b 01 00 00    	je     1e758f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x71f>
  1e73f4:	48 3b 84 24 b0 00 00 	cmp    0xb0(%rsp),%rax
  1e73fb:	00 
  1e73fc:	0f 84 84 4e 00 00    	je     1ec286 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5416>
  1e7402:	48 39 f0             	cmp    %rsi,%rax
  1e7405:	0f 84 68 4e 00 00    	je     1ec273 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5403>
  1e740b:	4d 89 cf             	mov    %r9,%r15
  1e740e:	8b 3c 83             	mov    (%rbx,%rax,4),%edi
  1e7411:	c5 f9 6e d7          	vmovd  %edi,%xmm2
  1e7415:	81 e7 ff ff ff 7f    	and    $0x7fffffff,%edi
  1e741b:	45 8b 4c 85 00       	mov    0x0(%r13,%rax,4),%r9d
  1e7420:	c4 c1 79 6e d9       	vmovd  %r9d,%xmm3
  1e7425:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  1e742c:	41 39 f9             	cmp    %edi,%r9d
  1e742f:	44 0f 46 cf          	cmovbe %edi,%r9d
  1e7433:	41 81 f9 01 00 80 53 	cmp    $0x53800001,%r9d
  1e743a:	72 64                	jb     1e74a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x630>
  1e743c:	48 8b 3c c1          	mov    (%rcx,%rax,8),%rdi
  1e7440:	c5 ea 59 d0          	vmulss %xmm0,%xmm2,%xmm2
  1e7444:	c5 e2 59 d8          	vmulss %xmm0,%xmm3,%xmm3
  1e7448:	48 83 c7 50          	add    $0x50,%rdi
  1e744c:	0f 80 0f 06 00 00    	jo     1e7a61 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xbf1>
  1e7452:	c4 c1 79 6e e1       	vmovd  %r9d,%xmm4
  1e7457:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  1e745e:	00 00 
  1e7460:	49 89 fa             	mov    %rdi,%r10
  1e7463:	c5 da 59 e0          	vmulss %xmm0,%xmm4,%xmm4
  1e7467:	c4 c1 79 7e e1       	vmovd  %xmm4,%r9d
  1e746c:	45 89 c8             	mov    %r9d,%r8d
  1e746f:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
  1e7476:	41 81 f8 00 00 80 53 	cmp    $0x53800000,%r8d
  1e747d:	76 41                	jbe    1e74c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x650>
  1e747f:	c5 ea 59 d0          	vmulss %xmm0,%xmm2,%xmm2
  1e7483:	c5 e2 59 d8          	vmulss %xmm0,%xmm3,%xmm3
  1e7487:	48 83 c7 50          	add    $0x50,%rdi
  1e748b:	71 d3                	jno    1e7460 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5f0>
  1e748d:	e9 cb 05 00 00       	jmp    1e7a5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xbed>
  1e7492:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e7499:	1f 84 00 00 00 00 00 
  1e74a0:	45 89 c8             	mov    %r9d,%r8d
  1e74a3:	41 8d 78 ff          	lea    -0x1(%r8),%edi
  1e74a7:	81 ff fe ff 7f 2b    	cmp    $0x2b7ffffe,%edi
  1e74ad:	76 2d                	jbe    1e74dc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x66c>
  1e74af:	e9 9c 00 00 00       	jmp    1e7550 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x6e0>
  1e74b4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e74bb:	00 00 00 00 00 
  1e74c0:	4c 89 14 c1          	mov    %r10,(%rcx,%rax,8)
  1e74c4:	c5 fa 11 14 83       	vmovss %xmm2,(%rbx,%rax,4)
  1e74c9:	c4 c1 7a 11 5c 85 00 	vmovss %xmm3,0x0(%r13,%rax,4)
  1e74d0:	41 8d 78 ff          	lea    -0x1(%r8),%edi
  1e74d4:	81 ff fe ff 7f 2b    	cmp    $0x2b7ffffe,%edi
  1e74da:	77 74                	ja     1e7550 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x6e0>
  1e74dc:	48 8b 3c c1          	mov    (%rcx,%rax,8),%rdi
  1e74e0:	c5 ea 59 e1          	vmulss %xmm1,%xmm2,%xmm4
  1e74e4:	c5 e2 59 d1          	vmulss %xmm1,%xmm3,%xmm2
  1e74e8:	48 83 c7 b0          	add    $0xffffffffffffffb0,%rdi
  1e74ec:	0f 80 84 05 00 00    	jo     1e7a76 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xc06>
  1e74f2:	c4 c1 79 6e d9       	vmovd  %r9d,%xmm3
  1e74f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  1e74fe:	00 00 
  1e7500:	49 89 f9             	mov    %rdi,%r9
  1e7503:	c5 e2 59 d9          	vmulss %xmm1,%xmm3,%xmm3
  1e7507:	c4 c1 79 7e d8       	vmovd  %xmm3,%r8d
  1e750c:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
  1e7513:	45 8d 50 ff          	lea    -0x1(%r8),%r10d
  1e7517:	41 81 fa ff ff 7f 2b 	cmp    $0x2b7fffff,%r10d
  1e751e:	73 20                	jae    1e7540 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x6d0>
  1e7520:	c5 da 59 e1          	vmulss %xmm1,%xmm4,%xmm4
  1e7524:	c5 ea 59 d1          	vmulss %xmm1,%xmm2,%xmm2
  1e7528:	48 83 c7 b0          	add    $0xffffffffffffffb0,%rdi
  1e752c:	71 d2                	jno    1e7500 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x690>
  1e752e:	e9 3f 05 00 00       	jmp    1e7a72 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xc02>
  1e7533:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e753a:	84 00 00 00 00 00 
  1e7540:	4c 89 0c c1          	mov    %r9,(%rcx,%rax,8)
  1e7544:	c5 fa 11 24 83       	vmovss %xmm4,(%rbx,%rax,4)
  1e7549:	c4 c1 7a 11 54 85 00 	vmovss %xmm2,0x0(%r13,%rax,4)
  1e7550:	31 ff                	xor    %edi,%edi
  1e7552:	41 81 f8 00 00 80 53 	cmp    $0x53800000,%r8d
  1e7559:	0f 87 81 fe ff ff    	ja     1e73e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x570>
  1e755f:	48 83 3c c1 00       	cmpq   $0x0,(%rcx,%rax,8)
  1e7564:	4d 89 f9             	mov    %r15,%r9
  1e7567:	0f 85 76 fe ff ff    	jne    1e73e3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x573>
  1e756d:	45 85 c0             	test   %r8d,%r8d
  1e7570:	74 10                	je     1e7582 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x712>
  1e7572:	41 81 f8 00 00 80 2b 	cmp    $0x2b800000,%r8d
  1e7579:	40 0f 93 c7          	setae  %dil
  1e757d:	e9 61 fe ff ff       	jmp    1e73e3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x573>
  1e7582:	40 b7 01             	mov    $0x1,%dil
  1e7585:	e9 59 fe ff ff       	jmp    1e73e3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x573>
  1e758a:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1e758f:	c6 84 24 dc 17 00 00 	movb   $0x2,0x17dc(%rsp)
  1e7596:	02 
  1e7597:	4c 8b ac 24 18 01 00 	mov    0x118(%rsp),%r13
  1e759e:	00 
  1e759f:	4d 89 ef             	mov    %r13,%r15
  1e75a2:	49 c1 ef 03          	shr    $0x3,%r15
  1e75a6:	4c 8b 84 24 38 01 00 	mov    0x138(%rsp),%r8
  1e75ad:	00 
  1e75ae:	4c 89 c0             	mov    %r8,%rax
  1e75b1:	48 c1 e8 03          	shr    $0x3,%rax
  1e75b5:	4c 8b 8c 24 30 01 00 	mov    0x130(%rsp),%r9
  1e75bc:	00 
  1e75bd:	4c 89 c9             	mov    %r9,%rcx
  1e75c0:	48 c1 e9 03          	shr    $0x3,%rcx
  1e75c4:	4c 8b 94 24 28 01 00 	mov    0x128(%rsp),%r10
  1e75cb:	00 
  1e75cc:	4c 89 d6             	mov    %r10,%rsi
  1e75cf:	48 c1 ee 03          	shr    $0x3,%rsi
  1e75d3:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1e75d8:	48 89 df             	mov    %rbx,%rdi
  1e75db:	48 c1 ef 03          	shr    $0x3,%rdi
  1e75df:	4c 31 f8             	xor    %r15,%rax
  1e75e2:	4c 31 f9             	xor    %r15,%rcx
  1e75e5:	48 09 c1             	or     %rax,%rcx
  1e75e8:	4c 31 fe             	xor    %r15,%rsi
  1e75eb:	48 09 ce             	or     %rcx,%rsi
  1e75ee:	4c 89 bc 24 98 00 00 	mov    %r15,0x98(%rsp)
  1e75f5:	00 
  1e75f6:	4c 31 ff             	xor    %r15,%rdi
  1e75f9:	48 09 f7             	or     %rsi,%rdi
  1e75fc:	75 35                	jne    1e7633 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x7c3>
  1e75fe:	45 89 ef             	mov    %r13d,%r15d
  1e7601:	41 83 e7 07          	and    $0x7,%r15d
  1e7605:	89 d8                	mov    %ebx,%eax
  1e7607:	83 e0 07             	and    $0x7,%eax
  1e760a:	44 89 d1             	mov    %r10d,%ecx
  1e760d:	83 e1 07             	and    $0x7,%ecx
  1e7610:	44 89 ce             	mov    %r9d,%esi
  1e7613:	83 e6 07             	and    $0x7,%esi
  1e7616:	44 89 c7             	mov    %r8d,%edi
  1e7619:	83 e7 07             	and    $0x7,%edi
  1e761c:	4c 31 ff             	xor    %r15,%rdi
  1e761f:	4c 31 fe             	xor    %r15,%rsi
  1e7622:	48 09 fe             	or     %rdi,%rsi
  1e7625:	4c 31 f9             	xor    %r15,%rcx
  1e7628:	48 09 f1             	or     %rsi,%rcx
  1e762b:	4c 31 f8             	xor    %r15,%rax
  1e762e:	48 09 c8             	or     %rcx,%rax
  1e7631:	74 18                	je     1e764b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x7db>
  1e7633:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  1e763a:	00 
  1e763b:	c6 40 08 00          	movb   $0x0,0x8(%rax)
  1e763f:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
  1e7646:	e9 28 4a 00 00       	jmp    1ec073 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5203>
  1e764b:	4c 89 7c 24 48       	mov    %r15,0x48(%rsp)
  1e7650:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  1e7657:	00 
  1e7658:	48 2b 84 24 80 00 00 	sub    0x80(%rsp),%rax
  1e765f:	00 
  1e7660:	89 c1                	mov    %eax,%ecx
  1e7662:	f7 d1                	not    %ecx
  1e7664:	48 ff c0             	inc    %rax
  1e7667:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  1e766e:	00 
  1e766f:	48 d1 e8             	shr    $1,%rax
  1e7672:	83 e1 01             	and    $0x1,%ecx
  1e7675:	48 01 c1             	add    %rax,%rcx
  1e7678:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  1e767f:	00 
  1e7680:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
  1e7685:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
  1e768a:	0f 84 ce 47 00 00    	je     1ebe5e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4fee>
  1e7690:	4c 8b 8c 24 18 01 00 	mov    0x118(%rsp),%r9
  1e7697:	00 
  1e7698:	4c 89 c9             	mov    %r9,%rcx
  1e769b:	49 b8 f8 ff ff ff ff 	movabs $0x1ffffffffffffff8,%r8
  1e76a2:	ff ff 1f 
  1e76a5:	4c 21 c1             	and    %r8,%rcx
  1e76a8:	48 89 8c 24 d8 00 00 	mov    %rcx,0xd8(%rsp)
  1e76af:	00 
  1e76b0:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  1e76b7:	00 
  1e76b8:	48 89 c1             	mov    %rax,%rcx
  1e76bb:	4c 21 c1             	and    %r8,%rcx
  1e76be:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  1e76c5:	00 
  1e76c6:	48 8b 8c 24 30 01 00 	mov    0x130(%rsp),%rcx
  1e76cd:	00 
  1e76ce:	48 89 ce             	mov    %rcx,%rsi
  1e76d1:	4c 21 c6             	and    %r8,%rsi
  1e76d4:	48 89 b4 24 e8 00 00 	mov    %rsi,0xe8(%rsp)
  1e76db:	00 
  1e76dc:	48 8b bc 24 28 01 00 	mov    0x128(%rsp),%rdi
  1e76e3:	00 
  1e76e4:	48 89 fe             	mov    %rdi,%rsi
  1e76e7:	4c 21 c6             	and    %r8,%rsi
  1e76ea:	48 89 b4 24 e0 00 00 	mov    %rsi,0xe0(%rsp)
  1e76f1:	00 
  1e76f2:	4c 21 c3             	and    %r8,%rbx
  1e76f5:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
  1e76fa:	4a 8d 34 8e          	lea    (%rsi,%r9,4),%rsi
  1e76fe:	48 89 b4 24 90 01 00 	mov    %rsi,0x190(%rsp)
  1e7705:	00 
  1e7706:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
  1e770d:	00 
  1e770e:	48 8d 04 86          	lea    (%rsi,%rax,4),%rax
  1e7712:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  1e7719:	00 
  1e771a:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  1e771f:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
  1e7723:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  1e772a:	00 
  1e772b:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  1e7732:	00 
  1e7733:	48 8d 04 b8          	lea    (%rax,%rdi,4),%rax
  1e7737:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
  1e773e:	00 
  1e773f:	4b 8d 0c 30          	lea    (%r8,%r14,1),%rcx
  1e7743:	48 83 c1 07          	add    $0x7,%rcx
  1e7747:	b0 3d                	mov    $0x3d,%al
  1e7749:	c4 e2 f8 f5 c1       	bzhi   %rax,%rcx,%rax
  1e774e:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  1e7755:	00 
  1e7756:	49 8d 40 f8          	lea    -0x8(%r8),%rax
  1e775a:	48 21 c8             	and    %rcx,%rax
  1e775d:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  1e7764:	00 
  1e7765:	49 8d 70 04          	lea    0x4(%r8),%rsi
  1e7769:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
  1e776e:	48 89 8c 24 60 01 00 	mov    %rcx,0x160(%rsp)
  1e7775:	00 
  1e7776:	48 21 f1             	and    %rsi,%rcx
  1e7779:	48 89 8c 24 70 01 00 	mov    %rcx,0x170(%rsp)
  1e7780:	00 
  1e7781:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  1e7788:	00 
  1e7789:	89 c1                	mov    %eax,%ecx
  1e778b:	83 e1 03             	and    $0x3,%ecx
  1e778e:	48 21 c6             	and    %rax,%rsi
  1e7791:	48 89 b4 24 a0 01 00 	mov    %rsi,0x1a0(%rsp)
  1e7798:	00 
  1e7799:	48 89 8c 24 98 01 00 	mov    %rcx,0x198(%rsp)
  1e77a0:	00 
  1e77a1:	c1 e1 05             	shl    $0x5,%ecx
  1e77a4:	48 89 8c 24 58 01 00 	mov    %rcx,0x158(%rsp)
  1e77ab:	00 
  1e77ac:	c4 41 00 57 ff       	vxorps %xmm15,%xmm15,%xmm15
  1e77b1:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
  1e77b6:	31 c9                	xor    %ecx,%ecx
  1e77b8:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
  1e77bd:	e9 2b 06 00 00       	jmp    1e7ded <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xf7d>
  1e77c2:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  1e77c6:	c5 fc 11 84 24 90 03 	vmovups %ymm0,0x390(%rsp)
  1e77cd:	00 00 
  1e77cf:	c5 fc 11 84 24 70 03 	vmovups %ymm0,0x370(%rsp)
  1e77d6:	00 00 
  1e77d8:	c5 fc 11 84 24 50 03 	vmovups %ymm0,0x350(%rsp)
  1e77df:	00 00 
  1e77e1:	c5 fc 11 84 24 30 03 	vmovups %ymm0,0x330(%rsp)
  1e77e8:	00 00 
  1e77ea:	c5 fc 11 84 24 10 03 	vmovups %ymm0,0x310(%rsp)
  1e77f1:	00 00 
  1e77f3:	c5 fc 11 84 24 f0 02 	vmovups %ymm0,0x2f0(%rsp)
  1e77fa:	00 00 
  1e77fc:	c5 fc 11 84 24 d0 02 	vmovups %ymm0,0x2d0(%rsp)
  1e7803:	00 00 
  1e7805:	c5 fc 11 84 24 b0 02 	vmovups %ymm0,0x2b0(%rsp)
  1e780c:	00 00 
  1e780e:	c5 fc 11 84 24 90 04 	vmovups %ymm0,0x490(%rsp)
  1e7815:	00 00 
  1e7817:	c5 fc 11 84 24 70 04 	vmovups %ymm0,0x470(%rsp)
  1e781e:	00 00 
  1e7820:	c5 fc 11 84 24 50 04 	vmovups %ymm0,0x450(%rsp)
  1e7827:	00 00 
  1e7829:	c5 fc 11 84 24 30 04 	vmovups %ymm0,0x430(%rsp)
  1e7830:	00 00 
  1e7832:	c5 fc 11 84 24 10 04 	vmovups %ymm0,0x410(%rsp)
  1e7839:	00 00 
  1e783b:	c5 fc 11 84 24 f0 03 	vmovups %ymm0,0x3f0(%rsp)
  1e7842:	00 00 
  1e7844:	c5 fc 11 84 24 d0 03 	vmovups %ymm0,0x3d0(%rsp)
  1e784b:	00 00 
  1e784d:	c5 fc 11 84 24 b0 03 	vmovups %ymm0,0x3b0(%rsp)
  1e7854:	00 00 
  1e7856:	49 8b 97 08 08 00 00 	mov    0x808(%r15),%rdx
  1e785d:	48 8d 84 24 b0 02 00 	lea    0x2b0(%rsp),%rax
  1e7864:	00 
  1e7865:	c5 fc 28 c2          	vmovaps %ymm2,%ymm0
  1e7869:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e7872 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xa02>
  1e7870:	ff e2                	jmp    *%rdx
  1e7872:	c4 c1 7c 10 01       	vmovups (%r9),%ymm0
  1e7877:	49 8b 97 08 08 00 00 	mov    0x808(%r15),%rdx
  1e787e:	48 8d 84 24 b0 03 00 	lea    0x3b0(%rsp),%rax
  1e7885:	00 
  1e7886:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e788f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xa1f>
  1e788d:	ff e2                	jmp    *%rdx
  1e788f:	4a 8d 04 c5 07 00 00 	lea    0x7(,%r8,8),%rax
  1e7896:	00 
  1e7897:	49 c1 e0 03          	shl    $0x3,%r8
  1e789b:	4c 39 f0             	cmp    %r14,%rax
  1e789e:	0f 83 bd 48 00 00    	jae    1ec161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x52f1>
  1e78a4:	4b 8d 0c c4          	lea    (%r12,%r8,8),%rcx
  1e78a8:	b2 01                	mov    $0x1,%dl
  1e78aa:	31 c0                	xor    %eax,%eax
  1e78ac:	c5 fa 10 15 84 d8 e3 	vmovss -0x1c277c(%rip),%xmm2        # 25138 <__abi_tag+0x24e3c>
  1e78b3:	ff 
  1e78b4:	c5 fa 10 1d e4 d6 e3 	vmovss -0x1c291c(%rip),%xmm3        # 24fa0 <__abi_tag+0x24ca4>
  1e78bb:	ff 
  1e78bc:	eb 1c                	jmp    1e78da <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xa6a>
  1e78be:	66 90                	xchg   %ax,%ax
  1e78c0:	81 fe 00 00 80 2b    	cmp    $0x2b800000,%esi
  1e78c6:	40 0f 93 c7          	setae  %dil
  1e78ca:	40 20 fa             	and    %dil,%dl
  1e78cd:	48 ff c0             	inc    %rax
  1e78d0:	48 83 f8 08          	cmp    $0x8,%rax
  1e78d4:	0f 84 ad 01 00 00    	je     1e7a87 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xc17>
  1e78da:	8b b4 84 b0 02 00 00 	mov    0x2b0(%rsp,%rax,4),%esi
  1e78e1:	89 f7                	mov    %esi,%edi
  1e78e3:	81 e7 ff ff ff 7f    	and    $0x7fffffff,%edi
  1e78e9:	44 8b 84 84 b0 03 00 	mov    0x3b0(%rsp,%rax,4),%r8d
  1e78f0:	00 
  1e78f1:	45 89 c3             	mov    %r8d,%r11d
  1e78f4:	41 81 e3 ff ff ff 7f 	and    $0x7fffffff,%r11d
  1e78fb:	41 39 fb             	cmp    %edi,%r11d
  1e78fe:	44 0f 46 df          	cmovbe %edi,%r11d
  1e7902:	c5 f9 6e ce          	vmovd  %esi,%xmm1
  1e7906:	c4 c1 79 6e c0       	vmovd  %r8d,%xmm0
  1e790b:	4c 8b 04 c1          	mov    (%rcx,%rax,8),%r8
  1e790f:	41 81 fb 01 00 80 53 	cmp    $0x53800001,%r11d
  1e7916:	72 58                	jb     1e7970 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xb00>
  1e7918:	c5 f2 59 ca          	vmulss %xmm2,%xmm1,%xmm1
  1e791c:	c5 fa 59 c2          	vmulss %xmm2,%xmm0,%xmm0
  1e7920:	49 83 c0 50          	add    $0x50,%r8
  1e7924:	0f 80 fd 46 00 00    	jo     1ec027 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51b7>
  1e792a:	c4 c1 79 6e e3       	vmovd  %r11d,%xmm4
  1e792f:	90                   	nop
  1e7930:	4c 89 c7             	mov    %r8,%rdi
  1e7933:	c5 da 59 e2          	vmulss %xmm2,%xmm4,%xmm4
  1e7937:	c4 c1 79 7e e3       	vmovd  %xmm4,%r11d
  1e793c:	44 89 de             	mov    %r11d,%esi
  1e793f:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
  1e7945:	81 fe 00 00 80 53    	cmp    $0x53800000,%esi
  1e794b:	0f 86 8f 00 00 00    	jbe    1e79e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xb70>
  1e7951:	c5 f2 59 ca          	vmulss %xmm2,%xmm1,%xmm1
  1e7955:	c5 fa 59 c2          	vmulss %xmm2,%xmm0,%xmm0
  1e7959:	49 83 c0 50          	add    $0x50,%r8
  1e795d:	71 d1                	jno    1e7930 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xac0>
  1e795f:	e9 b9 46 00 00       	jmp    1ec01d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51ad>
  1e7964:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e796b:	00 00 00 00 00 
  1e7970:	4c 89 c7             	mov    %r8,%rdi
  1e7973:	44 89 de             	mov    %r11d,%esi
  1e7976:	44 8d 46 ff          	lea    -0x1(%rsi),%r8d
  1e797a:	41 81 f8 fe ff 7f 2b 	cmp    $0x2b7ffffe,%r8d
  1e7981:	0f 87 7c 00 00 00    	ja     1e7a03 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xb93>
  1e7987:	c5 f2 59 cb          	vmulss %xmm3,%xmm1,%xmm1
  1e798b:	c5 fa 59 c3          	vmulss %xmm3,%xmm0,%xmm0
  1e798f:	48 83 c7 b0          	add    $0xffffffffffffffb0,%rdi
  1e7993:	0f 80 8e 46 00 00    	jo     1ec027 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51b7>
  1e7999:	c4 c1 79 6e e3       	vmovd  %r11d,%xmm4
  1e799e:	66 90                	xchg   %ax,%ax
  1e79a0:	49 89 f8             	mov    %rdi,%r8
  1e79a3:	c5 da 59 e3          	vmulss %xmm3,%xmm4,%xmm4
  1e79a7:	c5 f9 7e e6          	vmovd  %xmm4,%esi
  1e79ab:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
  1e79b1:	44 8d 5e ff          	lea    -0x1(%rsi),%r11d
  1e79b5:	41 81 fb ff ff 7f 2b 	cmp    $0x2b7fffff,%r11d
  1e79bc:	73 62                	jae    1e7a20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xbb0>
  1e79be:	c5 f2 59 cb          	vmulss %xmm3,%xmm1,%xmm1
  1e79c2:	c5 fa 59 c3          	vmulss %xmm3,%xmm0,%xmm0
  1e79c6:	48 83 c7 b0          	add    $0xffffffffffffffb0,%rdi
  1e79ca:	71 d4                	jno    1e79a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xb30>
  1e79cc:	e9 52 46 00 00       	jmp    1ec023 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51b3>
  1e79d1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e79d8:	0f 1f 84 00 00 00 00 
  1e79df:	00 
  1e79e0:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
  1e79e4:	c5 fa 11 8c 84 b0 02 	vmovss %xmm1,0x2b0(%rsp,%rax,4)
  1e79eb:	00 00 
  1e79ed:	c5 fa 11 84 84 b0 03 	vmovss %xmm0,0x3b0(%rsp,%rax,4)
  1e79f4:	00 00 
  1e79f6:	44 8d 46 ff          	lea    -0x1(%rsi),%r8d
  1e79fa:	41 81 f8 fe ff 7f 2b 	cmp    $0x2b7ffffe,%r8d
  1e7a01:	76 84                	jbe    1e7987 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xb17>
  1e7a03:	49 89 f8             	mov    %rdi,%r8
  1e7a06:	31 ff                	xor    %edi,%edi
  1e7a08:	4d 85 c0             	test   %r8,%r8
  1e7a0b:	74 34                	je     1e7a41 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xbd1>
  1e7a0d:	e9 b8 fe ff ff       	jmp    1e78ca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xa5a>
  1e7a12:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e7a19:	1f 84 00 00 00 00 00 
  1e7a20:	4c 89 04 c1          	mov    %r8,(%rcx,%rax,8)
  1e7a24:	c5 fa 11 8c 84 b0 02 	vmovss %xmm1,0x2b0(%rsp,%rax,4)
  1e7a2b:	00 00 
  1e7a2d:	c5 fa 11 84 84 b0 03 	vmovss %xmm0,0x3b0(%rsp,%rax,4)
  1e7a34:	00 00 
  1e7a36:	31 ff                	xor    %edi,%edi
  1e7a38:	4d 85 c0             	test   %r8,%r8
  1e7a3b:	0f 85 89 fe ff ff    	jne    1e78ca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xa5a>
  1e7a41:	81 fe 00 00 80 53    	cmp    $0x53800000,%esi
  1e7a47:	0f 87 7d fe ff ff    	ja     1e78ca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xa5a>
  1e7a4d:	85 f6                	test   %esi,%esi
  1e7a4f:	0f 85 6b fe ff ff    	jne    1e78c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xa50>
  1e7a55:	40 b7 01             	mov    $0x1,%dil
  1e7a58:	e9 6d fe ff ff       	jmp    1e78ca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xa5a>
  1e7a5d:	4c 89 14 c1          	mov    %r10,(%rcx,%rax,8)
  1e7a61:	c5 fa 11 14 83       	vmovss %xmm2,(%rbx,%rax,4)
  1e7a66:	c4 c1 7a 11 5c 85 00 	vmovss %xmm3,0x0(%r13,%rax,4)
  1e7a6d:	e9 c7 45 00 00       	jmp    1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1e7a72:	4c 89 0c c1          	mov    %r9,(%rcx,%rax,8)
  1e7a76:	c5 fa 11 24 83       	vmovss %xmm4,(%rbx,%rax,4)
  1e7a7b:	c4 c1 7a 11 54 85 00 	vmovss %xmm2,0x0(%r13,%rax,4)
  1e7a82:	e9 b2 45 00 00       	jmp    1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1e7a87:	49 8b b7 00 08 00 00 	mov    0x800(%r15),%rsi
  1e7a8e:	48 8d 84 24 b0 02 00 	lea    0x2b0(%rsp),%rax
  1e7a95:	00 
  1e7a96:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e7a9f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xc2f>
  1e7a9d:	ff e6                	jmp    *%rsi
  1e7a9f:	c5 fc 11 45 00       	vmovups %ymm0,0x0(%rbp)
  1e7aa4:	49 8b b7 00 08 00 00 	mov    0x800(%r15),%rsi
  1e7aab:	48 8d 84 24 b0 03 00 	lea    0x3b0(%rsp),%rax
  1e7ab2:	00 
  1e7ab3:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e7abc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xc4c>
  1e7aba:	ff e6                	jmp    *%rsi
  1e7abc:	c4 c1 7c 11 01       	vmovups %ymm0,(%r9)
  1e7ac1:	4c 3b 94 24 98 00 00 	cmp    0x98(%rsp),%r10
  1e7ac8:	00 
  1e7ac9:	0f 83 a0 43 00 00    	jae    1ebe6f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4fff>
  1e7acf:	c5 d8 57 e4          	vxorps %xmm4,%xmm4,%xmm4
  1e7ad3:	4c 8d 84 24 b0 01 00 	lea    0x1b0(%rsp),%r8
  1e7ada:	00 
  1e7adb:	4c 8d 8c 24 b0 05 00 	lea    0x5b0(%rsp),%r9
  1e7ae2:	00 
  1e7ae3:	eb 54                	jmp    1e7b39 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xcc9>
  1e7ae5:	20 ca                	and    %cl,%dl
  1e7ae7:	49 8b b7 00 08 00 00 	mov    0x800(%r15),%rsi
  1e7aee:	4c 8d 84 24 b0 01 00 	lea    0x1b0(%rsp),%r8
  1e7af5:	00 
  1e7af6:	4c 89 c0             	mov    %r8,%rax
  1e7af9:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e7b02 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xc92>
  1e7b00:	ff e6                	jmp    *%rsi
  1e7b02:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  1e7b07:	c5 fc 11 00          	vmovups %ymm0,(%rax)
  1e7b0b:	49 8b b7 00 08 00 00 	mov    0x800(%r15),%rsi
  1e7b12:	4c 8d 8c 24 b0 05 00 	lea    0x5b0(%rsp),%r9
  1e7b19:	00 
  1e7b1a:	4c 89 c8             	mov    %r9,%rax
  1e7b1d:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e7b26 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xcb6>
  1e7b24:	ff e6                	jmp    *%rsi
  1e7b26:	c5 fc 11 45 00       	vmovups %ymm0,0x0(%rbp)
  1e7b2b:	4c 3b 94 24 98 00 00 	cmp    0x98(%rsp),%r10
  1e7b32:	00 
  1e7b33:	0f 84 36 43 00 00    	je     1ebe6f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4fff>
  1e7b39:	c5 fc 11 a4 24 90 02 	vmovups %ymm4,0x290(%rsp)
  1e7b40:	00 00 
  1e7b42:	c5 fc 11 a4 24 70 02 	vmovups %ymm4,0x270(%rsp)
  1e7b49:	00 00 
  1e7b4b:	c5 fc 11 a4 24 50 02 	vmovups %ymm4,0x250(%rsp)
  1e7b52:	00 00 
  1e7b54:	c5 fc 11 a4 24 30 02 	vmovups %ymm4,0x230(%rsp)
  1e7b5b:	00 00 
  1e7b5d:	c5 fc 11 a4 24 10 02 	vmovups %ymm4,0x210(%rsp)
  1e7b64:	00 00 
  1e7b66:	c5 fc 11 a4 24 f0 01 	vmovups %ymm4,0x1f0(%rsp)
  1e7b6d:	00 00 
  1e7b6f:	c5 fc 11 a4 24 d0 01 	vmovups %ymm4,0x1d0(%rsp)
  1e7b76:	00 00 
  1e7b78:	c5 fc 11 a4 24 b0 01 	vmovups %ymm4,0x1b0(%rsp)
  1e7b7f:	00 00 
  1e7b81:	c5 fc 11 a4 24 90 06 	vmovups %ymm4,0x690(%rsp)
  1e7b88:	00 00 
  1e7b8a:	c5 fc 11 a4 24 70 06 	vmovups %ymm4,0x670(%rsp)
  1e7b91:	00 00 
  1e7b93:	c5 fc 11 a4 24 50 06 	vmovups %ymm4,0x650(%rsp)
  1e7b9a:	00 00 
  1e7b9c:	c5 fc 11 a4 24 30 06 	vmovups %ymm4,0x630(%rsp)
  1e7ba3:	00 00 
  1e7ba5:	c5 fc 11 a4 24 10 06 	vmovups %ymm4,0x610(%rsp)
  1e7bac:	00 00 
  1e7bae:	c5 fc 11 a4 24 f0 05 	vmovups %ymm4,0x5f0(%rsp)
  1e7bb5:	00 00 
  1e7bb7:	c5 fc 11 a4 24 d0 05 	vmovups %ymm4,0x5d0(%rsp)
  1e7bbe:	00 00 
  1e7bc0:	c5 fc 11 a4 24 b0 05 	vmovups %ymm4,0x5b0(%rsp)
  1e7bc7:	00 00 
  1e7bc9:	4c 89 d5             	mov    %r10,%rbp
  1e7bcc:	48 c1 e5 05          	shl    $0x5,%rbp
  1e7bd0:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  1e7bd5:	c5 fc 10 04 28       	vmovups (%rax,%rbp,1),%ymm0
  1e7bda:	49 8b b7 08 08 00 00 	mov    0x808(%r15),%rsi
  1e7be1:	4c 89 c0             	mov    %r8,%rax
  1e7be4:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e7bed <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xd7d>
  1e7beb:	ff e6                	jmp    *%rsi
  1e7bed:	4c 3b 54 24 70       	cmp    0x70(%rsp),%r10
  1e7bf2:	0f 83 eb 49 00 00    	jae    1ec5e3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5773>
  1e7bf8:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  1e7bfd:	c5 fc 10 04 2f       	vmovups (%rdi,%rbp,1),%ymm0
  1e7c02:	49 8b b7 08 08 00 00 	mov    0x808(%r15),%rsi
  1e7c09:	4c 89 c8             	mov    %r9,%rax
  1e7c0c:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e7c15 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xda5>
  1e7c13:	ff e6                	jmp    *%rsi
  1e7c15:	4a 8d 04 d5 00 00 00 	lea    0x0(,%r10,8),%rax
  1e7c1c:	00 
  1e7c1d:	4a 8d 0c d5 07 00 00 	lea    0x7(,%r10,8),%rcx
  1e7c24:	00 
  1e7c25:	4c 39 f1             	cmp    %r14,%rcx
  1e7c28:	0f 83 8d 45 00 00    	jae    1ec1bb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x534b>
  1e7c2e:	49 ff c2             	inc    %r10
  1e7c31:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  1e7c36:	48 01 e9             	add    %rbp,%rcx
  1e7c39:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  1e7c3e:	48 01 fd             	add    %rdi,%rbp
  1e7c41:	49 8d 04 c4          	lea    (%r12,%rax,8),%rax
  1e7c45:	b1 01                	mov    $0x1,%cl
  1e7c47:	45 31 c9             	xor    %r9d,%r9d
  1e7c4a:	eb 1a                	jmp    1e7c66 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xdf6>
  1e7c4c:	81 fe 00 00 80 2b    	cmp    $0x2b800000,%esi
  1e7c52:	41 0f 93 c0          	setae  %r8b
  1e7c56:	44 20 c1             	and    %r8b,%cl
  1e7c59:	49 ff c1             	inc    %r9
  1e7c5c:	49 83 f9 08          	cmp    $0x8,%r9
  1e7c60:	0f 84 7f fe ff ff    	je     1e7ae5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xc75>
  1e7c66:	42 8b b4 8c b0 01 00 	mov    0x1b0(%rsp,%r9,4),%esi
  1e7c6d:	00 
  1e7c6e:	89 f7                	mov    %esi,%edi
  1e7c70:	81 e7 ff ff ff 7f    	and    $0x7fffffff,%edi
  1e7c76:	46 8b 84 8c b0 05 00 	mov    0x5b0(%rsp,%r9,4),%r8d
  1e7c7d:	00 
  1e7c7e:	45 89 c3             	mov    %r8d,%r11d
  1e7c81:	41 81 e3 ff ff ff 7f 	and    $0x7fffffff,%r11d
  1e7c88:	41 39 fb             	cmp    %edi,%r11d
  1e7c8b:	44 0f 46 df          	cmovbe %edi,%r11d
  1e7c8f:	c5 f9 6e c6          	vmovd  %esi,%xmm0
  1e7c93:	c4 c1 79 6e c8       	vmovd  %r8d,%xmm1
  1e7c98:	4a 8b 3c c8          	mov    (%rax,%r9,8),%rdi
  1e7c9c:	41 81 fb 01 00 80 53 	cmp    $0x53800001,%r11d
  1e7ca3:	72 4b                	jb     1e7cf0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xe80>
  1e7ca5:	48 83 c7 50          	add    $0x50,%rdi
  1e7ca9:	0f 80 8a 43 00 00    	jo     1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1e7caf:	c4 c1 79 6e eb       	vmovd  %r11d,%xmm5
  1e7cb4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e7cbb:	00 00 00 00 00 
  1e7cc0:	c5 f2 59 ca          	vmulss %xmm2,%xmm1,%xmm1
  1e7cc4:	c5 fa 59 c2          	vmulss %xmm2,%xmm0,%xmm0
  1e7cc8:	49 89 f8             	mov    %rdi,%r8
  1e7ccb:	c5 d2 59 ea          	vmulss %xmm2,%xmm5,%xmm5
  1e7ccf:	c4 c1 79 7e eb       	vmovd  %xmm5,%r11d
  1e7cd4:	44 89 de             	mov    %r11d,%esi
  1e7cd7:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
  1e7cdd:	81 fe 00 00 80 53    	cmp    $0x53800000,%esi
  1e7ce3:	76 6b                	jbe    1e7d50 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xee0>
  1e7ce5:	48 83 c7 50          	add    $0x50,%rdi
  1e7ce9:	71 d5                	jno    1e7cc0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xe50>
  1e7ceb:	e9 98 43 00 00       	jmp    1ec088 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5218>
  1e7cf0:	49 89 f8             	mov    %rdi,%r8
  1e7cf3:	44 89 de             	mov    %r11d,%esi
  1e7cf6:	8d 7e ff             	lea    -0x1(%rsi),%edi
  1e7cf9:	81 ff fe ff 7f 2b    	cmp    $0x2b7ffffe,%edi
  1e7cff:	77 72                	ja     1e7d73 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xf03>
  1e7d01:	49 83 c0 b0          	add    $0xffffffffffffffb0,%r8
  1e7d05:	0f 80 2e 43 00 00    	jo     1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1e7d0b:	c4 c1 79 6e eb       	vmovd  %r11d,%xmm5
  1e7d10:	c5 f2 59 cb          	vmulss %xmm3,%xmm1,%xmm1
  1e7d14:	c5 fa 59 c3          	vmulss %xmm3,%xmm0,%xmm0
  1e7d18:	4c 89 c7             	mov    %r8,%rdi
  1e7d1b:	c5 d2 59 eb          	vmulss %xmm3,%xmm5,%xmm5
  1e7d1f:	c5 f9 7e ee          	vmovd  %xmm5,%esi
  1e7d23:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
  1e7d29:	44 8d 5e ff          	lea    -0x1(%rsi),%r11d
  1e7d2d:	41 81 fb ff ff 7f 2b 	cmp    $0x2b7fffff,%r11d
  1e7d34:	73 5a                	jae    1e7d90 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xf20>
  1e7d36:	49 83 c0 b0          	add    $0xffffffffffffffb0,%r8
  1e7d3a:	71 d4                	jno    1e7d10 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xea0>
  1e7d3c:	e9 4d 43 00 00       	jmp    1ec08e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x521e>
  1e7d41:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e7d48:	0f 1f 84 00 00 00 00 
  1e7d4f:	00 
  1e7d50:	4e 89 04 c8          	mov    %r8,(%rax,%r9,8)
  1e7d54:	c4 a1 7a 11 84 8c b0 	vmovss %xmm0,0x1b0(%rsp,%r9,4)
  1e7d5b:	01 00 00 
  1e7d5e:	c4 a1 7a 11 8c 8c b0 	vmovss %xmm1,0x5b0(%rsp,%r9,4)
  1e7d65:	05 00 00 
  1e7d68:	8d 7e ff             	lea    -0x1(%rsi),%edi
  1e7d6b:	81 ff fe ff 7f 2b    	cmp    $0x2b7ffffe,%edi
  1e7d71:	76 8e                	jbe    1e7d01 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xe91>
  1e7d73:	4c 89 c7             	mov    %r8,%rdi
  1e7d76:	45 31 c0             	xor    %r8d,%r8d
  1e7d79:	48 85 ff             	test   %rdi,%rdi
  1e7d7c:	74 36                	je     1e7db4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xf44>
  1e7d7e:	e9 d3 fe ff ff       	jmp    1e7c56 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xde6>
  1e7d83:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e7d8a:	84 00 00 00 00 00 
  1e7d90:	4a 89 3c c8          	mov    %rdi,(%rax,%r9,8)
  1e7d94:	c4 a1 7a 11 84 8c b0 	vmovss %xmm0,0x1b0(%rsp,%r9,4)
  1e7d9b:	01 00 00 
  1e7d9e:	c4 a1 7a 11 8c 8c b0 	vmovss %xmm1,0x5b0(%rsp,%r9,4)
  1e7da5:	05 00 00 
  1e7da8:	45 31 c0             	xor    %r8d,%r8d
  1e7dab:	48 85 ff             	test   %rdi,%rdi
  1e7dae:	0f 85 a2 fe ff ff    	jne    1e7c56 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xde6>
  1e7db4:	81 fe 00 00 80 53    	cmp    $0x53800000,%esi
  1e7dba:	0f 87 96 fe ff ff    	ja     1e7c56 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xde6>
  1e7dc0:	85 f6                	test   %esi,%esi
  1e7dc2:	0f 85 84 fe ff ff    	jne    1e7c4c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xddc>
  1e7dc8:	41 b0 01             	mov    $0x1,%r8b
  1e7dcb:	e9 86 fe ff ff       	jmp    1e7c56 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xde6>
  1e7dd0:	8b 54 24 50          	mov    0x50(%rsp),%edx
  1e7dd4:	48 8b 8c 24 40 01 00 	mov    0x140(%rsp),%rcx
  1e7ddb:	00 
  1e7ddc:	48 3b 8c 24 b0 00 00 	cmp    0xb0(%rsp),%rcx
  1e7de3:	00 
  1e7de4:	4d 89 f8             	mov    %r15,%r8
  1e7de7:	0f 83 71 40 00 00    	jae    1ebe5e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4fee>
  1e7ded:	80 7c 24 0f 00       	cmpb   $0x0,0xf(%rsp)
  1e7df2:	0f 84 6d 0c 00 00    	je     1e8a65 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1bf5>
  1e7df8:	4c 89 e8             	mov    %r13,%rax
  1e7dfb:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1e7e00:	4d 89 d5             	mov    %r10,%r13
  1e7e03:	4c 89 5c 24 38       	mov    %r11,0x38(%rsp)
  1e7e08:	49 89 ea             	mov    %rbp,%r10
  1e7e0b:	4c 8b 9c 24 90 00 00 	mov    0x90(%rsp),%r11
  1e7e12:	00 
  1e7e13:	48 89 cf             	mov    %rcx,%rdi
  1e7e16:	eb 2e                	jmp    1e7e46 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xfd6>
  1e7e18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1e7e1f:	00 
  1e7e20:	b2 01                	mov    $0x1,%dl
  1e7e22:	4c 89 d0             	mov    %r10,%rax
  1e7e25:	4c 89 ce             	mov    %r9,%rsi
  1e7e28:	4d 89 ea             	mov    %r13,%r10
  1e7e2b:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  1e7e30:	48 89 cf             	mov    %rcx,%rdi
  1e7e33:	48 3b 8c 24 b0 00 00 	cmp    0xb0(%rsp),%rcx
  1e7e3a:	00 
  1e7e3b:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  1e7e40:	0f 83 18 40 00 00    	jae    1ebe5e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4fee>
  1e7e46:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  1e7e4b:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  1e7e50:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  1e7e55:	4c 8d 4f 01          	lea    0x1(%rdi),%r9
  1e7e59:	f6 c2 01             	test   $0x1,%dl
  1e7e5c:	48 89 7c 24 70       	mov    %rdi,0x70(%rsp)
  1e7e61:	0f 84 27 0c 00 00    	je     1e8a8e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1c1e>
  1e7e67:	4c 3b 8c 24 b0 00 00 	cmp    0xb0(%rsp),%r9
  1e7e6e:	00 
  1e7e6f:	0f 83 19 0c 00 00    	jae    1e8a8e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1c1e>
  1e7e75:	4c 39 c7             	cmp    %r8,%rdi
  1e7e78:	0f 83 cc 44 00 00    	jae    1ec34a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54da>
  1e7e7e:	48 3b bc 24 10 01 00 	cmp    0x110(%rsp),%rdi
  1e7e85:	00 
  1e7e86:	0f 83 02 45 00 00    	jae    1ec38e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x551e>
  1e7e8c:	4d 39 c1             	cmp    %r8,%r9
  1e7e8f:	0f 83 e3 44 00 00    	jae    1ec378 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5508>
  1e7e95:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
  1e7e9a:	4c 3b 8c 24 10 01 00 	cmp    0x110(%rsp),%r9
  1e7ea1:	00 
  1e7ea2:	0f 83 b5 44 00 00    	jae    1ec35d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54ed>
  1e7ea8:	4d 89 d3             	mov    %r10,%r11
  1e7eab:	48 8d 47 02          	lea    0x2(%rdi),%rax
  1e7eaf:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  1e7eb4:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  1e7eb9:	48 89 c8             	mov    %rcx,%rax
  1e7ebc:	48 c1 e8 03          	shr    $0x3,%rax
  1e7ec0:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  1e7ec7:	00 
  1e7ec8:	c4 e2 7d 18 1c b9    	vbroadcastss (%rcx,%rdi,4),%ymm3
  1e7ece:	48 8b 94 24 f8 00 00 	mov    0xf8(%rsp),%rdx
  1e7ed5:	00 
  1e7ed6:	c4 e2 7d 18 04 ba    	vbroadcastss (%rdx,%rdi,4),%ymm0
  1e7edc:	c4 e2 7d 18 54 b9 04 	vbroadcastss 0x4(%rcx,%rdi,4),%ymm2
  1e7ee3:	c4 e2 7d 18 4c ba 04 	vbroadcastss 0x4(%rdx,%rdi,4),%ymm1
  1e7eea:	4c 89 6c 24 50       	mov    %r13,0x50(%rsp)
  1e7eef:	0f 84 2b 01 00 00    	je     1e8020 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x11b0>
  1e7ef5:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  1e7efa:	48 c1 ef 03          	shr    $0x3,%rdi
  1e7efe:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1e7f03:	48 c1 ee 03          	shr    $0x3,%rsi
  1e7f07:	c4 41 29 ef d2       	vpxor  %xmm10,%xmm10,%xmm10
  1e7f0c:	31 d2                	xor    %edx,%edx
  1e7f0e:	45 31 d2             	xor    %r10d,%r10d
  1e7f11:	c4 41 30 57 c9       	vxorps %xmm9,%xmm9,%xmm9
  1e7f16:	c5 c0 57 ff          	vxorps %xmm7,%xmm7,%xmm7
  1e7f1a:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
  1e7f1f:	c5 c8 57 f6          	vxorps %xmm6,%xmm6,%xmm6
  1e7f23:	c5 d1 ef ed          	vpxor  %xmm5,%xmm5,%xmm5
  1e7f27:	c5 d8 57 e4          	vxorps %xmm4,%xmm4,%xmm4
  1e7f2b:	c4 41 21 ef db       	vpxor  %xmm11,%xmm11,%xmm11
  1e7f30:	4c 8b 4c 24 78       	mov    0x78(%rsp),%r9
  1e7f35:	eb 1e                	jmp    1e7f55 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x10e5>
  1e7f37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  1e7f3e:	00 00 
  1e7f40:	49 ff c2             	inc    %r10
  1e7f43:	48 83 c2 20          	add    $0x20,%rdx
  1e7f47:	4c 39 d0             	cmp    %r10,%rax
  1e7f4a:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
  1e7f4f:	0f 84 f4 00 00 00    	je     1e8049 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x11d9>
  1e7f55:	4c 39 d7             	cmp    %r10,%rdi
  1e7f58:	0f 84 77 42 00 00    	je     1ec1d5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5365>
  1e7f5e:	4c 39 94 24 98 00 00 	cmp    %r10,0x98(%rsp)
  1e7f65:	00 
  1e7f66:	0f 84 8f 42 00 00    	je     1ec1fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x538b>
  1e7f6c:	4c 39 d6             	cmp    %r10,%rsi
  1e7f6f:	0f 84 73 42 00 00    	je     1ec1e8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5378>
  1e7f75:	c4 41 7c 10 64 15 00 	vmovups 0x0(%r13,%rdx,1),%ymm12
  1e7f7c:	c4 c2 1d b8 24 11    	vfmadd231ps (%r9,%rdx,1),%ymm12,%ymm4
  1e7f82:	4c 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%r13
  1e7f89:	00 
  1e7f8a:	c4 c2 1d b8 6c 15 00 	vfmadd231ps 0x0(%r13,%rdx,1),%ymm12,%ymm5
  1e7f91:	4c 8b 7c 24 58       	mov    0x58(%rsp),%r15
  1e7f96:	c4 c2 1d b8 34 17    	vfmadd231ps (%r15,%rdx,1),%ymm12,%ymm6
  1e7f9c:	48 8b 9c 24 b8 00 00 	mov    0xb8(%rsp),%rbx
  1e7fa3:	00 
  1e7fa4:	c4 62 1d b8 04 13    	vfmadd231ps (%rbx,%rdx,1),%ymm12,%ymm8
  1e7faa:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e7faf:	c5 7c 10 2c 11       	vmovups (%rcx,%rdx,1),%ymm13
  1e7fb4:	c4 62 65 a8 e8       	vfmadd213ps %ymm0,%ymm3,%ymm13
  1e7fb9:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  1e7fbe:	c4 62 1d a8 2c 11    	vfmadd213ps (%rcx,%rdx,1),%ymm12,%ymm13
  1e7fc4:	c4 41 7c 11 2c 13    	vmovups %ymm13,(%r11,%rdx,1)
  1e7fca:	c4 c2 15 b8 3c 11    	vfmadd231ps (%r9,%rdx,1),%ymm13,%ymm7
  1e7fd0:	c4 42 15 b8 4c 15 00 	vfmadd231ps 0x0(%r13,%rdx,1),%ymm13,%ymm9
  1e7fd7:	c4 42 15 b8 14 17    	vfmadd231ps (%r15,%rdx,1),%ymm13,%ymm10
  1e7fdd:	c4 62 15 b8 1c 13    	vfmadd231ps (%rbx,%rdx,1),%ymm13,%ymm11
  1e7fe3:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  1e7fe8:	48 3b 8c 24 b0 00 00 	cmp    0xb0(%rsp),%rcx
  1e7fef:	00 
  1e7ff0:	0f 83 4a ff ff ff    	jae    1e7f40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x10d0>
  1e7ff6:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e7ffb:	c5 7c 10 34 11       	vmovups (%rcx,%rdx,1),%ymm14
  1e8000:	c4 62 6d a8 f1       	vfmadd213ps %ymm1,%ymm2,%ymm14
  1e8005:	c4 42 0d a8 ec       	vfmadd213ps %ymm12,%ymm14,%ymm13
  1e800a:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  1e800f:	c5 7c 11 2c 11       	vmovups %ymm13,(%rcx,%rdx,1)
  1e8014:	e9 27 ff ff ff       	jmp    1e7f40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x10d0>
  1e8019:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  1e8020:	c4 41 21 ef db       	vpxor  %xmm11,%xmm11,%xmm11
  1e8025:	c5 d8 57 e4          	vxorps %xmm4,%xmm4,%xmm4
  1e8029:	c5 d1 ef ed          	vpxor  %xmm5,%xmm5,%xmm5
  1e802d:	c5 c8 57 f6          	vxorps %xmm6,%xmm6,%xmm6
  1e8031:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
  1e8036:	c5 c0 57 ff          	vxorps %xmm7,%xmm7,%xmm7
  1e803a:	c4 41 30 57 c9       	vxorps %xmm9,%xmm9,%xmm9
  1e803f:	c4 41 29 ef d2       	vpxor  %xmm10,%xmm10,%xmm10
  1e8044:	4c 8b 4c 24 78       	mov    0x78(%rsp),%r9
  1e8049:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  1e804e:	c4 c3 7d 19 e4 01    	vextractf128 $0x1,%ymm4,%xmm12
  1e8054:	c5 98 58 e4          	vaddps %xmm4,%xmm12,%xmm4
  1e8058:	c5 59 c6 e4 01       	vshufpd $0x1,%xmm4,%xmm4,%xmm12
  1e805d:	c5 98 58 e4          	vaddps %xmm4,%xmm12,%xmm4
  1e8061:	c5 7a 16 e4          	vmovshdup %xmm4,%xmm12
  1e8065:	c5 9a 58 e4          	vaddss %xmm4,%xmm12,%xmm4
  1e8069:	c4 c3 7d 19 ec 01    	vextractf128 $0x1,%ymm5,%xmm12
  1e806f:	c5 98 58 ed          	vaddps %xmm5,%xmm12,%xmm5
  1e8073:	c5 51 c6 e5 01       	vshufpd $0x1,%xmm5,%xmm5,%xmm12
  1e8078:	c5 98 58 ed          	vaddps %xmm5,%xmm12,%xmm5
  1e807c:	c5 7a 16 e5          	vmovshdup %xmm5,%xmm12
  1e8080:	c5 9a 58 ed          	vaddss %xmm5,%xmm12,%xmm5
  1e8084:	c4 c3 7d 19 f4 01    	vextractf128 $0x1,%ymm6,%xmm12
  1e808a:	c5 98 58 f6          	vaddps %xmm6,%xmm12,%xmm6
  1e808e:	c5 49 c6 e6 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm12
  1e8093:	c5 98 58 f6          	vaddps %xmm6,%xmm12,%xmm6
  1e8097:	c5 7a 16 e6          	vmovshdup %xmm6,%xmm12
  1e809b:	c5 9a 58 f6          	vaddss %xmm6,%xmm12,%xmm6
  1e809f:	c4 43 7d 19 c4 01    	vextractf128 $0x1,%ymm8,%xmm12
  1e80a5:	c4 41 38 58 c4       	vaddps %xmm12,%xmm8,%xmm8
  1e80aa:	c4 41 39 c6 e0 01    	vshufpd $0x1,%xmm8,%xmm8,%xmm12
  1e80b0:	c4 41 38 58 c4       	vaddps %xmm12,%xmm8,%xmm8
  1e80b5:	c4 41 7a 16 e0       	vmovshdup %xmm8,%xmm12
  1e80ba:	c4 41 3a 58 c4       	vaddss %xmm12,%xmm8,%xmm8
  1e80bf:	c4 c3 7d 19 fc 01    	vextractf128 $0x1,%ymm7,%xmm12
  1e80c5:	c5 98 58 ff          	vaddps %xmm7,%xmm12,%xmm7
  1e80c9:	c5 41 c6 e7 01       	vshufpd $0x1,%xmm7,%xmm7,%xmm12
  1e80ce:	c5 98 58 ff          	vaddps %xmm7,%xmm12,%xmm7
  1e80d2:	c5 7a 16 e7          	vmovshdup %xmm7,%xmm12
  1e80d6:	c5 9a 58 ff          	vaddss %xmm7,%xmm12,%xmm7
  1e80da:	c4 43 7d 19 cc 01    	vextractf128 $0x1,%ymm9,%xmm12
  1e80e0:	c4 41 30 58 cc       	vaddps %xmm12,%xmm9,%xmm9
  1e80e5:	c4 41 31 c6 e1 01    	vshufpd $0x1,%xmm9,%xmm9,%xmm12
  1e80eb:	c4 41 30 58 cc       	vaddps %xmm12,%xmm9,%xmm9
  1e80f0:	c4 41 7a 16 e1       	vmovshdup %xmm9,%xmm12
  1e80f5:	c4 41 32 58 cc       	vaddss %xmm12,%xmm9,%xmm9
  1e80fa:	c4 43 7d 19 d4 01    	vextractf128 $0x1,%ymm10,%xmm12
  1e8100:	c4 41 28 58 d4       	vaddps %xmm12,%xmm10,%xmm10
  1e8105:	c4 41 29 c6 e2 01    	vshufpd $0x1,%xmm10,%xmm10,%xmm12
  1e810b:	c4 41 28 58 d4       	vaddps %xmm12,%xmm10,%xmm10
  1e8110:	c4 41 7a 16 e2       	vmovshdup %xmm10,%xmm12
  1e8115:	c4 41 2a 58 d4       	vaddss %xmm12,%xmm10,%xmm10
  1e811a:	c4 43 7d 19 dc 01    	vextractf128 $0x1,%ymm11,%xmm12
  1e8120:	c4 41 20 58 dc       	vaddps %xmm12,%xmm11,%xmm11
  1e8125:	c4 41 21 c6 e3 01    	vshufpd $0x1,%xmm11,%xmm11,%xmm12
  1e812b:	c4 41 20 58 dc       	vaddps %xmm12,%xmm11,%xmm11
  1e8130:	c4 41 7a 16 e3       	vmovshdup %xmm11,%xmm12
  1e8135:	c4 41 22 58 dc       	vaddss %xmm12,%xmm11,%xmm11
  1e813a:	83 e0 07             	and    $0x7,%eax
  1e813d:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  1e8144:	00 
  1e8145:	0f 84 85 08 00 00    	je     1e89d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1b60>
  1e814b:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  1e8150:	83 e0 07             	and    $0x7,%eax
  1e8153:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  1e815a:	00 
  1e815b:	0f 84 ce 41 00 00    	je     1ec32f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54bf>
  1e8161:	48 83 7c 24 48 00    	cmpq   $0x0,0x48(%rsp)
  1e8167:	0f 84 aa 41 00 00    	je     1ec317 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54a7>
  1e816d:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1e8172:	83 e6 07             	and    $0x7,%esi
  1e8175:	48 89 b4 24 c0 00 00 	mov    %rsi,0xc0(%rsp)
  1e817c:	00 
  1e817d:	0f 84 79 41 00 00    	je     1ec2fc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x548c>
  1e8183:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1e8188:	48 b9 f8 ff ff ff ff 	movabs $0x1ffffffffffffff8,%rcx
  1e818f:	ff ff 1f 
  1e8192:	48 21 cd             	and    %rcx,%rbp
  1e8195:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  1e819a:	48 21 c8             	and    %rcx,%rax
  1e819d:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  1e81a2:	49 21 c8             	and    %rcx,%r8
  1e81a5:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  1e81ac:	00 
  1e81ad:	c4 41 7a 10 64 85 00 	vmovss 0x0(%r13,%rax,4),%xmm12
  1e81b4:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
  1e81bb:	00 
  1e81bc:	c4 c2 19 b9 24 91    	vfmadd231ss (%r9,%rdx,4),%xmm12,%xmm4
  1e81c2:	4c 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%r13
  1e81c9:	00 
  1e81ca:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  1e81d1:	00 
  1e81d2:	c4 c2 19 b9 6c 85 00 	vfmadd231ss 0x0(%r13,%rax,4),%xmm12,%xmm5
  1e81d9:	4c 8b 7c 24 58       	mov    0x58(%rsp),%r15
  1e81de:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  1e81e5:	00 
  1e81e6:	c4 c2 19 b9 34 b7    	vfmadd231ss (%r15,%rsi,4),%xmm12,%xmm6
  1e81ec:	48 8b 9c 24 b8 00 00 	mov    0xb8(%rsp),%rbx
  1e81f3:	00 
  1e81f4:	4c 89 cf             	mov    %r9,%rdi
  1e81f7:	4c 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%r9
  1e81fe:	00 
  1e81ff:	c4 22 19 b9 04 8b    	vfmadd231ss (%rbx,%r9,4),%xmm12,%xmm8
  1e8205:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e820a:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  1e820f:	c4 21 7a 10 2c 91    	vmovss (%rcx,%r10,4),%xmm13
  1e8215:	4d 89 da             	mov    %r11,%r10
  1e8218:	c4 62 61 a9 e8       	vfmadd213ss %xmm0,%xmm3,%xmm13
  1e821d:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  1e8222:	48 89 ac 24 80 00 00 	mov    %rbp,0x80(%rsp)
  1e8229:	00 
  1e822a:	c4 62 19 a9 2c a9    	vfmadd213ss (%rcx,%rbp,4),%xmm12,%xmm13
  1e8230:	4c 89 c5             	mov    %r8,%rbp
  1e8233:	c4 01 7a 11 2c 83    	vmovss %xmm13,(%r11,%r8,4)
  1e8239:	c4 e2 11 b9 3c 97    	vfmadd231ss (%rdi,%rdx,4),%xmm13,%xmm7
  1e823f:	c4 42 11 b9 4c 85 00 	vfmadd231ss 0x0(%r13,%rax,4),%xmm13,%xmm9
  1e8246:	c4 42 11 b9 14 b7    	vfmadd231ss (%r15,%rsi,4),%xmm13,%xmm10
  1e824c:	c4 22 11 b9 1c 8b    	vfmadd231ss (%rbx,%r9,4),%xmm13,%xmm11
  1e8252:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  1e8257:	48 3b 84 24 b0 00 00 	cmp    0xb0(%rsp),%rax
  1e825e:	00 
  1e825f:	73 2f                	jae    1e8290 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1420>
  1e8261:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e8266:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  1e826b:	c4 21 7a 10 34 91    	vmovss (%rcx,%r10,4),%xmm14
  1e8271:	4d 89 da             	mov    %r11,%r10
  1e8274:	c4 62 69 a9 f1       	vfmadd213ss %xmm1,%xmm2,%xmm14
  1e8279:	c4 42 09 a9 ec       	vfmadd213ss %xmm12,%xmm14,%xmm13
  1e827e:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  1e8283:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  1e828a:	00 
  1e828b:	c5 7a 11 2c 88       	vmovss %xmm13,(%rax,%rcx,4)
  1e8290:	83 bc 24 90 00 00 00 	cmpl   $0x1,0x90(%rsp)
  1e8297:	01 
  1e8298:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
  1e829d:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  1e82a2:	0f 84 08 07 00 00    	je     1e89b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1b40>
  1e82a8:	83 bc 24 a8 00 00 00 	cmpl   $0x1,0xa8(%rsp)
  1e82af:	01 
  1e82b0:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1e82b7:	00 
  1e82b8:	0f 84 71 40 00 00    	je     1ec32f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54bf>
  1e82be:	83 7c 24 48 01       	cmpl   $0x1,0x48(%rsp)
  1e82c3:	0f 84 4e 40 00 00    	je     1ec317 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54a7>
  1e82c9:	83 bc 24 c0 00 00 00 	cmpl   $0x1,0xc0(%rsp)
  1e82d0:	01 
  1e82d1:	0f 84 25 40 00 00    	je     1ec2fc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x548c>
  1e82d7:	c4 41 7a 10 64 85 04 	vmovss 0x4(%r13,%rax,4),%xmm12
  1e82de:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
  1e82e5:	00 
  1e82e6:	c4 e2 19 b9 64 91 04 	vfmadd231ss 0x4(%rcx,%rdx,4),%xmm12,%xmm4
  1e82ed:	4c 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%r13
  1e82f4:	00 
  1e82f5:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  1e82fc:	00 
  1e82fd:	c4 c2 19 b9 6c 85 04 	vfmadd231ss 0x4(%r13,%rax,4),%xmm12,%xmm5
  1e8304:	4c 8b 7c 24 58       	mov    0x58(%rsp),%r15
  1e8309:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  1e8310:	00 
  1e8311:	c4 c2 19 b9 74 b7 04 	vfmadd231ss 0x4(%r15,%rsi,4),%xmm12,%xmm6
  1e8318:	48 8b 9c 24 b8 00 00 	mov    0xb8(%rsp),%rbx
  1e831f:	00 
  1e8320:	48 89 cf             	mov    %rcx,%rdi
  1e8323:	4c 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%r9
  1e832a:	00 
  1e832b:	c4 22 19 b9 44 8b 04 	vfmadd231ss 0x4(%rbx,%r9,4),%xmm12,%xmm8
  1e8332:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e8337:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  1e833c:	c4 21 7a 10 6c 91 04 	vmovss 0x4(%rcx,%r10,4),%xmm13
  1e8343:	c4 62 61 a9 e8       	vfmadd213ss %xmm0,%xmm3,%xmm13
  1e8348:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  1e834d:	4c 8b 94 24 80 00 00 	mov    0x80(%rsp),%r10
  1e8354:	00 
  1e8355:	c4 22 19 a9 6c 91 04 	vfmadd213ss 0x4(%rcx,%r10,4),%xmm12,%xmm13
  1e835c:	4d 89 da             	mov    %r11,%r10
  1e835f:	c4 41 7a 11 6c ab 04 	vmovss %xmm13,0x4(%r11,%rbp,4)
  1e8366:	c4 e2 11 b9 7c 97 04 	vfmadd231ss 0x4(%rdi,%rdx,4),%xmm13,%xmm7
  1e836d:	c4 42 11 b9 4c 85 04 	vfmadd231ss 0x4(%r13,%rax,4),%xmm13,%xmm9
  1e8374:	c4 42 11 b9 54 b7 04 	vfmadd231ss 0x4(%r15,%rsi,4),%xmm13,%xmm10
  1e837b:	c4 22 11 b9 5c 8b 04 	vfmadd231ss 0x4(%rbx,%r9,4),%xmm13,%xmm11
  1e8382:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  1e8387:	48 3b 84 24 b0 00 00 	cmp    0xb0(%rsp),%rax
  1e838e:	00 
  1e838f:	73 31                	jae    1e83c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1552>
  1e8391:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e8396:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  1e839b:	c4 21 7a 10 74 91 04 	vmovss 0x4(%rcx,%r10,4),%xmm14
  1e83a2:	4d 89 da             	mov    %r11,%r10
  1e83a5:	c4 62 69 a9 f1       	vfmadd213ss %xmm1,%xmm2,%xmm14
  1e83aa:	c4 42 09 a9 ec       	vfmadd213ss %xmm12,%xmm14,%xmm13
  1e83af:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  1e83b4:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  1e83bb:	00 
  1e83bc:	c5 7a 11 6c 88 04    	vmovss %xmm13,0x4(%rax,%rcx,4)
  1e83c2:	83 bc 24 90 00 00 00 	cmpl   $0x2,0x90(%rsp)
  1e83c9:	02 
  1e83ca:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
  1e83cf:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  1e83d4:	0f 84 d6 05 00 00    	je     1e89b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1b40>
  1e83da:	83 bc 24 a8 00 00 00 	cmpl   $0x2,0xa8(%rsp)
  1e83e1:	02 
  1e83e2:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1e83e9:	00 
  1e83ea:	0f 84 3f 3f 00 00    	je     1ec32f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54bf>
  1e83f0:	83 7c 24 48 02       	cmpl   $0x2,0x48(%rsp)
  1e83f5:	0f 84 1c 3f 00 00    	je     1ec317 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54a7>
  1e83fb:	83 bc 24 c0 00 00 00 	cmpl   $0x2,0xc0(%rsp)
  1e8402:	02 
  1e8403:	0f 84 f3 3e 00 00    	je     1ec2fc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x548c>
  1e8409:	c4 41 7a 10 64 85 08 	vmovss 0x8(%r13,%rax,4),%xmm12
  1e8410:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
  1e8417:	00 
  1e8418:	c4 e2 19 b9 64 91 08 	vfmadd231ss 0x8(%rcx,%rdx,4),%xmm12,%xmm4
  1e841f:	4c 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%r13
  1e8426:	00 
  1e8427:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  1e842e:	00 
  1e842f:	c4 c2 19 b9 6c 85 08 	vfmadd231ss 0x8(%r13,%rax,4),%xmm12,%xmm5
  1e8436:	4c 8b 7c 24 58       	mov    0x58(%rsp),%r15
  1e843b:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  1e8442:	00 
  1e8443:	c4 c2 19 b9 74 b7 08 	vfmadd231ss 0x8(%r15,%rsi,4),%xmm12,%xmm6
  1e844a:	48 8b 9c 24 b8 00 00 	mov    0xb8(%rsp),%rbx
  1e8451:	00 
  1e8452:	48 89 cf             	mov    %rcx,%rdi
  1e8455:	4c 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%r9
  1e845c:	00 
  1e845d:	c4 22 19 b9 44 8b 08 	vfmadd231ss 0x8(%rbx,%r9,4),%xmm12,%xmm8
  1e8464:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e8469:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  1e846e:	c4 21 7a 10 6c 91 08 	vmovss 0x8(%rcx,%r10,4),%xmm13
  1e8475:	c4 62 61 a9 e8       	vfmadd213ss %xmm0,%xmm3,%xmm13
  1e847a:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  1e847f:	4c 8b 94 24 80 00 00 	mov    0x80(%rsp),%r10
  1e8486:	00 
  1e8487:	c4 22 19 a9 6c 91 08 	vfmadd213ss 0x8(%rcx,%r10,4),%xmm12,%xmm13
  1e848e:	4d 89 da             	mov    %r11,%r10
  1e8491:	c4 41 7a 11 6c ab 08 	vmovss %xmm13,0x8(%r11,%rbp,4)
  1e8498:	c4 e2 11 b9 7c 97 08 	vfmadd231ss 0x8(%rdi,%rdx,4),%xmm13,%xmm7
  1e849f:	c4 42 11 b9 4c 85 08 	vfmadd231ss 0x8(%r13,%rax,4),%xmm13,%xmm9
  1e84a6:	c4 42 11 b9 54 b7 08 	vfmadd231ss 0x8(%r15,%rsi,4),%xmm13,%xmm10
  1e84ad:	c4 22 11 b9 5c 8b 08 	vfmadd231ss 0x8(%rbx,%r9,4),%xmm13,%xmm11
  1e84b4:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  1e84b9:	48 3b 84 24 b0 00 00 	cmp    0xb0(%rsp),%rax
  1e84c0:	00 
  1e84c1:	73 31                	jae    1e84f4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1684>
  1e84c3:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e84c8:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  1e84cd:	c4 21 7a 10 74 91 08 	vmovss 0x8(%rcx,%r10,4),%xmm14
  1e84d4:	4d 89 da             	mov    %r11,%r10
  1e84d7:	c4 62 69 a9 f1       	vfmadd213ss %xmm1,%xmm2,%xmm14
  1e84dc:	c4 42 09 a9 ec       	vfmadd213ss %xmm12,%xmm14,%xmm13
  1e84e1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  1e84e6:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  1e84ed:	00 
  1e84ee:	c5 7a 11 6c 88 08    	vmovss %xmm13,0x8(%rax,%rcx,4)
  1e84f4:	83 bc 24 90 00 00 00 	cmpl   $0x3,0x90(%rsp)
  1e84fb:	03 
  1e84fc:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
  1e8501:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  1e8506:	0f 84 a4 04 00 00    	je     1e89b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1b40>
  1e850c:	83 bc 24 a8 00 00 00 	cmpl   $0x3,0xa8(%rsp)
  1e8513:	03 
  1e8514:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1e851b:	00 
  1e851c:	0f 84 0d 3e 00 00    	je     1ec32f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54bf>
  1e8522:	83 7c 24 48 03       	cmpl   $0x3,0x48(%rsp)
  1e8527:	0f 84 ea 3d 00 00    	je     1ec317 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54a7>
  1e852d:	83 bc 24 c0 00 00 00 	cmpl   $0x3,0xc0(%rsp)
  1e8534:	03 
  1e8535:	0f 84 c1 3d 00 00    	je     1ec2fc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x548c>
  1e853b:	c4 41 7a 10 64 85 0c 	vmovss 0xc(%r13,%rax,4),%xmm12
  1e8542:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
  1e8549:	00 
  1e854a:	c4 e2 19 b9 64 91 0c 	vfmadd231ss 0xc(%rcx,%rdx,4),%xmm12,%xmm4
  1e8551:	4c 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%r13
  1e8558:	00 
  1e8559:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  1e8560:	00 
  1e8561:	c4 c2 19 b9 6c 85 0c 	vfmadd231ss 0xc(%r13,%rax,4),%xmm12,%xmm5
  1e8568:	4c 8b 7c 24 58       	mov    0x58(%rsp),%r15
  1e856d:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  1e8574:	00 
  1e8575:	c4 c2 19 b9 74 b7 0c 	vfmadd231ss 0xc(%r15,%rsi,4),%xmm12,%xmm6
  1e857c:	48 8b 9c 24 b8 00 00 	mov    0xb8(%rsp),%rbx
  1e8583:	00 
  1e8584:	48 89 cf             	mov    %rcx,%rdi
  1e8587:	4c 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%r9
  1e858e:	00 
  1e858f:	c4 22 19 b9 44 8b 0c 	vfmadd231ss 0xc(%rbx,%r9,4),%xmm12,%xmm8
  1e8596:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e859b:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  1e85a0:	c4 21 7a 10 6c 91 0c 	vmovss 0xc(%rcx,%r10,4),%xmm13
  1e85a7:	c4 62 61 a9 e8       	vfmadd213ss %xmm0,%xmm3,%xmm13
  1e85ac:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  1e85b1:	4c 8b 94 24 80 00 00 	mov    0x80(%rsp),%r10
  1e85b8:	00 
  1e85b9:	c4 22 19 a9 6c 91 0c 	vfmadd213ss 0xc(%rcx,%r10,4),%xmm12,%xmm13
  1e85c0:	4d 89 da             	mov    %r11,%r10
  1e85c3:	c4 41 7a 11 6c ab 0c 	vmovss %xmm13,0xc(%r11,%rbp,4)
  1e85ca:	c4 e2 11 b9 7c 97 0c 	vfmadd231ss 0xc(%rdi,%rdx,4),%xmm13,%xmm7
  1e85d1:	c4 42 11 b9 4c 85 0c 	vfmadd231ss 0xc(%r13,%rax,4),%xmm13,%xmm9
  1e85d8:	c4 42 11 b9 54 b7 0c 	vfmadd231ss 0xc(%r15,%rsi,4),%xmm13,%xmm10
  1e85df:	c4 22 11 b9 5c 8b 0c 	vfmadd231ss 0xc(%rbx,%r9,4),%xmm13,%xmm11
  1e85e6:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  1e85eb:	48 3b 84 24 b0 00 00 	cmp    0xb0(%rsp),%rax
  1e85f2:	00 
  1e85f3:	73 31                	jae    1e8626 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x17b6>
  1e85f5:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e85fa:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  1e85ff:	c4 21 7a 10 74 91 0c 	vmovss 0xc(%rcx,%r10,4),%xmm14
  1e8606:	4d 89 da             	mov    %r11,%r10
  1e8609:	c4 62 69 a9 f1       	vfmadd213ss %xmm1,%xmm2,%xmm14
  1e860e:	c4 42 09 a9 ec       	vfmadd213ss %xmm12,%xmm14,%xmm13
  1e8613:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  1e8618:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  1e861f:	00 
  1e8620:	c5 7a 11 6c 88 0c    	vmovss %xmm13,0xc(%rax,%rcx,4)
  1e8626:	83 bc 24 90 00 00 00 	cmpl   $0x4,0x90(%rsp)
  1e862d:	04 
  1e862e:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
  1e8633:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  1e8638:	0f 84 72 03 00 00    	je     1e89b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1b40>
  1e863e:	83 bc 24 a8 00 00 00 	cmpl   $0x4,0xa8(%rsp)
  1e8645:	04 
  1e8646:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1e864d:	00 
  1e864e:	0f 84 db 3c 00 00    	je     1ec32f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54bf>
  1e8654:	83 7c 24 48 04       	cmpl   $0x4,0x48(%rsp)
  1e8659:	0f 84 b8 3c 00 00    	je     1ec317 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54a7>
  1e865f:	83 bc 24 c0 00 00 00 	cmpl   $0x4,0xc0(%rsp)
  1e8666:	04 
  1e8667:	0f 84 8f 3c 00 00    	je     1ec2fc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x548c>
  1e866d:	c4 41 7a 10 64 85 10 	vmovss 0x10(%r13,%rax,4),%xmm12
  1e8674:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
  1e867b:	00 
  1e867c:	c4 e2 19 b9 64 91 10 	vfmadd231ss 0x10(%rcx,%rdx,4),%xmm12,%xmm4
  1e8683:	4c 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%r13
  1e868a:	00 
  1e868b:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  1e8692:	00 
  1e8693:	c4 c2 19 b9 6c 85 10 	vfmadd231ss 0x10(%r13,%rax,4),%xmm12,%xmm5
  1e869a:	4c 8b 7c 24 58       	mov    0x58(%rsp),%r15
  1e869f:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  1e86a6:	00 
  1e86a7:	c4 c2 19 b9 74 b7 10 	vfmadd231ss 0x10(%r15,%rsi,4),%xmm12,%xmm6
  1e86ae:	48 8b 9c 24 b8 00 00 	mov    0xb8(%rsp),%rbx
  1e86b5:	00 
  1e86b6:	48 89 cf             	mov    %rcx,%rdi
  1e86b9:	4c 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%r9
  1e86c0:	00 
  1e86c1:	c4 22 19 b9 44 8b 10 	vfmadd231ss 0x10(%rbx,%r9,4),%xmm12,%xmm8
  1e86c8:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e86cd:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  1e86d2:	c4 21 7a 10 6c 91 10 	vmovss 0x10(%rcx,%r10,4),%xmm13
  1e86d9:	c4 62 61 a9 e8       	vfmadd213ss %xmm0,%xmm3,%xmm13
  1e86de:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  1e86e3:	4c 8b 94 24 80 00 00 	mov    0x80(%rsp),%r10
  1e86ea:	00 
  1e86eb:	c4 22 19 a9 6c 91 10 	vfmadd213ss 0x10(%rcx,%r10,4),%xmm12,%xmm13
  1e86f2:	4d 89 da             	mov    %r11,%r10
  1e86f5:	c4 41 7a 11 6c ab 10 	vmovss %xmm13,0x10(%r11,%rbp,4)
  1e86fc:	c4 e2 11 b9 7c 97 10 	vfmadd231ss 0x10(%rdi,%rdx,4),%xmm13,%xmm7
  1e8703:	c4 42 11 b9 4c 85 10 	vfmadd231ss 0x10(%r13,%rax,4),%xmm13,%xmm9
  1e870a:	c4 42 11 b9 54 b7 10 	vfmadd231ss 0x10(%r15,%rsi,4),%xmm13,%xmm10
  1e8711:	c4 22 11 b9 5c 8b 10 	vfmadd231ss 0x10(%rbx,%r9,4),%xmm13,%xmm11
  1e8718:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  1e871d:	48 3b 84 24 b0 00 00 	cmp    0xb0(%rsp),%rax
  1e8724:	00 
  1e8725:	73 31                	jae    1e8758 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x18e8>
  1e8727:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e872c:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  1e8731:	c4 21 7a 10 74 91 10 	vmovss 0x10(%rcx,%r10,4),%xmm14
  1e8738:	4d 89 da             	mov    %r11,%r10
  1e873b:	c4 62 69 a9 f1       	vfmadd213ss %xmm1,%xmm2,%xmm14
  1e8740:	c4 42 09 a9 ec       	vfmadd213ss %xmm12,%xmm14,%xmm13
  1e8745:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  1e874a:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  1e8751:	00 
  1e8752:	c5 7a 11 6c 88 10    	vmovss %xmm13,0x10(%rax,%rcx,4)
  1e8758:	83 bc 24 90 00 00 00 	cmpl   $0x5,0x90(%rsp)
  1e875f:	05 
  1e8760:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
  1e8765:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  1e876a:	0f 84 40 02 00 00    	je     1e89b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1b40>
  1e8770:	83 bc 24 a8 00 00 00 	cmpl   $0x5,0xa8(%rsp)
  1e8777:	05 
  1e8778:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1e877f:	00 
  1e8780:	0f 84 a9 3b 00 00    	je     1ec32f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54bf>
  1e8786:	83 7c 24 48 05       	cmpl   $0x5,0x48(%rsp)
  1e878b:	0f 84 86 3b 00 00    	je     1ec317 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54a7>
  1e8791:	83 bc 24 c0 00 00 00 	cmpl   $0x5,0xc0(%rsp)
  1e8798:	05 
  1e8799:	0f 84 5d 3b 00 00    	je     1ec2fc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x548c>
  1e879f:	c4 41 7a 10 64 85 14 	vmovss 0x14(%r13,%rax,4),%xmm12
  1e87a6:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
  1e87ad:	00 
  1e87ae:	c4 e2 19 b9 64 91 14 	vfmadd231ss 0x14(%rcx,%rdx,4),%xmm12,%xmm4
  1e87b5:	4c 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%r13
  1e87bc:	00 
  1e87bd:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  1e87c4:	00 
  1e87c5:	c4 c2 19 b9 6c 85 14 	vfmadd231ss 0x14(%r13,%rax,4),%xmm12,%xmm5
  1e87cc:	4c 8b 7c 24 58       	mov    0x58(%rsp),%r15
  1e87d1:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  1e87d8:	00 
  1e87d9:	c4 c2 19 b9 74 b7 14 	vfmadd231ss 0x14(%r15,%rsi,4),%xmm12,%xmm6
  1e87e0:	48 8b 9c 24 b8 00 00 	mov    0xb8(%rsp),%rbx
  1e87e7:	00 
  1e87e8:	48 89 cf             	mov    %rcx,%rdi
  1e87eb:	4c 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%r9
  1e87f2:	00 
  1e87f3:	c4 22 19 b9 44 8b 14 	vfmadd231ss 0x14(%rbx,%r9,4),%xmm12,%xmm8
  1e87fa:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e87ff:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  1e8804:	c4 21 7a 10 6c 91 14 	vmovss 0x14(%rcx,%r10,4),%xmm13
  1e880b:	c4 62 61 a9 e8       	vfmadd213ss %xmm0,%xmm3,%xmm13
  1e8810:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  1e8815:	4c 8b 94 24 80 00 00 	mov    0x80(%rsp),%r10
  1e881c:	00 
  1e881d:	c4 22 19 a9 6c 91 14 	vfmadd213ss 0x14(%rcx,%r10,4),%xmm12,%xmm13
  1e8824:	4d 89 da             	mov    %r11,%r10
  1e8827:	c4 41 7a 11 6c ab 14 	vmovss %xmm13,0x14(%r11,%rbp,4)
  1e882e:	c4 e2 11 b9 7c 97 14 	vfmadd231ss 0x14(%rdi,%rdx,4),%xmm13,%xmm7
  1e8835:	c4 42 11 b9 4c 85 14 	vfmadd231ss 0x14(%r13,%rax,4),%xmm13,%xmm9
  1e883c:	c4 42 11 b9 54 b7 14 	vfmadd231ss 0x14(%r15,%rsi,4),%xmm13,%xmm10
  1e8843:	c4 22 11 b9 5c 8b 14 	vfmadd231ss 0x14(%rbx,%r9,4),%xmm13,%xmm11
  1e884a:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  1e884f:	48 3b 84 24 b0 00 00 	cmp    0xb0(%rsp),%rax
  1e8856:	00 
  1e8857:	73 31                	jae    1e888a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1a1a>
  1e8859:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e885e:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  1e8863:	c4 21 7a 10 74 91 14 	vmovss 0x14(%rcx,%r10,4),%xmm14
  1e886a:	4d 89 da             	mov    %r11,%r10
  1e886d:	c4 62 69 a9 f1       	vfmadd213ss %xmm1,%xmm2,%xmm14
  1e8872:	c4 42 09 a9 ec       	vfmadd213ss %xmm12,%xmm14,%xmm13
  1e8877:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  1e887c:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  1e8883:	00 
  1e8884:	c5 7a 11 6c 88 14    	vmovss %xmm13,0x14(%rax,%rcx,4)
  1e888a:	83 bc 24 90 00 00 00 	cmpl   $0x6,0x90(%rsp)
  1e8891:	06 
  1e8892:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
  1e8897:	4c 8b 4c 24 78       	mov    0x78(%rsp),%r9
  1e889c:	0f 84 0e 01 00 00    	je     1e89b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1b40>
  1e88a2:	83 bc 24 a8 00 00 00 	cmpl   $0x6,0xa8(%rsp)
  1e88a9:	06 
  1e88aa:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1e88b1:	00 
  1e88b2:	0f 84 77 3a 00 00    	je     1ec32f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54bf>
  1e88b8:	83 7c 24 48 06       	cmpl   $0x6,0x48(%rsp)
  1e88bd:	0f 84 54 3a 00 00    	je     1ec317 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x54a7>
  1e88c3:	83 bc 24 c0 00 00 00 	cmpl   $0x6,0xc0(%rsp)
  1e88ca:	06 
  1e88cb:	0f 84 2b 3a 00 00    	je     1ec2fc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x548c>
  1e88d1:	c4 41 7a 10 64 85 18 	vmovss 0x18(%r13,%rax,4),%xmm12
  1e88d8:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
  1e88df:	00 
  1e88e0:	c4 c2 19 b9 64 89 18 	vfmadd231ss 0x18(%r9,%rcx,4),%xmm12,%xmm4
  1e88e7:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  1e88ee:	00 
  1e88ef:	48 8b 94 24 f0 00 00 	mov    0xf0(%rsp),%rdx
  1e88f6:	00 
  1e88f7:	c4 e2 19 b9 6c 90 18 	vfmadd231ss 0x18(%rax,%rdx,4),%xmm12,%xmm5
  1e88fe:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  1e8903:	4c 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%r15
  1e890a:	00 
  1e890b:	c4 a2 19 b9 74 be 18 	vfmadd231ss 0x18(%rsi,%r15,4),%xmm12,%xmm6
  1e8912:	48 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%rdi
  1e8919:	00 
  1e891a:	4d 89 c8             	mov    %r9,%r8
  1e891d:	4c 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%r9
  1e8924:	00 
  1e8925:	c4 22 19 b9 44 8f 18 	vfmadd231ss 0x18(%rdi,%r9,4),%xmm12,%xmm8
  1e892c:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
  1e8931:	48 8b 5c 24 60       	mov    0x60(%rsp),%rbx
  1e8936:	c4 a2 61 b9 44 9b 18 	vfmadd231ss 0x18(%rbx,%r11,4),%xmm3,%xmm0
  1e893d:	48 8b 5c 24 28       	mov    0x28(%rsp),%rbx
  1e8942:	4c 8b 9c 24 80 00 00 	mov    0x80(%rsp),%r11
  1e8949:	00 
  1e894a:	c4 a2 19 a9 44 9b 18 	vfmadd213ss 0x18(%rbx,%r11,4),%xmm12,%xmm0
  1e8951:	c4 c1 7a 11 44 aa 18 	vmovss %xmm0,0x18(%r10,%rbp,4)
  1e8958:	c4 c2 79 b9 7c 88 18 	vfmadd231ss 0x18(%r8,%rcx,4),%xmm0,%xmm7
  1e895f:	c4 62 79 b9 4c 90 18 	vfmadd231ss 0x18(%rax,%rdx,4),%xmm0,%xmm9
  1e8966:	c4 22 79 b9 54 be 18 	vfmadd231ss 0x18(%rsi,%r15,4),%xmm0,%xmm10
  1e896d:	c4 22 79 b9 5c 8f 18 	vfmadd231ss 0x18(%rdi,%r9,4),%xmm0,%xmm11
  1e8974:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  1e8979:	48 3b 84 24 b0 00 00 	cmp    0xb0(%rsp),%rax
  1e8980:	00 
  1e8981:	73 2d                	jae    1e89b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1b40>
  1e8983:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  1e8988:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e898d:	c4 e2 69 b9 4c 81 18 	vfmadd231ss 0x18(%rcx,%rax,4),%xmm2,%xmm1
  1e8994:	c4 c2 71 a9 c4       	vfmadd213ss %xmm12,%xmm1,%xmm0
  1e8999:	c4 a1 7a 11 44 9b 18 	vmovss %xmm0,0x18(%rbx,%r11,4)
  1e89a0:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
  1e89a5:	48 89 c3             	mov    %rax,%rbx
  1e89a8:	eb 10                	jmp    1e89ba <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1b4a>
  1e89aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  1e89b0:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
  1e89b5:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1e89ba:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  1e89bf:	eb 1c                	jmp    1e89dd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1b6d>
  1e89c1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e89c8:	0f 1f 84 00 00 00 00 
  1e89cf:	00 
  1e89d0:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1e89d5:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  1e89da:	4d 89 da             	mov    %r11,%r10
  1e89dd:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
  1e89e2:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  1e89e7:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  1e89ee:	00 
  1e89ef:	48 8d 3c 00          	lea    (%rax,%rax,1),%rdi
  1e89f3:	48 39 f7             	cmp    %rsi,%rdi
  1e89f6:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
  1e89fb:	0f 83 a5 39 00 00    	jae    1ec3a6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5536>
  1e8a01:	c5 fa 11 24 f9       	vmovss %xmm4,(%rcx,%rdi,8)
  1e8a06:	c5 fa 11 6c f9 04    	vmovss %xmm5,0x4(%rcx,%rdi,8)
  1e8a0c:	48 8d 47 01          	lea    0x1(%rdi),%rax
  1e8a10:	48 39 f0             	cmp    %rsi,%rax
  1e8a13:	73 0b                	jae    1e8a20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1bb0>
  1e8a15:	c5 fa 11 34 c1       	vmovss %xmm6,(%rcx,%rax,8)
  1e8a1a:	c5 7a 11 44 c1 04    	vmovss %xmm8,0x4(%rcx,%rax,8)
  1e8a20:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  1e8a25:	48 8d 04 45 02 00 00 	lea    0x2(,%rax,2),%rax
  1e8a2c:	00 
  1e8a2d:	48 39 f0             	cmp    %rsi,%rax
  1e8a30:	0f 83 80 39 00 00    	jae    1ec3b6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5546>
  1e8a36:	c5 fa 11 7c f9 10    	vmovss %xmm7,0x10(%rcx,%rdi,8)
  1e8a3c:	c5 7a 11 4c f9 14    	vmovss %xmm9,0x14(%rcx,%rdi,8)
  1e8a42:	48 8d 47 03          	lea    0x3(%rdi),%rax
  1e8a46:	48 39 f0             	cmp    %rsi,%rax
  1e8a49:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
  1e8a4e:	0f 83 cc f3 ff ff    	jae    1e7e20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xfb0>
  1e8a54:	c5 7a 11 54 f9 18    	vmovss %xmm10,0x18(%rcx,%rdi,8)
  1e8a5a:	c5 7a 11 5c f9 1c    	vmovss %xmm11,0x1c(%rcx,%rdi,8)
  1e8a60:	e9 bb f3 ff ff       	jmp    1e7e20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xfb0>
  1e8a65:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
  1e8a6a:	4c 8d 49 01          	lea    0x1(%rcx),%r9
  1e8a6e:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
  1e8a73:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  1e8a78:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  1e8a7d:	4d 89 d5             	mov    %r10,%r13
  1e8a80:	4c 89 d9             	mov    %r11,%rcx
  1e8a83:	49 89 ea             	mov    %rbp,%r10
  1e8a86:	4c 8b 9c 24 90 00 00 	mov    0x90(%rsp),%r11
  1e8a8d:	00 
  1e8a8e:	f6 c2 01             	test   $0x1,%dl
  1e8a91:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
  1e8a98:	00 
  1e8a99:	0f 84 f2 00 00 00    	je     1e8b91 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1d21>
  1e8a9f:	48 89 ca             	mov    %rcx,%rdx
  1e8aa2:	48 c1 ea 03          	shr    $0x3,%rdx
  1e8aa6:	48 89 cd             	mov    %rcx,%rbp
  1e8aa9:	0f 84 46 02 00 00    	je     1e8cf5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1e85>
  1e8aaf:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
  1e8ab3:	48 39 84 24 98 00 00 	cmp    %rax,0x98(%rsp)
  1e8aba:	00 
  1e8abb:	0f 86 3a 3b 00 00    	jbe    1ec5fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x578b>
  1e8ac1:	48 85 c0             	test   %rax,%rax
  1e8ac4:	0f 84 44 02 00 00    	je     1e8d0e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1e9e>
  1e8aca:	4d 89 cf             	mov    %r9,%r15
  1e8acd:	4c 89 d1             	mov    %r10,%rcx
  1e8ad0:	48 b8 f8 ff ff ff ff 	movabs $0x1ffffffffffffff8,%rax
  1e8ad7:	ff ff 1f 
  1e8ada:	48 83 c0 06          	add    $0x6,%rax
  1e8ade:	48 21 c2             	and    %rax,%rdx
  1e8ae1:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  1e8ae5:	be 20 00 00 00       	mov    $0x20,%esi
  1e8aea:	31 c0                	xor    %eax,%eax
  1e8aec:	c5 e8 57 d2          	vxorps %xmm2,%xmm2,%xmm2
  1e8af0:	c5 f0 57 c9          	vxorps %xmm1,%xmm1,%xmm1
  1e8af4:	c5 e0 57 db          	vxorps %xmm3,%xmm3,%xmm3
  1e8af8:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
  1e8aff:	00 
  1e8b00:	4c 8b 4c 24 58       	mov    0x58(%rsp),%r9
  1e8b05:	4c 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%r10
  1e8b0c:	00 
  1e8b0d:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
  1e8b12:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e8b19:	1f 84 00 00 00 00 00 
  1e8b20:	c4 c1 7c 10 64 35 e0 	vmovups -0x20(%r13,%rsi,1),%ymm4
  1e8b27:	c4 e2 5d b8 44 33 e0 	vfmadd231ps -0x20(%rbx,%rsi,1),%ymm4,%ymm0
  1e8b2e:	c4 e2 5d b8 54 37 e0 	vfmadd231ps -0x20(%rdi,%rsi,1),%ymm4,%ymm2
  1e8b35:	c4 c2 5d b8 4c 31 e0 	vfmadd231ps -0x20(%r9,%rsi,1),%ymm4,%ymm1
  1e8b3c:	c4 c2 5d b8 5c 32 e0 	vfmadd231ps -0x20(%r10,%rsi,1),%ymm4,%ymm3
  1e8b43:	c4 c1 7c 10 64 35 00 	vmovups 0x0(%r13,%rsi,1),%ymm4
  1e8b4a:	48 83 c0 02          	add    $0x2,%rax
  1e8b4e:	c4 e2 5d b8 04 33    	vfmadd231ps (%rbx,%rsi,1),%ymm4,%ymm0
  1e8b54:	c4 e2 5d b8 14 37    	vfmadd231ps (%rdi,%rsi,1),%ymm4,%ymm2
  1e8b5a:	c4 c2 5d b8 0c 31    	vfmadd231ps (%r9,%rsi,1),%ymm4,%ymm1
  1e8b60:	c4 c2 5d b8 1c 32    	vfmadd231ps (%r10,%rsi,1),%ymm4,%ymm3
  1e8b66:	48 83 c6 40          	add    $0x40,%rsi
  1e8b6a:	48 39 c2             	cmp    %rax,%rdx
  1e8b6d:	75 b1                	jne    1e8b20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1cb0>
  1e8b6f:	40 f6 c5 08          	test   $0x8,%bpl
  1e8b73:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1e8b78:	49 89 ca             	mov    %rcx,%r10
  1e8b7b:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
  1e8b82:	00 
  1e8b83:	4d 89 f9             	mov    %r15,%r9
  1e8b86:	0f 85 94 01 00 00    	jne    1e8d20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1eb0>
  1e8b8c:	e9 cc 01 00 00       	jmp    1e8d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1eed>
  1e8b91:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  1e8b96:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  1e8b9d:	00 
  1e8b9e:	48 8b 6c 24 28       	mov    0x28(%rsp),%rbp
  1e8ba3:	0f b6 84 24 dc 17 00 	movzbl 0x17dc(%rsp),%eax
  1e8baa:	00 
  1e8bab:	3c 02                	cmp    $0x2,%al
  1e8bad:	49 89 cf             	mov    %rcx,%r15
  1e8bb0:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  1e8bb5:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
  1e8bba:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
  1e8bbf:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
  1e8bc4:	4c 89 8c 24 40 01 00 	mov    %r9,0x140(%rsp)
  1e8bcb:	00 
  1e8bcc:	0f 85 0f 01 00 00    	jne    1e8ce1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1e71>
  1e8bd2:	48 c7 84 24 b0 01 00 	movq   $0x1,0x1b0(%rsp)
  1e8bd9:	00 01 00 00 00 
  1e8bde:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  1e8be3:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
  1e8bea:	00 
  1e8beb:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  1e8bf2:	00 
  1e8bf3:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  1e8bfa:	00 
  1e8bfb:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  1e8c02:	00 
  1e8c03:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
  1e8c0a:	00 
  1e8c0b:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  1e8c12:	00 
  1e8c13:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
  1e8c1a:	00 
  1e8c1b:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  1e8c20:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  1e8c27:	00 
  1e8c28:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  1e8c2f:	00 
  1e8c30:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
  1e8c37:	00 
  1e8c38:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  1e8c3f:	00 
  1e8c40:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
  1e8c47:	00 
  1e8c48:	48 8b 84 24 78 01 00 	mov    0x178(%rsp),%rax
  1e8c4f:	00 
  1e8c50:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  1e8c57:	00 
  1e8c58:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  1e8c5c:	48 8d bc 24 b0 01 00 	lea    0x1b0(%rsp),%rdi
  1e8c63:	00 
  1e8c64:	c5 f8 77             	vzeroupper
  1e8c67:	e8 a4 55 07 00       	call   25e210 <<core::iter::adapters::chain::Chain<core::iter::adapters::chain::Chain<core::iter::adapters::chain::Chain<core::slice::iter::Iter<f32>, core::slice::iter::Iter<f32>>, core::slice::iter::Iter<f32>>, core::slice::iter::Iter<f32>> as core::iter::traits::iterator::Iterator>::fold::<f32, <f32 as rustsht::legendre::scalar_paired::analysis::FusedAnalysisPrecision>::prepare_scaled_state::{closure#0}>>
  1e8c6c:	c5 f9 7e c0          	vmovd  %xmm0,%eax
  1e8c70:	c1 e8 17             	shr    $0x17,%eax
  1e8c73:	0f b6 c0             	movzbl %al,%eax
  1e8c76:	83 c0 82             	add    $0xffffff82,%eax
  1e8c79:	c5 f0 57 c9          	vxorps %xmm1,%xmm1,%xmm1
  1e8c7d:	c5 f8 2e c1          	vucomiss %xmm1,%xmm0
  1e8c81:	bb 6b ff ff ff       	mov    $0xffffff6b,%ebx
  1e8c86:	0f 45 d8             	cmovne %eax,%ebx
  1e8c89:	0f 4a d8             	cmovp  %eax,%ebx
  1e8c8c:	ba 18 12 00 00       	mov    $0x1218,%edx
  1e8c91:	48 8d bc 24 c0 05 00 	lea    0x5c0(%rsp),%rdi
  1e8c98:	00 
  1e8c99:	31 f6                	xor    %esi,%esi
  1e8c9b:	ff 15 2f a8 13 00    	call   *0x13a82f(%rip)        # 3234d0 <memset@GLIBC_2.2.5>
  1e8ca1:	89 9c 24 d8 17 00 00 	mov    %ebx,0x17d8(%rsp)
  1e8ca8:	c6 84 24 dc 17 00 00 	movb   $0x0,0x17dc(%rsp)
  1e8caf:	00 
  1e8cb0:	4d 85 f6             	test   %r14,%r14
  1e8cb3:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  1e8cba:	00 
  1e8cbb:	74 4a                	je     1e8d07 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1e97>
  1e8cbd:	49 8b 1c 24          	mov    (%r12),%rbx
  1e8cc1:	49 83 fe 01          	cmp    $0x1,%r14
  1e8cc5:	0f 84 4b 04 00 00    	je     1e9116 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x22a6>
  1e8ccb:	48 83 fa 04          	cmp    $0x4,%rdx
  1e8ccf:	0f 83 d8 02 00 00    	jae    1e8fad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x213d>
  1e8cd5:	31 c0                	xor    %eax,%eax
  1e8cd7:	49 8d 74 24 08       	lea    0x8(%r12),%rsi
  1e8cdc:	e9 1f 04 00 00       	jmp    1e9100 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2290>
  1e8ce1:	3c 01                	cmp    $0x1,%al
  1e8ce3:	75 cb                	jne    1e8cb0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1e40>
  1e8ce5:	4c 39 bc 24 d0 17 00 	cmp    %r15,0x17d0(%rsp)
  1e8cec:	00 
  1e8ced:	0f 84 a2 09 00 00    	je     1e9695 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2825>
  1e8cf3:	eb bb                	jmp    1e8cb0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1e40>
  1e8cf5:	c5 e0 57 db          	vxorps %xmm3,%xmm3,%xmm3
  1e8cf9:	c5 f0 57 c9          	vxorps %xmm1,%xmm1,%xmm1
  1e8cfd:	c5 e8 57 d2          	vxorps %xmm2,%xmm2,%xmm2
  1e8d01:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  1e8d05:	eb 56                	jmp    1e8d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x1eed>
  1e8d07:	31 db                	xor    %ebx,%ebx
  1e8d09:	e9 08 04 00 00       	jmp    1e9116 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x22a6>
  1e8d0e:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  1e8d12:	31 c0                	xor    %eax,%eax
  1e8d14:	c5 e8 57 d2          	vxorps %xmm2,%xmm2,%xmm2
  1e8d18:	c5 f0 57 c9          	vxorps %xmm1,%xmm1,%xmm1
  1e8d1c:	c5 e0 57 db          	vxorps %xmm3,%xmm3,%xmm3
  1e8d20:	48 c1 e0 05          	shl    $0x5,%rax
  1e8d24:	c4 c1 7c 10 64 05 00 	vmovups 0x0(%r13,%rax,1),%ymm4
  1e8d2b:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  1e8d30:	c4 e2 5d b8 04 01    	vfmadd231ps (%rcx,%rax,1),%ymm4,%ymm0
  1e8d36:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
  1e8d3d:	00 
  1e8d3e:	c4 e2 5d b8 14 02    	vfmadd231ps (%rdx,%rax,1),%ymm4,%ymm2
  1e8d44:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
  1e8d49:	c4 e2 5d b8 0c 02    	vfmadd231ps (%rdx,%rax,1),%ymm4,%ymm1
  1e8d4f:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
  1e8d56:	00 
  1e8d57:	c4 e2 5d b8 1c 02    	vfmadd231ps (%rdx,%rax,1),%ymm4,%ymm3
  1e8d5d:	89 ea                	mov    %ebp,%edx
  1e8d5f:	c4 e3 7d 19 c4 01    	vextractf128 $0x1,%ymm0,%xmm4
  1e8d65:	c5 f8 58 c4          	vaddps %xmm4,%xmm0,%xmm0
  1e8d69:	c5 f9 c6 e0 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm4
  1e8d6e:	c5 f8 58 c4          	vaddps %xmm4,%xmm0,%xmm0
  1e8d72:	c5 fa 16 e0          	vmovshdup %xmm0,%xmm4
  1e8d76:	c5 fa 58 c4          	vaddss %xmm4,%xmm0,%xmm0
  1e8d7a:	c4 e3 7d 19 d4 01    	vextractf128 $0x1,%ymm2,%xmm4
  1e8d80:	c5 e8 58 d4          	vaddps %xmm4,%xmm2,%xmm2
  1e8d84:	c5 e9 c6 e2 01       	vshufpd $0x1,%xmm2,%xmm2,%xmm4
  1e8d89:	c5 e8 58 d4          	vaddps %xmm4,%xmm2,%xmm2
  1e8d8d:	c5 fa 16 e2          	vmovshdup %xmm2,%xmm4
  1e8d91:	c5 ea 58 d4          	vaddss %xmm4,%xmm2,%xmm2
  1e8d95:	c4 e3 7d 19 cc 01    	vextractf128 $0x1,%ymm1,%xmm4
  1e8d9b:	c5 f0 58 cc          	vaddps %xmm4,%xmm1,%xmm1
  1e8d9f:	c5 f1 c6 e1 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm4
  1e8da4:	c5 f0 58 cc          	vaddps %xmm4,%xmm1,%xmm1
  1e8da8:	c5 fa 16 e1          	vmovshdup %xmm1,%xmm4
  1e8dac:	c5 f2 58 cc          	vaddss %xmm4,%xmm1,%xmm1
  1e8db0:	c4 e3 7d 19 dc 01    	vextractf128 $0x1,%ymm3,%xmm4
  1e8db6:	c5 e0 58 dc          	vaddps %xmm4,%xmm3,%xmm3
  1e8dba:	c5 e1 c6 e3 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm4
  1e8dbf:	c5 e0 58 dc          	vaddps %xmm4,%xmm3,%xmm3
  1e8dc3:	c5 fa 16 e3          	vmovshdup %xmm3,%xmm4
  1e8dc7:	c5 e2 58 dc          	vaddss %xmm4,%xmm3,%xmm3
  1e8dcb:	b0 01                	mov    $0x1,%al
  1e8dcd:	89 44 24 50          	mov    %eax,0x50(%rsp)
  1e8dd1:	83 e2 07             	and    $0x7,%edx
  1e8dd4:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
  1e8dd9:	0f 84 ad 01 00 00    	je     1e8f8c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x211c>
  1e8ddf:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
  1e8de4:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
  1e8de9:	8d 72 ff             	lea    -0x1(%rdx),%esi
  1e8dec:	39 74 24 48          	cmp    %esi,0x48(%rsp)
  1e8df0:	0f 86 20 38 00 00    	jbe    1ec616 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x57a6>
  1e8df6:	4d 89 cf             	mov    %r9,%r15
  1e8df9:	48 89 ee             	mov    %rbp,%rsi
  1e8dfc:	48 b9 f8 ff ff ff ff 	movabs $0x1ffffffffffffff8,%rcx
  1e8e03:	ff ff 1f 
  1e8e06:	48 21 ce             	and    %rcx,%rsi
  1e8e09:	c4 c1 7a 10 64 b5 00 	vmovss 0x0(%r13,%rsi,4),%xmm4
  1e8e10:	4c 8b 5c 24 78       	mov    0x78(%rsp),%r11
  1e8e15:	c4 c2 59 b9 04 bb    	vfmadd231ss (%r11,%rdi,4),%xmm4,%xmm0
  1e8e1b:	48 89 f9             	mov    %rdi,%rcx
  1e8e1e:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
  1e8e25:	00 
  1e8e26:	48 8b 9c 24 f0 00 00 	mov    0xf0(%rsp),%rbx
  1e8e2d:	00 
  1e8e2e:	c4 e2 59 b9 14 9f    	vfmadd231ss (%rdi,%rbx,4),%xmm4,%xmm2
  1e8e34:	4c 8b 4c 24 58       	mov    0x58(%rsp),%r9
  1e8e39:	48 8b ac 24 e8 00 00 	mov    0xe8(%rsp),%rbp
  1e8e40:	00 
  1e8e41:	c4 c2 59 b9 0c a9    	vfmadd231ss (%r9,%rbp,4),%xmm4,%xmm1
  1e8e47:	4c 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%r10
  1e8e4e:	00 
  1e8e4f:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  1e8e56:	00 
  1e8e57:	c4 c2 59 b9 1c 82    	vfmadd231ss (%r10,%rax,4),%xmm4,%xmm3
  1e8e5d:	83 fa 01             	cmp    $0x1,%edx
  1e8e60:	0f 84 f3 00 00 00    	je     1e8f59 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x20e9>
  1e8e66:	c4 c1 7a 10 64 b5 04 	vmovss 0x4(%r13,%rsi,4),%xmm4
  1e8e6d:	c4 c2 59 b9 44 8b 04 	vfmadd231ss 0x4(%r11,%rcx,4),%xmm4,%xmm0
  1e8e74:	c4 e2 59 b9 54 9f 04 	vfmadd231ss 0x4(%rdi,%rbx,4),%xmm4,%xmm2
  1e8e7b:	c4 c2 59 b9 4c a9 04 	vfmadd231ss 0x4(%r9,%rbp,4),%xmm4,%xmm1
  1e8e82:	c4 c2 59 b9 5c 82 04 	vfmadd231ss 0x4(%r10,%rax,4),%xmm4,%xmm3
  1e8e89:	83 fa 02             	cmp    $0x2,%edx
  1e8e8c:	0f 84 c7 00 00 00    	je     1e8f59 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x20e9>
  1e8e92:	c4 c1 7a 10 64 b5 08 	vmovss 0x8(%r13,%rsi,4),%xmm4
  1e8e99:	c4 c2 59 b9 44 8b 08 	vfmadd231ss 0x8(%r11,%rcx,4),%xmm4,%xmm0
  1e8ea0:	c4 e2 59 b9 54 9f 08 	vfmadd231ss 0x8(%rdi,%rbx,4),%xmm4,%xmm2
  1e8ea7:	c4 c2 59 b9 4c a9 08 	vfmadd231ss 0x8(%r9,%rbp,4),%xmm4,%xmm1
  1e8eae:	c4 c2 59 b9 5c 82 08 	vfmadd231ss 0x8(%r10,%rax,4),%xmm4,%xmm3
  1e8eb5:	83 fa 03             	cmp    $0x3,%edx
  1e8eb8:	0f 84 9b 00 00 00    	je     1e8f59 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x20e9>
  1e8ebe:	c4 c1 7a 10 64 b5 0c 	vmovss 0xc(%r13,%rsi,4),%xmm4
  1e8ec5:	c4 c2 59 b9 44 8b 0c 	vfmadd231ss 0xc(%r11,%rcx,4),%xmm4,%xmm0
  1e8ecc:	c4 e2 59 b9 54 9f 0c 	vfmadd231ss 0xc(%rdi,%rbx,4),%xmm4,%xmm2
  1e8ed3:	c4 c2 59 b9 4c a9 0c 	vfmadd231ss 0xc(%r9,%rbp,4),%xmm4,%xmm1
  1e8eda:	c4 c2 59 b9 5c 82 0c 	vfmadd231ss 0xc(%r10,%rax,4),%xmm4,%xmm3
  1e8ee1:	83 fa 04             	cmp    $0x4,%edx
  1e8ee4:	74 73                	je     1e8f59 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x20e9>
  1e8ee6:	c4 c1 7a 10 64 b5 10 	vmovss 0x10(%r13,%rsi,4),%xmm4
  1e8eed:	c4 c2 59 b9 44 8b 10 	vfmadd231ss 0x10(%r11,%rcx,4),%xmm4,%xmm0
  1e8ef4:	c4 e2 59 b9 54 9f 10 	vfmadd231ss 0x10(%rdi,%rbx,4),%xmm4,%xmm2
  1e8efb:	c4 c2 59 b9 4c a9 10 	vfmadd231ss 0x10(%r9,%rbp,4),%xmm4,%xmm1
  1e8f02:	c4 c2 59 b9 5c 82 10 	vfmadd231ss 0x10(%r10,%rax,4),%xmm4,%xmm3
  1e8f09:	83 fa 05             	cmp    $0x5,%edx
  1e8f0c:	74 4b                	je     1e8f59 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x20e9>
  1e8f0e:	c4 c1 7a 10 64 b5 14 	vmovss 0x14(%r13,%rsi,4),%xmm4
  1e8f15:	c4 c2 59 b9 44 8b 14 	vfmadd231ss 0x14(%r11,%rcx,4),%xmm4,%xmm0
  1e8f1c:	c4 e2 59 b9 54 9f 14 	vfmadd231ss 0x14(%rdi,%rbx,4),%xmm4,%xmm2
  1e8f23:	c4 c2 59 b9 4c a9 14 	vfmadd231ss 0x14(%r9,%rbp,4),%xmm4,%xmm1
  1e8f2a:	c4 c2 59 b9 5c 82 14 	vfmadd231ss 0x14(%r10,%rax,4),%xmm4,%xmm3
  1e8f31:	83 fa 06             	cmp    $0x6,%edx
  1e8f34:	74 23                	je     1e8f59 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x20e9>
  1e8f36:	c4 c1 7a 10 64 b5 18 	vmovss 0x18(%r13,%rsi,4),%xmm4
  1e8f3d:	c4 c2 59 b9 44 8b 18 	vfmadd231ss 0x18(%r11,%rcx,4),%xmm4,%xmm0
  1e8f44:	c4 e2 59 b9 54 9f 18 	vfmadd231ss 0x18(%rdi,%rbx,4),%xmm4,%xmm2
  1e8f4b:	c4 c2 59 b9 4c a9 18 	vfmadd231ss 0x18(%r9,%rbp,4),%xmm4,%xmm1
  1e8f52:	c4 c2 59 b9 5c 82 18 	vfmadd231ss 0x18(%r10,%rax,4),%xmm4,%xmm3
  1e8f59:	48 8b 6c 24 28       	mov    0x28(%rsp),%rbp
  1e8f5e:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  1e8f63:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  1e8f6a:	00 
  1e8f6b:	0f b6 4c 24 0f       	movzbl 0xf(%rsp),%ecx
  1e8f70:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1e8f75:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
  1e8f7a:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
  1e8f7f:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1e8f84:	4d 89 f9             	mov    %r15,%r9
  1e8f87:	e9 eb 17 00 00       	jmp    1ea777 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3907>
  1e8f8c:	48 8b 6c 24 28       	mov    0x28(%rsp),%rbp
  1e8f91:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  1e8f96:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  1e8f9d:	00 
  1e8f9e:	0f b6 4c 24 0f       	movzbl 0xf(%rsp),%ecx
  1e8fa3:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
  1e8fa8:	e9 ca 17 00 00       	jmp    1ea777 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3907>
  1e8fad:	48 83 fa 10          	cmp    $0x10,%rdx
  1e8fb1:	73 0c                	jae    1e8fbf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x214f>
  1e8fb3:	31 c9                	xor    %ecx,%ecx
  1e8fb5:	49 8d 74 24 08       	lea    0x8(%r12),%rsi
  1e8fba:	e9 e0 00 00 00       	jmp    1e909f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x222f>
  1e8fbf:	c4 e1 f9 6e c3       	vmovq  %rbx,%xmm0
  1e8fc4:	c4 e2 7d 59 c0       	vpbroadcastq %xmm0,%ymm0
  1e8fc9:	31 c0                	xor    %eax,%eax
  1e8fcb:	c5 fd 6f d8          	vmovdqa %ymm0,%ymm3
  1e8fcf:	c5 fd 6f d0          	vmovdqa %ymm0,%ymm2
  1e8fd3:	c5 fd 6f c8          	vmovdqa %ymm0,%ymm1
  1e8fd7:	48 8b 94 24 68 01 00 	mov    0x168(%rsp),%rdx
  1e8fde:	00 
  1e8fdf:	c4 c1 7e 6f 64 c4 08 	vmovdqu 0x8(%r12,%rax,8),%ymm4
  1e8fe6:	c4 c1 7e 6f 6c c4 28 	vmovdqu 0x28(%r12,%rax,8),%ymm5
  1e8fed:	c4 c1 7e 6f 74 c4 48 	vmovdqu 0x48(%r12,%rax,8),%ymm6
  1e8ff4:	c4 e2 7d 37 fc       	vpcmpgtq %ymm4,%ymm0,%ymm7
  1e8ff9:	c4 e3 5d 4b c0 70    	vblendvpd %ymm7,%ymm0,%ymm4,%ymm0
  1e8fff:	c4 c1 7e 6f 64 c4 68 	vmovdqu 0x68(%r12,%rax,8),%ymm4
  1e9006:	c4 e2 65 37 fd       	vpcmpgtq %ymm5,%ymm3,%ymm7
  1e900b:	c4 e3 55 4b db 70    	vblendvpd %ymm7,%ymm3,%ymm5,%ymm3
  1e9011:	c4 e2 6d 37 ee       	vpcmpgtq %ymm6,%ymm2,%ymm5
  1e9016:	c4 e3 4d 4b d2 50    	vblendvpd %ymm5,%ymm2,%ymm6,%ymm2
  1e901c:	c4 e2 75 37 ec       	vpcmpgtq %ymm4,%ymm1,%ymm5
  1e9021:	c4 e3 5d 4b c9 50    	vblendvpd %ymm5,%ymm1,%ymm4,%ymm1
  1e9027:	48 83 c0 10          	add    $0x10,%rax
  1e902b:	48 39 c2             	cmp    %rax,%rdx
  1e902e:	75 af                	jne    1e8fdf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x216f>
  1e9030:	c4 e2 7d 37 e3       	vpcmpgtq %ymm3,%ymm0,%ymm4
  1e9035:	c4 e3 65 4b c0 40    	vblendvpd %ymm4,%ymm0,%ymm3,%ymm0
  1e903b:	c4 e2 7d 37 da       	vpcmpgtq %ymm2,%ymm0,%ymm3
  1e9040:	c4 e3 6d 4b c0 30    	vblendvpd %ymm3,%ymm0,%ymm2,%ymm0
  1e9046:	c4 e2 7d 37 d1       	vpcmpgtq %ymm1,%ymm0,%ymm2
  1e904b:	c4 e3 75 4b c0 20    	vblendvpd %ymm2,%ymm0,%ymm1,%ymm0
  1e9051:	c4 e3 7d 19 c1 01    	vextractf128 $0x1,%ymm0,%xmm1
  1e9057:	c4 e2 79 37 d1       	vpcmpgtq %xmm1,%xmm0,%xmm2
  1e905c:	c4 e3 71 4b c0 20    	vblendvpd %xmm2,%xmm0,%xmm1,%xmm0
  1e9062:	c4 e3 f9 16 c3 01    	vpextrq $0x1,%xmm0,%rbx
  1e9068:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  1e906d:	48 39 d8             	cmp    %rbx,%rax
  1e9070:	48 0f 4f d8          	cmovg  %rax,%rbx
  1e9074:	48 39 94 24 20 01 00 	cmp    %rdx,0x120(%rsp)
  1e907b:	00 
  1e907c:	0f 84 94 00 00 00    	je     1e9116 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x22a6>
  1e9082:	48 89 d1             	mov    %rdx,%rcx
  1e9085:	48 89 d0             	mov    %rdx,%rax
  1e9088:	f6 84 24 60 01 00 00 	testb  $0xc,0x160(%rsp)
  1e908f:	0c 
  1e9090:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  1e9097:	00 
  1e9098:	49 8d 74 24 08       	lea    0x8(%r12),%rsi
  1e909d:	74 61                	je     1e9100 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2290>
  1e909f:	c4 e1 f9 6e c3       	vmovq  %rbx,%xmm0
  1e90a4:	c4 e2 7d 59 c0       	vpbroadcastq %xmm0,%ymm0
  1e90a9:	48 8b 94 24 70 01 00 	mov    0x170(%rsp),%rdx
  1e90b0:	00 
  1e90b1:	c5 fe 6f 0c ce       	vmovdqu (%rsi,%rcx,8),%ymm1
  1e90b6:	c4 e2 7d 37 d1       	vpcmpgtq %ymm1,%ymm0,%ymm2
  1e90bb:	c4 e3 75 4b c0 20    	vblendvpd %ymm2,%ymm0,%ymm1,%ymm0
  1e90c1:	48 83 c1 04          	add    $0x4,%rcx
  1e90c5:	48 39 ca             	cmp    %rcx,%rdx
  1e90c8:	75 e7                	jne    1e90b1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2241>
  1e90ca:	c4 e3 7d 19 c1 01    	vextractf128 $0x1,%ymm0,%xmm1
  1e90d0:	c4 e2 79 37 d1       	vpcmpgtq %xmm1,%xmm0,%xmm2
  1e90d5:	c4 e3 71 4b c0 20    	vblendvpd %xmm2,%xmm0,%xmm1,%xmm0
  1e90db:	c4 e3 f9 16 c3 01    	vpextrq $0x1,%xmm0,%rbx
  1e90e1:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  1e90e6:	48 39 d8             	cmp    %rbx,%rax
  1e90e9:	48 0f 4f d8          	cmovg  %rax,%rbx
  1e90ed:	48 89 d0             	mov    %rdx,%rax
  1e90f0:	48 89 d1             	mov    %rdx,%rcx
  1e90f3:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  1e90fa:	00 
  1e90fb:	48 39 ca             	cmp    %rcx,%rdx
  1e90fe:	74 16                	je     1e9116 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x22a6>
  1e9100:	48 89 d9             	mov    %rbx,%rcx
  1e9103:	48 8b 1c c6          	mov    (%rsi,%rax,8),%rbx
  1e9107:	48 39 d9             	cmp    %rbx,%rcx
  1e910a:	48 0f 4f d9          	cmovg  %rcx,%rbx
  1e910e:	48 ff c0             	inc    %rax
  1e9111:	48 39 c2             	cmp    %rax,%rdx
  1e9114:	75 ea                	jne    1e9100 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2290>
  1e9116:	48 89 9c 24 b0 05 00 	mov    %rbx,0x5b0(%rsp)
  1e911d:	00 
  1e911e:	4c 89 fd             	mov    %r15,%rbp
  1e9121:	49 8d 47 ff          	lea    -0x1(%r15),%rax
  1e9125:	f3 48 0f bd c0       	lzcnt  %rax,%rax
  1e912a:	83 c0 16             	add    $0x16,%eax
  1e912d:	49 83 ff 02          	cmp    $0x2,%r15
  1e9131:	b9 56 00 00 00       	mov    $0x56,%ecx
  1e9136:	0f 42 c1             	cmovb  %ecx,%eax
  1e9139:	2b 84 24 d8 17 00 00 	sub    0x17d8(%rsp),%eax
  1e9140:	89 c1                	mov    %eax,%ecx
  1e9142:	c1 f9 1f             	sar    $0x1f,%ecx
  1e9145:	c4 e2 70 f2 c8       	andn   %eax,%ecx,%ecx
  1e914a:	83 f9 4e             	cmp    $0x4e,%ecx
  1e914d:	b8 4e 00 00 00       	mov    $0x4e,%eax
  1e9152:	0f 4d c8             	cmovge %eax,%ecx
  1e9155:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
  1e915a:	48 89 8c 24 b8 05 00 	mov    %rcx,0x5b8(%rsp)
  1e9161:	00 
  1e9162:	ba 00 04 00 00       	mov    $0x400,%edx
  1e9167:	48 8d bc 24 c0 09 00 	lea    0x9c0(%rsp),%rdi
  1e916e:	00 
  1e916f:	31 f6                	xor    %esi,%esi
  1e9171:	c5 f8 77             	vzeroupper
  1e9174:	ff 15 56 a3 13 00    	call   *0x13a356(%rip)        # 3234d0 <memset@GLIBC_2.2.5>
  1e917a:	48 c7 84 24 c0 16 00 	movq   $0x0,0x16c0(%rsp)
  1e9181:	00 00 00 00 00 
  1e9186:	48 c7 84 24 c8 17 00 	movq   $0x0,0x17c8(%rsp)
  1e918d:	00 00 00 00 00 
  1e9192:	49 81 ff 01 01 00 00 	cmp    $0x101,%r15
  1e9199:	0f 83 05 30 00 00    	jae    1ec1a4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5334>
  1e919f:	48 89 e9             	mov    %rbp,%rcx
  1e91a2:	48 c1 e9 03          	shr    $0x3,%rcx
  1e91a6:	c4 41 00 57 ff       	vxorps %xmm15,%xmm15,%xmm15
  1e91ab:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
  1e91b0:	c5 f9 6e 1d 38 ba e3 	vmovd  -0x1c45c8(%rip),%xmm3        # 24bf0 <__abi_tag+0x248f4>
  1e91b7:	ff 
  1e91b8:	c5 f9 6e 25 b8 bd e3 	vmovd  -0x1c4248(%rip),%xmm4        # 24f78 <__abi_tag+0x24c7c>
  1e91bf:	ff 
  1e91c0:	0f 84 a3 04 00 00    	je     1e9669 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x27f9>
  1e91c6:	4c 89 6c 24 50       	mov    %r13,0x50(%rsp)
  1e91cb:	ba 10 08 00 00       	mov    $0x810,%edx
  1e91d0:	be 08 00 00 00       	mov    $0x8,%esi
  1e91d5:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  1e91db:	4d 8d 6c 24 08       	lea    0x8(%r12),%r13
  1e91e0:	48 8d ac 24 c4 05 00 	lea    0x5c4(%rsp),%rbp
  1e91e7:	00 
  1e91e8:	4c 8d 84 24 c0 0d 00 	lea    0xdc0(%rsp),%r8
  1e91ef:	00 
  1e91f0:	31 c0                	xor    %eax,%eax
  1e91f2:	31 ff                	xor    %edi,%edi
  1e91f4:	eb 56                	jmp    1e924c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x23dc>
  1e91f6:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
  1e91fd:	00 
  1e91fe:	48 8b 94 24 08 01 00 	mov    0x108(%rsp),%rdx
  1e9205:	00 
  1e9206:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
  1e920d:	00 
  1e920e:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
  1e9215:	00 
  1e9216:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  1e921d:	00 
  1e921e:	48 ff c9             	dec    %rcx
  1e9221:	48 83 c2 08          	add    $0x8,%rdx
  1e9225:	48 ff c0             	inc    %rax
  1e9228:	4c 8d 04 14          	lea    (%rsp,%rdx,1),%r8
  1e922c:	49 81 c0 b0 05 00 00 	add    $0x5b0,%r8
  1e9233:	48 83 c6 08          	add    $0x8,%rsi
  1e9237:	49 83 c3 08          	add    $0x8,%r11
  1e923b:	48 83 c5 20          	add    $0x20,%rbp
  1e923f:	49 83 c5 40          	add    $0x40,%r13
  1e9243:	48 85 c9             	test   %rcx,%rcx
  1e9246:	0f 84 0e 04 00 00    	je     1e965a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x27ea>
  1e924c:	48 81 fa 10 10 00 00 	cmp    $0x1010,%rdx
  1e9253:	0f 84 01 04 00 00    	je     1e965a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x27ea>
  1e9259:	4c 89 84 24 48 01 00 	mov    %r8,0x148(%rsp)
  1e9260:	00 
  1e9261:	48 89 bc 24 c0 00 00 	mov    %rdi,0xc0(%rsp)
  1e9268:	00 
  1e9269:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  1e9270:	00 
  1e9271:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
  1e9278:	00 
  1e9279:	4d 39 f0             	cmp    %r14,%r8
  1e927c:	0f 83 28 32 00 00    	jae    1ec4aa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x563a>
  1e9282:	48 89 b4 24 a8 00 00 	mov    %rsi,0xa8(%rsp)
  1e9289:	00 
  1e928a:	48 89 94 24 08 01 00 	mov    %rdx,0x108(%rsp)
  1e9291:	00 
  1e9292:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  1e9299:	00 
  1e929a:	4f 8b 0c c4          	mov    (%r12,%r8,8),%r9
  1e929e:	31 c9                	xor    %ecx,%ecx
  1e92a0:	49 39 d9             	cmp    %rbx,%r9
  1e92a3:	0f 99 c1             	setns  %cl
  1e92a6:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
  1e92ad:	ff ff 7f 
  1e92b0:	48 01 d1             	add    %rdx,%rcx
  1e92b3:	4c 89 c8             	mov    %r9,%rax
  1e92b6:	48 29 d8             	sub    %rbx,%rax
  1e92b9:	48 0f 40 c1          	cmovo  %rcx,%rax
  1e92bd:	48 03 44 24 28       	add    0x28(%rsp),%rax
  1e92c2:	48 0f 40 c2          	cmovo  %rdx,%rax
  1e92c6:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
  1e92ca:	48 83 f8 aa          	cmp    $0xffffffffffffffaa,%rax
  1e92ce:	7c 20                	jl     1e92f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2480>
  1e92d0:	c5 f9 6f d3          	vmovdqa %xmm3,%xmm2
  1e92d4:	48 85 c0             	test   %rax,%rax
  1e92d7:	74 17                	je     1e92f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2480>
  1e92d9:	c5 f9 6f d4          	vmovdqa %xmm4,%xmm2
  1e92dd:	48 83 f8 7f          	cmp    $0x7f,%rax
  1e92e1:	7f 0d                	jg     1e92f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2480>
  1e92e3:	c1 e0 17             	shl    $0x17,%eax
  1e92e6:	05 00 00 80 3f       	add    $0x3f800000,%eax
  1e92eb:	c5 f9 6e d0          	vmovd  %eax,%xmm2
  1e92ef:	90                   	nop
  1e92f0:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  1e92f7:	00 
  1e92f8:	48 8d 34 c5 08 00 00 	lea    0x8(,%rax,8),%rsi
  1e92ff:	00 
  1e9300:	49 8d 40 07          	lea    0x7(%r8),%rax
  1e9304:	4c 39 f0             	cmp    %r14,%rax
  1e9307:	0f 83 da 2d 00 00    	jae    1ec0e7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5277>
  1e930d:	4f 39 4c c4 08       	cmp    %r9,0x8(%r12,%r8,8)
  1e9312:	75 7c                	jne    1e9390 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2520>
  1e9314:	4f 39 4c c4 10       	cmp    %r9,0x10(%r12,%r8,8)
  1e9319:	75 75                	jne    1e9390 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2520>
  1e931b:	4f 39 4c c4 18       	cmp    %r9,0x18(%r12,%r8,8)
  1e9320:	75 6e                	jne    1e9390 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2520>
  1e9322:	4f 39 4c c4 20       	cmp    %r9,0x20(%r12,%r8,8)
  1e9327:	75 67                	jne    1e9390 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2520>
  1e9329:	4f 39 4c c4 28       	cmp    %r9,0x28(%r12,%r8,8)
  1e932e:	75 60                	jne    1e9390 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2520>
  1e9330:	4f 39 4c c4 30       	cmp    %r9,0x30(%r12,%r8,8)
  1e9335:	75 59                	jne    1e9390 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2520>
  1e9337:	4f 39 4c c4 38       	cmp    %r9,0x38(%r12,%r8,8)
  1e933c:	75 52                	jne    1e9390 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2520>
  1e933e:	48 3b 74 24 20       	cmp    0x20(%rsp),%rsi
  1e9343:	0f 87 9b 2f 00 00    	ja     1ec2e4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5474>
  1e9349:	48 8d 84 24 c0 05 00 	lea    0x5c0(%rsp),%rax
  1e9350:	00 
  1e9351:	4a 8d 04 80          	lea    (%rax,%r8,4),%rax
  1e9355:	c4 e2 7d 18 c2       	vbroadcastss %xmm2,%ymm0
  1e935a:	48 8b 0d 37 a3 13 00 	mov    0x13a337(%rip),%rcx        # 323698 <_DYNAMIC+0x448>
  1e9361:	48 8b 91 08 08 00 00 	mov    0x808(%rcx),%rdx
  1e9368:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e9371 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2501>
  1e936f:	ff e2                	jmp    *%rdx
  1e9371:	c4 c1 78 2e d7       	vucomiss %xmm15,%xmm2
  1e9376:	0f 85 7a fe ff ff    	jne    1e91f6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2386>
  1e937c:	0f 8b 18 01 00 00    	jnp    1e949a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x262a>
  1e9382:	e9 6f fe ff ff       	jmp    1e91f6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2386>
  1e9387:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  1e938e:	00 00 
  1e9390:	4c 3b 44 24 20       	cmp    0x20(%rsp),%r8
  1e9395:	0f 83 25 31 00 00    	jae    1ec4c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5650>
  1e939b:	c4 a1 79 7e 94 84 c0 	vmovd  %xmm2,0x5c0(%rsp,%r8,4)
  1e93a2:	05 00 00 
  1e93a5:	c5 82 c2 c2 00       	vcmpeqss %xmm2,%xmm15,%xmm0
  1e93aa:	c5 f9 7e c6          	vmovd  %xmm0,%esi
  1e93ae:	83 e6 01             	and    $0x1,%esi
  1e93b1:	31 c9                	xor    %ecx,%ecx
  1e93b3:	eb 24                	jmp    1e93d9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2569>
  1e93b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  1e93bc:	00 00 00 00 
  1e93c0:	4d 39 ca             	cmp    %r9,%r10
  1e93c3:	4d 0f 4f ca          	cmovg  %r10,%r9
  1e93c7:	be 01 00 00 00       	mov    $0x1,%esi
  1e93cc:	48 ff c1             	inc    %rcx
  1e93cf:	48 83 f9 07          	cmp    $0x7,%rcx
  1e93d3:	0f 84 b7 00 00 00    	je     1e9490 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2620>
  1e93d9:	49 8d 04 0b          	lea    (%r11,%rcx,1),%rax
  1e93dd:	4c 39 f0             	cmp    %r14,%rax
  1e93e0:	0f 83 48 2e 00 00    	jae    1ec22e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x53be>
  1e93e6:	4d 8b 54 cd 00       	mov    0x0(%r13,%rcx,8),%r10
  1e93eb:	31 d2                	xor    %edx,%edx
  1e93ed:	49 39 da             	cmp    %rbx,%r10
  1e93f0:	0f 99 c2             	setns  %dl
  1e93f3:	49 bf ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r15
  1e93fa:	ff ff 7f 
  1e93fd:	4c 01 fa             	add    %r15,%rdx
  1e9400:	4c 89 d7             	mov    %r10,%rdi
  1e9403:	48 29 df             	sub    %rbx,%rdi
  1e9406:	48 0f 40 fa          	cmovo  %rdx,%rdi
  1e940a:	48 03 7c 24 28       	add    0x28(%rsp),%rdi
  1e940f:	49 0f 40 ff          	cmovo  %r15,%rdi
  1e9413:	48 83 ff aa          	cmp    $0xffffffffffffffaa,%rdi
  1e9417:	7d 17                	jge    1e9430 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x25c0>
  1e9419:	48 3b 44 24 20       	cmp    0x20(%rsp),%rax
  1e941e:	0f 83 f2 2d 00 00    	jae    1ec216 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x53a6>
  1e9424:	c7 44 8d 00 00 00 00 	movl   $0x0,0x0(%rbp,%rcx,4)
  1e942b:	00 
  1e942c:	eb 44                	jmp    1e9472 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2602>
  1e942e:	66 90                	xchg   %ax,%ax
  1e9430:	c5 f9 6f c3          	vmovdqa %xmm3,%xmm0
  1e9434:	48 85 ff             	test   %rdi,%rdi
  1e9437:	74 17                	je     1e9450 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x25e0>
  1e9439:	c5 f9 6f c4          	vmovdqa %xmm4,%xmm0
  1e943d:	48 83 ff 7f          	cmp    $0x7f,%rdi
  1e9441:	7f 0d                	jg     1e9450 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x25e0>
  1e9443:	c1 e7 17             	shl    $0x17,%edi
  1e9446:	81 c7 00 00 80 3f    	add    $0x3f800000,%edi
  1e944c:	c5 f9 6e c7          	vmovd  %edi,%xmm0
  1e9450:	48 3b 44 24 20       	cmp    0x20(%rsp),%rax
  1e9455:	0f 83 bb 2d 00 00    	jae    1ec216 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x53a6>
  1e945b:	c5 f9 7e 44 8d 00    	vmovd  %xmm0,0x0(%rbp,%rcx,4)
  1e9461:	c4 c1 78 2e c7       	vucomiss %xmm15,%xmm0
  1e9466:	0f 85 60 ff ff ff    	jne    1e93cc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x255c>
  1e946c:	0f 8a 5a ff ff ff    	jp     1e93cc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x255c>
  1e9472:	48 83 fe 01          	cmp    $0x1,%rsi
  1e9476:	0f 84 44 ff ff ff    	je     1e93c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2550>
  1e947c:	be 01 00 00 00       	mov    $0x1,%esi
  1e9481:	4d 89 d1             	mov    %r10,%r9
  1e9484:	e9 43 ff ff ff       	jmp    1e93cc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x255c>
  1e9489:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  1e9490:	40 f6 c6 01          	test   $0x1,%sil
  1e9494:	0f 84 5c fd ff ff    	je     1e91f6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2386>
  1e949a:	31 c0                	xor    %eax,%eax
  1e949c:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  1e94a1:	49 39 d1             	cmp    %rdx,%r9
  1e94a4:	0f 99 c0             	setns  %al
  1e94a7:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
  1e94ae:	ff ff 7f 
  1e94b1:	48 01 c8             	add    %rcx,%rax
  1e94b4:	4c 89 c9             	mov    %r9,%rcx
  1e94b7:	48 29 d1             	sub    %rdx,%rcx
  1e94ba:	48 0f 40 c8          	cmovo  %rax,%rcx
  1e94be:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  1e94c5:	00 
  1e94c6:	48 89 08             	mov    %rcx,(%rax)
  1e94c9:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
  1e94d0:	00 
  1e94d1:	49 39 f0             	cmp    %rsi,%r8
  1e94d4:	0f 83 56 01 00 00    	jae    1e9630 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x27c0>
  1e94da:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  1e94df:	49 39 c8             	cmp    %rcx,%r8
  1e94e2:	49 0f 47 c8          	cmova  %r8,%rcx
  1e94e6:	48 8b 84 24 c0 16 00 	mov    0x16c0(%rsp),%rax
  1e94ed:	00 
  1e94ee:	45 31 d2             	xor    %r10d,%r10d
  1e94f1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e94f8:	0f 1f 84 00 00 00 00 
  1e94ff:	00 
  1e9500:	4c 39 c1             	cmp    %r8,%rcx
  1e9503:	0f 84 ab 2d 00 00    	je     1ec2b4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5444>
  1e9509:	49 8d 78 01          	lea    0x1(%r8),%rdi
  1e950d:	c4 a1 7a 10 84 84 c0 	vmovss 0x5c0(%rsp,%r8,4),%xmm0
  1e9514:	05 00 00 
  1e9517:	c4 c1 78 2e c7       	vucomiss %xmm15,%xmm0
  1e951c:	75 02                	jne    1e9520 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x26b0>
  1e951e:	7b 0d                	jnp    1e952d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x26bd>
  1e9520:	49 89 f8             	mov    %rdi,%r8
  1e9523:	48 39 fe             	cmp    %rdi,%rsi
  1e9526:	75 d8                	jne    1e9500 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2690>
  1e9528:	e9 b1 00 00 00       	jmp    1e95de <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x276e>
  1e952d:	4d 39 f0             	cmp    %r14,%r8
  1e9530:	0f 83 3f 30 00 00    	jae    1ec575 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5705>
  1e9536:	4b 8b 0c c4          	mov    (%r12,%r8,8),%rcx
  1e953a:	31 d2                	xor    %edx,%edx
  1e953c:	4c 39 c9             	cmp    %r9,%rcx
  1e953f:	0f 99 c2             	setns  %dl
  1e9542:	48 be ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rsi
  1e9549:	ff ff 7f 
  1e954c:	48 01 f2             	add    %rsi,%rdx
  1e954f:	4c 29 c9             	sub    %r9,%rcx
  1e9552:	48 0f 40 ca          	cmovo  %rdx,%rcx
  1e9556:	48 03 4c 24 28       	add    0x28(%rsp),%rcx
  1e955b:	48 0f 40 ce          	cmovo  %rsi,%rcx
  1e955f:	48 83 f9 d2          	cmp    $0xffffffffffffffd2,%rcx
  1e9563:	7e 1d                	jle    1e9582 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2712>
  1e9565:	48 85 c9             	test   %rcx,%rcx
  1e9568:	74 41                	je     1e95ab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x273b>
  1e956a:	be 00 00 80 7f       	mov    $0x7f800000,%esi
  1e956f:	48 83 f9 7f          	cmp    $0x7f,%rcx
  1e9573:	7f 3b                	jg     1e95b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2740>
  1e9575:	c1 e1 17             	shl    $0x17,%ecx
  1e9578:	81 c1 00 00 80 3f    	add    $0x3f800000,%ecx
  1e957e:	89 ce                	mov    %ecx,%esi
  1e9580:	eb 2e                	jmp    1e95b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2740>
  1e9582:	48 3d 00 01 00 00    	cmp    $0x100,%rax
  1e9588:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
  1e958f:	00 
  1e9590:	0f 83 20 30 00 00    	jae    1ec5b6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5746>
  1e9596:	44 88 84 04 c0 15 00 	mov    %r8b,0x15c0(%rsp,%rax,1)
  1e959d:	00 
  1e959e:	48 ff c0             	inc    %rax
  1e95a1:	48 89 84 24 c0 16 00 	mov    %rax,0x16c0(%rsp)
  1e95a8:	00 
  1e95a9:	eb 17                	jmp    1e95c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2752>
  1e95ab:	be 00 00 80 3f       	mov    $0x3f800000,%esi
  1e95b0:	89 b4 bc bc 09 00 00 	mov    %esi,0x9bc(%rsp,%rdi,4)
  1e95b7:	41 b2 01             	mov    $0x1,%r10b
  1e95ba:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
  1e95c1:	00 
  1e95c2:	49 ff c0             	inc    %r8
  1e95c5:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  1e95ca:	49 39 c8             	cmp    %rcx,%r8
  1e95cd:	49 0f 47 c8          	cmova  %r8,%rcx
  1e95d1:	49 39 f0             	cmp    %rsi,%r8
  1e95d4:	49 0f 47 f0          	cmova  %r8,%rsi
  1e95d8:	0f 82 22 ff ff ff    	jb     1e9500 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2690>
  1e95de:	41 f6 c2 01          	test   $0x1,%r10b
  1e95e2:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
  1e95e9:	00 
  1e95ea:	48 8b 94 24 08 01 00 	mov    0x108(%rsp),%rdx
  1e95f1:	00 
  1e95f2:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  1e95f9:	00 
  1e95fa:	74 49                	je     1e9645 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x27d5>
  1e95fc:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
  1e9603:	00 
  1e9604:	48 81 ff ff 00 00 00 	cmp    $0xff,%rdi
  1e960b:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
  1e9612:	00 
  1e9613:	0f 87 b5 2f 00 00    	ja     1ec5ce <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x575e>
  1e9619:	88 84 3c c8 16 00 00 	mov    %al,0x16c8(%rsp,%rdi,1)
  1e9620:	48 ff c7             	inc    %rdi
  1e9623:	48 89 bc 24 c8 17 00 	mov    %rdi,0x17c8(%rsp)
  1e962a:	00 
  1e962b:	e9 ee fb ff ff       	jmp    1e921e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x23ae>
  1e9630:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
  1e9637:	00 
  1e9638:	48 8b 94 24 08 01 00 	mov    0x108(%rsp),%rdx
  1e963f:	00 
  1e9640:	e9 c9 fb ff ff       	jmp    1e920e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x239e>
  1e9645:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
  1e964c:	00 
  1e964d:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
  1e9654:	00 
  1e9655:	e9 c4 fb ff ff       	jmp    1e921e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x23ae>
  1e965a:	48 8b bc 24 c0 16 00 	mov    0x16c0(%rsp),%rdi
  1e9661:	00 
  1e9662:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
  1e9667:	eb 02                	jmp    1e966b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x27fb>
  1e9669:	31 ff                	xor    %edi,%edi
  1e966b:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  1e9670:	89 c8                	mov    %ecx,%eax
  1e9672:	25 f8 01 00 00       	and    $0x1f8,%eax
  1e9677:	48 39 c8             	cmp    %rcx,%rax
  1e967a:	0f 85 cc 01 00 00    	jne    1e984c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x29dc>
  1e9680:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  1e9685:	48 89 84 24 d0 17 00 	mov    %rax,0x17d0(%rsp)
  1e968c:	00 
  1e968d:	c6 84 24 dc 17 00 00 	movb   $0x1,0x17dc(%rsp)
  1e9694:	01 
  1e9695:	48 8b 84 24 c0 16 00 	mov    0x16c0(%rsp),%rax
  1e969c:	00 
  1e969d:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
  1e96a4:	00 
  1e96a5:	48 85 c0             	test   %rax,%rax
  1e96a8:	48 8b b4 24 18 01 00 	mov    0x118(%rsp),%rsi
  1e96af:	00 
  1e96b0:	0f 84 2d 02 00 00    	je     1e98e3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2a73>
  1e96b6:	c4 41 30 57 c9       	vxorps %xmm9,%xmm9,%xmm9
  1e96bb:	31 ed                	xor    %ebp,%ebp
  1e96bd:	c4 41 29 ef d2       	vpxor  %xmm10,%xmm10,%xmm10
  1e96c2:	c4 41 21 ef db       	vpxor  %xmm11,%xmm11,%xmm11
  1e96c7:	c4 41 18 57 e4       	vxorps %xmm12,%xmm12,%xmm12
  1e96cc:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
  1e96d3:	00 
  1e96d4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e96db:	00 00 00 00 00 
  1e96e0:	48 81 fd 00 01 00 00 	cmp    $0x100,%rbp
  1e96e7:	0f 84 12 02 00 00    	je     1e98ff <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2a8f>
  1e96ed:	0f b6 9c 2c c0 15 00 	movzbl 0x15c0(%rsp,%rbp,1),%ebx
  1e96f4:	00 
  1e96f5:	48 39 de             	cmp    %rbx,%rsi
  1e96f8:	0f 86 f9 2c 00 00    	jbe    1ec3f7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5587>
  1e96fe:	48 39 9c 24 38 01 00 	cmp    %rbx,0x138(%rsp)
  1e9705:	00 
  1e9706:	0f 86 fe 2c 00 00    	jbe    1ec40a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x559a>
  1e970c:	48 39 5c 24 20       	cmp    %rbx,0x20(%rsp)
  1e9711:	0f 86 0e 2d 00 00    	jbe    1ec425 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x55b5>
  1e9717:	c5 7a 11 a4 24 a8 00 	vmovss %xmm12,0xa8(%rsp)
  1e971e:	00 00 
  1e9720:	c5 79 7e 9c 24 80 00 	vmovd  %xmm11,0x80(%rsp)
  1e9727:	00 00 
  1e9729:	c5 79 7e 54 24 50    	vmovd  %xmm10,0x50(%rsp)
  1e972f:	c5 7a 11 4c 24 28    	vmovss %xmm9,0x28(%rsp)
  1e9735:	49 39 de             	cmp    %rbx,%r14
  1e9738:	0f 86 ff 2c 00 00    	jbe    1ec43d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x55cd>
  1e973e:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  1e9743:	c5 fa 10 04 98       	vmovss (%rax,%rbx,4),%xmm0
  1e9748:	c5 fa 10 0c 9f       	vmovss (%rdi,%rbx,4),%xmm1
  1e974d:	4d 89 ef             	mov    %r13,%r15
  1e9750:	c4 c1 7a 10 54 9d 00 	vmovss 0x0(%r13,%rbx,4),%xmm2
  1e9757:	4d 8b 2c dc          	mov    (%r12,%rbx,8),%r13
  1e975b:	c5 fa 11 94 24 c0 00 	vmovss %xmm2,0xc0(%rsp)
  1e9762:	00 00 
  1e9764:	4c 89 ef             	mov    %r13,%rdi
  1e9767:	c5 f8 77             	vzeroupper
  1e976a:	ff 15 e8 a4 13 00    	call   *0x13a4e8(%rip)        # 323c58 <_DYNAMIC+0xa08>
  1e9770:	48 39 9c 24 30 01 00 	cmp    %rbx,0x130(%rsp)
  1e9777:	00 
  1e9778:	0f 86 61 2c 00 00    	jbe    1ec3df <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x556f>
  1e977e:	c5 fa 11 8c 24 08 01 	vmovss %xmm1,0x108(%rsp)
  1e9785:	00 00 
  1e9787:	c5 fa 11 84 24 c8 00 	vmovss %xmm0,0xc8(%rsp)
  1e978e:	00 00 
  1e9790:	48 39 9c 24 28 01 00 	cmp    %rbx,0x128(%rsp)
  1e9797:	00 
  1e9798:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  1e979f:	00 
  1e97a0:	0f 86 ad 2c 00 00    	jbe    1ec453 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x55e3>
  1e97a6:	c1 e3 02             	shl    $0x2,%ebx
  1e97a9:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  1e97ae:	c5 fa 10 04 18       	vmovss (%rax,%rbx,1),%xmm0
  1e97b3:	c5 fa 10 0c 19       	vmovss (%rcx,%rbx,1),%xmm1
  1e97b8:	c5 fa 10 94 24 c0 00 	vmovss 0xc0(%rsp),%xmm2
  1e97bf:	00 00 
  1e97c1:	4c 89 ef             	mov    %r13,%rdi
  1e97c4:	ff 15 8e a4 13 00    	call   *0x13a48e(%rip)        # 323c58 <_DYNAMIC+0xa08>
  1e97ca:	c5 7a 10 a4 24 a8 00 	vmovss 0xa8(%rsp),%xmm12
  1e97d1:	00 00 
  1e97d3:	c5 1a 58 a4 24 c8 00 	vaddss 0xc8(%rsp),%xmm12,%xmm12
  1e97da:	00 00 
  1e97dc:	c5 7a 10 9c 24 80 00 	vmovss 0x80(%rsp),%xmm11
  1e97e3:	00 00 
  1e97e5:	c5 22 58 9c 24 08 01 	vaddss 0x108(%rsp),%xmm11,%xmm11
  1e97ec:	00 00 
  1e97ee:	c5 7a 10 54 24 50    	vmovss 0x50(%rsp),%xmm10
  1e97f4:	c5 2a 58 d0          	vaddss %xmm0,%xmm10,%xmm10
  1e97f8:	c5 7a 10 4c 24 28    	vmovss 0x28(%rsp),%xmm9
  1e97fe:	c5 32 58 c9          	vaddss %xmm1,%xmm9,%xmm9
  1e9802:	48 ff c5             	inc    %rbp
  1e9805:	48 39 ac 24 48 01 00 	cmp    %rbp,0x148(%rsp)
  1e980c:	00 
  1e980d:	48 8b b4 24 18 01 00 	mov    0x118(%rsp),%rsi
  1e9814:	00 
  1e9815:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
  1e981c:	00 
  1e981d:	4d 89 fd             	mov    %r15,%r13
  1e9820:	c4 41 00 57 ff       	vxorps %xmm15,%xmm15,%xmm15
  1e9825:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
  1e982a:	0f 85 b0 fe ff ff    	jne    1e96e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2870>
  1e9830:	e9 ca 00 00 00       	jmp    1e98ff <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2a8f>
  1e9835:	c5 f9 7e 84 84 c0 05 	vmovd  %xmm0,0x5c0(%rsp,%rax,4)
  1e983c:	00 00 
  1e983e:	48 ff c0             	inc    %rax
  1e9841:	48 3b 44 24 20       	cmp    0x20(%rsp),%rax
  1e9846:	0f 83 34 fe ff ff    	jae    1e9680 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2810>
  1e984c:	4c 39 f0             	cmp    %r14,%rax
  1e984f:	0f 83 74 2b 00 00    	jae    1ec3c9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5559>
  1e9855:	49 8b 0c c4          	mov    (%r12,%rax,8),%rcx
  1e9859:	31 d2                	xor    %edx,%edx
  1e985b:	48 39 d9             	cmp    %rbx,%rcx
  1e985e:	0f 99 c2             	setns  %dl
  1e9861:	48 be ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rsi
  1e9868:	ff ff 7f 
  1e986b:	48 01 f2             	add    %rsi,%rdx
  1e986e:	48 29 d9             	sub    %rbx,%rcx
  1e9871:	48 0f 40 ca          	cmovo  %rdx,%rcx
  1e9875:	48 03 4c 24 28       	add    0x28(%rsp),%rcx
  1e987a:	48 0f 40 ce          	cmovo  %rsi,%rcx
  1e987e:	48 83 f9 aa          	cmp    $0xffffffffffffffaa,%rcx
  1e9882:	7d 2c                	jge    1e98b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2a40>
  1e9884:	c7 84 84 c0 05 00 00 	movl   $0x0,0x5c0(%rsp,%rax,4)
  1e988b:	00 00 00 00 
  1e988f:	48 81 ff 00 01 00 00 	cmp    $0x100,%rdi
  1e9896:	0f 83 3c 2c 00 00    	jae    1ec4d8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5668>
  1e989c:	88 84 3c c0 15 00 00 	mov    %al,0x15c0(%rsp,%rdi,1)
  1e98a3:	48 ff c7             	inc    %rdi
  1e98a6:	48 89 bc 24 c0 16 00 	mov    %rdi,0x16c0(%rsp)
  1e98ad:	00 
  1e98ae:	eb 8e                	jmp    1e983e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x29ce>
  1e98b0:	c5 f9 6f c3          	vmovdqa %xmm3,%xmm0
  1e98b4:	48 85 c9             	test   %rcx,%rcx
  1e98b7:	0f 84 78 ff ff ff    	je     1e9835 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x29c5>
  1e98bd:	c5 f9 6f c4          	vmovdqa %xmm4,%xmm0
  1e98c1:	48 81 f9 80 00 00 00 	cmp    $0x80,%rcx
  1e98c8:	0f 8d 67 ff ff ff    	jge    1e9835 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x29c5>
  1e98ce:	c1 e1 17             	shl    $0x17,%ecx
  1e98d1:	81 c1 00 00 80 3f    	add    $0x3f800000,%ecx
  1e98d7:	89 8c 84 c0 05 00 00 	mov    %ecx,0x5c0(%rsp,%rax,4)
  1e98de:	e9 5b ff ff ff       	jmp    1e983e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x29ce>
  1e98e3:	c4 41 18 57 e4       	vxorps %xmm12,%xmm12,%xmm12
  1e98e8:	c4 41 21 ef db       	vpxor  %xmm11,%xmm11,%xmm11
  1e98ed:	c4 41 29 ef d2       	vpxor  %xmm10,%xmm10,%xmm10
  1e98f2:	c4 41 30 57 c9       	vxorps %xmm9,%xmm9,%xmm9
  1e98f7:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
  1e98fe:	00 
  1e98ff:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1e9904:	48 81 fe 01 01 00 00 	cmp    $0x101,%rsi
  1e990b:	0f 83 6a 28 00 00    	jae    1ec17b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x530b>
  1e9911:	48 c1 ee 03          	shr    $0x3,%rsi
  1e9915:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
  1e991a:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
  1e991f:	4c 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%r8
  1e9926:	00 
  1e9927:	0f 84 ae 00 00 00    	je     1e99db <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2b6b>
  1e992d:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
  1e9931:	48 39 84 24 98 00 00 	cmp    %rax,0x98(%rsp)
  1e9938:	00 
  1e9939:	0f 86 ef 2c 00 00    	jbe    1ec62e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x57be>
  1e993f:	48 85 c0             	test   %rax,%rax
  1e9942:	0f 84 a5 00 00 00    	je     1e99ed <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2b7d>
  1e9948:	89 f1                	mov    %esi,%ecx
  1e994a:	83 e1 3e             	and    $0x3e,%ecx
  1e994d:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  1e9951:	ba 20 00 00 00       	mov    $0x20,%edx
  1e9956:	31 c0                	xor    %eax,%eax
  1e9958:	c5 f0 57 c9          	vxorps %xmm1,%xmm1,%xmm1
  1e995c:	c5 e8 57 d2          	vxorps %xmm2,%xmm2,%xmm2
  1e9960:	c5 e0 57 db          	vxorps %xmm3,%xmm3,%xmm3
  1e9964:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e996b:	00 00 00 00 00 
  1e9970:	c4 c1 7c 10 64 15 e0 	vmovups -0x20(%r13,%rdx,1),%ymm4
  1e9977:	c4 c1 7c 10 6c 15 00 	vmovups 0x0(%r13,%rdx,1),%ymm5
  1e997e:	c5 dc 59 a4 14 a0 05 	vmulps 0x5a0(%rsp,%rdx,1),%ymm4,%ymm4
  1e9985:	00 00 
  1e9987:	c4 e2 5d b8 5c 15 e0 	vfmadd231ps -0x20(%rbp,%rdx,1),%ymm4,%ymm3
  1e998e:	c4 e2 5d b8 54 17 e0 	vfmadd231ps -0x20(%rdi,%rdx,1),%ymm4,%ymm2
  1e9995:	c4 e2 5d b8 4c 13 e0 	vfmadd231ps -0x20(%rbx,%rdx,1),%ymm4,%ymm1
  1e999c:	c4 c2 5d b8 44 10 e0 	vfmadd231ps -0x20(%r8,%rdx,1),%ymm4,%ymm0
  1e99a3:	c5 d4 59 a4 14 c0 05 	vmulps 0x5c0(%rsp,%rdx,1),%ymm5,%ymm4
  1e99aa:	00 00 
  1e99ac:	48 83 c0 02          	add    $0x2,%rax
  1e99b0:	c4 e2 5d b8 5c 15 00 	vfmadd231ps 0x0(%rbp,%rdx,1),%ymm4,%ymm3
  1e99b7:	c4 e2 5d b8 14 17    	vfmadd231ps (%rdi,%rdx,1),%ymm4,%ymm2
  1e99bd:	c4 e2 5d b8 0c 13    	vfmadd231ps (%rbx,%rdx,1),%ymm4,%ymm1
  1e99c3:	c4 c2 5d b8 04 10    	vfmadd231ps (%r8,%rdx,1),%ymm4,%ymm0
  1e99c9:	48 83 c2 40          	add    $0x40,%rdx
  1e99cd:	48 39 c1             	cmp    %rax,%rcx
  1e99d0:	75 9e                	jne    1e9970 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2b00>
  1e99d2:	f6 44 24 20 08       	testb  $0x8,0x20(%rsp)
  1e99d7:	75 26                	jne    1e99ff <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2b8f>
  1e99d9:	eb 55                	jmp    1e9a30 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2bc0>
  1e99db:	c5 e0 57 db          	vxorps %xmm3,%xmm3,%xmm3
  1e99df:	c5 e8 57 d2          	vxorps %xmm2,%xmm2,%xmm2
  1e99e3:	c5 f0 57 c9          	vxorps %xmm1,%xmm1,%xmm1
  1e99e7:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  1e99eb:	eb 43                	jmp    1e9a30 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2bc0>
  1e99ed:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
  1e99f1:	31 c0                	xor    %eax,%eax
  1e99f3:	c5 f0 57 c9          	vxorps %xmm1,%xmm1,%xmm1
  1e99f7:	c5 e8 57 d2          	vxorps %xmm2,%xmm2,%xmm2
  1e99fb:	c5 e0 57 db          	vxorps %xmm3,%xmm3,%xmm3
  1e99ff:	48 c1 e0 05          	shl    $0x5,%rax
  1e9a03:	c4 c1 7c 10 64 05 00 	vmovups 0x0(%r13,%rax,1),%ymm4
  1e9a0a:	48 8d 8c 24 c0 05 00 	lea    0x5c0(%rsp),%rcx
  1e9a11:	00 
  1e9a12:	c5 dc 59 24 01       	vmulps (%rcx,%rax,1),%ymm4,%ymm4
  1e9a17:	c4 e2 5d b8 5c 05 00 	vfmadd231ps 0x0(%rbp,%rax,1),%ymm4,%ymm3
  1e9a1e:	c4 e2 5d b8 14 07    	vfmadd231ps (%rdi,%rax,1),%ymm4,%ymm2
  1e9a24:	c4 e2 5d b8 0c 03    	vfmadd231ps (%rbx,%rax,1),%ymm4,%ymm1
  1e9a2a:	c4 c2 5d b8 04 00    	vfmadd231ps (%r8,%rax,1),%ymm4,%ymm0
  1e9a30:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  1e9a35:	c4 e3 7d 19 dc 01    	vextractf128 $0x1,%ymm3,%xmm4
  1e9a3b:	c5 e0 58 dc          	vaddps %xmm4,%xmm3,%xmm3
  1e9a3f:	c5 e1 c6 e3 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm4
  1e9a44:	c5 e0 58 dc          	vaddps %xmm4,%xmm3,%xmm3
  1e9a48:	c5 fa 16 e3          	vmovshdup %xmm3,%xmm4
  1e9a4c:	c5 e2 58 dc          	vaddss %xmm4,%xmm3,%xmm3
  1e9a50:	c4 e3 7d 19 d4 01    	vextractf128 $0x1,%ymm2,%xmm4
  1e9a56:	c5 e8 58 d4          	vaddps %xmm4,%xmm2,%xmm2
  1e9a5a:	c5 e9 c6 e2 01       	vshufpd $0x1,%xmm2,%xmm2,%xmm4
  1e9a5f:	c5 e8 58 d4          	vaddps %xmm4,%xmm2,%xmm2
  1e9a63:	c5 fa 16 e2          	vmovshdup %xmm2,%xmm4
  1e9a67:	c5 ea 58 d4          	vaddss %xmm4,%xmm2,%xmm2
  1e9a6b:	c4 e3 7d 19 cc 01    	vextractf128 $0x1,%ymm1,%xmm4
  1e9a71:	c5 f0 58 cc          	vaddps %xmm4,%xmm1,%xmm1
  1e9a75:	c5 f1 c6 e1 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm4
  1e9a7a:	c5 f0 58 cc          	vaddps %xmm4,%xmm1,%xmm1
  1e9a7e:	c5 fa 16 e1          	vmovshdup %xmm1,%xmm4
  1e9a82:	c5 f2 58 cc          	vaddss %xmm4,%xmm1,%xmm1
  1e9a86:	c4 e3 7d 19 c4 01    	vextractf128 $0x1,%ymm0,%xmm4
  1e9a8c:	c5 f8 58 c4          	vaddps %xmm4,%xmm0,%xmm0
  1e9a90:	c5 f9 c6 e0 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm4
  1e9a95:	c5 f8 58 c4          	vaddps %xmm4,%xmm0,%xmm0
  1e9a99:	c5 fa 16 e0          	vmovshdup %xmm0,%xmm4
  1e9a9d:	c5 fa 58 c4          	vaddss %xmm4,%xmm0,%xmm0
  1e9aa1:	83 e0 07             	and    $0x7,%eax
  1e9aa4:	0f 84 9e 01 00 00    	je     1e9c48 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2dd8>
  1e9aaa:	8d 48 ff             	lea    -0x1(%rax),%ecx
  1e9aad:	39 4c 24 48          	cmp    %ecx,0x48(%rsp)
  1e9ab1:	0f 86 92 2b 00 00    	jbe    1ec649 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x57d9>
  1e9ab7:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  1e9abc:	48 ba f8 ff ff ff ff 	movabs $0x1ffffffffffffff8,%rdx
  1e9ac3:	ff ff 1f 
  1e9ac6:	48 21 d1             	and    %rdx,%rcx
  1e9ac9:	c4 c1 7a 10 64 8d 00 	vmovss 0x0(%r13,%rcx,4),%xmm4
  1e9ad0:	c5 da 59 a4 8c c0 05 	vmulss 0x5c0(%rsp,%rcx,4),%xmm4,%xmm4
  1e9ad7:	00 00 
  1e9ad9:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
  1e9ae0:	00 
  1e9ae1:	c4 e2 59 b9 5c 95 00 	vfmadd231ss 0x0(%rbp,%rdx,4),%xmm4,%xmm3
  1e9ae8:	4c 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%r9
  1e9aef:	00 
  1e9af0:	c4 a2 59 b9 14 8f    	vfmadd231ss (%rdi,%r9,4),%xmm4,%xmm2
  1e9af6:	4c 8b 94 24 e8 00 00 	mov    0xe8(%rsp),%r10
  1e9afd:	00 
  1e9afe:	c4 a2 59 b9 0c 93    	vfmadd231ss (%rbx,%r10,4),%xmm4,%xmm1
  1e9b04:	4c 8b 9c 24 e0 00 00 	mov    0xe0(%rsp),%r11
  1e9b0b:	00 
  1e9b0c:	c4 82 59 b9 04 98    	vfmadd231ss (%r8,%r11,4),%xmm4,%xmm0
  1e9b12:	83 f8 01             	cmp    $0x1,%eax
  1e9b15:	0f 84 2d 01 00 00    	je     1e9c48 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2dd8>
  1e9b1b:	c4 c1 7a 10 64 8d 04 	vmovss 0x4(%r13,%rcx,4),%xmm4
  1e9b22:	c5 da 59 a4 8c c4 05 	vmulss 0x5c4(%rsp,%rcx,4),%xmm4,%xmm4
  1e9b29:	00 00 
  1e9b2b:	c4 e2 59 b9 5c 95 04 	vfmadd231ss 0x4(%rbp,%rdx,4),%xmm4,%xmm3
  1e9b32:	c4 a2 59 b9 54 8f 04 	vfmadd231ss 0x4(%rdi,%r9,4),%xmm4,%xmm2
  1e9b39:	c4 a2 59 b9 4c 93 04 	vfmadd231ss 0x4(%rbx,%r10,4),%xmm4,%xmm1
  1e9b40:	c4 82 59 b9 44 98 04 	vfmadd231ss 0x4(%r8,%r11,4),%xmm4,%xmm0
  1e9b47:	83 f8 02             	cmp    $0x2,%eax
  1e9b4a:	0f 84 f8 00 00 00    	je     1e9c48 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2dd8>
  1e9b50:	c4 c1 7a 10 64 8d 08 	vmovss 0x8(%r13,%rcx,4),%xmm4
  1e9b57:	c5 da 59 a4 8c c8 05 	vmulss 0x5c8(%rsp,%rcx,4),%xmm4,%xmm4
  1e9b5e:	00 00 
  1e9b60:	c4 e2 59 b9 5c 95 08 	vfmadd231ss 0x8(%rbp,%rdx,4),%xmm4,%xmm3
  1e9b67:	c4 a2 59 b9 54 8f 08 	vfmadd231ss 0x8(%rdi,%r9,4),%xmm4,%xmm2
  1e9b6e:	c4 a2 59 b9 4c 93 08 	vfmadd231ss 0x8(%rbx,%r10,4),%xmm4,%xmm1
  1e9b75:	c4 82 59 b9 44 98 08 	vfmadd231ss 0x8(%r8,%r11,4),%xmm4,%xmm0
  1e9b7c:	83 f8 03             	cmp    $0x3,%eax
  1e9b7f:	0f 84 c3 00 00 00    	je     1e9c48 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2dd8>
  1e9b85:	c4 c1 7a 10 64 8d 0c 	vmovss 0xc(%r13,%rcx,4),%xmm4
  1e9b8c:	c5 da 59 a4 8c cc 05 	vmulss 0x5cc(%rsp,%rcx,4),%xmm4,%xmm4
  1e9b93:	00 00 
  1e9b95:	c4 e2 59 b9 5c 95 0c 	vfmadd231ss 0xc(%rbp,%rdx,4),%xmm4,%xmm3
  1e9b9c:	c4 a2 59 b9 54 8f 0c 	vfmadd231ss 0xc(%rdi,%r9,4),%xmm4,%xmm2
  1e9ba3:	c4 a2 59 b9 4c 93 0c 	vfmadd231ss 0xc(%rbx,%r10,4),%xmm4,%xmm1
  1e9baa:	c4 82 59 b9 44 98 0c 	vfmadd231ss 0xc(%r8,%r11,4),%xmm4,%xmm0
  1e9bb1:	83 f8 04             	cmp    $0x4,%eax
  1e9bb4:	0f 84 8e 00 00 00    	je     1e9c48 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2dd8>
  1e9bba:	c4 c1 7a 10 64 8d 10 	vmovss 0x10(%r13,%rcx,4),%xmm4
  1e9bc1:	c5 da 59 a4 8c d0 05 	vmulss 0x5d0(%rsp,%rcx,4),%xmm4,%xmm4
  1e9bc8:	00 00 
  1e9bca:	c4 e2 59 b9 5c 95 10 	vfmadd231ss 0x10(%rbp,%rdx,4),%xmm4,%xmm3
  1e9bd1:	c4 a2 59 b9 54 8f 10 	vfmadd231ss 0x10(%rdi,%r9,4),%xmm4,%xmm2
  1e9bd8:	c4 a2 59 b9 4c 93 10 	vfmadd231ss 0x10(%rbx,%r10,4),%xmm4,%xmm1
  1e9bdf:	c4 82 59 b9 44 98 10 	vfmadd231ss 0x10(%r8,%r11,4),%xmm4,%xmm0
  1e9be6:	83 f8 05             	cmp    $0x5,%eax
  1e9be9:	74 5d                	je     1e9c48 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2dd8>
  1e9beb:	c4 c1 7a 10 64 8d 14 	vmovss 0x14(%r13,%rcx,4),%xmm4
  1e9bf2:	c5 da 59 a4 8c d4 05 	vmulss 0x5d4(%rsp,%rcx,4),%xmm4,%xmm4
  1e9bf9:	00 00 
  1e9bfb:	c4 e2 59 b9 5c 95 14 	vfmadd231ss 0x14(%rbp,%rdx,4),%xmm4,%xmm3
  1e9c02:	c4 a2 59 b9 54 8f 14 	vfmadd231ss 0x14(%rdi,%r9,4),%xmm4,%xmm2
  1e9c09:	c4 a2 59 b9 4c 93 14 	vfmadd231ss 0x14(%rbx,%r10,4),%xmm4,%xmm1
  1e9c10:	c4 82 59 b9 44 98 14 	vfmadd231ss 0x14(%r8,%r11,4),%xmm4,%xmm0
  1e9c17:	83 f8 06             	cmp    $0x6,%eax
  1e9c1a:	74 2c                	je     1e9c48 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2dd8>
  1e9c1c:	c4 c1 7a 10 64 8d 18 	vmovss 0x18(%r13,%rcx,4),%xmm4
  1e9c23:	c5 da 59 a4 8c d8 05 	vmulss 0x5d8(%rsp,%rcx,4),%xmm4,%xmm4
  1e9c2a:	00 00 
  1e9c2c:	c4 e2 59 b9 5c 95 18 	vfmadd231ss 0x18(%rbp,%rdx,4),%xmm4,%xmm3
  1e9c33:	c4 a2 59 b9 54 8f 18 	vfmadd231ss 0x18(%rdi,%r9,4),%xmm4,%xmm2
  1e9c3a:	c4 a2 59 b9 4c 93 18 	vfmadd231ss 0x18(%rbx,%r10,4),%xmm4,%xmm1
  1e9c41:	c4 82 59 b9 44 98 18 	vfmadd231ss 0x18(%r8,%r11,4),%xmm4,%xmm0
  1e9c48:	48 8b 84 24 c8 17 00 	mov    0x17c8(%rsp),%rax
  1e9c4f:	00 
  1e9c50:	48 85 c0             	test   %rax,%rax
  1e9c53:	0f 84 61 06 00 00    	je     1ea2ba <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x344a>
  1e9c59:	31 c9                	xor    %ecx,%ecx
  1e9c5b:	eb 3c                	jmp    1e9c99 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2e29>
  1e9c5d:	41 09 fa             	or     %edi,%r10d
  1e9c60:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
  1e9c65:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
  1e9c6a:	c5 f9 6e e2          	vmovd  %edx,%xmm4
  1e9c6e:	c5 1a 58 e4          	vaddss %xmm4,%xmm12,%xmm12
  1e9c72:	c4 c1 79 6e e0       	vmovd  %r8d,%xmm4
  1e9c77:	c5 22 58 dc          	vaddss %xmm4,%xmm11,%xmm11
  1e9c7b:	c4 c1 79 6e e1       	vmovd  %r9d,%xmm4
  1e9c80:	c5 2a 58 d4          	vaddss %xmm4,%xmm10,%xmm10
  1e9c84:	c4 c1 79 6e e2       	vmovd  %r10d,%xmm4
  1e9c89:	c5 32 58 cc          	vaddss %xmm4,%xmm9,%xmm9
  1e9c8d:	48 ff c1             	inc    %rcx
  1e9c90:	48 39 c8             	cmp    %rcx,%rax
  1e9c93:	0f 84 21 06 00 00    	je     1ea2ba <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x344a>
  1e9c99:	48 81 f9 00 01 00 00 	cmp    $0x100,%rcx
  1e9ca0:	0f 84 14 06 00 00    	je     1ea2ba <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x344a>
  1e9ca6:	0f b6 bc 0c c8 16 00 	movzbl 0x16c8(%rsp,%rcx,1),%edi
  1e9cad:	00 
  1e9cae:	48 39 fe             	cmp    %rdi,%rsi
  1e9cb1:	0f 86 b4 27 00 00    	jbe    1ec46b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x55fb>
  1e9cb7:	48 39 bc 24 98 00 00 	cmp    %rdi,0x98(%rsp)
  1e9cbe:	00 
  1e9cbf:	0f 86 b6 27 00 00    	jbe    1ec47b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x560b>
  1e9cc5:	41 89 f8             	mov    %edi,%r8d
  1e9cc8:	41 c1 e0 05          	shl    $0x5,%r8d
  1e9ccc:	c4 81 7c 10 64 05 00 	vmovups 0x0(%r13,%r8,1),%ymm4
  1e9cd3:	48 8d 94 24 c0 09 00 	lea    0x9c0(%rsp),%rdx
  1e9cda:	00 
  1e9cdb:	c4 a1 5c 59 24 02    	vmulps (%rdx,%r8,1),%ymm4,%ymm4
  1e9ce1:	c4 a1 7c 10 6c 05 00 	vmovups 0x0(%rbp,%r8,1),%ymm5
  1e9ce8:	c4 e2 3d 98 ec       	vfmadd132ps %ymm4,%ymm8,%ymm5
  1e9ced:	48 8b bc fc c0 0d 00 	mov    0xdc0(%rsp,%rdi,8),%rdi
  1e9cf4:	00 
  1e9cf5:	c4 e3 7d 19 ee 01    	vextractf128 $0x1,%ymm5,%xmm6
  1e9cfb:	c5 d0 58 ee          	vaddps %xmm6,%xmm5,%xmm5
  1e9cff:	c5 d1 c6 f5 01       	vshufpd $0x1,%xmm5,%xmm5,%xmm6
  1e9d04:	c5 d0 58 ee          	vaddps %xmm6,%xmm5,%xmm5
  1e9d08:	c5 fa 16 f5          	vmovshdup %xmm5,%xmm6
  1e9d0c:	c5 d2 58 ee          	vaddss %xmm6,%xmm5,%xmm5
  1e9d10:	c5 f9 7e ea          	vmovd  %xmm5,%edx
  1e9d14:	41 89 d3             	mov    %edx,%r11d
  1e9d17:	41 81 e3 ff ff ff 7f 	and    $0x7fffffff,%r11d
  1e9d1e:	41 81 fb 00 00 80 7f 	cmp    $0x7f800000,%r11d
  1e9d25:	41 0f 94 c2          	sete   %r10b
  1e9d29:	45 85 db             	test   %r11d,%r11d
  1e9d2c:	41 0f 94 c1          	sete   %r9b
  1e9d30:	41 81 fb 01 00 80 7f 	cmp    $0x7f800001,%r11d
  1e9d37:	41 0f 9d c3          	setge  %r11b
  1e9d3b:	48 85 ff             	test   %rdi,%rdi
  1e9d3e:	74 5e                	je     1e9d9e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2f2e>
  1e9d40:	45 08 d1             	or     %r10b,%r9b
  1e9d43:	45 08 d9             	or     %r11b,%r9b
  1e9d46:	75 56                	jne    1e9d9e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2f2e>
  1e9d48:	41 89 d2             	mov    %edx,%r10d
  1e9d4b:	41 c1 ea 17          	shr    $0x17,%r10d
  1e9d4f:	41 89 d1             	mov    %edx,%r9d
  1e9d52:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
  1e9d59:	41 81 e2 ff 00 00 00 	and    $0xff,%r10d
  1e9d60:	0f 84 6a 01 00 00    	je     1e9ed0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3060>
  1e9d66:	45 89 d2             	mov    %r10d,%r10d
  1e9d69:	41 81 c9 00 00 80 00 	or     $0x800000,%r9d
  1e9d70:	49 83 c2 81          	add    $0xffffffffffffff81,%r10
  1e9d74:	49 01 fa             	add    %rdi,%r10
  1e9d77:	4c 8b 9c 24 a0 00 00 	mov    0xa0(%rsp),%r11
  1e9d7e:	00 
  1e9d7f:	0f 80 77 01 00 00    	jo     1e9efc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x308c>
  1e9d85:	49 83 fa 7f          	cmp    $0x7f,%r10
  1e9d89:	0f 8e e6 00 00 00    	jle    1e9e75 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3005>
  1e9d8f:	c5 f8 50 d5          	vmovmskps %xmm5,%edx
  1e9d93:	c1 e2 1f             	shl    $0x1f,%edx
  1e9d96:	81 ca 00 00 80 7f    	or     $0x7f800000,%edx
  1e9d9c:	eb 08                	jmp    1e9da6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2f36>
  1e9d9e:	4c 8b 9c 24 a0 00 00 	mov    0xa0(%rsp),%r11
  1e9da5:	00 
  1e9da6:	c4 81 7c 10 34 03    	vmovups (%r11,%r8,1),%ymm6
  1e9dac:	c4 e2 3d 98 f4       	vfmadd132ps %ymm4,%ymm8,%ymm6
  1e9db1:	c4 a1 7c 10 2c 03    	vmovups (%rbx,%r8,1),%ymm5
  1e9db7:	c4 e2 3d 98 ec       	vfmadd132ps %ymm4,%ymm8,%ymm5
  1e9dbc:	4c 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%r9
  1e9dc3:	00 
  1e9dc4:	c4 82 3d 98 24 01    	vfmadd132ps (%r9,%r8,1),%ymm8,%ymm4
  1e9dca:	c4 e3 7d 19 f7 01    	vextractf128 $0x1,%ymm6,%xmm7
  1e9dd0:	c5 c8 58 f7          	vaddps %xmm7,%xmm6,%xmm6
  1e9dd4:	c5 c9 c6 fe 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm7
  1e9dd9:	c5 c8 58 f7          	vaddps %xmm7,%xmm6,%xmm6
  1e9ddd:	c5 fa 16 fe          	vmovshdup %xmm6,%xmm7
  1e9de1:	c5 ca 58 f7          	vaddss %xmm7,%xmm6,%xmm6
  1e9de5:	c4 c1 79 7e f0       	vmovd  %xmm6,%r8d
  1e9dea:	45 89 c3             	mov    %r8d,%r11d
  1e9ded:	41 81 e3 ff ff ff 7f 	and    $0x7fffffff,%r11d
  1e9df4:	41 81 fb 00 00 80 7f 	cmp    $0x7f800000,%r11d
  1e9dfb:	41 0f 94 c2          	sete   %r10b
  1e9dff:	45 85 db             	test   %r11d,%r11d
  1e9e02:	41 0f 94 c1          	sete   %r9b
  1e9e06:	41 81 fb 01 00 80 7f 	cmp    $0x7f800001,%r11d
  1e9e0d:	41 0f 9d c3          	setge  %r11b
  1e9e11:	48 85 ff             	test   %rdi,%rdi
  1e9e14:	0f 84 e6 01 00 00    	je     1ea000 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3190>
  1e9e1a:	45 08 d1             	or     %r10b,%r9b
  1e9e1d:	45 08 d9             	or     %r11b,%r9b
  1e9e20:	0f 85 da 01 00 00    	jne    1ea000 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3190>
  1e9e26:	45 89 c2             	mov    %r8d,%r10d
  1e9e29:	41 c1 ea 17          	shr    $0x17,%r10d
  1e9e2d:	45 89 c1             	mov    %r8d,%r9d
  1e9e30:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
  1e9e37:	41 81 e2 ff 00 00 00 	and    $0xff,%r10d
  1e9e3e:	0f 84 cd 00 00 00    	je     1e9f11 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x30a1>
  1e9e44:	45 89 d2             	mov    %r10d,%r10d
  1e9e47:	41 81 c9 00 00 80 00 	or     $0x800000,%r9d
  1e9e4e:	49 83 c2 81          	add    $0xffffffffffffff81,%r10
  1e9e52:	49 01 fa             	add    %rdi,%r10
  1e9e55:	0f 80 da 00 00 00    	jo     1e9f35 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x30c5>
  1e9e5b:	49 83 fa 7f          	cmp    $0x7f,%r10
  1e9e5f:	7e 41                	jle    1e9ea2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3032>
  1e9e61:	c5 78 50 c6          	vmovmskps %xmm6,%r8d
  1e9e65:	41 c1 e0 1f          	shl    $0x1f,%r8d
  1e9e69:	41 81 c8 00 00 80 7f 	or     $0x7f800000,%r8d
  1e9e70:	e9 8b 01 00 00       	jmp    1ea000 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3190>
  1e9e75:	81 e2 00 00 00 80    	and    $0x80000000,%edx
  1e9e7b:	49 83 fa 81          	cmp    $0xffffffffffffff81,%r10
  1e9e7f:	0f 8e c6 00 00 00    	jle    1e9f4b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x30db>
  1e9e85:	41 c1 e2 17          	shl    $0x17,%r10d
  1e9e89:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
  1e9e90:	45 01 d1             	add    %r10d,%r9d
  1e9e93:	41 81 c1 00 00 80 3f 	add    $0x3f800000,%r9d
  1e9e9a:	44 09 ca             	or     %r9d,%edx
  1e9e9d:	e9 04 ff ff ff       	jmp    1e9da6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2f36>
  1e9ea2:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
  1e9ea9:	49 83 fa 81          	cmp    $0xffffffffffffff81,%r10
  1e9ead:	0f 8e f4 00 00 00    	jle    1e9fa7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3137>
  1e9eb3:	41 c1 e2 17          	shl    $0x17,%r10d
  1e9eb7:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
  1e9ebe:	45 01 d1             	add    %r10d,%r9d
  1e9ec1:	41 81 c1 00 00 80 3f 	add    $0x3f800000,%r9d
  1e9ec8:	45 09 c8             	or     %r9d,%r8d
  1e9ecb:	e9 30 01 00 00       	jmp    1ea000 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3190>
  1e9ed0:	45 31 db             	xor    %r11d,%r11d
  1e9ed3:	f3 45 0f bd d9       	lzcnt  %r9d,%r11d
  1e9ed8:	41 83 c3 f8          	add    $0xfffffff8,%r11d
  1e9edc:	c4 42 21 f7 c9       	shlx   %r11d,%r9d,%r9d
  1e9ee1:	49 c7 c2 82 ff ff ff 	mov    $0xffffffffffffff82,%r10
  1e9ee8:	4d 29 da             	sub    %r11,%r10
  1e9eeb:	49 01 fa             	add    %rdi,%r10
  1e9eee:	4c 8b 9c 24 a0 00 00 	mov    0xa0(%rsp),%r11
  1e9ef5:	00 
  1e9ef6:	0f 81 89 fe ff ff    	jno    1e9d85 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2f15>
  1e9efc:	48 85 ff             	test   %rdi,%rdi
  1e9eff:	0f 8f 8a fe ff ff    	jg     1e9d8f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2f1f>
  1e9f05:	c5 f8 50 d5          	vmovmskps %xmm5,%edx
  1e9f09:	c1 e2 1f             	shl    $0x1f,%edx
  1e9f0c:	e9 95 fe ff ff       	jmp    1e9da6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2f36>
  1e9f11:	45 31 db             	xor    %r11d,%r11d
  1e9f14:	f3 45 0f bd d9       	lzcnt  %r9d,%r11d
  1e9f19:	41 83 c3 f8          	add    $0xfffffff8,%r11d
  1e9f1d:	c4 42 21 f7 c9       	shlx   %r11d,%r9d,%r9d
  1e9f22:	49 c7 c2 82 ff ff ff 	mov    $0xffffffffffffff82,%r10
  1e9f29:	4d 29 da             	sub    %r11,%r10
  1e9f2c:	49 01 fa             	add    %rdi,%r10
  1e9f2f:	0f 81 26 ff ff ff    	jno    1e9e5b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2feb>
  1e9f35:	48 85 ff             	test   %rdi,%rdi
  1e9f38:	0f 8f 23 ff ff ff    	jg     1e9e61 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2ff1>
  1e9f3e:	c5 78 50 c6          	vmovmskps %xmm6,%r8d
  1e9f42:	41 c1 e0 1f          	shl    $0x1f,%r8d
  1e9f46:	e9 b5 00 00 00       	jmp    1ea000 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3190>
  1e9f4b:	49 81 fa 6a ff ff ff 	cmp    $0xffffffffffffff6a,%r10
  1e9f52:	0f 82 4e fe ff ff    	jb     1e9da6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2f36>
  1e9f58:	41 b3 82             	mov    $0x82,%r11b
  1e9f5b:	45 28 d3             	sub    %r10b,%r11b
  1e9f5e:	c4 c2 23 f7 d9       	shrx   %r11d,%r9d,%ebx
  1e9f63:	c4 42 20 f5 d9       	bzhi   %r11d,%r9d,%r11d
  1e9f68:	41 b1 81             	mov    $0x81,%r9b
  1e9f6b:	45 28 d1             	sub    %r10b,%r9b
  1e9f6e:	bd 01 00 00 00       	mov    $0x1,%ebp
  1e9f73:	c4 62 31 f7 d5       	shlx   %r9d,%ebp,%r10d
  1e9f78:	45 31 c9             	xor    %r9d,%r9d
  1e9f7b:	45 39 d3             	cmp    %r10d,%r11d
  1e9f7e:	41 0f 94 c1          	sete   %r9b
  1e9f82:	41 21 d9             	and    %ebx,%r9d
  1e9f85:	45 39 d3             	cmp    %r10d,%r11d
  1e9f88:	44 0f 47 cd          	cmova  %ebp,%r9d
  1e9f8c:	41 01 d9             	add    %ebx,%r9d
  1e9f8f:	41 81 f9 ff ff 7f 00 	cmp    $0x7fffff,%r9d
  1e9f96:	0f 86 09 03 00 00    	jbe    1ea2a5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3435>
  1e9f9c:	81 ca 00 00 80 00    	or     $0x800000,%edx
  1e9fa2:	e9 01 03 00 00       	jmp    1ea2a8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3438>
  1e9fa7:	49 81 fa 6a ff ff ff 	cmp    $0xffffffffffffff6a,%r10
  1e9fae:	72 50                	jb     1ea000 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3190>
  1e9fb0:	41 b3 82             	mov    $0x82,%r11b
  1e9fb3:	45 28 d3             	sub    %r10b,%r11b
  1e9fb6:	c4 c2 23 f7 d9       	shrx   %r11d,%r9d,%ebx
  1e9fbb:	c4 42 20 f5 d9       	bzhi   %r11d,%r9d,%r11d
  1e9fc0:	41 b1 81             	mov    $0x81,%r9b
  1e9fc3:	45 28 d1             	sub    %r10b,%r9b
  1e9fc6:	bd 01 00 00 00       	mov    $0x1,%ebp
  1e9fcb:	c4 62 31 f7 d5       	shlx   %r9d,%ebp,%r10d
  1e9fd0:	45 31 c9             	xor    %r9d,%r9d
  1e9fd3:	45 39 d3             	cmp    %r10d,%r11d
  1e9fd6:	41 0f 94 c1          	sete   %r9b
  1e9fda:	41 21 d9             	and    %ebx,%r9d
  1e9fdd:	45 39 d3             	cmp    %r10d,%r11d
  1e9fe0:	44 0f 47 cd          	cmova  %ebp,%r9d
  1e9fe4:	41 01 d9             	add    %ebx,%r9d
  1e9fe7:	41 81 f9 ff ff 7f 00 	cmp    $0x7fffff,%r9d
  1e9fee:	0f 86 d4 fe ff ff    	jbe    1e9ec8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3058>
  1e9ff4:	41 81 c8 00 00 80 00 	or     $0x800000,%r8d
  1e9ffb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  1ea000:	c4 e3 7d 19 ee 01    	vextractf128 $0x1,%ymm5,%xmm6
  1ea006:	c5 d0 58 ee          	vaddps %xmm6,%xmm5,%xmm5
  1ea00a:	c5 d1 c6 f5 01       	vshufpd $0x1,%xmm5,%xmm5,%xmm6
  1ea00f:	c5 d0 58 ee          	vaddps %xmm6,%xmm5,%xmm5
  1ea013:	c5 fa 16 f5          	vmovshdup %xmm5,%xmm6
  1ea017:	c5 d2 58 ee          	vaddss %xmm6,%xmm5,%xmm5
  1ea01b:	c4 c1 79 7e e9       	vmovd  %xmm5,%r9d
  1ea020:	44 89 cb             	mov    %r9d,%ebx
  1ea023:	81 e3 ff ff ff 7f    	and    $0x7fffffff,%ebx
  1ea029:	81 fb 00 00 80 7f    	cmp    $0x7f800000,%ebx
  1ea02f:	41 0f 94 c3          	sete   %r11b
  1ea033:	85 db                	test   %ebx,%ebx
  1ea035:	41 0f 94 c2          	sete   %r10b
  1ea039:	81 fb 01 00 80 7f    	cmp    $0x7f800001,%ebx
  1ea03f:	0f 9d c3             	setge  %bl
  1ea042:	48 85 ff             	test   %rdi,%rdi
  1ea045:	0f 84 05 01 00 00    	je     1ea150 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x32e0>
  1ea04b:	45 08 da             	or     %r11b,%r10b
  1ea04e:	41 08 da             	or     %bl,%r10b
  1ea051:	0f 85 f9 00 00 00    	jne    1ea150 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x32e0>
  1ea057:	45 89 cb             	mov    %r9d,%r11d
  1ea05a:	41 c1 eb 17          	shr    $0x17,%r11d
  1ea05e:	45 89 ca             	mov    %r9d,%r10d
  1ea061:	41 81 e2 ff ff 7f 00 	and    $0x7fffff,%r10d
  1ea068:	41 81 e3 ff 00 00 00 	and    $0xff,%r11d
  1ea06f:	74 57                	je     1ea0c8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3258>
  1ea071:	45 89 db             	mov    %r11d,%r11d
  1ea074:	41 81 ca 00 00 80 00 	or     $0x800000,%r10d
  1ea07b:	49 83 c3 81          	add    $0xffffffffffffff81,%r11
  1ea07f:	49 01 fb             	add    %rdi,%r11
  1ea082:	70 62                	jo     1ea0e6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3276>
  1ea084:	49 83 fb 7f          	cmp    $0x7f,%r11
  1ea088:	7e 14                	jle    1ea09e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x322e>
  1ea08a:	c5 78 50 cd          	vmovmskps %xmm5,%r9d
  1ea08e:	41 c1 e1 1f          	shl    $0x1f,%r9d
  1ea092:	41 81 c9 00 00 80 7f 	or     $0x7f800000,%r9d
  1ea099:	e9 b2 00 00 00       	jmp    1ea150 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x32e0>
  1ea09e:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
  1ea0a5:	49 83 fb 81          	cmp    $0xffffffffffffff81,%r11
  1ea0a9:	7e 4a                	jle    1ea0f5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3285>
  1ea0ab:	41 c1 e3 17          	shl    $0x17,%r11d
  1ea0af:	41 81 e2 ff ff 7f 00 	and    $0x7fffff,%r10d
  1ea0b6:	45 01 da             	add    %r11d,%r10d
  1ea0b9:	41 81 c2 00 00 80 3f 	add    $0x3f800000,%r10d
  1ea0c0:	45 09 d1             	or     %r10d,%r9d
  1ea0c3:	e9 88 00 00 00       	jmp    1ea150 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x32e0>
  1ea0c8:	31 db                	xor    %ebx,%ebx
  1ea0ca:	f3 41 0f bd da       	lzcnt  %r10d,%ebx
  1ea0cf:	83 c3 f8             	add    $0xfffffff8,%ebx
  1ea0d2:	c4 42 61 f7 d2       	shlx   %ebx,%r10d,%r10d
  1ea0d7:	49 c7 c3 82 ff ff ff 	mov    $0xffffffffffffff82,%r11
  1ea0de:	49 29 db             	sub    %rbx,%r11
  1ea0e1:	49 01 fb             	add    %rdi,%r11
  1ea0e4:	71 9e                	jno    1ea084 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3214>
  1ea0e6:	48 85 ff             	test   %rdi,%rdi
  1ea0e9:	7f 9f                	jg     1ea08a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x321a>
  1ea0eb:	c5 78 50 cd          	vmovmskps %xmm5,%r9d
  1ea0ef:	41 c1 e1 1f          	shl    $0x1f,%r9d
  1ea0f3:	eb 5b                	jmp    1ea150 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x32e0>
  1ea0f5:	49 81 fb 6a ff ff ff 	cmp    $0xffffffffffffff6a,%r11
  1ea0fc:	72 52                	jb     1ea150 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x32e0>
  1ea0fe:	b3 82                	mov    $0x82,%bl
  1ea100:	44 28 db             	sub    %r11b,%bl
  1ea103:	c4 c2 63 f7 ea       	shrx   %ebx,%r10d,%ebp
  1ea108:	c4 c2 60 f5 da       	bzhi   %ebx,%r10d,%ebx
  1ea10d:	41 b2 81             	mov    $0x81,%r10b
  1ea110:	45 28 da             	sub    %r11b,%r10b
  1ea113:	41 bf 01 00 00 00    	mov    $0x1,%r15d
  1ea119:	c4 42 29 f7 df       	shlx   %r10d,%r15d,%r11d
  1ea11e:	45 31 d2             	xor    %r10d,%r10d
  1ea121:	44 39 db             	cmp    %r11d,%ebx
  1ea124:	41 0f 94 c2          	sete   %r10b
  1ea128:	41 21 ea             	and    %ebp,%r10d
  1ea12b:	44 39 db             	cmp    %r11d,%ebx
  1ea12e:	45 0f 47 d7          	cmova  %r15d,%r10d
  1ea132:	41 01 ea             	add    %ebp,%r10d
  1ea135:	41 81 fa ff ff 7f 00 	cmp    $0x7fffff,%r10d
  1ea13c:	76 82                	jbe    1ea0c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3250>
  1ea13e:	41 81 c9 00 00 80 00 	or     $0x800000,%r9d
  1ea145:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  1ea14c:	00 00 00 00 
  1ea150:	c4 e3 7d 19 e5 01    	vextractf128 $0x1,%ymm4,%xmm5
  1ea156:	c5 d8 58 e5          	vaddps %xmm5,%xmm4,%xmm4
  1ea15a:	c5 d9 c6 ec 01       	vshufpd $0x1,%xmm4,%xmm4,%xmm5
  1ea15f:	c5 d8 58 e5          	vaddps %xmm5,%xmm4,%xmm4
  1ea163:	c5 fa 16 ec          	vmovshdup %xmm4,%xmm5
  1ea167:	c5 da 58 e5          	vaddss %xmm5,%xmm4,%xmm4
  1ea16b:	c4 c1 79 7e e2       	vmovd  %xmm4,%r10d
  1ea170:	44 89 d5             	mov    %r10d,%ebp
  1ea173:	81 e5 ff ff ff 7f    	and    $0x7fffffff,%ebp
  1ea179:	81 fd 00 00 80 7f    	cmp    $0x7f800000,%ebp
  1ea17f:	0f 94 c3             	sete   %bl
  1ea182:	85 ed                	test   %ebp,%ebp
  1ea184:	41 0f 94 c3          	sete   %r11b
  1ea188:	81 fd 01 00 80 7f    	cmp    $0x7f800001,%ebp
  1ea18e:	40 0f 9d c5          	setge  %bpl
  1ea192:	48 85 ff             	test   %rdi,%rdi
  1ea195:	0f 84 c5 fa ff ff    	je     1e9c60 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2df0>
  1ea19b:	41 08 db             	or     %bl,%r11b
  1ea19e:	41 08 eb             	or     %bpl,%r11b
  1ea1a1:	0f 85 b9 fa ff ff    	jne    1e9c60 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2df0>
  1ea1a7:	44 89 d3             	mov    %r10d,%ebx
  1ea1aa:	c1 eb 17             	shr    $0x17,%ebx
  1ea1ad:	45 89 d3             	mov    %r10d,%r11d
  1ea1b0:	41 81 e3 ff ff 7f 00 	and    $0x7fffff,%r11d
  1ea1b7:	81 e3 ff 00 00 00    	and    $0xff,%ebx
  1ea1bd:	48 8b 6c 24 78       	mov    0x78(%rsp),%rbp
  1ea1c2:	74 55                	je     1ea219 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x33a9>
  1ea1c4:	89 db                	mov    %ebx,%ebx
  1ea1c6:	41 81 cb 00 00 80 00 	or     $0x800000,%r11d
  1ea1cd:	48 83 c3 81          	add    $0xffffffffffffff81,%rbx
  1ea1d1:	48 01 fb             	add    %rdi,%rbx
  1ea1d4:	70 63                	jo     1ea239 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x33c9>
  1ea1d6:	48 83 fb 7f          	cmp    $0x7f,%rbx
  1ea1da:	7e 14                	jle    1ea1f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3380>
  1ea1dc:	c5 78 50 d4          	vmovmskps %xmm4,%r10d
  1ea1e0:	41 c1 e2 1f          	shl    $0x1f,%r10d
  1ea1e4:	41 81 ca 00 00 80 7f 	or     $0x7f800000,%r10d
  1ea1eb:	e9 75 fa ff ff       	jmp    1e9c65 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2df5>
  1ea1f0:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
  1ea1f7:	48 83 fb 81          	cmp    $0xffffffffffffff81,%rbx
  1ea1fb:	7e 4e                	jle    1ea24b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x33db>
  1ea1fd:	c1 e3 17             	shl    $0x17,%ebx
  1ea200:	41 81 e3 ff ff 7f 00 	and    $0x7fffff,%r11d
  1ea207:	42 8d 3c 1b          	lea    (%rbx,%r11,1),%edi
  1ea20b:	81 c7 00 00 80 3f    	add    $0x3f800000,%edi
  1ea211:	41 09 fa             	or     %edi,%r10d
  1ea214:	e9 4c fa ff ff       	jmp    1e9c65 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2df5>
  1ea219:	45 31 ff             	xor    %r15d,%r15d
  1ea21c:	f3 45 0f bd fb       	lzcnt  %r11d,%r15d
  1ea221:	41 83 c7 f8          	add    $0xfffffff8,%r15d
  1ea225:	c4 42 01 f7 db       	shlx   %r15d,%r11d,%r11d
  1ea22a:	48 c7 c3 82 ff ff ff 	mov    $0xffffffffffffff82,%rbx
  1ea231:	4c 29 fb             	sub    %r15,%rbx
  1ea234:	48 01 fb             	add    %rdi,%rbx
  1ea237:	71 9d                	jno    1ea1d6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3366>
  1ea239:	48 85 ff             	test   %rdi,%rdi
  1ea23c:	7f 9e                	jg     1ea1dc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x336c>
  1ea23e:	c5 78 50 d4          	vmovmskps %xmm4,%r10d
  1ea242:	41 c1 e2 1f          	shl    $0x1f,%r10d
  1ea246:	e9 1a fa ff ff       	jmp    1e9c65 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2df5>
  1ea24b:	48 81 fb 6a ff ff ff 	cmp    $0xffffffffffffff6a,%rbx
  1ea252:	0f 82 0d fa ff ff    	jb     1e9c65 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2df5>
  1ea258:	40 b7 82             	mov    $0x82,%dil
  1ea25b:	40 28 df             	sub    %bl,%dil
  1ea25e:	c4 c2 43 f7 eb       	shrx   %edi,%r11d,%ebp
  1ea263:	c4 42 40 f5 db       	bzhi   %edi,%r11d,%r11d
  1ea268:	40 b7 81             	mov    $0x81,%dil
  1ea26b:	40 28 df             	sub    %bl,%dil
  1ea26e:	41 bf 01 00 00 00    	mov    $0x1,%r15d
  1ea274:	c4 c2 41 f7 df       	shlx   %edi,%r15d,%ebx
  1ea279:	31 ff                	xor    %edi,%edi
  1ea27b:	41 39 db             	cmp    %ebx,%r11d
  1ea27e:	40 0f 94 c7          	sete   %dil
  1ea282:	21 ef                	and    %ebp,%edi
  1ea284:	41 39 db             	cmp    %ebx,%r11d
  1ea287:	41 0f 47 ff          	cmova  %r15d,%edi
  1ea28b:	01 ef                	add    %ebp,%edi
  1ea28d:	81 ff ff ff 7f 00    	cmp    $0x7fffff,%edi
  1ea293:	0f 86 c4 f9 ff ff    	jbe    1e9c5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2ded>
  1ea299:	41 81 ca 00 00 80 00 	or     $0x800000,%r10d
  1ea2a0:	e9 bb f9 ff ff       	jmp    1e9c60 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2df0>
  1ea2a5:	44 09 ca             	or     %r9d,%edx
  1ea2a8:	4c 8b 9c 24 a0 00 00 	mov    0xa0(%rsp),%r11
  1ea2af:	00 
  1ea2b0:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
  1ea2b5:	e9 ec fa ff ff       	jmp    1e9da6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x2f36>
  1ea2ba:	48 8b 8c 24 b0 05 00 	mov    0x5b0(%rsp),%rcx
  1ea2c1:	00 
  1ea2c2:	48 8b 94 24 b8 05 00 	mov    0x5b8(%rsp),%rdx
  1ea2c9:	00 
  1ea2ca:	31 c0                	xor    %eax,%eax
  1ea2cc:	48 39 d1             	cmp    %rdx,%rcx
  1ea2cf:	0f 99 c0             	setns  %al
  1ea2d2:	40 0f 94 c7          	sete   %dil
  1ea2d6:	48 be ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rsi
  1ea2dd:	ff ff 7f 
  1ea2e0:	48 01 f0             	add    %rsi,%rax
  1ea2e3:	48 89 ce             	mov    %rcx,%rsi
  1ea2e6:	48 29 d6             	sub    %rdx,%rsi
  1ea2e9:	48 0f 40 f0          	cmovo  %rax,%rsi
  1ea2ed:	c5 f9 7e d8          	vmovd  %xmm3,%eax
  1ea2f1:	41 89 c0             	mov    %eax,%r8d
  1ea2f4:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
  1ea2fb:	41 81 f8 00 00 80 7f 	cmp    $0x7f800000,%r8d
  1ea302:	41 0f 94 c1          	sete   %r9b
  1ea306:	45 85 c0             	test   %r8d,%r8d
  1ea309:	41 0f 94 c2          	sete   %r10b
  1ea30d:	45 08 ca             	or     %r9b,%r10b
  1ea310:	41 81 f8 01 00 80 7f 	cmp    $0x7f800001,%r8d
  1ea317:	41 0f 9d c0          	setge  %r8b
  1ea31b:	45 08 d0             	or     %r10b,%r8b
  1ea31e:	41 08 f8             	or     %dil,%r8b
  1ea321:	0f 85 ce 00 00 00    	jne    1ea3f5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3585>
  1ea327:	41 89 c0             	mov    %eax,%r8d
  1ea32a:	41 c1 e8 17          	shr    $0x17,%r8d
  1ea32e:	89 c7                	mov    %eax,%edi
  1ea330:	81 e7 ff ff 7f 00    	and    $0x7fffff,%edi
  1ea336:	41 81 e0 ff 00 00 00 	and    $0xff,%r8d
  1ea33d:	74 0f                	je     1ea34e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x34de>
  1ea33f:	45 89 c0             	mov    %r8d,%r8d
  1ea342:	81 cf 00 00 80 00    	or     $0x800000,%edi
  1ea348:	49 83 c0 81          	add    $0xffffffffffffff81,%r8
  1ea34c:	eb 1b                	jmp    1ea369 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x34f9>
  1ea34e:	45 31 c9             	xor    %r9d,%r9d
  1ea351:	f3 44 0f bd cf       	lzcnt  %edi,%r9d
  1ea356:	41 83 c1 f8          	add    $0xfffffff8,%r9d
  1ea35a:	c4 e2 31 f7 ff       	shlx   %r9d,%edi,%edi
  1ea35f:	49 c7 c0 82 ff ff ff 	mov    $0xffffffffffffff82,%r8
  1ea366:	4d 29 c8             	sub    %r9,%r8
  1ea369:	49 01 f0             	add    %rsi,%r8
  1ea36c:	0f 80 ae 18 00 00    	jo     1ebc20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4db0>
  1ea372:	49 83 f8 7f          	cmp    $0x7f,%r8
  1ea376:	7e 0e                	jle    1ea386 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3516>
  1ea378:	c5 f8 50 c3          	vmovmskps %xmm3,%eax
  1ea37c:	c1 e0 1f             	shl    $0x1f,%eax
  1ea37f:	0d 00 00 80 7f       	or     $0x7f800000,%eax
  1ea384:	eb 6f                	jmp    1ea3f5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3585>
  1ea386:	25 00 00 00 80       	and    $0x80000000,%eax
  1ea38b:	49 83 f8 81          	cmp    $0xffffffffffffff81,%r8
  1ea38f:	7e 17                	jle    1ea3a8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3538>
  1ea391:	41 c1 e0 17          	shl    $0x17,%r8d
  1ea395:	81 e7 ff ff 7f 00    	and    $0x7fffff,%edi
  1ea39b:	44 01 c7             	add    %r8d,%edi
  1ea39e:	81 c7 00 00 80 3f    	add    $0x3f800000,%edi
  1ea3a4:	09 f8                	or     %edi,%eax
  1ea3a6:	eb 4d                	jmp    1ea3f5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3585>
  1ea3a8:	49 81 f8 6a ff ff ff 	cmp    $0xffffffffffffff6a,%r8
  1ea3af:	72 44                	jb     1ea3f5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3585>
  1ea3b1:	41 b1 82             	mov    $0x82,%r9b
  1ea3b4:	45 28 c1             	sub    %r8b,%r9b
  1ea3b7:	c4 62 33 f7 d7       	shrx   %r9d,%edi,%r10d
  1ea3bc:	c4 62 30 f5 cf       	bzhi   %r9d,%edi,%r9d
  1ea3c1:	40 b7 81             	mov    $0x81,%dil
  1ea3c4:	44 28 c7             	sub    %r8b,%dil
  1ea3c7:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  1ea3cd:	c4 42 41 f7 c3       	shlx   %edi,%r11d,%r8d
  1ea3d2:	31 ff                	xor    %edi,%edi
  1ea3d4:	45 39 c1             	cmp    %r8d,%r9d
  1ea3d7:	40 0f 94 c7          	sete   %dil
  1ea3db:	44 21 d7             	and    %r10d,%edi
  1ea3de:	45 39 c1             	cmp    %r8d,%r9d
  1ea3e1:	41 0f 47 fb          	cmova  %r11d,%edi
  1ea3e5:	44 01 d7             	add    %r10d,%edi
  1ea3e8:	81 ff ff ff 7f 00    	cmp    $0x7fffff,%edi
  1ea3ee:	76 b4                	jbe    1ea3a4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3534>
  1ea3f0:	0d 00 00 80 00       	or     $0x800000,%eax
  1ea3f5:	48 39 d1             	cmp    %rdx,%rcx
  1ea3f8:	41 0f 94 c0          	sete   %r8b
  1ea3fc:	c5 f9 7e d7          	vmovd  %xmm2,%edi
  1ea400:	41 89 f9             	mov    %edi,%r9d
  1ea403:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  1ea40a:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  1ea411:	41 0f 94 c2          	sete   %r10b
  1ea415:	45 85 c9             	test   %r9d,%r9d
  1ea418:	41 0f 94 c3          	sete   %r11b
  1ea41c:	45 08 d3             	or     %r10b,%r11b
  1ea41f:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  1ea426:	41 0f 9d c1          	setge  %r9b
  1ea42a:	45 08 d9             	or     %r11b,%r9b
  1ea42d:	45 08 c1             	or     %r8b,%r9b
  1ea430:	0f 85 d8 00 00 00    	jne    1ea50e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x369e>
  1ea436:	41 89 f9             	mov    %edi,%r9d
  1ea439:	41 c1 e9 17          	shr    $0x17,%r9d
  1ea43d:	41 89 f8             	mov    %edi,%r8d
  1ea440:	41 81 e0 ff ff 7f 00 	and    $0x7fffff,%r8d
  1ea447:	41 81 e1 ff 00 00 00 	and    $0xff,%r9d
  1ea44e:	74 10                	je     1ea460 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x35f0>
  1ea450:	45 89 c9             	mov    %r9d,%r9d
  1ea453:	41 81 c8 00 00 80 00 	or     $0x800000,%r8d
  1ea45a:	49 83 c1 81          	add    $0xffffffffffffff81,%r9
  1ea45e:	eb 1b                	jmp    1ea47b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x360b>
  1ea460:	45 31 d2             	xor    %r10d,%r10d
  1ea463:	f3 45 0f bd d0       	lzcnt  %r8d,%r10d
  1ea468:	41 83 c2 f8          	add    $0xfffffff8,%r10d
  1ea46c:	c4 42 29 f7 c0       	shlx   %r10d,%r8d,%r8d
  1ea471:	49 c7 c1 82 ff ff ff 	mov    $0xffffffffffffff82,%r9
  1ea478:	4d 29 d1             	sub    %r10,%r9
  1ea47b:	49 01 f1             	add    %rsi,%r9
  1ea47e:	0f 80 bc 17 00 00    	jo     1ebc40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4dd0>
  1ea484:	49 83 f9 7f          	cmp    $0x7f,%r9
  1ea488:	7e 0f                	jle    1ea499 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3629>
  1ea48a:	c5 f8 50 fa          	vmovmskps %xmm2,%edi
  1ea48e:	c1 e7 1f             	shl    $0x1f,%edi
  1ea491:	81 cf 00 00 80 7f    	or     $0x7f800000,%edi
  1ea497:	eb 75                	jmp    1ea50e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x369e>
  1ea499:	81 e7 00 00 00 80    	and    $0x80000000,%edi
  1ea49f:	49 83 f9 81          	cmp    $0xffffffffffffff81,%r9
  1ea4a3:	7e 1a                	jle    1ea4bf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x364f>
  1ea4a5:	41 c1 e1 17          	shl    $0x17,%r9d
  1ea4a9:	41 81 e0 ff ff 7f 00 	and    $0x7fffff,%r8d
  1ea4b0:	45 01 c8             	add    %r9d,%r8d
  1ea4b3:	41 81 c0 00 00 80 3f 	add    $0x3f800000,%r8d
  1ea4ba:	44 09 c7             	or     %r8d,%edi
  1ea4bd:	eb 4f                	jmp    1ea50e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x369e>
  1ea4bf:	49 81 f9 6a ff ff ff 	cmp    $0xffffffffffffff6a,%r9
  1ea4c6:	72 46                	jb     1ea50e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x369e>
  1ea4c8:	41 b2 82             	mov    $0x82,%r10b
  1ea4cb:	45 28 ca             	sub    %r9b,%r10b
  1ea4ce:	c4 42 2b f7 d8       	shrx   %r10d,%r8d,%r11d
  1ea4d3:	c4 42 28 f5 d0       	bzhi   %r10d,%r8d,%r10d
  1ea4d8:	41 b0 81             	mov    $0x81,%r8b
  1ea4db:	45 28 c8             	sub    %r9b,%r8b
  1ea4de:	bb 01 00 00 00       	mov    $0x1,%ebx
  1ea4e3:	c4 62 39 f7 cb       	shlx   %r8d,%ebx,%r9d
  1ea4e8:	45 31 c0             	xor    %r8d,%r8d
  1ea4eb:	45 39 ca             	cmp    %r9d,%r10d
  1ea4ee:	41 0f 94 c0          	sete   %r8b
  1ea4f2:	45 21 d8             	and    %r11d,%r8d
  1ea4f5:	45 39 ca             	cmp    %r9d,%r10d
  1ea4f8:	44 0f 47 c3          	cmova  %ebx,%r8d
  1ea4fc:	45 01 d8             	add    %r11d,%r8d
  1ea4ff:	41 81 f8 ff ff 7f 00 	cmp    $0x7fffff,%r8d
  1ea506:	76 b2                	jbe    1ea4ba <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x364a>
  1ea508:	81 cf 00 00 80 00    	or     $0x800000,%edi
  1ea50e:	48 39 d1             	cmp    %rdx,%rcx
  1ea511:	41 0f 94 c1          	sete   %r9b
  1ea515:	c4 c1 79 7e c8       	vmovd  %xmm1,%r8d
  1ea51a:	45 89 c2             	mov    %r8d,%r10d
  1ea51d:	41 81 e2 ff ff ff 7f 	and    $0x7fffffff,%r10d
  1ea524:	41 81 fa 00 00 80 7f 	cmp    $0x7f800000,%r10d
  1ea52b:	41 0f 94 c3          	sete   %r11b
  1ea52f:	45 85 d2             	test   %r10d,%r10d
  1ea532:	0f 94 c3             	sete   %bl
  1ea535:	44 08 db             	or     %r11b,%bl
  1ea538:	41 81 fa 01 00 80 7f 	cmp    $0x7f800001,%r10d
  1ea53f:	41 0f 9d c2          	setge  %r10b
  1ea543:	41 08 da             	or     %bl,%r10b
  1ea546:	45 08 ca             	or     %r9b,%r10b
  1ea549:	0f 85 dc 00 00 00    	jne    1ea62b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x37bb>
  1ea54f:	45 89 c2             	mov    %r8d,%r10d
  1ea552:	41 c1 ea 17          	shr    $0x17,%r10d
  1ea556:	45 89 c1             	mov    %r8d,%r9d
  1ea559:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
  1ea560:	41 81 e2 ff 00 00 00 	and    $0xff,%r10d
  1ea567:	74 10                	je     1ea579 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3709>
  1ea569:	45 89 d2             	mov    %r10d,%r10d
  1ea56c:	41 81 c9 00 00 80 00 	or     $0x800000,%r9d
  1ea573:	49 83 c2 81          	add    $0xffffffffffffff81,%r10
  1ea577:	eb 1b                	jmp    1ea594 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3724>
  1ea579:	45 31 db             	xor    %r11d,%r11d
  1ea57c:	f3 45 0f bd d9       	lzcnt  %r9d,%r11d
  1ea581:	41 83 c3 f8          	add    $0xfffffff8,%r11d
  1ea585:	c4 42 21 f7 c9       	shlx   %r11d,%r9d,%r9d
  1ea58a:	49 c7 c2 82 ff ff ff 	mov    $0xffffffffffffff82,%r10
  1ea591:	4d 29 da             	sub    %r11,%r10
  1ea594:	49 01 f2             	add    %rsi,%r10
  1ea597:	0f 80 c4 16 00 00    	jo     1ebc61 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4df1>
  1ea59d:	49 83 fa 7f          	cmp    $0x7f,%r10
  1ea5a1:	7e 11                	jle    1ea5b4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3744>
  1ea5a3:	c5 78 50 c1          	vmovmskps %xmm1,%r8d
  1ea5a7:	41 c1 e0 1f          	shl    $0x1f,%r8d
  1ea5ab:	41 81 c8 00 00 80 7f 	or     $0x7f800000,%r8d
  1ea5b2:	eb 77                	jmp    1ea62b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x37bb>
  1ea5b4:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
  1ea5bb:	49 83 fa 81          	cmp    $0xffffffffffffff81,%r10
  1ea5bf:	7e 1a                	jle    1ea5db <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x376b>
  1ea5c1:	41 c1 e2 17          	shl    $0x17,%r10d
  1ea5c5:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
  1ea5cc:	45 01 d1             	add    %r10d,%r9d
  1ea5cf:	41 81 c1 00 00 80 3f 	add    $0x3f800000,%r9d
  1ea5d6:	45 09 c8             	or     %r9d,%r8d
  1ea5d9:	eb 50                	jmp    1ea62b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x37bb>
  1ea5db:	49 81 fa 6a ff ff ff 	cmp    $0xffffffffffffff6a,%r10
  1ea5e2:	72 47                	jb     1ea62b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x37bb>
  1ea5e4:	41 b3 82             	mov    $0x82,%r11b
  1ea5e7:	45 28 d3             	sub    %r10b,%r11b
  1ea5ea:	c4 c2 23 f7 d9       	shrx   %r11d,%r9d,%ebx
  1ea5ef:	c4 42 20 f5 d9       	bzhi   %r11d,%r9d,%r11d
  1ea5f4:	41 b1 81             	mov    $0x81,%r9b
  1ea5f7:	45 28 d1             	sub    %r10b,%r9b
  1ea5fa:	bd 01 00 00 00       	mov    $0x1,%ebp
  1ea5ff:	c4 62 31 f7 d5       	shlx   %r9d,%ebp,%r10d
  1ea604:	45 31 c9             	xor    %r9d,%r9d
  1ea607:	45 39 d3             	cmp    %r10d,%r11d
  1ea60a:	41 0f 94 c1          	sete   %r9b
  1ea60e:	41 21 d9             	and    %ebx,%r9d
  1ea611:	45 39 d3             	cmp    %r10d,%r11d
  1ea614:	44 0f 47 cd          	cmova  %ebp,%r9d
  1ea618:	41 01 d9             	add    %ebx,%r9d
  1ea61b:	41 81 f9 ff ff 7f 00 	cmp    $0x7fffff,%r9d
  1ea622:	76 b2                	jbe    1ea5d6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3766>
  1ea624:	41 81 c8 00 00 80 00 	or     $0x800000,%r8d
  1ea62b:	48 39 d1             	cmp    %rdx,%rcx
  1ea62e:	41 0f 94 c2          	sete   %r10b
  1ea632:	c4 c1 79 7e c1       	vmovd  %xmm0,%r9d
  1ea637:	45 89 cb             	mov    %r9d,%r11d
  1ea63a:	41 81 e3 ff ff ff 7f 	and    $0x7fffffff,%r11d
  1ea641:	41 81 fb 00 00 80 7f 	cmp    $0x7f800000,%r11d
  1ea648:	0f 94 c3             	sete   %bl
  1ea64b:	45 85 db             	test   %r11d,%r11d
  1ea64e:	40 0f 94 c5          	sete   %bpl
  1ea652:	40 08 dd             	or     %bl,%bpl
  1ea655:	41 81 fb 01 00 80 7f 	cmp    $0x7f800001,%r11d
  1ea65c:	41 0f 9d c3          	setge  %r11b
  1ea660:	41 08 eb             	or     %bpl,%r11b
  1ea663:	45 08 d3             	or     %r10b,%r11b
  1ea666:	74 23                	je     1ea68b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x381b>
  1ea668:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  1ea66d:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1ea672:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
  1ea677:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
  1ea67c:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1ea681:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1ea686:	e9 b5 00 00 00       	jmp    1ea740 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x38d0>
  1ea68b:	45 89 cb             	mov    %r9d,%r11d
  1ea68e:	41 c1 eb 17          	shr    $0x17,%r11d
  1ea692:	45 89 ca             	mov    %r9d,%r10d
  1ea695:	41 81 e2 ff ff 7f 00 	and    $0x7fffff,%r10d
  1ea69c:	41 81 e3 ff 00 00 00 	and    $0xff,%r11d
  1ea6a3:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1ea6a8:	74 10                	je     1ea6ba <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x384a>
  1ea6aa:	45 89 db             	mov    %r11d,%r11d
  1ea6ad:	41 81 ca 00 00 80 00 	or     $0x800000,%r10d
  1ea6b4:	49 83 c3 81          	add    $0xffffffffffffff81,%r11
  1ea6b8:	eb 19                	jmp    1ea6d3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3863>
  1ea6ba:	31 db                	xor    %ebx,%ebx
  1ea6bc:	f3 41 0f bd da       	lzcnt  %r10d,%ebx
  1ea6c1:	83 c3 f8             	add    $0xfffffff8,%ebx
  1ea6c4:	c4 42 61 f7 d2       	shlx   %ebx,%r10d,%r10d
  1ea6c9:	49 c7 c3 82 ff ff ff 	mov    $0xffffffffffffff82,%r11
  1ea6d0:	49 29 db             	sub    %rbx,%r11
  1ea6d3:	49 01 f3             	add    %rsi,%r11
  1ea6d6:	0f 80 a8 15 00 00    	jo     1ebc84 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4e14>
  1ea6dc:	49 83 fb 7f          	cmp    $0x7f,%r11
  1ea6e0:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
  1ea6e5:	7e 11                	jle    1ea6f8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3888>
  1ea6e7:	c5 78 50 c8          	vmovmskps %xmm0,%r9d
  1ea6eb:	41 c1 e1 1f          	shl    $0x1f,%r9d
  1ea6ef:	41 81 c9 00 00 80 7f 	or     $0x7f800000,%r9d
  1ea6f6:	eb 34                	jmp    1ea72c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x38bc>
  1ea6f8:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
  1ea6ff:	49 83 fb 81          	cmp    $0xffffffffffffff81,%r11
  1ea703:	7e 1a                	jle    1ea71f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x38af>
  1ea705:	41 c1 e3 17          	shl    $0x17,%r11d
  1ea709:	41 81 e2 ff ff 7f 00 	and    $0x7fffff,%r10d
  1ea710:	43 8d 0c 13          	lea    (%r11,%r10,1),%ecx
  1ea714:	81 c1 00 00 80 3f    	add    $0x3f800000,%ecx
  1ea71a:	41 09 c9             	or     %ecx,%r9d
  1ea71d:	eb 0d                	jmp    1ea72c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x38bc>
  1ea71f:	49 81 fb 6a ff ff ff 	cmp    $0xffffffffffffff6a,%r11
  1ea726:	0f 83 c2 0c 00 00    	jae    1eb3ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x457e>
  1ea72c:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  1ea731:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1ea736:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
  1ea73b:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1ea740:	c5 f9 6e c0          	vmovd  %eax,%xmm0
  1ea744:	c5 9a 58 c0          	vaddss %xmm0,%xmm12,%xmm0
  1ea748:	c5 f9 6e cf          	vmovd  %edi,%xmm1
  1ea74c:	c5 a2 58 d1          	vaddss %xmm1,%xmm11,%xmm2
  1ea750:	c4 c1 79 6e c8       	vmovd  %r8d,%xmm1
  1ea755:	c5 aa 58 c9          	vaddss %xmm1,%xmm10,%xmm1
  1ea759:	c4 c1 79 6e d9       	vmovd  %r9d,%xmm3
  1ea75e:	c5 b2 58 db          	vaddss %xmm3,%xmm9,%xmm3
  1ea762:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
  1ea769:	00 
  1ea76a:	31 c9                	xor    %ecx,%ecx
  1ea76c:	4c 8b 8c 24 40 01 00 	mov    0x140(%rsp),%r9
  1ea773:	00 
  1ea774:	49 89 f0             	mov    %rsi,%r8
  1ea777:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  1ea77c:	48 8d 3c 00          	lea    (%rax,%rax,1),%rdi
  1ea780:	48 3b bc 24 d0 00 00 	cmp    0xd0(%rsp),%rdi
  1ea787:	00 
  1ea788:	0f 83 a4 1d 00 00    	jae    1ec532 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x56c2>
  1ea78e:	c5 fa 11 04 fa       	vmovss %xmm0,(%rdx,%rdi,8)
  1ea793:	c5 fa 11 54 fa 04    	vmovss %xmm2,0x4(%rdx,%rdi,8)
  1ea799:	48 ff c7             	inc    %rdi
  1ea79c:	48 3b bc 24 50 01 00 	cmp    0x150(%rsp),%rdi
  1ea7a3:	00 
  1ea7a4:	73 19                	jae    1ea7bf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x394f>
  1ea7a6:	48 3b bc 24 d0 00 00 	cmp    0xd0(%rsp),%rdi
  1ea7ad:	00 
  1ea7ae:	0f 83 d7 1d 00 00    	jae    1ec58b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x571b>
  1ea7b4:	c5 fa 11 0c fa       	vmovss %xmm1,(%rdx,%rdi,8)
  1ea7b9:	c5 fa 11 5c fa 04    	vmovss %xmm3,0x4(%rdx,%rdi,8)
  1ea7bf:	4c 3b 8c 24 b0 00 00 	cmp    0xb0(%rsp),%r9
  1ea7c6:	00 
  1ea7c7:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  1ea7cc:	0f 84 8c 16 00 00    	je     1ebe5e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4fee>
  1ea7d2:	4c 39 c7             	cmp    %r8,%rdi
  1ea7d5:	0f 83 6f 1d 00 00    	jae    1ec54a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x56da>
  1ea7db:	48 3b bc 24 10 01 00 	cmp    0x110(%rsp),%rdi
  1ea7e2:	00 
  1ea7e3:	0f 83 74 1d 00 00    	jae    1ec55d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x56ed>
  1ea7e9:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
  1ea7f0:	00 
  1ea7f1:	83 e2 07             	and    $0x7,%edx
  1ea7f4:	44 89 de             	mov    %r11d,%esi
  1ea7f7:	83 e6 07             	and    $0x7,%esi
  1ea7fa:	48 39 f2             	cmp    %rsi,%rdx
  1ea7fd:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  1ea804:	00 
  1ea805:	0f 85 28 ce ff ff    	jne    1e7633 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x7c3>
  1ea80b:	3b 54 24 48          	cmp    0x48(%rsp),%edx
  1ea80f:	0f 85 1e ce ff ff    	jne    1e7633 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x7c3>
  1ea815:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1ea81a:	83 e6 07             	and    $0x7,%esi
  1ea81d:	39 f2                	cmp    %esi,%edx
  1ea81f:	0f 85 0e ce ff ff    	jne    1e7633 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x7c3>
  1ea825:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
  1ea82c:	00 
  1ea82d:	48 c1 ea 03          	shr    $0x3,%rdx
  1ea831:	48 3b 94 24 98 00 00 	cmp    0x98(%rsp),%rdx
  1ea838:	00 
  1ea839:	0f 85 f4 cd ff ff    	jne    1e7633 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x7c3>
  1ea83f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1ea844:	48 c1 ee 03          	shr    $0x3,%rsi
  1ea848:	48 39 f2             	cmp    %rsi,%rdx
  1ea84b:	0f 85 e2 cd ff ff    	jne    1e7633 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x7c3>
  1ea851:	4c 89 de             	mov    %r11,%rsi
  1ea854:	48 c1 ee 03          	shr    $0x3,%rsi
  1ea858:	48 39 f2             	cmp    %rsi,%rdx
  1ea85b:	0f 85 d2 cd ff ff    	jne    1e7633 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x7c3>
  1ea861:	4d 89 c7             	mov    %r8,%r15
  1ea864:	4c 89 8c 24 40 01 00 	mov    %r9,0x140(%rsp)
  1ea86b:	00 
  1ea86c:	48 83 bc 24 98 00 00 	cmpq   $0x0,0x98(%rsp)
  1ea873:	00 00 
  1ea875:	0f 84 3b 01 00 00    	je     1ea9b6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3b46>
  1ea87b:	48 8b 94 24 00 01 00 	mov    0x100(%rsp),%rdx
  1ea882:	00 
  1ea883:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  1ea888:	c4 e2 7d 18 04 b2    	vbroadcastss (%rdx,%rsi,4),%ymm0
  1ea88e:	48 8b 94 24 f8 00 00 	mov    0xf8(%rsp),%rdx
  1ea895:	00 
  1ea896:	c4 e2 7d 18 0c b2    	vbroadcastss (%rdx,%rsi,4),%ymm1
  1ea89c:	48 83 bc 24 18 01 00 	cmpq   $0x20,0x118(%rsp)
  1ea8a3:	00 20 
  1ea8a5:	73 07                	jae    1ea8ae <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3a3e>
  1ea8a7:	31 d2                	xor    %edx,%edx
  1ea8a9:	e9 c4 00 00 00       	jmp    1ea972 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3b02>
  1ea8ae:	be 60 00 00 00       	mov    $0x60,%esi
  1ea8b3:	31 d2                	xor    %edx,%edx
  1ea8b5:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  1ea8ba:	48 8b 84 24 a0 01 00 	mov    0x1a0(%rsp),%rax
  1ea8c1:	00 
  1ea8c2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1ea8c9:	1f 84 00 00 00 00 00 
  1ea8d0:	c5 fc 10 54 37 a0    	vmovups -0x60(%rdi,%rsi,1),%ymm2
  1ea8d6:	c4 e2 7d a8 d1       	vfmadd213ps %ymm1,%ymm0,%ymm2
  1ea8db:	c4 c1 7c 10 5c 35 a0 	vmovups -0x60(%r13,%rsi,1),%ymm3
  1ea8e2:	c4 e2 6d a8 5c 35 a0 	vfmadd213ps -0x60(%rbp,%rsi,1),%ymm2,%ymm3
  1ea8e9:	c4 c1 7c 11 5c 32 a0 	vmovups %ymm3,-0x60(%r10,%rsi,1)
  1ea8f0:	c5 fc 10 54 37 c0    	vmovups -0x40(%rdi,%rsi,1),%ymm2
  1ea8f6:	c4 e2 7d a8 d1       	vfmadd213ps %ymm1,%ymm0,%ymm2
  1ea8fb:	c4 c1 7c 10 5c 35 c0 	vmovups -0x40(%r13,%rsi,1),%ymm3
  1ea902:	c4 e2 6d a8 5c 35 c0 	vfmadd213ps -0x40(%rbp,%rsi,1),%ymm2,%ymm3
  1ea909:	c4 c1 7c 11 5c 32 c0 	vmovups %ymm3,-0x40(%r10,%rsi,1)
  1ea910:	c5 fc 10 54 37 e0    	vmovups -0x20(%rdi,%rsi,1),%ymm2
  1ea916:	c4 e2 7d a8 d1       	vfmadd213ps %ymm1,%ymm0,%ymm2
  1ea91b:	c4 c1 7c 10 5c 35 e0 	vmovups -0x20(%r13,%rsi,1),%ymm3
  1ea922:	c4 e2 6d a8 5c 35 e0 	vfmadd213ps -0x20(%rbp,%rsi,1),%ymm2,%ymm3
  1ea929:	c4 c1 7c 11 5c 32 e0 	vmovups %ymm3,-0x20(%r10,%rsi,1)
  1ea930:	48 83 c2 04          	add    $0x4,%rdx
  1ea934:	c5 fc 10 14 37       	vmovups (%rdi,%rsi,1),%ymm2
  1ea939:	c4 e2 7d a8 d1       	vfmadd213ps %ymm1,%ymm0,%ymm2
  1ea93e:	c4 c1 7c 10 5c 35 00 	vmovups 0x0(%r13,%rsi,1),%ymm3
  1ea945:	c4 e2 6d a8 5c 35 00 	vfmadd213ps 0x0(%rbp,%rsi,1),%ymm2,%ymm3
  1ea94c:	c4 c1 7c 11 1c 32    	vmovups %ymm3,(%r10,%rsi,1)
  1ea952:	48 83 ee 80          	sub    $0xffffffffffffff80,%rsi
  1ea956:	48 39 d0             	cmp    %rdx,%rax
  1ea959:	0f 85 71 ff ff ff    	jne    1ea8d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3a60>
  1ea95f:	48 83 bc 24 98 01 00 	cmpq   $0x0,0x198(%rsp)
  1ea966:	00 00 
  1ea968:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  1ea96f:	00 
  1ea970:	74 44                	je     1ea9b6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3b46>
  1ea972:	48 c1 e2 05          	shl    $0x5,%rdx
  1ea976:	49 8d 34 12          	lea    (%r10,%rdx,1),%rsi
  1ea97a:	48 8d 3c 2a          	lea    (%rdx,%rbp,1),%rdi
  1ea97e:	4e 8d 04 2a          	lea    (%rdx,%r13,1),%r8
  1ea982:	48 03 54 24 60       	add    0x60(%rsp),%rdx
  1ea987:	45 31 c9             	xor    %r9d,%r9d
  1ea98a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  1ea990:	c4 a1 7c 10 14 0a    	vmovups (%rdx,%r9,1),%ymm2
  1ea996:	c4 e2 7d a8 d1       	vfmadd213ps %ymm1,%ymm0,%ymm2
  1ea99b:	c4 81 7c 10 1c 08    	vmovups (%r8,%r9,1),%ymm3
  1ea9a1:	c4 a2 6d a8 1c 0f    	vfmadd213ps (%rdi,%r9,1),%ymm2,%ymm3
  1ea9a7:	c4 a1 7c 11 1c 0e    	vmovups %ymm3,(%rsi,%r9,1)
  1ea9ad:	49 83 c1 20          	add    $0x20,%r9
  1ea9b1:	4c 39 c8             	cmp    %r9,%rax
  1ea9b4:	75 da                	jne    1ea990 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3b20>
  1ea9b6:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  1ea9bb:	48 be f8 ff ff ff ff 	movabs $0x1ffffffffffffff8,%rsi
  1ea9c2:	ff ff 1f 
  1ea9c5:	48 21 f2             	and    %rsi,%rdx
  1ea9c8:	4c 8d 0c 95 00 00 00 	lea    0x0(,%rdx,4),%r9
  1ea9cf:	00 
  1ea9d0:	4d 01 e9             	add    %r13,%r9
  1ea9d3:	4c 89 da             	mov    %r11,%rdx
  1ea9d6:	48 21 f2             	and    %rsi,%rdx
  1ea9d9:	4d 8d 04 92          	lea    (%r10,%rdx,4),%r8
  1ea9dd:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  1ea9e2:	48 85 ff             	test   %rdi,%rdi
  1ea9e5:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  1ea9ea:	0f 84 cf 01 00 00    	je     1eabbf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3d4f>
  1ea9f0:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
  1ea9f7:	00 
  1ea9f8:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  1ea9ff:	00 
  1eaa00:	c5 fa 10 04 86       	vmovss (%rsi,%rax,4),%xmm0
  1eaa05:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  1eaa0a:	c5 fa 10 0c 9e       	vmovss (%rsi,%rbx,4),%xmm1
  1eaa0f:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  1eaa16:	00 
  1eaa17:	c4 e2 79 a9 0c 86    	vfmadd213ss (%rsi,%rax,4),%xmm0,%xmm1
  1eaa1d:	48 be f8 ff ff ff ff 	movabs $0x1ffffffffffffff8,%rsi
  1eaa24:	ff ff 1f 
  1eaa27:	48 21 f2             	and    %rsi,%rdx
  1eaa2a:	c4 c1 7a 10 01       	vmovss (%r9),%xmm0
  1eaa2f:	c4 e2 71 a9 44 95 00 	vfmadd213ss 0x0(%rbp,%rdx,4),%xmm1,%xmm0
  1eaa36:	c4 c1 7a 11 00       	vmovss %xmm0,(%r8)
  1eaa3b:	83 ff 01             	cmp    $0x1,%edi
  1eaa3e:	0f 84 7b 01 00 00    	je     1eabbf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3d4f>
  1eaa44:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  1eaa4b:	00 
  1eaa4c:	c5 fa 10 04 86       	vmovss (%rsi,%rax,4),%xmm0
  1eaa51:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  1eaa56:	c5 fa 10 4c 9e 04    	vmovss 0x4(%rsi,%rbx,4),%xmm1
  1eaa5c:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  1eaa63:	00 
  1eaa64:	c4 e2 79 a9 0c 86    	vfmadd213ss (%rsi,%rax,4),%xmm0,%xmm1
  1eaa6a:	c4 c1 7a 10 41 04    	vmovss 0x4(%r9),%xmm0
  1eaa70:	c4 e2 71 a9 44 95 04 	vfmadd213ss 0x4(%rbp,%rdx,4),%xmm1,%xmm0
  1eaa77:	c4 c1 7a 11 40 04    	vmovss %xmm0,0x4(%r8)
  1eaa7d:	83 ff 02             	cmp    $0x2,%edi
  1eaa80:	0f 84 39 01 00 00    	je     1eabbf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3d4f>
  1eaa86:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  1eaa8d:	00 
  1eaa8e:	c5 fa 10 04 86       	vmovss (%rsi,%rax,4),%xmm0
  1eaa93:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  1eaa98:	c5 fa 10 4c 9e 08    	vmovss 0x8(%rsi,%rbx,4),%xmm1
  1eaa9e:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  1eaaa5:	00 
  1eaaa6:	c4 e2 79 a9 0c 86    	vfmadd213ss (%rsi,%rax,4),%xmm0,%xmm1
  1eaaac:	c4 c1 7a 10 41 08    	vmovss 0x8(%r9),%xmm0
  1eaab2:	c4 e2 71 a9 44 95 08 	vfmadd213ss 0x8(%rbp,%rdx,4),%xmm1,%xmm0
  1eaab9:	c4 c1 7a 11 40 08    	vmovss %xmm0,0x8(%r8)
  1eaabf:	83 ff 03             	cmp    $0x3,%edi
  1eaac2:	0f 84 f7 00 00 00    	je     1eabbf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3d4f>
  1eaac8:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  1eaacf:	00 
  1eaad0:	c5 fa 10 04 86       	vmovss (%rsi,%rax,4),%xmm0
  1eaad5:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  1eaada:	c5 fa 10 4c 9e 0c    	vmovss 0xc(%rsi,%rbx,4),%xmm1
  1eaae0:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  1eaae7:	00 
  1eaae8:	c4 e2 79 a9 0c 86    	vfmadd213ss (%rsi,%rax,4),%xmm0,%xmm1
  1eaaee:	c4 c1 7a 10 41 0c    	vmovss 0xc(%r9),%xmm0
  1eaaf4:	c4 e2 71 a9 44 95 0c 	vfmadd213ss 0xc(%rbp,%rdx,4),%xmm1,%xmm0
  1eaafb:	c4 c1 7a 11 40 0c    	vmovss %xmm0,0xc(%r8)
  1eab01:	83 ff 04             	cmp    $0x4,%edi
  1eab04:	0f 84 b5 00 00 00    	je     1eabbf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3d4f>
  1eab0a:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  1eab11:	00 
  1eab12:	c5 fa 10 04 86       	vmovss (%rsi,%rax,4),%xmm0
  1eab17:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  1eab1c:	c5 fa 10 4c 9e 10    	vmovss 0x10(%rsi,%rbx,4),%xmm1
  1eab22:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  1eab29:	00 
  1eab2a:	c4 e2 79 a9 0c 86    	vfmadd213ss (%rsi,%rax,4),%xmm0,%xmm1
  1eab30:	c4 c1 7a 10 41 10    	vmovss 0x10(%r9),%xmm0
  1eab36:	c4 e2 71 a9 44 95 10 	vfmadd213ss 0x10(%rbp,%rdx,4),%xmm1,%xmm0
  1eab3d:	c4 c1 7a 11 40 10    	vmovss %xmm0,0x10(%r8)
  1eab43:	83 ff 05             	cmp    $0x5,%edi
  1eab46:	74 77                	je     1eabbf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3d4f>
  1eab48:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  1eab4f:	00 
  1eab50:	c5 fa 10 04 86       	vmovss (%rsi,%rax,4),%xmm0
  1eab55:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  1eab5a:	c5 fa 10 4c 9e 14    	vmovss 0x14(%rsi,%rbx,4),%xmm1
  1eab60:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  1eab67:	00 
  1eab68:	c4 e2 79 a9 0c 86    	vfmadd213ss (%rsi,%rax,4),%xmm0,%xmm1
  1eab6e:	c4 c1 7a 10 41 14    	vmovss 0x14(%r9),%xmm0
  1eab74:	c4 e2 71 a9 44 95 14 	vfmadd213ss 0x14(%rbp,%rdx,4),%xmm1,%xmm0
  1eab7b:	c4 c1 7a 11 40 14    	vmovss %xmm0,0x14(%r8)
  1eab81:	83 ff 06             	cmp    $0x6,%edi
  1eab84:	74 39                	je     1eabbf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3d4f>
  1eab86:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  1eab8d:	00 
  1eab8e:	c5 fa 10 04 86       	vmovss (%rsi,%rax,4),%xmm0
  1eab93:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  1eab98:	c5 fa 10 4c 9e 18    	vmovss 0x18(%rsi,%rbx,4),%xmm1
  1eab9e:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  1eaba5:	00 
  1eaba6:	c4 e2 79 a9 0c 86    	vfmadd213ss (%rsi,%rax,4),%xmm0,%xmm1
  1eabac:	c4 c1 7a 10 41 18    	vmovss 0x18(%r9),%xmm0
  1eabb2:	c4 e2 71 a9 44 95 18 	vfmadd213ss 0x18(%rbp,%rdx,4),%xmm1,%xmm0
  1eabb9:	c4 c1 7a 11 40 18    	vmovss %xmm0,0x18(%r8)
  1eabbf:	b2 01                	mov    $0x1,%dl
  1eabc1:	84 c9                	test   %cl,%cl
  1eabc3:	0f 85 0b d2 ff ff    	jne    1e7dd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xf64>
  1eabc9:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
  1eabd0:	00 
  1eabd1:	c6 01 01             	movb   $0x1,(%rcx)
  1eabd4:	48 83 bc 24 98 00 00 	cmpq   $0x0,0x98(%rsp)
  1eabdb:	00 00 
  1eabdd:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
  1eabe2:	0f 84 d9 00 00 00    	je     1eacc1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3e51>
  1eabe8:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  1eabef:	00 
  1eabf0:	31 d2                	xor    %edx,%edx
  1eabf2:	eb 19                	jmp    1eac0d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3d9d>
  1eabf4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1eabfb:	00 00 00 00 00 
  1eac00:	48 83 c2 20          	add    $0x20,%rdx
  1eac04:	48 ff c9             	dec    %rcx
  1eac07:	0f 84 b4 00 00 00    	je     1eacc1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3e51>
  1eac0d:	c4 e2 7d 18 0d 22 a6 	vbroadcastss -0x1c59de(%rip),%ymm1        # 25238 <__abi_tag+0x24f3c>
  1eac14:	e3 ff 
  1eac16:	c4 c1 74 54 44 15 00 	vandps 0x0(%r13,%rdx,1),%ymm1,%ymm0
  1eac1d:	c4 c1 74 54 0c 12    	vandps (%r10,%rdx,1),%ymm1,%ymm1
  1eac23:	c5 fc 5f d1          	vmaxps %ymm1,%ymm0,%ymm2
  1eac27:	c4 e2 7d 18 1d a0 a3 	vbroadcastss -0x1c5c60(%rip),%ymm3        # 24fd0 <__abi_tag+0x24cd4>
  1eac2e:	e3 ff 
  1eac30:	c5 ec c2 db 12       	vcmple_oqps %ymm3,%ymm2,%ymm3
  1eac35:	c5 bc c2 e2 00       	vcmpeqps %ymm2,%ymm8,%ymm4
  1eac3a:	c4 e2 7d 18 2d d5 a5 	vbroadcastss -0x1c5a2b(%rip),%ymm5        # 25218 <__abi_tag+0x24f1c>
  1eac41:	e3 ff 
  1eac43:	c5 ec c2 ed 1d       	vcmpge_oqps %ymm5,%ymm2,%ymm5
  1eac48:	c5 d4 56 e4          	vorps  %ymm4,%ymm5,%ymm4
  1eac4c:	c5 dc 54 db          	vandps %ymm3,%ymm4,%ymm3
  1eac50:	c5 dd 76 e4          	vpcmpeqd %ymm4,%ymm4,%ymm4
  1eac54:	c4 e2 7d 17 dc       	vptest %ymm4,%ymm3
  1eac59:	72 a5                	jb     1eac00 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3d90>
  1eac5b:	c5 f4 c2 d9 00       	vcmpeqps %ymm1,%ymm1,%ymm3
  1eac60:	c4 e3 7d 4a d2 30    	vblendvps %ymm3,%ymm2,%ymm0,%ymm2
  1eac66:	c5 fc c2 c0 00       	vcmpeqps %ymm0,%ymm0,%ymm0
  1eac6b:	c4 e3 75 4a c2 00    	vblendvps %ymm0,%ymm2,%ymm1,%ymm0
  1eac71:	c4 e2 7d 18 1d 56 a3 	vbroadcastss -0x1c5caa(%rip),%ymm3        # 24fd0 <__abi_tag+0x24cd4>
  1eac78:	e3 ff 
  1eac7a:	c5 fc c2 cb 12       	vcmple_oqps %ymm3,%ymm0,%ymm1
  1eac7f:	c5 bc c2 d0 00       	vcmpeqps %ymm0,%ymm8,%ymm2
  1eac84:	c4 e3 7d 4a c3 20    	vblendvps %ymm2,%ymm3,%ymm0,%ymm0
  1eac8a:	c5 bd 66 c9          	vpcmpgtd %ymm1,%ymm8,%ymm1
  1eac8e:	c5 f5 db c0          	vpand  %ymm0,%ymm1,%ymm0
  1eac92:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
  1eac98:	c5 f8 5d c1          	vminps %xmm1,%xmm0,%xmm0
  1eac9c:	c5 f9 c6 c8 03       	vshufpd $0x3,%xmm0,%xmm0,%xmm1
  1eaca1:	c5 f8 5d c1          	vminps %xmm1,%xmm0,%xmm0
  1eaca5:	c5 fa 16 c8          	vmovshdup %xmm0,%xmm1
  1eaca9:	c5 fa 5d c1          	vminss %xmm1,%xmm0,%xmm0
  1eacad:	c5 fa 10 0d 63 a5 e3 	vmovss -0x1c5a9d(%rip),%xmm1        # 25218 <__abi_tag+0x24f1c>
  1eacb4:	ff 
  1eacb5:	c5 f8 2e c8          	vucomiss %xmm0,%xmm1
  1eacb9:	0f 86 41 ff ff ff    	jbe    1eac00 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3d90>
  1eacbf:	eb 6f                	jmp    1ead30 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3ec0>
  1eacc1:	48 83 7c 24 48 00    	cmpq   $0x0,0x48(%rsp)
  1eacc7:	0f 84 03 d1 ff ff    	je     1e7dd0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xf60>
  1eaccd:	c4 c1 7a 10 01       	vmovss (%r9),%xmm0
  1eacd2:	c4 e2 79 18 15 5d a5 	vbroadcastss -0x1c5aa3(%rip),%xmm2        # 25238 <__abi_tag+0x24f3c>
  1eacd9:	e3 ff 
  1eacdb:	c5 f8 54 c2          	vandps %xmm2,%xmm0,%xmm0
  1eacdf:	c4 c1 7a 10 08       	vmovss (%r8),%xmm1
  1eace4:	c5 f0 54 ca          	vandps %xmm2,%xmm1,%xmm1
  1eace8:	c5 fa 5f d1          	vmaxss %xmm1,%xmm0,%xmm2
  1eacec:	c5 f2 c2 c9 03       	vcmpunordss %xmm1,%xmm1,%xmm1
  1eacf1:	c4 e3 69 4a c0 10    	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  1eacf7:	c5 fa 10 0d d1 a2 e3 	vmovss -0x1c5d2f(%rip),%xmm1        # 24fd0 <__abi_tag+0x24cd4>
  1eacfe:	ff 
  1eacff:	c5 f8 2e c8          	vucomiss %xmm0,%xmm1
  1ead03:	72 1b                	jb     1ead20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3eb0>
  1ead05:	c4 c1 78 2e c7       	vucomiss %xmm15,%xmm0
  1ead0a:	75 06                	jne    1ead12 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3ea2>
  1ead0c:	0f 8b 25 04 00 00    	jnp    1eb137 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x42c7>
  1ead12:	c5 f8 2e 05 fe a4 e3 	vucomiss -0x1c5b02(%rip),%xmm0        # 25218 <__abi_tag+0x24f1c>
  1ead19:	ff 
  1ead1a:	0f 83 17 04 00 00    	jae    1eb137 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x42c7>
  1ead20:	31 c9                	xor    %ecx,%ecx
  1ead22:	8b 54 24 50          	mov    0x50(%rsp),%edx
  1ead26:	3b 4c 24 48          	cmp    0x48(%rsp),%ecx
  1ead2a:	0f 83 a4 d0 ff ff    	jae    1e7dd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xf64>
  1ead30:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
  1ead36:	74 2b                	je     1ead63 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3ef3>
  1ead38:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  1ead3d:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  1ead44:	00 
  1ead45:	31 c9                	xor    %ecx,%ecx
  1ead47:	41 8b 54 0d 00       	mov    0x0(%r13,%rcx,1),%edx
  1ead4c:	01 d2                	add    %edx,%edx
  1ead4e:	81 fa ff ff ff fe    	cmp    $0xfeffffff,%edx
  1ead54:	0f 87 d9 c8 ff ff    	ja     1e7633 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x7c3>
  1ead5a:	48 83 c1 04          	add    $0x4,%rcx
  1ead5e:	48 39 c8             	cmp    %rcx,%rax
  1ead61:	75 e4                	jne    1ead47 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3ed7>
  1ead63:	4d 85 db             	test   %r11,%r11
  1ead66:	74 25                	je     1ead8d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3f1d>
  1ead68:	4a 8d 04 9d 00 00 00 	lea    0x0(,%r11,4),%rax
  1ead6f:	00 
  1ead70:	31 c9                	xor    %ecx,%ecx
  1ead72:	41 8b 14 0a          	mov    (%r10,%rcx,1),%edx
  1ead76:	01 d2                	add    %edx,%edx
  1ead78:	81 fa ff ff ff fe    	cmp    $0xfeffffff,%edx
  1ead7e:	0f 87 af c8 ff ff    	ja     1e7633 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x7c3>
  1ead84:	48 83 c1 04          	add    $0x4,%rcx
  1ead88:	48 39 c8             	cmp    %rcx,%rax
  1ead8b:	75 e5                	jne    1ead72 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3f02>
  1ead8d:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
  1ead92:	48 83 bc 24 98 00 00 	cmpq   $0x0,0x98(%rsp)
  1ead99:	00 00 
  1ead9b:	0f 84 a3 04 00 00    	je     1eb244 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x43d4>
  1eada1:	b2 01                	mov    $0x1,%dl
  1eada3:	45 31 d2             	xor    %r10d,%r10d
  1eada6:	4c 89 d7             	mov    %r10,%rdi
  1eada9:	49 ff c2             	inc    %r10
  1eadac:	48 89 f8             	mov    %rdi,%rax
  1eadaf:	48 c1 e0 05          	shl    $0x5,%rax
  1eadb3:	4e 8d 1c 28          	lea    (%rax,%r13,1),%r11
  1eadb7:	c4 c1 7c 10 54 05 00 	vmovups 0x0(%r13,%rax,1),%ymm2
  1eadbe:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  1eadc3:	48 8d 34 01          	lea    (%rcx,%rax,1),%rsi
  1eadc7:	c5 fc 10 1c 01       	vmovups (%rcx,%rax,1),%ymm3
  1eadcc:	c4 e2 7d 18 25 63 a4 	vbroadcastss -0x1c5b9d(%rip),%ymm4        # 25238 <__abi_tag+0x24f3c>
  1eadd3:	e3 ff 
  1eadd5:	c5 ec 54 c4          	vandps %ymm4,%ymm2,%ymm0
  1eadd9:	c5 e4 54 cc          	vandps %ymm4,%ymm3,%ymm1
  1eaddd:	c5 fc 5f c1          	vmaxps %ymm1,%ymm0,%ymm0
  1eade1:	c4 e2 7d 18 0d 5e a1 	vbroadcastss -0x1c5ea2(%rip),%ymm1        # 24f48 <__abi_tag+0x24c4c>
  1eade8:	e3 ff 
  1eadea:	c5 fc c2 c9 12       	vcmple_oqps %ymm1,%ymm0,%ymm1
  1eadef:	c5 ec c2 ea 00       	vcmpeqps %ymm2,%ymm2,%ymm5
  1eadf4:	c5 e4 c2 f3 00       	vcmpeqps %ymm3,%ymm3,%ymm6
  1eadf9:	c5 d4 54 ee          	vandps %ymm6,%ymm5,%ymm5
  1eadfd:	c5 d4 54 c9          	vandps %ymm1,%ymm5,%ymm1
  1eae01:	c5 d5 76 ed          	vpcmpeqd %ymm5,%ymm5,%ymm5
  1eae05:	c4 e2 7d 17 cd       	vptest %ymm5,%ymm1
  1eae0a:	0f 83 38 06 00 00    	jae    1eb448 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x45d8>
  1eae10:	48 c1 e7 03          	shl    $0x3,%rdi
  1eae14:	eb 33                	jmp    1eae49 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3fd9>
  1eae16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  1eae1d:	00 00 00 
  1eae20:	c4 e2 7d 18 0d 0f a3 	vbroadcastss -0x1c5cf1(%rip),%ymm1        # 25138 <__abi_tag+0x24e3c>
  1eae27:	e3 ff 
  1eae29:	c5 ec 59 c1          	vmulps %ymm1,%ymm2,%ymm0
  1eae2d:	c4 e3 6d 4a d0 50    	vblendvps %ymm5,%ymm0,%ymm2,%ymm2
  1eae33:	c5 e4 59 c1          	vmulps %ymm1,%ymm3,%ymm0
  1eae37:	c4 e3 65 4a d8 50    	vblendvps %ymm5,%ymm0,%ymm3,%ymm3
  1eae3d:	c5 ec 54 c4          	vandps %ymm4,%ymm2,%ymm0
  1eae41:	c5 e4 54 cc          	vandps %ymm4,%ymm3,%ymm1
  1eae45:	c5 fc 5f c1          	vmaxps %ymm1,%ymm0,%ymm0
  1eae49:	c4 e2 7d 18 0d 7e a1 	vbroadcastss -0x1c5e82(%rip),%ymm1        # 24fd0 <__abi_tag+0x24cd4>
  1eae50:	e3 ff 
  1eae52:	c5 fc c2 e9 1e       	vcmpgt_oqps %ymm1,%ymm0,%ymm5
  1eae57:	c4 e2 7d 17 ed       	vptest %ymm5,%ymm5
  1eae5c:	0f 84 f7 00 00 00    	je     1eaf59 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x40e9>
  1eae62:	c5 7c 11 84 24 10 02 	vmovups %ymm8,0x210(%rsp)
  1eae69:	00 00 
  1eae6b:	c5 7c 11 84 24 f0 01 	vmovups %ymm8,0x1f0(%rsp)
  1eae72:	00 00 
  1eae74:	c5 7c 11 84 24 d0 01 	vmovups %ymm8,0x1d0(%rsp)
  1eae7b:	00 00 
  1eae7d:	c5 7c 11 84 24 b0 01 	vmovups %ymm8,0x1b0(%rsp)
  1eae84:	00 00 
  1eae86:	c4 e2 7d 18 05 49 a0 	vbroadcastss -0x1c5fb7(%rip),%ymm0        # 24ed8 <__abi_tag+0x24bdc>
  1eae8d:	e3 ff 
  1eae8f:	c5 d4 54 c0          	vandps %ymm0,%ymm5,%ymm0
  1eae93:	48 8b 05 fe 87 13 00 	mov    0x1387fe(%rip),%rax        # 323698 <_DYNAMIC+0x448>
  1eae9a:	48 8b 98 08 08 00 00 	mov    0x808(%rax),%rbx
  1eaea1:	48 8d 84 24 b0 01 00 	lea    0x1b0(%rsp),%rax
  1eaea8:	00 
  1eaea9:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1eaeb2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4042>
  1eaeb0:	ff e3                	jmp    *%rbx
  1eaeb2:	c5 fe 6f 84 24 b0 01 	vmovdqu 0x1b0(%rsp),%ymm0
  1eaeb9:	00 00 
  1eaebb:	c4 e2 7d 45 05 bc a9 	vpsrlvd -0x1c5644(%rip),%ymm0,%ymm0        # 25880 <__abi_tag+0x25584>
  1eaec2:	e3 ff 
  1eaec4:	c5 fd db 05 b4 ab e3 	vpand  -0x1c544c(%rip),%ymm0,%ymm0        # 25a80 <__abi_tag+0x25784>
  1eaecb:	ff 
  1eaecc:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
  1eaed2:	c5 f9 eb c1          	vpor   %xmm1,%xmm0,%xmm0
  1eaed6:	c5 f9 70 c8 ee       	vpshufd $0xee,%xmm0,%xmm1
  1eaedb:	c5 f9 eb c1          	vpor   %xmm1,%xmm0,%xmm0
  1eaedf:	c5 f9 70 c8 55       	vpshufd $0x55,%xmm0,%xmm1
  1eaee4:	c5 f9 eb c1          	vpor   %xmm1,%xmm0,%xmm0
  1eaee8:	c5 f9 7e c1          	vmovd  %xmm0,%ecx
  1eaeec:	85 c9                	test   %ecx,%ecx
  1eaeee:	0f 84 2c ff ff ff    	je     1eae20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3fb0>
  1eaef4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1eaefb:	00 00 00 00 00 
  1eaf00:	31 c0                	xor    %eax,%eax
  1eaf02:	f3 0f bc c1          	tzcnt  %ecx,%eax
  1eaf06:	48 01 f8             	add    %rdi,%rax
  1eaf09:	4c 39 f0             	cmp    %r14,%rax
  1eaf0c:	0f 83 32 13 00 00    	jae    1ec244 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x53d4>
  1eaf12:	49 8b 1c c4          	mov    (%r12,%rax,8),%rbx
  1eaf16:	48 83 c3 50          	add    $0x50,%rbx
  1eaf1a:	0f 80 19 11 00 00    	jo     1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1eaf20:	49 89 1c c4          	mov    %rbx,(%r12,%rax,8)
  1eaf24:	c4 e2 70 f3 c9       	blsr   %ecx,%ecx
  1eaf29:	75 d5                	jne    1eaf00 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4090>
  1eaf2b:	e9 f0 fe ff ff       	jmp    1eae20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3fb0>
  1eaf30:	c4 e2 7d 18 0d 67 a0 	vbroadcastss -0x1c5f99(%rip),%ymm1        # 24fa0 <__abi_tag+0x24ca4>
  1eaf37:	e3 ff 
  1eaf39:	c5 ec 59 c1          	vmulps %ymm1,%ymm2,%ymm0
  1eaf3d:	c4 e3 6d 4a d0 50    	vblendvps %ymm5,%ymm0,%ymm2,%ymm2
  1eaf43:	c5 e4 59 c1          	vmulps %ymm1,%ymm3,%ymm0
  1eaf47:	c4 e3 65 4a d8 50    	vblendvps %ymm5,%ymm0,%ymm3,%ymm3
  1eaf4d:	c5 ec 54 c4          	vandps %ymm4,%ymm2,%ymm0
  1eaf51:	c5 e4 54 cc          	vandps %ymm4,%ymm3,%ymm1
  1eaf55:	c5 fc 5f c1          	vmaxps %ymm1,%ymm0,%ymm0
  1eaf59:	c5 bc c2 c8 00       	vcmpeqps %ymm0,%ymm8,%ymm1
  1eaf5e:	c4 e2 7d 18 2d b1 a2 	vbroadcastss -0x1c5d4f(%rip),%ymm5        # 25218 <__abi_tag+0x24f1c>
  1eaf65:	e3 ff 
  1eaf67:	c5 fc c2 ed 11       	vcmplt_oqps %ymm5,%ymm0,%ymm5
  1eaf6c:	c5 f4 55 ed          	vandnps %ymm5,%ymm1,%ymm5
  1eaf70:	c4 e2 7d 17 ed       	vptest %ymm5,%ymm5
  1eaf75:	0f 84 c5 00 00 00    	je     1eb040 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x41d0>
  1eaf7b:	c5 7c 11 84 24 10 02 	vmovups %ymm8,0x210(%rsp)
  1eaf82:	00 00 
  1eaf84:	c5 7c 11 84 24 f0 01 	vmovups %ymm8,0x1f0(%rsp)
  1eaf8b:	00 00 
  1eaf8d:	c5 7c 11 84 24 d0 01 	vmovups %ymm8,0x1d0(%rsp)
  1eaf94:	00 00 
  1eaf96:	c5 7c 11 84 24 b0 01 	vmovups %ymm8,0x1b0(%rsp)
  1eaf9d:	00 00 
  1eaf9f:	c4 e2 7d 18 05 30 9f 	vbroadcastss -0x1c60d0(%rip),%ymm0        # 24ed8 <__abi_tag+0x24bdc>
  1eafa6:	e3 ff 
  1eafa8:	c5 d4 54 c0          	vandps %ymm0,%ymm5,%ymm0
  1eafac:	48 8b 05 e5 86 13 00 	mov    0x1386e5(%rip),%rax        # 323698 <_DYNAMIC+0x448>
  1eafb3:	48 8b 98 08 08 00 00 	mov    0x808(%rax),%rbx
  1eafba:	48 8d 84 24 b0 01 00 	lea    0x1b0(%rsp),%rax
  1eafc1:	00 
  1eafc2:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1eafcb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x415b>
  1eafc9:	ff e3                	jmp    *%rbx
  1eafcb:	c5 fe 6f 84 24 b0 01 	vmovdqu 0x1b0(%rsp),%ymm0
  1eafd2:	00 00 
  1eafd4:	c4 e2 7d 45 05 a3 a8 	vpsrlvd -0x1c575d(%rip),%ymm0,%ymm0        # 25880 <__abi_tag+0x25584>
  1eafdb:	e3 ff 
  1eafdd:	c5 fd db 05 9b aa e3 	vpand  -0x1c5565(%rip),%ymm0,%ymm0        # 25a80 <__abi_tag+0x25784>
  1eafe4:	ff 
  1eafe5:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
  1eafeb:	c5 f9 eb c1          	vpor   %xmm1,%xmm0,%xmm0
  1eafef:	c5 f9 70 c8 ee       	vpshufd $0xee,%xmm0,%xmm1
  1eaff4:	c5 f9 eb c1          	vpor   %xmm1,%xmm0,%xmm0
  1eaff8:	c5 f9 70 c8 55       	vpshufd $0x55,%xmm0,%xmm1
  1eaffd:	c5 f9 eb c1          	vpor   %xmm1,%xmm0,%xmm0
  1eb001:	c5 f9 7e c1          	vmovd  %xmm0,%ecx
  1eb005:	85 c9                	test   %ecx,%ecx
  1eb007:	0f 84 23 ff ff ff    	je     1eaf30 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x40c0>
  1eb00d:	0f 1f 00             	nopl   (%rax)
  1eb010:	31 c0                	xor    %eax,%eax
  1eb012:	f3 0f bc c1          	tzcnt  %ecx,%eax
  1eb016:	48 01 f8             	add    %rdi,%rax
  1eb019:	4c 39 f0             	cmp    %r14,%rax
  1eb01c:	0f 83 22 12 00 00    	jae    1ec244 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x53d4>
  1eb022:	49 8b 1c c4          	mov    (%r12,%rax,8),%rbx
  1eb026:	48 83 c3 b0          	add    $0xffffffffffffffb0,%rbx
  1eb02a:	0f 80 09 10 00 00    	jo     1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1eb030:	49 89 1c c4          	mov    %rbx,(%r12,%rax,8)
  1eb034:	c4 e2 70 f3 c9       	blsr   %ecx,%ecx
  1eb039:	75 d5                	jne    1eb010 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x41a0>
  1eb03b:	e9 f0 fe ff ff       	jmp    1eaf30 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x40c0>
  1eb040:	c4 c1 7c 11 13       	vmovups %ymm2,(%r11)
  1eb045:	c5 fc 11 1e          	vmovups %ymm3,(%rsi)
  1eb049:	f6 c2 01             	test   $0x1,%dl
  1eb04c:	74 4f                	je     1eb09d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x422d>
  1eb04e:	4a 8d 34 d5 00 00 00 	lea    0x0(,%r10,8),%rsi
  1eb055:	00 
  1eb056:	4c 39 f6             	cmp    %r14,%rsi
  1eb059:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1eb05e:	0f 87 3d 12 00 00    	ja     1ec2a1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5431>
  1eb064:	49 83 3c fc 00       	cmpq   $0x0,(%r12,%rdi,8)
  1eb069:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1eb06e:	75 18                	jne    1eb088 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4218>
  1eb070:	49 83 7c fc 08 00    	cmpq   $0x0,0x8(%r12,%rdi,8)
  1eb076:	75 10                	jne    1eb088 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4218>
  1eb078:	49 83 7c fc 10 00    	cmpq   $0x0,0x10(%r12,%rdi,8)
  1eb07e:	75 08                	jne    1eb088 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4218>
  1eb080:	49 83 7c fc 18 00    	cmpq   $0x0,0x18(%r12,%rdi,8)
  1eb086:	74 34                	je     1eb0bc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x424c>
  1eb088:	31 d2                	xor    %edx,%edx
  1eb08a:	4c 3b 94 24 98 00 00 	cmp    0x98(%rsp),%r10
  1eb091:	00 
  1eb092:	0f 85 0e fd ff ff    	jne    1eada6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3f36>
  1eb098:	e9 a9 01 00 00       	jmp    1eb246 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x43d6>
  1eb09d:	31 d2                	xor    %edx,%edx
  1eb09f:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1eb0a4:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1eb0a9:	4c 3b 94 24 98 00 00 	cmp    0x98(%rsp),%r10
  1eb0b0:	00 
  1eb0b1:	0f 85 ef fc ff ff    	jne    1eada6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3f36>
  1eb0b7:	e9 8a 01 00 00       	jmp    1eb246 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x43d6>
  1eb0bc:	49 83 7c fc 20 00    	cmpq   $0x0,0x20(%r12,%rdi,8)
  1eb0c2:	75 18                	jne    1eb0dc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x426c>
  1eb0c4:	49 83 7c fc 28 00    	cmpq   $0x0,0x28(%r12,%rdi,8)
  1eb0ca:	75 10                	jne    1eb0dc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x426c>
  1eb0cc:	49 83 7c fc 30 00    	cmpq   $0x0,0x30(%r12,%rdi,8)
  1eb0d2:	75 08                	jne    1eb0dc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x426c>
  1eb0d4:	49 83 7c fc 38 00    	cmpq   $0x0,0x38(%r12,%rdi,8)
  1eb0da:	74 29                	je     1eb105 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4295>
  1eb0dc:	31 d2                	xor    %edx,%edx
  1eb0de:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1eb0e3:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1eb0e8:	c4 41 00 57 ff       	vxorps %xmm15,%xmm15,%xmm15
  1eb0ed:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
  1eb0f2:	4c 3b 94 24 98 00 00 	cmp    0x98(%rsp),%r10
  1eb0f9:	00 
  1eb0fa:	0f 85 a6 fc ff ff    	jne    1eada6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3f36>
  1eb100:	e9 41 01 00 00       	jmp    1eb246 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x43d6>
  1eb105:	c4 e2 7d 18 15 c2 9e 	vbroadcastss -0x1c613e(%rip),%ymm2        # 24fd0 <__abi_tag+0x24cd4>
  1eb10c:	e3 ff 
  1eb10e:	c5 fc c2 d2 12       	vcmple_oqps %ymm2,%ymm0,%ymm2
  1eb113:	c4 e2 7d 18 1d fc a0 	vbroadcastss -0x1c5f04(%rip),%ymm3        # 25218 <__abi_tag+0x24f1c>
  1eb11a:	e3 ff 
  1eb11c:	c5 fc c2 c3 1d       	vcmpge_oqps %ymm3,%ymm0,%ymm0
  1eb121:	c5 fc 56 c1          	vorps  %ymm1,%ymm0,%ymm0
  1eb125:	c5 fc 54 c2          	vandps %ymm2,%ymm0,%ymm0
  1eb129:	c5 f5 76 c9          	vpcmpeqd %ymm1,%ymm1,%ymm1
  1eb12d:	c4 e2 7d 17 c1       	vptest %ymm1,%ymm0
  1eb132:	0f 92 c2             	setb   %dl
  1eb135:	eb a7                	jmp    1eb0de <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x426e>
  1eb137:	83 7c 24 48 01       	cmpl   $0x1,0x48(%rsp)
  1eb13c:	0f 84 8e cc ff ff    	je     1e7dd0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xf60>
  1eb142:	c4 c1 7a 10 41 04    	vmovss 0x4(%r9),%xmm0
  1eb148:	c4 e2 79 18 15 e7 a0 	vbroadcastss -0x1c5f19(%rip),%xmm2        # 25238 <__abi_tag+0x24f3c>
  1eb14f:	e3 ff 
  1eb151:	c5 f8 54 c2          	vandps %xmm2,%xmm0,%xmm0
  1eb155:	c4 c1 7a 10 48 04    	vmovss 0x4(%r8),%xmm1
  1eb15b:	c5 f0 54 ca          	vandps %xmm2,%xmm1,%xmm1
  1eb15f:	c5 fa 5f d1          	vmaxss %xmm1,%xmm0,%xmm2
  1eb163:	c5 f2 c2 c9 03       	vcmpunordss %xmm1,%xmm1,%xmm1
  1eb168:	c4 e3 69 4a c0 10    	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  1eb16e:	b9 01 00 00 00       	mov    $0x1,%ecx
  1eb173:	c5 fa 10 0d 55 9e e3 	vmovss -0x1c61ab(%rip),%xmm1        # 24fd0 <__abi_tag+0x24cd4>
  1eb17a:	ff 
  1eb17b:	c5 f8 2e c8          	vucomiss %xmm0,%xmm1
  1eb17f:	0f 82 9d fb ff ff    	jb     1ead22 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3eb2>
  1eb185:	c4 c1 78 2e c7       	vucomiss %xmm15,%xmm0
  1eb18a:	75 02                	jne    1eb18e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x431e>
  1eb18c:	7b 0e                	jnp    1eb19c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x432c>
  1eb18e:	c5 f8 2e 05 82 a0 e3 	vucomiss -0x1c5f7e(%rip),%xmm0        # 25218 <__abi_tag+0x24f1c>
  1eb195:	ff 
  1eb196:	0f 82 86 fb ff ff    	jb     1ead22 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3eb2>
  1eb19c:	83 7c 24 48 02       	cmpl   $0x2,0x48(%rsp)
  1eb1a1:	0f 84 29 cc ff ff    	je     1e7dd0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xf60>
  1eb1a7:	c4 c1 7a 10 41 08    	vmovss 0x8(%r9),%xmm0
  1eb1ad:	c4 e2 79 18 15 82 a0 	vbroadcastss -0x1c5f7e(%rip),%xmm2        # 25238 <__abi_tag+0x24f3c>
  1eb1b4:	e3 ff 
  1eb1b6:	c5 f8 54 c2          	vandps %xmm2,%xmm0,%xmm0
  1eb1ba:	c4 c1 7a 10 48 08    	vmovss 0x8(%r8),%xmm1
  1eb1c0:	c5 f0 54 ca          	vandps %xmm2,%xmm1,%xmm1
  1eb1c4:	c5 fa 5f d1          	vmaxss %xmm1,%xmm0,%xmm2
  1eb1c8:	c5 f2 c2 c9 03       	vcmpunordss %xmm1,%xmm1,%xmm1
  1eb1cd:	c4 e3 69 4a c0 10    	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  1eb1d3:	b9 02 00 00 00       	mov    $0x2,%ecx
  1eb1d8:	c5 fa 10 0d f0 9d e3 	vmovss -0x1c6210(%rip),%xmm1        # 24fd0 <__abi_tag+0x24cd4>
  1eb1df:	ff 
  1eb1e0:	c5 f8 2e c8          	vucomiss %xmm0,%xmm1
  1eb1e4:	0f 82 38 fb ff ff    	jb     1ead22 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3eb2>
  1eb1ea:	c4 c1 78 2e c7       	vucomiss %xmm15,%xmm0
  1eb1ef:	75 02                	jne    1eb1f3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4383>
  1eb1f1:	7b 0e                	jnp    1eb201 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4391>
  1eb1f3:	c5 f8 2e 05 1d a0 e3 	vucomiss -0x1c5fe3(%rip),%xmm0        # 25218 <__abi_tag+0x24f1c>
  1eb1fa:	ff 
  1eb1fb:	0f 82 21 fb ff ff    	jb     1ead22 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3eb2>
  1eb201:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
  1eb206:	4c 89 e8             	mov    %r13,%rax
  1eb209:	4c 89 d7             	mov    %r10,%rdi
  1eb20c:	83 7c 24 48 03       	cmpl   $0x3,0x48(%rsp)
  1eb211:	0f 85 38 09 00 00    	jne    1ebb4f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4cdf>
  1eb217:	8b 54 24 50          	mov    0x50(%rsp),%edx
  1eb21b:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1eb220:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1eb225:	49 89 fa             	mov    %rdi,%r10
  1eb228:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1eb22d:	49 89 c5             	mov    %rax,%r13
  1eb230:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1eb235:	c4 41 00 57 ff       	vxorps %xmm15,%xmm15,%xmm15
  1eb23a:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
  1eb23f:	e9 90 cb ff ff       	jmp    1e7dd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xf64>
  1eb244:	b2 01                	mov    $0x1,%dl
  1eb246:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  1eb24b:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
  1eb24f:	4c 89 f7             	mov    %r14,%rdi
  1eb252:	48 29 c7             	sub    %rax,%rdi
  1eb255:	0f 82 cc 0e 00 00    	jb     1ec127 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x52b7>
  1eb25b:	48 83 7c 24 48 00    	cmpq   $0x0,0x48(%rsp)
  1eb261:	c5 fa 10 1d cf 9e e3 	vmovss -0x1c6131(%rip),%xmm3        # 25138 <__abi_tag+0x24e3c>
  1eb268:	ff 
  1eb269:	0f 84 bf 08 00 00    	je     1ebb2e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4cbe>
  1eb26f:	49 8d 0c c4          	lea    (%r12,%rax,8),%rcx
  1eb273:	31 c0                	xor    %eax,%eax
  1eb275:	eb 1b                	jmp    1eb292 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4422>
  1eb277:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1eb27c:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1eb281:	44 20 d2             	and    %r10b,%dl
  1eb284:	48 ff c0             	inc    %rax
  1eb287:	48 3b 44 24 48       	cmp    0x48(%rsp),%rax
  1eb28c:	0f 84 9c 08 00 00    	je     1ebb2e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4cbe>
  1eb292:	48 39 f8             	cmp    %rdi,%rax
  1eb295:	0f 84 08 13 00 00    	je     1ec5a3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5733>
  1eb29b:	41 8b 34 81          	mov    (%r9,%rax,4),%esi
  1eb29f:	c5 f9 6e c6          	vmovd  %esi,%xmm0
  1eb2a3:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
  1eb2a9:	45 8b 14 80          	mov    (%r8,%rax,4),%r10d
  1eb2ad:	c4 c1 79 6e ca       	vmovd  %r10d,%xmm1
  1eb2b2:	41 81 e2 ff ff ff 7f 	and    $0x7fffffff,%r10d
  1eb2b9:	41 39 f2             	cmp    %esi,%r10d
  1eb2bc:	44 0f 46 d6          	cmovbe %esi,%r10d
  1eb2c0:	41 81 fa 01 00 80 53 	cmp    $0x53800001,%r10d
  1eb2c7:	72 57                	jb     1eb320 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x44b0>
  1eb2c9:	4c 8b 1c c1          	mov    (%rcx,%rax,8),%r11
  1eb2cd:	c5 fa 59 c3          	vmulss %xmm3,%xmm0,%xmm0
  1eb2d1:	c5 f2 59 cb          	vmulss %xmm3,%xmm1,%xmm1
  1eb2d5:	49 83 c3 50          	add    $0x50,%r11
  1eb2d9:	0f 80 22 0e 00 00    	jo     1ec101 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5291>
  1eb2df:	c4 c1 79 6e d2       	vmovd  %r10d,%xmm2
  1eb2e4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1eb2eb:	00 00 00 00 00 
  1eb2f0:	4c 89 db             	mov    %r11,%rbx
  1eb2f3:	c5 ea 59 d3          	vmulss %xmm3,%xmm2,%xmm2
  1eb2f7:	c4 c1 79 7e d2       	vmovd  %xmm2,%r10d
  1eb2fc:	44 89 d6             	mov    %r10d,%esi
  1eb2ff:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
  1eb305:	81 fe 00 00 80 53    	cmp    $0x53800000,%esi
  1eb30b:	76 18                	jbe    1eb325 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x44b5>
  1eb30d:	c5 fa 59 c3          	vmulss %xmm3,%xmm0,%xmm0
  1eb311:	c5 f2 59 cb          	vmulss %xmm3,%xmm1,%xmm1
  1eb315:	49 83 c3 50          	add    $0x50,%r11
  1eb319:	71 d5                	jno    1eb2f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4480>
  1eb31b:	e9 dd 0d 00 00       	jmp    1ec0fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x528d>
  1eb320:	44 89 d6             	mov    %r10d,%esi
  1eb323:	eb 10                	jmp    1eb335 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x44c5>
  1eb325:	48 89 1c c1          	mov    %rbx,(%rcx,%rax,8)
  1eb329:	c4 c1 7a 11 04 81    	vmovss %xmm0,(%r9,%rax,4)
  1eb32f:	c4 c1 7a 11 0c 80    	vmovss %xmm1,(%r8,%rax,4)
  1eb335:	44 8d 5e ff          	lea    -0x1(%rsi),%r11d
  1eb339:	41 81 fb fe ff 7f 2b 	cmp    $0x2b7ffffe,%r11d
  1eb340:	77 6d                	ja     1eb3af <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x453f>
  1eb342:	4c 8b 1c c1          	mov    (%rcx,%rax,8),%r11
  1eb346:	c5 fa 10 25 52 9c e3 	vmovss -0x1c63ae(%rip),%xmm4        # 24fa0 <__abi_tag+0x24ca4>
  1eb34d:	ff 
  1eb34e:	c5 fa 59 d4          	vmulss %xmm4,%xmm0,%xmm2
  1eb352:	c5 f2 59 c4          	vmulss %xmm4,%xmm1,%xmm0
  1eb356:	49 83 c3 b0          	add    $0xffffffffffffffb0,%r11
  1eb35a:	0f 80 b6 0d 00 00    	jo     1ec116 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x52a6>
  1eb360:	c4 c1 79 6e ca       	vmovd  %r10d,%xmm1
  1eb365:	c5 fa 10 25 33 9c e3 	vmovss -0x1c63cd(%rip),%xmm4        # 24fa0 <__abi_tag+0x24ca4>
  1eb36c:	ff 
  1eb36d:	0f 1f 00             	nopl   (%rax)
  1eb370:	4d 89 da             	mov    %r11,%r10
  1eb373:	c5 f2 59 cc          	vmulss %xmm4,%xmm1,%xmm1
  1eb377:	c5 f9 7e ce          	vmovd  %xmm1,%esi
  1eb37b:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
  1eb381:	8d 5e ff             	lea    -0x1(%rsi),%ebx
  1eb384:	81 fb ff ff 7f 2b    	cmp    $0x2b7fffff,%ebx
  1eb38a:	73 13                	jae    1eb39f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x452f>
  1eb38c:	c5 ea 59 d4          	vmulss %xmm4,%xmm2,%xmm2
  1eb390:	c5 fa 59 c4          	vmulss %xmm4,%xmm0,%xmm0
  1eb394:	49 83 c3 b0          	add    $0xffffffffffffffb0,%r11
  1eb398:	71 d6                	jno    1eb370 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4500>
  1eb39a:	e9 73 0d 00 00       	jmp    1ec112 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x52a2>
  1eb39f:	4c 89 14 c1          	mov    %r10,(%rcx,%rax,8)
  1eb3a3:	c4 c1 7a 11 14 81    	vmovss %xmm2,(%r9,%rax,4)
  1eb3a9:	c4 c1 7a 11 04 80    	vmovss %xmm0,(%r8,%rax,4)
  1eb3af:	45 31 d2             	xor    %r10d,%r10d
  1eb3b2:	81 fe 00 00 80 53    	cmp    $0x53800000,%esi
  1eb3b8:	0f 87 b9 fe ff ff    	ja     1eb277 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4407>
  1eb3be:	48 83 3c c1 00       	cmpq   $0x0,(%rcx,%rax,8)
  1eb3c3:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1eb3c8:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1eb3cd:	0f 85 ae fe ff ff    	jne    1eb281 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4411>
  1eb3d3:	85 f6                	test   %esi,%esi
  1eb3d5:	74 0f                	je     1eb3e6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4576>
  1eb3d7:	81 fe 00 00 80 2b    	cmp    $0x2b800000,%esi
  1eb3dd:	41 0f 93 c2          	setae  %r10b
  1eb3e1:	e9 9b fe ff ff       	jmp    1eb281 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4411>
  1eb3e6:	41 b2 01             	mov    $0x1,%r10b
  1eb3e9:	e9 93 fe ff ff       	jmp    1eb281 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4411>
  1eb3ee:	b1 82                	mov    $0x82,%cl
  1eb3f0:	44 28 d9             	sub    %r11b,%cl
  1eb3f3:	c4 c2 73 f7 d2       	shrx   %ecx,%r10d,%edx
  1eb3f8:	c4 c2 70 f5 f2       	bzhi   %ecx,%r10d,%esi
  1eb3fd:	b1 81                	mov    $0x81,%cl
  1eb3ff:	44 28 d9             	sub    %r11b,%cl
  1eb402:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  1eb408:	c4 42 71 f7 d3       	shlx   %ecx,%r11d,%r10d
  1eb40d:	31 c9                	xor    %ecx,%ecx
  1eb40f:	44 39 d6             	cmp    %r10d,%esi
  1eb412:	0f 94 c1             	sete   %cl
  1eb415:	21 d1                	and    %edx,%ecx
  1eb417:	44 39 d6             	cmp    %r10d,%esi
  1eb41a:	41 0f 47 cb          	cmova  %r11d,%ecx
  1eb41e:	01 d1                	add    %edx,%ecx
  1eb420:	81 f9 ff ff 7f 00    	cmp    $0x7fffff,%ecx
  1eb426:	76 09                	jbe    1eb431 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x45c1>
  1eb428:	41 81 c9 00 00 80 00 	or     $0x800000,%r9d
  1eb42f:	eb 03                	jmp    1eb434 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x45c4>
  1eb431:	41 09 c9             	or     %ecx,%r9d
  1eb434:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  1eb439:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1eb43e:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
  1eb443:	e9 ee f2 ff ff       	jmp    1ea736 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x38c6>
  1eb448:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
  1eb44d:	c5 7c 11 84 24 90 05 	vmovups %ymm8,0x590(%rsp)
  1eb454:	00 00 
  1eb456:	c5 7c 11 84 24 70 05 	vmovups %ymm8,0x570(%rsp)
  1eb45d:	00 00 
  1eb45f:	c5 7c 11 84 24 50 05 	vmovups %ymm8,0x550(%rsp)
  1eb466:	00 00 
  1eb468:	c5 7c 11 84 24 30 05 	vmovups %ymm8,0x530(%rsp)
  1eb46f:	00 00 
  1eb471:	c5 7c 11 84 24 10 05 	vmovups %ymm8,0x510(%rsp)
  1eb478:	00 00 
  1eb47a:	c5 7c 11 84 24 f0 04 	vmovups %ymm8,0x4f0(%rsp)
  1eb481:	00 00 
  1eb483:	c5 7c 11 84 24 d0 04 	vmovups %ymm8,0x4d0(%rsp)
  1eb48a:	00 00 
  1eb48c:	c5 7c 11 84 24 b0 04 	vmovups %ymm8,0x4b0(%rsp)
  1eb493:	00 00 
  1eb495:	c5 7c 11 84 24 90 03 	vmovups %ymm8,0x390(%rsp)
  1eb49c:	00 00 
  1eb49e:	c5 7c 11 84 24 70 03 	vmovups %ymm8,0x370(%rsp)
  1eb4a5:	00 00 
  1eb4a7:	c5 7c 11 84 24 50 03 	vmovups %ymm8,0x350(%rsp)
  1eb4ae:	00 00 
  1eb4b0:	c5 7c 11 84 24 30 03 	vmovups %ymm8,0x330(%rsp)
  1eb4b7:	00 00 
  1eb4b9:	c5 7c 11 84 24 10 03 	vmovups %ymm8,0x310(%rsp)
  1eb4c0:	00 00 
  1eb4c2:	c5 7c 11 84 24 f0 02 	vmovups %ymm8,0x2f0(%rsp)
  1eb4c9:	00 00 
  1eb4cb:	c5 7c 11 84 24 d0 02 	vmovups %ymm8,0x2d0(%rsp)
  1eb4d2:	00 00 
  1eb4d4:	c5 7c 11 84 24 b0 02 	vmovups %ymm8,0x2b0(%rsp)
  1eb4db:	00 00 
  1eb4dd:	c4 c1 7c 10 03       	vmovups (%r11),%ymm0
  1eb4e2:	48 8b 1d af 81 13 00 	mov    0x1381af(%rip),%rbx        # 323698 <_DYNAMIC+0x448>
  1eb4e9:	48 8b 93 08 08 00 00 	mov    0x808(%rbx),%rdx
  1eb4f0:	48 8d 84 24 b0 04 00 	lea    0x4b0(%rsp),%rax
  1eb4f7:	00 
  1eb4f8:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1eb501 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4691>
  1eb4ff:	ff e2                	jmp    *%rdx
  1eb501:	c5 fc 10 06          	vmovups (%rsi),%ymm0
  1eb505:	48 8b 93 08 08 00 00 	mov    0x808(%rbx),%rdx
  1eb50c:	48 8d 84 24 b0 02 00 	lea    0x2b0(%rsp),%rax
  1eb513:	00 
  1eb514:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1eb51d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x46ad>
  1eb51b:	ff e2                	jmp    *%rdx
  1eb51d:	48 8d 04 fd 07 00 00 	lea    0x7(,%rdi,8),%rax
  1eb524:	00 
  1eb525:	48 c1 e7 03          	shl    $0x3,%rdi
  1eb529:	4c 39 f0             	cmp    %r14,%rax
  1eb52c:	0f 83 61 0f 00 00    	jae    1ec493 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5623>
  1eb532:	49 8d 0c fc          	lea    (%r12,%rdi,8),%rcx
  1eb536:	b2 01                	mov    $0x1,%dl
  1eb538:	31 c0                	xor    %eax,%eax
  1eb53a:	c5 fa 10 1d f6 9b e3 	vmovss -0x1c640a(%rip),%xmm3        # 25138 <__abi_tag+0x24e3c>
  1eb541:	ff 
  1eb542:	c5 fa 10 25 56 9a e3 	vmovss -0x1c65aa(%rip),%xmm4        # 24fa0 <__abi_tag+0x24ca4>
  1eb549:	ff 
  1eb54a:	eb 1a                	jmp    1eb566 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x46f6>
  1eb54c:	81 fb 00 00 80 2b    	cmp    $0x2b800000,%ebx
  1eb552:	40 0f 93 c7          	setae  %dil
  1eb556:	40 20 fa             	and    %dil,%dl
  1eb559:	48 ff c0             	inc    %rax
  1eb55c:	48 83 f8 08          	cmp    $0x8,%rax
  1eb560:	0f 84 2f 01 00 00    	je     1eb695 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4825>
  1eb566:	8b bc 84 b0 04 00 00 	mov    0x4b0(%rsp,%rax,4),%edi
  1eb56d:	89 fb                	mov    %edi,%ebx
  1eb56f:	81 e3 ff ff ff 7f    	and    $0x7fffffff,%ebx
  1eb575:	44 8b bc 84 b0 02 00 	mov    0x2b0(%rsp,%rax,4),%r15d
  1eb57c:	00 
  1eb57d:	44 89 fd             	mov    %r15d,%ebp
  1eb580:	81 e5 ff ff ff 7f    	and    $0x7fffffff,%ebp
  1eb586:	39 dd                	cmp    %ebx,%ebp
  1eb588:	0f 46 eb             	cmovbe %ebx,%ebp
  1eb58b:	c5 f9 6e cf          	vmovd  %edi,%xmm1
  1eb58f:	c4 c1 79 6e c7       	vmovd  %r15d,%xmm0
  1eb594:	4c 8b 3c c1          	mov    (%rcx,%rax,8),%r15
  1eb598:	81 fd 01 00 80 53    	cmp    $0x53800001,%ebp
  1eb59e:	72 44                	jb     1eb5e4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4774>
  1eb5a0:	c5 f2 59 cb          	vmulss %xmm3,%xmm1,%xmm1
  1eb5a4:	c5 fa 59 c3          	vmulss %xmm3,%xmm0,%xmm0
  1eb5a8:	49 83 c7 50          	add    $0x50,%r15
  1eb5ac:	0f 80 98 0b 00 00    	jo     1ec14a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x52da>
  1eb5b2:	c5 f9 6e d5          	vmovd  %ebp,%xmm2
  1eb5b6:	4c 89 ff             	mov    %r15,%rdi
  1eb5b9:	c5 ea 59 d3          	vmulss %xmm3,%xmm2,%xmm2
  1eb5bd:	c5 f9 7e d5          	vmovd  %xmm2,%ebp
  1eb5c1:	89 eb                	mov    %ebp,%ebx
  1eb5c3:	81 e3 ff ff ff 7f    	and    $0x7fffffff,%ebx
  1eb5c9:	81 fb 00 00 80 53    	cmp    $0x53800000,%ebx
  1eb5cf:	76 1a                	jbe    1eb5eb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x477b>
  1eb5d1:	c5 f2 59 cb          	vmulss %xmm3,%xmm1,%xmm1
  1eb5d5:	c5 fa 59 c3          	vmulss %xmm3,%xmm0,%xmm0
  1eb5d9:	49 83 c7 50          	add    $0x50,%r15
  1eb5dd:	71 d7                	jno    1eb5b6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4746>
  1eb5df:	e9 5c 0b 00 00       	jmp    1ec140 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x52d0>
  1eb5e4:	4c 89 ff             	mov    %r15,%rdi
  1eb5e7:	89 eb                	mov    %ebp,%ebx
  1eb5e9:	eb 16                	jmp    1eb601 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4791>
  1eb5eb:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
  1eb5ef:	c5 fa 11 8c 84 b0 04 	vmovss %xmm1,0x4b0(%rsp,%rax,4)
  1eb5f6:	00 00 
  1eb5f8:	c5 fa 11 84 84 b0 02 	vmovss %xmm0,0x2b0(%rsp,%rax,4)
  1eb5ff:	00 00 
  1eb601:	44 8d 7b ff          	lea    -0x1(%rbx),%r15d
  1eb605:	41 81 ff fe ff 7f 2b 	cmp    $0x2b7ffffe,%r15d
  1eb60c:	77 45                	ja     1eb653 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x47e3>
  1eb60e:	c5 f2 59 cc          	vmulss %xmm4,%xmm1,%xmm1
  1eb612:	c5 fa 59 c4          	vmulss %xmm4,%xmm0,%xmm0
  1eb616:	48 83 c7 b0          	add    $0xffffffffffffffb0,%rdi
  1eb61a:	0f 80 2a 0b 00 00    	jo     1ec14a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x52da>
  1eb620:	c5 f9 6e d5          	vmovd  %ebp,%xmm2
  1eb624:	49 89 ff             	mov    %rdi,%r15
  1eb627:	c5 ea 59 d4          	vmulss %xmm4,%xmm2,%xmm2
  1eb62b:	c5 f9 7e d3          	vmovd  %xmm2,%ebx
  1eb62f:	81 e3 ff ff ff 7f    	and    $0x7fffffff,%ebx
  1eb635:	8d 6b ff             	lea    -0x1(%rbx),%ebp
  1eb638:	81 fd ff ff 7f 2b    	cmp    $0x2b7fffff,%ebp
  1eb63e:	73 18                	jae    1eb658 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x47e8>
  1eb640:	c5 f2 59 cc          	vmulss %xmm4,%xmm1,%xmm1
  1eb644:	c5 fa 59 c4          	vmulss %xmm4,%xmm0,%xmm0
  1eb648:	48 83 c7 b0          	add    $0xffffffffffffffb0,%rdi
  1eb64c:	71 d6                	jno    1eb624 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x47b4>
  1eb64e:	e9 f3 0a 00 00       	jmp    1ec146 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x52d6>
  1eb653:	49 89 ff             	mov    %rdi,%r15
  1eb656:	eb 16                	jmp    1eb66e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x47fe>
  1eb658:	4c 89 3c c1          	mov    %r15,(%rcx,%rax,8)
  1eb65c:	c5 fa 11 8c 84 b0 04 	vmovss %xmm1,0x4b0(%rsp,%rax,4)
  1eb663:	00 00 
  1eb665:	c5 fa 11 84 84 b0 02 	vmovss %xmm0,0x2b0(%rsp,%rax,4)
  1eb66c:	00 00 
  1eb66e:	31 ff                	xor    %edi,%edi
  1eb670:	4d 85 ff             	test   %r15,%r15
  1eb673:	0f 85 dd fe ff ff    	jne    1eb556 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x46e6>
  1eb679:	81 fb 00 00 80 53    	cmp    $0x53800000,%ebx
  1eb67f:	0f 87 d1 fe ff ff    	ja     1eb556 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x46e6>
  1eb685:	85 db                	test   %ebx,%ebx
  1eb687:	0f 85 bf fe ff ff    	jne    1eb54c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x46dc>
  1eb68d:	40 b7 01             	mov    $0x1,%dil
  1eb690:	e9 c1 fe ff ff       	jmp    1eb556 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x46e6>
  1eb695:	48 8b 1d fc 7f 13 00 	mov    0x137ffc(%rip),%rbx        # 323698 <_DYNAMIC+0x448>
  1eb69c:	48 8b bb 00 08 00 00 	mov    0x800(%rbx),%rdi
  1eb6a3:	48 8d 84 24 b0 04 00 	lea    0x4b0(%rsp),%rax
  1eb6aa:	00 
  1eb6ab:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1eb6b4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4844>
  1eb6b2:	ff e7                	jmp    *%rdi
  1eb6b4:	c4 c1 7c 11 03       	vmovups %ymm0,(%r11)
  1eb6b9:	49 89 db             	mov    %rbx,%r11
  1eb6bc:	48 8b bb 00 08 00 00 	mov    0x800(%rbx),%rdi
  1eb6c3:	48 8d 84 24 b0 02 00 	lea    0x2b0(%rsp),%rax
  1eb6ca:	00 
  1eb6cb:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1eb6d4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4864>
  1eb6d2:	ff e7                	jmp    *%rdi
  1eb6d4:	c5 fc 11 06          	vmovups %ymm0,(%rsi)
  1eb6d8:	4c 3b 94 24 98 00 00 	cmp    0x98(%rsp),%r10
  1eb6df:	00 
  1eb6e0:	0f 82 c9 01 00 00    	jb     1eb8af <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4a3f>
  1eb6e6:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  1eb6eb:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
  1eb6ef:	4c 89 f7             	mov    %r14,%rdi
  1eb6f2:	48 29 c7             	sub    %rax,%rdi
  1eb6f5:	0f 82 5f 0b 00 00    	jb     1ec25a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x53ea>
  1eb6fb:	48 83 7c 24 48 00    	cmpq   $0x0,0x48(%rsp)
  1eb701:	0f 84 0e 04 00 00    	je     1ebb15 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4ca5>
  1eb707:	49 8d 0c c4          	lea    (%r12,%rax,8),%rcx
  1eb70b:	31 c0                	xor    %eax,%eax
  1eb70d:	c5 fa 10 1d 23 9a e3 	vmovss -0x1c65dd(%rip),%xmm3        # 25138 <__abi_tag+0x24e3c>
  1eb714:	ff 
  1eb715:	c5 fa 10 25 83 98 e3 	vmovss -0x1c677d(%rip),%xmm4        # 24fa0 <__abi_tag+0x24ca4>
  1eb71c:	ff 
  1eb71d:	eb 1b                	jmp    1eb73a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x48ca>
  1eb71f:	81 fe 00 00 80 2b    	cmp    $0x2b800000,%esi
  1eb725:	41 0f 93 c2          	setae  %r10b
  1eb729:	44 20 d2             	and    %r10b,%dl
  1eb72c:	48 ff c0             	inc    %rax
  1eb72f:	48 3b 44 24 48       	cmp    0x48(%rsp),%rax
  1eb734:	0f 84 db 03 00 00    	je     1ebb15 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4ca5>
  1eb73a:	48 39 f8             	cmp    %rdi,%rax
  1eb73d:	0f 84 1e 0f 00 00    	je     1ec661 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x57f1>
  1eb743:	41 8b 34 81          	mov    (%r9,%rax,4),%esi
  1eb747:	c5 f9 6e c6          	vmovd  %esi,%xmm0
  1eb74b:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
  1eb751:	45 8b 14 80          	mov    (%r8,%rax,4),%r10d
  1eb755:	c4 c1 79 6e ca       	vmovd  %r10d,%xmm1
  1eb75a:	41 81 e2 ff ff ff 7f 	and    $0x7fffffff,%r10d
  1eb761:	41 39 f2             	cmp    %esi,%r10d
  1eb764:	44 0f 46 d6          	cmovbe %esi,%r10d
  1eb768:	41 81 fa 01 00 80 53 	cmp    $0x53800001,%r10d
  1eb76f:	72 4b                	jb     1eb7bc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x494c>
  1eb771:	4c 8b 1c c1          	mov    (%rcx,%rax,8),%r11
  1eb775:	c5 fa 59 c3          	vmulss %xmm3,%xmm0,%xmm0
  1eb779:	c5 f2 59 cb          	vmulss %xmm3,%xmm1,%xmm1
  1eb77d:	49 83 c3 50          	add    $0x50,%r11
  1eb781:	0f 80 7a 09 00 00    	jo     1ec101 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5291>
  1eb787:	c4 c1 79 6e d2       	vmovd  %r10d,%xmm2
  1eb78c:	4c 89 db             	mov    %r11,%rbx
  1eb78f:	c5 ea 59 d3          	vmulss %xmm3,%xmm2,%xmm2
  1eb793:	c4 c1 79 7e d2       	vmovd  %xmm2,%r10d
  1eb798:	44 89 d6             	mov    %r10d,%esi
  1eb79b:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
  1eb7a1:	81 fe 00 00 80 53    	cmp    $0x53800000,%esi
  1eb7a7:	76 18                	jbe    1eb7c1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4951>
  1eb7a9:	c5 fa 59 c3          	vmulss %xmm3,%xmm0,%xmm0
  1eb7ad:	c5 f2 59 cb          	vmulss %xmm3,%xmm1,%xmm1
  1eb7b1:	49 83 c3 50          	add    $0x50,%r11
  1eb7b5:	71 d5                	jno    1eb78c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x491c>
  1eb7b7:	e9 41 09 00 00       	jmp    1ec0fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x528d>
  1eb7bc:	44 89 d6             	mov    %r10d,%esi
  1eb7bf:	eb 10                	jmp    1eb7d1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4961>
  1eb7c1:	48 89 1c c1          	mov    %rbx,(%rcx,%rax,8)
  1eb7c5:	c4 c1 7a 11 04 81    	vmovss %xmm0,(%r9,%rax,4)
  1eb7cb:	c4 c1 7a 11 0c 80    	vmovss %xmm1,(%r8,%rax,4)
  1eb7d1:	44 8d 5e ff          	lea    -0x1(%rsi),%r11d
  1eb7d5:	41 81 fb fe ff 7f 2b 	cmp    $0x2b7ffffe,%r11d
  1eb7dc:	77 5a                	ja     1eb838 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x49c8>
  1eb7de:	4c 8b 1c c1          	mov    (%rcx,%rax,8),%r11
  1eb7e2:	c5 fa 59 d4          	vmulss %xmm4,%xmm0,%xmm2
  1eb7e6:	c5 f2 59 c4          	vmulss %xmm4,%xmm1,%xmm0
  1eb7ea:	49 83 c3 b0          	add    $0xffffffffffffffb0,%r11
  1eb7ee:	0f 80 22 09 00 00    	jo     1ec116 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x52a6>
  1eb7f4:	c4 c1 79 6e ca       	vmovd  %r10d,%xmm1
  1eb7f9:	4d 89 da             	mov    %r11,%r10
  1eb7fc:	c5 f2 59 cc          	vmulss %xmm4,%xmm1,%xmm1
  1eb800:	c5 f9 7e ce          	vmovd  %xmm1,%esi
  1eb804:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
  1eb80a:	8d 5e ff             	lea    -0x1(%rsi),%ebx
  1eb80d:	81 fb ff ff 7f 2b    	cmp    $0x2b7fffff,%ebx
  1eb813:	73 13                	jae    1eb828 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x49b8>
  1eb815:	c5 ea 59 d4          	vmulss %xmm4,%xmm2,%xmm2
  1eb819:	c5 fa 59 c4          	vmulss %xmm4,%xmm0,%xmm0
  1eb81d:	49 83 c3 b0          	add    $0xffffffffffffffb0,%r11
  1eb821:	71 d6                	jno    1eb7f9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4989>
  1eb823:	e9 ea 08 00 00       	jmp    1ec112 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x52a2>
  1eb828:	4c 89 14 c1          	mov    %r10,(%rcx,%rax,8)
  1eb82c:	c4 c1 7a 11 14 81    	vmovss %xmm2,(%r9,%rax,4)
  1eb832:	c4 c1 7a 11 04 80    	vmovss %xmm0,(%r8,%rax,4)
  1eb838:	45 31 d2             	xor    %r10d,%r10d
  1eb83b:	81 fe 00 00 80 53    	cmp    $0x53800000,%esi
  1eb841:	0f 87 e2 fe ff ff    	ja     1eb729 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x48b9>
  1eb847:	48 83 3c c1 00       	cmpq   $0x0,(%rcx,%rax,8)
  1eb84c:	0f 85 d7 fe ff ff    	jne    1eb729 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x48b9>
  1eb852:	85 f6                	test   %esi,%esi
  1eb854:	0f 85 c5 fe ff ff    	jne    1eb71f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x48af>
  1eb85a:	41 b2 01             	mov    $0x1,%r10b
  1eb85d:	e9 c7 fe ff ff       	jmp    1eb729 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x48b9>
  1eb862:	20 ca                	and    %cl,%dl
  1eb864:	49 8b bb 00 08 00 00 	mov    0x800(%r11),%rdi
  1eb86b:	48 8d 84 24 b0 03 00 	lea    0x3b0(%rsp),%rax
  1eb872:	00 
  1eb873:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1eb87c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4a0c>
  1eb87a:	ff e7                	jmp    *%rdi
  1eb87c:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  1eb881:	c5 fc 11 00          	vmovups %ymm0,(%rax)
  1eb885:	49 8b bb 00 08 00 00 	mov    0x800(%r11),%rdi
  1eb88c:	48 8d 84 24 b0 01 00 	lea    0x1b0(%rsp),%rax
  1eb893:	00 
  1eb894:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1eb89d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4a2d>
  1eb89b:	ff e7                	jmp    *%rdi
  1eb89d:	c5 fc 11 06          	vmovups %ymm0,(%rsi)
  1eb8a1:	4c 3b 94 24 98 00 00 	cmp    0x98(%rsp),%r10
  1eb8a8:	00 
  1eb8a9:	0f 84 37 fe ff ff    	je     1eb6e6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4876>
  1eb8af:	c5 7c 11 84 24 90 04 	vmovups %ymm8,0x490(%rsp)
  1eb8b6:	00 00 
  1eb8b8:	c5 7c 11 84 24 70 04 	vmovups %ymm8,0x470(%rsp)
  1eb8bf:	00 00 
  1eb8c1:	c5 7c 11 84 24 50 04 	vmovups %ymm8,0x450(%rsp)
  1eb8c8:	00 00 
  1eb8ca:	c5 7c 11 84 24 30 04 	vmovups %ymm8,0x430(%rsp)
  1eb8d1:	00 00 
  1eb8d3:	c5 7c 11 84 24 10 04 	vmovups %ymm8,0x410(%rsp)
  1eb8da:	00 00 
  1eb8dc:	c5 7c 11 84 24 f0 03 	vmovups %ymm8,0x3f0(%rsp)
  1eb8e3:	00 00 
  1eb8e5:	c5 7c 11 84 24 d0 03 	vmovups %ymm8,0x3d0(%rsp)
  1eb8ec:	00 00 
  1eb8ee:	c5 7c 11 84 24 b0 03 	vmovups %ymm8,0x3b0(%rsp)
  1eb8f5:	00 00 
  1eb8f7:	c5 7c 11 84 24 90 02 	vmovups %ymm8,0x290(%rsp)
  1eb8fe:	00 00 
  1eb900:	c5 7c 11 84 24 70 02 	vmovups %ymm8,0x270(%rsp)
  1eb907:	00 00 
  1eb909:	c5 7c 11 84 24 50 02 	vmovups %ymm8,0x250(%rsp)
  1eb910:	00 00 
  1eb912:	c5 7c 11 84 24 30 02 	vmovups %ymm8,0x230(%rsp)
  1eb919:	00 00 
  1eb91b:	c5 7c 11 84 24 10 02 	vmovups %ymm8,0x210(%rsp)
  1eb922:	00 00 
  1eb924:	c5 7c 11 84 24 f0 01 	vmovups %ymm8,0x1f0(%rsp)
  1eb92b:	00 00 
  1eb92d:	c5 7c 11 84 24 d0 01 	vmovups %ymm8,0x1d0(%rsp)
  1eb934:	00 00 
  1eb936:	c5 7c 11 84 24 b0 01 	vmovups %ymm8,0x1b0(%rsp)
  1eb93d:	00 00 
  1eb93f:	4c 89 d6             	mov    %r10,%rsi
  1eb942:	48 c1 e6 05          	shl    $0x5,%rsi
  1eb946:	c4 c1 7c 10 44 35 00 	vmovups 0x0(%r13,%rsi,1),%ymm0
  1eb94d:	49 8b bb 08 08 00 00 	mov    0x808(%r11),%rdi
  1eb954:	48 8d 84 24 b0 03 00 	lea    0x3b0(%rsp),%rax
  1eb95b:	00 
  1eb95c:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1eb965 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4af5>
  1eb963:	ff e7                	jmp    *%rdi
  1eb965:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
  1eb96a:	c5 fc 10 04 33       	vmovups (%rbx,%rsi,1),%ymm0
  1eb96f:	49 8b bb 08 08 00 00 	mov    0x808(%r11),%rdi
  1eb976:	48 8d 84 24 b0 01 00 	lea    0x1b0(%rsp),%rax
  1eb97d:	00 
  1eb97e:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1eb987 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4b17>
  1eb985:	ff e7                	jmp    *%rdi
  1eb987:	4a 8d 3c d5 00 00 00 	lea    0x0(,%r10,8),%rdi
  1eb98e:	00 
  1eb98f:	4a 8d 04 d5 07 00 00 	lea    0x7(,%r10,8),%rax
  1eb996:	00 
  1eb997:	4c 39 f0             	cmp    %r14,%rax
  1eb99a:	0f 83 4d 0b 00 00    	jae    1ec4ed <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x567d>
  1eb9a0:	49 ff c2             	inc    %r10
  1eb9a3:	4a 8d 04 2e          	lea    (%rsi,%r13,1),%rax
  1eb9a7:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  1eb9ac:	48 01 de             	add    %rbx,%rsi
  1eb9af:	49 8d 04 fc          	lea    (%r12,%rdi,8),%rax
  1eb9b3:	b1 01                	mov    $0x1,%cl
  1eb9b5:	31 ff                	xor    %edi,%edi
  1eb9b7:	eb 19                	jmp    1eb9d2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4b62>
  1eb9b9:	4d 89 dd             	mov    %r11,%r13
  1eb9bc:	4c 8b 1d d5 7c 13 00 	mov    0x137cd5(%rip),%r11        # 323698 <_DYNAMIC+0x448>
  1eb9c3:	20 d9                	and    %bl,%cl
  1eb9c5:	48 ff c7             	inc    %rdi
  1eb9c8:	48 83 ff 08          	cmp    $0x8,%rdi
  1eb9cc:	0f 84 90 fe ff ff    	je     1eb862 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x49f2>
  1eb9d2:	4d 89 eb             	mov    %r13,%r11
  1eb9d5:	8b 9c bc b0 03 00 00 	mov    0x3b0(%rsp,%rdi,4),%ebx
  1eb9dc:	41 89 df             	mov    %ebx,%r15d
  1eb9df:	41 81 e7 ff ff ff 7f 	and    $0x7fffffff,%r15d
  1eb9e6:	44 8b ac bc b0 01 00 	mov    0x1b0(%rsp,%rdi,4),%r13d
  1eb9ed:	00 
  1eb9ee:	44 89 ed             	mov    %r13d,%ebp
  1eb9f1:	81 e5 ff ff ff 7f    	and    $0x7fffffff,%ebp
  1eb9f7:	44 39 fd             	cmp    %r15d,%ebp
  1eb9fa:	41 0f 46 ef          	cmovbe %r15d,%ebp
  1eb9fe:	c5 f9 6e c3          	vmovd  %ebx,%xmm0
  1eba02:	c4 c1 79 6e cd       	vmovd  %r13d,%xmm1
  1eba07:	4c 8b 2c f8          	mov    (%rax,%rdi,8),%r13
  1eba0b:	81 fd 01 00 80 53    	cmp    $0x53800001,%ebp
  1eba11:	72 3f                	jb     1eba52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4be2>
  1eba13:	49 83 c5 50          	add    $0x50,%r13
  1eba17:	0f 80 1c 06 00 00    	jo     1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1eba1d:	c5 f9 6e d5          	vmovd  %ebp,%xmm2
  1eba21:	c5 f2 59 cb          	vmulss %xmm3,%xmm1,%xmm1
  1eba25:	c5 fa 59 c3          	vmulss %xmm3,%xmm0,%xmm0
  1eba29:	4c 89 eb             	mov    %r13,%rbx
  1eba2c:	c5 ea 59 d3          	vmulss %xmm3,%xmm2,%xmm2
  1eba30:	c5 f9 7e d5          	vmovd  %xmm2,%ebp
  1eba34:	41 89 ef             	mov    %ebp,%r15d
  1eba37:	41 81 e7 ff ff ff 7f 	and    $0x7fffffff,%r15d
  1eba3e:	41 81 ff 00 00 80 53 	cmp    $0x53800000,%r15d
  1eba45:	76 13                	jbe    1eba5a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4bea>
  1eba47:	49 83 c5 50          	add    $0x50,%r13
  1eba4b:	71 d4                	jno    1eba21 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4bb1>
  1eba4d:	e9 40 07 00 00       	jmp    1ec192 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5322>
  1eba52:	4c 89 eb             	mov    %r13,%rbx
  1eba55:	41 89 ef             	mov    %ebp,%r15d
  1eba58:	eb 16                	jmp    1eba70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4c00>
  1eba5a:	48 89 1c f8          	mov    %rbx,(%rax,%rdi,8)
  1eba5e:	c5 fa 11 84 bc b0 03 	vmovss %xmm0,0x3b0(%rsp,%rdi,4)
  1eba65:	00 00 
  1eba67:	c5 fa 11 8c bc b0 01 	vmovss %xmm1,0x1b0(%rsp,%rdi,4)
  1eba6e:	00 00 
  1eba70:	45 8d 6f ff          	lea    -0x1(%r15),%r13d
  1eba74:	41 81 fd fe ff 7f 2b 	cmp    $0x2b7ffffe,%r13d
  1eba7b:	77 40                	ja     1ebabd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4c4d>
  1eba7d:	48 83 c3 b0          	add    $0xffffffffffffffb0,%rbx
  1eba81:	0f 80 b2 05 00 00    	jo     1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1eba87:	c5 f9 6e d5          	vmovd  %ebp,%xmm2
  1eba8b:	c5 f2 59 cc          	vmulss %xmm4,%xmm1,%xmm1
  1eba8f:	c5 fa 59 c4          	vmulss %xmm4,%xmm0,%xmm0
  1eba93:	49 89 dd             	mov    %rbx,%r13
  1eba96:	c5 ea 59 d4          	vmulss %xmm4,%xmm2,%xmm2
  1eba9a:	c4 c1 79 7e d7       	vmovd  %xmm2,%r15d
  1eba9f:	41 81 e7 ff ff ff 7f 	and    $0x7fffffff,%r15d
  1ebaa6:	41 8d 6f ff          	lea    -0x1(%r15),%ebp
  1ebaaa:	81 fd ff ff 7f 2b    	cmp    $0x2b7fffff,%ebp
  1ebab0:	73 10                	jae    1ebac2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4c52>
  1ebab2:	48 83 c3 b0          	add    $0xffffffffffffffb0,%rbx
  1ebab6:	71 d3                	jno    1eba8b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4c1b>
  1ebab8:	e9 de 06 00 00       	jmp    1ec19b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x532b>
  1ebabd:	49 89 dd             	mov    %rbx,%r13
  1ebac0:	eb 16                	jmp    1ebad8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4c68>
  1ebac2:	4c 89 2c f8          	mov    %r13,(%rax,%rdi,8)
  1ebac6:	c5 fa 11 84 bc b0 03 	vmovss %xmm0,0x3b0(%rsp,%rdi,4)
  1ebacd:	00 00 
  1ebacf:	c5 fa 11 8c bc b0 01 	vmovss %xmm1,0x1b0(%rsp,%rdi,4)
  1ebad6:	00 00 
  1ebad8:	31 db                	xor    %ebx,%ebx
  1ebada:	4d 85 ed             	test   %r13,%r13
  1ebadd:	0f 85 d6 fe ff ff    	jne    1eb9b9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4b49>
  1ebae3:	41 81 ff 00 00 80 53 	cmp    $0x53800000,%r15d
  1ebaea:	4d 89 dd             	mov    %r11,%r13
  1ebaed:	4c 8b 1d a4 7b 13 00 	mov    0x137ba4(%rip),%r11        # 323698 <_DYNAMIC+0x448>
  1ebaf4:	0f 87 c9 fe ff ff    	ja     1eb9c3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4b53>
  1ebafa:	45 85 ff             	test   %r15d,%r15d
  1ebafd:	74 0f                	je     1ebb0e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4c9e>
  1ebaff:	41 81 ff 00 00 80 2b 	cmp    $0x2b800000,%r15d
  1ebb06:	0f 93 c3             	setae  %bl
  1ebb09:	e9 b5 fe ff ff       	jmp    1eb9c3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4b53>
  1ebb0e:	b3 01                	mov    $0x1,%bl
  1ebb10:	e9 ae fe ff ff       	jmp    1eb9c3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4b53>
  1ebb15:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1ebb1a:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1ebb1f:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1ebb24:	c4 41 00 57 ff       	vxorps %xmm15,%xmm15,%xmm15
  1ebb29:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
  1ebb2e:	80 bc 24 dc 17 00 00 	cmpb   $0x2,0x17dc(%rsp)
  1ebb35:	02 
  1ebb36:	74 08                	je     1ebb40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4cd0>
  1ebb38:	c6 84 24 dc 17 00 00 	movb   $0x0,0x17dc(%rsp)
  1ebb3f:	00 
  1ebb40:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1ebb45:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
  1ebb4a:	e9 85 c2 ff ff       	jmp    1e7dd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xf64>
  1ebb4f:	c4 c1 7a 10 41 0c    	vmovss 0xc(%r9),%xmm0
  1ebb55:	c4 e2 79 18 15 da 96 	vbroadcastss -0x1c6926(%rip),%xmm2        # 25238 <__abi_tag+0x24f3c>
  1ebb5c:	e3 ff 
  1ebb5e:	c5 f8 54 c2          	vandps %xmm2,%xmm0,%xmm0
  1ebb62:	c4 c1 7a 10 48 0c    	vmovss 0xc(%r8),%xmm1
  1ebb68:	c5 f0 54 ca          	vandps %xmm2,%xmm1,%xmm1
  1ebb6c:	c5 fa 5f d1          	vmaxss %xmm1,%xmm0,%xmm2
  1ebb70:	c5 f2 c2 c9 03       	vcmpunordss %xmm1,%xmm1,%xmm1
  1ebb75:	c4 e3 69 4a c0 10    	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  1ebb7b:	b9 03 00 00 00       	mov    $0x3,%ecx
  1ebb80:	c5 fa 10 0d 48 94 e3 	vmovss -0x1c6bb8(%rip),%xmm1        # 24fd0 <__abi_tag+0x24cd4>
  1ebb87:	ff 
  1ebb88:	c5 f8 2e c8          	vucomiss %xmm0,%xmm1
  1ebb8c:	73 29                	jae    1ebbb7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4d47>
  1ebb8e:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1ebb93:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1ebb98:	49 89 fa             	mov    %rdi,%r10
  1ebb9b:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1ebba0:	49 89 c5             	mov    %rax,%r13
  1ebba3:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1ebba8:	c4 41 00 57 ff       	vxorps %xmm15,%xmm15,%xmm15
  1ebbad:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
  1ebbb2:	e9 6b f1 ff ff       	jmp    1ead22 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3eb2>
  1ebbb7:	c4 41 00 57 ff       	vxorps %xmm15,%xmm15,%xmm15
  1ebbbc:	c4 c1 78 2e c7       	vucomiss %xmm15,%xmm0
  1ebbc1:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1ebbc6:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1ebbcb:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1ebbd0:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1ebbd5:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
  1ebbda:	75 02                	jne    1ebbde <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4d6e>
  1ebbdc:	7b 14                	jnp    1ebbf2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4d82>
  1ebbde:	49 89 fa             	mov    %rdi,%r10
  1ebbe1:	49 89 c5             	mov    %rax,%r13
  1ebbe4:	c5 f8 2e 05 2c 96 e3 	vucomiss -0x1c69d4(%rip),%xmm0        # 25218 <__abi_tag+0x24f1c>
  1ebbeb:	ff 
  1ebbec:	0f 82 30 f1 ff ff    	jb     1ead22 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3eb2>
  1ebbf2:	83 7c 24 48 04       	cmpl   $0x4,0x48(%rsp)
  1ebbf7:	0f 85 c8 00 00 00    	jne    1ebcc5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4e55>
  1ebbfd:	8b 54 24 50          	mov    0x50(%rsp),%edx
  1ebc01:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1ebc06:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1ebc0b:	49 89 fa             	mov    %rdi,%r10
  1ebc0e:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1ebc13:	49 89 c5             	mov    %rax,%r13
  1ebc16:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1ebc1b:	e9 b4 c1 ff ff       	jmp    1e7dd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xf64>
  1ebc20:	c5 f8 50 c3          	vmovmskps %xmm3,%eax
  1ebc24:	c1 e0 1f             	shl    $0x1f,%eax
  1ebc27:	48 39 d1             	cmp    %rdx,%rcx
  1ebc2a:	7e 05                	jle    1ebc31 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4dc1>
  1ebc2c:	0d 00 00 80 7f       	or     $0x7f800000,%eax
  1ebc31:	c4 41 00 57 ff       	vxorps %xmm15,%xmm15,%xmm15
  1ebc36:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
  1ebc3b:	e9 b5 e7 ff ff       	jmp    1ea3f5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3585>
  1ebc40:	c5 f8 50 fa          	vmovmskps %xmm2,%edi
  1ebc44:	c1 e7 1f             	shl    $0x1f,%edi
  1ebc47:	48 39 d1             	cmp    %rdx,%rcx
  1ebc4a:	7e 06                	jle    1ebc52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4de2>
  1ebc4c:	81 cf 00 00 80 7f    	or     $0x7f800000,%edi
  1ebc52:	c4 41 00 57 ff       	vxorps %xmm15,%xmm15,%xmm15
  1ebc57:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
  1ebc5c:	e9 ad e8 ff ff       	jmp    1ea50e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x369e>
  1ebc61:	c5 78 50 c1          	vmovmskps %xmm1,%r8d
  1ebc65:	41 c1 e0 1f          	shl    $0x1f,%r8d
  1ebc69:	48 39 d1             	cmp    %rdx,%rcx
  1ebc6c:	7e 07                	jle    1ebc75 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4e05>
  1ebc6e:	41 81 c8 00 00 80 7f 	or     $0x7f800000,%r8d
  1ebc75:	c4 41 00 57 ff       	vxorps %xmm15,%xmm15,%xmm15
  1ebc7a:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
  1ebc7f:	e9 a7 e9 ff ff       	jmp    1ea62b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x37bb>
  1ebc84:	c5 78 50 c8          	vmovmskps %xmm0,%r9d
  1ebc88:	41 c1 e1 1f          	shl    $0x1f,%r9d
  1ebc8c:	48 39 d1             	cmp    %rdx,%rcx
  1ebc8f:	7e 07                	jle    1ebc98 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4e28>
  1ebc91:	41 81 c9 00 00 80 7f 	or     $0x7f800000,%r9d
  1ebc98:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  1ebc9d:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1ebca2:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
  1ebca7:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
  1ebcac:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1ebcb1:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1ebcb6:	c4 41 00 57 ff       	vxorps %xmm15,%xmm15,%xmm15
  1ebcbb:	c4 41 38 57 c0       	vxorps %xmm8,%xmm8,%xmm8
  1ebcc0:	e9 7b ea ff ff       	jmp    1ea740 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x38d0>
  1ebcc5:	c4 c1 7a 10 41 10    	vmovss 0x10(%r9),%xmm0
  1ebccb:	c4 e2 79 18 15 64 95 	vbroadcastss -0x1c6a9c(%rip),%xmm2        # 25238 <__abi_tag+0x24f3c>
  1ebcd2:	e3 ff 
  1ebcd4:	c5 f8 54 c2          	vandps %xmm2,%xmm0,%xmm0
  1ebcd8:	c4 c1 7a 10 48 10    	vmovss 0x10(%r8),%xmm1
  1ebcde:	c5 f0 54 ca          	vandps %xmm2,%xmm1,%xmm1
  1ebce2:	c5 fa 5f d1          	vmaxss %xmm1,%xmm0,%xmm2
  1ebce6:	c5 f2 c2 c9 03       	vcmpunordss %xmm1,%xmm1,%xmm1
  1ebceb:	c4 e3 69 4a c0 10    	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  1ebcf1:	b9 04 00 00 00       	mov    $0x4,%ecx
  1ebcf6:	c5 fa 10 0d d2 92 e3 	vmovss -0x1c6d2e(%rip),%xmm1        # 24fd0 <__abi_tag+0x24cd4>
  1ebcfd:	ff 
  1ebcfe:	c5 f8 2e c8          	vucomiss %xmm0,%xmm1
  1ebd02:	73 1f                	jae    1ebd23 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4eb3>
  1ebd04:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1ebd09:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1ebd0e:	49 89 fa             	mov    %rdi,%r10
  1ebd11:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1ebd16:	49 89 c5             	mov    %rax,%r13
  1ebd19:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1ebd1e:	e9 ff ef ff ff       	jmp    1ead22 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3eb2>
  1ebd23:	c4 c1 78 2e c7       	vucomiss %xmm15,%xmm0
  1ebd28:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1ebd2d:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1ebd32:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1ebd37:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1ebd3c:	75 02                	jne    1ebd40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4ed0>
  1ebd3e:	7b 14                	jnp    1ebd54 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4ee4>
  1ebd40:	49 89 fa             	mov    %rdi,%r10
  1ebd43:	49 89 c5             	mov    %rax,%r13
  1ebd46:	c5 f8 2e 05 ca 94 e3 	vucomiss -0x1c6b36(%rip),%xmm0        # 25218 <__abi_tag+0x24f1c>
  1ebd4d:	ff 
  1ebd4e:	0f 82 ce ef ff ff    	jb     1ead22 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3eb2>
  1ebd54:	83 7c 24 48 05       	cmpl   $0x5,0x48(%rsp)
  1ebd59:	0f 84 9e fe ff ff    	je     1ebbfd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4d8d>
  1ebd5f:	c4 c1 7a 10 41 14    	vmovss 0x14(%r9),%xmm0
  1ebd65:	c4 e2 79 18 15 ca 94 	vbroadcastss -0x1c6b36(%rip),%xmm2        # 25238 <__abi_tag+0x24f3c>
  1ebd6c:	e3 ff 
  1ebd6e:	c5 f8 54 c2          	vandps %xmm2,%xmm0,%xmm0
  1ebd72:	c4 c1 7a 10 48 14    	vmovss 0x14(%r8),%xmm1
  1ebd78:	c5 f0 54 ca          	vandps %xmm2,%xmm1,%xmm1
  1ebd7c:	c5 fa 5f d1          	vmaxss %xmm1,%xmm0,%xmm2
  1ebd80:	c5 f2 c2 c9 03       	vcmpunordss %xmm1,%xmm1,%xmm1
  1ebd85:	c4 e3 69 4a c0 10    	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  1ebd8b:	b9 05 00 00 00       	mov    $0x5,%ecx
  1ebd90:	c5 fa 10 0d 38 92 e3 	vmovss -0x1c6dc8(%rip),%xmm1        # 24fd0 <__abi_tag+0x24cd4>
  1ebd97:	ff 
  1ebd98:	c5 f8 2e c8          	vucomiss %xmm0,%xmm1
  1ebd9c:	0f 82 62 ff ff ff    	jb     1ebd04 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4e94>
  1ebda2:	c4 c1 78 2e c7       	vucomiss %xmm15,%xmm0
  1ebda7:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1ebdac:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1ebdb1:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1ebdb6:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1ebdbb:	75 02                	jne    1ebdbf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4f4f>
  1ebdbd:	7b 14                	jnp    1ebdd3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4f63>
  1ebdbf:	49 89 fa             	mov    %rdi,%r10
  1ebdc2:	49 89 c5             	mov    %rax,%r13
  1ebdc5:	c5 f8 2e 05 4b 94 e3 	vucomiss -0x1c6bb5(%rip),%xmm0        # 25218 <__abi_tag+0x24f1c>
  1ebdcc:	ff 
  1ebdcd:	0f 82 4f ef ff ff    	jb     1ead22 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3eb2>
  1ebdd3:	c5 e0 57 db          	vxorps %xmm3,%xmm3,%xmm3
  1ebdd7:	83 7c 24 48 06       	cmpl   $0x6,0x48(%rsp)
  1ebddc:	0f 84 1b fe ff ff    	je     1ebbfd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4d8d>
  1ebde2:	c4 c1 7a 10 41 18    	vmovss 0x18(%r9),%xmm0
  1ebde8:	c4 e2 79 18 15 47 94 	vbroadcastss -0x1c6bb9(%rip),%xmm2        # 25238 <__abi_tag+0x24f3c>
  1ebdef:	e3 ff 
  1ebdf1:	c5 f8 54 c2          	vandps %xmm2,%xmm0,%xmm0
  1ebdf5:	c4 c1 7a 10 48 18    	vmovss 0x18(%r8),%xmm1
  1ebdfb:	c5 f0 54 ca          	vandps %xmm2,%xmm1,%xmm1
  1ebdff:	c5 fa 5f d1          	vmaxss %xmm1,%xmm0,%xmm2
  1ebe03:	c5 f2 c2 c9 03       	vcmpunordss %xmm1,%xmm1,%xmm1
  1ebe08:	c4 e3 69 4a c0 10    	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  1ebe0e:	b9 06 00 00 00       	mov    $0x6,%ecx
  1ebe13:	c5 fa 10 0d b5 91 e3 	vmovss -0x1c6e4b(%rip),%xmm1        # 24fd0 <__abi_tag+0x24cd4>
  1ebe1a:	ff 
  1ebe1b:	c5 f8 2e c8          	vucomiss %xmm0,%xmm1
  1ebe1f:	0f 82 df fe ff ff    	jb     1ebd04 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4e94>
  1ebe25:	c5 f8 2e c3          	vucomiss %xmm3,%xmm0
  1ebe29:	75 06                	jne    1ebe31 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4fc1>
  1ebe2b:	0f 8b cc fd ff ff    	jnp    1ebbfd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x4d8d>
  1ebe31:	c5 f8 2e 05 df 93 e3 	vucomiss -0x1c6c21(%rip),%xmm0        # 25218 <__abi_tag+0x24f1c>
  1ebe38:	ff 
  1ebe39:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1ebe3e:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  1ebe43:	49 89 fa             	mov    %rdi,%r10
  1ebe46:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1ebe4b:	49 89 c5             	mov    %rax,%r13
  1ebe4e:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1ebe53:	0f 82 c9 ee ff ff    	jb     1ead22 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x3eb2>
  1ebe59:	e9 72 bf ff ff       	jmp    1e7dd0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0xf60>
  1ebe5e:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  1ebe65:	00 
  1ebe66:	c6 40 08 01          	movb   $0x1,0x8(%rax)
  1ebe6a:	e9 d0 b7 ff ff       	jmp    1e763f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x7cf>
  1ebe6f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  1ebe74:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
  1ebe78:	4c 89 f6             	mov    %r14,%rsi
  1ebe7b:	48 29 c6             	sub    %rax,%rsi
  1ebe7e:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
  1ebe83:	0f 82 d1 03 00 00    	jb     1ec25a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x53ea>
  1ebe89:	48 83 7c 24 28 00    	cmpq   $0x0,0x28(%rsp)
  1ebe8f:	4c 8b 4c 24 78       	mov    0x78(%rsp),%r9
  1ebe94:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  1ebe99:	0f 84 f0 b6 ff ff    	je     1e758f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x71f>
  1ebe9f:	49 8d 0c c4          	lea    (%r12,%rax,8),%rcx
  1ebea3:	31 c0                	xor    %eax,%eax
  1ebea5:	eb 14                	jmp    1ebebb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x504b>
  1ebea7:	4d 89 f9             	mov    %r15,%r9
  1ebeaa:	40 20 fa             	and    %dil,%dl
  1ebead:	48 ff c0             	inc    %rax
  1ebeb0:	48 3b 44 24 28       	cmp    0x28(%rsp),%rax
  1ebeb5:	0f 84 d4 b6 ff ff    	je     1e758f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x71f>
  1ebebb:	48 3b 84 24 b0 00 00 	cmp    0xb0(%rsp),%rax
  1ebec2:	00 
  1ebec3:	0f 84 4e 06 00 00    	je     1ec517 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x56a7>
  1ebec9:	48 39 f0             	cmp    %rsi,%rax
  1ebecc:	0f 84 32 06 00 00    	je     1ec504 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5694>
  1ebed2:	4d 89 cf             	mov    %r9,%r15
  1ebed5:	8b 3c 83             	mov    (%rbx,%rax,4),%edi
  1ebed8:	c5 f9 6e c7          	vmovd  %edi,%xmm0
  1ebedc:	81 e7 ff ff ff 7f    	and    $0x7fffffff,%edi
  1ebee2:	45 8b 4c 85 00       	mov    0x0(%r13,%rax,4),%r9d
  1ebee7:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
  1ebeec:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  1ebef3:	41 39 f9             	cmp    %edi,%r9d
  1ebef6:	44 0f 46 cf          	cmovbe %edi,%r9d
  1ebefa:	41 81 f9 01 00 80 53 	cmp    $0x53800001,%r9d
  1ebf01:	72 4f                	jb     1ebf52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x50e2>
  1ebf03:	48 8b 3c c1          	mov    (%rcx,%rax,8),%rdi
  1ebf07:	c5 fa 59 c2          	vmulss %xmm2,%xmm0,%xmm0
  1ebf0b:	c5 f2 59 ca          	vmulss %xmm2,%xmm1,%xmm1
  1ebf0f:	48 83 c7 50          	add    $0x50,%rdi
  1ebf13:	0f 80 7f 01 00 00    	jo     1ec098 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5228>
  1ebf19:	c4 c1 79 6e e1       	vmovd  %r9d,%xmm4
  1ebf1e:	66 90                	xchg   %ax,%ax
  1ebf20:	49 89 fa             	mov    %rdi,%r10
  1ebf23:	c5 da 59 e2          	vmulss %xmm2,%xmm4,%xmm4
  1ebf27:	c4 c1 79 7e e1       	vmovd  %xmm4,%r9d
  1ebf2c:	45 89 c8             	mov    %r9d,%r8d
  1ebf2f:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
  1ebf36:	41 81 f8 00 00 80 53 	cmp    $0x53800000,%r8d
  1ebf3d:	76 27                	jbe    1ebf66 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x50f6>
  1ebf3f:	c5 fa 59 c2          	vmulss %xmm2,%xmm0,%xmm0
  1ebf43:	c5 f2 59 ca          	vmulss %xmm2,%xmm1,%xmm1
  1ebf47:	48 83 c7 50          	add    $0x50,%rdi
  1ebf4b:	71 d3                	jno    1ebf20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x50b0>
  1ebf4d:	e9 42 01 00 00       	jmp    1ec094 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5224>
  1ebf52:	45 89 c8             	mov    %r9d,%r8d
  1ebf55:	41 8d 78 ff          	lea    -0x1(%r8),%edi
  1ebf59:	81 ff fe ff 7f 2b    	cmp    $0x2b7ffffe,%edi
  1ebf5f:	76 21                	jbe    1ebf82 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5112>
  1ebf61:	e9 7d 00 00 00       	jmp    1ebfe3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5173>
  1ebf66:	4c 89 14 c1          	mov    %r10,(%rcx,%rax,8)
  1ebf6a:	c5 fa 11 04 83       	vmovss %xmm0,(%rbx,%rax,4)
  1ebf6f:	c4 c1 7a 11 4c 85 00 	vmovss %xmm1,0x0(%r13,%rax,4)
  1ebf76:	41 8d 78 ff          	lea    -0x1(%r8),%edi
  1ebf7a:	81 ff fe ff 7f 2b    	cmp    $0x2b7ffffe,%edi
  1ebf80:	77 61                	ja     1ebfe3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5173>
  1ebf82:	48 8b 3c c1          	mov    (%rcx,%rax,8),%rdi
  1ebf86:	c5 fa 59 e3          	vmulss %xmm3,%xmm0,%xmm4
  1ebf8a:	c5 f2 59 c3          	vmulss %xmm3,%xmm1,%xmm0
  1ebf8e:	48 83 c7 b0          	add    $0xffffffffffffffb0,%rdi
  1ebf92:	0f 80 12 01 00 00    	jo     1ec0aa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x523a>
  1ebf98:	c4 c1 79 6e c9       	vmovd  %r9d,%xmm1
  1ebf9d:	0f 1f 00             	nopl   (%rax)
  1ebfa0:	49 89 f9             	mov    %rdi,%r9
  1ebfa3:	c5 f2 59 cb          	vmulss %xmm3,%xmm1,%xmm1
  1ebfa7:	c4 c1 79 7e c8       	vmovd  %xmm1,%r8d
  1ebfac:	41 81 e0 ff ff ff 7f 	and    $0x7fffffff,%r8d
  1ebfb3:	45 8d 50 ff          	lea    -0x1(%r8),%r10d
  1ebfb7:	41 81 fa ff ff 7f 2b 	cmp    $0x2b7fffff,%r10d
  1ebfbe:	73 13                	jae    1ebfd3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5163>
  1ebfc0:	c5 da 59 e3          	vmulss %xmm3,%xmm4,%xmm4
  1ebfc4:	c5 fa 59 c3          	vmulss %xmm3,%xmm0,%xmm0
  1ebfc8:	48 83 c7 b0          	add    $0xffffffffffffffb0,%rdi
  1ebfcc:	71 d2                	jno    1ebfa0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5130>
  1ebfce:	e9 d3 00 00 00       	jmp    1ec0a6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5236>
  1ebfd3:	4c 89 0c c1          	mov    %r9,(%rcx,%rax,8)
  1ebfd7:	c5 fa 11 24 83       	vmovss %xmm4,(%rbx,%rax,4)
  1ebfdc:	c4 c1 7a 11 44 85 00 	vmovss %xmm0,0x0(%r13,%rax,4)
  1ebfe3:	31 ff                	xor    %edi,%edi
  1ebfe5:	41 81 f8 00 00 80 53 	cmp    $0x53800000,%r8d
  1ebfec:	0f 87 b5 fe ff ff    	ja     1ebea7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x5037>
  1ebff2:	48 83 3c c1 00       	cmpq   $0x0,(%rcx,%rax,8)
  1ebff7:	4d 89 f9             	mov    %r15,%r9
  1ebffa:	0f 85 aa fe ff ff    	jne    1ebeaa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x503a>
  1ec000:	45 85 c0             	test   %r8d,%r8d
  1ec003:	74 10                	je     1ec015 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51a5>
  1ec005:	41 81 f8 00 00 80 2b 	cmp    $0x2b800000,%r8d
  1ec00c:	40 0f 93 c7          	setae  %dil
  1ec010:	e9 95 fe ff ff       	jmp    1ebeaa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x503a>
  1ec015:	40 b7 01             	mov    $0x1,%dil
  1ec018:	e9 8d fe ff ff       	jmp    1ebeaa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x503a>
  1ec01d:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
  1ec021:	eb 04                	jmp    1ec027 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51b7>
  1ec023:	4c 89 04 c1          	mov    %r8,(%rcx,%rax,8)
  1ec027:	c5 fa 11 8c 84 b0 02 	vmovss %xmm1,0x2b0(%rsp,%rax,4)
  1ec02e:	00 00 
  1ec030:	c5 fa 11 84 84 b0 03 	vmovss %xmm0,0x3b0(%rsp,%rax,4)
  1ec037:	00 00 
  1ec039:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
  1ec040:	00 
  1ec041:	48 8d 05 8b 32 e4 ff 	lea    -0x1bcd75(%rip),%rax        # 2f2d3 <anon.cc766c50d6f6989ff40805d0f8c3184f.7.llvm.8891494790698771628+0x60>
  1ec048:	89 c1                	mov    %eax,%ecx
  1ec04a:	c1 e9 08             	shr    $0x8,%ecx
  1ec04d:	48 89 c2             	mov    %rax,%rdx
  1ec050:	48 c1 ea 20          	shr    $0x20,%rdx
  1ec054:	48 c7 06 10 00 00 00 	movq   $0x10,(%rsi)
  1ec05b:	88 46 08             	mov    %al,0x8(%rsi)
  1ec05e:	c1 e8 18             	shr    $0x18,%eax
  1ec061:	88 46 0b             	mov    %al,0xb(%rsi)
  1ec064:	66 89 4e 09          	mov    %cx,0x9(%rsi)
  1ec068:	89 56 0c             	mov    %edx,0xc(%rsi)
  1ec06b:	48 c7 46 10 17 00 00 	movq   $0x17,0x10(%rsi)
  1ec072:	00 
  1ec073:	48 81 c4 e8 17 00 00 	add    $0x17e8,%rsp
  1ec07a:	5b                   	pop    %rbx
  1ec07b:	41 5c                	pop    %r12
  1ec07d:	41 5d                	pop    %r13
  1ec07f:	41 5e                	pop    %r14
  1ec081:	41 5f                	pop    %r15
  1ec083:	5d                   	pop    %rbp
  1ec084:	c5 f8 77             	vzeroupper
  1ec087:	c3                   	ret
  1ec088:	4e 89 04 c8          	mov    %r8,(%rax,%r9,8)
  1ec08c:	eb ab                	jmp    1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1ec08e:	4a 89 3c c8          	mov    %rdi,(%rax,%r9,8)
  1ec092:	eb a5                	jmp    1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1ec094:	4c 89 14 c1          	mov    %r10,(%rcx,%rax,8)
  1ec098:	c5 fa 11 04 83       	vmovss %xmm0,(%rbx,%rax,4)
  1ec09d:	c4 c1 7a 11 4c 85 00 	vmovss %xmm1,0x0(%r13,%rax,4)
  1ec0a4:	eb 93                	jmp    1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1ec0a6:	4c 89 0c c1          	mov    %r9,(%rcx,%rax,8)
  1ec0aa:	c5 fa 11 24 83       	vmovss %xmm4,(%rbx,%rax,4)
  1ec0af:	c4 c1 7a 11 44 85 00 	vmovss %xmm0,0x0(%r13,%rax,4)
  1ec0b6:	eb 81                	jmp    1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1ec0b8:	48 8d 15 09 c2 12 00 	lea    0x12c209(%rip),%rdx        # 3182c8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x3b0>
  1ec0bf:	48 89 cf             	mov    %rcx,%rdi
  1ec0c2:	4c 89 f6             	mov    %r14,%rsi
  1ec0c5:	c5 f8 77             	vzeroupper
  1ec0c8:	ff 15 e2 73 13 00    	call   *0x1373e2(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec0ce:	48 8d 0d 6b c2 12 00 	lea    0x12c26b(%rip),%rcx        # 318340 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x428>
  1ec0d5:	4c 89 c7             	mov    %r8,%rdi
  1ec0d8:	4c 89 ce             	mov    %r9,%rsi
  1ec0db:	4c 89 f2             	mov    %r14,%rdx
  1ec0de:	c5 f8 77             	vzeroupper
  1ec0e1:	ff 15 19 74 13 00    	call   *0x137419(%rip)        # 323500 <_DYNAMIC+0x2b0>
  1ec0e7:	48 8d 0d 6a c5 12 00 	lea    0x12c56a(%rip),%rcx        # 318658 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x740>
  1ec0ee:	4c 89 c7             	mov    %r8,%rdi
  1ec0f1:	4c 89 f2             	mov    %r14,%rdx
  1ec0f4:	c5 f8 77             	vzeroupper
  1ec0f7:	ff 15 03 74 13 00    	call   *0x137403(%rip)        # 323500 <_DYNAMIC+0x2b0>
  1ec0fd:	48 89 1c c1          	mov    %rbx,(%rcx,%rax,8)
  1ec101:	c4 c1 7a 11 04 81    	vmovss %xmm0,(%r9,%rax,4)
  1ec107:	c4 c1 7a 11 0c 80    	vmovss %xmm1,(%r8,%rax,4)
  1ec10d:	e9 27 ff ff ff       	jmp    1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1ec112:	4c 89 14 c1          	mov    %r10,(%rcx,%rax,8)
  1ec116:	c4 c1 7a 11 14 81    	vmovss %xmm2,(%r9,%rax,4)
  1ec11c:	c4 c1 7a 11 04 80    	vmovss %xmm0,(%r8,%rax,4)
  1ec122:	e9 12 ff ff ff       	jmp    1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1ec127:	48 8d 0d e2 c1 12 00 	lea    0x12c1e2(%rip),%rcx        # 318310 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x3f8>
  1ec12e:	48 89 c7             	mov    %rax,%rdi
  1ec131:	4c 89 f6             	mov    %r14,%rsi
  1ec134:	4c 89 f2             	mov    %r14,%rdx
  1ec137:	c5 f8 77             	vzeroupper
  1ec13a:	ff 15 c0 73 13 00    	call   *0x1373c0(%rip)        # 323500 <_DYNAMIC+0x2b0>
  1ec140:	48 89 3c c1          	mov    %rdi,(%rcx,%rax,8)
  1ec144:	eb 04                	jmp    1ec14a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x52da>
  1ec146:	4c 89 3c c1          	mov    %r15,(%rcx,%rax,8)
  1ec14a:	c5 fa 11 8c 84 b0 04 	vmovss %xmm1,0x4b0(%rsp,%rax,4)
  1ec151:	00 00 
  1ec153:	c5 fa 11 84 84 b0 02 	vmovss %xmm0,0x2b0(%rsp,%rax,4)
  1ec15a:	00 00 
  1ec15c:	e9 d8 fe ff ff       	jmp    1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1ec161:	49 8d 70 08          	lea    0x8(%r8),%rsi
  1ec165:	48 8d 0d 64 c2 12 00 	lea    0x12c264(%rip),%rcx        # 3183d0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x4b8>
  1ec16c:	4c 89 c7             	mov    %r8,%rdi
  1ec16f:	4c 89 f2             	mov    %r14,%rdx
  1ec172:	c5 f8 77             	vzeroupper
  1ec175:	ff 15 85 73 13 00    	call   *0x137385(%rip)        # 323500 <_DYNAMIC+0x2b0>
  1ec17b:	48 8d 0d 66 c8 12 00 	lea    0x12c866(%rip),%rcx        # 3189e8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xad0>
  1ec182:	ba 00 01 00 00       	mov    $0x100,%edx
  1ec187:	31 ff                	xor    %edi,%edi
  1ec189:	c5 f8 77             	vzeroupper
  1ec18c:	ff 15 6e 73 13 00    	call   *0x13736e(%rip)        # 323500 <_DYNAMIC+0x2b0>
  1ec192:	48 89 1c f8          	mov    %rbx,(%rax,%rdi,8)
  1ec196:	e9 9e fe ff ff       	jmp    1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1ec19b:	4c 89 2c f8          	mov    %r13,(%rax,%rdi,8)
  1ec19f:	e9 95 fe ff ff       	jmp    1ec039 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f32>>>+0x51c9>
  1ec1a4:	48 8d 0d 55 c8 12 00 	lea    0x12c855(%rip),%rcx        # 318a00 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xae8>
  1ec1ab:	ba 00 01 00 00       	mov    $0x100,%edx
  1ec1b0:	31 ff                	xor    %edi,%edi
  1ec1b2:	48 89 ee             	mov    %rbp,%rsi
  1ec1b5:	ff 15 45 73 13 00    	call   *0x137345(%rip)        # 323500 <_DYNAMIC+0x2b0>
  1ec1bb:	48 8d 70 08          	lea    0x8(%rax),%rsi
  1ec1bf:	48 8d 0d f2 c1 12 00 	lea    0x12c1f2(%rip),%rcx        # 3183b8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x4a0>
  1ec1c6:	48 89 c7             	mov    %rax,%rdi
  1ec1c9:	4c 89 f2             	mov    %r14,%rdx
  1ec1cc:	c5 f8 77             	vzeroupper
  1ec1cf:	ff 15 2b 73 13 00    	call   *0x13732b(%rip)        # 323500 <_DYNAMIC+0x2b0>
  1ec1d5:	48 8d 15 6c c5 12 00 	lea    0x12c56c(%rip),%rdx        # 318748 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x830>
  1ec1dc:	48 89 fe             	mov    %rdi,%rsi
  1ec1df:	c5 f8 77             	vzeroupper
  1ec1e2:	ff 15 c8 72 13 00    	call   *0x1372c8(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec1e8:	48 8d 15 89 c5 12 00 	lea    0x12c589(%rip),%rdx        # 318778 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x860>
  1ec1ef:	48 89 f7             	mov    %rsi,%rdi
  1ec1f2:	c5 f8 77             	vzeroupper
  1ec1f5:	ff 15 b5 72 13 00    	call   *0x1372b5(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec1fb:	48 8d 15 5e c5 12 00 	lea    0x12c55e(%rip),%rdx        # 318760 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x848>
  1ec202:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
  1ec209:	00 
  1ec20a:	48 89 fe             	mov    %rdi,%rsi
  1ec20d:	c5 f8 77             	vzeroupper
  1ec210:	ff 15 9a 72 13 00    	call   *0x13729a(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec216:	48 8d 15 ab c3 12 00 	lea    0x12c3ab(%rip),%rdx        # 3185c8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x6b0>
  1ec21d:	48 89 c7             	mov    %rax,%rdi
  1ec220:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1ec225:	c5 f8 77             	vzeroupper
  1ec228:	ff 15 82 72 13 00    	call   *0x137282(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec22e:	48 8d 15 7b c3 12 00 	lea    0x12c37b(%rip),%rdx        # 3185b0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x698>
  1ec235:	48 89 c7             	mov    %rax,%rdi
  1ec238:	4c 89 f6             	mov    %r14,%rsi
  1ec23b:	c5 f8 77             	vzeroupper
  1ec23e:	ff 15 6c 72 13 00    	call   *0x13726c(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec244:	48 8d 15 7d c0 12 00 	lea    0x12c07d(%rip),%rdx        # 3182c8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x3b0>
  1ec24b:	48 89 c7             	mov    %rax,%rdi
  1ec24e:	4c 89 f6             	mov    %r14,%rsi
  1ec251:	c5 f8 77             	vzeroupper
  1ec254:	ff 15 56 72 13 00    	call   *0x137256(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec25a:	48 8d 0d 27 c1 12 00 	lea    0x12c127(%rip),%rcx        # 318388 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x470>
  1ec261:	48 89 c7             	mov    %rax,%rdi
  1ec264:	4c 89 f6             	mov    %r14,%rsi
  1ec267:	4c 89 f2             	mov    %r14,%rdx
  1ec26a:	c5 f8 77             	vzeroupper
  1ec26d:	ff 15 8d 72 13 00    	call   *0x13728d(%rip)        # 323500 <_DYNAMIC+0x2b0>
  1ec273:	48 8d 15 7e c0 12 00 	lea    0x12c07e(%rip),%rdx        # 3182f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x3e0>
  1ec27a:	48 89 f7             	mov    %rsi,%rdi
  1ec27d:	c5 f8 77             	vzeroupper
  1ec280:	ff 15 2a 72 13 00    	call   *0x13722a(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec286:	48 8d 15 53 c0 12 00 	lea    0x12c053(%rip),%rdx        # 3182e0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x3c8>
  1ec28d:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
  1ec294:	00 
  1ec295:	48 89 fe             	mov    %rdi,%rsi
  1ec298:	c5 f8 77             	vzeroupper
  1ec29b:	ff 15 0f 72 13 00    	call   *0x13720f(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec2a1:	48 8d 0d 98 c0 12 00 	lea    0x12c098(%rip),%rcx        # 318340 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x428>
  1ec2a8:	4c 89 f2             	mov    %r14,%rdx
  1ec2ab:	c5 f8 77             	vzeroupper
  1ec2ae:	ff 15 4c 72 13 00    	call   *0x13724c(%rip)        # 323500 <_DYNAMIC+0x2b0>
  1ec2b4:	48 8d 15 55 c3 12 00 	lea    0x12c355(%rip),%rdx        # 318610 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x6f8>
  1ec2bb:	48 89 cf             	mov    %rcx,%rdi
  1ec2be:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1ec2c3:	c5 f8 77             	vzeroupper
  1ec2c6:	ff 15 e4 71 13 00    	call   *0x1371e4(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec2cc:	48 8d 15 55 c0 12 00 	lea    0x12c055(%rip),%rdx        # 318328 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x410>
  1ec2d3:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  1ec2d8:	48 89 fe             	mov    %rdi,%rsi
  1ec2db:	c5 f8 77             	vzeroupper
  1ec2de:	ff 15 cc 71 13 00    	call   *0x1371cc(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec2e4:	48 8d 0d f5 c2 12 00 	lea    0x12c2f5(%rip),%rcx        # 3185e0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x6c8>
  1ec2eb:	4c 89 c7             	mov    %r8,%rdi
  1ec2ee:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  1ec2f3:	c5 f8 77             	vzeroupper
  1ec2f6:	ff 15 04 72 13 00    	call   *0x137204(%rip)        # 323500 <_DYNAMIC+0x2b0>
  1ec2fc:	48 8d 15 2d c4 12 00 	lea    0x12c42d(%rip),%rdx        # 318730 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x818>
  1ec303:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
  1ec30a:	00 
  1ec30b:	48 89 fe             	mov    %rdi,%rsi
  1ec30e:	c5 f8 77             	vzeroupper
  1ec311:	ff 15 99 71 13 00    	call   *0x137199(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec317:	48 8d 15 fa c3 12 00 	lea    0x12c3fa(%rip),%rdx        # 318718 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x800>
  1ec31e:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  1ec323:	48 89 fe             	mov    %rdi,%rsi
  1ec326:	c5 f8 77             	vzeroupper
  1ec329:	ff 15 81 71 13 00    	call   *0x137181(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec32f:	48 8d 15 ca c3 12 00 	lea    0x12c3ca(%rip),%rdx        # 318700 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x7e8>
  1ec336:	48 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%rdi
  1ec33d:	00 
  1ec33e:	48 89 fe             	mov    %rdi,%rsi
  1ec341:	c5 f8 77             	vzeroupper
  1ec344:	ff 15 66 71 13 00    	call   *0x137166(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec34a:	48 8d 15 1f c3 12 00 	lea    0x12c31f(%rip),%rdx        # 318670 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x758>
  1ec351:	4c 89 c6             	mov    %r8,%rsi
  1ec354:	c5 f8 77             	vzeroupper
  1ec357:	ff 15 53 71 13 00    	call   *0x137153(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec35d:	48 8d 15 54 c3 12 00 	lea    0x12c354(%rip),%rdx        # 3186b8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x7a0>
  1ec364:	4c 89 cf             	mov    %r9,%rdi
  1ec367:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
  1ec36e:	00 
  1ec36f:	c5 f8 77             	vzeroupper
  1ec372:	ff 15 38 71 13 00    	call   *0x137138(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec378:	48 8d 15 21 c3 12 00 	lea    0x12c321(%rip),%rdx        # 3186a0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x788>
  1ec37f:	4c 89 cf             	mov    %r9,%rdi
  1ec382:	4c 89 c6             	mov    %r8,%rsi
  1ec385:	c5 f8 77             	vzeroupper
  1ec388:	ff 15 22 71 13 00    	call   *0x137122(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec38e:	48 8d 15 f3 c2 12 00 	lea    0x12c2f3(%rip),%rdx        # 318688 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x770>
  1ec395:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
  1ec39c:	00 
  1ec39d:	c5 f8 77             	vzeroupper
  1ec3a0:	ff 15 0a 71 13 00    	call   *0x13710a(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec3a6:	48 8d 15 23 c3 12 00 	lea    0x12c323(%rip),%rdx        # 3186d0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x7b8>
  1ec3ad:	c5 f8 77             	vzeroupper
  1ec3b0:	ff 15 fa 70 13 00    	call   *0x1370fa(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec3b6:	48 8d 15 2b c3 12 00 	lea    0x12c32b(%rip),%rdx        # 3186e8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x7d0>
  1ec3bd:	48 89 c7             	mov    %rax,%rdi
  1ec3c0:	c5 f8 77             	vzeroupper
  1ec3c3:	ff 15 e7 70 13 00    	call   *0x1370e7(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec3c9:	48 8d 15 80 c1 12 00 	lea    0x12c180(%rip),%rdx        # 318550 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x638>
  1ec3d0:	48 89 c7             	mov    %rax,%rdi
  1ec3d3:	4c 89 f6             	mov    %r14,%rsi
  1ec3d6:	c5 f8 77             	vzeroupper
  1ec3d9:	ff 15 d1 70 13 00    	call   *0x1370d1(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec3df:	48 8d 15 9a c4 12 00 	lea    0x12c49a(%rip),%rdx        # 318880 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x968>
  1ec3e6:	48 89 df             	mov    %rbx,%rdi
  1ec3e9:	48 8b b4 24 30 01 00 	mov    0x130(%rsp),%rsi
  1ec3f0:	00 
  1ec3f1:	ff 15 b9 70 13 00    	call   *0x1370b9(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec3f7:	48 8d 15 22 c4 12 00 	lea    0x12c422(%rip),%rdx        # 318820 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x908>
  1ec3fe:	48 89 df             	mov    %rbx,%rdi
  1ec401:	c5 f8 77             	vzeroupper
  1ec404:	ff 15 a6 70 13 00    	call   *0x1370a6(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec40a:	48 8d 15 27 c4 12 00 	lea    0x12c427(%rip),%rdx        # 318838 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x920>
  1ec411:	48 89 df             	mov    %rbx,%rdi
  1ec414:	48 8b b4 24 38 01 00 	mov    0x138(%rsp),%rsi
  1ec41b:	00 
  1ec41c:	c5 f8 77             	vzeroupper
  1ec41f:	ff 15 8b 70 13 00    	call   *0x13708b(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec425:	48 8d 15 24 c4 12 00 	lea    0x12c424(%rip),%rdx        # 318850 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x938>
  1ec42c:	48 89 df             	mov    %rbx,%rdi
  1ec42f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1ec434:	c5 f8 77             	vzeroupper
  1ec437:	ff 15 73 70 13 00    	call   *0x137073(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec43d:	48 8d 15 24 c4 12 00 	lea    0x12c424(%rip),%rdx        # 318868 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x950>
  1ec444:	48 89 df             	mov    %rbx,%rdi
  1ec447:	4c 89 f6             	mov    %r14,%rsi
  1ec44a:	c5 f8 77             	vzeroupper
  1ec44d:	ff 15 5d 70 13 00    	call   *0x13705d(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec453:	48 8d 15 3e c4 12 00 	lea    0x12c43e(%rip),%rdx        # 318898 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x980>
  1ec45a:	48 89 df             	mov    %rbx,%rdi
  1ec45d:	48 8b b4 24 28 01 00 	mov    0x128(%rsp),%rsi
  1ec464:	00 
  1ec465:	ff 15 45 70 13 00    	call   *0x137045(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec46b:	48 8d 15 3e c4 12 00 	lea    0x12c43e(%rip),%rdx        # 3188b0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x998>
  1ec472:	c5 f8 77             	vzeroupper
  1ec475:	ff 15 35 70 13 00    	call   *0x137035(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec47b:	48 8d 15 46 c4 12 00 	lea    0x12c446(%rip),%rdx        # 3188c8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9b0>
  1ec482:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
  1ec489:	00 
  1ec48a:	c5 f8 77             	vzeroupper
  1ec48d:	ff 15 1d 70 13 00    	call   *0x13701d(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec493:	48 8d 77 08          	lea    0x8(%rdi),%rsi
  1ec497:	48 8d 0d 32 bf 12 00 	lea    0x12bf32(%rip),%rcx        # 3183d0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x4b8>
  1ec49e:	4c 89 f2             	mov    %r14,%rdx
  1ec4a1:	c5 f8 77             	vzeroupper
  1ec4a4:	ff 15 56 70 13 00    	call   *0x137056(%rip)        # 323500 <_DYNAMIC+0x2b0>
  1ec4aa:	48 8d 15 cf c0 12 00 	lea    0x12c0cf(%rip),%rdx        # 318580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x668>
  1ec4b1:	4c 89 c7             	mov    %r8,%rdi
  1ec4b4:	4c 89 f6             	mov    %r14,%rsi
  1ec4b7:	c5 f8 77             	vzeroupper
  1ec4ba:	ff 15 f0 6f 13 00    	call   *0x136ff0(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec4c0:	48 8d 15 d1 c0 12 00 	lea    0x12c0d1(%rip),%rdx        # 318598 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x680>
  1ec4c7:	4c 89 c7             	mov    %r8,%rdi
  1ec4ca:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1ec4cf:	c5 f8 77             	vzeroupper
  1ec4d2:	ff 15 d8 6f 13 00    	call   *0x136fd8(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec4d8:	48 8d 15 89 c0 12 00 	lea    0x12c089(%rip),%rdx        # 318568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x650>
  1ec4df:	be 00 01 00 00       	mov    $0x100,%esi
  1ec4e4:	c5 f8 77             	vzeroupper
  1ec4e7:	ff 15 c3 6f 13 00    	call   *0x136fc3(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec4ed:	48 8d 77 08          	lea    0x8(%rdi),%rsi
  1ec4f1:	48 8d 0d c0 be 12 00 	lea    0x12bec0(%rip),%rcx        # 3183b8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x4a0>
  1ec4f8:	4c 89 f2             	mov    %r14,%rdx
  1ec4fb:	c5 f8 77             	vzeroupper
  1ec4fe:	ff 15 fc 6f 13 00    	call   *0x136ffc(%rip)        # 323500 <_DYNAMIC+0x2b0>
  1ec504:	48 8d 15 65 be 12 00 	lea    0x12be65(%rip),%rdx        # 318370 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x458>
  1ec50b:	48 89 f7             	mov    %rsi,%rdi
  1ec50e:	c5 f8 77             	vzeroupper
  1ec511:	ff 15 99 6f 13 00    	call   *0x136f99(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec517:	48 8d 15 3a be 12 00 	lea    0x12be3a(%rip),%rdx        # 318358 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x440>
  1ec51e:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
  1ec525:	00 
  1ec526:	48 89 fe             	mov    %rdi,%rsi
  1ec529:	c5 f8 77             	vzeroupper
  1ec52c:	ff 15 7e 6f 13 00    	call   *0x136f7e(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec532:	48 8d 15 df c4 12 00 	lea    0x12c4df(%rip),%rdx        # 318a18 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xb00>
  1ec539:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  1ec540:	00 
  1ec541:	c5 f8 77             	vzeroupper
  1ec544:	ff 15 66 6f 13 00    	call   *0x136f66(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec54a:	48 8d 15 f7 c4 12 00 	lea    0x12c4f7(%rip),%rdx        # 318a48 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xb30>
  1ec551:	4c 89 c6             	mov    %r8,%rsi
  1ec554:	c5 f8 77             	vzeroupper
  1ec557:	ff 15 53 6f 13 00    	call   *0x136f53(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec55d:	48 8d 15 fc c4 12 00 	lea    0x12c4fc(%rip),%rdx        # 318a60 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xb48>
  1ec564:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
  1ec56b:	00 
  1ec56c:	c5 f8 77             	vzeroupper
  1ec56f:	ff 15 3b 6f 13 00    	call   *0x136f3b(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec575:	48 8d 15 ac c0 12 00 	lea    0x12c0ac(%rip),%rdx        # 318628 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x710>
  1ec57c:	4c 89 c7             	mov    %r8,%rdi
  1ec57f:	4c 89 f6             	mov    %r14,%rsi
  1ec582:	c5 f8 77             	vzeroupper
  1ec585:	ff 15 25 6f 13 00    	call   *0x136f25(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec58b:	48 8d 15 9e c4 12 00 	lea    0x12c49e(%rip),%rdx        # 318a30 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xb18>
  1ec592:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  1ec599:	00 
  1ec59a:	c5 f8 77             	vzeroupper
  1ec59d:	ff 15 0d 6f 13 00    	call   *0x136f0d(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec5a3:	48 8d 15 4e bd 12 00 	lea    0x12bd4e(%rip),%rdx        # 3182f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x3e0>
  1ec5aa:	48 89 fe             	mov    %rdi,%rsi
  1ec5ad:	c5 f8 77             	vzeroupper
  1ec5b0:	ff 15 fa 6e 13 00    	call   *0x136efa(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec5b6:	48 8d 15 83 c0 12 00 	lea    0x12c083(%rip),%rdx        # 318640 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x728>
  1ec5bd:	be 00 01 00 00       	mov    $0x100,%esi
  1ec5c2:	48 89 c7             	mov    %rax,%rdi
  1ec5c5:	c5 f8 77             	vzeroupper
  1ec5c8:	ff 15 e2 6e 13 00    	call   *0x136ee2(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec5ce:	48 8d 15 23 c0 12 00 	lea    0x12c023(%rip),%rdx        # 3185f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x6e0>
  1ec5d5:	be 00 01 00 00       	mov    $0x100,%esi
  1ec5da:	c5 f8 77             	vzeroupper
  1ec5dd:	ff 15 cd 6e 13 00    	call   *0x136ecd(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec5e3:	48 8d 15 b6 bd 12 00 	lea    0x12bdb6(%rip),%rdx        # 3183a0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x488>
  1ec5ea:	4c 89 d7             	mov    %r10,%rdi
  1ec5ed:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  1ec5f2:	c5 f8 77             	vzeroupper
  1ec5f5:	ff 15 b5 6e 13 00    	call   *0x136eb5(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec5fb:	48 8d 15 8e c4 12 00 	lea    0x12c48e(%rip),%rdx        # 318a90 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xb78>
  1ec602:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
  1ec609:	00 
  1ec60a:	48 89 fe             	mov    %rdi,%rsi
  1ec60d:	c5 f8 77             	vzeroupper
  1ec610:	ff 15 9a 6e 13 00    	call   *0x136e9a(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec616:	48 8d 15 5b c4 12 00 	lea    0x12c45b(%rip),%rdx        # 318a78 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xb60>
  1ec61d:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  1ec622:	48 89 fe             	mov    %rdi,%rsi
  1ec625:	c5 f8 77             	vzeroupper
  1ec628:	ff 15 82 6e 13 00    	call   *0x136e82(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec62e:	48 8d 15 53 c3 12 00 	lea    0x12c353(%rip),%rdx        # 318988 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa70>
  1ec635:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
  1ec63c:	00 
  1ec63d:	48 89 fe             	mov    %rdi,%rsi
  1ec640:	c5 f8 77             	vzeroupper
  1ec643:	ff 15 67 6e 13 00    	call   *0x136e67(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec649:	48 8d 15 d8 c2 12 00 	lea    0x12c2d8(%rip),%rdx        # 318928 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa10>
  1ec650:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  1ec655:	48 89 fe             	mov    %rdi,%rsi
  1ec658:	c5 f8 77             	vzeroupper
  1ec65b:	ff 15 4f 6e 13 00    	call   *0x136e4f(%rip)        # 3234b0 <_DYNAMIC+0x260>
  1ec661:	48 8d 15 08 bd 12 00 	lea    0x12bd08(%rip),%rdx        # 318370 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x458>
  1ec668:	48 89 fe             	mov    %rdi,%rsi
  1ec66b:	c5 f8 77             	vzeroupper
  1ec66e:	ff 15 3c 6e 13 00    	call   *0x136e3c(%rip)        # 3234b0 <_DYNAMIC+0x260>
