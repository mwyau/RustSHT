
/tmp/rsh-b3-dynamic-leaf-profile-ceae53e2/ducc-clean-build/ducc_spin1_full_transform_parity:     file format elf64-x86-64


Disassembly of section .text:

000000000067c3e0 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]>:
  67c3e0:	55                   	push   %rbp
  67c3e1:	48 8d 41 02          	lea    0x2(%rcx),%rax
  67c3e5:	49 89 f3             	mov    %rsi,%r11
  67c3e8:	49 89 d2             	mov    %rdx,%r10
  67c3eb:	48 89 e5             	mov    %rsp,%rbp
  67c3ee:	41 55                	push   %r13
  67c3f0:	41 54                	push   %r12
  67c3f2:	4d 89 c4             	mov    %r8,%r12
  67c3f5:	4c 8b 45 10          	mov    0x10(%rbp),%r8
  67c3f9:	53                   	push   %rbx
  67c3fa:	48 89 cb             	mov    %rcx,%rbx
  67c3fd:	49 39 c1             	cmp    %rax,%r9
  67c400:	0f 82 93 01 00 00    	jb     67c599 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x1b9>
  67c406:	48 c1 e1 04          	shl    $0x4,%rcx
  67c40a:	4c 89 e6             	mov    %r12,%rsi
  67c40d:	48 01 d1             	add    %rdx,%rcx
  67c410:	4c 89 c2             	mov    %r8,%rdx
  67c413:	48 c1 e6 04          	shl    $0x4,%rsi
  67c417:	48 c1 e2 05          	shl    $0x5,%rdx
  67c41b:	4c 01 de             	add    %r11,%rsi
  67c41e:	48 01 fa             	add    %rdi,%rdx
  67c421:	4d 85 c0             	test   %r8,%r8
  67c424:	0f 84 44 01 00 00    	je     67c56e <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x18e>
  67c42a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  67c430:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  67c435:	c4 62 7d 19 3e       	vbroadcastsd (%rsi),%ymm15
  67c43a:	48 89 f8             	mov    %rdi,%rax
  67c43d:	c4 e2 7d 19 7e 08    	vbroadcastsd 0x8(%rsi),%ymm7
  67c443:	c4 e2 7d 19 76 10    	vbroadcastsd 0x10(%rsi),%ymm6
  67c449:	c4 41 7d 28 cb       	vmovapd %ymm11,%ymm9
  67c44e:	c4 41 7d 28 e3       	vmovapd %ymm11,%ymm12
  67c453:	c5 7d 29 db          	vmovapd %ymm11,%ymm3
  67c457:	c4 e2 7d 19 6e 18    	vbroadcastsd 0x18(%rsi),%ymm5
  67c45d:	c4 41 7d 28 eb       	vmovapd %ymm11,%ymm13
  67c462:	c4 41 7d 28 d3       	vmovapd %ymm11,%ymm10
  67c467:	c4 41 7d 28 f3       	vmovapd %ymm11,%ymm14
  67c46c:	c5 7d 29 dc          	vmovapd %ymm11,%ymm4
  67c470:	c5 fd 28 90 00 28 00 	vmovapd 0x2800(%rax),%ymm2
  67c477:	00 
  67c478:	c5 7d 29 f8          	vmovapd %ymm15,%ymm0
  67c47c:	48 83 c0 20          	add    $0x20,%rax
  67c480:	c5 fd 28 88 e0 1f 00 	vmovapd 0x1fe0(%rax),%ymm1
  67c487:	00 
  67c488:	c5 7d 28 80 e0 2f 00 	vmovapd 0x2fe0(%rax),%ymm8
  67c48f:	00 
  67c490:	c4 62 f5 b8 b0 e0 37 	vfmadd231pd 0x37e0(%rax),%ymm1,%ymm14
  67c497:	00 00 
  67c499:	c4 62 f5 b8 90 e0 3f 	vfmadd231pd 0x3fe0(%rax),%ymm1,%ymm10
  67c4a0:	00 00 
  67c4a2:	c4 e2 c5 98 c2       	vfmadd132pd %ymm2,%ymm7,%ymm0
  67c4a7:	c4 e2 f5 a8 80 e0 17 	vfmadd213pd 0x17e0(%rax),%ymm1,%ymm0
  67c4ae:	00 00 
  67c4b0:	c4 e2 d5 98 d6       	vfmadd132pd %ymm6,%ymm5,%ymm2
  67c4b5:	c4 62 fd b8 a0 e0 37 	vfmadd231pd 0x37e0(%rax),%ymm0,%ymm12
  67c4bc:	00 00 
  67c4be:	c4 c2 f5 b8 e0       	vfmadd231pd %ymm8,%ymm1,%ymm4
  67c4c3:	c4 62 fd b8 88 e0 3f 	vfmadd231pd 0x3fe0(%rax),%ymm0,%ymm9
  67c4ca:	00 00 
  67c4cc:	c4 62 fd b8 98 e0 47 	vfmadd231pd 0x47e0(%rax),%ymm0,%ymm11
  67c4d3:	00 00 
  67c4d5:	c4 62 f5 b8 a8 e0 47 	vfmadd231pd 0x47e0(%rax),%ymm1,%ymm13
  67c4dc:	00 00 
  67c4de:	c5 fd 29 80 e0 17 00 	vmovapd %ymm0,0x17e0(%rax)
  67c4e5:	00 
  67c4e6:	c4 e2 bd b8 d8       	vfmadd231pd %ymm0,%ymm8,%ymm3
  67c4eb:	c4 e2 f5 98 c2       	vfmadd132pd %ymm2,%ymm1,%ymm0
  67c4f0:	c5 fd 29 80 e0 1f 00 	vmovapd %ymm0,0x1fe0(%rax)
  67c4f7:	00 
  67c4f8:	48 39 c2             	cmp    %rax,%rdx
  67c4fb:	0f 85 6f ff ff ff    	jne    67c470 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x90>
  67c501:	c4 c1 5d 7c e6       	vhaddpd %ymm14,%ymm4,%ymm4
  67c506:	c4 41 2d 7c d5       	vhaddpd %ymm13,%ymm10,%ymm10
  67c50b:	49 83 c4 02          	add    $0x2,%r12
  67c50f:	48 83 c1 40          	add    $0x40,%rcx
  67c513:	c4 c1 65 7c dc       	vhaddpd %ymm12,%ymm3,%ymm3
  67c518:	c4 41 35 7c cb       	vhaddpd %ymm11,%ymm9,%ymm9
  67c51d:	48 83 c6 20          	add    $0x20,%rsi
  67c521:	4c 8d 6b 04          	lea    0x4(%rbx),%r13
  67c525:	48 83 c3 06          	add    $0x6,%rbx
  67c529:	c4 c3 5d 06 c2 31    	vperm2f128 $0x31,%ymm10,%ymm4,%ymm0
  67c52f:	c4 c3 5d 18 e2 01    	vinsertf128 $0x1,%xmm10,%ymm4,%ymm4
  67c535:	c5 fd 58 c4          	vaddpd %ymm4,%ymm0,%ymm0
  67c539:	c5 fd 58 41 c0       	vaddpd -0x40(%rcx),%ymm0,%ymm0
  67c53e:	c5 fd 11 41 c0       	vmovupd %ymm0,-0x40(%rcx)
  67c543:	c4 c3 65 06 c1 31    	vperm2f128 $0x31,%ymm9,%ymm3,%ymm0
  67c549:	c4 c3 65 18 d9 01    	vinsertf128 $0x1,%xmm9,%ymm3,%ymm3
  67c54f:	c5 fd 58 c3          	vaddpd %ymm3,%ymm0,%ymm0
  67c553:	c5 fd 58 41 e0       	vaddpd -0x20(%rcx),%ymm0,%ymm0
  67c558:	c5 fd 11 41 e0       	vmovupd %ymm0,-0x20(%rcx)
  67c55d:	49 39 d9             	cmp    %rbx,%r9
  67c560:	72 3e                	jb     67c5a0 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x1c0>
  67c562:	4c 89 eb             	mov    %r13,%rbx
  67c565:	4d 85 c0             	test   %r8,%r8
  67c568:	0f 85 c2 fe ff ff    	jne    67c430 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x50>
  67c56e:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  67c573:	c4 41 7d 28 cb       	vmovapd %ymm11,%ymm9
  67c578:	c4 41 7d 28 e3       	vmovapd %ymm11,%ymm12
  67c57d:	c5 7d 29 db          	vmovapd %ymm11,%ymm3
  67c581:	c4 41 7d 28 eb       	vmovapd %ymm11,%ymm13
  67c586:	c4 41 7d 28 d3       	vmovapd %ymm11,%ymm10
  67c58b:	c4 41 7d 28 f3       	vmovapd %ymm11,%ymm14
  67c590:	c5 7d 29 dc          	vmovapd %ymm11,%ymm4
  67c594:	e9 68 ff ff ff       	jmp    67c501 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x121>
  67c599:	49 89 cd             	mov    %rcx,%r13
  67c59c:	0f 1f 40 00          	nopl   0x0(%rax)
  67c5a0:	4d 39 e9             	cmp    %r13,%r9
  67c5a3:	0f 82 eb 00 00 00    	jb     67c694 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x2b4>
  67c5a9:	4c 89 e8             	mov    %r13,%rax
  67c5ac:	4c 89 c2             	mov    %r8,%rdx
  67c5af:	49 c1 e4 04          	shl    $0x4,%r12
  67c5b3:	48 c1 e0 04          	shl    $0x4,%rax
  67c5b7:	48 c1 e2 05          	shl    $0x5,%rdx
  67c5bb:	4d 01 e3             	add    %r12,%r11
  67c5be:	49 01 c2             	add    %rax,%r10
  67c5c1:	48 01 fa             	add    %rdi,%rdx
  67c5c4:	90                   	nop
  67c5c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  67c5cc:	00 00 00 00 
  67c5d0:	4d 85 c0             	test   %r8,%r8
  67c5d3:	0f 84 c7 00 00 00    	je     67c6a0 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x2c0>
  67c5d9:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  67c5dd:	c4 c2 7d 19 3b       	vbroadcastsd (%r11),%ymm7
  67c5e2:	c4 c2 7d 19 73 08    	vbroadcastsd 0x8(%r11),%ymm6
  67c5e8:	48 89 f8             	mov    %rdi,%rax
  67c5eb:	c5 fd 28 dc          	vmovapd %ymm4,%ymm3
  67c5ef:	c5 fd 28 ec          	vmovapd %ymm4,%ymm5
  67c5f3:	c5 fd 28 d4          	vmovapd %ymm4,%ymm2
  67c5f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  67c5fe:	00 00 
  67c600:	c5 fd 28 cf          	vmovapd %ymm7,%ymm1
  67c604:	c5 fd 28 80 00 20 00 	vmovapd 0x2000(%rax),%ymm0
  67c60b:	00 
  67c60c:	48 83 c0 20          	add    $0x20,%rax
  67c610:	c4 e2 cd 98 88 e0 27 	vfmadd132pd 0x27e0(%rax),%ymm6,%ymm1
  67c617:	00 00 
  67c619:	c4 e2 fd b8 90 e0 2f 	vfmadd231pd 0x2fe0(%rax),%ymm0,%ymm2
  67c620:	00 00 
  67c622:	c4 e2 fd a8 88 e0 17 	vfmadd213pd 0x17e0(%rax),%ymm0,%ymm1
  67c629:	00 00 
  67c62b:	c4 e2 fd b8 a8 e0 37 	vfmadd231pd 0x37e0(%rax),%ymm0,%ymm5
  67c632:	00 00 
  67c634:	c5 fd 29 80 e0 17 00 	vmovapd %ymm0,0x17e0(%rax)
  67c63b:	00 
  67c63c:	c4 e2 fd b8 98 e0 3f 	vfmadd231pd 0x3fe0(%rax),%ymm0,%ymm3
  67c643:	00 00 
  67c645:	c4 e2 fd b8 a0 e0 47 	vfmadd231pd 0x47e0(%rax),%ymm0,%ymm4
  67c64c:	00 00 
  67c64e:	c5 fd 29 88 e0 1f 00 	vmovapd %ymm1,0x1fe0(%rax)
  67c655:	00 
  67c656:	48 39 d0             	cmp    %rdx,%rax
  67c659:	75 a5                	jne    67c600 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x220>
  67c65b:	c5 ed 7c d5          	vhaddpd %ymm5,%ymm2,%ymm2
  67c65f:	c5 e5 7c dc          	vhaddpd %ymm4,%ymm3,%ymm3
  67c663:	49 83 c5 02          	add    $0x2,%r13
  67c667:	49 83 c2 20          	add    $0x20,%r10
  67c66b:	49 83 c3 10          	add    $0x10,%r11
  67c66f:	c4 e3 6d 06 c3 31    	vperm2f128 $0x31,%ymm3,%ymm2,%ymm0
  67c675:	c4 e3 6d 18 d3 01    	vinsertf128 $0x1,%xmm3,%ymm2,%ymm2
  67c67b:	c5 fd 58 c2          	vaddpd %ymm2,%ymm0,%ymm0
  67c67f:	c4 c1 7d 58 42 e0    	vaddpd -0x20(%r10),%ymm0,%ymm0
  67c685:	c4 c1 7d 11 42 e0    	vmovupd %ymm0,-0x20(%r10)
  67c68b:	4d 39 e9             	cmp    %r13,%r9
  67c68e:	0f 83 3c ff ff ff    	jae    67c5d0 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x1f0>
  67c694:	c5 f8 77             	vzeroupper
  67c697:	5b                   	pop    %rbx
  67c698:	41 5c                	pop    %r12
  67c69a:	41 5d                	pop    %r13
  67c69c:	5d                   	pop    %rbp
  67c69d:	c3                   	ret
  67c69e:	66 90                	xchg   %ax,%ax
  67c6a0:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  67c6a4:	c5 fd 28 dc          	vmovapd %ymm4,%ymm3
  67c6a8:	c5 fd 28 ec          	vmovapd %ymm4,%ymm5
  67c6ac:	c5 fd 28 d4          	vmovapd %ymm4,%ymm2
  67c6b0:	eb a9                	jmp    67c65b <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x27b>
