
/tmp/rsh-b3-dynamic-leaf-profile-ceae53e2/target-current-f64/release/examples/m6_b3_analysis_callgrind_f64:     file format elf64-x86-64


Disassembly of section .text:

00000000001a0de0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>>:
  1a0de0:	55                   	push   %rbp
  1a0de1:	41 57                	push   %r15
  1a0de3:	41 56                	push   %r14
  1a0de5:	41 55                	push   %r13
  1a0de7:	41 54                	push   %r12
  1a0de9:	53                   	push   %rbx
  1a0dea:	48 81 ec 38 02 00 00 	sub    $0x238,%rsp
  1a0df1:	48 8b 87 a0 00 00 00 	mov    0xa0(%rdi),%rax
  1a0df8:	48 3b 87 b0 00 00 00 	cmp    0xb0(%rdi),%rax
  1a0dff:	0f 85 69 28 00 00    	jne    1a366e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1a0e05:	4c 8b 67 10          	mov    0x10(%rdi),%r12
  1a0e09:	48 8b 6f 20          	mov    0x20(%rdi),%rbp
  1a0e0d:	4c 8b 6f 50          	mov    0x50(%rdi),%r13
  1a0e11:	4c 8b 57 60          	mov    0x60(%rdi),%r10
  1a0e15:	4c 8b 5f 70          	mov    0x70(%rdi),%r11
  1a0e19:	4c 8b bf 80 00 00 00 	mov    0x80(%rdi),%r15
  1a0e20:	48 8b 8f e0 00 00 00 	mov    0xe0(%rdi),%rcx
  1a0e27:	48 8b 9f e8 00 00 00 	mov    0xe8(%rdi),%rbx
  1a0e2e:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
  1a0e35:	48 31 c2             	xor    %rax,%rdx
  1a0e38:	4c 89 e6             	mov    %r12,%rsi
  1a0e3b:	48 31 c6             	xor    %rax,%rsi
  1a0e3e:	48 09 d6             	or     %rdx,%rsi
  1a0e41:	48 89 ea             	mov    %rbp,%rdx
  1a0e44:	48 31 c2             	xor    %rax,%rdx
  1a0e47:	4d 89 e8             	mov    %r13,%r8
  1a0e4a:	49 31 c0             	xor    %rax,%r8
  1a0e4d:	49 09 d0             	or     %rdx,%r8
  1a0e50:	49 09 f0             	or     %rsi,%r8
  1a0e53:	4c 89 d2             	mov    %r10,%rdx
  1a0e56:	48 31 c2             	xor    %rax,%rdx
  1a0e59:	4c 89 de             	mov    %r11,%rsi
  1a0e5c:	48 31 c6             	xor    %rax,%rsi
  1a0e5f:	48 09 d6             	or     %rdx,%rsi
  1a0e62:	4c 89 fa             	mov    %r15,%rdx
  1a0e65:	48 31 c2             	xor    %rax,%rdx
  1a0e68:	48 09 f2             	or     %rsi,%rdx
  1a0e6b:	4c 09 c2             	or     %r8,%rdx
  1a0e6e:	48 85 c9             	test   %rcx,%rcx
  1a0e71:	40 0f 95 c6          	setne  %sil
  1a0e75:	48 31 d8             	xor    %rbx,%rax
  1a0e78:	48 09 d0             	or     %rdx,%rax
  1a0e7b:	0f 94 c0             	sete   %al
  1a0e7e:	40 84 f0             	test   %sil,%al
  1a0e81:	0f 84 e7 27 00 00    	je     1a366e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1a0e87:	48 39 9f f8 00 00 00 	cmp    %rbx,0xf8(%rdi)
  1a0e8e:	0f 85 da 27 00 00    	jne    1a366e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1a0e94:	48 39 9f 08 01 00 00 	cmp    %rbx,0x108(%rdi)
  1a0e9b:	0f 85 cd 27 00 00    	jne    1a366e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1a0ea1:	48 39 9f 18 01 00 00 	cmp    %rbx,0x118(%rdi)
  1a0ea8:	0f 85 c0 27 00 00    	jne    1a366e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1a0eae:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
  1a0eb5:	48 8b b7 d0 00 00 00 	mov    0xd0(%rdi),%rsi
  1a0ebc:	49 89 f9             	mov    %rdi,%r9
  1a0ebf:	48 8b bf 28 01 00 00 	mov    0x128(%rdi),%rdi
  1a0ec6:	49 89 f6             	mov    %rsi,%r14
  1a0ec9:	48 89 94 24 30 01 00 	mov    %rdx,0x130(%rsp)
  1a0ed0:	00 
  1a0ed1:	49 29 d6             	sub    %rdx,%r14
  1a0ed4:	49 8d 46 01          	lea    0x1(%r14),%rax
  1a0ed8:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
  1a0edd:	48 39 c7             	cmp    %rax,%rdi
  1a0ee0:	0f 82 88 27 00 00    	jb     1a366e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1a0ee6:	48 89 74 24 68       	mov    %rsi,0x68(%rsp)
  1a0eeb:	48 89 ac 24 18 01 00 	mov    %rbp,0x118(%rsp)
  1a0ef2:	00 
  1a0ef3:	4c 89 a4 24 98 00 00 	mov    %r12,0x98(%rsp)
  1a0efa:	00 
  1a0efb:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
  1a0f00:	4c 89 5c 24 78       	mov    %r11,0x78(%rsp)
  1a0f05:	4c 89 54 24 50       	mov    %r10,0x50(%rsp)
  1a0f0a:	49 8b b9 d8 00 00 00 	mov    0xd8(%r9),%rdi
  1a0f11:	49 8b 41 18          	mov    0x18(%r9),%rax
  1a0f15:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  1a0f1c:	00 
  1a0f1d:	49 8b 41 28          	mov    0x28(%r9),%rax
  1a0f21:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
  1a0f28:	00 
  1a0f29:	49 8b 41 30          	mov    0x30(%r9),%rax
  1a0f2d:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  1a0f34:	00 
  1a0f35:	49 8b 41 38          	mov    0x38(%r9),%rax
  1a0f39:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
  1a0f40:	00 
  1a0f41:	49 8b 41 40          	mov    0x40(%r9),%rax
  1a0f45:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  1a0f4a:	4d 8b 51 48          	mov    0x48(%r9),%r10
  1a0f4e:	49 8b 41 58          	mov    0x58(%r9),%rax
  1a0f52:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  1a0f57:	4d 8b 79 68          	mov    0x68(%r9),%r15
  1a0f5b:	49 83 c6 02          	add    $0x2,%r14
  1a0f5f:	4d 89 f0             	mov    %r14,%r8
  1a0f62:	49 d1 e8             	shr    $1,%r8
  1a0f65:	31 c0                	xor    %eax,%eax
  1a0f67:	4c 89 c2             	mov    %r8,%rdx
  1a0f6a:	48 83 ea 01          	sub    $0x1,%rdx
  1a0f6e:	48 0f 42 d0          	cmovb  %rax,%rdx
  1a0f72:	48 89 94 24 d8 01 00 	mov    %rdx,0x1d8(%rsp)
  1a0f79:	00 
  1a0f7a:	49 8b 51 78          	mov    0x78(%r9),%rdx
  1a0f7e:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
  1a0f83:	49 83 e8 02          	sub    $0x2,%r8
  1a0f87:	4c 0f 42 c0          	cmovb  %rax,%r8
  1a0f8b:	49 8b 81 88 00 00 00 	mov    0x88(%r9),%rax
  1a0f92:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  1a0f99:	00 
  1a0f9a:	49 8b 81 90 00 00 00 	mov    0x90(%r9),%rax
  1a0fa1:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  1a0fa6:	49 8b 91 f0 00 00 00 	mov    0xf0(%r9),%rdx
  1a0fad:	49 8b a9 00 01 00 00 	mov    0x100(%r9),%rbp
  1a0fb4:	4d 8b a1 10 01 00 00 	mov    0x110(%r9),%r12
  1a0fbb:	49 8b 81 20 01 00 00 	mov    0x120(%r9),%rax
  1a0fc2:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  1a0fc9:	00 
  1a0fca:	49 8b 81 98 00 00 00 	mov    0x98(%r9),%rax
  1a0fd1:	4d 8b 99 a8 00 00 00 	mov    0xa8(%r9),%r11
  1a0fd8:	4d 8b 89 b8 00 00 00 	mov    0xb8(%r9),%r9
  1a0fdf:	4c 89 8c 24 90 00 00 	mov    %r9,0x90(%rsp)
  1a0fe6:	00 
  1a0fe7:	4c 89 84 24 b8 00 00 	mov    %r8,0xb8(%rsp)
  1a0fee:	00 
  1a0fef:	4c 39 c7             	cmp    %r8,%rdi
  1a0ff2:	4c 89 a4 24 c0 00 00 	mov    %r12,0xc0(%rsp)
  1a0ff9:	00 
  1a0ffa:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
  1a0fff:	4c 89 7c 24 60       	mov    %r15,0x60(%rsp)
  1a1004:	4c 89 b4 24 00 02 00 	mov    %r14,0x200(%rsp)
  1a100b:	00 
  1a100c:	48 89 9c 24 08 01 00 	mov    %rbx,0x108(%rsp)
  1a1013:	00 
  1a1014:	73 7d                	jae    1a1093 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b3>
  1a1016:	4d 89 e8             	mov    %r13,%r8
  1a1019:	49 c1 e8 02          	shr    $0x2,%r8
  1a101d:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
  1a1022:	49 c1 e9 02          	shr    $0x2,%r9
  1a1026:	49 89 dc             	mov    %rbx,%r12
  1a1029:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
  1a102e:	48 c1 eb 02          	shr    $0x2,%rbx
  1a1032:	4c 8b 7c 24 70       	mov    0x70(%rsp),%r15
  1a1037:	49 c1 ef 02          	shr    $0x2,%r15
  1a103b:	49 c1 ec 02          	shr    $0x2,%r12
  1a103f:	4c 89 c6             	mov    %r8,%rsi
  1a1042:	4c 31 ce             	xor    %r9,%rsi
  1a1045:	4c 31 cb             	xor    %r9,%rbx
  1a1048:	48 09 f3             	or     %rsi,%rbx
  1a104b:	4d 31 cf             	xor    %r9,%r15
  1a104e:	4d 39 e0             	cmp    %r12,%r8
  1a1051:	4d 0f 42 e0          	cmovb  %r8,%r12
  1a1055:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
  1a105c:	00 
  1a105d:	49 09 df             	or     %rbx,%r15
  1a1060:	0f 84 ad 0d 00 00    	je     1a1e13 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1033>
  1a1066:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
  1a106d:	00 
  1a106e:	48 39 c7             	cmp    %rax,%rdi
  1a1071:	0f 83 34 27 00 00    	jae    1a37ab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29cb>
  1a1077:	48 3b 7c 24 58       	cmp    0x58(%rsp),%rdi
  1a107c:	0f 83 44 27 00 00    	jae    1a37c6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29e6>
  1a1082:	48 ff c7             	inc    %rdi
  1a1085:	48 39 c7             	cmp    %rax,%rdi
  1a1088:	0f 82 d5 25 00 00    	jb     1a3663 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2883>
  1a108e:	e9 fd 26 00 00       	jmp    1a3790 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29b0>
  1a1093:	4c 89 ac 24 28 01 00 	mov    %r13,0x128(%rsp)
  1a109a:	00 
  1a109b:	c6 44 24 07 01       	movb   $0x1,0x7(%rsp)
  1a10a0:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
  1a10a7:	00 
  1a10a8:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
  1a10ad:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
  1a10b2:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
  1a10b7:	49 89 c5             	mov    %rax,%r13
  1a10ba:	49 89 f8             	mov    %rdi,%r8
  1a10bd:	4c 8b 94 24 90 00 00 	mov    0x90(%rsp),%r10
  1a10c4:	00 
  1a10c5:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  1a10c9:	c5 fd c2 c0 00       	vcmpeqpd %ymm0,%ymm0,%ymm0
  1a10ce:	48 bf fe ff ff ff ff 	movabs $0x3fffffffffffffe,%rdi
  1a10d5:	ff ff 03 
  1a10d8:	4c 3b 84 24 d8 01 00 	cmp    0x1d8(%rsp),%r8
  1a10df:	00 
  1a10e0:	0f 83 76 0b 00 00    	jae    1a1c5c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xe7c>
  1a10e6:	49 89 df             	mov    %rbx,%r15
  1a10e9:	49 c1 ef 02          	shr    $0x2,%r15
  1a10ed:	89 d8                	mov    %ebx,%eax
  1a10ef:	83 e0 03             	and    $0x3,%eax
  1a10f2:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
  1a10f9:	00 
  1a10fa:	48 89 de             	mov    %rbx,%rsi
  1a10fd:	49 be fc ff ff ff ff 	movabs $0xffffffffffffffc,%r14
  1a1104:	ff ff 0f 
  1a1107:	4c 21 f6             	and    %r14,%rsi
  1a110a:	48 89 b4 24 f8 00 00 	mov    %rsi,0xf8(%rsp)
  1a1111:	00 
  1a1112:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
  1a1119:	00 
  1a111a:	49 89 f1             	mov    %rsi,%r9
  1a111d:	49 c1 e9 02          	shr    $0x2,%r9
  1a1121:	4c 89 8c 24 b0 00 00 	mov    %r9,0xb0(%rsp)
  1a1128:	00 
  1a1129:	49 21 ff             	and    %rdi,%r15
  1a112c:	49 c1 e7 05          	shl    $0x5,%r15
  1a1130:	4a 8d 04 39          	lea    (%rcx,%r15,1),%rax
  1a1134:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
  1a113b:	00 
  1a113c:	48 c1 eb 03          	shr    $0x3,%rbx
  1a1140:	48 89 9c 24 f0 01 00 	mov    %rbx,0x1f0(%rsp)
  1a1147:	00 
  1a1148:	4a 8d 04 3a          	lea    (%rdx,%r15,1),%rax
  1a114c:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  1a1153:	00 
  1a1154:	49 8d 04 2f          	lea    (%r15,%rbp,1),%rax
  1a1158:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  1a115f:	00 
  1a1160:	4d 01 e7             	add    %r12,%r15
  1a1163:	4c 89 bc 24 20 02 00 	mov    %r15,0x220(%rsp)
  1a116a:	00 
  1a116b:	48 89 f7             	mov    %rsi,%rdi
  1a116e:	48 c1 ef 03          	shr    $0x3,%rdi
  1a1172:	48 89 bc 24 88 00 00 	mov    %rdi,0x88(%rsp)
  1a1179:	00 
  1a117a:	4c 8b bc 24 28 01 00 	mov    0x128(%rsp),%r15
  1a1181:	00 
  1a1182:	4c 89 f8             	mov    %r15,%rax
  1a1185:	48 c1 e8 02          	shr    $0x2,%rax
  1a1189:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
  1a1190:	00 
  1a1191:	44 89 f8             	mov    %r15d,%eax
  1a1194:	83 e0 03             	and    $0x3,%eax
  1a1197:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  1a119e:	00 
  1a119f:	4d 21 f7             	and    %r14,%r15
  1a11a2:	4c 89 bc 24 50 01 00 	mov    %r15,0x150(%rsp)
  1a11a9:	00 
  1a11aa:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  1a11af:	48 89 fb             	mov    %rdi,%rbx
  1a11b2:	48 c1 eb 02          	shr    $0x2,%rbx
  1a11b6:	89 f8                	mov    %edi,%eax
  1a11b8:	83 e0 03             	and    $0x3,%eax
  1a11bb:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  1a11c2:	00 
  1a11c3:	4c 21 f7             	and    %r14,%rdi
  1a11c6:	48 89 bc 24 a8 00 00 	mov    %rdi,0xa8(%rsp)
  1a11cd:	00 
  1a11ce:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  1a11d3:	48 89 fe             	mov    %rdi,%rsi
  1a11d6:	48 c1 ee 02          	shr    $0x2,%rsi
  1a11da:	89 f8                	mov    %edi,%eax
  1a11dc:	83 e0 03             	and    $0x3,%eax
  1a11df:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  1a11e6:	00 
  1a11e7:	4c 21 f7             	and    %r14,%rdi
  1a11ea:	48 89 bc 24 80 00 00 	mov    %rdi,0x80(%rsp)
  1a11f1:	00 
  1a11f2:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  1a11f7:	48 89 f8             	mov    %rdi,%rax
  1a11fa:	48 c1 e8 02          	shr    $0x2,%rax
  1a11fe:	41 89 f9             	mov    %edi,%r9d
  1a1201:	41 83 e1 03          	and    $0x3,%r9d
  1a1205:	4c 21 f7             	and    %r14,%rdi
  1a1208:	48 89 bc 24 30 02 00 	mov    %rdi,0x230(%rsp)
  1a120f:	00 
  1a1210:	48 8b bc 24 18 01 00 	mov    0x118(%rsp),%rdi
  1a1217:	00 
  1a1218:	49 89 fe             	mov    %rdi,%r14
  1a121b:	49 bf fc ff ff ff ff 	movabs $0xffffffffffffffc,%r15
  1a1222:	ff ff 0f 
  1a1225:	4d 21 fe             	and    %r15,%r14
  1a1228:	4c 89 b4 24 28 02 00 	mov    %r14,0x228(%rsp)
  1a122f:	00 
  1a1230:	4c 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%r14
  1a1237:	00 
  1a1238:	4d 39 f0             	cmp    %r14,%r8
  1a123b:	4d 0f 47 f0          	cmova  %r8,%r14
  1a123f:	4c 89 b4 24 f0 00 00 	mov    %r14,0xf0(%rsp)
  1a1246:	00 
  1a1247:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
  1a124c:	4d 39 f0             	cmp    %r14,%r8
  1a124f:	4d 0f 47 f0          	cmova  %r8,%r14
  1a1253:	4c 89 b4 24 e8 00 00 	mov    %r14,0xe8(%rsp)
  1a125a:	00 
  1a125b:	4c 8b b4 24 78 01 00 	mov    0x178(%rsp),%r14
  1a1262:	00 
  1a1263:	4c 39 f3             	cmp    %r14,%rbx
  1a1266:	48 89 9c 24 b8 01 00 	mov    %rbx,0x1b8(%rsp)
  1a126d:	00 
  1a126e:	4c 0f 42 f3          	cmovb  %rbx,%r14
  1a1272:	4c 39 f6             	cmp    %r14,%rsi
  1a1275:	48 89 b4 24 b0 01 00 	mov    %rsi,0x1b0(%rsp)
  1a127c:	00 
  1a127d:	4c 0f 42 f6          	cmovb  %rsi,%r14
  1a1281:	4c 39 f0             	cmp    %r14,%rax
  1a1284:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
  1a128b:	00 
  1a128c:	4c 0f 42 f0          	cmovb  %rax,%r14
  1a1290:	4c 89 b4 24 a0 01 00 	mov    %r14,0x1a0(%rsp)
  1a1297:	00 
  1a1298:	48 89 f8             	mov    %rdi,%rax
  1a129b:	48 c1 e8 02          	shr    $0x2,%rax
  1a129f:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  1a12a6:	00 
  1a12a7:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  1a12ae:	00 
  1a12af:	48 8b b4 24 88 01 00 	mov    0x188(%rsp),%rsi
  1a12b6:	00 
  1a12b7:	48 39 c6             	cmp    %rax,%rsi
  1a12ba:	48 0f 42 c6          	cmovb  %rsi,%rax
  1a12be:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
  1a12c5:	00 
  1a12c6:	48 39 c6             	cmp    %rax,%rsi
  1a12c9:	48 0f 42 c6          	cmovb  %rsi,%rax
  1a12cd:	49 39 c1             	cmp    %rax,%r9
  1a12d0:	4c 89 8c 24 c0 01 00 	mov    %r9,0x1c0(%rsp)
  1a12d7:	00 
  1a12d8:	49 0f 42 c1          	cmovb  %r9,%rax
  1a12dc:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  1a12e3:	00 
  1a12e4:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  1a12eb:	00 
  1a12ec:	83 e0 03             	and    $0x3,%eax
  1a12ef:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  1a12f6:	00 
  1a12f7:	83 e7 03             	and    $0x3,%edi
  1a12fa:	48 89 bc 24 18 01 00 	mov    %rdi,0x118(%rsp)
  1a1301:	00 
  1a1302:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1a1306:	c4 e2 7d 19 1d c1 f7 	vbroadcastsd -0x18083f(%rip),%ymm3        # 20ad0 <anon.78df67f796aa28d9f7a9000f5aadab22.22.llvm.16697214829213932600+0x380>
  1a130d:	e7 ff 
  1a130f:	c5 fd 28 c8          	vmovapd %ymm0,%ymm1
  1a1313:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1a1318:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  1a131f:	00 
  1a1320:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  1a1325:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  1a132a:	48 89 8c 24 10 01 00 	mov    %rcx,0x110(%rsp)
  1a1331:	00 
  1a1332:	48 89 94 24 d0 01 00 	mov    %rdx,0x1d0(%rsp)
  1a1339:	00 
  1a133a:	eb 26                	jmp    1a1362 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x582>
  1a133c:	c5 dd 54 c9          	vandpd %ymm1,%ymm4,%ymm1
  1a1340:	49 ff c0             	inc    %r8
  1a1343:	4d 89 dd             	mov    %r11,%r13
  1a1346:	48 89 f0             	mov    %rsi,%rax
  1a1349:	49 89 db             	mov    %rbx,%r11
  1a134c:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  1a1351:	48 89 fe             	mov    %rdi,%rsi
  1a1354:	4c 3b 84 24 d8 01 00 	cmp    0x1d8(%rsp),%r8
  1a135b:	00 
  1a135c:	0f 83 d5 09 00 00    	jae    1a1d37 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xf57>
  1a1362:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
  1a1367:	4c 89 d3             	mov    %r10,%rbx
  1a136a:	49 89 c2             	mov    %rax,%r10
  1a136d:	48 89 f7             	mov    %rsi,%rdi
  1a1370:	48 c1 ef 03          	shr    $0x3,%rdi
  1a1374:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
  1a137b:	00 
  1a137c:	48 39 c7             	cmp    %rax,%rdi
  1a137f:	48 0f 43 f8          	cmovae %rax,%rdi
  1a1383:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  1a138a:	00 
  1a138b:	48 39 f8             	cmp    %rdi,%rax
  1a138e:	48 0f 42 f8          	cmovb  %rax,%rdi
  1a1392:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1a1397:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1a139b:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1a13a0:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1a13a5:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1a13aa:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1a13ae:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1a13b2:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1a13b6:	48 85 ff             	test   %rdi,%rdi
  1a13b9:	0f 84 16 01 00 00    	je     1a14d5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x6f5>
  1a13bf:	48 83 ff 01          	cmp    $0x1,%rdi
  1a13c3:	75 07                	jne    1a13cc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x5ec>
  1a13c5:	31 c0                	xor    %eax,%eax
  1a13c7:	e9 c3 00 00 00       	jmp    1a148f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x6af>
  1a13cc:	49 89 f9             	mov    %rdi,%r9
  1a13cf:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
  1a13d6:	ff ff 1f 
  1a13d9:	49 21 c1             	and    %rax,%r9
  1a13dc:	41 bf 60 00 00 00    	mov    $0x60,%r15d
  1a13e2:	31 c0                	xor    %eax,%eax
  1a13e4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1a13eb:	00 00 00 00 00 
  1a13f0:	c4 01 7d 10 64 3b a0 	vmovupd -0x60(%r11,%r15,1),%ymm12
  1a13f7:	c4 01 7d 10 6c 3b c0 	vmovupd -0x40(%r11,%r15,1),%ymm13
  1a13fe:	c4 01 7d 10 74 3b e0 	vmovupd -0x20(%r11,%r15,1),%ymm14
  1a1405:	c4 a2 9d b8 7c 39 a0 	vfmadd231pd -0x60(%rcx,%r15,1),%ymm12,%ymm7
  1a140c:	c4 22 9d b8 44 3a a0 	vfmadd231pd -0x60(%rdx,%r15,1),%ymm12,%ymm8
  1a1413:	c4 22 9d b8 4c 3d a0 	vfmadd231pd -0x60(%rbp,%r15,1),%ymm12,%ymm9
  1a141a:	c4 02 9d b8 54 3c a0 	vfmadd231pd -0x60(%r12,%r15,1),%ymm12,%ymm10
  1a1421:	c4 a2 95 b8 6c 39 c0 	vfmadd231pd -0x40(%rcx,%r15,1),%ymm13,%ymm5
  1a1428:	c4 a2 95 b8 74 3a c0 	vfmadd231pd -0x40(%rdx,%r15,1),%ymm13,%ymm6
  1a142f:	c4 a2 95 b8 64 3d c0 	vfmadd231pd -0x40(%rbp,%r15,1),%ymm13,%ymm4
  1a1436:	c4 02 95 b8 5c 3c c0 	vfmadd231pd -0x40(%r12,%r15,1),%ymm13,%ymm11
  1a143d:	c4 01 7d 10 24 3b    	vmovupd (%r11,%r15,1),%ymm12
  1a1443:	48 83 c0 02          	add    $0x2,%rax
  1a1447:	c4 a2 8d b8 7c 39 e0 	vfmadd231pd -0x20(%rcx,%r15,1),%ymm14,%ymm7
  1a144e:	c4 22 8d b8 44 3a e0 	vfmadd231pd -0x20(%rdx,%r15,1),%ymm14,%ymm8
  1a1455:	c4 22 8d b8 4c 3d e0 	vfmadd231pd -0x20(%rbp,%r15,1),%ymm14,%ymm9
  1a145c:	c4 02 8d b8 54 3c e0 	vfmadd231pd -0x20(%r12,%r15,1),%ymm14,%ymm10
  1a1463:	c4 a2 9d b8 2c 39    	vfmadd231pd (%rcx,%r15,1),%ymm12,%ymm5
  1a1469:	c4 a2 9d b8 34 3a    	vfmadd231pd (%rdx,%r15,1),%ymm12,%ymm6
  1a146f:	c4 a2 9d b8 64 3d 00 	vfmadd231pd 0x0(%rbp,%r15,1),%ymm12,%ymm4
  1a1476:	c4 02 9d b8 1c 3c    	vfmadd231pd (%r12,%r15,1),%ymm12,%ymm11
  1a147c:	49 83 ef 80          	sub    $0xffffffffffffff80,%r15
  1a1480:	49 39 c1             	cmp    %rax,%r9
  1a1483:	0f 85 67 ff ff ff    	jne    1a13f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x610>
  1a1489:	40 f6 c7 01          	test   $0x1,%dil
  1a148d:	74 46                	je     1a14d5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x6f5>
  1a148f:	48 c1 e0 06          	shl    $0x6,%rax
  1a1493:	c4 41 7d 10 24 03    	vmovupd (%r11,%rax,1),%ymm12
  1a1499:	c4 41 7d 10 6c 03 20 	vmovupd 0x20(%r11,%rax,1),%ymm13
  1a14a0:	c4 e2 9d b8 3c 01    	vfmadd231pd (%rcx,%rax,1),%ymm12,%ymm7
  1a14a6:	c4 62 9d b8 04 02    	vfmadd231pd (%rdx,%rax,1),%ymm12,%ymm8
  1a14ac:	c4 62 9d b8 4c 05 00 	vfmadd231pd 0x0(%rbp,%rax,1),%ymm12,%ymm9
  1a14b3:	c4 42 9d b8 14 04    	vfmadd231pd (%r12,%rax,1),%ymm12,%ymm10
  1a14b9:	c4 e2 95 b8 6c 01 20 	vfmadd231pd 0x20(%rcx,%rax,1),%ymm13,%ymm5
  1a14c0:	c4 e2 95 b8 74 02 20 	vfmadd231pd 0x20(%rdx,%rax,1),%ymm13,%ymm6
  1a14c7:	c4 e2 95 b8 64 05 20 	vfmadd231pd 0x20(%rbp,%rax,1),%ymm13,%ymm4
  1a14ce:	c4 42 95 b8 5c 04 20 	vfmadd231pd 0x20(%r12,%rax,1),%ymm13,%ymm11
  1a14d5:	49 89 f4             	mov    %rsi,%r12
  1a14d8:	49 c1 ec 02          	shr    $0x2,%r12
  1a14dc:	40 f6 c6 04          	test   $0x4,%sil
  1a14e0:	74 6b                	je     1a154d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x76d>
  1a14e2:	f6 84 24 98 00 00 00 	testb  $0x4,0x98(%rsp)
  1a14e9:	04 
  1a14ea:	0f 84 35 22 00 00    	je     1a3725 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2945>
  1a14f0:	f6 84 24 08 01 00 00 	testb  $0x4,0x108(%rsp)
  1a14f7:	04 
  1a14f8:	0f 84 3b 22 00 00    	je     1a3739 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2959>
  1a14fe:	4c 89 e0             	mov    %r12,%rax
  1a1501:	48 bf fe ff ff ff ff 	movabs $0x3fffffffffffffe,%rdi
  1a1508:	ff ff 03 
  1a150b:	48 21 f8             	and    %rdi,%rax
  1a150e:	48 c1 e0 05          	shl    $0x5,%rax
  1a1512:	4c 01 d8             	add    %r11,%rax
  1a1515:	c5 7d 10 20          	vmovupd (%rax),%ymm12
  1a1519:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
  1a1520:	00 
  1a1521:	c4 e2 9d b8 38       	vfmadd231pd (%rax),%ymm12,%ymm7
  1a1526:	48 8b 84 24 10 02 00 	mov    0x210(%rsp),%rax
  1a152d:	00 
  1a152e:	c4 62 9d b8 00       	vfmadd231pd (%rax),%ymm12,%ymm8
  1a1533:	48 8b 84 24 08 02 00 	mov    0x208(%rsp),%rax
  1a153a:	00 
  1a153b:	c4 62 9d b8 08       	vfmadd231pd (%rax),%ymm12,%ymm9
  1a1540:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
  1a1547:	00 
  1a1548:	c4 62 9d b8 10       	vfmadd231pd (%rax),%ymm12,%ymm10
  1a154d:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
  1a1554:	00 
  1a1555:	c4 41 25 58 d2       	vaddpd %ymm10,%ymm11,%ymm10
  1a155a:	c5 b5 58 e4          	vaddpd %ymm4,%ymm9,%ymm4
  1a155e:	c5 bd 58 f6          	vaddpd %ymm6,%ymm8,%ymm6
  1a1562:	c5 d5 58 ef          	vaddpd %ymm7,%ymm5,%ymm5
  1a1566:	41 89 f1             	mov    %esi,%r9d
  1a1569:	41 83 e1 03          	and    $0x3,%r9d
  1a156d:	49 89 f6             	mov    %rsi,%r14
  1a1570:	48 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%rax
  1a1577:	ff ff 0f 
  1a157a:	49 21 c6             	and    %rax,%r14
  1a157d:	c4 e3 7d 19 ef 01    	vextractf128 $0x1,%ymm5,%xmm7
  1a1583:	c5 d1 58 ef          	vaddpd %xmm7,%xmm5,%xmm5
  1a1587:	c5 d1 c6 fd 01       	vshufpd $0x1,%xmm5,%xmm5,%xmm7
  1a158c:	c5 d3 58 ef          	vaddsd %xmm7,%xmm5,%xmm5
  1a1590:	c4 e3 7d 19 f7 01    	vextractf128 $0x1,%ymm6,%xmm7
  1a1596:	c5 c9 58 f7          	vaddpd %xmm7,%xmm6,%xmm6
  1a159a:	c5 c9 c6 fe 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm7
  1a159f:	c5 cb 58 ff          	vaddsd %xmm7,%xmm6,%xmm7
  1a15a3:	c4 e3 7d 19 e6 01    	vextractf128 $0x1,%ymm4,%xmm6
  1a15a9:	c5 d9 58 e6          	vaddpd %xmm6,%xmm4,%xmm4
  1a15ad:	c5 d9 c6 f4 01       	vshufpd $0x1,%xmm4,%xmm4,%xmm6
  1a15b2:	c5 db 58 e6          	vaddsd %xmm6,%xmm4,%xmm4
  1a15b6:	c4 63 7d 19 d6 01    	vextractf128 $0x1,%ymm10,%xmm6
  1a15bc:	c5 a9 58 f6          	vaddpd %xmm6,%xmm10,%xmm6
  1a15c0:	c5 49 c6 c6 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm8
  1a15c5:	c5 bb 58 f6          	vaddsd %xmm6,%xmm8,%xmm6
  1a15c9:	4d 85 c9             	test   %r9,%r9
  1a15cc:	0f 84 8a 00 00 00    	je     1a165c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x87c>
  1a15d2:	41 8d 41 ff          	lea    -0x1(%r9),%eax
  1a15d6:	39 84 24 c8 01 00 00 	cmp    %eax,0x1c8(%rsp)
  1a15dd:	0f 86 27 21 00 00    	jbe    1a370a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x292a>
  1a15e3:	c4 01 7b 10 04 f3    	vmovsd (%r11,%r14,8),%xmm8
  1a15e9:	c4 e2 b9 b9 2c f9    	vfmadd231sd (%rcx,%rdi,8),%xmm8,%xmm5
  1a15ef:	c4 e2 b9 b9 3c fa    	vfmadd231sd (%rdx,%rdi,8),%xmm8,%xmm7
  1a15f5:	c4 e2 b9 b9 64 fd 00 	vfmadd231sd 0x0(%rbp,%rdi,8),%xmm8,%xmm4
  1a15fc:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  1a1603:	00 
  1a1604:	c4 e2 b9 b9 34 f8    	vfmadd231sd (%rax,%rdi,8),%xmm8,%xmm6
  1a160a:	41 83 f9 01          	cmp    $0x1,%r9d
  1a160e:	74 4c                	je     1a165c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x87c>
  1a1610:	c4 01 7b 10 44 f3 08 	vmovsd 0x8(%r11,%r14,8),%xmm8
  1a1617:	c4 e2 b9 b9 6c f9 08 	vfmadd231sd 0x8(%rcx,%rdi,8),%xmm8,%xmm5
  1a161e:	c4 e2 b9 b9 7c fa 08 	vfmadd231sd 0x8(%rdx,%rdi,8),%xmm8,%xmm7
  1a1625:	c4 e2 b9 b9 64 fd 08 	vfmadd231sd 0x8(%rbp,%rdi,8),%xmm8,%xmm4
  1a162c:	c4 e2 b9 b9 74 f8 08 	vfmadd231sd 0x8(%rax,%rdi,8),%xmm8,%xmm6
  1a1633:	41 83 f9 02          	cmp    $0x2,%r9d
  1a1637:	74 23                	je     1a165c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x87c>
  1a1639:	c4 01 7b 10 44 f3 10 	vmovsd 0x10(%r11,%r14,8),%xmm8
  1a1640:	c4 e2 b9 b9 6c f9 10 	vfmadd231sd 0x10(%rcx,%rdi,8),%xmm8,%xmm5
  1a1647:	c4 e2 b9 b9 7c fa 10 	vfmadd231sd 0x10(%rdx,%rdi,8),%xmm8,%xmm7
  1a164e:	c4 e2 b9 b9 64 fd 10 	vfmadd231sd 0x10(%rbp,%rdi,8),%xmm8,%xmm4
  1a1655:	c4 e2 b9 b9 74 f8 10 	vfmadd231sd 0x10(%rax,%rdi,8),%xmm8,%xmm6
  1a165c:	4c 89 ed             	mov    %r13,%rbp
  1a165f:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
  1a1664:	4f 8d 2c 00          	lea    (%r8,%r8,1),%r13
  1a1668:	4c 3b 6c 24 18       	cmp    0x18(%rsp),%r13
  1a166d:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  1a1672:	0f 83 7a 20 00 00    	jae    1a36f2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2912>
  1a1678:	4c 89 f1             	mov    %r14,%rcx
  1a167b:	4d 89 ef             	mov    %r13,%r15
  1a167e:	49 c1 e7 04          	shl    $0x4,%r15
  1a1682:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  1a1689:	00 
  1a168a:	c4 a1 7b 11 2c 3e    	vmovsd %xmm5,(%rsi,%r15,1)
  1a1690:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  1a1697:	00 
  1a1698:	4a 8d 04 40          	lea    (%rax,%r8,2),%rax
  1a169c:	c4 a1 7b 11 7c 3e 08 	vmovsd %xmm7,0x8(%rsi,%r15,1)
  1a16a3:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
  1a16aa:	00 
  1a16ab:	48 3b 44 24 68       	cmp    0x68(%rsp),%rax
  1a16b0:	73 26                	jae    1a16d8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x8f8>
  1a16b2:	49 8d 45 01          	lea    0x1(%r13),%rax
  1a16b6:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  1a16bb:	0f 83 a2 20 00 00    	jae    1a3763 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2983>
  1a16c1:	48 c1 e0 04          	shl    $0x4,%rax
  1a16c5:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  1a16cc:	00 
  1a16cd:	c5 fb 11 24 06       	vmovsd %xmm4,(%rsi,%rax,1)
  1a16d2:	c5 fb 11 74 06 08    	vmovsd %xmm6,0x8(%rsi,%rax,1)
  1a16d8:	4c 3b 84 24 f0 00 00 	cmp    0xf0(%rsp),%r8
  1a16df:	00 
  1a16e0:	0f 84 b9 1f 00 00    	je     1a369f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x28bf>
  1a16e6:	4c 3b 84 24 e8 00 00 	cmp    0xe8(%rsp),%r8
  1a16ed:	00 
  1a16ee:	0f 84 cb 1f 00 00    	je     1a36bf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x28df>
  1a16f4:	48 c1 ef 02          	shr    $0x2,%rdi
  1a16f8:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
  1a16fd:	4c 89 d0             	mov    %r10,%rax
  1a1700:	48 c1 e8 02          	shr    $0x2,%rax
  1a1704:	48 8b 94 24 a0 01 00 	mov    0x1a0(%rsp),%rdx
  1a170b:	00 
  1a170c:	48 39 d0             	cmp    %rdx,%rax
  1a170f:	48 0f 43 c2          	cmovae %rdx,%rax
  1a1713:	49 39 c4             	cmp    %rax,%r12
  1a1716:	49 0f 42 c4          	cmovb  %r12,%rax
  1a171a:	48 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%rsi
  1a1721:	00 
  1a1722:	c4 a2 7d 19 34 c6    	vbroadcastsd (%rsi,%r8,8),%ymm6
  1a1728:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
  1a172f:	00 
  1a1730:	48 39 c2             	cmp    %rax,%rdx
  1a1733:	48 0f 42 c2          	cmovb  %rdx,%rax
  1a1737:	48 8b b4 24 e0 01 00 	mov    0x1e0(%rsp),%rsi
  1a173e:	00 
  1a173f:	4c 89 44 24 40       	mov    %r8,0x40(%rsp)
  1a1744:	c4 a2 7d 19 2c c6    	vbroadcastsd (%rsi,%r8,8),%ymm5
  1a174a:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  1a1751:	00 
  1a1752:	48 39 c2             	cmp    %rax,%rdx
  1a1755:	48 0f 42 c2          	cmovb  %rdx,%rax
  1a1759:	48 39 c7             	cmp    %rax,%rdi
  1a175c:	48 89 bc 24 60 01 00 	mov    %rdi,0x160(%rsp)
  1a1763:	00 
  1a1764:	48 0f 42 c7          	cmovb  %rdi,%rax
  1a1768:	48 85 c0             	test   %rax,%rax
  1a176b:	0f 84 a0 00 00 00    	je     1a1811 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xa31>
  1a1771:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1a1776:	45 31 e4             	xor    %r12d,%r12d
  1a1779:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1a177e:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1a1782:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1a1787:	c5 fd 28 e0          	vmovapd %ymm0,%ymm4
  1a178b:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  1a1790:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  1a1795:	4c 8b 54 24 60       	mov    0x60(%rsp),%r10
  1a179a:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
  1a179f:	4c 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%r14
  1a17a6:	00 
  1a17a7:	48 89 ea             	mov    %rbp,%rdx
  1a17aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  1a17b0:	c4 01 7d 10 1c 23    	vmovupd (%r11,%r12,1),%ymm11
  1a17b6:	c4 22 a5 b8 04 27    	vfmadd231pd (%rdi,%r12,1),%ymm11,%ymm8
  1a17bc:	c4 22 a5 b8 0c 26    	vfmadd231pd (%rsi,%r12,1),%ymm11,%ymm9
  1a17c2:	c4 82 a5 b8 3c 22    	vfmadd231pd (%r10,%r12,1),%ymm11,%ymm7
  1a17c8:	c4 02 a5 b8 14 20    	vfmadd231pd (%r8,%r12,1),%ymm11,%ymm10
  1a17ce:	c4 01 7d 10 24 26    	vmovupd (%r14,%r12,1),%ymm12
  1a17d4:	c4 62 cd a8 e5       	vfmadd213pd %ymm5,%ymm6,%ymm12
  1a17d9:	c4 22 a5 a8 24 22    	vfmadd213pd (%rdx,%r12,1),%ymm11,%ymm12
  1a17df:	c4 21 7d 11 24 23    	vmovupd %ymm12,(%rbx,%r12,1)
  1a17e5:	c4 62 7d 19 1d fa f3 	vbroadcastsd -0x180c06(%rip),%ymm11        # 20be8 <anon.78df67f796aa28d9f7a9000f5aadab22.22.llvm.16697214829213932600+0x498>
  1a17ec:	e7 ff 
  1a17ee:	c4 41 1d 54 db       	vandpd %ymm11,%ymm12,%ymm11
  1a17f3:	c5 25 c2 e2 00       	vcmpeqpd %ymm2,%ymm11,%ymm12
  1a17f8:	c5 25 c2 db 1d       	vcmpge_oqpd %ymm3,%ymm11,%ymm11
  1a17fd:	c4 41 25 56 dc       	vorpd  %ymm12,%ymm11,%ymm11
  1a1802:	c5 a5 54 e4          	vandpd %ymm4,%ymm11,%ymm4
  1a1806:	49 83 c4 20          	add    $0x20,%r12
  1a180a:	48 ff c8             	dec    %rax
  1a180d:	75 a1                	jne    1a17b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x9d0>
  1a180f:	eb 17                	jmp    1a1828 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xa48>
  1a1811:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1a1816:	c5 fd 28 e0          	vmovapd %ymm0,%ymm4
  1a181a:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1a181e:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1a1823:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1a1828:	4c 8b 54 24 48       	mov    0x48(%rsp),%r10
  1a182d:	44 89 d2             	mov    %r10d,%edx
  1a1830:	83 e2 03             	and    $0x3,%edx
  1a1833:	48 be fc ff ff ff ff 	movabs $0xffffffffffffffc,%rsi
  1a183a:	ff ff 0f 
  1a183d:	49 21 f2             	and    %rsi,%r10
  1a1840:	c4 43 7d 19 c3 01    	vextractf128 $0x1,%ymm8,%xmm11
  1a1846:	c4 41 39 58 c3       	vaddpd %xmm11,%xmm8,%xmm8
  1a184b:	c4 41 39 c6 d8 01    	vshufpd $0x1,%xmm8,%xmm8,%xmm11
  1a1851:	c4 41 3b 58 c3       	vaddsd %xmm11,%xmm8,%xmm8
  1a1856:	c4 43 7d 19 cb 01    	vextractf128 $0x1,%ymm9,%xmm11
  1a185c:	c4 41 31 58 cb       	vaddpd %xmm11,%xmm9,%xmm9
  1a1861:	c4 41 31 c6 d9 01    	vshufpd $0x1,%xmm9,%xmm9,%xmm11
  1a1867:	c4 41 33 58 cb       	vaddsd %xmm11,%xmm9,%xmm9
  1a186c:	c4 c3 7d 19 fb 01    	vextractf128 $0x1,%ymm7,%xmm11
  1a1872:	c5 a1 58 ff          	vaddpd %xmm7,%xmm11,%xmm7
  1a1876:	c5 41 c6 df 01       	vshufpd $0x1,%xmm7,%xmm7,%xmm11
  1a187b:	c5 a3 58 ff          	vaddsd %xmm7,%xmm11,%xmm7
  1a187f:	c4 43 7d 19 d3 01    	vextractf128 $0x1,%ymm10,%xmm11
  1a1885:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  1a188a:	45 89 f4             	mov    %r14d,%r12d
  1a188d:	41 83 e4 03          	and    $0x3,%r12d
  1a1891:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  1a1898:	00 
  1a1899:	49 39 c4             	cmp    %rax,%r12
  1a189c:	4c 0f 43 e0          	cmovae %rax,%r12
  1a18a0:	c4 41 29 58 d3       	vaddpd %xmm11,%xmm10,%xmm10
  1a18a5:	4d 39 e1             	cmp    %r12,%r9
  1a18a8:	4d 0f 42 e1          	cmovb  %r9,%r12
  1a18ac:	c4 41 29 c6 da 01    	vshufpd $0x1,%xmm10,%xmm10,%xmm11
  1a18b2:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
  1a18b9:	00 
  1a18ba:	4c 39 e0             	cmp    %r12,%rax
  1a18bd:	4c 0f 42 e0          	cmovb  %rax,%r12
  1a18c1:	c4 41 2b 58 d3       	vaddsd %xmm11,%xmm10,%xmm10
  1a18c6:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
  1a18cd:	00 
  1a18ce:	4c 39 e0             	cmp    %r12,%rax
  1a18d1:	4c 0f 42 e0          	cmovb  %rax,%r12
  1a18d5:	4c 39 e2             	cmp    %r12,%rdx
  1a18d8:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
  1a18df:	00 
  1a18e0:	4c 0f 42 e2          	cmovb  %rdx,%r12
  1a18e4:	4d 85 e4             	test   %r12,%r12
  1a18e7:	4c 89 94 24 40 01 00 	mov    %r10,0x140(%rsp)
  1a18ee:	00 
  1a18ef:	0f 84 ff 00 00 00    	je     1a19f4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xc14>
  1a18f5:	4c 89 f0             	mov    %r14,%rax
  1a18f8:	48 21 f0             	and    %rsi,%rax
  1a18fb:	c4 41 7b 10 1c cb    	vmovsd (%r11,%rcx,8),%xmm11
  1a1901:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  1a1908:	00 
  1a1909:	48 8b bc 24 28 02 00 	mov    0x228(%rsp),%rdi
  1a1910:	00 
  1a1911:	c5 7b 10 24 fe       	vmovsd (%rsi,%rdi,8),%xmm12
  1a1916:	c4 62 c9 a9 e5       	vfmadd213sd %xmm5,%xmm6,%xmm12
  1a191b:	48 89 ac 24 90 00 00 	mov    %rbp,0x90(%rsp)
  1a1922:	00 
  1a1923:	c4 62 a1 a9 64 c5 00 	vfmadd213sd 0x0(%rbp,%rax,8),%xmm11,%xmm12
  1a192a:	c4 41 f9 7e e1       	vmovq  %xmm12,%r9
  1a192f:	b2 3f                	mov    $0x3f,%dl
  1a1931:	c4 42 e8 f5 c9       	bzhi   %rdx,%r9,%r9
  1a1936:	48 ba 00 00 00 00 00 	movabs $0x7ff0000000000000,%rdx
  1a193d:	00 f0 7f 
  1a1940:	49 39 d1             	cmp    %rdx,%r9
  1a1943:	41 0f 94 c0          	sete   %r8b
  1a1947:	4d 85 c9             	test   %r9,%r9
  1a194a:	41 0f 94 c6          	sete   %r14b
  1a194e:	45 08 c6             	or     %r8b,%r14b
  1a1951:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  1a1956:	4c 8b 84 24 50 01 00 	mov    0x150(%rsp),%r8
  1a195d:	00 
  1a195e:	c4 22 a1 b9 04 c2    	vfmadd231sd (%rdx,%r8,8),%xmm11,%xmm8
  1a1964:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  1a1969:	4c 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%r8
  1a1970:	00 
  1a1971:	c4 22 a1 b9 0c c2    	vfmadd231sd (%rdx,%r8,8),%xmm11,%xmm9
  1a1977:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  1a197c:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  1a1983:	00 
  1a1984:	c4 a2 a1 b9 3c c2    	vfmadd231sd (%rdx,%r8,8),%xmm11,%xmm7
  1a198a:	48 ba 00 00 00 00 00 	movabs $0xfff0000000000000,%rdx
  1a1991:	00 f0 ff 
  1a1994:	49 01 d1             	add    %rdx,%r9
  1a1997:	49 c1 e9 35          	shr    $0x35,%r9
  1a199b:	41 81 f9 ff 03 00 00 	cmp    $0x3ff,%r9d
  1a19a2:	48 8b 94 24 30 02 00 	mov    0x230(%rsp),%rdx
  1a19a9:	00 
  1a19aa:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
  1a19af:	c4 42 a1 b9 14 d0    	vfmadd231sd (%r8,%rdx,8),%xmm11,%xmm10
  1a19b5:	41 0f 92 c1          	setb   %r9b
  1a19b9:	45 08 f1             	or     %r14b,%r9b
  1a19bc:	c4 21 7b 11 24 d3    	vmovsd %xmm12,(%rbx,%r10,8)
  1a19c2:	41 83 fc 01          	cmp    $0x1,%r12d
  1a19c6:	75 63                	jne    1a1a2b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xc4b>
  1a19c8:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  1a19cd:	4c 8b a4 24 c0 00 00 	mov    0xc0(%rsp),%r12
  1a19d4:	00 
  1a19d5:	4c 8b 94 24 90 00 00 	mov    0x90(%rsp),%r10
  1a19dc:	00 
  1a19dd:	48 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%rbp
  1a19e4:	00 
  1a19e5:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
  1a19ea:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  1a19ef:	e9 f3 01 00 00       	jmp    1a1be7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xe07>
  1a19f4:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  1a19f9:	4c 8b a4 24 c0 00 00 	mov    0xc0(%rsp),%r12
  1a1a00:	00 
  1a1a01:	49 89 ea             	mov    %rbp,%r10
  1a1a04:	48 8b 94 24 d0 01 00 	mov    0x1d0(%rsp),%rdx
  1a1a0b:	00 
  1a1a0c:	48 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%rbp
  1a1a13:	00 
  1a1a14:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
  1a1a19:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  1a1a1e:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  1a1a25:	00 
  1a1a26:	e9 d6 01 00 00       	jmp    1a1c01 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xe21>
  1a1a2b:	4c 89 d5             	mov    %r10,%rbp
  1a1a2e:	c4 41 7b 10 5c cb 08 	vmovsd 0x8(%r11,%rcx,8),%xmm11
  1a1a35:	c5 7b 10 64 fe 08    	vmovsd 0x8(%rsi,%rdi,8),%xmm12
  1a1a3b:	c4 62 c9 a9 e5       	vfmadd213sd %xmm5,%xmm6,%xmm12
  1a1a40:	4c 8b 84 24 90 00 00 	mov    0x90(%rsp),%r8
  1a1a47:	00 
  1a1a48:	c4 42 a1 a9 64 c0 08 	vfmadd213sd 0x8(%r8,%rax,8),%xmm11,%xmm12
  1a1a4f:	c4 41 f9 7e e0       	vmovq  %xmm12,%r8
  1a1a54:	41 b2 3f             	mov    $0x3f,%r10b
  1a1a57:	c4 42 a8 f5 c0       	bzhi   %r10,%r8,%r8
  1a1a5c:	49 ba 00 00 00 00 00 	movabs $0x7ff0000000000000,%r10
  1a1a63:	00 f0 7f 
  1a1a66:	4d 39 d0             	cmp    %r10,%r8
  1a1a69:	41 0f 94 c6          	sete   %r14b
  1a1a6d:	4d 85 c0             	test   %r8,%r8
  1a1a70:	41 0f 94 c2          	sete   %r10b
  1a1a74:	45 08 f2             	or     %r14b,%r10b
  1a1a77:	48 be 00 00 00 00 00 	movabs $0xfff0000000000000,%rsi
  1a1a7e:	00 f0 ff 
  1a1a81:	49 01 f0             	add    %rsi,%r8
  1a1a84:	49 c1 e8 35          	shr    $0x35,%r8
  1a1a88:	41 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8d
  1a1a8f:	41 0f 92 c0          	setb   %r8b
  1a1a93:	45 08 d0             	or     %r10b,%r8b
  1a1a96:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  1a1a9b:	4c 8b 94 24 50 01 00 	mov    0x150(%rsp),%r10
  1a1aa2:	00 
  1a1aa3:	c4 22 a1 b9 44 d6 08 	vfmadd231sd 0x8(%rsi,%r10,8),%xmm11,%xmm8
  1a1aaa:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  1a1aaf:	4c 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%r10
  1a1ab6:	00 
  1a1ab7:	c4 22 a1 b9 4c d6 08 	vfmadd231sd 0x8(%rsi,%r10,8),%xmm11,%xmm9
  1a1abe:	4c 8b 54 24 60       	mov    0x60(%rsp),%r10
  1a1ac3:	4c 8b b4 24 80 00 00 	mov    0x80(%rsp),%r14
  1a1aca:	00 
  1a1acb:	c4 82 a1 b9 7c f2 08 	vfmadd231sd 0x8(%r10,%r14,8),%xmm11,%xmm7
  1a1ad2:	4c 8b 54 24 20       	mov    0x20(%rsp),%r10
  1a1ad7:	c4 42 a1 b9 54 d2 08 	vfmadd231sd 0x8(%r10,%rdx,8),%xmm11,%xmm10
  1a1ade:	45 20 c1             	and    %r8b,%r9b
  1a1ae1:	c5 7b 11 64 eb 08    	vmovsd %xmm12,0x8(%rbx,%rbp,8)
  1a1ae7:	41 83 fc 02          	cmp    $0x2,%r12d
  1a1aeb:	49 89 ee             	mov    %rbp,%r14
  1a1aee:	48 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%rbp
  1a1af5:	00 
  1a1af6:	75 1f                	jne    1a1b17 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xd37>
  1a1af8:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  1a1afd:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  1a1b02:	4c 8b a4 24 c0 00 00 	mov    0xc0(%rsp),%r12
  1a1b09:	00 
  1a1b0a:	4c 8b 94 24 90 00 00 	mov    0x90(%rsp),%r10
  1a1b11:	00 
  1a1b12:	e9 cb 00 00 00       	jmp    1a1be2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xe02>
  1a1b17:	c4 41 7b 10 5c cb 10 	vmovsd 0x10(%r11,%rcx,8),%xmm11
  1a1b1e:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  1a1b25:	00 
  1a1b26:	c4 e2 c9 b9 6c f9 10 	vfmadd231sd 0x10(%rcx,%rdi,8),%xmm6,%xmm5
  1a1b2d:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  1a1b34:	00 
  1a1b35:	c4 e2 a1 a9 6c c1 10 	vfmadd213sd 0x10(%rcx,%rax,8),%xmm11,%xmm5
  1a1b3c:	c4 e1 f9 7e e8       	vmovq  %xmm5,%rax
  1a1b41:	40 b7 3f             	mov    $0x3f,%dil
  1a1b44:	c4 e2 c0 f5 c0       	bzhi   %rdi,%rax,%rax
  1a1b49:	48 bf 00 00 00 00 00 	movabs $0x7ff0000000000000,%rdi
  1a1b50:	00 f0 7f 
  1a1b53:	48 39 f8             	cmp    %rdi,%rax
  1a1b56:	41 0f 94 c2          	sete   %r10b
  1a1b5a:	48 85 c0             	test   %rax,%rax
  1a1b5d:	41 0f 94 c0          	sete   %r8b
  1a1b61:	45 08 d0             	or     %r10b,%r8b
  1a1b64:	48 bf 00 00 00 00 00 	movabs $0xfff0000000000000,%rdi
  1a1b6b:	00 f0 ff 
  1a1b6e:	48 01 f8             	add    %rdi,%rax
  1a1b71:	48 c1 e8 35          	shr    $0x35,%rax
  1a1b75:	3d ff 03 00 00       	cmp    $0x3ff,%eax
  1a1b7a:	0f 92 c0             	setb   %al
  1a1b7d:	44 08 c0             	or     %r8b,%al
  1a1b80:	41 20 c1             	and    %al,%r9b
  1a1b83:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  1a1b88:	48 8b bc 24 50 01 00 	mov    0x150(%rsp),%rdi
  1a1b8f:	00 
  1a1b90:	c4 62 a1 b9 44 f8 10 	vfmadd231sd 0x10(%rax,%rdi,8),%xmm11,%xmm8
  1a1b97:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  1a1b9e:	00 
  1a1b9f:	c4 62 a1 b9 4c c6 10 	vfmadd231sd 0x10(%rsi,%rax,8),%xmm11,%xmm9
  1a1ba6:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  1a1bab:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  1a1bb2:	00 
  1a1bb3:	c4 e2 a1 b9 7c f0 10 	vfmadd231sd 0x10(%rax,%rsi,8),%xmm11,%xmm7
  1a1bba:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  1a1bbf:	c4 62 a1 b9 54 d0 10 	vfmadd231sd 0x10(%rax,%rdx,8),%xmm11,%xmm10
  1a1bc6:	c4 a1 7b 11 6c f3 10 	vmovsd %xmm5,0x10(%rbx,%r14,8)
  1a1bcd:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  1a1bd2:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  1a1bd7:	4c 8b a4 24 c0 00 00 	mov    0xc0(%rsp),%r12
  1a1bde:	00 
  1a1bdf:	49 89 ca             	mov    %rcx,%r10
  1a1be2:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
  1a1be7:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  1a1bec:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  1a1bf3:	00 
  1a1bf4:	44 20 4c 24 07       	and    %r9b,0x7(%rsp)
  1a1bf9:	48 8b 94 24 d0 01 00 	mov    0x1d0(%rsp),%rdx
  1a1c00:	00 
  1a1c01:	49 39 fd             	cmp    %rdi,%r13
  1a1c04:	0f 83 d2 1a 00 00    	jae    1a36dc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x28fc>
  1a1c0a:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1a1c11:	00 
  1a1c12:	c4 21 7b 11 04 38    	vmovsd %xmm8,(%rax,%r15,1)
  1a1c18:	c4 21 7b 11 4c 38 08 	vmovsd %xmm9,0x8(%rax,%r15,1)
  1a1c1f:	48 39 b4 24 38 01 00 	cmp    %rsi,0x138(%rsp)
  1a1c26:	00 
  1a1c27:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1a1c2c:	0f 83 0a f7 ff ff    	jae    1a133c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x55c>
  1a1c32:	49 ff c5             	inc    %r13
  1a1c35:	49 39 fd             	cmp    %rdi,%r13
  1a1c38:	0f 83 0f 1b 00 00    	jae    1a374d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x296d>
  1a1c3e:	49 c1 e5 04          	shl    $0x4,%r13
  1a1c42:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1a1c49:	00 
  1a1c4a:	c4 a1 7b 11 3c 28    	vmovsd %xmm7,(%rax,%r13,1)
  1a1c50:	c4 21 7b 11 54 28 08 	vmovsd %xmm10,0x8(%rax,%r13,1)
  1a1c57:	e9 e0 f6 ff ff       	jmp    1a133c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x55c>
  1a1c5c:	4c 8b ac 24 28 01 00 	mov    0x128(%rsp),%r13
  1a1c63:	00 
  1a1c64:	4c 89 e8             	mov    %r13,%rax
  1a1c67:	48 c1 e8 02          	shr    $0x2,%rax
  1a1c6b:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
  1a1c72:	00 
  1a1c73:	44 89 e8             	mov    %r13d,%eax
  1a1c76:	83 e0 03             	and    $0x3,%eax
  1a1c79:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  1a1c80:	00 
  1a1c81:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
  1a1c86:	4c 89 c8             	mov    %r9,%rax
  1a1c89:	48 c1 e8 02          	shr    $0x2,%rax
  1a1c8d:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
  1a1c94:	00 
  1a1c95:	44 89 c8             	mov    %r9d,%eax
  1a1c98:	83 e0 03             	and    $0x3,%eax
  1a1c9b:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  1a1ca2:	00 
  1a1ca3:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
  1a1ca8:	48 89 f0             	mov    %rsi,%rax
  1a1cab:	48 c1 e8 02          	shr    $0x2,%rax
  1a1caf:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
  1a1cb6:	00 
  1a1cb7:	89 f0                	mov    %esi,%eax
  1a1cb9:	83 e0 03             	and    $0x3,%eax
  1a1cbc:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  1a1cc3:	00 
  1a1cc4:	4c 8b 54 24 70       	mov    0x70(%rsp),%r10
  1a1cc9:	4c 89 d0             	mov    %r10,%rax
  1a1ccc:	48 c1 e8 02          	shr    $0x2,%rax
  1a1cd0:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
  1a1cd7:	00 
  1a1cd8:	44 89 d0             	mov    %r10d,%eax
  1a1cdb:	83 e0 03             	and    $0x3,%eax
  1a1cde:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  1a1ce5:	00 
  1a1ce6:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  1a1ceb:	49 89 fc             	mov    %rdi,%r12
  1a1cee:	49 c1 ec 02          	shr    $0x2,%r12
  1a1cf2:	89 f8                	mov    %edi,%eax
  1a1cf4:	83 e0 03             	and    $0x3,%eax
  1a1cf7:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  1a1cfe:	00 
  1a1cff:	49 89 f8             	mov    %rdi,%r8
  1a1d02:	48 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%rax
  1a1d09:	ff ff 0f 
  1a1d0c:	49 21 c0             	and    %rax,%r8
  1a1d0f:	4c 89 84 24 40 01 00 	mov    %r8,0x140(%rsp)
  1a1d16:	00 
  1a1d17:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  1a1d1e:	00 
  1a1d1f:	49 89 c0             	mov    %rax,%r8
  1a1d22:	49 c1 e8 02          	shr    $0x2,%r8
  1a1d26:	4c 89 84 24 b0 00 00 	mov    %r8,0xb0(%rsp)
  1a1d2d:	00 
  1a1d2e:	48 c1 e8 03          	shr    $0x3,%rax
  1a1d32:	49 89 c6             	mov    %rax,%r14
  1a1d35:	eb 3b                	jmp    1a1d72 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xf92>
  1a1d37:	c5 fd 28 c1          	vmovapd %ymm1,%ymm0
  1a1d3b:	49 89 db             	mov    %rbx,%r11
  1a1d3e:	48 8b 9c 24 08 01 00 	mov    0x108(%rsp),%rbx
  1a1d45:	00 
  1a1d46:	4c 8b ac 24 28 01 00 	mov    0x128(%rsp),%r13
  1a1d4d:	00 
  1a1d4e:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
  1a1d53:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
  1a1d58:	4c 8b 54 24 70       	mov    0x70(%rsp),%r10
  1a1d5d:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
  1a1d62:	4c 8b b4 24 88 00 00 	mov    0x88(%rsp),%r14
  1a1d69:	00 
  1a1d6a:	4c 8b a4 24 60 01 00 	mov    0x160(%rsp),%r12
  1a1d71:	00 
  1a1d72:	48 b8 fe ff ff ff ff 	movabs $0x3fffffffffffffe,%rax
  1a1d79:	ff ff 03 
  1a1d7c:	49 21 c4             	and    %rax,%r12
  1a1d7f:	49 c1 e4 05          	shl    $0x5,%r12
  1a1d83:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
  1a1d88:	48 c1 ef 03          	shr    $0x3,%rdi
  1a1d8c:	4c 89 e8             	mov    %r13,%rax
  1a1d8f:	48 c1 e8 03          	shr    $0x3,%rax
  1a1d93:	49 c1 e9 03          	shr    $0x3,%r9
  1a1d97:	49 39 c1             	cmp    %rax,%r9
  1a1d9a:	4c 0f 43 c8          	cmovae %rax,%r9
  1a1d9e:	48 89 f0             	mov    %rsi,%rax
  1a1da1:	48 c1 e8 03          	shr    $0x3,%rax
  1a1da5:	4c 39 c8             	cmp    %r9,%rax
  1a1da8:	49 0f 43 c1          	cmovae %r9,%rax
  1a1dac:	49 c1 ea 03          	shr    $0x3,%r10
  1a1db0:	49 39 c2             	cmp    %rax,%r10
  1a1db3:	4c 0f 43 d0          	cmovae %rax,%r10
  1a1db7:	4c 39 d7             	cmp    %r10,%rdi
  1a1dba:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
  1a1dbf:	4c 0f 42 d7          	cmovb  %rdi,%r10
  1a1dc3:	4d 39 d6             	cmp    %r10,%r14
  1a1dc6:	4d 0f 42 d6          	cmovb  %r14,%r10
  1a1dca:	4d 85 d2             	test   %r10,%r10
  1a1dcd:	4c 89 b4 24 88 00 00 	mov    %r14,0x88(%rsp)
  1a1dd4:	00 
  1a1dd5:	0f 84 6a 0f 00 00    	je     1a2d45 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1f65>
  1a1ddb:	49 83 fa 01          	cmp    $0x1,%r10
  1a1ddf:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  1a1de4:	0f 85 86 0f 00 00    	jne    1a2d70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1f90>
  1a1dea:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1a1dee:	45 31 c9             	xor    %r9d,%r9d
  1a1df1:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1a1df5:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1a1df9:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1a1dfd:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1a1e01:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1a1e05:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1a1e09:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1a1e0e:	e9 4c 10 00 00       	jmp    1a2e5f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x207f>
  1a1e13:	4c 8b 8c 24 98 00 00 	mov    0x98(%rsp),%r9
  1a1e1a:	00 
  1a1e1b:	49 c1 e9 02          	shr    $0x2,%r9
  1a1e1f:	4d 39 c1             	cmp    %r8,%r9
  1a1e22:	4c 8b 64 24 50       	mov    0x50(%rsp),%r12
  1a1e27:	0f 85 0e 18 00 00    	jne    1a363b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x285b>
  1a1e2d:	4c 8b 8c 24 18 01 00 	mov    0x118(%rsp),%r9
  1a1e34:	00 
  1a1e35:	49 c1 e9 02          	shr    $0x2,%r9
  1a1e39:	4d 39 c1             	cmp    %r8,%r9
  1a1e3c:	0f 85 f9 17 00 00    	jne    1a363b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x285b>
  1a1e42:	45 89 ef             	mov    %r13d,%r15d
  1a1e45:	41 83 e7 03          	and    $0x3,%r15d
  1a1e49:	45 89 e1             	mov    %r12d,%r9d
  1a1e4c:	41 83 e1 03          	and    $0x3,%r9d
  1a1e50:	45 39 cf             	cmp    %r9d,%r15d
  1a1e53:	0f 85 e2 17 00 00    	jne    1a363b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x285b>
  1a1e59:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
  1a1e5e:	83 e3 03             	and    $0x3,%ebx
  1a1e61:	44 39 cb             	cmp    %r9d,%ebx
  1a1e64:	0f 85 d1 17 00 00    	jne    1a363b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x285b>
  1a1e6a:	48 8b 5c 24 70       	mov    0x70(%rsp),%rbx
  1a1e6f:	83 e3 03             	and    $0x3,%ebx
  1a1e72:	44 39 cb             	cmp    %r9d,%ebx
  1a1e75:	0f 85 c0 17 00 00    	jne    1a363b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x285b>
  1a1e7b:	4c 8b 8c 24 98 00 00 	mov    0x98(%rsp),%r9
  1a1e82:	00 
  1a1e83:	41 83 e1 03          	and    $0x3,%r9d
  1a1e87:	45 39 f9             	cmp    %r15d,%r9d
  1a1e8a:	0f 85 ab 17 00 00    	jne    1a363b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x285b>
  1a1e90:	4c 8b 8c 24 18 01 00 	mov    0x118(%rsp),%r9
  1a1e97:	00 
  1a1e98:	41 83 e1 03          	and    $0x3,%r9d
  1a1e9c:	4c 89 8c 24 a0 01 00 	mov    %r9,0x1a0(%rsp)
  1a1ea3:	00 
  1a1ea4:	45 39 f9             	cmp    %r15d,%r9d
  1a1ea7:	0f 85 8e 17 00 00    	jne    1a363b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x285b>
  1a1ead:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
  1a1eb2:	4c 89 84 24 38 01 00 	mov    %r8,0x138(%rsp)
  1a1eb9:	00 
  1a1eba:	4c 89 ac 24 28 01 00 	mov    %r13,0x128(%rsp)
  1a1ec1:	00 
  1a1ec2:	49 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%r8
  1a1ec9:	ff ff 0f 
  1a1ecc:	4d 21 c5             	and    %r8,%r13
  1a1ecf:	4c 89 ac 24 f8 00 00 	mov    %r13,0xf8(%rsp)
  1a1ed6:	00 
  1a1ed7:	4d 21 c4             	and    %r8,%r12
  1a1eda:	4c 89 a4 24 80 00 00 	mov    %r12,0x80(%rsp)
  1a1ee1:	00 
  1a1ee2:	4c 8b 4c 24 78       	mov    0x78(%rsp),%r9
  1a1ee7:	4d 21 c1             	and    %r8,%r9
  1a1eea:	4c 89 8c 24 f0 00 00 	mov    %r9,0xf0(%rsp)
  1a1ef1:	00 
  1a1ef2:	4c 8b 4c 24 70       	mov    0x70(%rsp),%r9
  1a1ef7:	4d 21 c1             	and    %r8,%r9
  1a1efa:	4c 89 8c 24 e8 00 00 	mov    %r9,0xe8(%rsp)
  1a1f01:	00 
  1a1f02:	4c 8b 8c 24 18 01 00 	mov    0x118(%rsp),%r9
  1a1f09:	00 
  1a1f0a:	4d 21 c1             	and    %r8,%r9
  1a1f0d:	4c 89 8c 24 a0 00 00 	mov    %r9,0xa0(%rsp)
  1a1f14:	00 
  1a1f15:	4c 8b 8c 24 08 01 00 	mov    0x108(%rsp),%r9
  1a1f1c:	00 
  1a1f1d:	44 89 cb             	mov    %r9d,%ebx
  1a1f20:	83 e3 03             	and    $0x3,%ebx
  1a1f23:	4d 89 ce             	mov    %r9,%r14
  1a1f26:	4d 21 c6             	and    %r8,%r14
  1a1f29:	4c 89 b4 24 10 01 00 	mov    %r14,0x110(%rsp)
  1a1f30:	00 
  1a1f31:	48 8d 73 ff          	lea    -0x1(%rbx),%rsi
  1a1f35:	48 39 de             	cmp    %rbx,%rsi
  1a1f38:	48 89 9c 24 a8 00 00 	mov    %rbx,0xa8(%rsp)
  1a1f3f:	00 
  1a1f40:	48 0f 43 f3          	cmovae %rbx,%rsi
  1a1f44:	48 89 b4 24 98 01 00 	mov    %rsi,0x198(%rsp)
  1a1f4b:	00 
  1a1f4c:	48 8b b4 24 b0 00 00 	mov    0xb0(%rsp),%rsi
  1a1f53:	00 
  1a1f54:	48 83 e6 fe          	and    $0xfffffffffffffffe,%rsi
  1a1f58:	c6 44 24 07 01       	movb   $0x1,0x7(%rsp)
  1a1f5d:	49 89 f8             	mov    %rdi,%r8
  1a1f60:	4c 89 cf             	mov    %r9,%rdi
  1a1f63:	48 8b 9c 24 98 00 00 	mov    0x98(%rsp),%rbx
  1a1f6a:	00 
  1a1f6b:	4c 8b a4 24 c0 00 00 	mov    0xc0(%rsp),%r12
  1a1f72:	00 
  1a1f73:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
  1a1f78:	4c 8b b4 24 90 00 00 	mov    0x90(%rsp),%r14
  1a1f7f:	00 
  1a1f80:	48 89 b4 24 e0 00 00 	mov    %rsi,0xe0(%rsp)
  1a1f87:	00 
  1a1f88:	eb 29                	jmp    1a1fb3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x11d3>
  1a1f8a:	49 83 c0 02          	add    $0x2,%r8
  1a1f8e:	4c 89 e8             	mov    %r13,%rax
  1a1f91:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  1a1f96:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  1a1f9b:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
  1a1fa0:	4c 3b 84 24 b8 00 00 	cmp    0xb8(%rsp),%r8
  1a1fa7:	00 
  1a1fa8:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
  1a1fad:	0f 83 d2 16 00 00    	jae    1a3685 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x28a5>
  1a1fb3:	48 89 5c 24 48       	mov    %rbx,0x48(%rsp)
  1a1fb8:	4d 89 f5             	mov    %r14,%r13
  1a1fbb:	4d 89 de             	mov    %r11,%r14
  1a1fbe:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
  1a1fc3:	49 89 c3             	mov    %rax,%r11
  1a1fc6:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
  1a1fcd:	00 
  1a1fce:	49 39 c0             	cmp    %rax,%r8
  1a1fd1:	0f 83 d1 17 00 00    	jae    1a37a8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29c8>
  1a1fd7:	4c 3b 44 24 58       	cmp    0x58(%rsp),%r8
  1a1fdc:	48 8b 5c 24 30       	mov    0x30(%rsp),%rbx
  1a1fe1:	0f 83 dc 17 00 00    	jae    1a37c3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29e3>
  1a1fe7:	49 8d 78 01          	lea    0x1(%r8),%rdi
  1a1feb:	48 39 c7             	cmp    %rax,%rdi
  1a1fee:	0f 83 9c 17 00 00    	jae    1a3790 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29b0>
  1a1ff4:	48 3b 7c 24 58       	cmp    0x58(%rsp),%rdi
  1a1ff9:	0f 83 7c 17 00 00    	jae    1a377b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x299b>
  1a1fff:	31 c0                	xor    %eax,%eax
  1a2001:	4c 39 4c 24 28       	cmp    %r9,0x28(%rsp)
  1a2006:	0f 85 64 16 00 00    	jne    1a3670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2890>
  1a200c:	4c 39 4c 24 50       	cmp    %r9,0x50(%rsp)
  1a2011:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  1a2016:	48 8b bc 24 38 01 00 	mov    0x138(%rsp),%rdi
  1a201d:	00 
  1a201e:	0f 85 4c 16 00 00    	jne    1a3670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2890>
  1a2024:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  1a2029:	48 c1 e8 02          	shr    $0x2,%rax
  1a202d:	48 39 f8             	cmp    %rdi,%rax
  1a2030:	0f 85 38 16 00 00    	jne    1a366e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1a2036:	4c 89 fe             	mov    %r15,%rsi
  1a2039:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  1a203e:	89 c7                	mov    %eax,%edi
  1a2040:	83 e7 03             	and    $0x3,%edi
  1a2043:	31 c0                	xor    %eax,%eax
  1a2045:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
  1a204a:	44 39 ff             	cmp    %r15d,%edi
  1a204d:	0f 85 1d 16 00 00    	jne    1a3670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2890>
  1a2053:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  1a2058:	83 e7 03             	and    $0x3,%edi
  1a205b:	44 39 ff             	cmp    %r15d,%edi
  1a205e:	0f 85 0c 16 00 00    	jne    1a3670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2890>
  1a2064:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  1a2069:	48 c1 ef 02          	shr    $0x2,%rdi
  1a206d:	4c 8b bc 24 38 01 00 	mov    0x138(%rsp),%r15
  1a2074:	00 
  1a2075:	4c 39 ff             	cmp    %r15,%rdi
  1a2078:	0f 85 f2 15 00 00    	jne    1a3670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2890>
  1a207e:	48 8b 84 24 e8 01 00 	mov    0x1e8(%rsp),%rax
  1a2085:	00 
  1a2086:	c4 a1 7b 10 04 c0    	vmovsd (%rax,%r8,8),%xmm0
  1a208c:	48 8b bc 24 e0 01 00 	mov    0x1e0(%rsp),%rdi
  1a2093:	00 
  1a2094:	c4 a1 7b 10 1c c7    	vmovsd (%rdi,%r8,8),%xmm3
  1a209a:	c4 a1 7b 10 4c c0 08 	vmovsd 0x8(%rax,%r8,8),%xmm1
  1a20a1:	c4 a1 7b 10 54 c7 08 	vmovsd 0x8(%rdi,%r8,8),%xmm2
  1a20a8:	4d 85 ff             	test   %r15,%r15
  1a20ab:	c5 f9 29 84 24 60 01 	vmovapd %xmm0,0x160(%rsp)
  1a20b2:	00 00 
  1a20b4:	c5 f9 29 8c 24 50 01 	vmovapd %xmm1,0x150(%rsp)
  1a20bb:	00 00 
  1a20bd:	c5 f9 29 94 24 40 01 	vmovapd %xmm2,0x140(%rsp)
  1a20c4:	00 00 
  1a20c6:	c5 f9 29 9c 24 f0 01 	vmovapd %xmm3,0x1f0(%rsp)
  1a20cd:	00 00 
  1a20cf:	0f 84 d2 00 00 00    	je     1a21a7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x13c7>
  1a20d5:	c4 62 7d 19 e0       	vbroadcastsd %xmm0,%ymm12
  1a20da:	c4 62 7d 19 eb       	vbroadcastsd %xmm3,%ymm13
  1a20df:	c4 62 7d 19 f1       	vbroadcastsd %xmm1,%ymm14
  1a20e4:	c4 62 7d 19 fa       	vbroadcastsd %xmm2,%ymm15
  1a20e9:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1a20ed:	4c 89 f8             	mov    %r15,%rax
  1a20f0:	31 ff                	xor    %edi,%edi
  1a20f2:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1a20f6:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1a20fa:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1a20fe:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1a2102:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1a2106:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1a210b:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1a2110:	49 89 f7             	mov    %rsi,%r15
  1a2113:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  1a2118:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1a211f:	00 
  1a2120:	c4 41 7d 10 14 3e    	vmovupd (%r14,%rdi,1),%ymm10
  1a2126:	c5 7d 10 1c 3e       	vmovupd (%rsi,%rdi,1),%ymm11
  1a212b:	c4 42 a5 b8 c2       	vfmadd231pd %ymm10,%ymm11,%ymm8
  1a2130:	4c 8b 94 24 d0 00 00 	mov    0xd0(%rsp),%r10
  1a2137:	00 
  1a2138:	c4 c1 7d 10 04 3a    	vmovupd (%r10,%rdi,1),%ymm0
  1a213e:	c5 fd 28 c8          	vmovapd %ymm0,%ymm1
  1a2142:	c4 c2 9d a8 cd       	vfmadd213pd %ymm13,%ymm12,%ymm1
  1a2147:	c4 c2 ad a8 0c 3b    	vfmadd213pd (%r11,%rdi,1),%ymm10,%ymm1
  1a214d:	c4 c2 f5 b8 db       	vfmadd231pd %ymm11,%ymm1,%ymm3
  1a2152:	c5 7d 10 1c 3b       	vmovupd (%rbx,%rdi,1),%ymm11
  1a2157:	c4 42 a5 b8 ca       	vfmadd231pd %ymm10,%ymm11,%ymm9
  1a215c:	c4 c2 f5 b8 eb       	vfmadd231pd %ymm11,%ymm1,%ymm5
  1a2161:	c4 41 7d 10 1c 3f    	vmovupd (%r15,%rdi,1),%ymm11
  1a2167:	c4 c2 a5 b8 f2       	vfmadd231pd %ymm10,%ymm11,%ymm6
  1a216c:	c4 c2 f5 b8 d3       	vfmadd231pd %ymm11,%ymm1,%ymm2
  1a2171:	c4 41 7d 10 1c 39    	vmovupd (%r9,%rdi,1),%ymm11
  1a2177:	c4 c2 a5 b8 fa       	vfmadd231pd %ymm10,%ymm11,%ymm7
  1a217c:	c4 c2 f5 b8 e3       	vfmadd231pd %ymm11,%ymm1,%ymm4
  1a2181:	c4 c2 8d a8 c7       	vfmadd213pd %ymm15,%ymm14,%ymm0
  1a2186:	c4 c2 f5 a8 c2       	vfmadd213pd %ymm10,%ymm1,%ymm0
  1a218b:	c4 c1 7d 11 4c 3d 00 	vmovupd %ymm1,0x0(%r13,%rdi,1)
  1a2192:	c4 c1 7d 11 04 3b    	vmovupd %ymm0,(%r11,%rdi,1)
  1a2198:	48 83 c7 20          	add    $0x20,%rdi
  1a219c:	48 ff c8             	dec    %rax
  1a219f:	0f 85 7b ff ff ff    	jne    1a2120 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1340>
  1a21a5:	eb 25                	jmp    1a21cc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x13ec>
  1a21a7:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1a21ac:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1a21b1:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1a21b5:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1a21b9:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1a21bd:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1a21c1:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1a21c5:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1a21c9:	49 89 f7             	mov    %rsi,%r15
  1a21cc:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  1a21d1:	48 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%rax
  1a21d8:	ff ff 0f 
  1a21db:	48 21 c6             	and    %rax,%rsi
  1a21de:	c4 63 7d 19 c0 01    	vextractf128 $0x1,%ymm8,%xmm0
  1a21e4:	c5 b9 58 c0          	vaddpd %xmm0,%xmm8,%xmm0
  1a21e8:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1a21ed:	c5 7b 58 c1          	vaddsd %xmm1,%xmm0,%xmm8
  1a21f1:	c4 63 7d 19 c8 01    	vextractf128 $0x1,%ymm9,%xmm0
  1a21f7:	c5 b1 58 c0          	vaddpd %xmm0,%xmm9,%xmm0
  1a21fb:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1a2200:	c5 7b 58 c9          	vaddsd %xmm1,%xmm0,%xmm9
  1a2204:	c4 e3 7d 19 f0 01    	vextractf128 $0x1,%ymm6,%xmm0
  1a220a:	c5 c9 58 c0          	vaddpd %xmm0,%xmm6,%xmm0
  1a220e:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1a2213:	c5 fb 58 f1          	vaddsd %xmm1,%xmm0,%xmm6
  1a2217:	c4 e3 7d 19 f8 01    	vextractf128 $0x1,%ymm7,%xmm0
  1a221d:	c5 c1 58 c0          	vaddpd %xmm0,%xmm7,%xmm0
  1a2221:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1a2226:	c5 fb 58 f9          	vaddsd %xmm1,%xmm0,%xmm7
  1a222a:	c4 e3 7d 19 d8 01    	vextractf128 $0x1,%ymm3,%xmm0
  1a2230:	c5 e1 58 c0          	vaddpd %xmm0,%xmm3,%xmm0
  1a2234:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1a2239:	c5 fb 58 d9          	vaddsd %xmm1,%xmm0,%xmm3
  1a223d:	c4 e3 7d 19 e8 01    	vextractf128 $0x1,%ymm5,%xmm0
  1a2243:	c5 d1 58 c0          	vaddpd %xmm0,%xmm5,%xmm0
  1a2247:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1a224c:	c5 fb 58 e9          	vaddsd %xmm1,%xmm0,%xmm5
  1a2250:	c4 e3 7d 19 d0 01    	vextractf128 $0x1,%ymm2,%xmm0
  1a2256:	c5 e9 58 c0          	vaddpd %xmm0,%xmm2,%xmm0
  1a225a:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1a225f:	c5 fb 58 d1          	vaddsd %xmm1,%xmm0,%xmm2
  1a2263:	c4 e3 7d 19 e0 01    	vextractf128 $0x1,%ymm4,%xmm0
  1a2269:	c5 d9 58 c0          	vaddpd %xmm0,%xmm4,%xmm0
  1a226d:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1a2272:	c5 fb 58 e1          	vaddsd %xmm1,%xmm0,%xmm4
  1a2276:	48 83 bc 24 a0 01 00 	cmpq   $0x0,0x1a0(%rsp)
  1a227d:	00 00 
  1a227f:	48 89 b4 24 88 00 00 	mov    %rsi,0x88(%rsp)
  1a2286:	00 
  1a2287:	4c 89 b4 24 90 00 00 	mov    %r14,0x90(%rsp)
  1a228e:	00 
  1a228f:	0f 84 67 05 00 00    	je     1a27fc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1a1c>
  1a2295:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  1a229b:	0f 84 cd 13 00 00    	je     1a366e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1a22a1:	48 89 f0             	mov    %rsi,%rax
  1a22a4:	4c 89 44 24 40       	mov    %r8,0x40(%rsp)
  1a22a9:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1a22ae:	48 bf fc ff ff ff ff 	movabs $0xffffffffffffffc,%rdi
  1a22b5:	ff ff 0f 
  1a22b8:	48 21 fe             	and    %rdi,%rsi
  1a22bb:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
  1a22c2:	00 
  1a22c3:	4c 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%r8
  1a22ca:	00 
  1a22cb:	c4 41 7b 10 24 f8    	vmovsd (%r8,%rdi,8),%xmm12
  1a22d1:	c4 41 79 28 ec       	vmovapd %xmm12,%xmm13
  1a22d6:	c5 79 28 bc 24 60 01 	vmovapd 0x160(%rsp),%xmm15
  1a22dd:	00 00 
  1a22df:	c5 79 28 9c 24 f0 01 	vmovapd 0x1f0(%rsp),%xmm11
  1a22e6:	00 00 
  1a22e8:	c4 42 81 a9 eb       	vfmadd213sd %xmm11,%xmm15,%xmm13
  1a22ed:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  1a22f4:	00 
  1a22f5:	c4 41 7b 10 34 fe    	vmovsd (%r14,%rdi,8),%xmm14
  1a22fb:	c4 42 89 a9 2c f3    	vfmadd213sd (%r11,%rsi,8),%xmm14,%xmm13
  1a2301:	c5 f9 28 8c 24 50 01 	vmovapd 0x150(%rsp),%xmm1
  1a2308:	00 00 
  1a230a:	c5 79 28 94 24 40 01 	vmovapd 0x140(%rsp),%xmm10
  1a2311:	00 00 
  1a2313:	c4 42 f1 a9 e2       	vfmadd213sd %xmm10,%xmm1,%xmm12
  1a2318:	c4 42 91 a9 e6       	vfmadd213sd %xmm14,%xmm13,%xmm12
  1a231d:	4c 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%r8
  1a2324:	00 
  1a2325:	c4 81 7b 10 04 c1    	vmovsd (%r9,%r8,8),%xmm0
  1a232b:	c4 c2 f9 b9 e5       	vfmadd231sd %xmm13,%xmm0,%xmm4
  1a2330:	c4 e2 89 b9 f8       	vfmadd231sd %xmm0,%xmm14,%xmm7
  1a2335:	4c 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%r8
  1a233c:	00 
  1a233d:	c4 81 7b 10 04 c7    	vmovsd (%r15,%r8,8),%xmm0
  1a2343:	c4 c2 f9 b9 d5       	vfmadd231sd %xmm13,%xmm0,%xmm2
  1a2348:	c4 e2 89 b9 f0       	vfmadd231sd %xmm0,%xmm14,%xmm6
  1a234d:	c5 fb 10 04 fb       	vmovsd (%rbx,%rdi,8),%xmm0
  1a2352:	c4 c2 f9 b9 ed       	vfmadd231sd %xmm13,%xmm0,%xmm5
  1a2357:	c4 62 89 b9 c8       	vfmadd231sd %xmm0,%xmm14,%xmm9
  1a235c:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  1a2361:	4c 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%r8
  1a2368:	00 
  1a2369:	c4 a1 7b 10 04 c7    	vmovsd (%rdi,%r8,8),%xmm0
  1a236f:	c4 42 f9 b9 c6       	vfmadd231sd %xmm14,%xmm0,%xmm8
  1a2374:	c4 c2 f9 b9 dd       	vfmadd231sd %xmm13,%xmm0,%xmm3
  1a2379:	c4 41 7b 11 6c c5 00 	vmovsd %xmm13,0x0(%r13,%rax,8)
  1a2380:	c4 61 f9 7e ef       	vmovq  %xmm13,%rdi
  1a2385:	c4 41 f9 7e e0       	vmovq  %xmm12,%r8
  1a238a:	48 89 b4 24 20 01 00 	mov    %rsi,0x120(%rsp)
  1a2391:	00 
  1a2392:	c4 41 7b 11 24 f3    	vmovsd %xmm12,(%r11,%rsi,8)
  1a2398:	40 b6 3f             	mov    $0x3f,%sil
  1a239b:	c4 e2 c8 f5 ff       	bzhi   %rsi,%rdi,%rdi
  1a23a0:	48 be 00 00 00 00 00 	movabs $0x7ff0000000000000,%rsi
  1a23a7:	00 f0 7f 
  1a23aa:	48 39 f7             	cmp    %rsi,%rdi
  1a23ad:	41 0f 94 c1          	sete   %r9b
  1a23b1:	48 85 ff             	test   %rdi,%rdi
  1a23b4:	41 0f 94 c2          	sete   %r10b
  1a23b8:	45 08 ca             	or     %r9b,%r10b
  1a23bb:	48 b8 00 00 00 00 00 	movabs $0xfff0000000000000,%rax
  1a23c2:	00 f0 ff 
  1a23c5:	48 01 c7             	add    %rax,%rdi
  1a23c8:	48 c1 ef 35          	shr    $0x35,%rdi
  1a23cc:	81 ff ff 03 00 00    	cmp    $0x3ff,%edi
  1a23d2:	41 0f 92 c1          	setb   %r9b
  1a23d6:	45 08 d1             	or     %r10b,%r9b
  1a23d9:	40 b7 3f             	mov    $0x3f,%dil
  1a23dc:	c4 c2 c0 f5 f8       	bzhi   %rdi,%r8,%rdi
  1a23e1:	48 39 f7             	cmp    %rsi,%rdi
  1a23e4:	41 0f 94 c0          	sete   %r8b
  1a23e8:	48 85 ff             	test   %rdi,%rdi
  1a23eb:	41 0f 94 c2          	sete   %r10b
  1a23ef:	45 08 c2             	or     %r8b,%r10b
  1a23f2:	48 01 c7             	add    %rax,%rdi
  1a23f5:	48 c1 ef 35          	shr    $0x35,%rdi
  1a23f9:	81 ff ff 03 00 00    	cmp    $0x3ff,%edi
  1a23ff:	40 0f 92 c7          	setb   %dil
  1a2403:	44 08 d7             	or     %r10b,%dil
  1a2406:	44 20 cf             	and    %r9b,%dil
  1a2409:	83 7c 24 10 01       	cmpl   $0x1,0x10(%rsp)
  1a240e:	0f 84 c7 03 00 00    	je     1a27db <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x19fb>
  1a2414:	4c 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%r8
  1a241b:	00 
  1a241c:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  1a2423:	00 
  1a2424:	c4 21 7b 10 64 c0 08 	vmovsd 0x8(%rax,%r8,8),%xmm12
  1a242b:	c4 41 79 28 ec       	vmovapd %xmm12,%xmm13
  1a2430:	c4 42 81 a9 eb       	vfmadd213sd %xmm11,%xmm15,%xmm13
  1a2435:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  1a243c:	00 
  1a243d:	c4 01 7b 10 74 c6 08 	vmovsd 0x8(%r14,%r8,8),%xmm14
  1a2444:	48 8b b4 24 20 01 00 	mov    0x120(%rsp),%rsi
  1a244b:	00 
  1a244c:	c4 42 89 a9 6c f3 08 	vfmadd213sd 0x8(%r11,%rsi,8),%xmm14,%xmm13
  1a2453:	c4 42 f1 a9 e2       	vfmadd213sd %xmm10,%xmm1,%xmm12
  1a2458:	c4 42 91 a9 e6       	vfmadd213sd %xmm14,%xmm13,%xmm12
  1a245d:	4c 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%r9
  1a2464:	00 
  1a2465:	4c 8b 54 24 20       	mov    0x20(%rsp),%r10
  1a246a:	c4 81 7b 10 44 ca 08 	vmovsd 0x8(%r10,%r9,8),%xmm0
  1a2471:	c4 c2 f9 b9 e5       	vfmadd231sd %xmm13,%xmm0,%xmm4
  1a2476:	c4 e2 89 b9 f8       	vfmadd231sd %xmm0,%xmm14,%xmm7
  1a247b:	4c 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%r9
  1a2482:	00 
  1a2483:	c4 81 7b 10 44 cf 08 	vmovsd 0x8(%r15,%r9,8),%xmm0
  1a248a:	c4 c2 f9 b9 d5       	vfmadd231sd %xmm13,%xmm0,%xmm2
  1a248f:	c4 e2 89 b9 f0       	vfmadd231sd %xmm0,%xmm14,%xmm6
  1a2494:	c4 a1 7b 10 44 c3 08 	vmovsd 0x8(%rbx,%r8,8),%xmm0
  1a249b:	c4 c2 f9 b9 ed       	vfmadd231sd %xmm13,%xmm0,%xmm5
  1a24a0:	c4 62 89 b9 c8       	vfmadd231sd %xmm0,%xmm14,%xmm9
  1a24a5:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
  1a24aa:	4c 8b 8c 24 f8 00 00 	mov    0xf8(%rsp),%r9
  1a24b1:	00 
  1a24b2:	c4 81 7b 10 44 c8 08 	vmovsd 0x8(%r8,%r9,8),%xmm0
  1a24b9:	c4 42 f9 b9 c6       	vfmadd231sd %xmm14,%xmm0,%xmm8
  1a24be:	c4 c2 f9 b9 dd       	vfmadd231sd %xmm13,%xmm0,%xmm3
  1a24c3:	c4 41 f9 7e e8       	vmovq  %xmm13,%r8
  1a24c8:	4c 8b 8c 24 88 00 00 	mov    0x88(%rsp),%r9
  1a24cf:	00 
  1a24d0:	c4 01 7b 11 6c cd 08 	vmovsd %xmm13,0x8(%r13,%r9,8)
  1a24d7:	c4 41 f9 7e e1       	vmovq  %xmm12,%r9
  1a24dc:	c4 41 7b 11 64 f3 08 	vmovsd %xmm12,0x8(%r11,%rsi,8)
  1a24e3:	40 b6 3f             	mov    $0x3f,%sil
  1a24e6:	c4 42 c8 f5 c0       	bzhi   %rsi,%r8,%r8
  1a24eb:	48 b8 00 00 00 00 00 	movabs $0x7ff0000000000000,%rax
  1a24f2:	00 f0 7f 
  1a24f5:	49 39 c0             	cmp    %rax,%r8
  1a24f8:	41 0f 94 c2          	sete   %r10b
  1a24fc:	4d 85 c0             	test   %r8,%r8
  1a24ff:	0f 94 c3             	sete   %bl
  1a2502:	44 08 d3             	or     %r10b,%bl
  1a2505:	49 bf 00 00 00 00 00 	movabs $0xfff0000000000000,%r15
  1a250c:	00 f0 ff 
  1a250f:	4d 01 f8             	add    %r15,%r8
  1a2512:	49 c1 e8 35          	shr    $0x35,%r8
  1a2516:	41 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8d
  1a251d:	41 0f 92 c0          	setb   %r8b
  1a2521:	41 08 d8             	or     %bl,%r8b
  1a2524:	c4 42 c8 f5 c9       	bzhi   %rsi,%r9,%r9
  1a2529:	49 39 c1             	cmp    %rax,%r9
  1a252c:	41 0f 94 c2          	sete   %r10b
  1a2530:	4d 85 c9             	test   %r9,%r9
  1a2533:	0f 94 c3             	sete   %bl
  1a2536:	44 08 d3             	or     %r10b,%bl
  1a2539:	4d 01 f9             	add    %r15,%r9
  1a253c:	49 c1 e9 35          	shr    $0x35,%r9
  1a2540:	41 81 f9 ff 03 00 00 	cmp    $0x3ff,%r9d
  1a2547:	41 0f 92 c1          	setb   %r9b
  1a254b:	41 08 d9             	or     %bl,%r9b
  1a254e:	45 20 c1             	and    %r8b,%r9b
  1a2551:	44 20 cf             	and    %r9b,%dil
  1a2554:	83 7c 24 10 02       	cmpl   $0x2,0x10(%rsp)
  1a2559:	0f 84 7c 02 00 00    	je     1a27db <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x19fb>
  1a255f:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  1a2566:	00 
  1a2567:	4c 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%r8
  1a256e:	00 
  1a256f:	c4 21 7b 10 64 c6 10 	vmovsd 0x10(%rsi,%r8,8),%xmm12
  1a2576:	c4 41 79 28 ec       	vmovapd %xmm12,%xmm13
  1a257b:	c4 42 81 a9 eb       	vfmadd213sd %xmm11,%xmm15,%xmm13
  1a2580:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  1a2587:	00 
  1a2588:	c4 01 7b 10 74 c6 10 	vmovsd 0x10(%r14,%r8,8),%xmm14
  1a258f:	48 8b b4 24 20 01 00 	mov    0x120(%rsp),%rsi
  1a2596:	00 
  1a2597:	c4 42 89 a9 6c f3 10 	vfmadd213sd 0x10(%r11,%rsi,8),%xmm14,%xmm13
  1a259e:	c4 42 f1 a9 e2       	vfmadd213sd %xmm10,%xmm1,%xmm12
  1a25a3:	c4 42 91 a9 e6       	vfmadd213sd %xmm14,%xmm13,%xmm12
  1a25a8:	4c 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%r9
  1a25af:	00 
  1a25b0:	4c 8b 54 24 20       	mov    0x20(%rsp),%r10
  1a25b5:	c4 81 7b 10 44 ca 10 	vmovsd 0x10(%r10,%r9,8),%xmm0
  1a25bc:	c4 c2 f9 b9 e5       	vfmadd231sd %xmm13,%xmm0,%xmm4
  1a25c1:	c4 e2 89 b9 f8       	vfmadd231sd %xmm0,%xmm14,%xmm7
  1a25c6:	4c 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%r9
  1a25cd:	00 
  1a25ce:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  1a25d3:	c4 a1 7b 10 44 c8 10 	vmovsd 0x10(%rax,%r9,8),%xmm0
  1a25da:	c4 c2 f9 b9 d5       	vfmadd231sd %xmm13,%xmm0,%xmm2
  1a25df:	c4 e2 89 b9 f0       	vfmadd231sd %xmm0,%xmm14,%xmm6
  1a25e4:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  1a25e9:	c4 a1 7b 10 44 c0 10 	vmovsd 0x10(%rax,%r8,8),%xmm0
  1a25f0:	c4 c2 f9 b9 ed       	vfmadd231sd %xmm13,%xmm0,%xmm5
  1a25f5:	c4 62 89 b9 c8       	vfmadd231sd %xmm0,%xmm14,%xmm9
  1a25fa:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
  1a25ff:	4c 8b 8c 24 f8 00 00 	mov    0xf8(%rsp),%r9
  1a2606:	00 
  1a2607:	c4 81 7b 10 44 c8 10 	vmovsd 0x10(%r8,%r9,8),%xmm0
  1a260e:	c4 42 f9 b9 c6       	vfmadd231sd %xmm14,%xmm0,%xmm8
  1a2613:	c4 c2 f9 b9 dd       	vfmadd231sd %xmm13,%xmm0,%xmm3
  1a2618:	c4 41 f9 7e e8       	vmovq  %xmm13,%r8
  1a261d:	4c 8b 8c 24 88 00 00 	mov    0x88(%rsp),%r9
  1a2624:	00 
  1a2625:	c4 01 7b 11 6c cd 10 	vmovsd %xmm13,0x10(%r13,%r9,8)
  1a262c:	c4 41 f9 7e e1       	vmovq  %xmm12,%r9
  1a2631:	c4 41 7b 11 64 f3 10 	vmovsd %xmm12,0x10(%r11,%rsi,8)
  1a2638:	40 b6 3f             	mov    $0x3f,%sil
  1a263b:	c4 42 c8 f5 c0       	bzhi   %rsi,%r8,%r8
  1a2640:	48 b8 00 00 00 00 00 	movabs $0x7ff0000000000000,%rax
  1a2647:	00 f0 7f 
  1a264a:	49 39 c0             	cmp    %rax,%r8
  1a264d:	41 0f 94 c2          	sete   %r10b
  1a2651:	4d 85 c0             	test   %r8,%r8
  1a2654:	0f 94 c3             	sete   %bl
  1a2657:	44 08 d3             	or     %r10b,%bl
  1a265a:	4d 01 f8             	add    %r15,%r8
  1a265d:	49 c1 e8 35          	shr    $0x35,%r8
  1a2661:	41 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8d
  1a2668:	41 0f 92 c0          	setb   %r8b
  1a266c:	41 08 d8             	or     %bl,%r8b
  1a266f:	c4 42 c8 f5 c9       	bzhi   %rsi,%r9,%r9
  1a2674:	49 39 c1             	cmp    %rax,%r9
  1a2677:	41 0f 94 c2          	sete   %r10b
  1a267b:	4d 85 c9             	test   %r9,%r9
  1a267e:	0f 94 c3             	sete   %bl
  1a2681:	44 08 d3             	or     %r10b,%bl
  1a2684:	4d 01 f9             	add    %r15,%r9
  1a2687:	49 c1 e9 35          	shr    $0x35,%r9
  1a268b:	41 81 f9 ff 03 00 00 	cmp    $0x3ff,%r9d
  1a2692:	41 0f 92 c1          	setb   %r9b
  1a2696:	41 08 d9             	or     %bl,%r9b
  1a2699:	45 20 c1             	and    %r8b,%r9b
  1a269c:	44 20 cf             	and    %r9b,%dil
  1a269f:	83 7c 24 10 03       	cmpl   $0x3,0x10(%rsp)
  1a26a4:	0f 84 31 01 00 00    	je     1a27db <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x19fb>
  1a26aa:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  1a26b1:	00 
  1a26b2:	4c 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%r8
  1a26b9:	00 
  1a26ba:	c4 a1 7b 10 44 c6 18 	vmovsd 0x18(%rsi,%r8,8),%xmm0
  1a26c1:	c4 42 f9 a9 fb       	vfmadd213sd %xmm11,%xmm0,%xmm15
  1a26c6:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  1a26cd:	00 
  1a26ce:	c4 41 7b 10 5c f6 18 	vmovsd 0x18(%r14,%rsi,8),%xmm11
  1a26d5:	4c 8b b4 24 20 01 00 	mov    0x120(%rsp),%r14
  1a26dc:	00 
  1a26dd:	c4 02 a1 a9 7c f3 18 	vfmadd213sd 0x18(%r11,%r14,8),%xmm11,%xmm15
  1a26e4:	c4 41 f9 7e f8       	vmovq  %xmm15,%r8
  1a26e9:	b3 3f                	mov    $0x3f,%bl
  1a26eb:	c4 42 e0 f5 c0       	bzhi   %rbx,%r8,%r8
  1a26f0:	49 39 c0             	cmp    %rax,%r8
  1a26f3:	41 0f 94 c1          	sete   %r9b
  1a26f7:	4d 85 c0             	test   %r8,%r8
  1a26fa:	41 0f 94 c2          	sete   %r10b
  1a26fe:	45 08 ca             	or     %r9b,%r10b
  1a2701:	4d 01 f8             	add    %r15,%r8
  1a2704:	49 c1 e8 35          	shr    $0x35,%r8
  1a2708:	41 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8d
  1a270f:	41 0f 92 c1          	setb   %r9b
  1a2713:	45 08 d1             	or     %r10b,%r9b
  1a2716:	c4 c2 f9 a9 ca       	vfmadd213sd %xmm10,%xmm0,%xmm1
  1a271b:	c4 c2 81 a9 cb       	vfmadd213sd %xmm11,%xmm15,%xmm1
  1a2720:	c4 c1 f9 7e c8       	vmovq  %xmm1,%r8
  1a2725:	c4 42 e0 f5 c0       	bzhi   %rbx,%r8,%r8
  1a272a:	49 39 c0             	cmp    %rax,%r8
  1a272d:	41 0f 94 c2          	sete   %r10b
  1a2731:	4d 85 c0             	test   %r8,%r8
  1a2734:	0f 94 c3             	sete   %bl
  1a2737:	44 08 d3             	or     %r10b,%bl
  1a273a:	4d 01 f8             	add    %r15,%r8
  1a273d:	49 c1 e8 35          	shr    $0x35,%r8
  1a2741:	41 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8d
  1a2748:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  1a274f:	00 
  1a2750:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
  1a2755:	c4 c1 7b 10 44 c0 18 	vmovsd 0x18(%r8,%rax,8),%xmm0
  1a275c:	c5 79 28 e9          	vmovapd %xmm1,%xmm13
  1a2760:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  1a2767:	00 
  1a2768:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
  1a276d:	c4 c1 7b 10 4c c7 18 	vmovsd 0x18(%r15,%rax,8),%xmm1
  1a2774:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  1a2779:	c5 7b 10 54 f0 18    	vmovsd 0x18(%rax,%rsi,8),%xmm10
  1a277f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  1a2784:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  1a278b:	00 
  1a278c:	c5 7b 10 64 f0 18    	vmovsd 0x18(%rax,%rsi,8),%xmm12
  1a2792:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  1a2799:	00 
  1a279a:	c4 41 7b 11 7c c5 18 	vmovsd %xmm15,0x18(%r13,%rax,8)
  1a27a1:	c4 01 7b 11 6c f3 18 	vmovsd %xmm13,0x18(%r11,%r14,8)
  1a27a8:	0f 92 c0             	setb   %al
  1a27ab:	08 d8                	or     %bl,%al
  1a27ad:	44 20 c8             	and    %r9b,%al
  1a27b0:	40 20 c7             	and    %al,%dil
  1a27b3:	c4 c2 f9 b9 e7       	vfmadd231sd %xmm15,%xmm0,%xmm4
  1a27b8:	c4 c2 f1 b9 d7       	vfmadd231sd %xmm15,%xmm1,%xmm2
  1a27bd:	c4 c2 a9 b9 ef       	vfmadd231sd %xmm15,%xmm10,%xmm5
  1a27c2:	c4 c2 99 b9 df       	vfmadd231sd %xmm15,%xmm12,%xmm3
  1a27c7:	c4 e2 a1 b9 f8       	vfmadd231sd %xmm0,%xmm11,%xmm7
  1a27cc:	c4 e2 a1 b9 f1       	vfmadd231sd %xmm1,%xmm11,%xmm6
  1a27d1:	c4 42 a1 b9 ca       	vfmadd231sd %xmm10,%xmm11,%xmm9
  1a27d6:	c4 42 99 b9 c3       	vfmadd231sd %xmm11,%xmm12,%xmm8
  1a27db:	4c 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%r14
  1a27e2:	00 
  1a27e3:	40 20 7c 24 07       	and    %dil,0x7(%rsp)
  1a27e8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  1a27ed:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
  1a27f2:	4c 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%r10
  1a27f9:	00 
  1a27fa:	eb 15                	jmp    1a2811 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1a31>
  1a27fc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  1a2801:	4c 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%r10
  1a2808:	00 
  1a2809:	4c 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%r14
  1a2810:	00 
  1a2811:	4f 8d 0c 00          	lea    (%r8,%r8,1),%r9
  1a2815:	49 39 c1             	cmp    %rax,%r9
  1a2818:	0f 83 d5 0f 00 00    	jae    1a37f3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a13>
  1a281e:	4c 89 cb             	mov    %r9,%rbx
  1a2821:	48 c1 e3 04          	shl    $0x4,%rbx
  1a2825:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
  1a282c:	00 
  1a282d:	c5 7b 11 04 1f       	vmovsd %xmm8,(%rdi,%rbx,1)
  1a2832:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  1a2839:	00 
  1a283a:	4a 8d 34 40          	lea    (%rax,%r8,2),%rsi
  1a283e:	c5 7b 11 4c 1f 08    	vmovsd %xmm9,0x8(%rdi,%rbx,1)
  1a2844:	48 3b 74 24 68       	cmp    0x68(%rsp),%rsi
  1a2849:	73 26                	jae    1a2871 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1a91>
  1a284b:	49 8d 41 01          	lea    0x1(%r9),%rax
  1a284f:	48 3b 44 24 08       	cmp    0x8(%rsp),%rax
  1a2854:	0f 83 e1 0f 00 00    	jae    1a383b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a5b>
  1a285a:	48 c1 e0 04          	shl    $0x4,%rax
  1a285e:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
  1a2865:	00 
  1a2866:	c5 fb 11 34 07       	vmovsd %xmm6,(%rdi,%rax,1)
  1a286b:	c5 fb 11 7c 07 08    	vmovsd %xmm7,0x8(%rdi,%rax,1)
  1a2871:	48 89 9c 24 60 01 00 	mov    %rbx,0x160(%rsp)
  1a2878:	00 
  1a2879:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
  1a287e:	48 8d 7e 02          	lea    0x2(%rsi),%rdi
  1a2882:	49 89 ff             	mov    %rdi,%r15
  1a2885:	4c 2b bc 24 30 01 00 	sub    0x130(%rsp),%r15
  1a288c:	00 
  1a288d:	4c 3b 7c 24 08       	cmp    0x8(%rsp),%r15
  1a2892:	0f 83 8b 0f 00 00    	jae    1a3823 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a43>
  1a2898:	4c 89 fb             	mov    %r15,%rbx
  1a289b:	48 c1 e3 04          	shl    $0x4,%rbx
  1a289f:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1a28a6:	00 
  1a28a7:	c5 fb 11 1c 18       	vmovsd %xmm3,(%rax,%rbx,1)
  1a28ac:	48 89 9c 24 50 01 00 	mov    %rbx,0x150(%rsp)
  1a28b3:	00 
  1a28b4:	c5 fb 11 6c 18 08    	vmovsd %xmm5,0x8(%rax,%rbx,1)
  1a28ba:	48 3b 7c 24 68       	cmp    0x68(%rsp),%rdi
  1a28bf:	4c 89 f6             	mov    %r14,%rsi
  1a28c2:	4c 8b b4 24 90 00 00 	mov    0x90(%rsp),%r14
  1a28c9:	00 
  1a28ca:	73 45                	jae    1a2911 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1b31>
  1a28cc:	49 8d 47 01          	lea    0x1(%r15),%rax
  1a28d0:	48 3b 44 24 08       	cmp    0x8(%rsp),%rax
  1a28d5:	0f 83 60 0f 00 00    	jae    1a383b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a5b>
  1a28db:	4c 89 cb             	mov    %r9,%rbx
  1a28de:	4d 89 c1             	mov    %r8,%r9
  1a28e1:	48 c1 e0 04          	shl    $0x4,%rax
  1a28e5:	4c 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%r8
  1a28ec:	00 
  1a28ed:	c4 c1 7b 11 14 00    	vmovsd %xmm2,(%r8,%rax,1)
  1a28f3:	c4 c1 7b 11 64 00 08 	vmovsd %xmm4,0x8(%r8,%rax,1)
  1a28fa:	4d 89 c8             	mov    %r9,%r8
  1a28fd:	4c 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%r10
  1a2904:	00 
  1a2905:	49 89 d9             	mov    %rbx,%r9
  1a2908:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  1a290d:	48 8d 78 02          	lea    0x2(%rax),%rdi
  1a2911:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  1a2915:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  1a291c:	00 
  1a291d:	48 85 c0             	test   %rax,%rax
  1a2920:	74 29                	je     1a294b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1b6b>
  1a2922:	48 83 f8 01          	cmp    $0x1,%rax
  1a2926:	75 44                	jne    1a296c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1b8c>
  1a2928:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1a292c:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1a2930:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1a2934:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1a2938:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1a293c:	31 c0                	xor    %eax,%eax
  1a293e:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1a2942:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1a2946:	e9 18 01 00 00       	jmp    1a2a63 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1c83>
  1a294b:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1a294f:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1a2953:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1a2957:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1a295b:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1a295f:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1a2963:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1a2967:	e9 46 01 00 00       	jmp    1a2ab2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1cd2>
  1a296c:	4c 89 8c 24 40 01 00 	mov    %r9,0x140(%rsp)
  1a2973:	00 
  1a2974:	41 b9 20 00 00 00    	mov    $0x20,%r9d
  1a297a:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1a297e:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1a2982:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1a2986:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1a298a:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1a298e:	31 c0                	xor    %eax,%eax
  1a2990:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1a2994:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1a2998:	c4 21 7d 10 44 09 e0 	vmovupd -0x20(%rcx,%r9,1),%ymm8
  1a299f:	c4 01 7d 10 4c 0e e0 	vmovupd -0x20(%r14,%r9,1),%ymm9
  1a29a6:	c4 c2 bd b8 f9       	vfmadd231pd %ymm9,%ymm8,%ymm7
  1a29ab:	c4 21 7d 10 54 0a e0 	vmovupd -0x20(%rdx,%r9,1),%ymm10
  1a29b2:	c4 c2 ad b8 f1       	vfmadd231pd %ymm9,%ymm10,%ymm6
  1a29b7:	c4 21 7d 10 5c 0d e0 	vmovupd -0x20(%rbp,%r9,1),%ymm11
  1a29be:	c4 c2 a5 b8 e1       	vfmadd231pd %ymm9,%ymm11,%ymm4
  1a29c3:	c4 01 7d 10 64 0c e0 	vmovupd -0x20(%r12,%r9,1),%ymm12
  1a29ca:	c4 c2 9d b8 d9       	vfmadd231pd %ymm9,%ymm12,%ymm3
  1a29cf:	c4 01 7d 10 4c 0d e0 	vmovupd -0x20(%r13,%r9,1),%ymm9
  1a29d6:	c4 c2 b5 b8 e8       	vfmadd231pd %ymm8,%ymm9,%ymm5
  1a29db:	c4 21 7d 10 04 09    	vmovupd (%rcx,%r9,1),%ymm8
  1a29e1:	c4 c2 b5 b8 d2       	vfmadd231pd %ymm10,%ymm9,%ymm2
  1a29e6:	c4 01 7d 10 14 0e    	vmovupd (%r14,%r9,1),%ymm10
  1a29ec:	c4 c2 b5 b8 cb       	vfmadd231pd %ymm11,%ymm9,%ymm1
  1a29f1:	c4 21 7d 10 1c 0a    	vmovupd (%rdx,%r9,1),%ymm11
  1a29f7:	c4 c2 9d b8 c1       	vfmadd231pd %ymm9,%ymm12,%ymm0
  1a29fc:	c4 21 7d 10 4c 0d 00 	vmovupd 0x0(%rbp,%r9,1),%ymm9
  1a2a03:	c4 01 7d 10 24 0c    	vmovupd (%r12,%r9,1),%ymm12
  1a2a09:	c4 c2 bd b8 fa       	vfmadd231pd %ymm10,%ymm8,%ymm7
  1a2a0e:	c4 c2 a5 b8 f2       	vfmadd231pd %ymm10,%ymm11,%ymm6
  1a2a13:	c4 c2 b5 b8 e2       	vfmadd231pd %ymm10,%ymm9,%ymm4
  1a2a18:	c4 c2 9d b8 da       	vfmadd231pd %ymm10,%ymm12,%ymm3
  1a2a1d:	c4 01 7d 10 54 0d 00 	vmovupd 0x0(%r13,%r9,1),%ymm10
  1a2a24:	c4 c2 ad b8 e8       	vfmadd231pd %ymm8,%ymm10,%ymm5
  1a2a29:	c4 c2 ad b8 d3       	vfmadd231pd %ymm11,%ymm10,%ymm2
  1a2a2e:	c4 c2 ad b8 c9       	vfmadd231pd %ymm9,%ymm10,%ymm1
  1a2a33:	c4 c2 9d b8 c2       	vfmadd231pd %ymm10,%ymm12,%ymm0
  1a2a38:	48 83 c0 02          	add    $0x2,%rax
  1a2a3c:	49 83 c1 40          	add    $0x40,%r9
  1a2a40:	48 39 c6             	cmp    %rax,%rsi
  1a2a43:	0f 85 4f ff ff ff    	jne    1a2998 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1bb8>
  1a2a49:	f6 84 24 b0 00 00 00 	testb  $0x1,0xb0(%rsp)
  1a2a50:	01 
  1a2a51:	4c 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%r10
  1a2a58:	00 
  1a2a59:	4c 8b 8c 24 40 01 00 	mov    0x140(%rsp),%r9
  1a2a60:	00 
  1a2a61:	74 4f                	je     1a2ab2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1cd2>
  1a2a63:	48 c1 e0 05          	shl    $0x5,%rax
  1a2a67:	c5 7d 10 04 01       	vmovupd (%rcx,%rax,1),%ymm8
  1a2a6c:	c4 41 7d 10 0c 06    	vmovupd (%r14,%rax,1),%ymm9
  1a2a72:	c4 c2 bd b8 f9       	vfmadd231pd %ymm9,%ymm8,%ymm7
  1a2a77:	c5 7d 10 14 02       	vmovupd (%rdx,%rax,1),%ymm10
  1a2a7c:	c4 c2 ad b8 f1       	vfmadd231pd %ymm9,%ymm10,%ymm6
  1a2a81:	c5 7d 10 5c 05 00    	vmovupd 0x0(%rbp,%rax,1),%ymm11
  1a2a87:	c4 c2 a5 b8 e1       	vfmadd231pd %ymm9,%ymm11,%ymm4
  1a2a8c:	c4 41 7d 10 24 04    	vmovupd (%r12,%rax,1),%ymm12
  1a2a92:	c4 c2 9d b8 d9       	vfmadd231pd %ymm9,%ymm12,%ymm3
  1a2a97:	c4 41 7d 10 4c 05 00 	vmovupd 0x0(%r13,%rax,1),%ymm9
  1a2a9e:	c4 c2 b5 b8 e8       	vfmadd231pd %ymm8,%ymm9,%ymm5
  1a2aa3:	c4 c2 b5 b8 d2       	vfmadd231pd %ymm10,%ymm9,%ymm2
  1a2aa8:	c4 c2 b5 b8 cb       	vfmadd231pd %ymm11,%ymm9,%ymm1
  1a2aad:	c4 c2 9d b8 c1       	vfmadd231pd %ymm9,%ymm12,%ymm0
  1a2ab2:	c4 c3 7d 19 f8 01    	vextractf128 $0x1,%ymm7,%xmm8
  1a2ab8:	c5 b9 58 ff          	vaddpd %xmm7,%xmm8,%xmm7
  1a2abc:	c5 41 c6 c7 01       	vshufpd $0x1,%xmm7,%xmm7,%xmm8
  1a2ac1:	c5 bb 58 ff          	vaddsd %xmm7,%xmm8,%xmm7
  1a2ac5:	c4 c3 7d 19 f0 01    	vextractf128 $0x1,%ymm6,%xmm8
  1a2acb:	c5 b9 58 f6          	vaddpd %xmm6,%xmm8,%xmm6
  1a2acf:	c5 49 c6 c6 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm8
  1a2ad4:	c5 3b 58 c6          	vaddsd %xmm6,%xmm8,%xmm8
  1a2ad8:	c4 e3 7d 19 e6 01    	vextractf128 $0x1,%ymm4,%xmm6
  1a2ade:	c5 d9 58 e6          	vaddpd %xmm6,%xmm4,%xmm4
  1a2ae2:	c5 d9 c6 f4 01       	vshufpd $0x1,%xmm4,%xmm4,%xmm6
  1a2ae7:	c5 db 58 e6          	vaddsd %xmm6,%xmm4,%xmm4
  1a2aeb:	c4 e3 7d 19 de 01    	vextractf128 $0x1,%ymm3,%xmm6
  1a2af1:	c5 e1 58 de          	vaddpd %xmm6,%xmm3,%xmm3
  1a2af5:	c5 e1 c6 f3 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm6
  1a2afa:	c5 e3 58 f6          	vaddsd %xmm6,%xmm3,%xmm6
  1a2afe:	c4 e3 7d 19 eb 01    	vextractf128 $0x1,%ymm5,%xmm3
  1a2b04:	c5 d1 58 db          	vaddpd %xmm3,%xmm5,%xmm3
  1a2b08:	c5 e1 c6 eb 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm5
  1a2b0d:	c5 e3 58 dd          	vaddsd %xmm5,%xmm3,%xmm3
  1a2b11:	c4 e3 7d 19 d5 01    	vextractf128 $0x1,%ymm2,%xmm5
  1a2b17:	c5 e9 58 d5          	vaddpd %xmm5,%xmm2,%xmm2
  1a2b1b:	c5 e9 c6 ea 01       	vshufpd $0x1,%xmm2,%xmm2,%xmm5
  1a2b20:	c5 eb 58 d5          	vaddsd %xmm5,%xmm2,%xmm2
  1a2b24:	c4 e3 7d 19 cd 01    	vextractf128 $0x1,%ymm1,%xmm5
  1a2b2a:	c5 f1 58 cd          	vaddpd %xmm5,%xmm1,%xmm1
  1a2b2e:	c5 f1 c6 e9 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm5
  1a2b33:	c5 f3 58 cd          	vaddsd %xmm5,%xmm1,%xmm1
  1a2b37:	c4 e3 7d 19 c5 01    	vextractf128 $0x1,%ymm0,%xmm5
  1a2b3d:	c5 f9 58 c5          	vaddpd %xmm5,%xmm0,%xmm0
  1a2b41:	c5 f9 c6 e8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm5
  1a2b46:	c5 fb 58 c5          	vaddsd %xmm5,%xmm0,%xmm0
  1a2b4a:	4d 85 d2             	test   %r10,%r10
  1a2b4d:	0f 84 35 01 00 00    	je     1a2c88 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1ea8>
  1a2b53:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
  1a2b5a:	00 
  1a2b5b:	48 39 44 24 10       	cmp    %rax,0x10(%rsp)
  1a2b60:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  1a2b67:	00 
  1a2b68:	0f 86 21 0d 00 00    	jbe    1a388f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2aaf>
  1a2b6e:	4c 89 cb             	mov    %r9,%rbx
  1a2b71:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
  1a2b78:	00 
  1a2b79:	c5 fb 10 2c f1       	vmovsd (%rcx,%rsi,8),%xmm5
  1a2b7e:	c4 41 7b 10 0c c6    	vmovsd (%r14,%rax,8),%xmm9
  1a2b84:	c4 c2 d1 b9 f9       	vfmadd231sd %xmm9,%xmm5,%xmm7
  1a2b89:	c5 7b 10 14 f2       	vmovsd (%rdx,%rsi,8),%xmm10
  1a2b8e:	c4 42 a9 b9 c1       	vfmadd231sd %xmm9,%xmm10,%xmm8
  1a2b93:	c5 7b 10 5c f5 00    	vmovsd 0x0(%rbp,%rsi,8),%xmm11
  1a2b99:	c4 c2 a1 b9 e1       	vfmadd231sd %xmm9,%xmm11,%xmm4
  1a2b9e:	c4 41 7b 10 24 f4    	vmovsd (%r12,%rsi,8),%xmm12
  1a2ba4:	c4 c2 99 b9 f1       	vfmadd231sd %xmm9,%xmm12,%xmm6
  1a2ba9:	4c 8b 8c 24 88 00 00 	mov    0x88(%rsp),%r9
  1a2bb0:	00 
  1a2bb1:	c4 01 7b 10 4c cd 00 	vmovsd 0x0(%r13,%r9,8),%xmm9
  1a2bb8:	c4 e2 b1 b9 dd       	vfmadd231sd %xmm5,%xmm9,%xmm3
  1a2bbd:	c4 c2 b1 b9 d2       	vfmadd231sd %xmm10,%xmm9,%xmm2
  1a2bc2:	c4 c2 b1 b9 cb       	vfmadd231sd %xmm11,%xmm9,%xmm1
  1a2bc7:	c4 c2 99 b9 c1       	vfmadd231sd %xmm9,%xmm12,%xmm0
  1a2bcc:	41 83 fa 01          	cmp    $0x1,%r10d
  1a2bd0:	0f 84 a4 00 00 00    	je     1a2c7a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1e9a>
  1a2bd6:	c5 fb 10 6c f1 08    	vmovsd 0x8(%rcx,%rsi,8),%xmm5
  1a2bdc:	c4 41 7b 10 4c c6 08 	vmovsd 0x8(%r14,%rax,8),%xmm9
  1a2be3:	c4 c2 d1 b9 f9       	vfmadd231sd %xmm9,%xmm5,%xmm7
  1a2be8:	c5 7b 10 54 f2 08    	vmovsd 0x8(%rdx,%rsi,8),%xmm10
  1a2bee:	c4 42 a9 b9 c1       	vfmadd231sd %xmm9,%xmm10,%xmm8
  1a2bf3:	c5 7b 10 5c f5 08    	vmovsd 0x8(%rbp,%rsi,8),%xmm11
  1a2bf9:	c4 c2 a1 b9 e1       	vfmadd231sd %xmm9,%xmm11,%xmm4
  1a2bfe:	c4 41 7b 10 64 f4 08 	vmovsd 0x8(%r12,%rsi,8),%xmm12
  1a2c05:	c4 c2 99 b9 f1       	vfmadd231sd %xmm9,%xmm12,%xmm6
  1a2c0a:	c4 01 7b 10 4c cd 08 	vmovsd 0x8(%r13,%r9,8),%xmm9
  1a2c11:	c4 e2 b1 b9 dd       	vfmadd231sd %xmm5,%xmm9,%xmm3
  1a2c16:	c4 c2 b1 b9 d2       	vfmadd231sd %xmm10,%xmm9,%xmm2
  1a2c1b:	c4 c2 b1 b9 cb       	vfmadd231sd %xmm11,%xmm9,%xmm1
  1a2c20:	c4 c2 99 b9 c1       	vfmadd231sd %xmm9,%xmm12,%xmm0
  1a2c25:	41 83 fa 02          	cmp    $0x2,%r10d
  1a2c29:	74 4f                	je     1a2c7a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1e9a>
  1a2c2b:	c5 fb 10 6c f1 10    	vmovsd 0x10(%rcx,%rsi,8),%xmm5
  1a2c31:	c4 41 7b 10 4c c6 10 	vmovsd 0x10(%r14,%rax,8),%xmm9
  1a2c38:	c4 c2 d1 b9 f9       	vfmadd231sd %xmm9,%xmm5,%xmm7
  1a2c3d:	c5 7b 10 54 f2 10    	vmovsd 0x10(%rdx,%rsi,8),%xmm10
  1a2c43:	c4 42 a9 b9 c1       	vfmadd231sd %xmm9,%xmm10,%xmm8
  1a2c48:	c5 7b 10 5c f5 10    	vmovsd 0x10(%rbp,%rsi,8),%xmm11
  1a2c4e:	c4 c2 a1 b9 e1       	vfmadd231sd %xmm9,%xmm11,%xmm4
  1a2c53:	c4 41 7b 10 64 f4 10 	vmovsd 0x10(%r12,%rsi,8),%xmm12
  1a2c5a:	c4 c2 99 b9 f1       	vfmadd231sd %xmm9,%xmm12,%xmm6
  1a2c5f:	c4 01 7b 10 4c cd 10 	vmovsd 0x10(%r13,%r9,8),%xmm9
  1a2c66:	c4 e2 b1 b9 dd       	vfmadd231sd %xmm5,%xmm9,%xmm3
  1a2c6b:	c4 c2 b1 b9 d2       	vfmadd231sd %xmm10,%xmm9,%xmm2
  1a2c70:	c4 c2 b1 b9 cb       	vfmadd231sd %xmm11,%xmm9,%xmm1
  1a2c75:	c4 c2 99 b9 c1       	vfmadd231sd %xmm9,%xmm12,%xmm0
  1a2c7a:	49 89 d9             	mov    %rbx,%r9
  1a2c7d:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  1a2c82:	48 8d 78 02          	lea    0x2(%rax),%rdi
  1a2c86:	eb 05                	jmp    1a2c8d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1ead>
  1a2c88:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  1a2c8d:	4c 3b 4c 24 18       	cmp    0x18(%rsp),%r9
  1a2c92:	0f 83 43 0b 00 00    	jae    1a37db <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29fb>
  1a2c98:	48 89 c3             	mov    %rax,%rbx
  1a2c9b:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  1a2ca2:	00 
  1a2ca3:	4c 8b 94 24 60 01 00 	mov    0x160(%rsp),%r10
  1a2caa:	00 
  1a2cab:	c4 a1 7b 11 3c 10    	vmovsd %xmm7,(%rax,%r10,1)
  1a2cb1:	c4 21 7b 11 44 10 08 	vmovsd %xmm8,0x8(%rax,%r10,1)
  1a2cb8:	48 3b 5c 24 68       	cmp    0x68(%rsp),%rbx
  1a2cbd:	73 27                	jae    1a2ce6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1f06>
  1a2cbf:	49 ff c1             	inc    %r9
  1a2cc2:	4c 3b 4c 24 18       	cmp    0x18(%rsp),%r9
  1a2cc7:	0f 83 da 0b 00 00    	jae    1a38a7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2ac7>
  1a2ccd:	49 c1 e1 04          	shl    $0x4,%r9
  1a2cd1:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  1a2cd8:	00 
  1a2cd9:	c4 a1 7b 11 24 08    	vmovsd %xmm4,(%rax,%r9,1)
  1a2cdf:	c4 a1 7b 11 74 08 08 	vmovsd %xmm6,0x8(%rax,%r9,1)
  1a2ce6:	4c 3b 7c 24 18       	cmp    0x18(%rsp),%r15
  1a2ceb:	0f 83 1a 0b 00 00    	jae    1a380b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a2b>
  1a2cf1:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  1a2cf8:	00 
  1a2cf9:	4c 8b 8c 24 50 01 00 	mov    0x150(%rsp),%r9
  1a2d00:	00 
  1a2d01:	c4 a1 7b 11 1c 08    	vmovsd %xmm3,(%rax,%r9,1)
  1a2d07:	c4 a1 7b 11 54 08 08 	vmovsd %xmm2,0x8(%rax,%r9,1)
  1a2d0e:	48 3b 7c 24 68       	cmp    0x68(%rsp),%rdi
  1a2d13:	0f 83 71 f2 ff ff    	jae    1a1f8a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x11aa>
  1a2d19:	49 ff c7             	inc    %r15
  1a2d1c:	4c 3b 7c 24 18       	cmp    0x18(%rsp),%r15
  1a2d21:	0f 83 98 0b 00 00    	jae    1a38bf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2adf>
  1a2d27:	49 c1 e7 04          	shl    $0x4,%r15
  1a2d2b:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  1a2d32:	00 
  1a2d33:	c4 a1 7b 11 0c 38    	vmovsd %xmm1,(%rax,%r15,1)
  1a2d39:	c4 a1 7b 11 44 38 08 	vmovsd %xmm0,0x8(%rax,%r15,1)
  1a2d40:	e9 45 f2 ff ff       	jmp    1a1f8a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x11aa>
  1a2d45:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1a2d4a:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1a2d4e:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1a2d52:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1a2d56:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1a2d5a:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1a2d5e:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1a2d62:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1a2d66:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  1a2d6b:	e9 3e 01 00 00       	jmp    1a2eae <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x20ce>
  1a2d70:	4c 89 d0             	mov    %r10,%rax
  1a2d73:	49 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%r8
  1a2d7a:	ff ff 1f 
  1a2d7d:	4c 21 c0             	and    %r8,%rax
  1a2d80:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1a2d84:	bb 60 00 00 00       	mov    $0x60,%ebx
  1a2d89:	45 31 c9             	xor    %r9d,%r9d
  1a2d8c:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1a2d90:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1a2d94:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1a2d98:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1a2d9c:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1a2da0:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1a2da4:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1a2da9:	4d 89 f8             	mov    %r15,%r8
  1a2dac:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1a2db1:	4c 8b 74 24 20       	mov    0x20(%rsp),%r14
  1a2db6:	c4 41 7d 10 4c 1b a0 	vmovupd -0x60(%r11,%rbx,1),%ymm9
  1a2dbd:	c4 41 7d 10 54 1b c0 	vmovupd -0x40(%r11,%rbx,1),%ymm10
  1a2dc4:	c4 41 7d 10 5c 1b e0 	vmovupd -0x20(%r11,%rbx,1),%ymm11
  1a2dcb:	c4 e2 b5 b8 64 1e a0 	vfmadd231pd -0x60(%rsi,%rbx,1),%ymm9,%ymm4
  1a2dd2:	c4 c2 b5 b8 6c 1f a0 	vfmadd231pd -0x60(%r15,%rbx,1),%ymm9,%ymm5
  1a2dd9:	c4 c2 b5 b8 74 18 a0 	vfmadd231pd -0x60(%r8,%rbx,1),%ymm9,%ymm6
  1a2de0:	c4 c2 b5 b8 7c 1e a0 	vfmadd231pd -0x60(%r14,%rbx,1),%ymm9,%ymm7
  1a2de7:	c4 e2 ad b8 54 1e c0 	vfmadd231pd -0x40(%rsi,%rbx,1),%ymm10,%ymm2
  1a2dee:	c4 c2 ad b8 5c 1f c0 	vfmadd231pd -0x40(%r15,%rbx,1),%ymm10,%ymm3
  1a2df5:	c4 c2 ad b8 4c 18 c0 	vfmadd231pd -0x40(%r8,%rbx,1),%ymm10,%ymm1
  1a2dfc:	c4 42 ad b8 44 1e c0 	vfmadd231pd -0x40(%r14,%rbx,1),%ymm10,%ymm8
  1a2e03:	c4 41 7d 10 0c 1b    	vmovupd (%r11,%rbx,1),%ymm9
  1a2e09:	49 83 c1 02          	add    $0x2,%r9
  1a2e0d:	c4 e2 a5 b8 64 1e e0 	vfmadd231pd -0x20(%rsi,%rbx,1),%ymm11,%ymm4
  1a2e14:	c4 c2 a5 b8 6c 1f e0 	vfmadd231pd -0x20(%r15,%rbx,1),%ymm11,%ymm5
  1a2e1b:	c4 c2 a5 b8 74 18 e0 	vfmadd231pd -0x20(%r8,%rbx,1),%ymm11,%ymm6
  1a2e22:	c4 c2 a5 b8 7c 1e e0 	vfmadd231pd -0x20(%r14,%rbx,1),%ymm11,%ymm7
  1a2e29:	c4 e2 b5 b8 14 1e    	vfmadd231pd (%rsi,%rbx,1),%ymm9,%ymm2
  1a2e2f:	c4 c2 b5 b8 1c 1f    	vfmadd231pd (%r15,%rbx,1),%ymm9,%ymm3
  1a2e35:	c4 c2 b5 b8 0c 18    	vfmadd231pd (%r8,%rbx,1),%ymm9,%ymm1
  1a2e3b:	c4 42 b5 b8 04 1e    	vfmadd231pd (%r14,%rbx,1),%ymm9,%ymm8
  1a2e41:	48 83 eb 80          	sub    $0xffffffffffffff80,%rbx
  1a2e45:	4c 39 c8             	cmp    %r9,%rax
  1a2e48:	0f 85 68 ff ff ff    	jne    1a2db6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1fd6>
  1a2e4e:	41 f6 c2 01          	test   $0x1,%r10b
  1a2e52:	48 8b 9c 24 08 01 00 	mov    0x108(%rsp),%rbx
  1a2e59:	00 
  1a2e5a:	4d 89 c7             	mov    %r8,%r15
  1a2e5d:	74 4f                	je     1a2eae <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x20ce>
  1a2e5f:	49 c1 e1 06          	shl    $0x6,%r9
  1a2e63:	c4 01 7d 10 0c 0b    	vmovupd (%r11,%r9,1),%ymm9
  1a2e69:	c4 01 7d 10 54 0b 20 	vmovupd 0x20(%r11,%r9,1),%ymm10
  1a2e70:	c4 a2 b5 b8 24 0e    	vfmadd231pd (%rsi,%r9,1),%ymm9,%ymm4
  1a2e76:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  1a2e7b:	c4 a2 b5 b8 2c 08    	vfmadd231pd (%rax,%r9,1),%ymm9,%ymm5
  1a2e81:	c4 82 b5 b8 34 0f    	vfmadd231pd (%r15,%r9,1),%ymm9,%ymm6
  1a2e87:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
  1a2e8c:	c4 82 b5 b8 3c 08    	vfmadd231pd (%r8,%r9,1),%ymm9,%ymm7
  1a2e92:	c4 a2 ad b8 54 0e 20 	vfmadd231pd 0x20(%rsi,%r9,1),%ymm10,%ymm2
  1a2e99:	c4 a2 ad b8 5c 08 20 	vfmadd231pd 0x20(%rax,%r9,1),%ymm10,%ymm3
  1a2ea0:	c4 82 ad b8 4c 0f 20 	vfmadd231pd 0x20(%r15,%r9,1),%ymm10,%ymm1
  1a2ea7:	c4 02 ad b8 44 08 20 	vfmadd231pd 0x20(%r8,%r9,1),%ymm10,%ymm8
  1a2eae:	4d 01 dc             	add    %r11,%r12
  1a2eb1:	f6 44 24 28 04       	testb  $0x4,0x28(%rsp)
  1a2eb6:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
  1a2ebd:	00 
  1a2ebe:	0f 84 b0 00 00 00    	je     1a2f74 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2194>
  1a2ec4:	f6 84 24 b0 00 00 00 	testb  $0x1,0xb0(%rsp)
  1a2ecb:	01 
  1a2ecc:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  1a2ed1:	0f 84 4e 08 00 00    	je     1a3725 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2945>
  1a2ed7:	41 f6 c5 04          	test   $0x4,%r13b
  1a2edb:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  1a2ee0:	0f 84 53 08 00 00    	je     1a3739 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2959>
  1a2ee6:	40 f6 c7 04          	test   $0x4,%dil
  1a2eea:	0f 84 29 0a 00 00    	je     1a3919 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b39>
  1a2ef0:	f6 44 24 78 04       	testb  $0x4,0x78(%rsp)
  1a2ef5:	0f 84 32 0a 00 00    	je     1a392d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b4d>
  1a2efb:	f6 44 24 70 04       	testb  $0x4,0x70(%rsp)
  1a2f00:	0f 84 3b 0a 00 00    	je     1a3941 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b61>
  1a2f06:	49 b8 fe ff ff ff ff 	movabs $0x3fffffffffffffe,%r8
  1a2f0d:	ff ff 03 
  1a2f10:	48 8b bc 24 78 01 00 	mov    0x178(%rsp),%rdi
  1a2f17:	00 
  1a2f18:	4c 21 c7             	and    %r8,%rdi
  1a2f1b:	4c 8b 8c 24 b8 01 00 	mov    0x1b8(%rsp),%r9
  1a2f22:	00 
  1a2f23:	4d 21 c1             	and    %r8,%r9
  1a2f26:	4c 8b 94 24 b0 01 00 	mov    0x1b0(%rsp),%r10
  1a2f2d:	00 
  1a2f2e:	4d 21 c2             	and    %r8,%r10
  1a2f31:	4c 8b b4 24 a8 01 00 	mov    0x1a8(%rsp),%r14
  1a2f38:	00 
  1a2f39:	4d 21 c6             	and    %r8,%r14
  1a2f3c:	48 c1 e7 05          	shl    $0x5,%rdi
  1a2f40:	49 c1 e1 05          	shl    $0x5,%r9
  1a2f44:	49 c1 e2 05          	shl    $0x5,%r10
  1a2f48:	49 c1 e6 05          	shl    $0x5,%r14
  1a2f4c:	48 01 f7             	add    %rsi,%rdi
  1a2f4f:	4c 03 4c 24 30       	add    0x30(%rsp),%r9
  1a2f54:	4d 01 fa             	add    %r15,%r10
  1a2f57:	49 01 c6             	add    %rax,%r14
  1a2f5a:	c4 41 7d 10 0c 24    	vmovupd (%r12),%ymm9
  1a2f60:	c4 e2 b5 b8 27       	vfmadd231pd (%rdi),%ymm9,%ymm4
  1a2f65:	c4 c2 b5 b8 29       	vfmadd231pd (%r9),%ymm9,%ymm5
  1a2f6a:	c4 c2 b5 b8 32       	vfmadd231pd (%r10),%ymm9,%ymm6
  1a2f6f:	c4 c2 b5 b8 3e       	vfmadd231pd (%r14),%ymm9,%ymm7
  1a2f74:	c5 bd 58 ff          	vaddpd %ymm7,%ymm8,%ymm7
  1a2f78:	c5 f5 58 f6          	vaddpd %ymm6,%ymm1,%ymm6
  1a2f7c:	c5 e5 58 dd          	vaddpd %ymm5,%ymm3,%ymm3
  1a2f80:	c5 ed 58 cc          	vaddpd %ymm4,%ymm2,%ymm1
  1a2f84:	c4 e3 7d 19 ca 01    	vextractf128 $0x1,%ymm1,%xmm2
  1a2f8a:	c5 f1 58 ca          	vaddpd %xmm2,%xmm1,%xmm1
  1a2f8e:	c5 f1 c6 d1 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm2
  1a2f93:	c5 f3 58 ca          	vaddsd %xmm2,%xmm1,%xmm1
  1a2f97:	c4 e3 7d 19 da 01    	vextractf128 $0x1,%ymm3,%xmm2
  1a2f9d:	c5 e1 58 d2          	vaddpd %xmm2,%xmm3,%xmm2
  1a2fa1:	c5 e9 c6 da 01       	vshufpd $0x1,%xmm2,%xmm2,%xmm3
  1a2fa6:	c5 eb 58 d3          	vaddsd %xmm3,%xmm2,%xmm2
  1a2faa:	c4 e3 7d 19 f3 01    	vextractf128 $0x1,%ymm6,%xmm3
  1a2fb0:	c5 c9 58 db          	vaddpd %xmm3,%xmm6,%xmm3
  1a2fb4:	c5 e1 c6 e3 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm4
  1a2fb9:	c5 e3 58 dc          	vaddsd %xmm4,%xmm3,%xmm3
  1a2fbd:	c4 e3 7d 19 fc 01    	vextractf128 $0x1,%ymm7,%xmm4
  1a2fc3:	c5 c1 58 e4          	vaddpd %xmm4,%xmm7,%xmm4
  1a2fc7:	c5 d9 c6 ec 01       	vshufpd $0x1,%xmm4,%xmm4,%xmm5
  1a2fcc:	c5 db 58 e5          	vaddsd %xmm5,%xmm4,%xmm4
  1a2fd0:	4c 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%r9
  1a2fd7:	00 
  1a2fd8:	4d 85 c9             	test   %r9,%r9
  1a2fdb:	48 8b bc 24 90 01 00 	mov    0x190(%rsp),%rdi
  1a2fe2:	00 
  1a2fe3:	4c 8b 84 24 88 01 00 	mov    0x188(%rsp),%r8
  1a2fea:	00 
  1a2feb:	4c 8b 94 24 80 01 00 	mov    0x180(%rsp),%r10
  1a2ff2:	00 
  1a2ff3:	4c 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%r14
  1a2ffa:	00 
  1a2ffb:	0f 84 22 02 00 00    	je     1a3223 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2443>
  1a3001:	49 39 f8             	cmp    %rdi,%r8
  1a3004:	48 89 f8             	mov    %rdi,%rax
  1a3007:	49 0f 42 c0          	cmovb  %r8,%rax
  1a300b:	4c 39 d0             	cmp    %r10,%rax
  1a300e:	49 0f 43 c2          	cmovae %r10,%rax
  1a3012:	49 ff c9             	dec    %r9
  1a3015:	4c 39 f0             	cmp    %r14,%rax
  1a3018:	49 0f 43 c6          	cmovae %r14,%rax
  1a301c:	49 39 c1             	cmp    %rax,%r9
  1a301f:	49 0f 42 c1          	cmovb  %r9,%rax
  1a3023:	48 39 c7             	cmp    %rax,%rdi
  1a3026:	0f 84 27 08 00 00    	je     1a3853 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a73>
  1a302c:	49 39 c0             	cmp    %rax,%r8
  1a302f:	0f 84 a2 08 00 00    	je     1a38d7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2af7>
  1a3035:	49 39 c2             	cmp    %rax,%r10
  1a3038:	0f 84 af 08 00 00    	je     1a38ed <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b0d>
  1a303e:	49 39 c6             	cmp    %rax,%r14
  1a3041:	0f 84 bc 08 00 00    	je     1a3903 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b23>
  1a3047:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  1a304e:	00 
  1a304f:	41 89 c1             	mov    %eax,%r9d
  1a3052:	41 83 e1 03          	and    $0x3,%r9d
  1a3056:	48 83 f8 04          	cmp    $0x4,%rax
  1a305a:	73 12                	jae    1a306e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x228e>
  1a305c:	45 31 e4             	xor    %r12d,%r12d
  1a305f:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
  1a3064:	4c 8b 74 24 20       	mov    0x20(%rsp),%r14
  1a3069:	e9 27 01 00 00       	jmp    1a3195 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x23b5>
  1a306e:	48 83 e0 fc          	and    $0xfffffffffffffffc,%rax
  1a3072:	49 89 f6             	mov    %rsi,%r14
  1a3075:	4c 89 ee             	mov    %r13,%rsi
  1a3078:	4d 89 ea             	mov    %r13,%r10
  1a307b:	49 bd fc ff ff ff ff 	movabs $0xffffffffffffffc,%r13
  1a3082:	ff ff 0f 
  1a3085:	4d 21 ea             	and    %r13,%r10
  1a3088:	4f 8d 14 d6          	lea    (%r14,%r10,8),%r10
  1a308c:	49 83 c2 18          	add    $0x18,%r10
  1a3090:	48 8b bc 24 40 01 00 	mov    0x140(%rsp),%rdi
  1a3097:	00 
  1a3098:	49 8d 1c fb          	lea    (%r11,%rdi,8),%rbx
  1a309c:	48 83 c3 18          	add    $0x18,%rbx
  1a30a0:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
  1a30a5:	4d 21 ee             	and    %r13,%r14
  1a30a8:	4d 89 fc             	mov    %r15,%r12
  1a30ab:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  1a30b0:	4f 8d 34 f7          	lea    (%r15,%r14,8),%r14
  1a30b4:	49 83 c6 18          	add    $0x18,%r14
  1a30b8:	4c 8b 7c 24 78       	mov    0x78(%rsp),%r15
  1a30bd:	4d 21 ef             	and    %r13,%r15
  1a30c0:	4f 8d 3c fc          	lea    (%r12,%r15,8),%r15
  1a30c4:	49 83 c7 18          	add    $0x18,%r15
  1a30c8:	4c 8b 64 24 70       	mov    0x70(%rsp),%r12
  1a30cd:	4d 21 ec             	and    %r13,%r12
  1a30d0:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
  1a30d5:	4f 8d 6c e5 18       	lea    0x18(%r13,%r12,8),%r13
  1a30da:	45 31 e4             	xor    %r12d,%r12d
  1a30dd:	c4 a1 7b 10 6c e3 e8 	vmovsd -0x18(%rbx,%r12,8),%xmm5
  1a30e4:	c4 a1 7b 10 74 e3 f0 	vmovsd -0x10(%rbx,%r12,8),%xmm6
  1a30eb:	c4 82 d1 b9 4c e2 e8 	vfmadd231sd -0x18(%r10,%r12,8),%xmm5,%xmm1
  1a30f2:	c4 82 d1 b9 54 e6 e8 	vfmadd231sd -0x18(%r14,%r12,8),%xmm5,%xmm2
  1a30f9:	c4 82 d1 b9 5c e7 e8 	vfmadd231sd -0x18(%r15,%r12,8),%xmm5,%xmm3
  1a3100:	c4 82 d1 b9 64 e5 e8 	vfmadd231sd -0x18(%r13,%r12,8),%xmm5,%xmm4
  1a3107:	c4 82 c9 b9 4c e2 f0 	vfmadd231sd -0x10(%r10,%r12,8),%xmm6,%xmm1
  1a310e:	c4 82 c9 b9 54 e6 f0 	vfmadd231sd -0x10(%r14,%r12,8),%xmm6,%xmm2
  1a3115:	c4 82 c9 b9 5c e7 f0 	vfmadd231sd -0x10(%r15,%r12,8),%xmm6,%xmm3
  1a311c:	c4 82 c9 b9 64 e5 f0 	vfmadd231sd -0x10(%r13,%r12,8),%xmm6,%xmm4
  1a3123:	c4 a1 7b 10 6c e3 f8 	vmovsd -0x8(%rbx,%r12,8),%xmm5
  1a312a:	c4 82 d1 b9 4c e2 f8 	vfmadd231sd -0x8(%r10,%r12,8),%xmm5,%xmm1
  1a3131:	c4 82 d1 b9 54 e6 f8 	vfmadd231sd -0x8(%r14,%r12,8),%xmm5,%xmm2
  1a3138:	c4 82 d1 b9 5c e7 f8 	vfmadd231sd -0x8(%r15,%r12,8),%xmm5,%xmm3
  1a313f:	c4 82 d1 b9 64 e5 f8 	vfmadd231sd -0x8(%r13,%r12,8),%xmm5,%xmm4
  1a3146:	c4 a1 7b 10 2c e3    	vmovsd (%rbx,%r12,8),%xmm5
  1a314c:	c4 82 d1 b9 0c e2    	vfmadd231sd (%r10,%r12,8),%xmm5,%xmm1
  1a3152:	c4 82 d1 b9 14 e6    	vfmadd231sd (%r14,%r12,8),%xmm5,%xmm2
  1a3158:	c4 82 d1 b9 1c e7    	vfmadd231sd (%r15,%r12,8),%xmm5,%xmm3
  1a315e:	c4 82 d1 b9 64 e5 00 	vfmadd231sd 0x0(%r13,%r12,8),%xmm5,%xmm4
  1a3165:	49 83 c4 04          	add    $0x4,%r12
  1a3169:	4c 39 e0             	cmp    %r12,%rax
  1a316c:	0f 85 6b ff ff ff    	jne    1a30dd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x22fd>
  1a3172:	4d 85 c9             	test   %r9,%r9
  1a3175:	48 8b 9c 24 08 01 00 	mov    0x108(%rsp),%rbx
  1a317c:	00 
  1a317d:	49 89 f5             	mov    %rsi,%r13
  1a3180:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
  1a3185:	4c 8b 7c 24 60       	mov    0x60(%rsp),%r15
  1a318a:	4c 8b 74 24 20       	mov    0x20(%rsp),%r14
  1a318f:	0f 84 8e 00 00 00    	je     1a3223 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2443>
  1a3195:	48 be fc ff ff ff ff 	movabs $0xffffffffffffffc,%rsi
  1a319c:	ff ff 0f 
  1a319f:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  1a31a4:	48 21 f0             	and    %rsi,%rax
  1a31a7:	4e 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%r10
  1a31ae:	00 
  1a31af:	49 8d 04 c2          	lea    (%r10,%rax,8),%rax
  1a31b3:	49 01 c6             	add    %rax,%r14
  1a31b6:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  1a31bb:	48 21 f0             	and    %rsi,%rax
  1a31be:	49 8d 04 c2          	lea    (%r10,%rax,8),%rax
  1a31c2:	49 01 c7             	add    %rax,%r15
  1a31c5:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  1a31ca:	48 21 f0             	and    %rsi,%rax
  1a31cd:	49 8d 04 c2          	lea    (%r10,%rax,8),%rax
  1a31d1:	49 01 c0             	add    %rax,%r8
  1a31d4:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  1a31db:	00 
  1a31dc:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  1a31e3:	00 
  1a31e4:	4a 8d 04 e0          	lea    (%rax,%r12,8),%rax
  1a31e8:	4c 01 d8             	add    %r11,%rax
  1a31eb:	49 21 f5             	and    %rsi,%r13
  1a31ee:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  1a31f3:	4f 8d 14 ea          	lea    (%r10,%r13,8),%r10
  1a31f7:	4c 01 d6             	add    %r10,%rsi
  1a31fa:	45 31 d2             	xor    %r10d,%r10d
  1a31fd:	c4 a1 7b 10 2c d0    	vmovsd (%rax,%r10,8),%xmm5
  1a3203:	c4 a2 d1 b9 0c d6    	vfmadd231sd (%rsi,%r10,8),%xmm5,%xmm1
  1a3209:	c4 82 d1 b9 14 d0    	vfmadd231sd (%r8,%r10,8),%xmm5,%xmm2
  1a320f:	c4 82 d1 b9 1c d7    	vfmadd231sd (%r15,%r10,8),%xmm5,%xmm3
  1a3215:	c4 82 d1 b9 24 d6    	vfmadd231sd (%r14,%r10,8),%xmm5,%xmm4
  1a321b:	49 ff c2             	inc    %r10
  1a321e:	4d 39 d1             	cmp    %r10,%r9
  1a3221:	75 da                	jne    1a31fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x241d>
  1a3223:	48 89 d8             	mov    %rbx,%rax
  1a3226:	48 c1 e8 03          	shr    $0x3,%rax
  1a322a:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  1a322f:	48 39 c6             	cmp    %rax,%rsi
  1a3232:	48 0f 42 c6          	cmovb  %rsi,%rax
  1a3236:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
  1a323d:	00 
  1a323e:	48 39 c6             	cmp    %rax,%rsi
  1a3241:	48 0f 42 c6          	cmovb  %rsi,%rax
  1a3245:	48 85 c0             	test   %rax,%rax
  1a3248:	74 5a                	je     1a32a4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x24c4>
  1a324a:	48 83 f8 01          	cmp    $0x1,%rax
  1a324e:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1a3253:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
  1a3258:	4c 8b a4 24 c0 00 00 	mov    0xc0(%rsp),%r12
  1a325f:	00 
  1a3260:	49 b9 fe ff ff ff ff 	movabs $0x3fffffffffffffe,%r9
  1a3267:	ff ff 03 
  1a326a:	0f 85 82 00 00 00    	jne    1a32f2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2512>
  1a3270:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1a3274:	31 ff                	xor    %edi,%edi
  1a3276:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1a327a:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1a327e:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1a3283:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1a3288:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1a328d:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1a3292:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1a3297:	4c 8b b4 24 b8 00 00 	mov    0xb8(%rsp),%r14
  1a329e:	00 
  1a329f:	e9 2d 01 00 00       	jmp    1a33d1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x25f1>
  1a32a4:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1a32a9:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1a32ae:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1a32b3:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1a32b8:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1a32bd:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1a32c1:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1a32c5:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1a32c9:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1a32ce:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
  1a32d3:	4c 8b a4 24 c0 00 00 	mov    0xc0(%rsp),%r12
  1a32da:	00 
  1a32db:	49 b9 fe ff ff ff ff 	movabs $0x3fffffffffffffe,%r9
  1a32e2:	ff ff 03 
  1a32e5:	4c 8b b4 24 b8 00 00 	mov    0xb8(%rsp),%r14
  1a32ec:	00 
  1a32ed:	e9 25 01 00 00       	jmp    1a3417 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2637>
  1a32f2:	49 be fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%r14
  1a32f9:	ff ff 1f 
  1a32fc:	49 21 c6             	and    %rax,%r14
  1a32ff:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1a3303:	41 b8 60 00 00 00    	mov    $0x60,%r8d
  1a3309:	31 ff                	xor    %edi,%edi
  1a330b:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1a330f:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1a3313:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1a3318:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1a331d:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1a3322:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1a3327:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1a332c:	c4 01 7d 10 6c 03 a0 	vmovupd -0x60(%r11,%r8,1),%ymm13
  1a3333:	c4 01 7d 10 74 03 c0 	vmovupd -0x40(%r11,%r8,1),%ymm14
  1a333a:	c4 01 7d 10 7c 03 e0 	vmovupd -0x20(%r11,%r8,1),%ymm15
  1a3341:	c4 22 95 b8 44 01 a0 	vfmadd231pd -0x60(%rcx,%r8,1),%ymm13,%ymm8
  1a3348:	c4 22 95 b8 4c 02 a0 	vfmadd231pd -0x60(%rdx,%r8,1),%ymm13,%ymm9
  1a334f:	c4 22 95 b8 54 05 a0 	vfmadd231pd -0x60(%rbp,%r8,1),%ymm13,%ymm10
  1a3356:	c4 02 95 b8 5c 04 a0 	vfmadd231pd -0x60(%r12,%r8,1),%ymm13,%ymm11
  1a335d:	c4 a2 8d b8 74 01 c0 	vfmadd231pd -0x40(%rcx,%r8,1),%ymm14,%ymm6
  1a3364:	c4 a2 8d b8 7c 02 c0 	vfmadd231pd -0x40(%rdx,%r8,1),%ymm14,%ymm7
  1a336b:	c4 a2 8d b8 6c 05 c0 	vfmadd231pd -0x40(%rbp,%r8,1),%ymm14,%ymm5
  1a3372:	c4 02 8d b8 64 04 c0 	vfmadd231pd -0x40(%r12,%r8,1),%ymm14,%ymm12
  1a3379:	c4 01 7d 10 2c 03    	vmovupd (%r11,%r8,1),%ymm13
  1a337f:	48 83 c7 02          	add    $0x2,%rdi
  1a3383:	c4 22 85 b8 44 01 e0 	vfmadd231pd -0x20(%rcx,%r8,1),%ymm15,%ymm8
  1a338a:	c4 22 85 b8 4c 02 e0 	vfmadd231pd -0x20(%rdx,%r8,1),%ymm15,%ymm9
  1a3391:	c4 22 85 b8 54 05 e0 	vfmadd231pd -0x20(%rbp,%r8,1),%ymm15,%ymm10
  1a3398:	c4 02 85 b8 5c 04 e0 	vfmadd231pd -0x20(%r12,%r8,1),%ymm15,%ymm11
  1a339f:	c4 a2 95 b8 34 01    	vfmadd231pd (%rcx,%r8,1),%ymm13,%ymm6
  1a33a5:	c4 a2 95 b8 3c 02    	vfmadd231pd (%rdx,%r8,1),%ymm13,%ymm7
  1a33ab:	c4 a2 95 b8 6c 05 00 	vfmadd231pd 0x0(%rbp,%r8,1),%ymm13,%ymm5
  1a33b2:	c4 02 95 b8 24 04    	vfmadd231pd (%r12,%r8,1),%ymm13,%ymm12
  1a33b8:	49 83 e8 80          	sub    $0xffffffffffffff80,%r8
  1a33bc:	49 39 fe             	cmp    %rdi,%r14
  1a33bf:	0f 85 67 ff ff ff    	jne    1a332c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x254c>
  1a33c5:	a8 01                	test   $0x1,%al
  1a33c7:	4c 8b b4 24 b8 00 00 	mov    0xb8(%rsp),%r14
  1a33ce:	00 
  1a33cf:	74 46                	je     1a3417 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2637>
  1a33d1:	48 c1 e7 06          	shl    $0x6,%rdi
  1a33d5:	c4 41 7d 10 2c 3b    	vmovupd (%r11,%rdi,1),%ymm13
  1a33db:	c4 41 7d 10 74 3b 20 	vmovupd 0x20(%r11,%rdi,1),%ymm14
  1a33e2:	c4 62 95 b8 04 39    	vfmadd231pd (%rcx,%rdi,1),%ymm13,%ymm8
  1a33e8:	c4 62 95 b8 0c 3a    	vfmadd231pd (%rdx,%rdi,1),%ymm13,%ymm9
  1a33ee:	c4 62 95 b8 54 3d 00 	vfmadd231pd 0x0(%rbp,%rdi,1),%ymm13,%ymm10
  1a33f5:	c4 42 95 b8 1c 3c    	vfmadd231pd (%r12,%rdi,1),%ymm13,%ymm11
  1a33fb:	c4 e2 8d b8 74 39 20 	vfmadd231pd 0x20(%rcx,%rdi,1),%ymm14,%ymm6
  1a3402:	c4 e2 8d b8 7c 3a 20 	vfmadd231pd 0x20(%rdx,%rdi,1),%ymm14,%ymm7
  1a3409:	c4 e2 8d b8 6c 3d 20 	vfmadd231pd 0x20(%rbp,%rdi,1),%ymm14,%ymm5
  1a3410:	c4 42 8d b8 64 3c 20 	vfmadd231pd 0x20(%r12,%rdi,1),%ymm14,%ymm12
  1a3417:	f6 44 24 28 04       	testb  $0x4,0x28(%rsp)
  1a341c:	74 55                	je     1a3473 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2693>
  1a341e:	f6 84 24 b0 00 00 00 	testb  $0x1,0xb0(%rsp)
  1a3425:	01 
  1a3426:	0f 84 f9 02 00 00    	je     1a3725 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2945>
  1a342c:	f6 c3 04             	test   $0x4,%bl
  1a342f:	0f 84 04 03 00 00    	je     1a3739 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2959>
  1a3435:	48 89 d8             	mov    %rbx,%rax
  1a3438:	48 c1 e8 02          	shr    $0x2,%rax
  1a343c:	4c 21 c8             	and    %r9,%rax
  1a343f:	48 c1 e0 05          	shl    $0x5,%rax
  1a3443:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
  1a3447:	4c 8d 04 02          	lea    (%rdx,%rax,1),%r8
  1a344b:	4c 8d 0c 28          	lea    (%rax,%rbp,1),%r9
  1a344f:	4c 01 e0             	add    %r12,%rax
  1a3452:	4c 8b bc 24 60 01 00 	mov    0x160(%rsp),%r15
  1a3459:	00 
  1a345a:	c4 41 7d 10 2f       	vmovupd (%r15),%ymm13
  1a345f:	c4 62 95 b8 07       	vfmadd231pd (%rdi),%ymm13,%ymm8
  1a3464:	c4 42 95 b8 08       	vfmadd231pd (%r8),%ymm13,%ymm9
  1a3469:	c4 42 95 b8 11       	vfmadd231pd (%r9),%ymm13,%ymm10
  1a346e:	c4 62 95 b8 18       	vfmadd231pd (%rax),%ymm13,%ymm11
  1a3473:	c4 41 1d 58 db       	vaddpd %ymm11,%ymm12,%ymm11
  1a3478:	c5 ad 58 ed          	vaddpd %ymm5,%ymm10,%ymm5
  1a347c:	c5 35 58 cf          	vaddpd %ymm7,%ymm9,%ymm9
  1a3480:	c5 bd 58 f6          	vaddpd %ymm6,%ymm8,%ymm6
  1a3484:	c4 e3 7d 19 f7 01    	vextractf128 $0x1,%ymm6,%xmm7
  1a348a:	c5 c9 58 f7          	vaddpd %xmm7,%xmm6,%xmm6
  1a348e:	c5 c9 c6 fe 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm7
  1a3493:	c5 cb 58 ff          	vaddsd %xmm7,%xmm6,%xmm7
  1a3497:	c4 63 7d 19 ce 01    	vextractf128 $0x1,%ymm9,%xmm6
  1a349d:	c5 b1 58 f6          	vaddpd %xmm6,%xmm9,%xmm6
  1a34a1:	c5 49 c6 c6 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm8
  1a34a6:	c5 3b 58 c6          	vaddsd %xmm6,%xmm8,%xmm8
  1a34aa:	c4 e3 7d 19 ee 01    	vextractf128 $0x1,%ymm5,%xmm6
  1a34b0:	c5 d1 58 ee          	vaddpd %xmm6,%xmm5,%xmm5
  1a34b4:	c5 d1 c6 f5 01       	vshufpd $0x1,%xmm5,%xmm5,%xmm6
  1a34b9:	c5 d3 58 ee          	vaddsd %xmm6,%xmm5,%xmm5
  1a34bd:	c4 63 7d 19 de 01    	vextractf128 $0x1,%ymm11,%xmm6
  1a34c3:	c5 a1 58 f6          	vaddpd %xmm6,%xmm11,%xmm6
  1a34c7:	c5 49 c6 ce 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm9
  1a34cc:	c5 b3 58 f6          	vaddsd %xmm6,%xmm9,%xmm6
  1a34d0:	4d 85 f6             	test   %r14,%r14
  1a34d3:	74 6f                	je     1a3544 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2764>
  1a34d5:	89 df                	mov    %ebx,%edi
  1a34d7:	83 e7 03             	and    $0x3,%edi
  1a34da:	49 8d 46 ff          	lea    -0x1(%r14),%rax
  1a34de:	48 39 c7             	cmp    %rax,%rdi
  1a34e1:	0f 86 6c 03 00 00    	jbe    1a3853 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a73>
  1a34e7:	48 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%rax
  1a34ee:	ff ff 0f 
  1a34f1:	48 21 c3             	and    %rax,%rbx
  1a34f4:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  1a34fb:	00 
  1a34fc:	49 8d 04 c3          	lea    (%r11,%rax,8),%rax
  1a3500:	48 8d 0c d9          	lea    (%rcx,%rbx,8),%rcx
  1a3504:	48 8d 3c da          	lea    (%rdx,%rbx,8),%rdi
  1a3508:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
  1a350f:	00 
  1a3510:	48 01 ea             	add    %rbp,%rdx
  1a3513:	4d 8d 0c dc          	lea    (%r12,%rbx,8),%r9
  1a3517:	41 83 e6 03          	and    $0x3,%r14d
  1a351b:	45 31 c0             	xor    %r8d,%r8d
  1a351e:	c4 21 7b 10 0c c0    	vmovsd (%rax,%r8,8),%xmm9
  1a3524:	c4 a2 b1 b9 3c c1    	vfmadd231sd (%rcx,%r8,8),%xmm9,%xmm7
  1a352a:	c4 22 b1 b9 04 c7    	vfmadd231sd (%rdi,%r8,8),%xmm9,%xmm8
  1a3530:	c4 a2 b1 b9 2c c2    	vfmadd231sd (%rdx,%r8,8),%xmm9,%xmm5
  1a3536:	c4 82 b1 b9 34 c1    	vfmadd231sd (%r9,%r8,8),%xmm9,%xmm6
  1a353c:	49 ff c0             	inc    %r8
  1a353f:	4d 39 c6             	cmp    %r8,%r14
  1a3542:	75 da                	jne    1a351e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x273e>
  1a3544:	48 8b bc 24 00 02 00 	mov    0x200(%rsp),%rdi
  1a354b:	00 
  1a354c:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
  1a3550:	48 8d 47 fe          	lea    -0x2(%rdi),%rax
  1a3554:	48 39 f0             	cmp    %rsi,%rax
  1a3557:	0f 83 09 03 00 00    	jae    1a3866 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a86>
  1a355d:	48 89 c1             	mov    %rax,%rcx
  1a3560:	48 c1 e1 04          	shl    $0x4,%rcx
  1a3564:	4c 8b 84 24 00 01 00 	mov    0x100(%rsp),%r8
  1a356b:	00 
  1a356c:	c4 c1 7b 11 3c 08    	vmovsd %xmm7,(%r8,%rcx,1)
  1a3572:	48 8b 94 24 30 01 00 	mov    0x130(%rsp),%rdx
  1a3579:	00 
  1a357a:	48 01 fa             	add    %rdi,%rdx
  1a357d:	48 83 c2 fe          	add    $0xfffffffffffffffe,%rdx
  1a3581:	c4 41 7b 11 44 08 08 	vmovsd %xmm8,0x8(%r8,%rcx,1)
  1a3588:	48 3b 54 24 68       	cmp    0x68(%rsp),%rdx
  1a358d:	73 52                	jae    1a35e1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2801>
  1a358f:	48 ff cf             	dec    %rdi
  1a3592:	48 39 f7             	cmp    %rsi,%rdi
  1a3595:	0f 83 ba 03 00 00    	jae    1a3955 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b75>
  1a359b:	48 89 fa             	mov    %rdi,%rdx
  1a359e:	48 c1 e2 04          	shl    $0x4,%rdx
  1a35a2:	c4 c1 7b 11 2c 10    	vmovsd %xmm5,(%r8,%rdx,1)
  1a35a8:	c4 c1 7b 11 74 10 08 	vmovsd %xmm6,0x8(%r8,%rdx,1)
  1a35af:	4c 39 d0             	cmp    %r10,%rax
  1a35b2:	0f 83 c1 02 00 00    	jae    1a3879 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a99>
  1a35b8:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1a35bf:	00 
  1a35c0:	c5 fb 11 0c 08       	vmovsd %xmm1,(%rax,%rcx,1)
  1a35c5:	c5 fb 11 54 08 08    	vmovsd %xmm2,0x8(%rax,%rcx,1)
  1a35cb:	4c 39 d7             	cmp    %r10,%rdi
  1a35ce:	0f 83 91 03 00 00    	jae    1a3965 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b85>
  1a35d4:	48 89 f8             	mov    %rdi,%rax
  1a35d7:	c5 f9 28 cb          	vmovapd %xmm3,%xmm1
  1a35db:	c5 f9 28 d4          	vmovapd %xmm4,%xmm2
  1a35df:	eb 09                	jmp    1a35ea <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x280a>
  1a35e1:	4c 39 d0             	cmp    %r10,%rax
  1a35e4:	0f 83 8f 02 00 00    	jae    1a3879 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a99>
  1a35ea:	48 c1 e0 04          	shl    $0x4,%rax
  1a35ee:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
  1a35f5:	00 
  1a35f6:	c5 fb 11 0c 01       	vmovsd %xmm1,(%rcx,%rax,1)
  1a35fb:	c5 fb 11 54 01 08    	vmovsd %xmm2,0x8(%rcx,%rax,1)
  1a3601:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1a3605:	c4 e2 75 37 c0       	vpcmpgtq %ymm0,%ymm1,%ymm0
  1a360a:	c4 e2 7d 59 0d cd d5 	vpbroadcastq -0x182a33(%rip),%ymm1        # 20be0 <anon.78df67f796aa28d9f7a9000f5aadab22.22.llvm.16697214829213932600+0x490>
  1a3611:	e7 ff 
  1a3613:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
  1a3617:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
  1a361d:	c5 f9 5d c1          	vminpd %xmm1,%xmm0,%xmm0
  1a3621:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1a3626:	c5 fb 5d c1          	vminsd %xmm1,%xmm0,%xmm0
  1a362a:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1a362e:	c5 f9 2e c1          	vucomisd %xmm1,%xmm0
  1a3632:	0f 97 c0             	seta   %al
  1a3635:	22 44 24 07          	and    0x7(%rsp),%al
  1a3639:	eb 35                	jmp    1a3670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2890>
  1a363b:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
  1a3642:	00 
  1a3643:	48 39 c7             	cmp    %rax,%rdi
  1a3646:	0f 83 5f 01 00 00    	jae    1a37ab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29cb>
  1a364c:	48 3b 7c 24 58       	cmp    0x58(%rsp),%rdi
  1a3651:	0f 83 6f 01 00 00    	jae    1a37c6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29e6>
  1a3657:	48 ff c7             	inc    %rdi
  1a365a:	48 39 c7             	cmp    %rax,%rdi
  1a365d:	0f 83 2d 01 00 00    	jae    1a3790 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29b0>
  1a3663:	48 3b 7c 24 58       	cmp    0x58(%rsp),%rdi
  1a3668:	0f 83 0d 01 00 00    	jae    1a377b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x299b>
  1a366e:	31 c0                	xor    %eax,%eax
  1a3670:	48 81 c4 38 02 00 00 	add    $0x238,%rsp
  1a3677:	5b                   	pop    %rbx
  1a3678:	41 5c                	pop    %r12
  1a367a:	41 5d                	pop    %r13
  1a367c:	41 5e                	pop    %r14
  1a367e:	41 5f                	pop    %r15
  1a3680:	5d                   	pop    %rbp
  1a3681:	c5 f8 77             	vzeroupper
  1a3684:	c3                   	ret
  1a3685:	4d 89 f2             	mov    %r14,%r10
  1a3688:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  1a368d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  1a3692:	48 8b 9c 24 08 01 00 	mov    0x108(%rsp),%rbx
  1a3699:	00 
  1a369a:	e9 26 da ff ff       	jmp    1a10c5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2e5>
  1a369f:	48 8d 15 92 e2 0c 00 	lea    0xce292(%rip),%rdx        # 271938 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x608>
  1a36a6:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  1a36ad:	00 
  1a36ae:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
  1a36b5:	00 
  1a36b6:	c5 f8 77             	vzeroupper
  1a36b9:	ff 15 01 79 0d 00    	call   *0xd7901(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a36bf:	48 8d 15 8a e2 0c 00 	lea    0xce28a(%rip),%rdx        # 271950 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x620>
  1a36c6:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
  1a36cd:	00 
  1a36ce:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  1a36d3:	c5 f8 77             	vzeroupper
  1a36d6:	ff 15 e4 78 0d 00    	call   *0xd78e4(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a36dc:	48 8d 15 f5 ed 0c 00 	lea    0xcedf5(%rip),%rdx        # 2724d8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a36e3:	48 89 fe             	mov    %rdi,%rsi
  1a36e6:	4c 89 ef             	mov    %r13,%rdi
  1a36e9:	c5 f8 77             	vzeroupper
  1a36ec:	ff 15 ce 78 0d 00    	call   *0xd78ce(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a36f2:	48 8d 15 df ed 0c 00 	lea    0xceddf(%rip),%rdx        # 2724d8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a36f9:	4c 89 ef             	mov    %r13,%rdi
  1a36fc:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1a3701:	c5 f8 77             	vzeroupper
  1a3704:	ff 15 b6 78 0d 00    	call   *0xd78b6(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a370a:	48 8d 15 5f e6 0c 00 	lea    0xce65f(%rip),%rdx        # 271d70 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa40>
  1a3711:	48 8b bc 24 c8 01 00 	mov    0x1c8(%rsp),%rdi
  1a3718:	00 
  1a3719:	48 89 fe             	mov    %rdi,%rsi
  1a371c:	c5 f8 77             	vzeroupper
  1a371f:	ff 15 9b 78 0d 00    	call   *0xd789b(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a3725:	48 8d 15 cc e5 0c 00 	lea    0xce5cc(%rip),%rdx        # 271cf8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9c8>
  1a372c:	31 ff                	xor    %edi,%edi
  1a372e:	31 f6                	xor    %esi,%esi
  1a3730:	c5 f8 77             	vzeroupper
  1a3733:	ff 15 87 78 0d 00    	call   *0xd7887(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a3739:	48 8d 15 d0 e5 0c 00 	lea    0xce5d0(%rip),%rdx        # 271d10 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9e0>
  1a3740:	31 ff                	xor    %edi,%edi
  1a3742:	31 f6                	xor    %esi,%esi
  1a3744:	c5 f8 77             	vzeroupper
  1a3747:	ff 15 73 78 0d 00    	call   *0xd7873(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a374d:	48 8d 15 9c ed 0c 00 	lea    0xced9c(%rip),%rdx        # 2724f0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1a3754:	48 89 fe             	mov    %rdi,%rsi
  1a3757:	4c 89 ef             	mov    %r13,%rdi
  1a375a:	c5 f8 77             	vzeroupper
  1a375d:	ff 15 5d 78 0d 00    	call   *0xd785d(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a3763:	48 8d 15 86 ed 0c 00 	lea    0xced86(%rip),%rdx        # 2724f0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1a376a:	48 89 c7             	mov    %rax,%rdi
  1a376d:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1a3772:	c5 f8 77             	vzeroupper
  1a3775:	ff 15 45 78 0d 00    	call   *0xd7845(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a377b:	48 8d 15 2e e2 0c 00 	lea    0xce22e(%rip),%rdx        # 2719b0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x680>
  1a3782:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  1a3787:	c5 f8 77             	vzeroupper
  1a378a:	ff 15 30 78 0d 00    	call   *0xd7830(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a3790:	48 8d 15 01 e2 0c 00 	lea    0xce201(%rip),%rdx        # 271998 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x668>
  1a3797:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
  1a379e:	00 
  1a379f:	c5 f8 77             	vzeroupper
  1a37a2:	ff 15 18 78 0d 00    	call   *0xd7818(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a37a8:	4c 89 c7             	mov    %r8,%rdi
  1a37ab:	48 8d 15 b6 e1 0c 00 	lea    0xce1b6(%rip),%rdx        # 271968 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x638>
  1a37b2:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
  1a37b9:	00 
  1a37ba:	c5 f8 77             	vzeroupper
  1a37bd:	ff 15 fd 77 0d 00    	call   *0xd77fd(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a37c3:	4c 89 c7             	mov    %r8,%rdi
  1a37c6:	48 8d 15 b3 e1 0c 00 	lea    0xce1b3(%rip),%rdx        # 271980 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x650>
  1a37cd:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  1a37d2:	c5 f8 77             	vzeroupper
  1a37d5:	ff 15 e5 77 0d 00    	call   *0xd77e5(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a37db:	48 8d 15 f6 ec 0c 00 	lea    0xcecf6(%rip),%rdx        # 2724d8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a37e2:	4c 89 cf             	mov    %r9,%rdi
  1a37e5:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1a37ea:	c5 f8 77             	vzeroupper
  1a37ed:	ff 15 cd 77 0d 00    	call   *0xd77cd(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a37f3:	48 8d 15 de ec 0c 00 	lea    0xcecde(%rip),%rdx        # 2724d8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a37fa:	4c 89 cf             	mov    %r9,%rdi
  1a37fd:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  1a3802:	c5 f8 77             	vzeroupper
  1a3805:	ff 15 b5 77 0d 00    	call   *0xd77b5(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a380b:	48 8d 15 c6 ec 0c 00 	lea    0xcecc6(%rip),%rdx        # 2724d8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a3812:	4c 89 ff             	mov    %r15,%rdi
  1a3815:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1a381a:	c5 f8 77             	vzeroupper
  1a381d:	ff 15 9d 77 0d 00    	call   *0xd779d(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a3823:	48 8d 15 ae ec 0c 00 	lea    0xcecae(%rip),%rdx        # 2724d8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a382a:	4c 89 ff             	mov    %r15,%rdi
  1a382d:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  1a3832:	c5 f8 77             	vzeroupper
  1a3835:	ff 15 85 77 0d 00    	call   *0xd7785(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a383b:	48 8d 15 ae ec 0c 00 	lea    0xcecae(%rip),%rdx        # 2724f0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1a3842:	48 89 c7             	mov    %rax,%rdi
  1a3845:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  1a384a:	c5 f8 77             	vzeroupper
  1a384d:	ff 15 6d 77 0d 00    	call   *0xd776d(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a3853:	48 8d 15 16 e5 0c 00 	lea    0xce516(%rip),%rdx        # 271d70 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa40>
  1a385a:	48 89 fe             	mov    %rdi,%rsi
  1a385d:	c5 f8 77             	vzeroupper
  1a3860:	ff 15 5a 77 0d 00    	call   *0xd775a(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a3866:	48 8d 15 6b ec 0c 00 	lea    0xcec6b(%rip),%rdx        # 2724d8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a386d:	48 89 c7             	mov    %rax,%rdi
  1a3870:	c5 f8 77             	vzeroupper
  1a3873:	ff 15 47 77 0d 00    	call   *0xd7747(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a3879:	48 8d 15 58 ec 0c 00 	lea    0xcec58(%rip),%rdx        # 2724d8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a3880:	48 89 c7             	mov    %rax,%rdi
  1a3883:	4c 89 d6             	mov    %r10,%rsi
  1a3886:	c5 f8 77             	vzeroupper
  1a3889:	ff 15 31 77 0d 00    	call   *0xd7731(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a388f:	48 8d 15 72 e3 0c 00 	lea    0xce372(%rip),%rdx        # 271c08 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x8d8>
  1a3896:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  1a389b:	48 89 fe             	mov    %rdi,%rsi
  1a389e:	c5 f8 77             	vzeroupper
  1a38a1:	ff 15 19 77 0d 00    	call   *0xd7719(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a38a7:	48 8d 15 42 ec 0c 00 	lea    0xcec42(%rip),%rdx        # 2724f0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1a38ae:	4c 89 cf             	mov    %r9,%rdi
  1a38b1:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1a38b6:	c5 f8 77             	vzeroupper
  1a38b9:	ff 15 01 77 0d 00    	call   *0xd7701(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a38bf:	48 8d 15 2a ec 0c 00 	lea    0xcec2a(%rip),%rdx        # 2724f0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1a38c6:	4c 89 ff             	mov    %r15,%rdi
  1a38c9:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1a38ce:	c5 f8 77             	vzeroupper
  1a38d1:	ff 15 e9 76 0d 00    	call   *0xd76e9(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a38d7:	48 8d 15 aa e4 0c 00 	lea    0xce4aa(%rip),%rdx        # 271d88 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa58>
  1a38de:	4c 89 c7             	mov    %r8,%rdi
  1a38e1:	4c 89 c6             	mov    %r8,%rsi
  1a38e4:	c5 f8 77             	vzeroupper
  1a38e7:	ff 15 d3 76 0d 00    	call   *0xd76d3(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a38ed:	48 8d 15 ac e4 0c 00 	lea    0xce4ac(%rip),%rdx        # 271da0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa70>
  1a38f4:	4c 89 d7             	mov    %r10,%rdi
  1a38f7:	4c 89 d6             	mov    %r10,%rsi
  1a38fa:	c5 f8 77             	vzeroupper
  1a38fd:	ff 15 bd 76 0d 00    	call   *0xd76bd(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a3903:	48 8d 15 ae e4 0c 00 	lea    0xce4ae(%rip),%rdx        # 271db8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa88>
  1a390a:	4c 89 f7             	mov    %r14,%rdi
  1a390d:	4c 89 f6             	mov    %r14,%rsi
  1a3910:	c5 f8 77             	vzeroupper
  1a3913:	ff 15 a7 76 0d 00    	call   *0xd76a7(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a3919:	48 8d 15 08 e4 0c 00 	lea    0xce408(%rip),%rdx        # 271d28 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9f8>
  1a3920:	31 ff                	xor    %edi,%edi
  1a3922:	31 f6                	xor    %esi,%esi
  1a3924:	c5 f8 77             	vzeroupper
  1a3927:	ff 15 93 76 0d 00    	call   *0xd7693(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a392d:	48 8d 15 0c e4 0c 00 	lea    0xce40c(%rip),%rdx        # 271d40 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa10>
  1a3934:	31 ff                	xor    %edi,%edi
  1a3936:	31 f6                	xor    %esi,%esi
  1a3938:	c5 f8 77             	vzeroupper
  1a393b:	ff 15 7f 76 0d 00    	call   *0xd767f(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a3941:	48 8d 15 10 e4 0c 00 	lea    0xce410(%rip),%rdx        # 271d58 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa28>
  1a3948:	31 ff                	xor    %edi,%edi
  1a394a:	31 f6                	xor    %esi,%esi
  1a394c:	c5 f8 77             	vzeroupper
  1a394f:	ff 15 6b 76 0d 00    	call   *0xd766b(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a3955:	48 8d 15 94 eb 0c 00 	lea    0xceb94(%rip),%rdx        # 2724f0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1a395c:	c5 f8 77             	vzeroupper
  1a395f:	ff 15 5b 76 0d 00    	call   *0xd765b(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
  1a3965:	48 8d 15 84 eb 0c 00 	lea    0xceb84(%rip),%rdx        # 2724f0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1a396c:	4c 89 d6             	mov    %r10,%rsi
  1a396f:	c5 f8 77             	vzeroupper
  1a3972:	ff 15 48 76 0d 00    	call   *0xd7648(%rip)        # 27afc0 <_DYNAMIC+0x2b8>
