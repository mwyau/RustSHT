
/tmp/rsh-b3-dynamic-leaf-profile-ceae53e2/target-b3-seed/release/examples/ducc_spin1_full_transform_parity:     file format elf64-x86-64


Disassembly of section .text:

00000000001e31b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>>:
  1e31b0:	push   %rbp
  1e31b1:	push   %r15
  1e31b3:	push   %r14
  1e31b5:	push   %r13
  1e31b7:	push   %r12
  1e31b9:	push   %rbx
  1e31ba:	sub    $0xb28,%rsp
  1e31c1:	mov    %rdi,0x878(%rsp)
  1e31c9:	mov    0x128(%rsi),%rcx
  1e31d0:	mov    0x130(%rsi),%r12
  1e31d7:	mov    0x10(%rsi),%rdx
  1e31db:	mov    %rdx,0x2f0(%rsp)
  1e31e3:	mov    0x18(%rsi),%rbx
  1e31e7:	mov    0x20(%rsi),%rdx
  1e31eb:	mov    %rdx,0x3c0(%rsp)
  1e31f3:	mov    0x28(%rsi),%rdx
  1e31f7:	mov    %rdx,0x670(%rsp)
  1e31ff:	mov    0x30(%rsi),%rdx
  1e3203:	mov    %rdx,0xa8(%rsp)
  1e320b:	mov    0x100(%rsi),%r14
  1e3212:	mov    0x120(%rsi),%rdx
  1e3219:	mov    %r12,0xe0(%rsp)
  1e3221:	mov    %rcx,0x188(%rsp)
  1e3229:	sub    %rcx,%r12
  1e322c:	lea    0x2(%r12),%rax
  1e3231:	mov    %rax,0x2e8(%rsp)
  1e3239:	shr    $1,%rax
  1e323c:	mov    %rax,0x118(%rsp)
  1e3244:	cmp    %r14,%rdx
  1e3247:	mov    %r14,0x1b0(%rsp)
  1e324f:	mov    %rdx,0x200(%rsp)
  1e3257:	cmovb  %rdx,%r14
  1e325b:	mov    0x38(%rsi),%rax
  1e325f:	mov    %rax,0x650(%rsp)
  1e3267:	mov    0x40(%rsi),%rax
  1e326b:	mov    %rax,0xa0(%rsp)
  1e3273:	mov    0x48(%rsi),%rax
  1e3277:	mov    %rax,0x58(%rsp)
  1e327c:	mov    0x50(%rsi),%rax
  1e3280:	mov    %rax,0x170(%rsp)
  1e3288:	mov    0x58(%rsi),%rax
  1e328c:	mov    %rax,0x68(%rsp)
  1e3291:	mov    0x60(%rsi),%rax
  1e3295:	mov    %rax,0x330(%rsp)
  1e329d:	mov    0x68(%rsi),%rax
  1e32a1:	mov    %rax,0x28(%rsp)
  1e32a6:	mov    0x70(%rsi),%rax
  1e32aa:	mov    %rax,0x180(%rsp)
  1e32b2:	mov    0x78(%rsi),%rax
  1e32b6:	mov    %rax,0x50(%rsp)
  1e32bb:	mov    0x80(%rsi),%rax
  1e32c2:	mov    %rax,0x580(%rsp)
  1e32ca:	mov    0x88(%rsi),%rax
  1e32d1:	mov    %rax,0x20(%rsp)
  1e32d6:	mov    0x90(%rsi),%rax
  1e32dd:	mov    %rax,0x178(%rsp)
  1e32e5:	mov    0x98(%rsi),%rax
  1e32ec:	mov    %rax,0x48(%rsp)
  1e32f1:	mov    0xa0(%rsi),%rax
  1e32f8:	mov    %rax,0x5a0(%rsp)
  1e3300:	mov    0xa8(%rsi),%rax
  1e3307:	mov    %rax,0x40(%rsp)
  1e330c:	mov    0xb0(%rsi),%rax
  1e3313:	mov    %rax,0x1d8(%rsp)
  1e331b:	mov    0xb8(%rsi),%rax
  1e3322:	mov    %rax,0x70(%rsp)
  1e3327:	mov    0xc0(%rsi),%rax
  1e332e:	mov    %rax,0x410(%rsp)
  1e3336:	mov    0xc8(%rsi),%rax
  1e333d:	mov    %rax,0x78(%rsp)
  1e3342:	mov    0xd0(%rsi),%rax
  1e3349:	mov    %rax,0x30(%rsp)
  1e334e:	mov    0xd8(%rsi),%rax
  1e3355:	mov    %rax,0x80(%rsp)
  1e335d:	mov    0xe0(%rsi),%rax
  1e3364:	mov    %rax,0x38(%rsp)
  1e3369:	mov    0xe8(%rsi),%r11
  1e3370:	mov    0xf0(%rsi),%r15
  1e3377:	mov    0xf8(%rsi),%r8
  1e337e:	mov    0x108(%rsi),%rax
  1e3385:	mov    %rax,0x18(%rsp)
  1e338a:	mov    0x110(%rsi),%rbp
  1e3391:	test   %r14,%r14
  1e3394:	mov    %r8,0x10(%rsp)
  1e3399:	je     1e3cf6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0xb46>
  1e339f:	mov    %rbx,0x360(%rsp)
  1e33a7:	mov    0x8(%rsi),%r10
  1e33ab:	mov    0x118(%rsi),%r9
  1e33b2:	xor    %r13d,%r13d
  1e33b5:	vxorpd %xmm6,%xmm6,%xmm6
  1e33b9:	movabs $0x7ff0000000000000,%rbx
  1e33c3:	vmovddup -0x1bcfdb(%rip),%xmm1        # 263f0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x620>
  1e33cb:	vmovddup -0x1bd12b(%rip),%xmm2        # 262a8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x4d8>
  1e33d3:	vmovsd -0x1bd2fb(%rip),%xmm3        # 260e0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x310>
  1e33db:	vmovsd -0x1bced3(%rip),%xmm4        # 26510 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x740>
  1e33e3:	vmovsd -0x1bd273(%rip),%xmm5        # 26178 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x3a8>
  1e33eb:	vmovsd -0x1bd43b(%rip),%xmm7        # 25fb8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x1e8>
  1e33f3:	mov    %r9,0xe8(%rsp)
  1e33fb:	jmp    1e340c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x25c>
  1e33fd:	nopl   (%rax)
  1e3400:	inc    %r13
  1e3403:	cmp    %r14,%r13
  1e3406:	je     1e3b19 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x969>
  1e340c:	vmovsd (%r8,%r13,8),%xmm0
  1e3412:	vucomisd %xmm6,%xmm0
  1e3416:	jne    1e341a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x26a>
  1e3418:	jnp    1e3400 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x250>
  1e341a:	mov    (%r9,%r13,8),%rdi
  1e341e:	vmovq  %xmm0,%rax
  1e3423:	mov    %rax,%rcx
  1e3426:	shr    $0x34,%rcx
  1e342a:	mov    %ecx,%edx
  1e342c:	and    $0x7ff,%edx
  1e3432:	cmp    $0x7ff,%edx
  1e3438:	setae  %dl
  1e343b:	test   %rdi,%rdi
  1e343e:	sete   %sil
  1e3442:	or     %dl,%sil
  1e3445:	jne    1e35e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x430>
  1e344b:	cmp    $0x1000,%rdi
  1e3452:	jle    1e3465 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2b5>
  1e3454:	vandpd %xmm1,%xmm0,%xmm0
  1e3458:	vorpd  %xmm2,%xmm0,%xmm0
  1e345c:	vmulsd %xmm3,%xmm0,%xmm0
  1e3460:	jmp    1e35e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x430>
  1e3465:	cmp    $0xfffffffffffff000,%rdi
  1e346c:	jge    1e3477 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2c7>
  1e346e:	vandpd %xmm1,%xmm0,%xmm0
  1e3472:	jmp    1e35e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x430>
  1e3477:	and    $0x7ff,%ecx
  1e347d:	lea    -0x1(%rcx),%edx
  1e3480:	cmp    $0x7fd,%edx
  1e3486:	ja     1e34b9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x309>
  1e3488:	lea    (%rcx,%rdi,1),%rdx
  1e348c:	dec    %rdx
  1e348f:	cmp    $0x7fe,%rdx
  1e3496:	jae    1e34b9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x309>
  1e3498:	add    %rdi,%rcx
  1e349b:	movabs $0x800fffffffffffff,%rdx
  1e34a5:	and    %rdx,%rax
  1e34a8:	shl    $0x34,%rcx
  1e34ac:	or     %rax,%rcx
  1e34af:	vmovq  %rcx,%xmm0
  1e34b4:	jmp    1e35e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x430>
  1e34b9:	cmp    $0x400,%rdi
  1e34c0:	jl     1e34fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x34d>
  1e34c2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e34d0:	vmulsd %xmm4,%xmm0,%xmm0
  1e34d4:	vmovq  %xmm0,%rax
  1e34d9:	shr    $0x34,%rax
  1e34dd:	and    $0x7ff,%eax
  1e34e2:	cmp    $0x7fe,%eax
  1e34e7:	ja     1e35e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x430>
  1e34ed:	cmp    $0x7fe,%rdi
  1e34f4:	lea    -0x3ff(%rdi),%rdi
  1e34fb:	jg     1e34d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x320>
  1e34fd:	cmp    $0xfffffffffffffc01,%rdi
  1e3504:	jg     1e3530 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x380>
  1e3506:	cs nopw 0x0(%rax,%rax,1)
  1e3510:	vmulsd %xmm5,%xmm0,%xmm0
  1e3514:	vucomisd %xmm6,%xmm0
  1e3518:	jne    1e3520 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x370>
  1e351a:	jnp    1e35e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x430>
  1e3520:	cmp    $0xfffffffffffff804,%rdi
  1e3527:	lea    0x3fe(%rdi),%rdi
  1e352e:	jl     1e3510 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x360>
  1e3530:	vmovaps %xmm0,0x120(%rsp)
  1e3539:	vmovapd %xmm7,%xmm0
  1e353d:	mov    %rbp,0x140(%rsp)
  1e3545:	mov    %r15,0x210(%rsp)
  1e354d:	mov    %r12,%r15
  1e3550:	mov    %r10,%r12
  1e3553:	mov    %r11,%rbp
  1e3556:	vmovapd %xmm2,0x1e0(%rsp)
  1e355f:	call   *0x11a0eb(%rip)        # 2fd650 <_DYNAMIC+0x5c8>
  1e3565:	vmovsd -0x1bd5b5(%rip),%xmm7        # 25fb8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x1e8>
  1e356d:	vxorpd %xmm6,%xmm6,%xmm6
  1e3571:	vmovsd -0x1bd401(%rip),%xmm5        # 26178 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x3a8>
  1e3579:	vmovsd -0x1bd071(%rip),%xmm4        # 26510 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x740>
  1e3581:	vmovsd -0x1bd4a9(%rip),%xmm3        # 260e0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x310>
  1e3589:	vmovapd 0x1e0(%rsp),%xmm2
  1e3592:	vmovddup -0x1bd1aa(%rip),%xmm1        # 263f0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x620>
  1e359a:	mov    %rbp,%r11
  1e359d:	mov    %r12,%r10
  1e35a0:	mov    %r15,%r12
  1e35a3:	mov    0x210(%rsp),%r15
  1e35ab:	mov    0x140(%rsp),%rbp
  1e35b3:	mov    0xe8(%rsp),%r9
  1e35bb:	mov    0x10(%rsp),%r8
  1e35c0:	vmovapd 0x120(%rsp),%xmm8
  1e35c9:	vmulsd %xmm0,%xmm8,%xmm8
  1e35cd:	vmovapd %xmm8,0x120(%rsp)
  1e35d6:	vmovdqa 0x120(%rsp),%xmm0
  1e35df:	nop
  1e35e0:	vmovq  %xmm0,%rax
  1e35e5:	mov    %rax,%rcx
  1e35e8:	shr    $0x34,%rcx
  1e35ec:	and    $0x7ff,%ecx
  1e35f2:	cmp    $0x7fe,%ecx
  1e35f8:	ja     1e3603 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x453>
  1e35fa:	test   %rbx,%rax
  1e35fd:	jne    1e3400 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x250>
  1e3603:	mov    0x118(%rsp),%rax
  1e360b:	test   %rax,%rax
  1e360e:	je     1e8fa8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5df8>
  1e3614:	mov    %rbp,0x140(%rsp)
  1e361c:	mov    %r15,0x210(%rsp)
  1e3624:	mov    %r10,0x648(%rsp)
  1e362c:	mov    %r11,0x98(%rsp)
  1e3634:	movabs $0xffffffffffffffc,%rcx
  1e363e:	mov    0x200(%rsp),%rax
  1e3646:	mov    %rax,%r15
  1e3649:	shr    $0x2,%r15
  1e364d:	mov    %eax,%edx
  1e364f:	and    $0x3,%edx
  1e3652:	mov    %rdx,0x160(%rsp)
  1e365a:	and    %rcx,%rax
  1e365d:	mov    0x170(%rsp),%rbx
  1e3665:	shr    $0x2,%rbx
  1e3669:	mov    0x180(%rsp),%r8
  1e3671:	shr    $0x2,%r8
  1e3675:	mov    0x178(%rsp),%rbp
  1e367d:	shr    $0x2,%rbp
  1e3681:	mov    0x1d8(%rsp),%rdx
  1e3689:	shr    $0x2,%rdx
  1e368d:	mov    0x330(%rsp),%r9
  1e3695:	shr    $0x2,%r9
  1e3699:	mov    %r12,%rcx
  1e369c:	mov    0x580(%rsp),%r12
  1e36a4:	mov    %r12,%r10
  1e36a7:	shr    $0x2,%r10
  1e36ab:	mov    0x5a0(%rsp),%r11
  1e36b3:	shr    $0x2,%r11
  1e36b7:	mov    0x410(%rsp),%r14
  1e36bf:	shr    $0x2,%r14
  1e36c3:	mov    0x2f0(%rsp),%rdi
  1e36cb:	mov    %rdi,%r13
  1e36ce:	shr    $0x2,%r13
  1e36d2:	mov    %rcx,0x850(%rsp)
  1e36da:	lea    0x2(%rcx),%rsi
  1e36de:	and    $0xfffffffffffffffe,%rsi
  1e36e2:	cmp    %r15,%r13
  1e36e5:	mov    %r15,0x518(%rsp)
  1e36ed:	cmovb  %r13,%r15
  1e36f1:	lea    -0x1(%r13),%rcx
  1e36f5:	cmp    %r14,%rcx
  1e36f8:	mov    %r14,0x88(%rsp)
  1e3700:	cmovae %r14,%rcx
  1e3704:	cmp    %r11,%rcx
  1e3707:	mov    %r11,0xf8(%rsp)
  1e370f:	cmovae %r11,%rcx
  1e3713:	cmp    %r10,%rcx
  1e3716:	mov    %r10,0x100(%rsp)
  1e371e:	cmovae %r10,%rcx
  1e3722:	cmp    %r9,%rcx
  1e3725:	mov    %r9,0xd8(%rsp)
  1e372d:	cmovae %r9,%rcx
  1e3731:	cmp    %rdx,%rcx
  1e3734:	mov    %rdx,0xb0(%rsp)
  1e373c:	cmovae %rdx,%rcx
  1e3740:	cmp    %rbp,%rcx
  1e3743:	mov    %rbp,0xc8(%rsp)
  1e374b:	cmovae %rbp,%rcx
  1e374f:	mov    0xe8(%rsp),%rdx
  1e3757:	lea    (%rdx,%rax,8),%rax
  1e375b:	mov    %rax,0xb8(%rsp)
  1e3763:	cmp    %r8,%rcx
  1e3766:	mov    %r8,0xf0(%rsp)
  1e376e:	cmovae %r8,%rcx
  1e3772:	mov    0x160(%rsp),%r8
  1e377a:	cmp    %rbx,%rcx
  1e377d:	mov    %rbx,0xc0(%rsp)
  1e3785:	cmovae %rbx,%rcx
  1e3789:	cmp    %r15,%rcx
  1e378c:	mov    %r15,0x858(%rsp)
  1e3794:	cmovae %r15,%rcx
  1e3798:	mov    %rcx,0x860(%rsp)
  1e37a0:	cmpq   $0x1,0x118(%rsp)
  1e37a9:	mov    %r13,0x60(%rsp)
  1e37ae:	mov    %rsi,0x2e8(%rsp)
  1e37b6:	jne    1e4f49 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1d99>
  1e37bc:	movq   $0x0,0x3e8(%rsp)
  1e37c8:	mov    0x68(%rsp),%r8
  1e37cd:	mov    0x50(%rsp),%r9
  1e37d2:	mov    0x48(%rsp),%r10
  1e37d7:	mov    0x70(%rsp),%r11
  1e37dc:	mov    0x58(%rsp),%r14
  1e37e1:	mov    0x20(%rsp),%r15
  1e37e6:	mov    0x410(%rsp),%rsi
  1e37ee:	mov    0x5a0(%rsp),%rdi
  1e37f6:	mov    %r14,0x450(%rsp)
  1e37fe:	mov    0x170(%rsp),%rax
  1e3806:	mov    %rax,0x458(%rsp)
  1e380e:	mov    %r8,0x460(%rsp)
  1e3816:	mov    0x330(%rsp),%rax
  1e381e:	mov    %rax,0x468(%rsp)
  1e3826:	mov    0x28(%rsp),%rax
  1e382b:	mov    %rax,0x470(%rsp)
  1e3833:	mov    0x180(%rsp),%rax
  1e383b:	mov    %rax,0x478(%rsp)
  1e3843:	mov    %r9,0x480(%rsp)
  1e384b:	mov    %r12,0x488(%rsp)
  1e3853:	mov    %r15,0x490(%rsp)
  1e385b:	mov    0x178(%rsp),%rax
  1e3863:	mov    %rax,0x498(%rsp)
  1e386b:	mov    %r10,0x4a0(%rsp)
  1e3873:	mov    %rdi,0x4a8(%rsp)
  1e387b:	mov    0x40(%rsp),%rax
  1e3880:	mov    %rax,0x4b0(%rsp)
  1e3888:	mov    0x1d8(%rsp),%rax
  1e3890:	mov    %rax,0x4b8(%rsp)
  1e3898:	mov    %r11,0x4c0(%rsp)
  1e38a0:	mov    %rsi,0x4c8(%rsp)
  1e38a8:	mov    0x1b0(%rsp),%r13
  1e38b0:	shr    $0x2,%r13
  1e38b4:	je     1e7d2e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4b7e>
  1e38ba:	lea    -0x1(%r13),%rax
  1e38be:	mov    0x88(%rsp),%rdx
  1e38c6:	cmp    %rdx,%rax
  1e38c9:	cmovae %rdx,%rax
  1e38cd:	mov    0xf8(%rsp),%rdx
  1e38d5:	cmp    %rdx,%rax
  1e38d8:	cmovae %rdx,%rax
  1e38dc:	mov    0x100(%rsp),%rdx
  1e38e4:	cmp    %rdx,%rax
  1e38e7:	cmovae %rdx,%rax
  1e38eb:	mov    0xd8(%rsp),%rdx
  1e38f3:	cmp    %rdx,%rax
  1e38f6:	cmovae %rdx,%rax
  1e38fa:	mov    0xb0(%rsp),%rdx
  1e3902:	cmp    %rdx,%rax
  1e3905:	cmovae %rdx,%rax
  1e3909:	mov    0xc8(%rsp),%rdx
  1e3911:	cmp    %rdx,%rax
  1e3914:	cmovae %rdx,%rax
  1e3918:	mov    0xf0(%rsp),%rdi
  1e3920:	cmp    %rdi,%rax
  1e3923:	cmovae %rdi,%rax
  1e3927:	mov    0xc0(%rsp),%rdx
  1e392f:	cmp    %rdx,%rax
  1e3932:	cmovae %rdx,%rax
  1e3936:	mov    0x858(%rsp),%rdx
  1e393e:	cmp    %rdx,%rax
  1e3941:	cmovae %rdx,%rax
  1e3945:	mov    0x518(%rsp),%rsi
  1e394d:	cmp    %rax,%rsi
  1e3950:	je     1ec538 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9388>
  1e3956:	cmp    %rax,0x60(%rsp)
  1e395b:	je     1ec54b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x939b>
  1e3961:	cmp    %rax,0xc0(%rsp)
  1e3969:	je     1ec21e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x906e>
  1e396f:	cmp    %rax,%rdi
  1e3972:	je     1ec563 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x93b3>
  1e3978:	cmp    %rax,0xc8(%rsp)
  1e3980:	je     1ec239 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9089>
  1e3986:	cmp    %rax,0xb0(%rsp)
  1e398e:	je     1ec254 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x90a4>
  1e3994:	cmp    %rax,0xd8(%rsp)
  1e399c:	je     1ec26f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x90bf>
  1e39a2:	cmp    %rax,0x100(%rsp)
  1e39aa:	je     1ec28a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x90da>
  1e39b0:	cmp    %rax,0xf8(%rsp)
  1e39b8:	je     1ec2a5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x90f5>
  1e39be:	cmp    %rax,0x88(%rsp)
  1e39c6:	je     1ec2c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9110>
  1e39cc:	vxorpd %xmm8,%xmm8,%xmm8
  1e39d1:	xor    %eax,%eax
  1e39d3:	vbroadcastsd -0x1bd73c(%rip),%ymm9        # 262a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x4d0>
  1e39dc:	vbroadcastsd -0x1bd645(%rip),%ymm10        # 263a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x5d0>
  1e39e5:	vbroadcastsd -0x1bd6c6(%rip),%ymm11        # 26328 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x558>
  1e39ee:	mov    %r13,%rcx
  1e39f1:	vxorpd %xmm1,%xmm1,%xmm1
  1e39f5:	vxorpd %xmm2,%xmm2,%xmm2
  1e39f9:	vpxor  %xmm0,%xmm0,%xmm0
  1e39fd:	vxorpd %xmm6,%xmm6,%xmm6
  1e3a01:	vxorpd %xmm7,%xmm7,%xmm7
  1e3a05:	vxorpd %xmm5,%xmm5,%xmm5
  1e3a09:	xor    %edx,%edx
  1e3a0b:	vxorpd %xmm4,%xmm4,%xmm4
  1e3a0f:	vxorpd %xmm3,%xmm3,%xmm3
  1e3a13:	mov    0x28(%rsp),%rbx
  1e3a18:	mov    0x40(%rsp),%r12
  1e3a1d:	mov    0xe8(%rsp),%rbp
  1e3a25:	data16 cs nopw 0x0(%rax,%rax,1)
  1e3a30:	mov    0x10(%rsp),%rsi
  1e3a35:	vmovupd (%rsi,%rax,8),%ymm12
  1e3a3a:	vandpd %ymm9,%ymm12,%ymm13
  1e3a3f:	vcmpge_oqpd %ymm10,%ymm13,%ymm14
  1e3a45:	vcmpeqpd %ymm8,%ymm13,%ymm15
  1e3a4b:	vorpd  %ymm14,%ymm15,%ymm14
  1e3a50:	vcmple_oqpd %ymm11,%ymm13,%ymm13
  1e3a56:	vandpd %ymm13,%ymm14,%ymm13
  1e3a5b:	vpcmpeqq 0x0(%rbp,%rax,8),%ymm8,%ymm14
  1e3a62:	vpcmpgtq %ymm13,%ymm8,%ymm15
  1e3a67:	vpand  %ymm13,%ymm14,%ymm13
  1e3a6c:	mov    %r15,%rdi
  1e3a6f:	mov    %r14,%r15
  1e3a72:	mov    %r11,%r14
  1e3a75:	mov    %r10,%r11
  1e3a78:	mov    %r9,%r10
  1e3a7b:	mov    %r8,%r9
  1e3a7e:	mov    %rdx,%r8
  1e3a81:	vmovmskpd %ymm13,%edx
  1e3a86:	xor    $0xf,%dl
  1e3a89:	movzbl %dl,%edx
  1e3a8c:	mov    %eax,%esi
  1e3a8e:	and    $0x3c,%sil
  1e3a92:	shlx   %rsi,%rdx,%rdx
  1e3a97:	or     %rdx,%r8
  1e3a9a:	mov    %r8,%rdx
  1e3a9d:	mov    %r9,%r8
  1e3aa0:	mov    %r10,%r9
  1e3aa3:	mov    %r11,%r10
  1e3aa6:	mov    %r14,%r11
  1e3aa9:	mov    %r15,%r14
  1e3aac:	mov    %rdi,%r15
  1e3aaf:	vpand  %ymm12,%ymm14,%ymm12
  1e3ab4:	vpand  %ymm15,%ymm12,%ymm12
  1e3ab9:	vmulpd (%r14,%rax,8),%ymm12,%ymm13
  1e3abf:	vaddpd %ymm4,%ymm13,%ymm4
  1e3ac3:	vmulpd (%rbx,%rax,8),%ymm12,%ymm13
  1e3ac8:	vaddpd %ymm5,%ymm13,%ymm5
  1e3acc:	vmulpd (%rdi,%rax,8),%ymm12,%ymm13
  1e3ad1:	vmulpd (%r12,%rax,8),%ymm12,%ymm14
  1e3ad7:	vaddpd %ymm7,%ymm13,%ymm7
  1e3adb:	vaddpd %ymm6,%ymm14,%ymm6
  1e3adf:	vmulpd (%r8,%rax,8),%ymm12,%ymm13
  1e3ae5:	vaddpd %ymm3,%ymm13,%ymm3
  1e3ae9:	vmulpd (%r9,%rax,8),%ymm12,%ymm13
  1e3aef:	vaddpd %ymm0,%ymm13,%ymm0
  1e3af3:	vmulpd (%r10,%rax,8),%ymm12,%ymm13
  1e3af9:	vmulpd (%r11,%rax,8),%ymm12,%ymm12
  1e3aff:	vaddpd %ymm2,%ymm13,%ymm2
  1e3b03:	vaddpd %ymm1,%ymm12,%ymm1
  1e3b07:	add    $0x4,%rax
  1e3b0b:	dec    %rcx
  1e3b0e:	jne    1e3a30 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x880>
  1e3b14:	jmp    1e7d58 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4ba8>
  1e3b19:	xor    %r13d,%r13d
  1e3b1c:	vxorpd %xmm6,%xmm6,%xmm6
  1e3b20:	vmovsd -0x1bdb70(%rip),%xmm7        # 25fb8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x1e8>
  1e3b28:	mov    0x360(%rsp),%rbx
  1e3b30:	jmp    1e3b5a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9aa>
  1e3b32:	vandpd %xmm1,%xmm0,%xmm0
  1e3b36:	vorpd  %xmm2,%xmm0,%xmm0
  1e3b3a:	vmulsd %xmm3,%xmm0,%xmm0
  1e3b3e:	xchg   %ax,%ax
  1e3b40:	vmovq  %xmm0,(%r8,%r13,8)
  1e3b46:	movq   $0x0,(%r9,%r13,8)
  1e3b4e:	inc    %r13
  1e3b51:	cmp    %r14,%r13
  1e3b54:	je     1e3cf6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0xb46>
  1e3b5a:	vmovsd (%r8,%r13,8),%xmm0
  1e3b60:	vucomisd %xmm6,%xmm0
  1e3b64:	jne    1e3b68 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9b8>
  1e3b66:	jnp    1e3b40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x990>
  1e3b68:	mov    (%r9,%r13,8),%rdi
  1e3b6c:	vmovq  %xmm0,%rax
  1e3b71:	mov    %rax,%rcx
  1e3b74:	shr    $0x34,%rcx
  1e3b78:	mov    %ecx,%edx
  1e3b7a:	and    $0x7ff,%edx
  1e3b80:	cmp    $0x7ff,%edx
  1e3b86:	setae  %dl
  1e3b89:	test   %rdi,%rdi
  1e3b8c:	sete   %sil
  1e3b90:	or     %dl,%sil
  1e3b93:	jne    1e3b40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x990>
  1e3b95:	cmp    $0x1000,%rdi
  1e3b9c:	jg     1e3b32 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x982>
  1e3b9e:	cmp    $0xfffffffffffff000,%rdi
  1e3ba5:	jge    1e3bad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9fd>
  1e3ba7:	vandpd %xmm1,%xmm0,%xmm0
  1e3bab:	jmp    1e3b40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x990>
  1e3bad:	and    $0x7ff,%ecx
  1e3bb3:	lea    -0x1(%rcx),%edx
  1e3bb6:	cmp    $0x7fd,%edx
  1e3bbc:	ja     1e3bef <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0xa3f>
  1e3bbe:	lea    (%rcx,%rdi,1),%rdx
  1e3bc2:	dec    %rdx
  1e3bc5:	cmp    $0x7fe,%rdx
  1e3bcc:	jae    1e3bef <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0xa3f>
  1e3bce:	add    %rdi,%rcx
  1e3bd1:	movabs $0x800fffffffffffff,%rdx
  1e3bdb:	and    %rdx,%rax
  1e3bde:	shl    $0x34,%rcx
  1e3be2:	or     %rax,%rcx
  1e3be5:	vmovq  %rcx,%xmm0
  1e3bea:	jmp    1e3b40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x990>
  1e3bef:	cmp    $0x400,%rdi
  1e3bf6:	jl     1e3c2d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0xa7d>
  1e3bf8:	nopl   0x0(%rax,%rax,1)
  1e3c00:	vmulsd %xmm4,%xmm0,%xmm0
  1e3c04:	vmovq  %xmm0,%rax
  1e3c09:	shr    $0x34,%rax
  1e3c0d:	and    $0x7ff,%eax
  1e3c12:	cmp    $0x7fe,%eax
  1e3c17:	ja     1e3b40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x990>
  1e3c1d:	cmp    $0x7fe,%rdi
  1e3c24:	lea    -0x3ff(%rdi),%rdi
  1e3c2b:	jg     1e3c00 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0xa50>
  1e3c2d:	cmp    $0xfffffffffffffc01,%rdi
  1e3c34:	jg     1e3c60 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0xab0>
  1e3c36:	cs nopw 0x0(%rax,%rax,1)
  1e3c40:	vmulsd %xmm5,%xmm0,%xmm0
  1e3c44:	vucomisd %xmm6,%xmm0
  1e3c48:	jne    1e3c50 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0xaa0>
  1e3c4a:	jnp    1e3b40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x990>
  1e3c50:	cmp    $0xfffffffffffff804,%rdi
  1e3c57:	lea    0x3fe(%rdi),%rdi
  1e3c5e:	jl     1e3c40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0xa90>
  1e3c60:	vmovaps %xmm0,0x120(%rsp)
  1e3c69:	vmovapd %xmm7,%xmm0
  1e3c6d:	mov    %rbp,%rbx
  1e3c70:	mov    %r11,%rbp
  1e3c73:	vmovapd %xmm2,0x1e0(%rsp)
  1e3c7c:	call   *0x1199ce(%rip)        # 2fd650 <_DYNAMIC+0x5c8>
  1e3c82:	vmovsd -0x1bdcd2(%rip),%xmm7        # 25fb8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x1e8>
  1e3c8a:	vxorpd %xmm6,%xmm6,%xmm6
  1e3c8e:	vmovsd -0x1bdb1e(%rip),%xmm5        # 26178 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x3a8>
  1e3c96:	vmovsd -0x1bd78e(%rip),%xmm4        # 26510 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x740>
  1e3c9e:	vmovsd -0x1bdbc6(%rip),%xmm3        # 260e0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x310>
  1e3ca6:	vmovapd 0x1e0(%rsp),%xmm2
  1e3caf:	vmovddup -0x1bd8c7(%rip),%xmm1        # 263f0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x620>
  1e3cb7:	mov    %rbp,%r11
  1e3cba:	mov    %rbx,%rbp
  1e3cbd:	mov    0x360(%rsp),%rbx
  1e3cc5:	mov    0xe8(%rsp),%r9
  1e3ccd:	mov    0x10(%rsp),%r8
  1e3cd2:	vmovapd 0x120(%rsp),%xmm8
  1e3cdb:	vmulsd %xmm0,%xmm8,%xmm8
  1e3cdf:	vmovapd %xmm8,0x120(%rsp)
  1e3ce8:	vmovdqa 0x120(%rsp),%xmm0
  1e3cf1:	jmp    1e3b40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x990>
  1e3cf6:	test   %r15,%r15
  1e3cf9:	je     1e3d14 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0xb64>
  1e3cfb:	lea    0x0(,%r15,8),%rdx
  1e3d03:	mov    %r11,%rdi
  1e3d06:	xor    %esi,%esi
  1e3d08:	mov    %r11,%r14
  1e3d0b:	call   *0x1196af(%rip)        # 2fd3c0 <memset@GLIBC_2.2.5>
  1e3d11:	mov    %r14,%r11
  1e3d14:	cmp    0x1b0(%rsp),%r15
  1e3d1c:	mov    0x38(%rsp),%rcx
  1e3d21:	jne    1e6d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bad>
  1e3d27:	inc    %r12
  1e3d2a:	xor    %eax,%eax
  1e3d2c:	cmp    %r12,%rcx
  1e3d2f:	jb     1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e3d35:	cmp    %r15,0x1d8(%rsp)
  1e3d3d:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e3d43:	cmp    %r15,0x178(%rsp)
  1e3d4b:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e3d51:	cmp    %r15,0x180(%rsp)
  1e3d59:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e3d5f:	cmp    %r15,0x170(%rsp)
  1e3d67:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e3d6d:	cmp    %r15,0x3c0(%rsp)
  1e3d75:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e3d7b:	cmp    %r15,0x2f0(%rsp)
  1e3d83:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e3d89:	cmp    %r15,%rbp
  1e3d8c:	mov    0x410(%rsp),%rcx
  1e3d94:	mov    0x5a0(%rsp),%rdx
  1e3d9c:	mov    0x580(%rsp),%rsi
  1e3da4:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e3daa:	cmp    %r15,0x330(%rsp)
  1e3db2:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e3db8:	cmp    %r15,%rsi
  1e3dbb:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e3dc1:	cmp    %r15,%rdx
  1e3dc4:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e3dca:	mov    %r11,0x98(%rsp)
  1e3dd2:	mov    %rbx,0x360(%rsp)
  1e3dda:	cmp    %r15,%rcx
  1e3ddd:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e3de3:	movabs $0xffffffffffffffc,%rax
  1e3ded:	xor    %r8d,%r8d
  1e3df0:	mov    0x118(%rsp),%rbx
  1e3df8:	mov    %rbx,%rcx
  1e3dfb:	sub    $0x1,%rcx
  1e3dff:	cmovb  %r8,%rcx
  1e3e03:	mov    %rcx,0xe8(%rsp)
  1e3e0b:	sub    $0x2,%rbx
  1e3e0f:	cmovb  %r8,%rbx
  1e3e13:	cmpq   $0x6,0x2e8(%rsp)
  1e3e1c:	jae    1e4c00 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1a50>
  1e3e22:	movb   $0x1,0x190(%rsp)
  1e3e2a:	mov    0x2f0(%rsp),%rcx
  1e3e32:	mov    %rcx,0x140(%rsp)
  1e3e3a:	mov    0x410(%rsp),%r12
  1e3e42:	mov    %r12,%rdx
  1e3e45:	mov    0x98(%rsp),%r15
  1e3e4d:	mov    0x70(%rsp),%r13
  1e3e52:	mov    0x10(%rsp),%r9
  1e3e57:	mov    0x58(%rsp),%r14
  1e3e5c:	mov    0x180(%rsp),%rbx
  1e3e64:	mov    0x18(%rsp),%rbp
  1e3e69:	vxorpd %xmm0,%xmm0,%xmm0
  1e3e6d:	vcmpeqpd %ymm0,%ymm0,%ymm0
  1e3e72:	movabs $0x3fffffffffffffe,%r10
  1e3e7c:	cmp    0xe8(%rsp),%r8
  1e3e84:	jae    1e7ae4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4934>
  1e3e8a:	mov    %rbp,0x18(%rsp)
  1e3e8f:	mov    %r10,%rsi
  1e3e92:	mov    0x330(%rsp),%rdi
  1e3e9a:	mov    %rdi,%r10
  1e3e9d:	shr    $0x2,%r10
  1e3ea1:	mov    %edi,%ecx
  1e3ea3:	and    $0x3,%ecx
  1e3ea6:	mov    %rcx,0x5e0(%rsp)
  1e3eae:	mov    %rdi,%rcx
  1e3eb1:	and    %rax,%rcx
  1e3eb4:	mov    %rcx,0x700(%rsp)
  1e3ebc:	mov    0x580(%rsp),%rcx
  1e3ec4:	mov    %rcx,%r14
  1e3ec7:	shr    $0x2,%r14
  1e3ecb:	mov    %ecx,%edi
  1e3ecd:	and    $0x3,%edi
  1e3ed0:	mov    %rdi,0x720(%rsp)
  1e3ed8:	mov    %rcx,%rdi
  1e3edb:	and    %rax,%rdi
  1e3ede:	mov    %rdi,0x60(%rsp)
  1e3ee3:	mov    %r8,0x120(%rsp)
  1e3eeb:	mov    0x5a0(%rsp),%r8
  1e3ef3:	mov    %r8,%rbp
  1e3ef6:	shr    $0x2,%rbp
  1e3efa:	mov    %r8d,%edi
  1e3efd:	and    $0x3,%edi
  1e3f00:	mov    %rdi,0x690(%rsp)
  1e3f08:	mov    %r8,%rcx
  1e3f0b:	and    %rax,%rcx
  1e3f0e:	mov    %rcx,0x118(%rsp)
  1e3f16:	mov    %rdx,0x1e0(%rsp)
  1e3f1e:	mov    0x410(%rsp),%rdi
  1e3f26:	mov    %rdi,%rcx
  1e3f29:	shr    $0x2,%rcx
  1e3f2d:	mov    %edi,%eax
  1e3f2f:	and    $0x3,%eax
  1e3f32:	mov    %rax,0x310(%rsp)
  1e3f3a:	mov    %rdi,%rdx
  1e3f3d:	movabs $0xffffffffffffffc,%rax
  1e3f47:	and    %rax,%rdx
  1e3f4a:	mov    %rdx,0xc8(%rsp)
  1e3f52:	mov    0x2f0(%rsp),%rdx
  1e3f5a:	mov    %rdx,%rax
  1e3f5d:	shr    $0x2,%rax
  1e3f61:	mov    %rax,0x2c0(%rsp)
  1e3f69:	and    %rsi,%r10
  1e3f6c:	shl    $0x5,%r10
  1e3f70:	add    0x68(%rsp),%r10
  1e3f75:	mov    %r10,0xc0(%rsp)
  1e3f7d:	and    %rsi,%r14
  1e3f80:	shl    $0x5,%r14
  1e3f84:	add    0x50(%rsp),%r14
  1e3f89:	mov    %r14,0xd8(%rsp)
  1e3f91:	and    %rsi,%rbp
  1e3f94:	shl    $0x5,%rbp
  1e3f98:	add    0x48(%rsp),%rbp
  1e3f9d:	mov    %rbp,0x100(%rsp)
  1e3fa5:	and    %rsi,%rcx
  1e3fa8:	shl    $0x5,%rcx
  1e3fac:	add    %r13,%rcx
  1e3faf:	mov    %rcx,0xf8(%rsp)
  1e3fb7:	mov    %rdx,%rax
  1e3fba:	shr    $0x3,%rax
  1e3fbe:	mov    %rax,0x200(%rsp)
  1e3fc6:	mov    0x170(%rsp),%rax
  1e3fce:	mov    %rax,%rdi
  1e3fd1:	shr    $0x2,%rdi
  1e3fd5:	mov    %eax,%r14d
  1e3fd8:	and    $0x3,%r14d
  1e3fdc:	mov    %rax,%rsi
  1e3fdf:	movabs $0xffffffffffffffc,%rax
  1e3fe9:	and    %rax,%rsi
  1e3fec:	mov    %rsi,0x2a0(%rsp)
  1e3ff4:	mov    %rbx,%rbp
  1e3ff7:	shr    $0x2,%rbp
  1e3ffb:	mov    %ebx,%eax
  1e3ffd:	and    $0x3,%eax
  1e4000:	mov    %rax,0x88(%rsp)
  1e4008:	movabs $0xffffffffffffffc,%rax
  1e4012:	and    %rax,%rbx
  1e4015:	mov    %rbx,0x520(%rsp)
  1e401d:	mov    0x178(%rsp),%rax
  1e4025:	mov    %rax,%r10
  1e4028:	shr    $0x2,%r10
  1e402c:	mov    %eax,%r11d
  1e402f:	and    $0x3,%r11d
  1e4033:	mov    %rax,%rsi
  1e4036:	movabs $0xffffffffffffffc,%rax
  1e4040:	and    %rax,%rsi
  1e4043:	mov    %rsi,0x4f0(%rsp)
  1e404b:	mov    0x1d8(%rsp),%rax
  1e4053:	mov    %rax,%rdx
  1e4056:	shr    $0x2,%rdx
  1e405a:	mov    %eax,%ebx
  1e405c:	and    $0x3,%ebx
  1e405f:	mov    %rax,%rsi
  1e4062:	movabs $0xffffffffffffffc,%rax
  1e406c:	and    %rax,%rsi
  1e406f:	mov    %rsi,0x600(%rsp)
  1e4077:	mov    0x3c0(%rsp),%rsi
  1e407f:	mov    %rsi,%rcx
  1e4082:	and    %rax,%rcx
  1e4085:	mov    %rcx,0xb0(%rsp)
  1e408d:	mov    0xa8(%rsp),%rax
  1e4095:	cmp    %rax,0x120(%rsp)
  1e409d:	cmova  0x120(%rsp),%rax
  1e40a6:	mov    %rax,0x430(%rsp)
  1e40ae:	mov    0xa0(%rsp),%rax
  1e40b6:	cmp    %rax,0x120(%rsp)
  1e40be:	cmova  0x120(%rsp),%rax
  1e40c7:	mov    %rax,0x3a0(%rsp)
  1e40cf:	mov    0x330(%rsp),%rax
  1e40d7:	shr    $0x3,%rax
  1e40db:	mov    0x580(%rsp),%rcx
  1e40e3:	shr    $0x3,%rcx
  1e40e7:	cmp    %rax,%rcx
  1e40ea:	cmovae %rax,%rcx
  1e40ee:	mov    %r8,%rax
  1e40f1:	mov    0x120(%rsp),%r8
  1e40f9:	shr    $0x3,%rax
  1e40fd:	cmp    %rcx,%rax
  1e4100:	cmovae %rcx,%rax
  1e4104:	mov    0x410(%rsp),%rcx
  1e410c:	shr    $0x3,%rcx
  1e4110:	cmp    %rax,%rcx
  1e4113:	cmovae %rax,%rcx
  1e4117:	mov    %rcx,0x620(%rsp)
  1e411f:	cmp    %rdi,%rbp
  1e4122:	mov    %rdi,0x358(%rsp)
  1e412a:	mov    %rbp,0x210(%rsp)
  1e4132:	cmovb  %rbp,%rdi
  1e4136:	cmp    %rdi,%r10
  1e4139:	mov    %r10,0x5d0(%rsp)
  1e4141:	cmovb  %r10,%rdi
  1e4145:	cmp    %rdi,%rdx
  1e4148:	mov    %rdx,0x5c0(%rsp)
  1e4150:	cmovb  %rdx,%rdi
  1e4154:	mov    %rdi,0x4d0(%rsp)
  1e415c:	mov    %rsi,%rax
  1e415f:	shr    $0x2,%rax
  1e4163:	mov    %rax,0x3f0(%rsp)
  1e416b:	mov    0x88(%rsp),%rdi
  1e4173:	cmp    %r14,%rdi
  1e4176:	mov    %r14,0x98(%rsp)
  1e417e:	cmovb  %rdi,%r14
  1e4182:	cmp    %r14,%r11
  1e4185:	mov    %r11,0xf0(%rsp)
  1e418d:	cmovb  %r11,%r14
  1e4191:	cmp    %r14,%rbx
  1e4194:	mov    %rbx,0x110(%rsp)
  1e419c:	cmovb  %rbx,%r14
  1e41a0:	mov    %r14,0x560(%rsp)
  1e41a8:	mov    0x2f0(%rsp),%rax
  1e41b0:	and    $0x3,%eax
  1e41b3:	mov    %rax,0x540(%rsp)
  1e41bb:	and    $0x3,%esi
  1e41be:	mov    %rsi,0x3c0(%rsp)
  1e41c6:	mov    0x1e0(%rsp),%rsi
  1e41ce:	vxorpd %xmm2,%xmm2,%xmm2
  1e41d2:	vbroadcastsd -0x1be063(%rip),%ymm3        # 26178 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x3a8>
  1e41db:	vmovapd %ymm0,%ymm1
  1e41df:	mov    0x360(%rsp),%rbp
  1e41e7:	movzbl 0x190(%rsp),%edx
  1e41ef:	jmp    1e4220 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1070>
  1e41f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e4200:	vandpd %ymm1,%ymm4,%ymm1
  1e4204:	and    %cl,%dl
  1e4206:	inc    %r8
  1e4209:	mov    %r9,%r15
  1e420c:	mov    %rbx,%r9
  1e420f:	mov    %r11,%rsi
  1e4212:	cmp    0xe8(%rsp),%r8
  1e421a:	jae    1e7be6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4a36>
  1e4220:	mov    %r9,0x10(%rsp)
  1e4225:	mov    0x140(%rsp),%rdi
  1e422d:	mov    0x18(%rsp),%rbx
  1e4232:	mov    %r12,0x140(%rsp)
  1e423a:	mov    %r15,0x18(%rsp)
  1e423f:	mov    %rsi,%rcx
  1e4242:	shr    $0x3,%rcx
  1e4246:	mov    0x620(%rsp),%rax
  1e424e:	cmp    %rax,%rcx
  1e4251:	cmovae %rax,%rcx
  1e4255:	mov    0x200(%rsp),%rax
  1e425d:	cmp    %rcx,%rax
  1e4260:	cmovb  %rax,%rcx
  1e4264:	vxorpd %xmm11,%xmm11,%xmm11
  1e4269:	vxorpd %xmm7,%xmm7,%xmm7
  1e426d:	vxorpd %xmm8,%xmm8,%xmm8
  1e4272:	vxorpd %xmm9,%xmm9,%xmm9
  1e4277:	vxorpd %xmm10,%xmm10,%xmm10
  1e427c:	vxorpd %xmm5,%xmm5,%xmm5
  1e4280:	vxorpd %xmm6,%xmm6,%xmm6
  1e4284:	vxorpd %xmm4,%xmm4,%xmm4
  1e4288:	test   %rcx,%rcx
  1e428b:	mov    0x68(%rsp),%r9
  1e4290:	mov    0x50(%rsp),%r10
  1e4295:	mov    0x48(%rsp),%r15
  1e429a:	mov    0x20(%rsp),%r12
  1e429f:	mov    %r8,0x120(%rsp)
  1e42a7:	mov    0x60(%rsp),%r11
  1e42ac:	je     1e43d7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1227>
  1e42b2:	cmp    $0x1,%rcx
  1e42b6:	jne    1e42c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1110>
  1e42b8:	xor    %eax,%eax
  1e42ba:	jmp    1e438e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x11de>
  1e42bf:	nop
  1e42c0:	mov    %rsi,%r14
  1e42c3:	mov    %rcx,%rsi
  1e42c6:	movabs $0x1ffffffffffffffe,%rax
  1e42d0:	and    %rax,%rsi
  1e42d3:	mov    $0x60,%r8d
  1e42d9:	xor    %eax,%eax
  1e42db:	mov    0x10(%rsp),%r11
  1e42e0:	vmovupd -0x60(%r11,%r8,1),%ymm12
  1e42e7:	vmovupd -0x40(%r11,%r8,1),%ymm13
  1e42ee:	vmovupd -0x20(%r11,%r8,1),%ymm14
  1e42f5:	vfmadd231pd -0x60(%r9,%r8,1),%ymm12,%ymm7
  1e42fc:	vfmadd231pd -0x60(%r10,%r8,1),%ymm12,%ymm8
  1e4303:	vfmadd231pd -0x60(%r15,%r8,1),%ymm12,%ymm9
  1e430a:	vfmadd231pd -0x60(%r13,%r8,1),%ymm12,%ymm10
  1e4311:	vfmadd231pd -0x40(%r9,%r8,1),%ymm13,%ymm5
  1e4318:	vfmadd231pd -0x40(%r10,%r8,1),%ymm13,%ymm6
  1e431f:	vfmadd231pd -0x40(%r15,%r8,1),%ymm13,%ymm4
  1e4326:	vfmadd231pd -0x40(%r13,%r8,1),%ymm13,%ymm11
  1e432d:	vmovupd (%r11,%r8,1),%ymm12
  1e4333:	add    $0x2,%rax
  1e4337:	vfmadd231pd -0x20(%r9,%r8,1),%ymm14,%ymm7
  1e433e:	vfmadd231pd -0x20(%r10,%r8,1),%ymm14,%ymm8
  1e4345:	vfmadd231pd -0x20(%r15,%r8,1),%ymm14,%ymm9
  1e434c:	vfmadd231pd -0x20(%r13,%r8,1),%ymm14,%ymm10
  1e4353:	vfmadd231pd (%r9,%r8,1),%ymm12,%ymm5
  1e4359:	vfmadd231pd (%r10,%r8,1),%ymm12,%ymm6
  1e435f:	vfmadd231pd (%r15,%r8,1),%ymm12,%ymm4
  1e4365:	vfmadd231pd 0x0(%r13,%r8,1),%ymm12,%ymm11
  1e436c:	sub    $0xffffffffffffff80,%r8
  1e4370:	cmp    %rax,%rsi
  1e4373:	jne    1e42e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1130>
  1e4379:	test   $0x1,%cl
  1e437c:	mov    0x120(%rsp),%r8
  1e4384:	mov    %r14,%rsi
  1e4387:	mov    0x60(%rsp),%r11
  1e438c:	je     1e43d7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1227>
  1e438e:	shl    $0x6,%rax
  1e4392:	mov    0x10(%rsp),%rcx
  1e4397:	vmovupd (%rcx,%rax,1),%ymm12
  1e439c:	vmovupd 0x20(%rcx,%rax,1),%ymm13
  1e43a2:	vfmadd231pd (%r9,%rax,1),%ymm12,%ymm7
  1e43a8:	vfmadd231pd (%r10,%rax,1),%ymm12,%ymm8
  1e43ae:	vfmadd231pd (%r15,%rax,1),%ymm12,%ymm9
  1e43b4:	vfmadd231pd 0x0(%r13,%rax,1),%ymm12,%ymm10
  1e43bb:	vfmadd231pd 0x20(%r9,%rax,1),%ymm13,%ymm5
  1e43c2:	vfmadd231pd 0x20(%r10,%rax,1),%ymm13,%ymm6
  1e43c9:	vfmadd231pd 0x20(%r15,%rax,1),%ymm13,%ymm4
  1e43d0:	vfmadd231pd 0x20(%r13,%rax,1),%ymm13,%ymm11
  1e43d7:	mov    %rdi,0x1b0(%rsp)
  1e43df:	mov    %rsi,%rcx
  1e43e2:	shr    $0x2,%rcx
  1e43e6:	test   $0x4,%sil
  1e43ea:	jne    1e4400 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1250>
  1e43ec:	movabs $0xffffffffffffffc,%rdi
  1e43f6:	jmp    1e44ad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x12fd>
  1e43fb:	nopl   0x0(%rax,%rax,1)
  1e4400:	testb  $0x4,0x2f0(%rsp)
  1e4408:	movabs $0xffffffffffffffc,%rdi
  1e4412:	je     1ebd79 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8bc9>
  1e4418:	testb  $0x4,0x330(%rsp)
  1e4420:	je     1ebd8d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8bdd>
  1e4426:	testb  $0x4,0x580(%rsp)
  1e442e:	je     1ebda1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8bf1>
  1e4434:	testb  $0x4,0x5a0(%rsp)
  1e443c:	je     1ebdb5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8c05>
  1e4442:	testb  $0x4,0x410(%rsp)
  1e444a:	je     1ebdc9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8c19>
  1e4450:	mov    %r11,%r14
  1e4453:	mov    %rsi,%r11
  1e4456:	mov    %rcx,%rax
  1e4459:	movabs $0x3fffffffffffffe,%rsi
  1e4463:	and    %rsi,%rax
  1e4466:	shl    $0x5,%rax
  1e446a:	add    0x10(%rsp),%rax
  1e446f:	vmovupd (%rax),%ymm12
  1e4473:	mov    0xc0(%rsp),%rax
  1e447b:	vfmadd231pd (%rax),%ymm12,%ymm7
  1e4480:	mov    0xd8(%rsp),%rax
  1e4488:	vfmadd231pd (%rax),%ymm12,%ymm8
  1e448d:	mov    0x100(%rsp),%rax
  1e4495:	vfmadd231pd (%rax),%ymm12,%ymm9
  1e449a:	mov    0xf8(%rsp),%rax
  1e44a2:	vfmadd231pd (%rax),%ymm12,%ymm10
  1e44a7:	mov    %r11,%rsi
  1e44aa:	mov    %r14,%r11
  1e44ad:	vaddpd %ymm10,%ymm11,%ymm10
  1e44b2:	vaddpd %ymm4,%ymm9,%ymm4
  1e44b6:	vaddpd %ymm6,%ymm8,%ymm6
  1e44ba:	vaddpd %ymm7,%ymm5,%ymm5
  1e44be:	mov    %esi,%r13d
  1e44c1:	and    $0x3,%r13d
  1e44c5:	mov    %rsi,0x1e0(%rsp)
  1e44cd:	mov    %rsi,%r14
  1e44d0:	and    %rdi,%r14
  1e44d3:	vextractf128 $0x1,%ymm5,%xmm7
  1e44d9:	vaddpd %xmm7,%xmm5,%xmm5
  1e44dd:	vshufpd $0x1,%xmm5,%xmm5,%xmm7
  1e44e2:	vaddsd %xmm7,%xmm5,%xmm5
  1e44e6:	vextractf128 $0x1,%ymm6,%xmm7
  1e44ec:	vaddpd %xmm7,%xmm6,%xmm6
  1e44f0:	vshufpd $0x1,%xmm6,%xmm6,%xmm7
  1e44f5:	vaddsd %xmm7,%xmm6,%xmm7
  1e44f9:	vextractf128 $0x1,%ymm4,%xmm6
  1e44ff:	vaddpd %xmm6,%xmm4,%xmm4
  1e4503:	vshufpd $0x1,%xmm4,%xmm4,%xmm6
  1e4508:	vaddsd %xmm6,%xmm4,%xmm4
  1e450c:	vextractf128 $0x1,%ymm10,%xmm6
  1e4512:	vaddpd %xmm6,%xmm10,%xmm6
  1e4516:	vshufpd $0x1,%xmm6,%xmm6,%xmm8
  1e451b:	vaddsd %xmm6,%xmm8,%xmm6
  1e451f:	test   %r13,%r13
  1e4522:	mov    %dl,0x190(%rsp)
  1e4529:	mov    %r14,0xb8(%rsp)
  1e4531:	je     1e4671 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x14c1>
  1e4537:	lea    -0x1(%r13),%rax
  1e453b:	mov    0x310(%rsp),%rsi
  1e4543:	cmp    %rsi,%rax
  1e4546:	cmovae %rsi,%rax
  1e454a:	mov    0x690(%rsp),%r8
  1e4552:	cmp    %r8,%rax
  1e4555:	cmovae %r8,%rax
  1e4559:	mov    0x720(%rsp),%rdi
  1e4561:	cmp    %rdi,%rax
  1e4564:	cmovae %rdi,%rax
  1e4568:	mov    0x5e0(%rsp),%rsi
  1e4570:	cmp    %rsi,%rax
  1e4573:	cmovae %rsi,%rax
  1e4577:	jae    1ebd35 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8b85>
  1e457d:	cmp    %eax,%edi
  1e457f:	je     1ebd50 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8ba0>
  1e4585:	mov    %rbx,0x280(%rsp)
  1e458d:	cmp    %eax,%r8d
  1e4590:	mov    0x700(%rsp),%rsi
  1e4598:	je     1ebd63 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8bb3>
  1e459e:	cmp    %eax,0x310(%rsp)
  1e45a5:	mov    0x118(%rsp),%rdi
  1e45ad:	je     1ebd1a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8b6a>
  1e45b3:	mov    %r13,%rbx
  1e45b6:	mov    0x10(%rsp),%r8
  1e45bb:	vmovsd (%r8,%r14,8),%xmm8
  1e45c1:	vfmadd231sd (%r9,%rsi,8),%xmm8,%xmm5
  1e45c7:	vfmadd231sd (%r10,%r11,8),%xmm8,%xmm7
  1e45cd:	vfmadd231sd (%r15,%rdi,8),%xmm8,%xmm4
  1e45d3:	mov    0x70(%rsp),%rax
  1e45d8:	mov    0xc8(%rsp),%r11
  1e45e0:	vfmadd231sd (%rax,%r11,8),%xmm8,%xmm6
  1e45e6:	cmp    $0x1,%r13d
  1e45ea:	jne    1e4600 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1450>
  1e45ec:	mov    0x120(%rsp),%r8
  1e45f4:	mov    0x280(%rsp),%rbx
  1e45fc:	jmp    1e4671 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x14c1>
  1e45fe:	xchg   %ax,%ax
  1e4600:	vmovsd 0x8(%r8,%r14,8),%xmm8
  1e4607:	vfmadd231sd 0x8(%r9,%rsi,8),%xmm8,%xmm5
  1e460e:	mov    0x60(%rsp),%rbp
  1e4613:	vfmadd231sd 0x8(%r10,%rbp,8),%xmm8,%xmm7
  1e461a:	vfmadd231sd 0x8(%r15,%rdi,8),%xmm8,%xmm4
  1e4621:	vfmadd231sd 0x8(%rax,%r11,8),%xmm8,%xmm6
  1e4628:	cmp    $0x2,%r13d
  1e462c:	je     1e4656 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x14a6>
  1e462e:	vmovsd 0x10(%r8,%r14,8),%xmm8
  1e4635:	vfmadd231sd 0x10(%r9,%rsi,8),%xmm8,%xmm5
  1e463c:	mov    0x60(%rsp),%rdx
  1e4641:	vfmadd231sd 0x10(%r10,%rdx,8),%xmm8,%xmm7
  1e4648:	vfmadd231sd 0x10(%r15,%rdi,8),%xmm8,%xmm4
  1e464f:	vfmadd231sd 0x10(%rax,%r11,8),%xmm8,%xmm6
  1e4656:	mov    0x120(%rsp),%r8
  1e465e:	mov    %rbx,%r13
  1e4661:	mov    0x280(%rsp),%rbx
  1e4669:	mov    0x360(%rsp),%rbp
  1e4671:	lea    (%r8,%r8,1),%r15
  1e4675:	mov    0x38(%rsp),%rax
  1e467a:	mov    %rax,%rsi
  1e467d:	cmp    %rax,%r15
  1e4680:	jae    1ebb67 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x89b7>
  1e4686:	mov    %r8,%rdx
  1e4689:	mov    %r15,%r10
  1e468c:	shl    $0x4,%r10
  1e4690:	mov    0x80(%rsp),%r8
  1e4698:	vmovsd %xmm5,(%r8,%r10,1)
  1e469e:	mov    0x188(%rsp),%rax
  1e46a6:	lea    (%rax,%rdx,2),%rdi
  1e46aa:	vmovsd %xmm7,0x8(%r8,%r10,1)
  1e46b1:	cmp    0xe0(%rsp),%rdi
  1e46b9:	mov    0x10(%rsp),%r9
  1e46be:	mov    0x58(%rsp),%r14
  1e46c3:	mov    0x140(%rsp),%r8
  1e46cb:	jae    1e46f8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1548>
  1e46cd:	lea    0x1(%r15),%r12
  1e46d1:	cmp    %rsi,%r12
  1e46d4:	jae    1ebddd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8c2d>
  1e46da:	shl    $0x4,%r12
  1e46de:	mov    0x80(%rsp),%rax
  1e46e6:	vmovsd %xmm4,(%rax,%r12,1)
  1e46ec:	vmovsd %xmm6,0x8(%rax,%r12,1)
  1e46f3:	mov    0x20(%rsp),%r12
  1e46f8:	mov    0x120(%rsp),%rdx
  1e4700:	cmp    0x430(%rsp),%rdx
  1e4708:	je     1ebba3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x89f3>
  1e470e:	mov    %rdi,0x280(%rsp)
  1e4716:	cmp    0x3a0(%rsp),%rdx
  1e471e:	mov    0x40(%rsp),%rax
  1e4723:	je     1ebbc3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8a13>
  1e4729:	mov    0x1b0(%rsp),%rdi
  1e4731:	shr    $0x2,%rdi
  1e4735:	shr    $0x2,%r8
  1e4739:	mov    0x4d0(%rsp),%r11
  1e4741:	cmp    %r11,%r8
  1e4744:	cmovae %r11,%r8
  1e4748:	cmp    %r8,%rcx
  1e474b:	cmovb  %rcx,%r8
  1e474f:	mov    0x670(%rsp),%rcx
  1e4757:	vbroadcastsd (%rcx,%rdx,8),%ymm6
  1e475d:	mov    0x2c0(%rsp),%rcx
  1e4765:	cmp    %r8,%rcx
  1e4768:	cmovb  %rcx,%r8
  1e476c:	mov    0x650(%rsp),%rcx
  1e4774:	vbroadcastsd (%rcx,%rdx,8),%ymm5
  1e477a:	mov    0x3f0(%rsp),%rcx
  1e4782:	cmp    %r8,%rcx
  1e4785:	cmovb  %rcx,%r8
  1e4789:	cmp    %r8,%rdi
  1e478c:	mov    %rdi,0x160(%rsp)
  1e4794:	cmovb  %rdi,%r8
  1e4798:	test   %r8,%r8
  1e479b:	je     1e4830 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1680>
  1e47a1:	vxorpd %xmm8,%xmm8,%xmm8
  1e47a6:	xor    %ecx,%ecx
  1e47a8:	vxorpd %xmm9,%xmm9,%xmm9
  1e47ad:	vxorpd %xmm7,%xmm7,%xmm7
  1e47b1:	vxorpd %xmm10,%xmm10,%xmm10
  1e47b6:	vmovapd %ymm0,%ymm4
  1e47ba:	mov    0x18(%rsp),%rdi
  1e47bf:	nop
  1e47c0:	vmovupd (%r9,%rcx,1),%ymm11
  1e47c6:	vfmadd231pd (%r14,%rcx,1),%ymm11,%ymm8
  1e47cc:	mov    0x28(%rsp),%rsi
  1e47d1:	vfmadd231pd (%rsi,%rcx,1),%ymm11,%ymm9
  1e47d7:	vfmadd231pd (%r12,%rcx,1),%ymm11,%ymm7
  1e47dd:	vfmadd231pd (%rax,%rcx,1),%ymm11,%ymm10
  1e47e3:	vmovupd 0x0(%rbp,%rcx,1),%ymm12
  1e47e9:	vfmadd213pd %ymm5,%ymm6,%ymm12
  1e47ee:	vfmadd213pd (%rdi,%rcx,1),%ymm11,%ymm12
  1e47f4:	vmovupd %ymm12,(%rbx,%rcx,1)
  1e47f9:	vbroadcastsd -0x1be562(%rip),%ymm11        # 262a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x4d0>
  1e4802:	vandpd %ymm11,%ymm12,%ymm11
  1e4807:	vcmpeqpd %ymm2,%ymm11,%ymm12
  1e480c:	vcmpge_oqpd %ymm3,%ymm11,%ymm11
  1e4811:	vorpd  %ymm12,%ymm11,%ymm11
  1e4816:	vandpd %ymm4,%ymm11,%ymm4
  1e481a:	add    $0x20,%rcx
  1e481e:	dec    %r8
  1e4821:	jne    1e47c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1610>
  1e4823:	jmp    1e4847 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1697>
  1e4825:	data16 cs nopw 0x0(%rax,%rax,1)
  1e4830:	vxorpd %xmm10,%xmm10,%xmm10
  1e4835:	vmovapd %ymm0,%ymm4
  1e4839:	vxorpd %xmm7,%xmm7,%xmm7
  1e483d:	vxorpd %xmm9,%xmm9,%xmm9
  1e4842:	vxorpd %xmm8,%xmm8,%xmm8
  1e4847:	mov    0x1b0(%rsp),%r11
  1e484f:	mov    %r11d,%esi
  1e4852:	and    $0x3,%esi
  1e4855:	mov    %r11,%rdi
  1e4858:	movabs $0xffffffffffffffc,%rdx
  1e4862:	and    %rdx,%rdi
  1e4865:	vextractf128 $0x1,%ymm8,%xmm11
  1e486b:	vaddpd %xmm11,%xmm8,%xmm8
  1e4870:	vshufpd $0x1,%xmm8,%xmm8,%xmm11
  1e4876:	vaddsd %xmm11,%xmm8,%xmm8
  1e487b:	vextractf128 $0x1,%ymm9,%xmm11
  1e4881:	vaddpd %xmm11,%xmm9,%xmm9
  1e4886:	vshufpd $0x1,%xmm9,%xmm9,%xmm11
  1e488c:	vaddsd %xmm11,%xmm9,%xmm9
  1e4891:	vextractf128 $0x1,%ymm7,%xmm11
  1e4897:	vaddpd %xmm7,%xmm11,%xmm7
  1e489b:	vshufpd $0x1,%xmm7,%xmm7,%xmm11
  1e48a0:	vaddsd %xmm7,%xmm11,%xmm7
  1e48a4:	vextractf128 $0x1,%ymm10,%xmm11
  1e48aa:	mov    0x140(%rsp),%r8
  1e48b2:	mov    %r8d,%r12d
  1e48b5:	and    $0x3,%r12d
  1e48b9:	mov    0x560(%rsp),%rcx
  1e48c1:	cmp    %rcx,%r12
  1e48c4:	cmovae %rcx,%r12
  1e48c8:	vaddpd %xmm11,%xmm10,%xmm10
  1e48cd:	cmp    %r12,%r13
  1e48d0:	cmovb  %r13,%r12
  1e48d4:	vshufpd $0x1,%xmm10,%xmm10,%xmm11
  1e48da:	mov    0x540(%rsp),%rcx
  1e48e2:	cmp    %r12,%rcx
  1e48e5:	cmovb  %rcx,%r12
  1e48e9:	vaddsd %xmm11,%xmm10,%xmm10
  1e48ee:	mov    0x3c0(%rsp),%rcx
  1e48f6:	cmp    %r12,%rcx
  1e48f9:	cmovb  %rcx,%r12
  1e48fd:	cmp    %r12,%rsi
  1e4900:	mov    %rsi,0x260(%rsp)
  1e4908:	cmovb  %rsi,%r12
  1e490c:	test   %r12,%r12
  1e490f:	mov    %rdi,0x380(%rsp)
  1e4917:	je     1e4ac0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1910>
  1e491d:	and    %rdx,%r8
  1e4920:	mov    0xb8(%rsp),%rcx
  1e4928:	vmovsd (%r9,%rcx,8),%xmm11
  1e492e:	mov    0xb0(%rsp),%r13
  1e4936:	vmovsd 0x0(%rbp,%r13,8),%xmm12
  1e493d:	vfmadd213sd %xmm5,%xmm6,%xmm12
  1e4942:	mov    0x18(%rsp),%rcx
  1e4947:	vfmadd213sd (%rcx,%r8,8),%xmm11,%xmm12
  1e494d:	vmovq  %xmm12,%rsi
  1e4952:	mov    $0x3f,%cl
  1e4954:	bzhi   %rcx,%rsi,%rsi
  1e4959:	movabs $0x7ff0000000000000,%rcx
  1e4963:	cmp    %rcx,%rsi
  1e4966:	sete   %r14b
  1e496a:	test   %rsi,%rsi
  1e496d:	mov    %rax,%rcx
  1e4970:	sete   %r9b
  1e4974:	or     %r14b,%r9b
  1e4977:	mov    0x58(%rsp),%r14
  1e497c:	mov    0x2a0(%rsp),%rax
  1e4984:	vfmadd231sd (%r14,%rax,8),%xmm11,%xmm8
  1e498a:	mov    0x520(%rsp),%rbp
  1e4992:	mov    0x28(%rsp),%rax
  1e4997:	vfmadd231sd (%rax,%rbp,8),%xmm11,%xmm9
  1e499d:	mov    0x4f0(%rsp),%rdx
  1e49a5:	mov    0x20(%rsp),%rax
  1e49aa:	vfmadd231sd (%rax,%rdx,8),%xmm11,%xmm7
  1e49b0:	mov    0x600(%rsp),%rax
  1e49b8:	vfmadd231sd (%rcx,%rax,8),%xmm11,%xmm10
  1e49be:	movabs $0xfff0000000000000,%r11
  1e49c8:	add    %r11,%rsi
  1e49cb:	shr    $0x35,%rsi
  1e49cf:	cmp    $0x3ff,%esi
  1e49d5:	setb   %cl
  1e49d8:	or     %r9b,%cl
  1e49db:	vmovsd %xmm12,(%rbx,%rdi,8)
  1e49e0:	cmp    $0x1,%r12d
  1e49e4:	je     1e4aa3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x18f3>
  1e49ea:	mov    0x10(%rsp),%rsi
  1e49ef:	mov    0xb8(%rsp),%r9
  1e49f7:	vmovsd 0x8(%rsi,%r9,8),%xmm11
  1e49fe:	mov    0x360(%rsp),%rsi
  1e4a06:	vmovsd 0x8(%rsi,%r13,8),%xmm12
  1e4a0d:	vfmadd213sd %xmm5,%xmm6,%xmm12
  1e4a12:	mov    0x18(%rsp),%rsi
  1e4a17:	vfmadd213sd 0x8(%rsi,%r8,8),%xmm11,%xmm12
  1e4a1e:	vmovq  %xmm12,%r9
  1e4a23:	mov    $0x3f,%sil
  1e4a26:	bzhi   %rsi,%r9,%r9
  1e4a2b:	lea    (%r9,%r11,1),%r14
  1e4a2f:	shr    $0x35,%r14
  1e4a33:	cmp    $0x3ff,%r14d
  1e4a3a:	movzbl %cl,%r14d
  1e4a3e:	mov    $0x0,%ecx
  1e4a43:	cmovb  %r14d,%ecx
  1e4a47:	movabs $0x7ff0000000000000,%rsi
  1e4a51:	cmp    %rsi,%r9
  1e4a54:	cmove  %r14d,%ecx
  1e4a58:	test   %r9,%r9
  1e4a5b:	cmove  %r14d,%ecx
  1e4a5f:	mov    0x58(%rsp),%r14
  1e4a64:	mov    0x2a0(%rsp),%rsi
  1e4a6c:	vfmadd231sd 0x8(%r14,%rsi,8),%xmm11,%xmm8
  1e4a73:	mov    0x28(%rsp),%rsi
  1e4a78:	vfmadd231sd 0x8(%rsi,%rbp,8),%xmm11,%xmm9
  1e4a7f:	mov    0x20(%rsp),%r9
  1e4a84:	vfmadd231sd 0x8(%r9,%rdx,8),%xmm11,%xmm7
  1e4a8b:	mov    0x40(%rsp),%r9
  1e4a90:	vfmadd231sd 0x8(%r9,%rax,8),%xmm11,%xmm10
  1e4a97:	vmovsd %xmm12,0x8(%rbx,%rdi,8)
  1e4a9d:	cmp    $0x2,%r12d
  1e4aa1:	jne    1e4ad4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1924>
  1e4aa3:	mov    0x30(%rsp),%rsi
  1e4aa8:	mov    0x10(%rsp),%r9
  1e4aad:	mov    0x360(%rsp),%rbp
  1e4ab5:	jmp    1e4b83 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x19d3>
  1e4aba:	nopw   0x0(%rax,%rax,1)
  1e4ac0:	mov    $0x1,%cl
  1e4ac2:	mov    0x30(%rsp),%rsi
  1e4ac7:	movzbl 0x190(%rsp),%edx
  1e4acf:	jmp    1e4b93 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x19e3>
  1e4ad4:	mov    0x360(%rsp),%r12
  1e4adc:	vfmadd231sd 0x10(%r12,%r13,8),%xmm6,%xmm5
  1e4ae3:	mov    0x10(%rsp),%r13
  1e4ae8:	mov    0xb8(%rsp),%r9
  1e4af0:	vmovsd 0x10(%r13,%r9,8),%xmm6
  1e4af7:	mov    0x18(%rsp),%r9
  1e4afc:	vfmadd213sd 0x10(%r9,%r8,8),%xmm6,%xmm5
  1e4b03:	vmovq  %xmm5,%r8
  1e4b08:	mov    $0x3f,%r9b
  1e4b0b:	bzhi   %r9,%r8,%r8
  1e4b10:	lea    (%r8,%r11,1),%r9
  1e4b14:	shr    $0x35,%r9
  1e4b18:	cmp    $0x3ff,%r9d
  1e4b1f:	movzbl %cl,%r9d
  1e4b23:	mov    $0x0,%ecx
  1e4b28:	cmovb  %r9d,%ecx
  1e4b2c:	movabs $0x7ff0000000000000,%r11
  1e4b36:	cmp    %r11,%r8
  1e4b39:	cmove  %r9d,%ecx
  1e4b3d:	test   %r8,%r8
  1e4b40:	cmove  %r9d,%ecx
  1e4b44:	mov    0x2a0(%rsp),%r8
  1e4b4c:	vfmadd231sd 0x10(%r14,%r8,8),%xmm6,%xmm8
  1e4b53:	vfmadd231sd 0x10(%rsi,%rbp,8),%xmm6,%xmm9
  1e4b5a:	mov    0x20(%rsp),%rsi
  1e4b5f:	vfmadd231sd 0x10(%rsi,%rdx,8),%xmm6,%xmm7
  1e4b66:	mov    0x40(%rsp),%rdx
  1e4b6b:	vfmadd231sd 0x10(%rdx,%rax,8),%xmm6,%xmm10
  1e4b72:	vmovsd %xmm5,0x10(%rbx,%rdi,8)
  1e4b78:	mov    0x30(%rsp),%rsi
  1e4b7d:	mov    %r13,%r9
  1e4b80:	mov    %r12,%rbp
  1e4b83:	movzbl 0x190(%rsp),%edx
  1e4b8b:	mov    0x1b0(%rsp),%r11
  1e4b93:	cmp    %rsi,%r15
  1e4b96:	mov    0x70(%rsp),%r13
  1e4b9b:	mov    0x1e0(%rsp),%r12
  1e4ba3:	jae    1ebb67 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x89b7>
  1e4ba9:	mov    0x78(%rsp),%r8
  1e4bae:	vmovsd %xmm8,(%r8,%r10,1)
  1e4bb4:	vmovsd %xmm9,0x8(%r8,%r10,1)
  1e4bbb:	mov    0x280(%rsp),%rax
  1e4bc3:	cmp    0xe0(%rsp),%rax
  1e4bcb:	mov    0x120(%rsp),%r8
  1e4bd3:	jae    1e4200 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1050>
  1e4bd9:	inc    %r15
  1e4bdc:	cmp    %rsi,%r15
  1e4bdf:	jae    1ebdf0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8c40>
  1e4be5:	shl    $0x4,%r15
  1e4be9:	mov    0x78(%rsp),%rsi
  1e4bee:	vmovsd %xmm7,(%rsi,%r15,1)
  1e4bf4:	vmovsd %xmm10,0x8(%rsi,%r15,1)
  1e4bfb:	jmp    1e4200 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1050>
  1e4c00:	mov    0x170(%rsp),%r11
  1e4c08:	mov    %r11,%r13
  1e4c0b:	shr    $0x2,%r13
  1e4c0f:	and    $0x3,%r11d
  1e4c13:	mov    0x180(%rsp),%rax
  1e4c1b:	mov    %rax,%rbp
  1e4c1e:	shr    $0x2,%rbp
  1e4c22:	mov    %eax,%r14d
  1e4c25:	and    $0x3,%r14d
  1e4c29:	mov    0x178(%rsp),%rax
  1e4c31:	mov    %rax,%rdi
  1e4c34:	shr    $0x2,%rdi
  1e4c38:	and    $0x3,%eax
  1e4c3b:	mov    0x1d8(%rsp),%r12
  1e4c43:	mov    %r12,%r9
  1e4c46:	shr    $0x2,%r9
  1e4c4a:	mov    %r12d,%ecx
  1e4c4d:	and    $0x3,%ecx
  1e4c50:	mov    0x2f0(%rsp),%r8
  1e4c58:	mov    %r8,%rdx
  1e4c5b:	shr    $0x2,%rdx
  1e4c5f:	mov    %r8d,%r15d
  1e4c62:	and    $0x3,%r15d
  1e4c66:	mov    0x3c0(%rsp),%r10
  1e4c6e:	mov    %r10,%rsi
  1e4c71:	shr    $0x2,%rsi
  1e4c75:	and    $0x3,%r10d
  1e4c79:	cmp    %rbp,%r13
  1e4c7c:	mov    %rbp,%r8
  1e4c7f:	cmovb  %r13,%r8
  1e4c83:	cmp    %rdi,%r8
  1e4c86:	cmovae %rdi,%r8
  1e4c8a:	cmp    %r9,%r8
  1e4c8d:	cmovae %r9,%r8
  1e4c91:	cmp    %rdx,%r8
  1e4c94:	cmovae %rdx,%r8
  1e4c98:	cmp    %rsi,%r8
  1e4c9b:	cmovae %rsi,%r8
  1e4c9f:	mov    %r8,0x430(%rsp)
  1e4ca7:	cmp    %r11,%r15
  1e4caa:	mov    %r11,0xb8(%rsp)
  1e4cb2:	mov    %r15,0x2c0(%rsp)
  1e4cba:	cmovb  %r15,%r11
  1e4cbe:	cmp    %r14,%r11
  1e4cc1:	mov    %r14,0x60(%rsp)
  1e4cc6:	cmovae %r14,%r11
  1e4cca:	cmp    %rax,%r11
  1e4ccd:	cmovae %rax,%r11
  1e4cd1:	cmp    %rcx,%r11
  1e4cd4:	cmovae %rcx,%r11
  1e4cd8:	cmp    %r10,%r11
  1e4cdb:	mov    %r10,0x140(%rsp)
  1e4ce3:	cmovae %r10,%r11
  1e4ce7:	mov    %r11,0x1b0(%rsp)
  1e4cef:	mov    0x330(%rsp),%r10
  1e4cf7:	shr    $0x2,%r10
  1e4cfb:	mov    0x580(%rsp),%r15
  1e4d03:	mov    %r15,%r11
  1e4d06:	shr    $0x2,%r11
  1e4d0a:	cmp    %r10,%r11
  1e4d0d:	cmovae %r10,%r11
  1e4d11:	mov    0x5a0(%rsp),%r14
  1e4d19:	mov    %r14,%r10
  1e4d1c:	shr    $0x2,%r10
  1e4d20:	cmp    %r11,%r10
  1e4d23:	cmovae %r11,%r10
  1e4d27:	mov    0x410(%rsp),%r11
  1e4d2f:	mov    %r11,%r8
  1e4d32:	shr    $0x2,%r8
  1e4d36:	cmp    %r10,%r8
  1e4d39:	cmovae %r10,%r8
  1e4d3d:	cmp    %r8,%r13
  1e4d40:	cmovb  %r13,%r8
  1e4d44:	mov    %r8,0x260(%rsp)
  1e4d4c:	mov    %r13,0x310(%rsp)
  1e4d54:	cmp    %rbp,%r13
  1e4d57:	jne    1e6d27 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3b77>
  1e4d5d:	cmp    %rbp,%rdi
  1e4d60:	jne    1e6d27 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3b77>
  1e4d66:	cmp    %rbp,%r9
  1e4d69:	jne    1e6d27 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3b77>
  1e4d6f:	mov    0x2c0(%rsp),%rdi
  1e4d77:	cmp    0xb8(%rsp),%edi
  1e4d7e:	jne    1e6d27 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3b77>
  1e4d84:	mov    0x140(%rsp),%rdi
  1e4d8c:	cmp    0xb8(%rsp),%edi
  1e4d93:	jne    1e6d27 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3b77>
  1e4d99:	cmp    0x310(%rsp),%rdx
  1e4da1:	jne    1e6d27 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3b77>
  1e4da7:	cmp    0x310(%rsp),%rsi
  1e4daf:	jne    1e6d27 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3b77>
  1e4db5:	mov    0x60(%rsp),%rdx
  1e4dba:	cmp    %edx,0xb8(%rsp)
  1e4dc1:	jne    1e6d27 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3b77>
  1e4dc7:	cmp    0x60(%rsp),%eax
  1e4dcb:	jne    1e6d27 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3b77>
  1e4dd1:	cmp    0x60(%rsp),%ecx
  1e4dd5:	jne    1e6d27 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3b77>
  1e4ddb:	mov    %rbp,0x4d0(%rsp)
  1e4de3:	mov    %rbx,0x118(%rsp)
  1e4deb:	mov    0x170(%rsp),%rdx
  1e4df3:	movabs $0xffffffffffffffc,%rcx
  1e4dfd:	and    %rcx,%rdx
  1e4e00:	mov    %rdx,0x3f0(%rsp)
  1e4e08:	mov    0x180(%rsp),%rbx
  1e4e10:	mov    %rbx,%rax
  1e4e13:	and    %rcx,%rax
  1e4e16:	mov    %rax,0x160(%rsp)
  1e4e1e:	mov    0x178(%rsp),%rax
  1e4e26:	and    %rcx,%rax
  1e4e29:	mov    %rax,0x560(%rsp)
  1e4e31:	and    %rcx,%r12
  1e4e34:	mov    %r12,0x540(%rsp)
  1e4e3c:	mov    0x3c0(%rsp),%rax
  1e4e44:	and    %rcx,%rax
  1e4e47:	mov    %rax,0x520(%rsp)
  1e4e4f:	mov    0x330(%rsp),%rax
  1e4e57:	mov    %eax,%edx
  1e4e59:	and    $0x3,%edx
  1e4e5c:	and    %rcx,%rax
  1e4e5f:	mov    %rax,0x720(%rsp)
  1e4e67:	mov    %r15d,%esi
  1e4e6a:	and    $0x3,%esi
  1e4e6d:	and    %rcx,%r15
  1e4e70:	mov    %r15,0x700(%rsp)
  1e4e78:	mov    %r14d,%edi
  1e4e7b:	and    $0x3,%edi
  1e4e7e:	and    %rcx,%r14
  1e4e81:	mov    %r14,0xc0(%rsp)
  1e4e89:	mov    %r11d,%r8d
  1e4e8c:	and    $0x3,%r8d
  1e4e90:	mov    %r11,%rax
  1e4e93:	and    %rcx,%rax
  1e4e96:	mov    %rax,0xd8(%rsp)
  1e4e9e:	mov    0x140(%rsp),%rax
  1e4ea6:	cmp    %r8,%rax
  1e4ea9:	mov    %r8,0xb0(%rsp)
  1e4eb1:	cmovb  %rax,%r8
  1e4eb5:	mov    %rdx,0x620(%rsp)
  1e4ebd:	lea    -0x1(%rdx),%rax
  1e4ec1:	cmp    %r8,%rax
  1e4ec4:	cmovb  %rax,%r8
  1e4ec8:	cmp    %rdi,%r8
  1e4ecb:	mov    %rdi,0x690(%rsp)
  1e4ed3:	cmovae %rdi,%r8
  1e4ed7:	cmp    %rsi,%r8
  1e4eda:	mov    %rsi,0x600(%rsp)
  1e4ee2:	cmovae %rsi,%r8
  1e4ee6:	mov    0x2c0(%rsp),%rcx
  1e4eee:	cmp    %rcx,%r8
  1e4ef1:	mov    %r8,0x5e0(%rsp)
  1e4ef9:	cmovb  %r8,%rcx
  1e4efd:	mov    %rcx,0xc8(%rsp)
  1e4f05:	mov    0x260(%rsp),%rax
  1e4f0d:	and    $0xfffffffffffffffe,%rax
  1e4f11:	mov    %rax,0x4f0(%rsp)
  1e4f19:	movb   $0x1,0x190(%rsp)
  1e4f21:	mov    %r11,%rax
  1e4f24:	mov    %r11,%rdx
  1e4f27:	mov    0x2f0(%rsp),%rsi
  1e4f2f:	xor    %r8d,%r8d
  1e4f32:	mov    0x10(%rsp),%r9
  1e4f37:	mov    0x98(%rsp),%rcx
  1e4f3f:	mov    0x18(%rsp),%rbp
  1e4f44:	jmp    1e6dac <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bfc>
  1e4f49:	mov    0x3c0(%rsp),%rax
  1e4f51:	mov    %rax,%rcx
  1e4f54:	shr    $0x2,%rcx
  1e4f58:	mov    %rcx,0x510(%rsp)
  1e4f60:	mov    %eax,%esi
  1e4f62:	and    $0x3,%esi
  1e4f65:	movabs $0xffffffffffffffc,%r9
  1e4f6f:	and    %r9,%rax
  1e4f72:	mov    0x360(%rsp),%rcx
  1e4f7a:	lea    (%rcx,%rax,8),%rax
  1e4f7e:	mov    %rax,0x258(%rsp)
  1e4f86:	mov    %edi,%edx
  1e4f88:	and    $0x3,%edx
  1e4f8b:	mov    %rdi,%rcx
  1e4f8e:	mov    %r9,0x1d0(%rsp)
  1e4f96:	and    %r9,%rcx
  1e4f99:	mov    %rcx,0x90(%rsp)
  1e4fa1:	and    $0xfffffffffffffffc,%rdi
  1e4fa5:	mov    %rdi,0x620(%rsp)
  1e4fad:	shl    $0x5,%r13
  1e4fb1:	mov    %r13,0x848(%rsp)
  1e4fb9:	lea    0x0(,%r8,8),%eax
  1e4fc1:	mov    %rax,0x868(%rsp)
  1e4fc9:	mov    %rdx,0x2c0(%rsp)
  1e4fd1:	lea    0x0(,%rdx,8),%eax
  1e4fd8:	mov    %rax,0x358(%rsp)
  1e4fe0:	vxorpd %xmm13,%xmm13,%xmm13
  1e4fe5:	vbroadcastsd -0x1becc6(%rip),%ymm14        # 26328 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x558>
  1e4fee:	vbroadcastsd -0x1bec57(%rip),%ymm15        # 263a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x5d0>
  1e4ff7:	vbroadcastsd -0x1bed60(%rip),%ymm12        # 262a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x4d0>
  1e5000:	mov    %rsi,0x108(%rsp)
  1e5008:	lea    0x0(,%rsi,8),%eax
  1e500f:	mov    %rax,0x870(%rsp)
  1e5017:	mov    $0x1,%esi
  1e501c:	xor    %r15d,%r15d
  1e501f:	mov    0x188(%rsp),%r12
  1e5027:	xor    %ecx,%ecx
  1e5029:	mov    0x18(%rsp),%rbp
  1e502e:	vmovupd %ymm12,0x380(%rsp)
  1e5037:	mov    0x10(%rsp),%rdx
  1e503c:	mov    0xa8(%rsp),%rdi
  1e5044:	cmp    %rdi,%rcx
  1e5047:	je     1ec2ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x913e>
  1e504d:	mov    0xa0(%rsp),%rdi
  1e5055:	cmp    %rdi,%rcx
  1e5058:	mov    0x1b0(%rsp),%r8
  1e5060:	mov    0x2f0(%rsp),%r9
  1e5068:	je     1ec2db <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x912b>
  1e506e:	xor    %eax,%eax
  1e5070:	cmp    0x3c0(%rsp),%r8
  1e5078:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e507e:	cmp    %r9,%r8
  1e5081:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e5087:	cmp    0x140(%rsp),%r8
  1e508f:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e5095:	cmp    0x200(%rsp),%r8
  1e509d:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e50a3:	mov    %r12,0x840(%rsp)
  1e50ab:	mov    %rdx,0x110(%rsp)
  1e50b3:	mov    %r15,0x3e8(%rsp)
  1e50bb:	mov    %rsi,0xd0(%rsp)
  1e50c3:	mov    %rbp,0x10(%rsp)
  1e50c8:	cmp    %r8,0x210(%rsp)
  1e50d0:	mov    0x28(%rsp),%rdx
  1e50d5:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e50db:	mov    0x670(%rsp),%rax
  1e50e3:	vmovsd (%rax,%rcx,8),%xmm0
  1e50e8:	vmovaps %xmm0,0x5d0(%rsp)
  1e50f1:	mov    0x650(%rsp),%rax
  1e50f9:	vmovsd (%rax,%rcx,8),%xmm0
  1e50fe:	vmovapd %xmm0,0x5c0(%rsp)
  1e5107:	mov    0x58(%rsp),%r11
  1e510c:	mov    %r11,0x450(%rsp)
  1e5114:	mov    0x170(%rsp),%rax
  1e511c:	mov    %rax,0x458(%rsp)
  1e5124:	mov    0x68(%rsp),%rbx
  1e5129:	mov    %rbx,0x460(%rsp)
  1e5131:	mov    0x330(%rsp),%rax
  1e5139:	mov    %rax,0x468(%rsp)
  1e5141:	mov    %rdx,0x470(%rsp)
  1e5149:	mov    0x180(%rsp),%rax
  1e5151:	mov    %rax,0x478(%rsp)
  1e5159:	mov    0x50(%rsp),%r8
  1e515e:	mov    %r8,0x480(%rsp)
  1e5166:	mov    0x580(%rsp),%rax
  1e516e:	mov    %rax,0x488(%rsp)
  1e5176:	mov    0x20(%rsp),%rax
  1e517b:	mov    %rax,0x490(%rsp)
  1e5183:	mov    0x178(%rsp),%rax
  1e518b:	mov    %rax,0x498(%rsp)
  1e5193:	mov    0x48(%rsp),%r9
  1e5198:	mov    %r9,0x4a0(%rsp)
  1e51a0:	mov    0x5a0(%rsp),%rax
  1e51a8:	mov    %rax,0x4a8(%rsp)
  1e51b0:	mov    0x40(%rsp),%rax
  1e51b5:	mov    %rax,0x4b0(%rsp)
  1e51bd:	mov    0x1d8(%rsp),%rax
  1e51c5:	mov    %rax,0x4b8(%rsp)
  1e51cd:	mov    0x70(%rsp),%r10
  1e51d2:	mov    %r10,0x4c0(%rsp)
  1e51da:	mov    0x410(%rsp),%rax
  1e51e2:	mov    %rax,0x4c8(%rsp)
  1e51ea:	mov    0x60(%rsp),%rsi
  1e51ef:	test   %rsi,%rsi
  1e51f2:	je     1e538a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x21da>
  1e51f8:	mov    0x860(%rsp),%rax
  1e5200:	mov    0x518(%rsp),%rdi
  1e5208:	cmp    %rax,%rdi
  1e520b:	je     1ec4a1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x92f1>
  1e5211:	cmp    %rax,%rsi
  1e5214:	je     1ec48e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x92de>
  1e521a:	cmp    %rax,0xc0(%rsp)
  1e5222:	je     1ec21e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x906e>
  1e5228:	cmp    %rax,0xf0(%rsp)
  1e5230:	je     1ec473 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x92c3>
  1e5236:	cmp    %rax,0xc8(%rsp)
  1e523e:	je     1ec239 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9089>
  1e5244:	cmp    %rax,0xb0(%rsp)
  1e524c:	je     1ec254 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x90a4>
  1e5252:	cmp    %rax,0xd8(%rsp)
  1e525a:	je     1ec26f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x90bf>
  1e5260:	cmp    %rax,0x100(%rsp)
  1e5268:	je     1ec28a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x90da>
  1e526e:	cmp    %rax,0xf8(%rsp)
  1e5276:	je     1ec2a5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x90f5>
  1e527c:	cmp    %rax,0x88(%rsp)
  1e5284:	je     1ec2c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9110>
  1e528a:	vxorpd %xmm0,%xmm0,%xmm0
  1e528e:	mov    %rsi,%rax
  1e5291:	xor    %ecx,%ecx
  1e5293:	vxorpd %xmm2,%xmm2,%xmm2
  1e5297:	vxorpd %xmm1,%xmm1,%xmm1
  1e529b:	vxorpd %xmm4,%xmm4,%xmm4
  1e529f:	vxorpd %xmm6,%xmm6,%xmm6
  1e52a3:	vxorpd %xmm5,%xmm5,%xmm5
  1e52a7:	xor    %edi,%edi
  1e52a9:	vxorpd %xmm7,%xmm7,%xmm7
  1e52ad:	vxorpd %xmm3,%xmm3,%xmm3
  1e52b1:	mov    0x28(%rsp),%r14
  1e52b6:	mov    0x20(%rsp),%r15
  1e52bb:	mov    0x40(%rsp),%r13
  1e52c0:	mov    0xe8(%rsp),%rbp
  1e52c8:	mov    0x110(%rsp),%r12
  1e52d0:	vmovupd (%r12,%rcx,8),%ymm8
  1e52d6:	vandpd %ymm12,%ymm8,%ymm9
  1e52db:	vcmpge_oqpd %ymm15,%ymm9,%ymm10
  1e52e1:	vcmpeqpd %ymm13,%ymm9,%ymm11
  1e52e7:	vorpd  %ymm10,%ymm11,%ymm10
  1e52ec:	vcmple_oqpd %ymm14,%ymm9,%ymm9
  1e52f2:	vandpd %ymm9,%ymm10,%ymm9
  1e52f7:	vpcmpeqq 0x0(%rbp,%rcx,8),%ymm13,%ymm10
  1e52fe:	vpcmpgtq %ymm9,%ymm13,%ymm11
  1e5303:	vpand  %ymm9,%ymm10,%ymm9
  1e5308:	vmovmskpd %ymm9,%edx
  1e530d:	xor    $0xf,%dl
  1e5310:	movzbl %dl,%edx
  1e5313:	mov    %ecx,%esi
  1e5315:	and    $0x3c,%sil
  1e5319:	shlx   %rsi,%rdx,%rdx
  1e531e:	or     %rdx,%rdi
  1e5321:	vpand  %ymm8,%ymm10,%ymm8
  1e5326:	vpand  %ymm11,%ymm8,%ymm8
  1e532b:	vmulpd (%r11,%rcx,8),%ymm8,%ymm9
  1e5331:	vaddpd %ymm7,%ymm9,%ymm7
  1e5335:	vmulpd (%r14,%rcx,8),%ymm8,%ymm9
  1e533b:	vaddpd %ymm5,%ymm9,%ymm5
  1e533f:	vmulpd (%r15,%rcx,8),%ymm8,%ymm9
  1e5345:	vmulpd 0x0(%r13,%rcx,8),%ymm8,%ymm10
  1e534c:	vaddpd %ymm6,%ymm9,%ymm6
  1e5350:	vaddpd %ymm4,%ymm10,%ymm4
  1e5354:	vmulpd (%rbx,%rcx,8),%ymm8,%ymm9
  1e5359:	vaddpd %ymm3,%ymm9,%ymm3
  1e535d:	vmulpd (%r8,%rcx,8),%ymm8,%ymm9
  1e5363:	vaddpd %ymm1,%ymm9,%ymm1
  1e5367:	vmulpd (%r9,%rcx,8),%ymm8,%ymm9
  1e536d:	vmulpd (%r10,%rcx,8),%ymm8,%ymm8
  1e5373:	vaddpd %ymm2,%ymm9,%ymm2
  1e5377:	vaddpd %ymm0,%ymm8,%ymm0
  1e537b:	add    $0x4,%rcx
  1e537f:	dec    %rax
  1e5382:	jne    1e52d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2120>
  1e5388:	jmp    1e53bc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x220c>
  1e538a:	vxorpd %xmm0,%xmm0,%xmm0
  1e538e:	vxorpd %xmm2,%xmm2,%xmm2
  1e5392:	vxorpd %xmm1,%xmm1,%xmm1
  1e5396:	vxorpd %xmm3,%xmm3,%xmm3
  1e539a:	vxorpd %xmm4,%xmm4,%xmm4
  1e539e:	vxorpd %xmm6,%xmm6,%xmm6
  1e53a2:	vxorpd %xmm5,%xmm5,%xmm5
  1e53a6:	vxorpd %xmm7,%xmm7,%xmm7
  1e53aa:	xor    %edi,%edi
  1e53ac:	mov    0xe8(%rsp),%rbp
  1e53b4:	mov    0x110(%rsp),%r12
  1e53bc:	vperm2f128 $0x31,%ymm4,%ymm6,%ymm8
  1e53c2:	vinsertf128 $0x1,%xmm4,%ymm6,%ymm4
  1e53c8:	vaddpd %ymm4,%ymm8,%ymm4
  1e53cc:	vperm2f128 $0x31,%ymm5,%ymm7,%ymm6
  1e53d2:	vinsertf128 $0x1,%xmm5,%ymm7,%ymm5
  1e53d8:	vaddpd %ymm6,%ymm5,%ymm5
  1e53dc:	vhaddpd %ymm4,%ymm5,%ymm4
  1e53e0:	vpermpd $0xd8,%ymm4,%ymm4
  1e53e6:	vmovupd %ymm4,0x218(%rsp)
  1e53ef:	vperm2f128 $0x31,%ymm0,%ymm2,%ymm4
  1e53f5:	vinsertf128 $0x1,%xmm0,%ymm2,%ymm0
  1e53fb:	vaddpd %ymm4,%ymm0,%ymm0
  1e53ff:	vperm2f128 $0x31,%ymm1,%ymm3,%ymm2
  1e5405:	vinsertf128 $0x1,%xmm1,%ymm3,%ymm1
  1e540b:	vaddpd %ymm2,%ymm1,%ymm1
  1e540f:	vhaddpd %ymm0,%ymm1,%ymm0
  1e5413:	vpermpd $0xd8,%ymm0,%ymm0
  1e5419:	vmovupd %ymm0,0x238(%rsp)
  1e5422:	lea    0x450(%rsp),%rax
  1e542a:	mov    %rax,0x6b0(%rsp)
  1e5432:	lea    0x470(%rsp),%rax
  1e543a:	mov    %rax,0x6b8(%rsp)
  1e5442:	mov    %r12,0x6c0(%rsp)
  1e544a:	mov    0x2f0(%rsp),%rax
  1e5452:	mov    %rax,0x6c8(%rsp)
  1e545a:	mov    %rbp,0x6d0(%rsp)
  1e5462:	mov    0x200(%rsp),%rcx
  1e546a:	mov    %rcx,0x6d8(%rsp)
  1e5472:	lea    0x490(%rsp),%rcx
  1e547a:	mov    %rcx,0x6e0(%rsp)
  1e5482:	lea    0x4b0(%rsp),%rcx
  1e548a:	mov    %rcx,0x6e8(%rsp)
  1e5492:	mov    0x648(%rsp),%rcx
  1e549a:	mov    %rcx,0x6f0(%rsp)
  1e54a2:	mov    %rax,0x6f8(%rsp)
  1e54aa:	cmpq   $0x0,0x60(%rsp)
  1e54b0:	je     1e5ee5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2d35>
  1e54b6:	xor    %r13d,%r13d
  1e54b9:	mov    %rdi,0x18(%rsp)
  1e54be:	jmp    1e5526 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2376>
  1e54c0:	lea    0x1(%r14),%rbp
  1e54c4:	lea    0x6b0(%rsp),%r12
  1e54cc:	mov    %r12,%rdi
  1e54cf:	mov    %r14,%rsi
  1e54d2:	lea    0x218(%rsp),%rbx
  1e54da:	mov    %rbx,%rdx
  1e54dd:	vzeroupper
  1e54e0:	call   1f7760 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e54e5:	or     $0x2,%r14
  1e54e9:	mov    %r12,%rdi
  1e54ec:	mov    %rbp,%rsi
  1e54ef:	mov    %rbx,%rdx
  1e54f2:	call   1f7760 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e54f7:	mov    %r12,%rdi
  1e54fa:	mov    %r14,%rsi
  1e54fd:	mov    %rbx,%rdx
  1e5500:	call   1f7760 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e5505:	mov    %r12,%rdi
  1e5508:	mov    %r15,%rsi
  1e550b:	mov    %rbx,%rdx
  1e550e:	call   1f7760 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e5513:	inc    %r13
  1e5516:	cmp    0x60(%rsp),%r13
  1e551b:	mov    0x18(%rsp),%rdi
  1e5520:	je     1e5ee5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2d35>
  1e5526:	lea    0x0(,%r13,4),%r14
  1e552e:	shrx   %r14,%rdi,%rax
  1e5533:	mov    %eax,%ebp
  1e5535:	and    $0xf,%bpl
  1e5539:	lea    0x6b0(%rsp),%r12
  1e5541:	lea    0x218(%rsp),%rbx
  1e5549:	je     1e5513 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2363>
  1e554b:	and    $0xf,%eax
  1e554e:	cmp    $0xf,%eax
  1e5551:	jne    1e5730 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2580>
  1e5557:	cmp    0xc0(%rsp),%r13
  1e555f:	jae    1ebe1e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8c6e>
  1e5565:	cmp    0xd8(%rsp),%r13
  1e556d:	mov    0x28(%rsp),%rdx
  1e5572:	mov    0xf0(%rsp),%rsi
  1e557a:	vbroadcastsd -0x1bf40b(%rip),%ymm9        # 26178 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x3a8>
  1e5583:	lea    0x9a8(%rsp),%rdi
  1e558b:	vbroadcastsd -0x1bf55c(%rip),%ymm12        # 26038 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x268>
  1e5594:	jae    1ebe39 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8c89>
  1e559a:	cmp    %rsi,%r13
  1e559d:	jae    1ebe8a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8cda>
  1e55a3:	cmp    0x100(%rsp),%r13
  1e55ab:	vmovupd 0x380(%rsp),%ymm11
  1e55b4:	mov    0xe8(%rsp),%rsi
  1e55bc:	vxorpd %xmm13,%xmm13,%xmm13
  1e55c1:	vxorpd %xmm14,%xmm14,%xmm14
  1e55c6:	jae    1ebe9d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8ced>
  1e55cc:	cmp    0xc8(%rsp),%r13
  1e55d4:	jae    1ebe54 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8ca4>
  1e55da:	cmp    0xf8(%rsp),%r13
  1e55e2:	jae    1ebe6f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8cbf>
  1e55e8:	cmp    0xb0(%rsp),%r13
  1e55f0:	jae    1ebe03 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8c53>
  1e55f6:	cmp    0x88(%rsp),%r13
  1e55fe:	jae    1ebeb8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8d08>
  1e5604:	lea    0x3(%r14),%r15
  1e5608:	cmp    0x200(%rsp),%r15
  1e5610:	jae    1e9903 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6753>
  1e5616:	cmp    0x60(%rsp),%r13
  1e561b:	jae    1ebed3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8d23>
  1e5621:	mov    %r13,%rax
  1e5624:	shl    $0x5,%rax
  1e5628:	mov    0x68(%rsp),%rcx
  1e562d:	vmovupd (%rcx,%rax,1),%ymm1
  1e5632:	vmovupd (%rdx,%rax,1),%ymm2
  1e5637:	mov    0x50(%rsp),%rcx
  1e563c:	vmovupd (%rcx,%rax,1),%ymm5
  1e5641:	mov    0x20(%rsp),%rcx
  1e5646:	vmovupd (%rcx,%rax,1),%ymm3
  1e564b:	mov    0x48(%rsp),%rcx
  1e5650:	vmovupd (%rcx,%rax,1),%ymm6
  1e5655:	mov    0x40(%rsp),%rcx
  1e565a:	vmovupd (%rcx,%rax,1),%ymm7
  1e565f:	mov    0x110(%rsp),%rcx
  1e5667:	vmovupd (%rcx,%rax,1),%ymm8
  1e566c:	mov    0x58(%rsp),%rcx
  1e5671:	vmulpd (%rcx,%rax,1),%ymm8,%ymm4
  1e5676:	mov    0x70(%rsp),%rcx
  1e567b:	vmovupd (%rcx,%rax,1),%ymm10
  1e5680:	vmovupd %ymm4,0x928(%rsp)
  1e5689:	vmulpd %ymm2,%ymm8,%ymm0
  1e568d:	vmovupd %ymm0,0x120(%rsp)
  1e5696:	vmovupd %ymm0,0x948(%rsp)
  1e569f:	vmulpd %ymm3,%ymm8,%ymm3
  1e56a3:	vmulpd %ymm7,%ymm8,%ymm2
  1e56a7:	vmovupd %ymm3,0x190(%rsp)
  1e56b0:	vmovupd %ymm3,0xa28(%rsp)
  1e56b9:	vmovupd %ymm2,0x1b0(%rsp)
  1e56c2:	vmovupd %ymm2,0xa48(%rsp)
  1e56cb:	vmulpd %ymm1,%ymm8,%ymm0
  1e56cf:	vmovupd %ymm0,0x140(%rsp)
  1e56d8:	vmovupd %ymm0,0x968(%rsp)
  1e56e1:	vmulpd %ymm5,%ymm8,%ymm2
  1e56e5:	vmovupd %ymm2,0x988(%rsp)
  1e56ee:	vmulpd %ymm6,%ymm8,%ymm5
  1e56f2:	vmulpd %ymm8,%ymm10,%ymm1
  1e56f7:	vmovupd %ymm5,0x280(%rsp)
  1e5700:	vmovupd %ymm5,0xa68(%rsp)
  1e5709:	vmovupd %ymm1,0x1e0(%rsp)
  1e5712:	vmovupd %ymm1,0xa88(%rsp)
  1e571b:	vcmpeqpd %ymm13,%ymm13,%ymm1
  1e5721:	lea    0x928(%rsp),%rcx
  1e5729:	xor    %eax,%eax
  1e572b:	jmp    1e577f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x25cf>
  1e572d:	nopl   (%rax)
  1e5730:	movzbl %bpl,%r15d
  1e5734:	xor    %esi,%esi
  1e5736:	tzcnt  %r15d,%esi
  1e573b:	lea    -0x1(%r15),%ebp
  1e573f:	add    %r14,%rsi
  1e5742:	mov    %r12,%rdi
  1e5745:	mov    %rbx,%rdx
  1e5748:	vzeroupper
  1e574b:	call   1f7760 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e5750:	and    %r15b,%bpl
  1e5753:	jne    1e5730 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2580>
  1e5755:	jmp    1e5513 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2363>
  1e575a:	nopw   0x0(%rax,%rax,1)
  1e5760:	lea    0x20(%rcx),%rdx
  1e5764:	vandpd (%rcx),%ymm11,%ymm5
  1e5768:	vcmpge_oqpd %ymm9,%ymm5,%ymm6
  1e576e:	vcmple_oqpd %ymm12,%ymm5,%ymm5
  1e5774:	vandpd %ymm5,%ymm6,%ymm5
  1e5778:	vandpd %ymm1,%ymm5,%ymm1
  1e577c:	mov    %rdx,%rcx
  1e577f:	test   %rcx,%rcx
  1e5782:	je     1e5789 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x25d9>
  1e5784:	cmp    %rdi,%rcx
  1e5787:	jne    1e5760 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x25b0>
  1e5789:	cmp    $0x80,%rax
  1e578f:	je     1e57b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2600>
  1e5791:	lea    (%rsp,%rax,1),%rcx
  1e5795:	add    $0xa28,%rcx
  1e579c:	add    $0x20,%rax
  1e57a0:	xor    %edx,%edx
  1e57a2:	jmp    1e5764 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x25b4>
  1e57a4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e57b0:	vpcmpgtq %ymm1,%ymm13,%ymm1
  1e57b5:	vpbroadcastq -0x1bf516(%rip),%ymm11        # 262a8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x4d8>
  1e57be:	vpand  %ymm1,%ymm11,%ymm1
  1e57c2:	vextracti128 $0x1,%ymm1,%xmm5
  1e57c8:	vminpd %xmm5,%xmm1,%xmm1
  1e57cc:	vshufpd $0x1,%xmm1,%xmm1,%xmm5
  1e57d1:	vminsd %xmm5,%xmm1,%xmm1
  1e57d5:	vucomisd %xmm14,%xmm1
  1e57da:	jbe    1e54c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2310>
  1e57e0:	vmovupd (%rsi,%r14,8),%ymm3
  1e57e6:	vpbroadcastq -0x1bf0af(%rip),%ymm10        # 26740 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x970>
  1e57ef:	vpbroadcastq -0x1bf3c0(%rip),%ymm1        # 26438 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x668>
  1e57f8:	vpbroadcastq -0x1bee61(%rip),%ymm13        # 269a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0xbd0>
  1e5801:	vxorpd %xmm0,%xmm0,%xmm0
  1e5805:	vmovupd 0x120(%rsp),%ymm7
  1e580e:	vcmpeqpd %ymm0,%ymm7,%ymm9
  1e5813:	vandnpd %ymm3,%ymm9,%ymm5
  1e5817:	vpaddq %ymm5,%ymm10,%ymm6
  1e581b:	vpbroadcastq -0x1bf434(%rip),%ymm15        # 263f0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x620>
  1e5824:	vpxor  %ymm6,%ymm15,%ymm6
  1e5828:	vpbroadcastq -0x1bf861(%rip),%ymm8        # 25fd0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x200>
  1e5831:	vmovupd %ymm9,0x310(%rsp)
  1e583a:	vblendvpd %ymm9,%ymm11,%ymm7,%ymm7
  1e5840:	vpcmpgtq %ymm6,%ymm8,%ymm6
  1e5845:	vmovupd %ymm7,0x260(%rsp)
  1e584e:	vpsrlq $0x34,%ymm7,%ymm7
  1e5853:	vpand  %ymm1,%ymm7,%ymm7
  1e5857:	vpaddq %ymm5,%ymm7,%ymm5
  1e585b:	vmovdqu %ymm5,0x2a0(%rsp)
  1e5864:	vpaddq %ymm5,%ymm13,%ymm5
  1e5868:	vpxor  %ymm5,%ymm15,%ymm7
  1e586c:	vpbroadcastq -0x1bf1d5(%rip),%ymm5        # 266a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x8d0>
  1e5875:	vpcmpgtq %ymm7,%ymm5,%ymm7
  1e587a:	vpor   %ymm7,%ymm6,%ymm6
  1e587e:	vmovupd 0x140(%rsp),%ymm14
  1e5887:	vcmpeqpd %ymm0,%ymm14,%ymm12
  1e588c:	vandnpd %ymm3,%ymm12,%ymm7
  1e5890:	vpaddq %ymm7,%ymm10,%ymm9
  1e5894:	vpxor  %ymm15,%ymm9,%ymm9
  1e5899:	vpcmpgtq %ymm9,%ymm8,%ymm9
  1e589e:	vmovupd %ymm12,0x430(%rsp)
  1e58a7:	vblendvpd %ymm12,%ymm11,%ymm14,%ymm12
  1e58ad:	vmovupd %ymm12,0x3a0(%rsp)
  1e58b6:	vpsrlq $0x34,%ymm12,%ymm12
  1e58bc:	vpand  %ymm1,%ymm12,%ymm12
  1e58c0:	vpaddq %ymm7,%ymm12,%ymm7
  1e58c4:	vmovdqu %ymm7,0x4d0(%rsp)
  1e58cd:	vpaddq %ymm7,%ymm13,%ymm7
  1e58d1:	vpxor  %ymm7,%ymm15,%ymm7
  1e58d5:	vpcmpgtq %ymm7,%ymm5,%ymm7
  1e58da:	vpor   %ymm7,%ymm9,%ymm9
  1e58de:	vcmpeqpd %ymm0,%ymm2,%ymm7
  1e58e3:	vblendvpd %ymm7,%ymm11,%ymm2,%ymm12
  1e58e9:	vmovupd %ymm12,0x560(%rsp)
  1e58f2:	vpsrlq $0x34,%ymm12,%ymm12
  1e58f8:	vpand  %ymm1,%ymm12,%ymm12
  1e58fc:	vmovupd %ymm7,0x3f0(%rsp)
  1e5905:	vandnpd %ymm3,%ymm7,%ymm7
  1e5909:	vpaddq %ymm7,%ymm12,%ymm12
  1e590d:	vpaddq %ymm7,%ymm10,%ymm7
  1e5911:	vpxor  %ymm7,%ymm15,%ymm7
  1e5915:	vpcmpgtq %ymm7,%ymm8,%ymm7
  1e591a:	vmovdqu %ymm12,0x520(%rsp)
  1e5923:	vpaddq %ymm13,%ymm12,%ymm12
  1e5928:	vpxor  %ymm15,%ymm12,%ymm12
  1e592d:	vpcmpgtq %ymm12,%ymm5,%ymm12
  1e5932:	vpor   %ymm7,%ymm12,%ymm7
  1e5936:	vpor   %ymm7,%ymm9,%ymm7
  1e593a:	vpor   %ymm6,%ymm7,%ymm7
  1e593e:	vcmpeqpd %ymm0,%ymm4,%ymm6
  1e5943:	vblendvpd %ymm6,%ymm11,%ymm4,%ymm0
  1e5949:	vmovupd %ymm0,0x540(%rsp)
  1e5952:	vpsrlq $0x34,%ymm0,%ymm9
  1e5957:	vpand  %ymm1,%ymm9,%ymm9
  1e595b:	vandnpd %ymm3,%ymm6,%ymm12
  1e595f:	vpaddq %ymm12,%ymm9,%ymm0
  1e5964:	vpaddq %ymm10,%ymm12,%ymm9
  1e5969:	vpxor  %ymm15,%ymm9,%ymm9
  1e596e:	vpcmpgtq %ymm9,%ymm8,%ymm9
  1e5973:	vmovdqu %ymm0,0x4f0(%rsp)
  1e597c:	vpaddq %ymm0,%ymm13,%ymm12
  1e5980:	vpxor  %ymm15,%ymm12,%ymm12
  1e5985:	vpcmpgtq %ymm12,%ymm5,%ymm12
  1e598a:	vpor   %ymm12,%ymm9,%ymm9
  1e598f:	vpsllq $0x3f,%ymm7,%ymm7
  1e5994:	vpor   %ymm7,%ymm9,%ymm7
  1e5998:	vtestpd %ymm7,%ymm7
  1e599d:	jne    1e54c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2310>
  1e59a3:	vmovupd 0x1b0(%rsp),%ymm12
  1e59ac:	vxorpd %xmm14,%xmm14,%xmm14
  1e59b1:	vcmpeqpd %ymm14,%ymm12,%ymm0
  1e59b7:	vandnpd %ymm3,%ymm0,%ymm7
  1e59bb:	vpaddq %ymm7,%ymm10,%ymm9
  1e59bf:	vpxor  %ymm15,%ymm9,%ymm9
  1e59c4:	vpcmpgtq %ymm9,%ymm8,%ymm9
  1e59c9:	vmovupd %ymm0,0x5e0(%rsp)
  1e59d2:	vblendvpd %ymm0,%ymm11,%ymm12,%ymm0
  1e59d8:	vmovupd %ymm0,0x720(%rsp)
  1e59e1:	vpsrlq $0x34,%ymm0,%ymm12
  1e59e6:	vpand  %ymm1,%ymm12,%ymm12
  1e59ea:	vpaddq %ymm7,%ymm12,%ymm0
  1e59ee:	vmovdqu %ymm0,0x700(%rsp)
  1e59f7:	vpaddq %ymm0,%ymm13,%ymm7
  1e59fb:	vpxor  %ymm7,%ymm15,%ymm7
  1e59ff:	vpcmpgtq %ymm7,%ymm5,%ymm7
  1e5a04:	vpor   %ymm7,%ymm9,%ymm0
  1e5a08:	vmovdqu %ymm0,0x600(%rsp)
  1e5a11:	vmovupd 0x280(%rsp),%ymm7
  1e5a1a:	vcmpeqpd %ymm7,%ymm14,%ymm0
  1e5a1f:	vblendvpd %ymm0,%ymm11,%ymm7,%ymm9
  1e5a25:	vmovupd %ymm0,0x690(%rsp)
  1e5a2e:	vandnpd %ymm3,%ymm0,%ymm7
  1e5a32:	vmovupd %ymm9,0x900(%rsp)
  1e5a3b:	vpsrlq $0x34,%ymm9,%ymm9
  1e5a41:	vpand  %ymm1,%ymm9,%ymm9
  1e5a45:	vpaddq %ymm7,%ymm9,%ymm0
  1e5a49:	vpaddq %ymm7,%ymm10,%ymm7
  1e5a4d:	vpxor  %ymm7,%ymm15,%ymm7
  1e5a51:	vpcmpgtq %ymm7,%ymm8,%ymm7
  1e5a56:	vmovdqu %ymm0,0x8e0(%rsp)
  1e5a5f:	vpaddq %ymm0,%ymm13,%ymm9
  1e5a63:	vpxor  %ymm15,%ymm9,%ymm9
  1e5a68:	vpcmpgtq %ymm9,%ymm5,%ymm9
  1e5a6d:	vpor   %ymm7,%ymm9,%ymm7
  1e5a71:	vmovupd 0x190(%rsp),%ymm9
  1e5a7a:	vcmpeqpd %ymm14,%ymm9,%ymm0
  1e5a80:	vblendvpd %ymm0,%ymm11,%ymm9,%ymm9
  1e5a86:	vmovupd %ymm9,0x8a0(%rsp)
  1e5a8f:	vpsrlq $0x34,%ymm9,%ymm9
  1e5a95:	vpand  %ymm1,%ymm9,%ymm9
  1e5a99:	vmovupd 0x1e0(%rsp),%ymm12
  1e5aa2:	vcmpeqpd %ymm14,%ymm12,%ymm14
  1e5aa8:	vmovupd %ymm4,0x880(%rsp)
  1e5ab1:	vblendvpd %ymm14,%ymm11,%ymm12,%ymm4
  1e5ab7:	vpsrlq $0x34,%ymm4,%ymm11
  1e5abc:	vpand  %ymm1,%ymm11,%ymm1
  1e5ac0:	vmovupd %ymm0,0x8c0(%rsp)
  1e5ac9:	vandnpd %ymm3,%ymm0,%ymm12
  1e5acd:	vpaddq %ymm12,%ymm9,%ymm11
  1e5ad2:	vpaddq %ymm10,%ymm12,%ymm9
  1e5ad7:	vandnpd %ymm3,%ymm14,%ymm12
  1e5adb:	vpaddq %ymm10,%ymm12,%ymm10
  1e5ae0:	vpaddq %ymm1,%ymm12,%ymm1
  1e5ae4:	vpxor  %ymm15,%ymm10,%ymm10
  1e5ae9:	vpcmpgtq %ymm10,%ymm8,%ymm10
  1e5aee:	vpaddq %ymm1,%ymm13,%ymm12
  1e5af2:	vpxor  %ymm15,%ymm12,%ymm12
  1e5af7:	vpcmpgtq %ymm12,%ymm5,%ymm12
  1e5afc:	vpor   %ymm12,%ymm10,%ymm10
  1e5b01:	vpor   %ymm7,%ymm10,%ymm7
  1e5b05:	vpor   0x600(%rsp),%ymm7,%ymm7
  1e5b0e:	vpaddq %ymm13,%ymm11,%ymm10
  1e5b13:	vpxor  %ymm15,%ymm10,%ymm10
  1e5b18:	vpcmpgtq %ymm10,%ymm5,%ymm5
  1e5b1d:	vpxor  %ymm15,%ymm9,%ymm9
  1e5b22:	vpcmpgtq %ymm9,%ymm8,%ymm8
  1e5b27:	vpor   %ymm5,%ymm8,%ymm5
  1e5b2b:	vpsllq $0x3f,%ymm7,%ymm7
  1e5b30:	vpor   %ymm5,%ymm7,%ymm5
  1e5b34:	vtestpd %ymm5,%ymm5
  1e5b39:	jne    1e54c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2310>
  1e5b3f:	vmovdqa %ymm4,%ymm10
  1e5b43:	vmovdqu 0x520(%rsp),%ymm4
  1e5b4c:	vpsllq $0x34,%ymm4,%ymm7
  1e5b51:	vpbroadcastq -0x1bf792(%rip),%ymm5        # 263c8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x5f8>
  1e5b5a:	vpand  0x560(%rsp),%ymm5,%ymm8
  1e5b63:	vpor   %ymm7,%ymm8,%ymm7
  1e5b67:	vmovupd 0x3f0(%rsp),%ymm4
  1e5b70:	vblendvpd %ymm4,%ymm2,%ymm7,%ymm2
  1e5b76:	vmovdqu 0x4d0(%rsp),%ymm4
  1e5b7f:	vpsllq $0x34,%ymm4,%ymm7
  1e5b84:	vpand  0x3a0(%rsp),%ymm5,%ymm8
  1e5b8d:	vpor   %ymm7,%ymm8,%ymm7
  1e5b91:	vmovupd 0x430(%rsp),%ymm4
  1e5b9a:	vblendvpd %ymm4,0x140(%rsp),%ymm7,%ymm3
  1e5ba5:	vmovdqu 0x2a0(%rsp),%ymm4
  1e5bae:	vpsllq $0x34,%ymm4,%ymm7
  1e5bb3:	vpand  0x260(%rsp),%ymm5,%ymm8
  1e5bbc:	vpor   %ymm7,%ymm8,%ymm7
  1e5bc0:	vmovupd 0x310(%rsp),%ymm4
  1e5bc9:	vblendvpd %ymm4,0x120(%rsp),%ymm7,%ymm4
  1e5bd4:	vmovdqu 0x4f0(%rsp),%ymm7
  1e5bdd:	vpsllq $0x34,%ymm7,%ymm7
  1e5be2:	vpand  0x540(%rsp),%ymm5,%ymm8
  1e5beb:	vpor   %ymm7,%ymm8,%ymm7
  1e5bef:	vblendvpd %ymm6,0x880(%rsp),%ymm7,%ymm0
  1e5bfa:	vpsllq $0x34,%ymm11,%ymm6
  1e5c00:	vpand  0x8a0(%rsp),%ymm5,%ymm7
  1e5c09:	vpor   %ymm7,%ymm6,%ymm6
  1e5c0d:	vmovupd 0x8c0(%rsp),%ymm7
  1e5c16:	vblendvpd %ymm7,0x190(%rsp),%ymm6,%ymm8
  1e5c21:	vmovdqu 0x700(%rsp),%ymm6
  1e5c2a:	vpsllq $0x34,%ymm6,%ymm6
  1e5c2f:	vpand  0x720(%rsp),%ymm5,%ymm7
  1e5c38:	vpor   %ymm7,%ymm6,%ymm6
  1e5c3c:	vmovupd 0x5e0(%rsp),%ymm7
  1e5c45:	vblendvpd %ymm7,0x1b0(%rsp),%ymm6,%ymm7
  1e5c50:	vmovdqu 0x8e0(%rsp),%ymm6
  1e5c59:	vpsllq $0x34,%ymm6,%ymm6
  1e5c5e:	vpand  0x900(%rsp),%ymm5,%ymm9
  1e5c67:	vpor   %ymm6,%ymm9,%ymm6
  1e5c6b:	vmovupd 0x690(%rsp),%ymm9
  1e5c74:	vblendvpd %ymm9,0x280(%rsp),%ymm6,%ymm6
  1e5c7f:	vpand  %ymm5,%ymm10,%ymm5
  1e5c83:	vpsllq $0x34,%ymm1,%ymm1
  1e5c88:	vpor   %ymm5,%ymm1,%ymm1
  1e5c8c:	vblendvpd %ymm14,0x1e0(%rsp),%ymm1,%ymm5
  1e5c97:	lea    0x7a0(%rsp),%rsi
  1e5c9f:	vxorpd %xmm1,%xmm1,%xmm1
  1e5ca3:	vmovupd %ymm1,(%rsi)
  1e5ca7:	vmovupd %ymm1,0x820(%rsp)
  1e5cb0:	vmovupd %ymm1,0x800(%rsp)
  1e5cb9:	vmovupd %ymm1,0x7e0(%rsp)
  1e5cc2:	vmovupd %ymm1,0x7c0(%rsp)
  1e5ccb:	vmovupd %ymm1,0x740(%rsp)
  1e5cd4:	vmovupd %ymm1,0x760(%rsp)
  1e5cdd:	vmovupd %ymm1,0x780(%rsp)
  1e5ce6:	mov    0x117e13(%rip),%rdi        # 2fdb00 <_DYNAMIC+0xa78>
  1e5ced:	mov    0x808(%rdi),%rdx
  1e5cf4:	lea    0x7c0(%rsp),%rax
  1e5cfc:	lea    0x2(%rip),%rcx        # 1e5d05 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2b55>
  1e5d03:	jmp    *%rdx
  1e5d05:	mov    0x808(%rdi),%rdx
  1e5d0c:	lea    0x740(%rsp),%rax
  1e5d14:	vmovapd %ymm8,%ymm0
  1e5d18:	lea    0x2(%rip),%rcx        # 1e5d21 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2b71>
  1e5d1f:	jmp    *%rdx
  1e5d21:	mov    0x808(%rdi),%rdx
  1e5d28:	lea    0x7e0(%rsp),%rax
  1e5d30:	vmovapd %ymm4,%ymm0
  1e5d34:	lea    0x2(%rip),%rcx        # 1e5d3d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2b8d>
  1e5d3b:	jmp    *%rdx
  1e5d3d:	mov    0x808(%rdi),%rdx
  1e5d44:	lea    0x760(%rsp),%rax
  1e5d4c:	vmovapd %ymm7,%ymm0
  1e5d50:	lea    0x2(%rip),%rcx        # 1e5d59 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2ba9>
  1e5d57:	jmp    *%rdx
  1e5d59:	mov    0x808(%rdi),%rdx
  1e5d60:	lea    0x800(%rsp),%rax
  1e5d68:	vmovapd %ymm3,%ymm0
  1e5d6c:	lea    0x2(%rip),%rcx        # 1e5d75 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2bc5>
  1e5d73:	jmp    *%rdx
  1e5d75:	mov    0x808(%rdi),%rdx
  1e5d7c:	lea    0x780(%rsp),%rax
  1e5d84:	vmovapd %ymm6,%ymm0
  1e5d88:	lea    0x2(%rip),%rcx        # 1e5d91 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2be1>
  1e5d8f:	jmp    *%rdx
  1e5d91:	mov    0x808(%rdi),%rdx
  1e5d98:	lea    0x820(%rsp),%rax
  1e5da0:	vmovapd %ymm2,%ymm0
  1e5da4:	lea    0x2(%rip),%rcx        # 1e5dad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2bfd>
  1e5dab:	jmp    *%rdx
  1e5dad:	mov    0x808(%rdi),%rdx
  1e5db4:	mov    %rsi,%rax
  1e5db7:	vmovapd %ymm5,%ymm0
  1e5dbb:	lea    0x2(%rip),%rcx        # 1e5dc4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2c14>
  1e5dc2:	jmp    *%rdx
  1e5dc4:	vmovupd 0x7c0(%rsp),%ymm0
  1e5dcd:	vmovupd 0x7e0(%rsp),%ymm1
  1e5dd6:	vinsertf128 $0x1,0x760(%rsp),%ymm1,%ymm1
  1e5de1:	vinsertf128 $0x1,0x740(%rsp),%ymm0,%ymm0
  1e5dec:	vunpcklpd %ymm1,%ymm0,%ymm2
  1e5df0:	vaddpd 0x218(%rsp),%ymm2,%ymm2
  1e5df9:	vunpckhpd %ymm1,%ymm0,%ymm0
  1e5dfd:	vaddpd %ymm0,%ymm2,%ymm0
  1e5e01:	vmovapd 0x7f0(%rsp),%xmm1
  1e5e0a:	vmovapd 0x7d0(%rsp),%xmm2
  1e5e13:	vunpcklpd %xmm1,%xmm2,%xmm3
  1e5e17:	vmovupd 0x740(%rsp),%ymm4
  1e5e20:	vmovupd 0x760(%rsp),%ymm5
  1e5e29:	vunpcklpd %ymm5,%ymm4,%ymm6
  1e5e2d:	vblendpd $0xc,%ymm6,%ymm3,%ymm3
  1e5e33:	vmovupd 0x780(%rsp),%ymm6
  1e5e3c:	vaddpd %ymm3,%ymm0,%ymm0
  1e5e40:	vunpckhpd %xmm1,%xmm2,%xmm1
  1e5e44:	vunpckhpd %ymm5,%ymm4,%ymm2
  1e5e48:	vblendpd $0xc,%ymm2,%ymm1,%ymm1
  1e5e4e:	vaddpd %ymm1,%ymm0,%ymm0
  1e5e52:	vmovupd %ymm0,0x218(%rsp)
  1e5e5b:	vmovupd 0x7a0(%rsp),%ymm0
  1e5e64:	vmovupd 0x820(%rsp),%ymm1
  1e5e6d:	vinsertf128 $0x1,0x7a0(%rsp),%ymm1,%ymm1
  1e5e78:	vmovupd 0x800(%rsp),%ymm2
  1e5e81:	vinsertf128 $0x1,0x780(%rsp),%ymm2,%ymm2
  1e5e8c:	vunpcklpd %ymm1,%ymm2,%ymm3
  1e5e90:	vaddpd 0x238(%rsp),%ymm3,%ymm3
  1e5e99:	vunpckhpd %ymm1,%ymm2,%ymm1
  1e5e9d:	vaddpd %ymm1,%ymm3,%ymm1
  1e5ea1:	vmovapd 0x830(%rsp),%xmm2
  1e5eaa:	vmovapd 0x810(%rsp),%xmm3
  1e5eb3:	vunpcklpd %xmm2,%xmm3,%xmm4
  1e5eb7:	vunpcklpd %ymm0,%ymm6,%ymm5
  1e5ebb:	vblendpd $0xc,%ymm5,%ymm4,%ymm4
  1e5ec1:	vaddpd %ymm4,%ymm1,%ymm1
  1e5ec5:	vunpckhpd %xmm2,%xmm3,%xmm2
  1e5ec9:	vunpckhpd %ymm0,%ymm6,%ymm0
  1e5ecd:	vblendpd $0xc,%ymm0,%ymm2,%ymm0
  1e5ed3:	vaddpd %ymm0,%ymm1,%ymm0
  1e5ed7:	vmovupd %ymm0,0x238(%rsp)
  1e5ee0:	jmp    1e5513 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2363>
  1e5ee5:	mov    0x90(%rsp),%rax
  1e5eed:	mov    0x110(%rsp),%rcx
  1e5ef5:	lea    (%rcx,%rax,8),%rax
  1e5ef9:	mov    %rax,0x280(%rsp)
  1e5f01:	vmovsd 0x218(%rsp),%xmm0
  1e5f0a:	vmovsd %xmm0,0x18(%rsp)
  1e5f10:	vmovsd 0x220(%rsp),%xmm0
  1e5f19:	vmovsd %xmm0,0x120(%rsp)
  1e5f22:	vmovsd 0x228(%rsp),%xmm0
  1e5f2b:	vmovsd %xmm0,0x1e0(%rsp)
  1e5f34:	cmpq   $0x0,0x2c0(%rsp)
  1e5f3d:	je     1e655b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x33ab>
  1e5f43:	vmovsd 0x230(%rsp),%xmm0
  1e5f4c:	vmovsd %xmm0,0x190(%rsp)
  1e5f55:	vmovsd 0x238(%rsp),%xmm0
  1e5f5e:	vmovsd %xmm0,0x140(%rsp)
  1e5f67:	vmovsd 0x248(%rsp),%xmm11
  1e5f70:	mov    0x458(%rsp),%rax
  1e5f78:	mov    %rax,0x430(%rsp)
  1e5f80:	mov    0x468(%rsp),%rax
  1e5f88:	mov    %rax,0x560(%rsp)
  1e5f90:	mov    0x478(%rsp),%rax
  1e5f98:	mov    %rax,0x3a0(%rsp)
  1e5fa0:	mov    0x488(%rsp),%rax
  1e5fa8:	mov    %rax,0x540(%rsp)
  1e5fb0:	mov    0x498(%rsp),%rax
  1e5fb8:	mov    %rax,0x4d0(%rsp)
  1e5fc0:	mov    0x4a8(%rsp),%rax
  1e5fc8:	mov    %rax,0x4f0(%rsp)
  1e5fd0:	mov    0x4b8(%rsp),%rax
  1e5fd8:	mov    %rax,0x3f0(%rsp)
  1e5fe0:	vmovsd 0x240(%rsp),%xmm0
  1e5fe9:	vmovsd %xmm0,0x1b0(%rsp)
  1e5ff2:	vmovsd 0x250(%rsp),%xmm4
  1e5ffb:	mov    0x4c0(%rsp),%rcx
  1e6003:	mov    0x848(%rsp),%rax
  1e600b:	add    %rax,%rcx
  1e600e:	mov    %rcx,0x700(%rsp)
  1e6016:	mov    0x4a0(%rsp),%rcx
  1e601e:	add    %rax,%rcx
  1e6021:	mov    %rcx,0x690(%rsp)
  1e6029:	mov    0x480(%rsp),%rcx
  1e6031:	add    %rax,%rcx
  1e6034:	mov    %rcx,0x720(%rsp)
  1e603c:	mov    0x460(%rsp),%rcx
  1e6044:	add    %rax,%rcx
  1e6047:	mov    %rcx,0x600(%rsp)
  1e604f:	mov    0x4b0(%rsp),%rcx
  1e6057:	add    %rax,%rcx
  1e605a:	mov    %rcx,0x520(%rsp)
  1e6062:	mov    0x490(%rsp),%r12
  1e606a:	add    %rax,%r12
  1e606d:	mov    0x470(%rsp),%r15
  1e6075:	add    %rax,%r15
  1e6078:	mov    0x450(%rsp),%rbx
  1e6080:	add    %rax,%rbx
  1e6083:	mov    0x4c8(%rsp),%rax
  1e608b:	mov    %rax,0x5e0(%rsp)
  1e6093:	xor    %ebp,%ebp
  1e6095:	mov    0x10(%rsp),%rsi
  1e609a:	vmovupd 0x380(%rsp),%ymm12
  1e60a3:	mov    0x160(%rsp),%rcx
  1e60ab:	vpxor  %xmm13,%xmm13,%xmm13
  1e60b0:	vxorpd %xmm14,%xmm14,%xmm14
  1e60b5:	vbroadcastsd -0x1bfd1e(%rip),%ymm15        # 263a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x5d0>
  1e60be:	xchg   %ax,%ax
  1e60c0:	cmp    %rbp,%rcx
  1e60c3:	je     1ebb7a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x89ca>
  1e60c9:	mov    0xb8(%rsp),%rax
  1e60d1:	mov    (%rax,%rbp,8),%r13
  1e60d5:	test   %r13,%r13
  1e60d8:	je     1e6350 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x31a0>
  1e60de:	mov    0x620(%rsp),%rax
  1e60e6:	lea    (%rax,%rbp,1),%r14
  1e60ea:	cmp    0x430(%rsp),%r14
  1e60f2:	jae    1ebbf3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8a43>
  1e60f8:	vmovsd %xmm4,0x310(%rsp)
  1e6101:	vmovsd %xmm11,0x260(%rsp)
  1e610a:	cmp    0x3a0(%rsp),%r14
  1e6112:	jae    1ebc1e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8a6e>
  1e6118:	vmovsd (%rbx,%rbp,8),%xmm0
  1e611d:	vmovsd (%r15,%rbp,8),%xmm1
  1e6123:	mov    0x280(%rsp),%rax
  1e612b:	vmovsd (%rax,%rbp,8),%xmm2
  1e6130:	vmovsd %xmm2,0x2a0(%rsp)
  1e6139:	mov    %r13,%rdi
  1e613c:	vzeroupper
  1e613f:	call   *0x1179ab(%rip)        # 2fdaf0 <_DYNAMIC+0xa68>
  1e6145:	vmovsd 0x18(%rsp),%xmm2
  1e614b:	vaddsd %xmm2,%xmm0,%xmm2
  1e614f:	vmovsd %xmm2,0x218(%rsp)
  1e6158:	vmovsd 0x120(%rsp),%xmm0
  1e6161:	vaddsd %xmm0,%xmm1,%xmm0
  1e6165:	vmovsd %xmm0,0x220(%rsp)
  1e616e:	cmp    0x4d0(%rsp),%r14
  1e6176:	jae    1ebc49 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8a99>
  1e617c:	vmovsd %xmm0,0x120(%rsp)
  1e6185:	vmovsd %xmm2,0x18(%rsp)
  1e618b:	cmp    0x3f0(%rsp),%r14
  1e6193:	jae    1ebc71 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8ac1>
  1e6199:	vmovsd (%r12,%rbp,8),%xmm0
  1e619f:	mov    0x520(%rsp),%rax
  1e61a7:	vmovsd (%rax,%rbp,8),%xmm1
  1e61ac:	vmovsd 0x2a0(%rsp),%xmm2
  1e61b5:	mov    %r13,%rdi
  1e61b8:	call   *0x117932(%rip)        # 2fdaf0 <_DYNAMIC+0xa68>
  1e61be:	vmovsd 0x1e0(%rsp),%xmm2
  1e61c7:	vaddsd %xmm2,%xmm0,%xmm2
  1e61cb:	vmovsd %xmm2,0x228(%rsp)
  1e61d4:	vmovsd 0x190(%rsp),%xmm0
  1e61dd:	vaddsd %xmm0,%xmm1,%xmm0
  1e61e1:	vmovsd %xmm0,0x230(%rsp)
  1e61ea:	cmp    0x560(%rsp),%r14
  1e61f2:	jae    1ebbe3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8a33>
  1e61f8:	vmovsd %xmm0,0x190(%rsp)
  1e6201:	vmovsd %xmm2,0x1e0(%rsp)
  1e620a:	cmp    0x540(%rsp),%r14
  1e6212:	jae    1ebc0e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8a5e>
  1e6218:	mov    0x600(%rsp),%rax
  1e6220:	vmovsd (%rax,%rbp,8),%xmm0
  1e6225:	mov    0x720(%rsp),%rax
  1e622d:	vmovsd (%rax,%rbp,8),%xmm1
  1e6232:	mov    0x280(%rsp),%rax
  1e623a:	vmovsd (%rax,%rbp,8),%xmm2
  1e623f:	vmovsd %xmm2,0x2a0(%rsp)
  1e6248:	mov    %r13,%rdi
  1e624b:	call   *0x11789f(%rip)        # 2fdaf0 <_DYNAMIC+0xa68>
  1e6251:	vmovsd 0x140(%rsp),%xmm2
  1e625a:	vaddsd %xmm2,%xmm0,%xmm2
  1e625e:	vmovsd %xmm2,0x238(%rsp)
  1e6267:	vmovsd 0x1b0(%rsp),%xmm0
  1e6270:	vaddsd %xmm0,%xmm1,%xmm0
  1e6274:	vmovsd %xmm0,0x240(%rsp)
  1e627d:	cmp    0x4f0(%rsp),%r14
  1e6285:	jae    1ebc39 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8a89>
  1e628b:	vmovsd %xmm0,0x1b0(%rsp)
  1e6294:	vmovsd %xmm2,0x140(%rsp)
  1e629d:	cmp    0x5e0(%rsp),%r14
  1e62a5:	jae    1ebc61 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8ab1>
  1e62ab:	mov    0x690(%rsp),%rax
  1e62b3:	vmovsd (%rax,%rbp,8),%xmm0
  1e62b8:	mov    0x700(%rsp),%rax
  1e62c0:	vmovsd (%rax,%rbp,8),%xmm1
  1e62c5:	vmovsd 0x2a0(%rsp),%xmm2
  1e62ce:	mov    %r13,%rdi
  1e62d1:	call   *0x117819(%rip)        # 2fdaf0 <_DYNAMIC+0xa68>
  1e62d7:	vmovsd 0x260(%rsp),%xmm11
  1e62e0:	vaddsd %xmm0,%xmm11,%xmm11
  1e62e4:	vmovsd %xmm11,0x248(%rsp)
  1e62ed:	vmovsd 0x310(%rsp),%xmm4
  1e62f6:	vaddsd %xmm4,%xmm1,%xmm4
  1e62fa:	mov    0x10(%rsp),%rsi
  1e62ff:	vmovupd 0x380(%rsp),%ymm12
  1e6308:	mov    0x160(%rsp),%rcx
  1e6310:	vpxor  %xmm13,%xmm13,%xmm13
  1e6315:	vxorpd %xmm14,%xmm14,%xmm14
  1e631a:	vbroadcastsd -0x1bff83(%rip),%ymm15        # 263a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x5d0>
  1e6323:	inc    %rbp
  1e6326:	vmovsd %xmm4,0x250(%rsp)
  1e632f:	cmp    %rbp,0x2c0(%rsp)
  1e6337:	jne    1e60c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2f10>
  1e633d:	jmp    1e65c4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3414>
  1e6342:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e6350:	mov    0x280(%rsp),%rax
  1e6358:	vmovsd (%rax,%rbp,8),%xmm0
  1e635d:	vucomisd %xmm14,%xmm0
  1e6362:	jne    1e6366 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x31b6>
  1e6364:	jnp    1e63ac <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x31fc>
  1e6366:	vandpd -0x1c0cee(%rip),%xmm0,%xmm1        # 25680 <__abi_tag+0x25384>
  1e636e:	vmovq  %xmm0,%rax
  1e6373:	shr    $0x34,%rax
  1e6377:	and    $0x7ff,%eax
  1e637c:	cmp    $0x7ff,%eax
  1e6381:	setb   %al
  1e6384:	vucomisd -0x1bffec(%rip),%xmm1        # 263a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x5d0>
  1e638c:	jb     1e60de <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2f2e>
  1e6392:	test   %al,%al
  1e6394:	je     1e60de <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2f2e>
  1e639a:	vmovsd -0x1c007a(%rip),%xmm2        # 26328 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x558>
  1e63a2:	vucomisd %xmm1,%xmm2
  1e63a6:	jb     1e60de <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2f2e>
  1e63ac:	mov    0x620(%rsp),%rax
  1e63b4:	lea    (%rax,%rbp,1),%rdi
  1e63b8:	cmp    0x430(%rsp),%rdi
  1e63c0:	jae    1ebf23 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8d73>
  1e63c6:	vmulsd (%rbx,%rbp,8),%xmm0,%xmm1
  1e63cb:	vmovsd 0x18(%rsp),%xmm2
  1e63d1:	vaddsd %xmm1,%xmm2,%xmm2
  1e63d5:	vmovsd %xmm2,0x18(%rsp)
  1e63db:	vmovsd %xmm2,0x218(%rsp)
  1e63e4:	cmp    0x3a0(%rsp),%rdi
  1e63ec:	jae    1ebf4b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8d9b>
  1e63f2:	vmulsd (%r15,%rbp,8),%xmm0,%xmm1
  1e63f8:	vmovsd 0x120(%rsp),%xmm2
  1e6401:	vaddsd %xmm1,%xmm2,%xmm2
  1e6405:	vmovsd %xmm2,0x120(%rsp)
  1e640e:	vmovsd %xmm2,0x220(%rsp)
  1e6417:	cmp    0x4d0(%rsp),%rdi
  1e641f:	jae    1ebf73 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8dc3>
  1e6425:	vmulsd (%r12,%rbp,8),%xmm0,%xmm1
  1e642b:	vmovsd 0x1e0(%rsp),%xmm2
  1e6434:	vaddsd %xmm1,%xmm2,%xmm2
  1e6438:	vmovsd %xmm2,0x1e0(%rsp)
  1e6441:	vmovsd %xmm2,0x228(%rsp)
  1e644a:	cmp    0x3f0(%rsp),%rdi
  1e6452:	jae    1ebefb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8d4b>
  1e6458:	mov    0x520(%rsp),%rax
  1e6460:	vmulsd (%rax,%rbp,8),%xmm0,%xmm1
  1e6465:	vmovsd 0x190(%rsp),%xmm2
  1e646e:	vaddsd %xmm1,%xmm2,%xmm2
  1e6472:	vmovsd %xmm2,0x190(%rsp)
  1e647b:	vmovsd %xmm2,0x230(%rsp)
  1e6484:	cmp    0x560(%rsp),%rdi
  1e648c:	jae    1ebf13 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8d63>
  1e6492:	mov    0x600(%rsp),%rax
  1e649a:	vmulsd (%rax,%rbp,8),%xmm0,%xmm1
  1e649f:	vmovsd 0x140(%rsp),%xmm2
  1e64a8:	vaddsd %xmm1,%xmm2,%xmm2
  1e64ac:	vmovsd %xmm2,0x140(%rsp)
  1e64b5:	vmovsd %xmm2,0x238(%rsp)
  1e64be:	cmp    0x540(%rsp),%rdi
  1e64c6:	jae    1ebf3b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8d8b>
  1e64cc:	mov    0x720(%rsp),%rax
  1e64d4:	vmulsd (%rax,%rbp,8),%xmm0,%xmm1
  1e64d9:	vmovsd 0x1b0(%rsp),%xmm2
  1e64e2:	vaddsd %xmm1,%xmm2,%xmm2
  1e64e6:	vmovsd %xmm2,0x1b0(%rsp)
  1e64ef:	vmovsd %xmm2,0x240(%rsp)
  1e64f8:	cmp    0x4f0(%rsp),%rdi
  1e6500:	jae    1ebf63 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8db3>
  1e6506:	mov    0x690(%rsp),%rax
  1e650e:	vmulsd (%rax,%rbp,8),%xmm0,%xmm1
  1e6513:	vaddsd %xmm1,%xmm11,%xmm11
  1e6517:	vmovsd %xmm11,0x248(%rsp)
  1e6520:	cmp    0x5e0(%rsp),%rdi
  1e6528:	jae    1ebeeb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8d3b>
  1e652e:	mov    0x700(%rsp),%rax
  1e6536:	vmulsd (%rax,%rbp,8),%xmm0,%xmm0
  1e653b:	vaddsd %xmm0,%xmm4,%xmm4
  1e653f:	inc    %rbp
  1e6542:	vmovsd %xmm4,0x250(%rsp)
  1e654b:	cmp    %rbp,0x2c0(%rsp)
  1e6553:	jne    1e60c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x2f10>
  1e6559:	jmp    1e65c4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3414>
  1e655b:	vmovsd 0x230(%rsp),%xmm0
  1e6564:	vmovsd %xmm0,0x190(%rsp)
  1e656d:	vmovsd 0x238(%rsp),%xmm0
  1e6576:	vmovsd %xmm0,0x140(%rsp)
  1e657f:	vmovsd 0x240(%rsp),%xmm0
  1e6588:	vmovsd %xmm0,0x1b0(%rsp)
  1e6591:	vmovsd 0x248(%rsp),%xmm11
  1e659a:	vmovsd 0x250(%rsp),%xmm4
  1e65a3:	mov    0x10(%rsp),%rsi
  1e65a8:	vmovupd 0x380(%rsp),%ymm12
  1e65b1:	vpxor  %xmm13,%xmm13,%xmm13
  1e65b6:	vxorpd %xmm14,%xmm14,%xmm14
  1e65bb:	vbroadcastsd -0x1c0224(%rip),%ymm15        # 263a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x5d0>
  1e65c4:	mov    0x60(%rsp),%rdi
  1e65c9:	test   %rdi,%rdi
  1e65cc:	mov    0xe8(%rsp),%r9
  1e65d4:	vmovsd %xmm11,0x260(%rsp)
  1e65dd:	vmovsd %xmm4,0x310(%rsp)
  1e65e6:	je     1e6a15 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3865>
  1e65ec:	vbroadcastsd 0x5d0(%rsp),%ymm0
  1e65f6:	vbroadcastsd 0x5c0(%rsp),%ymm1
  1e6600:	mov    $0x1,%bpl
  1e6603:	xor    %eax,%eax
  1e6605:	mov    0x510(%rsp),%r8
  1e660d:	mov    0x110(%rsp),%r10
  1e6615:	mov    0x518(%rsp),%r11
  1e661d:	cmp    %r8,%rax
  1e6620:	je     1ec165 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8fb5>
  1e6626:	cmp    %rdi,%rax
  1e6629:	je     1ec152 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8fa2>
  1e662f:	cmp    %r11,%rax
  1e6632:	je     1ec13c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8f8c>
  1e6638:	mov    %rax,%rcx
  1e663b:	shl    $0x5,%rcx
  1e663f:	vmovupd (%r10,%rcx,1),%ymm4
  1e6645:	mov    0x360(%rsp),%rdx
  1e664d:	vmovupd (%rdx,%rcx,1),%ymm2
  1e6652:	vfmadd213pd %ymm1,%ymm0,%ymm2
  1e6657:	mov    0x98(%rsp),%rdx
  1e665f:	vfmadd213pd (%rdx,%rcx,1),%ymm4,%ymm2
  1e6665:	vandpd %ymm4,%ymm12,%ymm6
  1e6669:	vandpd %ymm2,%ymm12,%ymm7
  1e666d:	vbroadcastsd -0x1c063e(%rip),%ymm5        # 26038 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x268>
  1e6676:	vcmple_oqpd %ymm5,%ymm6,%ymm3
  1e667b:	vcmple_oqpd %ymm5,%ymm7,%ymm5
  1e6680:	vandpd %ymm3,%ymm5,%ymm3
  1e6684:	vpcmpgtq %ymm3,%ymm13,%ymm3
  1e6689:	vpbroadcastq -0x1c03ea(%rip),%ymm5        # 262a8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x4d8>
  1e6692:	vpand  %ymm5,%ymm3,%ymm3
  1e6696:	vextracti128 $0x1,%ymm3,%xmm8
  1e669c:	vminpd %xmm8,%xmm3,%xmm3
  1e66a1:	vshufpd $0x1,%xmm3,%xmm3,%xmm8
  1e66a6:	vminsd %xmm8,%xmm3,%xmm3
  1e66ab:	vucomisd %xmm14,%xmm3
  1e66b0:	jbe    1e6d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bad>
  1e66b6:	vmovdqu (%r9,%rcx,1),%ymm3
  1e66bc:	vmaxpd %ymm7,%ymm6,%ymm6
  1e66c0:	vbroadcastsd -0x1c03a1(%rip),%ymm10        # 26328 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x558>
  1e66c9:	vcmple_oqpd %ymm10,%ymm6,%ymm8
  1e66cf:	vcmpeqpd %ymm6,%ymm13,%ymm7
  1e66d4:	vcmpge_oqpd %ymm15,%ymm6,%ymm9
  1e66da:	vorpd  %ymm7,%ymm9,%ymm9
  1e66de:	vandpd %ymm8,%ymm9,%ymm8
  1e66e3:	vpcmpgtq %ymm8,%ymm13,%ymm8
  1e66e8:	vpand  %ymm5,%ymm8,%ymm8
  1e66ec:	vextracti128 $0x1,%ymm8,%xmm9
  1e66f2:	vminpd %xmm9,%xmm8,%xmm8
  1e66f7:	vshufpd $0x1,%xmm8,%xmm8,%xmm9
  1e66fd:	vminsd %xmm9,%xmm8,%xmm8
  1e6702:	vucomisd %xmm14,%xmm8
  1e6707:	jbe    1e6737 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3587>
  1e6709:	vpcmpeqq %ymm13,%ymm3,%ymm4
  1e670e:	vpand  %ymm5,%ymm4,%ymm4
  1e6712:	vextracti128 $0x1,%ymm4,%xmm5
  1e6718:	vminpd %xmm5,%xmm4,%xmm4
  1e671c:	vshufpd $0x1,%xmm4,%xmm4,%xmm5
  1e6721:	vminsd %xmm5,%xmm4,%xmm4
  1e6725:	vucomisd %xmm14,%xmm4
  1e672a:	ja     1e69f2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3842>
  1e6730:	xor    %ebp,%ebp
  1e6732:	jmp    1e69f2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3842>
  1e6737:	vcmpgt_oqpd %ymm10,%ymm6,%ymm8
  1e673d:	vpcmpgtq %ymm8,%ymm13,%ymm9
  1e6742:	vpand  %ymm5,%ymm9,%ymm10
  1e6746:	vextracti128 $0x1,%ymm10,%xmm11
  1e674c:	vmaxpd %xmm11,%xmm10,%xmm10
  1e6751:	vshufpd $0x1,%xmm10,%xmm10,%xmm11
  1e6757:	vmaxsd %xmm11,%xmm10,%xmm10
  1e675c:	vucomisd %xmm14,%xmm10
  1e6761:	jbe    1e684b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x369b>
  1e6767:	vextracti128 $0x1,%ymm9,%xmm6
  1e676d:	vpackssdw %xmm6,%xmm9,%xmm7
  1e6771:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e6780:	vpbroadcastq -0x1bff69(%rip),%ymm6        # 26820 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0xa50>
  1e6789:	vpcmpgtq %ymm6,%ymm3,%ymm6
  1e678e:	vpcmpgtq %ymm8,%ymm13,%ymm8
  1e6793:	vpand  %ymm5,%ymm8,%ymm8
  1e6797:	vpand  %ymm6,%ymm8,%ymm6
  1e679b:	vextracti128 $0x1,%ymm6,%xmm8
  1e67a1:	vmaxpd %xmm8,%xmm6,%xmm6
  1e67a6:	vshufpd $0x1,%xmm6,%xmm6,%xmm8
  1e67ab:	vmaxsd %xmm8,%xmm6,%xmm6
  1e67b0:	vucomisd %xmm14,%xmm6
  1e67b5:	ja     1e6d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bad>
  1e67bb:	vbroadcastsd -0x1c015c(%rip),%ymm8        # 26668 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x898>
  1e67c4:	vmulpd %ymm4,%ymm8,%ymm6
  1e67c8:	vpslld $0x1f,%xmm7,%xmm7
  1e67cd:	vpsrad $0x1f,%xmm7,%xmm7
  1e67d2:	vpmovsxdq %xmm7,%ymm7
  1e67d7:	vblendvpd %ymm7,%ymm6,%ymm4,%ymm4
  1e67dd:	vmulpd %ymm2,%ymm8,%ymm6
  1e67e1:	vblendvpd %ymm7,%ymm6,%ymm2,%ymm2
  1e67e7:	vpbroadcastq -0x1c0670(%rip),%ymm6        # 26180 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x3b0>
  1e67f0:	vpand  %ymm6,%ymm7,%ymm6
  1e67f4:	vpaddq %ymm6,%ymm3,%ymm3
  1e67f8:	vandpd %ymm4,%ymm12,%ymm6
  1e67fc:	vandpd %ymm2,%ymm12,%ymm7
  1e6800:	vmaxpd %ymm7,%ymm6,%ymm6
  1e6804:	vbroadcastsd -0x1c04e5(%rip),%ymm7        # 26328 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x558>
  1e680d:	vcmpgt_oqpd %ymm7,%ymm6,%ymm8
  1e6812:	vpcmpgtq %ymm8,%ymm13,%ymm9
  1e6817:	vextracti128 $0x1,%ymm9,%xmm7
  1e681d:	vpackssdw %xmm7,%xmm9,%xmm7
  1e6821:	vpand  %ymm5,%ymm9,%ymm9
  1e6825:	vextracti128 $0x1,%ymm9,%xmm10
  1e682b:	vmaxpd %xmm10,%xmm9,%xmm9
  1e6830:	vshufpd $0x1,%xmm9,%xmm9,%xmm10
  1e6836:	vmaxsd %xmm10,%xmm9,%xmm9
  1e683b:	vucomisd %xmm14,%xmm9
  1e6840:	ja     1e6780 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x35d0>
  1e6846:	vcmpeqpd %ymm6,%ymm13,%ymm7
  1e684b:	vcmplt_oqpd %ymm15,%ymm6,%ymm8
  1e6851:	vandnpd %ymm8,%ymm7,%ymm8
  1e6856:	vpcmpgtq %ymm8,%ymm13,%ymm9
  1e685b:	vpand  %ymm5,%ymm9,%ymm10
  1e685f:	vextracti128 $0x1,%ymm10,%xmm11
  1e6865:	vmaxpd %xmm11,%xmm10,%xmm10
  1e686a:	vshufpd $0x1,%xmm10,%xmm10,%xmm11
  1e6870:	vmaxsd %xmm11,%xmm10,%xmm10
  1e6875:	vucomisd %xmm14,%xmm10
  1e687a:	jbe    1e6959 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x37a9>
  1e6880:	vextracti128 $0x1,%ymm9,%xmm6
  1e6886:	vpackssdw %xmm6,%xmm9,%xmm9
  1e688a:	nopw   0x0(%rax,%rax,1)
  1e6890:	vpbroadcastq -0x1c00e1(%rip),%ymm6        # 267b8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x9e8>
  1e6899:	vpcmpgtq %ymm6,%ymm3,%ymm6
  1e689e:	vpcmpgtq %ymm8,%ymm13,%ymm7
  1e68a3:	vpandn %ymm7,%ymm6,%ymm6
  1e68a7:	vpand  %ymm5,%ymm6,%ymm6
  1e68ab:	vextracti128 $0x1,%ymm6,%xmm7
  1e68b1:	vmaxpd %xmm7,%xmm6,%xmm6
  1e68b5:	vshufpd $0x1,%xmm6,%xmm6,%xmm7
  1e68ba:	vmaxsd %xmm7,%xmm6,%xmm6
  1e68be:	vucomisd %xmm14,%xmm6
  1e68c3:	ja     1e6d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bad>
  1e68c9:	vpbroadcastq -0x1c001a(%rip),%ymm6        # 268b8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0xae8>
  1e68d2:	vbroadcastsd -0x1c00e3(%rip),%ymm10        # 267f8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0xa28>
  1e68db:	vmulpd %ymm4,%ymm10,%ymm7
  1e68df:	vpslld $0x1f,%xmm9,%xmm8
  1e68e5:	vpsrad $0x1f,%xmm8,%xmm8
  1e68eb:	vpmovsxdq %xmm8,%ymm8
  1e68f0:	vblendvpd %ymm8,%ymm7,%ymm4,%ymm4
  1e68f6:	vmulpd %ymm2,%ymm10,%ymm7
  1e68fa:	vblendvpd %ymm8,%ymm7,%ymm2,%ymm2
  1e6900:	vpand  %ymm6,%ymm8,%ymm6
  1e6904:	vpaddq %ymm6,%ymm3,%ymm3
  1e6908:	vandpd %ymm4,%ymm12,%ymm6
  1e690c:	vandpd %ymm2,%ymm12,%ymm7
  1e6910:	vmaxpd %ymm7,%ymm6,%ymm6
  1e6914:	vcmpeqpd %ymm6,%ymm13,%ymm7
  1e6919:	vcmplt_oqpd %ymm15,%ymm6,%ymm8
  1e691f:	vandnpd %ymm8,%ymm7,%ymm8
  1e6924:	vpcmpgtq %ymm8,%ymm13,%ymm10
  1e6929:	vextracti128 $0x1,%ymm10,%xmm9
  1e692f:	vpackssdw %xmm9,%xmm10,%xmm9
  1e6934:	vpand  %ymm5,%ymm10,%ymm10
  1e6938:	vextracti128 $0x1,%ymm10,%xmm11
  1e693e:	vmaxpd %xmm11,%xmm10,%xmm10
  1e6943:	vshufpd $0x1,%xmm10,%xmm10,%xmm11
  1e6949:	vmaxsd %xmm11,%xmm10,%xmm10
  1e694e:	vucomisd %xmm14,%xmm10
  1e6953:	ja     1e6890 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x36e0>
  1e6959:	lea    (%r10,%rcx,1),%rdx
  1e695d:	vpcmpeqq %ymm13,%ymm3,%ymm8
  1e6962:	vpand  %ymm5,%ymm8,%ymm8
  1e6966:	vextracti128 $0x1,%ymm8,%xmm9
  1e696c:	vminpd %xmm9,%xmm8,%xmm8
  1e6971:	vshufpd $0x1,%xmm8,%xmm8,%xmm9
  1e6977:	vminsd %xmm9,%xmm8,%xmm8
  1e697c:	vucomisd %xmm14,%xmm8
  1e6981:	jbe    1e69e3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3833>
  1e6983:	vcmpge_oqpd %ymm15,%ymm6,%ymm8
  1e6989:	vorpd  %ymm7,%ymm8,%ymm7
  1e698d:	vbroadcastsd -0x1c066e(%rip),%ymm8        # 26328 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x558>
  1e6996:	vcmple_oqpd %ymm8,%ymm6,%ymm6
  1e699c:	vandpd %ymm6,%ymm7,%ymm6
  1e69a0:	vpcmpgtq %ymm6,%ymm13,%ymm6
  1e69a5:	vpand  %ymm5,%ymm6,%ymm5
  1e69a9:	vextracti128 $0x1,%ymm5,%xmm6
  1e69af:	vminpd %xmm6,%xmm5,%xmm5
  1e69b3:	vshufpd $0x1,%xmm5,%xmm5,%xmm6
  1e69b8:	vminsd %xmm6,%xmm5,%xmm6
  1e69bc:	vblendpd $0x1,%xmm6,%xmm5,%xmm5
  1e69c2:	vucomisd %xmm14,%xmm5
  1e69c7:	vmovupd %ymm4,(%rdx)
  1e69cb:	vmovsd 0x260(%rsp),%xmm11
  1e69d4:	vmovsd 0x310(%rsp),%xmm4
  1e69dd:	ja     1e69fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x384b>
  1e69df:	xor    %ebp,%ebp
  1e69e1:	jmp    1e69fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x384b>
  1e69e3:	vmovupd %ymm4,(%rdx)
  1e69e7:	xor    %ebp,%ebp
  1e69e9:	vmovsd 0x260(%rsp),%xmm11
  1e69f2:	vmovsd 0x310(%rsp),%xmm4
  1e69fb:	inc    %rax
  1e69fe:	vmovupd %ymm2,(%rsi,%rcx,1)
  1e6a03:	add    %r9,%rcx
  1e6a06:	vmovdqu %ymm3,(%rcx)
  1e6a0a:	cmp    %rdi,%rax
  1e6a0d:	jne    1e661d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x346d>
  1e6a13:	jmp    1e6a18 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3868>
  1e6a15:	mov    $0x1,%bpl
  1e6a18:	cmpq   $0x0,0x2c0(%rsp)
  1e6a21:	je     1e6b85 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x39d5>
  1e6a27:	mov    0x90(%rsp),%rax
  1e6a2f:	mov    0x98(%rsp),%rcx
  1e6a37:	lea    (%rcx,%rax,8),%rbx
  1e6a3b:	lea    (%rsi,%rax,8),%r15
  1e6a3f:	mov    $0x1,%r14d
  1e6a45:	xor    %r13d,%r13d
  1e6a48:	nopl   0x0(%rax,%rax,1)
  1e6a50:	cmp    %r13,0x870(%rsp)
  1e6a58:	mov    0x258(%rsp),%rax
  1e6a60:	je     1ec106 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8f56>
  1e6a66:	cmp    %r13,0x358(%rsp)
  1e6a6e:	je     1ec121 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8f71>
  1e6a74:	mov    0x280(%rsp),%rcx
  1e6a7c:	lea    (%rcx,%r13,1),%rsi
  1e6a80:	vmovq  (%rsi),%xmm1
  1e6a84:	vmovq  %xmm1,%rdx
  1e6a89:	vmovsd (%rax,%r13,1),%xmm0
  1e6a8f:	vmovapd 0x5c0(%rsp),%xmm2
  1e6a98:	vfmadd132sd 0x5d0(%rsp),%xmm2,%xmm0
  1e6aa2:	vfmadd213sd (%rbx,%r13,1),%xmm1,%xmm0
  1e6aa8:	vmovq  %xmm0,%rax
  1e6aad:	shr    $0x34,%rdx
  1e6ab1:	and    $0x7ff,%edx
  1e6ab7:	shr    $0x34,%rax
  1e6abb:	and    $0x7ff,%eax
  1e6ac0:	cmp    $0x7ff,%eax
  1e6ac5:	setb   %cl
  1e6ac8:	xor    %eax,%eax
  1e6aca:	cmp    $0x7fe,%edx
  1e6ad0:	ja     1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e6ad6:	test   %cl,%cl
  1e6ad8:	je     1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e6ade:	vmovsd %xmm0,(%r15,%r13,1)
  1e6ae4:	cmp    %r13,0x868(%rsp)
  1e6aec:	je     1e9b31 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6981>
  1e6af2:	lea    (%r15,%r13,1),%rcx
  1e6af6:	mov    0xb8(%rsp),%rax
  1e6afe:	lea    (%rax,%r13,1),%r9
  1e6b02:	movq   $0x1,(%rsp)
  1e6b0a:	mov    $0x1,%edx
  1e6b0f:	mov    $0x1,%r8d
  1e6b15:	lea    0x740(%rsp),%rdi
  1e6b1d:	vzeroupper
  1e6b20:	call   *0x116c9a(%rip)        # 2fd7c0 <_DYNAMIC+0x738>
  1e6b26:	cmpl   $0xffffffff,0x740(%rsp)
  1e6b2e:	jne    1e6d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bad>
  1e6b34:	and    0x748(%rsp),%bpl
  1e6b3c:	add    $0x8,%r13
  1e6b40:	inc    %r14
  1e6b43:	cmp    %r13,0x358(%rsp)
  1e6b4b:	vmovupd 0x380(%rsp),%ymm12
  1e6b54:	vxorpd %xmm13,%xmm13,%xmm13
  1e6b59:	vbroadcastsd -0x1c083a(%rip),%ymm14        # 26328 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x558>
  1e6b62:	vbroadcastsd -0x1c07cb(%rip),%ymm15        # 263a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x5d0>
  1e6b6b:	vmovsd 0x260(%rsp),%xmm11
  1e6b74:	vmovsd 0x310(%rsp),%xmm4
  1e6b7d:	jne    1e6a50 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x38a0>
  1e6b83:	jmp    1e6b8e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x39de>
  1e6b85:	vbroadcastsd -0x1c0866(%rip),%ymm14        # 26328 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x558>
  1e6b8e:	mov    0x3e8(%rsp),%rdi
  1e6b96:	cmp    0x30(%rsp),%rdi
  1e6b9b:	jae    1ec5af <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x93ff>
  1e6ba1:	mov    %rdi,%rax
  1e6ba4:	shl    $0x4,%rax
  1e6ba8:	mov    0x78(%rsp),%rcx
  1e6bad:	vmovsd 0x18(%rsp),%xmm0
  1e6bb3:	vmovsd %xmm0,(%rcx,%rax,1)
  1e6bb8:	vmovsd 0x120(%rsp),%xmm0
  1e6bc1:	vmovsd %xmm0,0x8(%rcx,%rax,1)
  1e6bc7:	mov    0x38(%rsp),%rsi
  1e6bcc:	cmp    %rsi,%rdi
  1e6bcf:	mov    0x68(%rsp),%r8
  1e6bd4:	mov    0x50(%rsp),%r9
  1e6bd9:	mov    0x48(%rsp),%r10
  1e6bde:	mov    0x70(%rsp),%r11
  1e6be3:	mov    0x58(%rsp),%r14
  1e6be8:	mov    0x2f0(%rsp),%r13
  1e6bf0:	mov    0x118(%rsp),%rdx
  1e6bf8:	mov    0xd0(%rsp),%rbx
  1e6c00:	jae    1ec5c4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9414>
  1e6c06:	mov    0x80(%rsp),%rcx
  1e6c0e:	vmovsd 0x140(%rsp),%xmm0
  1e6c17:	vmovsd %xmm0,(%rcx,%rax,1)
  1e6c1c:	vmovsd 0x1b0(%rsp),%xmm0
  1e6c25:	vmovsd %xmm0,0x8(%rcx,%rax,1)
  1e6c2b:	mov    0x840(%rsp),%rax
  1e6c33:	cmp    0xe0(%rsp),%rax
  1e6c3b:	jae    1e6c90 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3ae0>
  1e6c3d:	inc    %rdi
  1e6c40:	cmp    0x30(%rsp),%rdi
  1e6c45:	jae    1ec5d4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9424>
  1e6c4b:	mov    %rdi,%rax
  1e6c4e:	shl    $0x4,%rax
  1e6c52:	mov    0x78(%rsp),%rcx
  1e6c57:	vmovsd 0x1e0(%rsp),%xmm0
  1e6c60:	vmovsd %xmm0,(%rcx,%rax,1)
  1e6c65:	vmovsd 0x190(%rsp),%xmm0
  1e6c6e:	vmovsd %xmm0,0x8(%rcx,%rax,1)
  1e6c74:	cmp    %rsi,%rdi
  1e6c77:	jae    1ec5e9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9439>
  1e6c7d:	mov    0x80(%rsp),%rcx
  1e6c85:	vmovsd %xmm11,(%rcx,%rax,1)
  1e6c8a:	vmovsd %xmm4,0x8(%rcx,%rax,1)
  1e6c90:	lea    0x1(%rbx),%rdi
  1e6c94:	test   $0x1,%bpl
  1e6c98:	jne    1e9922 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6772>
  1e6c9e:	lea    (%rbx,%rbx,1),%r15
  1e6ca2:	mov    0x188(%rsp),%rax
  1e6caa:	lea    (%rax,%rbx,2),%r12
  1e6cae:	mov    %rbx,%rcx
  1e6cb1:	mov    0x210(%rsp),%rax
  1e6cb9:	mov    %rax,0x140(%rsp)
  1e6cc1:	mov    0x98(%rsp),%rbp
  1e6cc9:	mov    %r13,0x1b0(%rsp)
  1e6cd1:	mov    0x110(%rsp),%rax
  1e6cd9:	mov    %rax,0x98(%rsp)
  1e6ce1:	mov    %rdi,%rsi
  1e6ce4:	cmp    %rdx,%rdi
  1e6ce7:	jne    1e5037 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x1e87>
  1e6ced:	mov    %r15,0x3e8(%rsp)
  1e6cf5:	mov    0x2f0(%rsp),%rax
  1e6cfd:	mov    %rax,0x1b0(%rsp)
  1e6d05:	mov    0x20(%rsp),%r15
  1e6d0a:	mov    0x410(%rsp),%rsi
  1e6d12:	mov    0x5a0(%rsp),%rdi
  1e6d1a:	mov    0x580(%rsp),%r12
  1e6d22:	jmp    1e37f6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x646>
  1e6d27:	mov    0xa8(%rsp),%rax
  1e6d2f:	test   %rax,%rax
  1e6d32:	mov    0xa0(%rsp),%rcx
  1e6d3a:	je     1ec3bb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x920b>
  1e6d40:	test   %rcx,%rcx
  1e6d43:	je     1ec3d2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9222>
  1e6d49:	cmp    $0x1,%rax
  1e6d4d:	je     1ec3e9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9239>
  1e6d53:	cmp    $0x1,%rcx
  1e6d57:	je     1ec40a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x925a>
  1e6d5d:	xor    %eax,%eax
  1e6d5f:	jmp    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e6d64:	shl    $0x4,%rdi
  1e6d68:	mov    0x80(%rsp),%rax
  1e6d70:	vmovsd %xmm1,(%rax,%rdi,1)
  1e6d75:	vmovsd %xmm0,0x8(%rax,%rdi,1)
  1e6d7b:	and    0x18(%rsp),%dl
  1e6d7f:	mov    %dl,0x190(%rsp)
  1e6d86:	add    $0x2,%r8
  1e6d8a:	mov    %r15,%rcx
  1e6d8d:	mov    %r12,%rax
  1e6d90:	mov    0x1e0(%rsp),%rdi
  1e6d98:	mov    %rdi,%rdx
  1e6d9b:	mov    %rbx,%rsi
  1e6d9e:	cmp    0x118(%rsp),%r8
  1e6da6:	jae    1e98e9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6739>
  1e6dac:	mov    %rax,0x1e0(%rsp)
  1e6db4:	mov    %rcx,%rax
  1e6db7:	mov    0xa8(%rsp),%rcx
  1e6dbf:	cmp    %rcx,%r8
  1e6dc2:	jae    1ec190 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8fe0>
  1e6dc8:	mov    %rax,0x10(%rsp)
  1e6dcd:	mov    0xa0(%rsp),%rax
  1e6dd5:	cmp    %rax,%r8
  1e6dd8:	jae    1ec1ab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8ffb>
  1e6dde:	mov    %rsi,%r12
  1e6de1:	mov    %r9,%rsi
  1e6de4:	lea    0x1(%r8),%r9
  1e6de8:	cmp    %rcx,%r9
  1e6deb:	mov    0x4d0(%rsp),%r10
  1e6df3:	jae    1ec3ef <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x923f>
  1e6df9:	cmp    %rax,%r9
  1e6dfc:	mov    0x160(%rsp),%r11
  1e6e04:	jae    1ec410 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9260>
  1e6e0a:	xor    %eax,%eax
  1e6e0c:	cmp    %rdx,0x1e0(%rsp)
  1e6e14:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e6e1a:	cmp    %rdx,%rbx
  1e6e1d:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e6e23:	mov    0x1e0(%rsp),%rcx
  1e6e2b:	mov    %rcx,%rax
  1e6e2e:	shr    $0x2,%rax
  1e6e32:	cmp    %r10,%rax
  1e6e35:	jne    1e6d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bad>
  1e6e3b:	mov    %ecx,%edx
  1e6e3d:	and    $0x3,%edx
  1e6e40:	xor    %eax,%eax
  1e6e42:	cmp    0x60(%rsp),%edx
  1e6e46:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e6e4c:	mov    %r12,%rdx
  1e6e4f:	shr    $0x2,%rdx
  1e6e53:	cmp    0x310(%rsp),%rdx
  1e6e5b:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e6e61:	mov    %r12d,%edx
  1e6e64:	and    $0x3,%edx
  1e6e67:	cmp    0xb8(%rsp),%edx
  1e6e6e:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e6e74:	mov    %rbp,%r15
  1e6e77:	mov    %rsi,%rbp
  1e6e7a:	mov    0x670(%rsp),%rax
  1e6e82:	vmovsd (%rax,%r8,8),%xmm0
  1e6e88:	mov    0x650(%rsp),%rcx
  1e6e90:	mov    %r8,0x120(%rsp)
  1e6e98:	vmovsd (%rcx,%r8,8),%xmm3
  1e6e9e:	vmovsd (%rax,%r9,8),%xmm1
  1e6ea4:	vmovsd (%rcx,%r9,8),%xmm2
  1e6eaa:	mov    0x430(%rsp),%rax
  1e6eb2:	test   %rax,%rax
  1e6eb5:	vmovapd %xmm0,0x280(%rsp)
  1e6ebe:	vmovapd %xmm1,0x2a0(%rsp)
  1e6ec7:	vmovapd %xmm2,0x200(%rsp)
  1e6ed0:	vmovapd %xmm3,0x380(%rsp)
  1e6ed9:	je     1e6fbd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3e0d>
  1e6edf:	vbroadcastsd %xmm0,%ymm12
  1e6ee4:	vbroadcastsd %xmm3,%ymm13
  1e6ee9:	vbroadcastsd %xmm1,%ymm14
  1e6eee:	vbroadcastsd %xmm2,%ymm15
  1e6ef3:	vxorpd %xmm4,%xmm4,%xmm4
  1e6ef7:	xor    %edx,%edx
  1e6ef9:	vxorpd %xmm2,%xmm2,%xmm2
  1e6efd:	vxorpd %xmm5,%xmm5,%xmm5
  1e6f01:	vxorpd %xmm3,%xmm3,%xmm3
  1e6f05:	vxorpd %xmm7,%xmm7,%xmm7
  1e6f09:	vxorpd %xmm6,%xmm6,%xmm6
  1e6f0d:	vxorpd %xmm9,%xmm9,%xmm9
  1e6f12:	vxorpd %xmm8,%xmm8,%xmm8
  1e6f17:	mov    0x10(%rsp),%rcx
  1e6f1c:	mov    0x58(%rsp),%r14
  1e6f21:	mov    0x20(%rsp),%rsi
  1e6f26:	mov    0x40(%rsp),%r8
  1e6f2b:	mov    0x360(%rsp),%rbx
  1e6f33:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e6f40:	vmovupd 0x0(%rbp,%rdx,1),%ymm10
  1e6f46:	vmovupd (%r14,%rdx,1),%ymm11
  1e6f4c:	vfmadd231pd %ymm10,%ymm11,%ymm8
  1e6f51:	vmovupd (%rbx,%rdx,1),%ymm0
  1e6f56:	vmovapd %ymm0,%ymm1
  1e6f5a:	vfmadd213pd %ymm13,%ymm12,%ymm1
  1e6f5f:	vfmadd213pd (%rcx,%rdx,1),%ymm10,%ymm1
  1e6f65:	vfmadd231pd %ymm11,%ymm1,%ymm3
  1e6f6a:	mov    0x28(%rsp),%rdi
  1e6f6f:	vmovupd (%rdi,%rdx,1),%ymm11
  1e6f74:	vfmadd231pd %ymm10,%ymm11,%ymm9
  1e6f79:	vfmadd231pd %ymm11,%ymm1,%ymm5
  1e6f7e:	vmovupd (%rsi,%rdx,1),%ymm11
  1e6f83:	vfmadd231pd %ymm10,%ymm11,%ymm6
  1e6f88:	vfmadd231pd %ymm11,%ymm1,%ymm2
  1e6f8d:	vmovupd (%r8,%rdx,1),%ymm11
  1e6f93:	vfmadd231pd %ymm10,%ymm11,%ymm7
  1e6f98:	vfmadd231pd %ymm11,%ymm1,%ymm4
  1e6f9d:	vfmadd213pd %ymm15,%ymm14,%ymm0
  1e6fa2:	vfmadd213pd %ymm10,%ymm1,%ymm0
  1e6fa7:	vmovupd %ymm1,(%r15,%rdx,1)
  1e6fad:	vmovupd %ymm0,(%rcx,%rdx,1)
  1e6fb2:	add    $0x20,%rdx
  1e6fb6:	dec    %rax
  1e6fb9:	jne    1e6f40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3d90>
  1e6fbb:	jmp    1e6ff1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3e41>
  1e6fbd:	vxorpd %xmm8,%xmm8,%xmm8
  1e6fc2:	vxorpd %xmm9,%xmm9,%xmm9
  1e6fc7:	vxorpd %xmm6,%xmm6,%xmm6
  1e6fcb:	vxorpd %xmm7,%xmm7,%xmm7
  1e6fcf:	vxorpd %xmm3,%xmm3,%xmm3
  1e6fd3:	vxorpd %xmm5,%xmm5,%xmm5
  1e6fd7:	vxorpd %xmm2,%xmm2,%xmm2
  1e6fdb:	vxorpd %xmm4,%xmm4,%xmm4
  1e6fdf:	mov    0x10(%rsp),%rcx
  1e6fe4:	mov    0x58(%rsp),%r14
  1e6fe9:	mov    0x360(%rsp),%rbx
  1e6ff1:	mov    %r12,%r13
  1e6ff4:	movabs $0xffffffffffffffc,%rax
  1e6ffe:	and    %rax,%r13
  1e7001:	vextractf128 $0x1,%ymm8,%xmm0
  1e7007:	vaddpd %xmm0,%xmm8,%xmm0
  1e700b:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e7010:	vaddsd %xmm1,%xmm0,%xmm8
  1e7014:	vextractf128 $0x1,%ymm9,%xmm0
  1e701a:	vaddpd %xmm0,%xmm9,%xmm0
  1e701e:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e7023:	vaddsd %xmm1,%xmm0,%xmm9
  1e7027:	vextractf128 $0x1,%ymm6,%xmm0
  1e702d:	vaddpd %xmm0,%xmm6,%xmm0
  1e7031:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e7036:	vaddsd %xmm1,%xmm0,%xmm6
  1e703a:	vextractf128 $0x1,%ymm7,%xmm0
  1e7040:	vaddpd %xmm0,%xmm7,%xmm0
  1e7044:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e7049:	vaddsd %xmm1,%xmm0,%xmm7
  1e704d:	vextractf128 $0x1,%ymm3,%xmm0
  1e7053:	vaddpd %xmm0,%xmm3,%xmm0
  1e7057:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e705c:	vaddsd %xmm1,%xmm0,%xmm3
  1e7060:	vextractf128 $0x1,%ymm5,%xmm0
  1e7066:	vaddpd %xmm0,%xmm5,%xmm0
  1e706a:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e706f:	vaddsd %xmm1,%xmm0,%xmm5
  1e7073:	vextractf128 $0x1,%ymm2,%xmm0
  1e7079:	vaddpd %xmm0,%xmm2,%xmm0
  1e707d:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e7082:	vaddsd %xmm1,%xmm0,%xmm2
  1e7086:	vextractf128 $0x1,%ymm4,%xmm0
  1e708c:	vaddpd %xmm0,%xmm4,%xmm0
  1e7090:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e7095:	vaddsd %xmm1,%xmm0,%xmm4
  1e7099:	cmpq   $0x0,0x1b0(%rsp)
  1e70a2:	je     1e7382 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x41d2>
  1e70a8:	cmpq   $0x0,0x140(%rsp)
  1e70b1:	mov    0x120(%rsp),%r8
  1e70b9:	je     1e6d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bad>
  1e70bf:	mov    0x1e0(%rsp),%rax
  1e70c7:	movabs $0xffffffffffffffc,%rdx
  1e70d1:	and    %rdx,%rax
  1e70d4:	mov    0x520(%rsp),%rdx
  1e70dc:	vmovsd (%rbx,%rdx,8),%xmm12
  1e70e1:	vmovapd %xmm12,%xmm13
  1e70e6:	vmovapd 0x280(%rsp),%xmm15
  1e70ef:	vmovapd 0x380(%rsp),%xmm11
  1e70f8:	vfmadd213sd %xmm11,%xmm15,%xmm13
  1e70fd:	vmovsd 0x0(%rbp,%r11,8),%xmm14
  1e7104:	vfmadd213sd (%rcx,%rax,8),%xmm14,%xmm13
  1e710a:	vmovapd 0x2a0(%rsp),%xmm1
  1e7113:	vmovapd 0x200(%rsp),%xmm10
  1e711c:	vfmadd213sd %xmm10,%xmm1,%xmm12
  1e7121:	vfmadd213sd %xmm14,%xmm13,%xmm12
  1e7126:	mov    0x40(%rsp),%rdx
  1e712b:	mov    0x540(%rsp),%rsi
  1e7133:	vmovsd (%rdx,%rsi,8),%xmm0
  1e7138:	vfmadd231sd %xmm13,%xmm0,%xmm4
  1e713d:	vfmadd231sd %xmm0,%xmm14,%xmm7
  1e7142:	mov    0x20(%rsp),%rdx
  1e7147:	mov    0x560(%rsp),%rsi
  1e714f:	vmovsd (%rdx,%rsi,8),%xmm0
  1e7154:	vfmadd231sd %xmm13,%xmm0,%xmm2
  1e7159:	vfmadd231sd %xmm0,%xmm14,%xmm6
  1e715e:	mov    0x28(%rsp),%rdx
  1e7163:	vmovsd (%rdx,%r11,8),%xmm0
  1e7169:	vfmadd231sd %xmm13,%xmm0,%xmm5
  1e716e:	vfmadd231sd %xmm0,%xmm14,%xmm9
  1e7173:	mov    0x3f0(%rsp),%rdx
  1e717b:	vmovsd (%r14,%rdx,8),%xmm0
  1e7181:	vfmadd231sd %xmm14,%xmm0,%xmm8
  1e7186:	vfmadd231sd %xmm13,%xmm0,%xmm3
  1e718b:	mov    %r13,0x3a0(%rsp)
  1e7193:	vmovsd %xmm13,(%r15,%r13,8)
  1e7199:	vmovq  %xmm13,%rdx
  1e719e:	vmovq  %xmm12,%rsi
  1e71a3:	vmovsd %xmm12,(%rcx,%rax,8)
  1e71a8:	mov    $0x3f,%cl
  1e71aa:	bzhi   %rcx,%rdx,%rdx
  1e71af:	movabs $0x7ff0000000000000,%rdi
  1e71b9:	cmp    %rdi,%rdx
  1e71bc:	sete   %r9b
  1e71c0:	test   %rdx,%rdx
  1e71c3:	sete   %r10b
  1e71c7:	or     %r9b,%r10b
  1e71ca:	movabs $0xfff0000000000000,%r13
  1e71d4:	add    %r13,%rdx
  1e71d7:	shr    $0x35,%rdx
  1e71db:	cmp    $0x3ff,%edx
  1e71e1:	setb   %r9b
  1e71e5:	or     %r10b,%r9b
  1e71e8:	bzhi   %rcx,%rsi,%rdx
  1e71ed:	cmp    %rdi,%rdx
  1e71f0:	sete   %sil
  1e71f4:	test   %rdx,%rdx
  1e71f7:	sete   %r10b
  1e71fb:	or     %sil,%r10b
  1e71fe:	add    %r13,%rdx
  1e7201:	shr    $0x35,%rdx
  1e7205:	cmp    $0x3ff,%edx
  1e720b:	setb   %cl
  1e720e:	or     %r10b,%cl
  1e7211:	and    %r9b,%cl
  1e7214:	mov    %cl,0x18(%rsp)
  1e7218:	cmpl   $0x1,0x1b0(%rsp)
  1e7220:	je     1e7375 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x41c5>
  1e7226:	cmpl   $0x1,0x140(%rsp)
  1e722e:	je     1e6d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bad>
  1e7234:	mov    0x520(%rsp),%rcx
  1e723c:	vmovsd 0x8(%rbx,%rcx,8),%xmm12
  1e7242:	vmovapd %xmm12,%xmm13
  1e7247:	vfmadd213sd %xmm11,%xmm15,%xmm13
  1e724c:	vmovsd 0x8(%rbp,%r11,8),%xmm14
  1e7253:	mov    0x10(%rsp),%rcx
  1e7258:	vfmadd213sd 0x8(%rcx,%rax,8),%xmm14,%xmm13
  1e725f:	vfmadd213sd %xmm10,%xmm1,%xmm12
  1e7264:	vfmadd213sd %xmm14,%xmm13,%xmm12
  1e7269:	mov    0x40(%rsp),%rdx
  1e726e:	mov    0x540(%rsp),%rsi
  1e7276:	vmovsd 0x8(%rdx,%rsi,8),%xmm0
  1e727c:	vfmadd231sd %xmm13,%xmm0,%xmm4
  1e7281:	vfmadd231sd %xmm0,%xmm14,%xmm7
  1e7286:	mov    0x20(%rsp),%rdx
  1e728b:	mov    0x560(%rsp),%rsi
  1e7293:	vmovsd 0x8(%rdx,%rsi,8),%xmm0
  1e7299:	vfmadd231sd %xmm13,%xmm0,%xmm2
  1e729e:	vfmadd231sd %xmm0,%xmm14,%xmm6
  1e72a3:	mov    0x28(%rsp),%rdx
  1e72a8:	vmovsd 0x8(%rdx,%r11,8),%xmm0
  1e72af:	vfmadd231sd %xmm13,%xmm0,%xmm5
  1e72b4:	vfmadd231sd %xmm0,%xmm14,%xmm9
  1e72b9:	mov    0x3f0(%rsp),%rdx
  1e72c1:	vmovsd 0x8(%r14,%rdx,8),%xmm0
  1e72c8:	vfmadd231sd %xmm14,%xmm0,%xmm8
  1e72cd:	vfmadd231sd %xmm13,%xmm0,%xmm3
  1e72d2:	vmovq  %xmm13,%rsi
  1e72d7:	mov    0x3a0(%rsp),%rdx
  1e72df:	vmovsd %xmm13,0x8(%r15,%rdx,8)
  1e72e6:	vmovq  %xmm12,%r9
  1e72eb:	vmovsd %xmm12,0x8(%rcx,%rax,8)
  1e72f1:	mov    $0x3f,%cl
  1e72f3:	bzhi   %rcx,%rsi,%rsi
  1e72f8:	movabs $0x7ff0000000000000,%rdx
  1e7302:	cmp    %rdx,%rsi
  1e7305:	sete   %r10b
  1e7309:	test   %rsi,%rsi
  1e730c:	sete   %r11b
  1e7310:	or     %r10b,%r11b
  1e7313:	movabs $0xfff0000000000000,%rdi
  1e731d:	add    %rdi,%rsi
  1e7320:	shr    $0x35,%rsi
  1e7324:	cmp    $0x3ff,%esi
  1e732a:	setb   %sil
  1e732e:	or     %r11b,%sil
  1e7331:	bzhi   %rcx,%r9,%r9
  1e7336:	cmp    %rdx,%r9
  1e7339:	sete   %r10b
  1e733d:	test   %r9,%r9
  1e7340:	sete   %r11b
  1e7344:	or     %r10b,%r11b
  1e7347:	add    %rdi,%r9
  1e734a:	movzbl 0x18(%rsp),%ecx
  1e734f:	shr    $0x35,%r9
  1e7353:	cmp    $0x3ff,%r9d
  1e735a:	setb   %r9b
  1e735e:	or     %r11b,%r9b
  1e7361:	and    %sil,%r9b
  1e7364:	and    %r9b,%cl
  1e7367:	mov    %cl,0x18(%rsp)
  1e736b:	cmpl   $0x2,0x1b0(%rsp)
  1e7373:	jne    1e739c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x41ec>
  1e7375:	mov    0x3a0(%rsp),%r13
  1e737d:	jmp    1e74df <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x432f>
  1e7382:	movb   $0x1,0x18(%rsp)
  1e7387:	movzbl 0x190(%rsp),%edx
  1e738f:	mov    0x120(%rsp),%r8
  1e7397:	jmp    1e74e7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4337>
  1e739c:	cmpl   $0x2,0x140(%rsp)
  1e73a4:	je     1e6d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bad>
  1e73aa:	mov    0x520(%rsp),%rcx
  1e73b2:	vmovsd 0x10(%rbx,%rcx,8),%xmm0
  1e73b8:	vfmadd213sd %xmm11,%xmm0,%xmm15
  1e73bd:	mov    0x160(%rsp),%r13
  1e73c5:	vmovsd 0x10(%rbp,%r13,8),%xmm11
  1e73cc:	mov    0x10(%rsp),%rcx
  1e73d1:	vfmadd213sd 0x10(%rcx,%rax,8),%xmm11,%xmm15
  1e73d8:	vmovq  %xmm15,%rsi
  1e73dd:	mov    $0x3f,%dl
  1e73df:	bzhi   %rdx,%rsi,%rsi
  1e73e4:	movabs $0x7ff0000000000000,%rdi
  1e73ee:	cmp    %rdi,%rsi
  1e73f1:	sete   %r9b
  1e73f5:	test   %rsi,%rsi
  1e73f8:	sete   %r10b
  1e73fc:	or     %r9b,%r10b
  1e73ff:	movabs $0xfff0000000000000,%rbx
  1e7409:	add    %rbx,%rsi
  1e740c:	shr    $0x35,%rsi
  1e7410:	cmp    $0x3ff,%esi
  1e7416:	setb   %sil
  1e741a:	or     %r10b,%sil
  1e741d:	vfmadd213sd %xmm10,%xmm0,%xmm1
  1e7422:	vfmadd213sd %xmm11,%xmm15,%xmm1
  1e7427:	vmovq  %xmm1,%r9
  1e742c:	bzhi   %rdx,%r9,%r10
  1e7431:	cmp    %rdi,%r10
  1e7434:	sete   %r11b
  1e7438:	test   %r10,%r10
  1e743b:	sete   %r9b
  1e743f:	or     %r11b,%r9b
  1e7442:	add    %rbx,%r10
  1e7445:	shr    $0x35,%r10
  1e7449:	cmp    $0x3ff,%r10d
  1e7450:	mov    0x40(%rsp),%rdx
  1e7455:	mov    0x540(%rsp),%rdi
  1e745d:	vmovsd 0x10(%rdx,%rdi,8),%xmm0
  1e7463:	mov    0x20(%rsp),%rdx
  1e7468:	mov    0x560(%rsp),%rdi
  1e7470:	vmovapd %xmm1,%xmm13
  1e7474:	vmovsd 0x10(%rdx,%rdi,8),%xmm1
  1e747a:	mov    0x28(%rsp),%rdx
  1e747f:	vmovsd 0x10(%rdx,%r13,8),%xmm10
  1e7486:	mov    0x3f0(%rsp),%rdx
  1e748e:	vmovsd 0x10(%r14,%rdx,8),%xmm12
  1e7495:	mov    0x3a0(%rsp),%r13
  1e749d:	vmovsd %xmm15,0x10(%r15,%r13,8)
  1e74a4:	vmovsd %xmm13,0x10(%rcx,%rax,8)
  1e74aa:	setb   %al
  1e74ad:	or     %r9b,%al
  1e74b0:	and    %sil,%al
  1e74b3:	and    %al,0x18(%rsp)
  1e74b7:	vfmadd231sd %xmm15,%xmm0,%xmm4
  1e74bc:	vfmadd231sd %xmm15,%xmm1,%xmm2
  1e74c1:	vfmadd231sd %xmm15,%xmm10,%xmm5
  1e74c6:	vfmadd231sd %xmm15,%xmm12,%xmm3
  1e74cb:	vfmadd231sd %xmm0,%xmm11,%xmm7
  1e74d0:	vfmadd231sd %xmm1,%xmm11,%xmm6
  1e74d5:	vfmadd231sd %xmm10,%xmm11,%xmm9
  1e74da:	vfmadd231sd %xmm11,%xmm12,%xmm8
  1e74df:	movzbl 0x190(%rsp),%edx
  1e74e7:	mov    0x4f0(%rsp),%rax
  1e74ef:	lea    (%r8,%r8,1),%r9
  1e74f3:	cmp    0x30(%rsp),%r9
  1e74f8:	jae    1ec1f3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9043>
  1e74fe:	mov    %r9,%rcx
  1e7501:	shl    $0x4,%rcx
  1e7505:	mov    0x78(%rsp),%rsi
  1e750a:	vmovsd %xmm8,(%rsi,%rcx,1)
  1e750f:	mov    0x188(%rsp),%r10
  1e7517:	lea    (%r10,%r8,2),%r11
  1e751b:	vmovsd %xmm9,0x8(%rsi,%rcx,1)
  1e7521:	cmp    0xe0(%rsp),%r11
  1e7529:	jae    1e7550 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x43a0>
  1e752b:	lea    0x1(%r9),%r10
  1e752f:	cmp    0x30(%rsp),%r10
  1e7534:	jae    1ec42b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x927b>
  1e753a:	shl    $0x4,%r10
  1e753e:	mov    0x78(%rsp),%rsi
  1e7543:	vmovsd %xmm6,(%rsi,%r10,1)
  1e7549:	vmovsd %xmm7,0x8(%rsi,%r10,1)
  1e7550:	lea    0x2(%r11),%r10
  1e7554:	mov    %r10,%rdi
  1e7557:	sub    0x188(%rsp),%rdi
  1e755f:	cmp    0x30(%rsp),%rdi
  1e7564:	jae    1ec1c6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9016>
  1e756a:	mov    %rdi,0x280(%rsp)
  1e7572:	mov    %rdi,%rbx
  1e7575:	shl    $0x4,%rbx
  1e7579:	mov    0x78(%rsp),%rsi
  1e757e:	vmovsd %xmm3,(%rsi,%rbx,1)
  1e7583:	mov    %rbx,0x200(%rsp)
  1e758b:	vmovsd %xmm5,0x8(%rsi,%rbx,1)
  1e7591:	cmp    0xe0(%rsp),%r10
  1e7599:	jae    1e75d4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4424>
  1e759b:	mov    %r13,%rdi
  1e759e:	mov    %r11,%r13
  1e75a1:	mov    0x280(%rsp),%rsi
  1e75a9:	lea    0x1(%rsi),%r11
  1e75ad:	cmp    0x30(%rsp),%r11
  1e75b2:	jae    1ec443 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9293>
  1e75b8:	shl    $0x4,%r11
  1e75bc:	mov    0x78(%rsp),%rsi
  1e75c1:	vmovsd %xmm2,(%rsi,%r11,1)
  1e75c7:	vmovsd %xmm4,0x8(%rsi,%r11,1)
  1e75ce:	mov    %r13,%r11
  1e75d1:	mov    %rdi,%r13
  1e75d4:	mov    %rcx,0x2a0(%rsp)
  1e75dc:	vxorpd %xmm0,%xmm0,%xmm0
  1e75e0:	mov    0x260(%rsp),%rcx
  1e75e8:	test   %rcx,%rcx
  1e75eb:	mov    %r11,0x380(%rsp)
  1e75f3:	je     1e761f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x446f>
  1e75f5:	cmp    $0x1,%rcx
  1e75f9:	jne    1e7641 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4491>
  1e75fb:	vxorpd %xmm1,%xmm1,%xmm1
  1e75ff:	vxorpd %xmm3,%xmm3,%xmm3
  1e7603:	vxorpd %xmm4,%xmm4,%xmm4
  1e7607:	vxorpd %xmm2,%xmm2,%xmm2
  1e760b:	vxorpd %xmm6,%xmm6,%xmm6
  1e760f:	xor    %esi,%esi
  1e7611:	vxorpd %xmm5,%xmm5,%xmm5
  1e7615:	vxorpd %xmm8,%xmm8,%xmm8
  1e761a:	jmp    1e7757 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x45a7>
  1e761f:	vxorpd %xmm1,%xmm1,%xmm1
  1e7623:	vxorpd %xmm3,%xmm3,%xmm3
  1e7627:	vxorpd %xmm4,%xmm4,%xmm4
  1e762b:	vxorpd %xmm2,%xmm2,%xmm2
  1e762f:	vxorpd %xmm6,%xmm6,%xmm6
  1e7633:	vxorpd %xmm8,%xmm8,%xmm8
  1e7638:	vxorpd %xmm5,%xmm5,%xmm5
  1e763c:	jmp    1e77bf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x460f>
  1e7641:	mov    $0x20,%r11d
  1e7647:	vxorpd %xmm1,%xmm1,%xmm1
  1e764b:	vxorpd %xmm3,%xmm3,%xmm3
  1e764f:	vxorpd %xmm4,%xmm4,%xmm4
  1e7653:	vxorpd %xmm2,%xmm2,%xmm2
  1e7657:	vxorpd %xmm6,%xmm6,%xmm6
  1e765b:	xor    %esi,%esi
  1e765d:	vxorpd %xmm5,%xmm5,%xmm5
  1e7661:	vxorpd %xmm8,%xmm8,%xmm8
  1e7666:	mov    0x68(%rsp),%rdx
  1e766b:	mov    0x50(%rsp),%r8
  1e7670:	mov    0x48(%rsp),%r14
  1e7675:	mov    0x70(%rsp),%rcx
  1e767a:	nopw   0x0(%rax,%rax,1)
  1e7680:	vmovupd -0x20(%rdx,%r11,1),%ymm7
  1e7687:	vmovupd -0x20(%rbp,%r11,1),%ymm9
  1e768e:	vfmadd231pd %ymm9,%ymm7,%ymm5
  1e7693:	vmovupd -0x20(%r8,%r11,1),%ymm10
  1e769a:	vfmadd231pd %ymm9,%ymm10,%ymm6
  1e769f:	vmovupd -0x20(%r14,%r11,1),%ymm11
  1e76a6:	vfmadd231pd %ymm9,%ymm11,%ymm2
  1e76ab:	vmovupd -0x20(%rcx,%r11,1),%ymm12
  1e76b2:	vfmadd231pd %ymm9,%ymm12,%ymm4
  1e76b7:	vmovupd -0x20(%r15,%r11,1),%ymm9
  1e76be:	vfmadd231pd %ymm7,%ymm9,%ymm8
  1e76c3:	vmovupd (%rdx,%r11,1),%ymm7
  1e76c9:	vfmadd231pd %ymm10,%ymm9,%ymm3
  1e76ce:	vmovupd 0x0(%rbp,%r11,1),%ymm10
  1e76d5:	vfmadd231pd %ymm11,%ymm9,%ymm1
  1e76da:	vmovupd (%r8,%r11,1),%ymm11
  1e76e0:	vfmadd231pd %ymm9,%ymm12,%ymm0
  1e76e5:	vmovupd (%r14,%r11,1),%ymm9
  1e76eb:	vmovupd (%rcx,%r11,1),%ymm12
  1e76f1:	vfmadd231pd %ymm10,%ymm7,%ymm5
  1e76f6:	vfmadd231pd %ymm10,%ymm11,%ymm6
  1e76fb:	vfmadd231pd %ymm10,%ymm9,%ymm2
  1e7700:	vfmadd231pd %ymm10,%ymm12,%ymm4
  1e7705:	vmovupd (%r15,%r11,1),%ymm10
  1e770b:	vfmadd231pd %ymm7,%ymm10,%ymm8
  1e7710:	vfmadd231pd %ymm11,%ymm10,%ymm3
  1e7715:	vfmadd231pd %ymm9,%ymm10,%ymm1
  1e771a:	vfmadd231pd %ymm10,%ymm12,%ymm0
  1e771f:	add    $0x2,%rsi
  1e7723:	add    $0x40,%r11
  1e7727:	cmp    %rsi,%rax
  1e772a:	jne    1e7680 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x44d0>
  1e7730:	testb  $0x1,0x260(%rsp)
  1e7738:	mov    0x58(%rsp),%r14
  1e773d:	movzbl 0x190(%rsp),%edx
  1e7745:	mov    0x120(%rsp),%r8
  1e774d:	mov    0x380(%rsp),%r11
  1e7755:	je     1e77bf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x460f>
  1e7757:	shl    $0x5,%rsi
  1e775b:	mov    0x68(%rsp),%rdx
  1e7760:	vmovupd (%rdx,%rsi,1),%ymm7
  1e7765:	vmovupd 0x0(%rbp,%rsi,1),%ymm9
  1e776b:	vfmadd231pd %ymm9,%ymm7,%ymm5
  1e7770:	mov    0x50(%rsp),%rdx
  1e7775:	vmovupd (%rdx,%rsi,1),%ymm10
  1e777a:	vfmadd231pd %ymm9,%ymm10,%ymm6
  1e777f:	mov    0x48(%rsp),%rdx
  1e7784:	vmovupd (%rdx,%rsi,1),%ymm11
  1e7789:	movzbl 0x190(%rsp),%edx
  1e7791:	vfmadd231pd %ymm9,%ymm11,%ymm2
  1e7796:	mov    0x70(%rsp),%rcx
  1e779b:	vmovupd (%rcx,%rsi,1),%ymm12
  1e77a0:	vfmadd231pd %ymm9,%ymm12,%ymm4
  1e77a5:	vmovupd (%r15,%rsi,1),%ymm9
  1e77ab:	vfmadd231pd %ymm7,%ymm9,%ymm8
  1e77b0:	vfmadd231pd %ymm10,%ymm9,%ymm3
  1e77b5:	vfmadd231pd %ymm11,%ymm9,%ymm1
  1e77ba:	vfmadd231pd %ymm9,%ymm12,%ymm0
  1e77bf:	vextractf128 $0x1,%ymm5,%xmm7
  1e77c5:	vaddpd %xmm7,%xmm5,%xmm5
  1e77c9:	vshufpd $0x1,%xmm5,%xmm5,%xmm7
  1e77ce:	vaddsd %xmm7,%xmm5,%xmm5
  1e77d2:	vextractf128 $0x1,%ymm6,%xmm7
  1e77d8:	vaddpd %xmm7,%xmm6,%xmm6
  1e77dc:	vshufpd $0x1,%xmm6,%xmm6,%xmm7
  1e77e1:	vaddsd %xmm7,%xmm6,%xmm7
  1e77e5:	vextractf128 $0x1,%ymm2,%xmm6
  1e77eb:	vaddpd %xmm6,%xmm2,%xmm2
  1e77ef:	vshufpd $0x1,%xmm2,%xmm2,%xmm6
  1e77f4:	vaddsd %xmm6,%xmm2,%xmm2
  1e77f8:	vextractf128 $0x1,%ymm4,%xmm6
  1e77fe:	vaddpd %xmm6,%xmm4,%xmm4
  1e7802:	vshufpd $0x1,%xmm4,%xmm4,%xmm6
  1e7807:	vaddsd %xmm6,%xmm4,%xmm6
  1e780b:	vextractf128 $0x1,%ymm8,%xmm4
  1e7811:	vaddpd %xmm4,%xmm8,%xmm4
  1e7815:	vshufpd $0x1,%xmm4,%xmm4,%xmm8
  1e781a:	vaddsd %xmm4,%xmm8,%xmm4
  1e781e:	vextractf128 $0x1,%ymm3,%xmm8
  1e7824:	vaddpd %xmm3,%xmm8,%xmm3
  1e7828:	vshufpd $0x1,%xmm3,%xmm3,%xmm8
  1e782d:	vaddsd %xmm3,%xmm8,%xmm3
  1e7831:	vextractf128 $0x1,%ymm1,%xmm8
  1e7837:	vaddpd %xmm1,%xmm8,%xmm1
  1e783b:	vshufpd $0x1,%xmm1,%xmm1,%xmm8
  1e7840:	vaddsd %xmm1,%xmm8,%xmm1
  1e7844:	vextractf128 $0x1,%ymm0,%xmm8
  1e784a:	vaddpd %xmm0,%xmm8,%xmm0
  1e784e:	vshufpd $0x1,%xmm0,%xmm0,%xmm8
  1e7853:	vaddsd %xmm0,%xmm8,%xmm0
  1e7857:	cmpq   $0x0,0x620(%rsp)
  1e7860:	je     1e7a1c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x486c>
  1e7866:	mov    0x5e0(%rsp),%rax
  1e786e:	cmp    %eax,0x2c0(%rsp)
  1e7875:	jbe    1ec311 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9161>
  1e787b:	mov    0xc8(%rsp),%rdx
  1e7883:	cmp    %edx,0x600(%rsp)
  1e788a:	mov    0x720(%rsp),%rax
  1e7892:	mov    0x700(%rsp),%rcx
  1e789a:	je     1ec37d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x91cd>
  1e78a0:	cmp    %edx,0x690(%rsp)
  1e78a7:	je     1ec362 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x91b2>
  1e78ad:	cmp    %edx,0xb0(%rsp)
  1e78b4:	je     1ec347 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9197>
  1e78ba:	cmp    %edx,0x140(%rsp)
  1e78c1:	je     1ec32c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x917c>
  1e78c7:	mov    %r13,%r14
  1e78ca:	mov    0x68(%rsp),%rdx
  1e78cf:	vmovsd (%rdx,%rax,8),%xmm8
  1e78d4:	mov    0x160(%rsp),%rdi
  1e78dc:	vmovsd 0x0(%rbp,%rdi,8),%xmm9
  1e78e2:	vfmadd231sd %xmm9,%xmm8,%xmm5
  1e78e7:	mov    0x50(%rsp),%rsi
  1e78ec:	vmovsd (%rsi,%rcx,8),%xmm10
  1e78f1:	vfmadd231sd %xmm9,%xmm10,%xmm7
  1e78f6:	mov    %rax,%r11
  1e78f9:	mov    %rcx,%r10
  1e78fc:	mov    0x48(%rsp),%r8
  1e7901:	mov    0xc0(%rsp),%r13
  1e7909:	vmovsd (%r8,%r13,8),%xmm11
  1e790f:	vfmadd231sd %xmm9,%xmm11,%xmm2
  1e7914:	mov    0x70(%rsp),%rax
  1e7919:	mov    0xd8(%rsp),%rcx
  1e7921:	vmovsd (%rax,%rcx,8),%xmm12
  1e7926:	vfmadd231sd %xmm9,%xmm12,%xmm6
  1e792b:	vmovsd (%r15,%r14,8),%xmm9
  1e7931:	vfmadd231sd %xmm8,%xmm9,%xmm4
  1e7936:	vfmadd231sd %xmm10,%xmm9,%xmm3
  1e793b:	vfmadd231sd %xmm11,%xmm9,%xmm1
  1e7940:	vfmadd231sd %xmm9,%xmm12,%xmm0
  1e7945:	mov    0x620(%rsp),%rbx
  1e794d:	cmp    $0x1,%ebx
  1e7950:	je     1e79fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x484b>
  1e7956:	vmovsd 0x8(%rdx,%r11,8),%xmm8
  1e795d:	vmovsd 0x8(%rbp,%rdi,8),%xmm9
  1e7963:	vfmadd231sd %xmm9,%xmm8,%xmm5
  1e7968:	vmovsd 0x8(%rsi,%r10,8),%xmm10
  1e796f:	vfmadd231sd %xmm9,%xmm10,%xmm7
  1e7974:	vmovsd 0x8(%r8,%r13,8),%xmm11
  1e797b:	vfmadd231sd %xmm9,%xmm11,%xmm2
  1e7980:	vmovsd 0x8(%rax,%rcx,8),%xmm12
  1e7986:	vfmadd231sd %xmm9,%xmm12,%xmm6
  1e798b:	vmovsd 0x8(%r15,%r14,8),%xmm9
  1e7992:	vfmadd231sd %xmm8,%xmm9,%xmm4
  1e7997:	vfmadd231sd %xmm10,%xmm9,%xmm3
  1e799c:	vfmadd231sd %xmm11,%xmm9,%xmm1
  1e79a1:	vfmadd231sd %xmm9,%xmm12,%xmm0
  1e79a6:	cmp    $0x2,%ebx
  1e79a9:	je     1e79fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x484b>
  1e79ab:	vmovsd 0x10(%rdx,%r11,8),%xmm8
  1e79b2:	vmovsd 0x10(%rbp,%rdi,8),%xmm9
  1e79b8:	vfmadd231sd %xmm9,%xmm8,%xmm5
  1e79bd:	vmovsd 0x10(%rsi,%r10,8),%xmm10
  1e79c4:	vfmadd231sd %xmm9,%xmm10,%xmm7
  1e79c9:	vmovsd 0x10(%r8,%r13,8),%xmm11
  1e79d0:	vfmadd231sd %xmm9,%xmm11,%xmm2
  1e79d5:	vmovsd 0x10(%rax,%rcx,8),%xmm12
  1e79db:	vfmadd231sd %xmm9,%xmm12,%xmm6
  1e79e0:	vmovsd 0x10(%r15,%r14,8),%xmm9
  1e79e7:	vfmadd231sd %xmm8,%xmm9,%xmm4
  1e79ec:	vfmadd231sd %xmm10,%xmm9,%xmm3
  1e79f1:	vfmadd231sd %xmm11,%xmm9,%xmm1
  1e79f6:	vfmadd231sd %xmm9,%xmm12,%xmm0
  1e79fb:	movzbl 0x190(%rsp),%edx
  1e7a03:	mov    0x120(%rsp),%r8
  1e7a0b:	mov    0x58(%rsp),%r14
  1e7a10:	mov    0x380(%rsp),%r11
  1e7a18:	lea    0x2(%r11),%r10
  1e7a1c:	cmp    0x38(%rsp),%r9
  1e7a21:	mov    0x2a0(%rsp),%rax
  1e7a29:	jae    1ec1db <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x902b>
  1e7a2f:	mov    0x80(%rsp),%rsi
  1e7a37:	vmovsd %xmm5,(%rsi,%rax,1)
  1e7a3c:	vmovsd %xmm7,0x8(%rsi,%rax,1)
  1e7a42:	cmp    0xe0(%rsp),%r11
  1e7a4a:	mov    0x280(%rsp),%rdi
  1e7a52:	jae    1e7a7b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x48cb>
  1e7a54:	inc    %r9
  1e7a57:	cmp    0x38(%rsp),%r9
  1e7a5c:	jae    1ec45b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x92ab>
  1e7a62:	shl    $0x4,%r9
  1e7a66:	mov    0x80(%rsp),%rax
  1e7a6e:	vmovsd %xmm2,(%rax,%r9,1)
  1e7a74:	vmovsd %xmm6,0x8(%rax,%r9,1)
  1e7a7b:	cmp    0x38(%rsp),%rdi
  1e7a80:	jae    1ec17b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8fcb>
  1e7a86:	mov    0x80(%rsp),%rax
  1e7a8e:	mov    0x200(%rsp),%rcx
  1e7a96:	vmovsd %xmm4,(%rax,%rcx,1)
  1e7a9b:	vmovsd %xmm3,0x8(%rax,%rcx,1)
  1e7aa1:	cmp    0xe0(%rsp),%r10
  1e7aa9:	mov    0x70(%rsp),%r13
  1e7aae:	mov    0x10(%rsp),%r9
  1e7ab3:	mov    0x180(%rsp),%rbx
  1e7abb:	jae    1e6d7b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bcb>
  1e7ac1:	inc    %rdi
  1e7ac4:	cmp    0x38(%rsp),%rdi
  1e7ac9:	jb     1e6d64 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bb4>
  1e7acf:	lea    0x10aaaa(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1e7ad6:	mov    0x38(%rsp),%rsi
  1e7adb:	vzeroupper
  1e7ade:	call   *0x11585c(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1e7ae4:	mov    0x170(%rsp),%rsi
  1e7aec:	mov    %rsi,%rcx
  1e7aef:	shr    $0x2,%rcx
  1e7af3:	mov    %rcx,0x358(%rsp)
  1e7afb:	mov    %esi,%ecx
  1e7afd:	and    $0x3,%ecx
  1e7b00:	mov    %rcx,0x98(%rsp)
  1e7b08:	mov    %rsi,%rcx
  1e7b0b:	and    %rax,%rcx
  1e7b0e:	mov    %rcx,0x2a0(%rsp)
  1e7b16:	mov    %rbx,%rcx
  1e7b19:	shr    $0x2,%rcx
  1e7b1d:	mov    %rcx,0x210(%rsp)
  1e7b25:	mov    %ebx,%ecx
  1e7b27:	and    $0x3,%ecx
  1e7b2a:	mov    %rcx,0x88(%rsp)
  1e7b32:	mov    %rbx,%rcx
  1e7b35:	and    %rax,%rcx
  1e7b38:	mov    %rcx,0x520(%rsp)
  1e7b40:	mov    0x178(%rsp),%r8
  1e7b48:	mov    %r8,%rcx
  1e7b4b:	shr    $0x2,%rcx
  1e7b4f:	mov    %rcx,0x5d0(%rsp)
  1e7b57:	mov    %r8d,%ecx
  1e7b5a:	and    $0x3,%ecx
  1e7b5d:	mov    %rcx,0xf0(%rsp)
  1e7b65:	mov    %r8,%rcx
  1e7b68:	and    %rax,%rcx
  1e7b6b:	mov    %rcx,0x4f0(%rsp)
  1e7b73:	mov    0x1d8(%rsp),%rcx
  1e7b7b:	mov    %rcx,%rdi
  1e7b7e:	shr    $0x2,%rdi
  1e7b82:	mov    %rdi,0x5c0(%rsp)
  1e7b8a:	mov    %ecx,%edi
  1e7b8c:	and    $0x3,%edi
  1e7b8f:	mov    %rdi,0x110(%rsp)
  1e7b97:	mov    %rcx,%rdi
  1e7b9a:	and    %rax,%rdi
  1e7b9d:	mov    %rdi,0x600(%rsp)
  1e7ba5:	mov    %rdx,%rbp
  1e7ba8:	shr    $0x2,%rbp
  1e7bac:	mov    %edx,%r15d
  1e7baf:	and    $0x3,%r15d
  1e7bb3:	mov    %rdx,%rdi
  1e7bb6:	and    %rax,%rdi
  1e7bb9:	mov    %rdi,0x380(%rsp)
  1e7bc1:	mov    0x2f0(%rsp),%rax
  1e7bc9:	mov    %rax,%rdi
  1e7bcc:	shr    $0x2,%rdi
  1e7bd0:	mov    %rdi,0x2c0(%rsp)
  1e7bd8:	shr    $0x3,%rax
  1e7bdc:	mov    %rax,%r11
  1e7bdf:	mov    0x40(%rsp),%rax
  1e7be4:	jmp    1e7c3e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4a8e>
  1e7be6:	mov    %dl,0x190(%rsp)
  1e7bed:	vmovapd %ymm1,%ymm0
  1e7bf1:	mov    %r11,%rdx
  1e7bf4:	mov    %rbx,%r9
  1e7bf7:	mov    0x40(%rsp),%rax
  1e7bfc:	mov    0x1d8(%rsp),%rcx
  1e7c04:	mov    0x178(%rsp),%r8
  1e7c0c:	mov    0x180(%rsp),%rbx
  1e7c14:	mov    0x170(%rsp),%rsi
  1e7c1c:	movabs $0x3fffffffffffffe,%r10
  1e7c26:	mov    0x200(%rsp),%r11
  1e7c2e:	mov    0x260(%rsp),%r15
  1e7c36:	mov    0x160(%rsp),%rbp
  1e7c3e:	mov    %r15,0x260(%rsp)
  1e7c46:	and    %r10,%rbp
  1e7c49:	shl    $0x5,%rbp
  1e7c4d:	mov    %rdx,0x1e0(%rsp)
  1e7c55:	shr    $0x3,%rdx
  1e7c59:	shr    $0x3,%rsi
  1e7c5d:	mov    %rbx,%rdi
  1e7c60:	shr    $0x3,%rdi
  1e7c64:	cmp    %rsi,%rdi
  1e7c67:	cmovae %rsi,%rdi
  1e7c6b:	mov    %r8,%rsi
  1e7c6e:	shr    $0x3,%rsi
  1e7c72:	cmp    %rdi,%rsi
  1e7c75:	cmovae %rdi,%rsi
  1e7c79:	mov    %rcx,%rdi
  1e7c7c:	shr    $0x3,%rdi
  1e7c80:	cmp    %rsi,%rdi
  1e7c83:	cmovae %rsi,%rdi
  1e7c87:	cmp    %rdi,%rdx
  1e7c8a:	cmovb  %rdx,%rdi
  1e7c8e:	cmp    %rdi,%r11
  1e7c91:	mov    %r11,0x200(%rsp)
  1e7c99:	cmovb  %r11,%rdi
  1e7c9d:	test   %rdi,%rdi
  1e7ca0:	mov    0x68(%rsp),%r11
  1e7ca5:	mov    0x50(%rsp),%rbx
  1e7caa:	mov    0x48(%rsp),%r15
  1e7caf:	mov    0x20(%rsp),%r8
  1e7cb4:	je     1e7cf8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4b48>
  1e7cb6:	cmp    $0x1,%rdi
  1e7cba:	mov    0x88(%rsp),%r12
  1e7cc2:	mov    0x380(%rsp),%rsi
  1e7cca:	jne    1e8faf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5dff>
  1e7cd0:	vxorpd %xmm1,%xmm1,%xmm1
  1e7cd4:	xor    %ecx,%ecx
  1e7cd6:	vxorpd %xmm3,%xmm3,%xmm3
  1e7cda:	vxorpd %xmm2,%xmm2,%xmm2
  1e7cde:	vxorpd %xmm7,%xmm7,%xmm7
  1e7ce2:	vxorpd %xmm6,%xmm6,%xmm6
  1e7ce6:	vxorpd %xmm5,%xmm5,%xmm5
  1e7cea:	vxorpd %xmm4,%xmm4,%xmm4
  1e7cee:	vxorpd %xmm8,%xmm8,%xmm8
  1e7cf3:	jmp    1e90d5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5f25>
  1e7cf8:	vxorpd %xmm8,%xmm8,%xmm8
  1e7cfd:	vxorpd %xmm4,%xmm4,%xmm4
  1e7d01:	vxorpd %xmm5,%xmm5,%xmm5
  1e7d05:	vxorpd %xmm6,%xmm6,%xmm6
  1e7d09:	vxorpd %xmm7,%xmm7,%xmm7
  1e7d0d:	vxorpd %xmm2,%xmm2,%xmm2
  1e7d11:	vxorpd %xmm3,%xmm3,%xmm3
  1e7d15:	vxorpd %xmm1,%xmm1,%xmm1
  1e7d19:	mov    0x88(%rsp),%r12
  1e7d21:	mov    0x380(%rsp),%rsi
  1e7d29:	jmp    1e9129 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5f79>
  1e7d2e:	vxorpd %xmm4,%xmm4,%xmm4
  1e7d32:	xor    %edx,%edx
  1e7d34:	vxorpd %xmm5,%xmm5,%xmm5
  1e7d38:	vxorpd %xmm7,%xmm7,%xmm7
  1e7d3c:	vxorpd %xmm6,%xmm6,%xmm6
  1e7d40:	vxorpd %xmm3,%xmm3,%xmm3
  1e7d44:	vpxor  %xmm0,%xmm0,%xmm0
  1e7d48:	vxorpd %xmm2,%xmm2,%xmm2
  1e7d4c:	vxorpd %xmm1,%xmm1,%xmm1
  1e7d50:	mov    0xe8(%rsp),%rbp
  1e7d58:	vperm2f128 $0x31,%ymm6,%ymm7,%ymm8
  1e7d5e:	vinsertf128 $0x1,%xmm6,%ymm7,%ymm6
  1e7d64:	vaddpd %ymm6,%ymm8,%ymm6
  1e7d68:	vperm2f128 $0x31,%ymm5,%ymm4,%ymm7
  1e7d6e:	vinsertf128 $0x1,%xmm5,%ymm4,%ymm4
  1e7d74:	vaddpd %ymm7,%ymm4,%ymm4
  1e7d78:	vhaddpd %ymm6,%ymm4,%ymm4
  1e7d7c:	vpermpd $0xd8,%ymm4,%ymm4
  1e7d82:	vmovupd %ymm4,0x218(%rsp)
  1e7d8b:	vperm2f128 $0x31,%ymm1,%ymm2,%ymm4
  1e7d91:	vinsertf128 $0x1,%xmm1,%ymm2,%ymm1
  1e7d97:	vaddpd %ymm4,%ymm1,%ymm1
  1e7d9b:	vperm2f128 $0x31,%ymm0,%ymm3,%ymm2
  1e7da1:	vinsertf128 $0x1,%xmm0,%ymm3,%ymm0
  1e7da7:	vaddpd %ymm2,%ymm0,%ymm0
  1e7dab:	vhaddpd %ymm1,%ymm0,%ymm0
  1e7daf:	vpermpd $0xd8,%ymm0,%ymm0
  1e7db5:	vmovupd %ymm0,0x238(%rsp)
  1e7dbe:	lea    0x450(%rsp),%rax
  1e7dc6:	mov    %rax,0x6b0(%rsp)
  1e7dce:	lea    0x470(%rsp),%rax
  1e7dd6:	mov    %rax,0x6b8(%rsp)
  1e7dde:	mov    0x10(%rsp),%rax
  1e7de3:	mov    %rax,0x6c0(%rsp)
  1e7deb:	mov    0x1b0(%rsp),%rax
  1e7df3:	mov    %rax,0x6c8(%rsp)
  1e7dfb:	mov    %rbp,0x6d0(%rsp)
  1e7e03:	mov    0x200(%rsp),%rax
  1e7e0b:	mov    %rax,0x6d8(%rsp)
  1e7e13:	lea    0x490(%rsp),%rax
  1e7e1b:	mov    %rax,0x6e0(%rsp)
  1e7e23:	lea    0x4b0(%rsp),%rax
  1e7e2b:	mov    %rax,0x6e8(%rsp)
  1e7e33:	mov    0x648(%rsp),%rax
  1e7e3b:	mov    %rax,0x6f0(%rsp)
  1e7e43:	mov    0x2f0(%rsp),%rax
  1e7e4b:	mov    %rax,0x6f8(%rsp)
  1e7e53:	test   %r13,%r13
  1e7e56:	je     1e8893 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x56e3>
  1e7e5c:	xor    %r15d,%r15d
  1e7e5f:	mov    %r13,0x18(%rsp)
  1e7e64:	mov    %rdx,0x120(%rsp)
  1e7e6c:	jmp    1e7ecc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4d1c>
  1e7e6e:	xchg   %ax,%ax
  1e7e70:	lea    0x1(%r14),%rbp
  1e7e74:	mov    %r13,%rdi
  1e7e77:	mov    %r14,%rsi
  1e7e7a:	mov    %r12,%rdx
  1e7e7d:	vzeroupper
  1e7e80:	call   1f7760 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e7e85:	or     $0x2,%r14
  1e7e89:	mov    %r13,%rdi
  1e7e8c:	mov    %rbp,%rsi
  1e7e8f:	mov    %r12,%rdx
  1e7e92:	call   1f7760 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e7e97:	mov    %r13,%rdi
  1e7e9a:	mov    %r14,%rsi
  1e7e9d:	mov    %r12,%rdx
  1e7ea0:	call   1f7760 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e7ea5:	mov    %r13,%rdi
  1e7ea8:	mov    %rbx,%rsi
  1e7eab:	mov    %r12,%rdx
  1e7eae:	call   1f7760 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e7eb3:	inc    %r15
  1e7eb6:	mov    0x18(%rsp),%r13
  1e7ebb:	cmp    %r13,%r15
  1e7ebe:	mov    0x120(%rsp),%rdx
  1e7ec6:	je     1e8893 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x56e3>
  1e7ecc:	lea    0x0(,%r15,4),%r14
  1e7ed4:	shrx   %r14,%rdx,%rax
  1e7ed9:	mov    %eax,%ebp
  1e7edb:	and    $0xf,%bpl
  1e7edf:	lea    0x6b0(%rsp),%r12
  1e7ee7:	lea    0x218(%rsp),%rbx
  1e7eef:	je     1e7eb3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4d03>
  1e7ef1:	and    $0xf,%eax
  1e7ef4:	cmp    $0xf,%eax
  1e7ef7:	jne    1e80c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4f10>
  1e7efd:	cmp    0xc0(%rsp),%r15
  1e7f05:	jae    1ebfa6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8df6>
  1e7f0b:	cmp    0xd8(%rsp),%r15
  1e7f13:	mov    0x28(%rsp),%rdi
  1e7f18:	mov    0xf0(%rsp),%rax
  1e7f20:	lea    0x6b0(%rsp),%r13
  1e7f28:	lea    0x218(%rsp),%r12
  1e7f30:	jae    1ebfdc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8e2c>
  1e7f36:	cmp    %rax,%r15
  1e7f39:	jae    1ec012 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8e62>
  1e7f3f:	cmp    0x100(%rsp),%r15
  1e7f47:	mov    0x70(%rsp),%rdx
  1e7f4c:	mov    0x10(%rsp),%rsi
  1e7f51:	mov    0xe8(%rsp),%r8
  1e7f59:	vxorpd %xmm10,%xmm10,%xmm10
  1e7f5e:	jae    1ec048 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8e98>
  1e7f64:	cmp    0xc8(%rsp),%r15
  1e7f6c:	jae    1ebf8b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8ddb>
  1e7f72:	cmp    0xf8(%rsp),%r15
  1e7f7a:	jae    1ebfc1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8e11>
  1e7f80:	cmp    0xb0(%rsp),%r15
  1e7f88:	jae    1ebff7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8e47>
  1e7f8e:	cmp    0x88(%rsp),%r15
  1e7f96:	jae    1ec02d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8e7d>
  1e7f9c:	lea    0x3(%r14),%rbx
  1e7fa0:	cmp    0x200(%rsp),%rbx
  1e7fa8:	jae    1e9903 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6753>
  1e7fae:	cmp    0x60(%rsp),%r15
  1e7fb3:	jae    1ec063 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8eb3>
  1e7fb9:	mov    %r15,%rax
  1e7fbc:	shl    $0x5,%rax
  1e7fc0:	mov    0x68(%rsp),%rcx
  1e7fc5:	vmovupd (%rcx,%rax,1),%ymm1
  1e7fca:	vmovupd (%rdi,%rax,1),%ymm2
  1e7fcf:	mov    0x50(%rsp),%rcx
  1e7fd4:	vmovupd (%rcx,%rax,1),%ymm5
  1e7fd9:	mov    0x20(%rsp),%rcx
  1e7fde:	vmovupd (%rcx,%rax,1),%ymm3
  1e7fe3:	mov    0x48(%rsp),%rcx
  1e7fe8:	vmovupd (%rcx,%rax,1),%ymm6
  1e7fed:	mov    0x40(%rsp),%rcx
  1e7ff2:	vmovupd (%rcx,%rax,1),%ymm7
  1e7ff7:	vmovupd (%rsi,%rax,1),%ymm8
  1e7ffc:	mov    0x58(%rsp),%rcx
  1e8001:	vmulpd (%rcx,%rax,1),%ymm8,%ymm4
  1e8006:	vmovupd (%rdx,%rax,1),%ymm9
  1e800b:	vmovupd %ymm4,0x9a8(%rsp)
  1e8014:	vmulpd %ymm2,%ymm8,%ymm12
  1e8018:	vmovupd %ymm12,0x9c8(%rsp)
  1e8021:	vmulpd %ymm3,%ymm8,%ymm3
  1e8025:	vmulpd %ymm7,%ymm8,%ymm2
  1e8029:	vmovupd %ymm3,0x280(%rsp)
  1e8032:	vmovupd %ymm3,0xaa8(%rsp)
  1e803b:	vmovupd %ymm2,0x1e0(%rsp)
  1e8044:	vmovupd %ymm2,0xac8(%rsp)
  1e804d:	vmulpd %ymm1,%ymm8,%ymm3
  1e8051:	vmovupd %ymm3,0x9e8(%rsp)
  1e805a:	vmulpd %ymm5,%ymm8,%ymm0
  1e805e:	vmovupd %ymm0,0xa08(%rsp)
  1e8067:	vmulpd %ymm6,%ymm8,%ymm5
  1e806b:	vmulpd %ymm8,%ymm9,%ymm1
  1e8070:	vmovupd %ymm5,0x360(%rsp)
  1e8079:	vmovupd %ymm5,0xae8(%rsp)
  1e8082:	vmovupd %ymm1,0x190(%rsp)
  1e808b:	vmovupd %ymm1,0xb08(%rsp)
  1e8094:	vcmpeqpd %ymm10,%ymm10,%ymm1
  1e809a:	lea    0x9a8(%rsp),%rcx
  1e80a2:	xor    %eax,%eax
  1e80a4:	lea    0xa28(%rsp),%rsi
  1e80ac:	vbroadcastsd -0x1c1f3d(%rip),%ymm7        # 26178 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x3a8>
  1e80b5:	vbroadcastsd -0x1c2086(%rip),%ymm8        # 26038 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x268>
  1e80be:	jmp    1e8117 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4f67>
  1e80c0:	movzbl %bpl,%r13d
  1e80c4:	xor    %esi,%esi
  1e80c6:	tzcnt  %r13d,%esi
  1e80cb:	lea    -0x1(%r13),%ebp
  1e80cf:	add    %r14,%rsi
  1e80d2:	mov    %r12,%rdi
  1e80d5:	mov    %rbx,%rdx
  1e80d8:	vzeroupper
  1e80db:	call   1f7760 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e80e0:	and    %r13b,%bpl
  1e80e3:	jne    1e80c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4f10>
  1e80e5:	jmp    1e7eb3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4d03>
  1e80ea:	nopw   0x0(%rax,%rax,1)
  1e80f0:	lea    0x20(%rcx),%rdx
  1e80f4:	vbroadcastsd -0x1c1e5d(%rip),%ymm5        # 262a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x4d0>
  1e80fd:	vandpd (%rcx),%ymm5,%ymm5
  1e8101:	vcmpge_oqpd %ymm7,%ymm5,%ymm6
  1e8106:	vcmple_oqpd %ymm8,%ymm5,%ymm5
  1e810c:	vandpd %ymm5,%ymm6,%ymm5
  1e8110:	vandpd %ymm1,%ymm5,%ymm1
  1e8114:	mov    %rdx,%rcx
  1e8117:	test   %rcx,%rcx
  1e811a:	je     1e8121 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4f71>
  1e811c:	cmp    %rsi,%rcx
  1e811f:	jne    1e80f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4f40>
  1e8121:	cmp    $0x80,%rax
  1e8127:	je     1e8140 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4f90>
  1e8129:	lea    (%rsp,%rax,1),%rcx
  1e812d:	add    $0xaa8,%rcx
  1e8134:	add    $0x20,%rax
  1e8138:	xor    %edx,%edx
  1e813a:	jmp    1e80f4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4f44>
  1e813c:	nopl   0x0(%rax)
  1e8140:	vpcmpgtq %ymm1,%ymm10,%ymm1
  1e8145:	vpbroadcastq -0x1c1ea6(%rip),%ymm11        # 262a8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x4d8>
  1e814e:	vpand  %ymm1,%ymm11,%ymm1
  1e8152:	vextracti128 $0x1,%ymm1,%xmm5
  1e8158:	vminpd %xmm5,%xmm1,%xmm1
  1e815c:	vshufpd $0x1,%xmm1,%xmm1,%xmm5
  1e8161:	vminsd %xmm5,%xmm1,%xmm1
  1e8165:	vxorpd %xmm5,%xmm5,%xmm5
  1e8169:	vucomisd %xmm5,%xmm1
  1e816d:	jbe    1e7e70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4cc0>
  1e8173:	vmovupd (%r8,%r14,8),%ymm14
  1e8179:	vpbroadcastq -0x1c1a42(%rip),%ymm10        # 26740 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x970>
  1e8182:	vpbroadcastq -0x1c1d53(%rip),%ymm1        # 26438 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x668>
  1e818b:	vpbroadcastq -0x1c17f4(%rip),%ymm13        # 269a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0xbd0>
  1e8194:	vmovupd %ymm4,0x140(%rsp)
  1e819d:	vxorpd %xmm4,%xmm4,%xmm4
  1e81a1:	vcmpeqpd %ymm4,%ymm12,%ymm7
  1e81a6:	vandnpd %ymm14,%ymm7,%ymm5
  1e81ab:	vpaddq %ymm5,%ymm10,%ymm6
  1e81af:	vpbroadcastq -0x1c1dc8(%rip),%ymm15        # 263f0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x620>
  1e81b8:	vpxor  %ymm6,%ymm15,%ymm6
  1e81bc:	vpbroadcastq -0x1c21f5(%rip),%ymm8        # 25fd0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x200>
  1e81c5:	vmovupd %ymm7,0x260(%rsp)
  1e81ce:	vblendvpd %ymm7,%ymm11,%ymm12,%ymm7
  1e81d4:	vpcmpgtq %ymm6,%ymm8,%ymm6
  1e81d9:	vmovupd %ymm7,0x3c0(%rsp)
  1e81e2:	vpsrlq $0x34,%ymm7,%ymm9
  1e81e7:	vpand  %ymm1,%ymm9,%ymm9
  1e81eb:	vpaddq %ymm5,%ymm9,%ymm5
  1e81ef:	vmovdqu %ymm5,0x2a0(%rsp)
  1e81f8:	vpaddq %ymm5,%ymm13,%ymm5
  1e81fc:	vpxor  %ymm5,%ymm15,%ymm9
  1e8200:	vpbroadcastq -0x1c1b69(%rip),%ymm5        # 266a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x8d0>
  1e8209:	vpcmpgtq %ymm9,%ymm5,%ymm9
  1e820e:	vpor   %ymm6,%ymm9,%ymm9
  1e8212:	vmovapd %ymm3,%ymm2
  1e8216:	vmovupd %ymm3,0x670(%rsp)
  1e821f:	vcmpeqpd %ymm4,%ymm3,%ymm3
  1e8224:	vandnpd %ymm14,%ymm3,%ymm6
  1e8229:	vpaddq %ymm6,%ymm10,%ymm7
  1e822d:	vpxor  %ymm7,%ymm15,%ymm7
  1e8231:	vpcmpgtq %ymm7,%ymm8,%ymm7
  1e8236:	vmovupd %ymm3,0x2f0(%rsp)
  1e823f:	vblendvpd %ymm3,%ymm11,%ymm2,%ymm3
  1e8245:	vmovapd %ymm0,%ymm2
  1e8249:	vmovupd %ymm12,0x310(%rsp)
  1e8252:	vmovupd %ymm3,0x330(%rsp)
  1e825b:	vpsrlq $0x34,%ymm3,%ymm12
  1e8260:	vpand  %ymm1,%ymm12,%ymm12
  1e8264:	vpaddq %ymm6,%ymm12,%ymm3
  1e8268:	vpaddq %ymm3,%ymm13,%ymm6
  1e826c:	vpxor  %ymm6,%ymm15,%ymm6
  1e8270:	vpcmpgtq %ymm6,%ymm5,%ymm6
  1e8275:	vpor   %ymm6,%ymm7,%ymm7
  1e8279:	vcmpeqpd %ymm4,%ymm0,%ymm0
  1e827e:	vblendvpd %ymm0,%ymm11,%ymm2,%ymm6
  1e8284:	vmovupd %ymm6,0x410(%rsp)
  1e828d:	vpsrlq $0x34,%ymm6,%ymm12
  1e8292:	vpand  %ymm1,%ymm12,%ymm12
  1e8296:	vmovupd %ymm0,0x650(%rsp)
  1e829f:	vandnpd %ymm14,%ymm0,%ymm6
  1e82a4:	vpaddq %ymm6,%ymm12,%ymm0
  1e82a8:	vpaddq %ymm6,%ymm10,%ymm6
  1e82ac:	vpxor  %ymm6,%ymm15,%ymm6
  1e82b0:	vpcmpgtq %ymm6,%ymm8,%ymm6
  1e82b5:	vmovdqu %ymm0,0x380(%rsp)
  1e82be:	vpaddq %ymm0,%ymm13,%ymm12
  1e82c2:	vpxor  %ymm15,%ymm12,%ymm12
  1e82c7:	vpcmpgtq %ymm12,%ymm5,%ymm12
  1e82cc:	vpor   %ymm6,%ymm12,%ymm6
  1e82d0:	vpor   %ymm7,%ymm6,%ymm6
  1e82d4:	vpor   %ymm6,%ymm9,%ymm6
  1e82d8:	vcmpeqpd 0x140(%rsp),%ymm4,%ymm9
  1e82e2:	vmovupd 0x140(%rsp),%ymm0
  1e82eb:	vblendvpd %ymm9,%ymm11,%ymm0,%ymm0
  1e82f1:	vmovupd %ymm0,0x5a0(%rsp)
  1e82fa:	vpsrlq $0x34,%ymm0,%ymm7
  1e82ff:	vpand  %ymm1,%ymm7,%ymm7
  1e8303:	vandnpd %ymm14,%ymm9,%ymm12
  1e8308:	vpaddq %ymm7,%ymm12,%ymm0
  1e830c:	vpaddq %ymm10,%ymm12,%ymm7
  1e8311:	vpxor  %ymm7,%ymm15,%ymm7
  1e8315:	vpcmpgtq %ymm7,%ymm8,%ymm7
  1e831a:	vmovdqu %ymm0,0x580(%rsp)
  1e8323:	vpaddq %ymm0,%ymm13,%ymm12
  1e8327:	vpxor  %ymm15,%ymm12,%ymm12
  1e832c:	vpcmpgtq %ymm12,%ymm5,%ymm12
  1e8331:	vpor   %ymm7,%ymm12,%ymm7
  1e8335:	vpsllq $0x3f,%ymm6,%ymm6
  1e833a:	vpor   %ymm7,%ymm6,%ymm6
  1e833e:	vtestpd %ymm6,%ymm6
  1e8343:	jne    1e7e70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4cc0>
  1e8349:	vmovupd 0x1e0(%rsp),%ymm12
  1e8352:	vpxor  %xmm0,%xmm0,%xmm0
  1e8356:	vcmpeqpd %ymm0,%ymm12,%ymm4
  1e835b:	vandnpd %ymm14,%ymm4,%ymm6
  1e8360:	vpaddq %ymm6,%ymm10,%ymm7
  1e8364:	vpxor  %ymm7,%ymm15,%ymm7
  1e8368:	vpcmpgtq %ymm7,%ymm8,%ymm7
  1e836d:	vmovupd %ymm4,0x620(%rsp)
  1e8376:	vblendvpd %ymm4,%ymm11,%ymm12,%ymm4
  1e837c:	vmovupd %ymm4,0x430(%rsp)
  1e8385:	vpsrlq $0x34,%ymm4,%ymm12
  1e838a:	vpand  %ymm1,%ymm12,%ymm12
  1e838e:	vpaddq %ymm6,%ymm12,%ymm4
  1e8392:	vmovdqu %ymm4,0x4d0(%rsp)
  1e839b:	vpaddq %ymm4,%ymm13,%ymm6
  1e839f:	vpxor  %ymm6,%ymm15,%ymm6
  1e83a3:	vpcmpgtq %ymm6,%ymm5,%ymm6
  1e83a8:	vpor   %ymm6,%ymm7,%ymm0
  1e83ac:	vmovdqu %ymm0,0x2c0(%rsp)
  1e83b5:	vmovupd 0x360(%rsp),%ymm6
  1e83be:	vpxor  %xmm12,%xmm12,%xmm12
  1e83c3:	vcmpeqpd %ymm6,%ymm12,%ymm4
  1e83c8:	vblendvpd %ymm4,%ymm11,%ymm6,%ymm7
  1e83ce:	vmovupd %ymm4,0x3a0(%rsp)
  1e83d7:	vandnpd %ymm14,%ymm4,%ymm6
  1e83dc:	vmovupd %ymm7,0x3f0(%rsp)
  1e83e5:	vpsrlq $0x34,%ymm7,%ymm7
  1e83ea:	vpand  %ymm1,%ymm7,%ymm7
  1e83ee:	vpaddq %ymm6,%ymm7,%ymm4
  1e83f2:	vpaddq %ymm6,%ymm10,%ymm6
  1e83f6:	vpxor  %ymm6,%ymm15,%ymm6
  1e83fa:	vpcmpgtq %ymm6,%ymm8,%ymm6
  1e83ff:	vmovdqu %ymm4,0x560(%rsp)
  1e8408:	vpaddq %ymm4,%ymm13,%ymm7
  1e840c:	vpxor  %ymm7,%ymm15,%ymm7
  1e8410:	vpcmpgtq %ymm7,%ymm5,%ymm7
  1e8415:	vpor   %ymm7,%ymm6,%ymm6
  1e8419:	vmovupd 0x280(%rsp),%ymm7
  1e8422:	vmovdqa %ymm3,%ymm0
  1e8426:	vcmpeqpd %ymm7,%ymm12,%ymm3
  1e842b:	vblendvpd %ymm3,%ymm11,%ymm7,%ymm4
  1e8431:	vmovupd %ymm4,0x4f0(%rsp)
  1e843a:	vpsrlq $0x34,%ymm4,%ymm7
  1e843f:	vpand  %ymm1,%ymm7,%ymm7
  1e8443:	vmovupd 0x190(%rsp),%ymm12
  1e844c:	vxorpd %xmm4,%xmm4,%xmm4
  1e8450:	vcmpeqpd %ymm4,%ymm12,%ymm4
  1e8455:	vblendvpd %ymm4,%ymm11,%ymm12,%ymm11
  1e845b:	vmovupd %ymm11,0x520(%rsp)
  1e8464:	vpsrlq $0x34,%ymm11,%ymm11
  1e846a:	vpand  %ymm1,%ymm11,%ymm1
  1e846e:	vmovupd %ymm3,0x540(%rsp)
  1e8477:	vandnpd %ymm14,%ymm3,%ymm12
  1e847c:	vpaddq %ymm7,%ymm12,%ymm11
  1e8480:	vpaddq %ymm10,%ymm12,%ymm7
  1e8485:	vandnpd %ymm14,%ymm4,%ymm12
  1e848a:	vmovapd %ymm4,%ymm14
  1e848e:	vpaddq %ymm10,%ymm12,%ymm10
  1e8493:	vpaddq %ymm1,%ymm12,%ymm1
  1e8497:	vpxor  %ymm15,%ymm10,%ymm10
  1e849c:	vpcmpgtq %ymm10,%ymm8,%ymm10
  1e84a1:	vpaddq %ymm1,%ymm13,%ymm12
  1e84a5:	vpxor  %ymm15,%ymm12,%ymm12
  1e84aa:	vpcmpgtq %ymm12,%ymm5,%ymm12
  1e84af:	vpor   %ymm12,%ymm10,%ymm10
  1e84b4:	vmovupd 0x310(%rsp),%ymm4
  1e84bd:	vpor   %ymm6,%ymm10,%ymm6
  1e84c1:	vpor   0x2c0(%rsp),%ymm6,%ymm6
  1e84ca:	vpaddq %ymm13,%ymm11,%ymm10
  1e84cf:	vpxor  %ymm15,%ymm10,%ymm10
  1e84d4:	vpcmpgtq %ymm10,%ymm5,%ymm5
  1e84d9:	vpxor  %ymm7,%ymm15,%ymm7
  1e84dd:	vpcmpgtq %ymm7,%ymm8,%ymm7
  1e84e2:	vpor   %ymm5,%ymm7,%ymm5
  1e84e6:	vpsllq $0x3f,%ymm6,%ymm6
  1e84eb:	vpor   %ymm5,%ymm6,%ymm5
  1e84ef:	vtestpd %ymm5,%ymm5
  1e84f4:	jne    1e7e70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4cc0>
  1e84fa:	vmovdqu 0x380(%rsp),%ymm5
  1e8503:	vpsllq $0x34,%ymm5,%ymm6
  1e8508:	vpbroadcastq -0x1c2149(%rip),%ymm5        # 263c8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x5f8>
  1e8511:	vpand  0x410(%rsp),%ymm5,%ymm7
  1e851a:	vpor   %ymm7,%ymm6,%ymm6
  1e851e:	vmovupd 0x650(%rsp),%ymm7
  1e8527:	vblendvpd %ymm7,%ymm2,%ymm6,%ymm2
  1e852d:	vpsllq $0x34,%ymm0,%ymm6
  1e8532:	vpand  0x330(%rsp),%ymm5,%ymm7
  1e853b:	vpor   %ymm7,%ymm6,%ymm6
  1e853f:	vmovupd 0x2f0(%rsp),%ymm7
  1e8548:	vblendvpd %ymm7,0x670(%rsp),%ymm6,%ymm3
  1e8553:	vmovdqu 0x2a0(%rsp),%ymm6
  1e855c:	vpsllq $0x34,%ymm6,%ymm6
  1e8561:	vpand  0x3c0(%rsp),%ymm5,%ymm7
  1e856a:	vpor   %ymm7,%ymm6,%ymm6
  1e856e:	vmovupd 0x260(%rsp),%ymm7
  1e8577:	vblendvpd %ymm7,%ymm4,%ymm6,%ymm4
  1e857d:	vmovdqu 0x580(%rsp),%ymm6
  1e8586:	vpsllq $0x34,%ymm6,%ymm6
  1e858b:	vpand  0x5a0(%rsp),%ymm5,%ymm7
  1e8594:	vpor   %ymm7,%ymm6,%ymm6
  1e8598:	vblendvpd %ymm9,0x140(%rsp),%ymm6,%ymm0
  1e85a3:	vpsllq $0x34,%ymm11,%ymm6
  1e85a9:	vpand  0x4f0(%rsp),%ymm5,%ymm7
  1e85b2:	vpor   %ymm7,%ymm6,%ymm6
  1e85b6:	vmovupd 0x540(%rsp),%ymm7
  1e85bf:	vblendvpd %ymm7,0x280(%rsp),%ymm6,%ymm8
  1e85ca:	vmovdqu 0x4d0(%rsp),%ymm6
  1e85d3:	vpsllq $0x34,%ymm6,%ymm6
  1e85d8:	vpand  0x430(%rsp),%ymm5,%ymm7
  1e85e1:	vpor   %ymm7,%ymm6,%ymm6
  1e85e5:	vmovupd 0x620(%rsp),%ymm7
  1e85ee:	vblendvpd %ymm7,0x1e0(%rsp),%ymm6,%ymm7
  1e85f9:	vmovdqu 0x560(%rsp),%ymm6
  1e8602:	vpsllq $0x34,%ymm6,%ymm6
  1e8607:	vpand  0x3f0(%rsp),%ymm5,%ymm9
  1e8610:	vpor   %ymm6,%ymm9,%ymm6
  1e8614:	vmovupd 0x3a0(%rsp),%ymm9
  1e861d:	vblendvpd %ymm9,0x360(%rsp),%ymm6,%ymm6
  1e8628:	vpand  0x520(%rsp),%ymm5,%ymm5
  1e8631:	vpsllq $0x34,%ymm1,%ymm1
  1e8636:	vpor   %ymm5,%ymm1,%ymm1
  1e863a:	vblendvpd %ymm14,0x190(%rsp),%ymm1,%ymm5
  1e8645:	lea    0x7a0(%rsp),%rsi
  1e864d:	vxorpd %xmm1,%xmm1,%xmm1
  1e8651:	vmovupd %ymm1,(%rsi)
  1e8655:	vmovupd %ymm1,0x820(%rsp)
  1e865e:	vmovupd %ymm1,0x800(%rsp)
  1e8667:	vmovupd %ymm1,0x7e0(%rsp)
  1e8670:	vmovupd %ymm1,0x7c0(%rsp)
  1e8679:	vmovupd %ymm1,0x740(%rsp)
  1e8682:	vmovupd %ymm1,0x760(%rsp)
  1e868b:	vmovupd %ymm1,0x780(%rsp)
  1e8694:	mov    0x115465(%rip),%rdi        # 2fdb00 <_DYNAMIC+0xa78>
  1e869b:	mov    0x808(%rdi),%rdx
  1e86a2:	lea    0x7c0(%rsp),%rax
  1e86aa:	lea    0x2(%rip),%rcx        # 1e86b3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5503>
  1e86b1:	jmp    *%rdx
  1e86b3:	mov    0x808(%rdi),%rdx
  1e86ba:	lea    0x740(%rsp),%rax
  1e86c2:	vmovapd %ymm8,%ymm0
  1e86c6:	lea    0x2(%rip),%rcx        # 1e86cf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x551f>
  1e86cd:	jmp    *%rdx
  1e86cf:	mov    0x808(%rdi),%rdx
  1e86d6:	lea    0x7e0(%rsp),%rax
  1e86de:	vmovapd %ymm4,%ymm0
  1e86e2:	lea    0x2(%rip),%rcx        # 1e86eb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x553b>
  1e86e9:	jmp    *%rdx
  1e86eb:	mov    0x808(%rdi),%rdx
  1e86f2:	lea    0x760(%rsp),%rax
  1e86fa:	vmovapd %ymm7,%ymm0
  1e86fe:	lea    0x2(%rip),%rcx        # 1e8707 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5557>
  1e8705:	jmp    *%rdx
  1e8707:	mov    0x808(%rdi),%rdx
  1e870e:	lea    0x800(%rsp),%rax
  1e8716:	vmovapd %ymm3,%ymm0
  1e871a:	lea    0x2(%rip),%rcx        # 1e8723 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5573>
  1e8721:	jmp    *%rdx
  1e8723:	mov    0x808(%rdi),%rdx
  1e872a:	lea    0x780(%rsp),%rax
  1e8732:	vmovapd %ymm6,%ymm0
  1e8736:	lea    0x2(%rip),%rcx        # 1e873f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x558f>
  1e873d:	jmp    *%rdx
  1e873f:	mov    0x808(%rdi),%rdx
  1e8746:	lea    0x820(%rsp),%rax
  1e874e:	vmovapd %ymm2,%ymm0
  1e8752:	lea    0x2(%rip),%rcx        # 1e875b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x55ab>
  1e8759:	jmp    *%rdx
  1e875b:	mov    0x808(%rdi),%rdx
  1e8762:	mov    %rsi,%rax
  1e8765:	vmovapd %ymm5,%ymm0
  1e8769:	lea    0x2(%rip),%rcx        # 1e8772 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x55c2>
  1e8770:	jmp    *%rdx
  1e8772:	vmovupd 0x7c0(%rsp),%ymm0
  1e877b:	vmovupd 0x7e0(%rsp),%ymm1
  1e8784:	vinsertf128 $0x1,0x760(%rsp),%ymm1,%ymm1
  1e878f:	vinsertf128 $0x1,0x740(%rsp),%ymm0,%ymm0
  1e879a:	vunpcklpd %ymm1,%ymm0,%ymm2
  1e879e:	vaddpd 0x218(%rsp),%ymm2,%ymm2
  1e87a7:	vunpckhpd %ymm1,%ymm0,%ymm0
  1e87ab:	vaddpd %ymm0,%ymm2,%ymm0
  1e87af:	vmovapd 0x7f0(%rsp),%xmm1
  1e87b8:	vmovapd 0x7d0(%rsp),%xmm2
  1e87c1:	vunpcklpd %xmm1,%xmm2,%xmm3
  1e87c5:	vmovupd 0x740(%rsp),%ymm4
  1e87ce:	vmovupd 0x760(%rsp),%ymm5
  1e87d7:	vunpcklpd %ymm5,%ymm4,%ymm6
  1e87db:	vblendpd $0xc,%ymm6,%ymm3,%ymm3
  1e87e1:	vmovupd 0x780(%rsp),%ymm6
  1e87ea:	vaddpd %ymm3,%ymm0,%ymm0
  1e87ee:	vunpckhpd %xmm1,%xmm2,%xmm1
  1e87f2:	vunpckhpd %ymm5,%ymm4,%ymm2
  1e87f6:	vblendpd $0xc,%ymm2,%ymm1,%ymm1
  1e87fc:	vaddpd %ymm1,%ymm0,%ymm0
  1e8800:	vmovupd %ymm0,0x218(%rsp)
  1e8809:	vmovupd 0x7a0(%rsp),%ymm0
  1e8812:	vmovupd 0x820(%rsp),%ymm1
  1e881b:	vinsertf128 $0x1,0x7a0(%rsp),%ymm1,%ymm1
  1e8826:	vmovupd 0x800(%rsp),%ymm2
  1e882f:	vinsertf128 $0x1,0x780(%rsp),%ymm2,%ymm2
  1e883a:	vunpcklpd %ymm1,%ymm2,%ymm3
  1e883e:	vaddpd 0x238(%rsp),%ymm3,%ymm3
  1e8847:	vunpckhpd %ymm1,%ymm2,%ymm1
  1e884b:	vaddpd %ymm1,%ymm3,%ymm1
  1e884f:	vmovapd 0x830(%rsp),%xmm2
  1e8858:	vmovapd 0x810(%rsp),%xmm3
  1e8861:	vunpcklpd %xmm2,%xmm3,%xmm4
  1e8865:	vunpcklpd %ymm0,%ymm6,%ymm5
  1e8869:	vblendpd $0xc,%ymm5,%ymm4,%ymm4
  1e886f:	vaddpd %ymm4,%ymm1,%ymm1
  1e8873:	vunpckhpd %xmm2,%xmm3,%xmm2
  1e8877:	vunpckhpd %ymm0,%ymm6,%ymm0
  1e887b:	vblendpd $0xc,%ymm0,%ymm2,%ymm0
  1e8881:	vaddpd %ymm0,%ymm1,%ymm0
  1e8885:	vmovupd %ymm0,0x238(%rsp)
  1e888e:	jmp    1e7eb3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x4d03>
  1e8893:	mov    0x1b0(%rsp),%rdx
  1e889b:	mov    %edx,%eax
  1e889d:	vmovsd 0x218(%rsp),%xmm0
  1e88a6:	vmovsd %xmm0,0x28(%rsp)
  1e88ac:	vmovsd 0x220(%rsp),%xmm0
  1e88b5:	vmovsd %xmm0,0x18(%rsp)
  1e88bb:	vmovsd 0x228(%rsp),%xmm0
  1e88c4:	vmovsd %xmm0,0x120(%rsp)
  1e88cd:	and    $0x3,%eax
  1e88d0:	mov    %rax,0x40(%rsp)
  1e88d5:	je     1e8e8c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5cdc>
  1e88db:	movabs $0xffffffffffffffc,%rcx
  1e88e5:	and    %rdx,%rcx
  1e88e8:	mov    0x10(%rsp),%rax
  1e88ed:	lea    (%rax,%rcx,8),%r15
  1e88f1:	mov    %rdx,%rax
  1e88f4:	and    $0xfffffffffffffffc,%rax
  1e88f8:	mov    %rax,0x1e0(%rsp)
  1e8900:	vmovsd 0x230(%rsp),%xmm0
  1e8909:	vmovsd %xmm0,0x140(%rsp)
  1e8912:	vmovsd 0x238(%rsp),%xmm0
  1e891b:	vmovsd %xmm0,0x10(%rsp)
  1e8921:	vmovsd 0x248(%rsp),%xmm3
  1e892a:	mov    0x458(%rsp),%rax
  1e8932:	mov    %rax,0x50(%rsp)
  1e8937:	mov    0x468(%rsp),%rax
  1e893f:	mov    %rax,0x60(%rsp)
  1e8944:	mov    0x478(%rsp),%rax
  1e894c:	mov    %rax,0x48(%rsp)
  1e8951:	mov    0x488(%rsp),%rax
  1e8959:	mov    %rax,0x260(%rsp)
  1e8961:	mov    0x498(%rsp),%rax
  1e8969:	mov    %rax,0x68(%rsp)
  1e896e:	mov    0x4a8(%rsp),%rax
  1e8976:	mov    %rax,0x3c0(%rsp)
  1e897e:	vmovsd 0x240(%rsp),%xmm0
  1e8987:	vmovsd %xmm0,0x20(%rsp)
  1e898d:	vmovsd 0x250(%rsp),%xmm4
  1e8996:	shl    $0x3,%rdx
  1e899a:	and    $0xffffffffffffffe0,%rdx
  1e899e:	mov    0x4c0(%rsp),%rax
  1e89a6:	add    %rdx,%rax
  1e89a9:	mov    %rax,0x650(%rsp)
  1e89b1:	mov    0x4a0(%rsp),%rax
  1e89b9:	add    %rdx,%rax
  1e89bc:	mov    %rax,0x670(%rsp)
  1e89c4:	mov    0x480(%rsp),%rax
  1e89cc:	add    %rdx,%rax
  1e89cf:	mov    %rax,0x2f0(%rsp)
  1e89d7:	mov    0x460(%rsp),%rax
  1e89df:	add    %rdx,%rax
  1e89e2:	mov    %rax,0x2a0(%rsp)
  1e89ea:	mov    0x4b0(%rsp),%rax
  1e89f2:	add    %rdx,%rax
  1e89f5:	mov    %rax,0x310(%rsp)
  1e89fd:	mov    0x490(%rsp),%rax
  1e8a05:	add    %rdx,%rax
  1e8a08:	mov    %rax,0x360(%rsp)
  1e8a10:	mov    0x470(%rsp),%rax
  1e8a18:	add    %rdx,%rax
  1e8a1b:	mov    %rax,0x280(%rsp)
  1e8a23:	add    0x450(%rsp),%rdx
  1e8a2b:	mov    0x4b8(%rsp),%rax
  1e8a33:	mov    %rax,0x190(%rsp)
  1e8a3b:	mov    0x4c8(%rsp),%rax
  1e8a43:	mov    %rax,0x330(%rsp)
  1e8a4b:	xor    %r14d,%r14d
  1e8a4e:	mov    0x11509b(%rip),%rbx        # 2fdaf0 <_DYNAMIC+0xa68>
  1e8a55:	mov    0x160(%rsp),%rsi
  1e8a5d:	nopl   (%rax)
  1e8a60:	cmp    %r14,%rsi
  1e8a63:	je     1ebb90 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x89e0>
  1e8a69:	mov    0xb8(%rsp),%rax
  1e8a71:	mov    (%rax,%r14,8),%rbp
  1e8a75:	test   %rbp,%rbp
  1e8a78:	je     1e8c90 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5ae0>
  1e8a7e:	mov    0x1e0(%rsp),%rax
  1e8a86:	lea    (%rax,%r14,1),%r13
  1e8a8a:	cmp    0x50(%rsp),%r13
  1e8a8f:	jae    1ebd02 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8b52>
  1e8a95:	vmovsd %xmm4,0x70(%rsp)
  1e8a9b:	vmovsd %xmm3,0x1b0(%rsp)
  1e8aa4:	cmp    0x48(%rsp),%r13
  1e8aa9:	jae    1ebce0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8b30>
  1e8aaf:	mov    %rdx,%r12
  1e8ab2:	vmovsd (%rdx,%r14,8),%xmm0
  1e8ab8:	mov    0x280(%rsp),%rax
  1e8ac0:	vmovsd (%rax,%r14,8),%xmm1
  1e8ac6:	vmovsd (%r15,%r14,8),%xmm2
  1e8acc:	vmovsd %xmm2,0x58(%rsp)
  1e8ad2:	mov    %rbp,%rdi
  1e8ad5:	vzeroupper
  1e8ad8:	call   *%rbx
  1e8ada:	vmovsd 0x28(%rsp),%xmm2
  1e8ae0:	vaddsd %xmm2,%xmm0,%xmm2
  1e8ae4:	vmovsd %xmm2,0x218(%rsp)
  1e8aed:	vmovsd 0x18(%rsp),%xmm0
  1e8af3:	vaddsd %xmm0,%xmm1,%xmm0
  1e8af7:	vmovsd %xmm0,0x220(%rsp)
  1e8b00:	cmp    0x68(%rsp),%r13
  1e8b05:	jae    1ebcbe <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8b0e>
  1e8b0b:	vmovsd %xmm0,0x18(%rsp)
  1e8b11:	vmovsd %xmm2,0x28(%rsp)
  1e8b17:	cmp    0x190(%rsp),%r13
  1e8b1f:	jae    1ebc99 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8ae9>
  1e8b25:	mov    0x360(%rsp),%rax
  1e8b2d:	vmovsd (%rax,%r14,8),%xmm0
  1e8b33:	mov    0x310(%rsp),%rax
  1e8b3b:	vmovsd (%rax,%r14,8),%xmm1
  1e8b41:	vmovsd 0x58(%rsp),%xmm2
  1e8b47:	mov    %rbp,%rdi
  1e8b4a:	call   *%rbx
  1e8b4c:	vmovsd 0x120(%rsp),%xmm2
  1e8b55:	vaddsd %xmm2,%xmm0,%xmm2
  1e8b59:	vmovsd %xmm2,0x120(%rsp)
  1e8b62:	vmovsd %xmm2,0x228(%rsp)
  1e8b6b:	vmovsd 0x140(%rsp),%xmm0
  1e8b74:	vaddsd %xmm0,%xmm1,%xmm0
  1e8b78:	vmovsd %xmm0,0x140(%rsp)
  1e8b81:	vmovsd %xmm0,0x230(%rsp)
  1e8b8a:	cmp    0x60(%rsp),%r13
  1e8b8f:	jae    1ebcf8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8b48>
  1e8b95:	cmp    0x260(%rsp),%r13
  1e8b9d:	jae    1ebcd3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8b23>
  1e8ba3:	mov    0x2a0(%rsp),%rax
  1e8bab:	vmovsd (%rax,%r14,8),%xmm0
  1e8bb1:	mov    0x2f0(%rsp),%rax
  1e8bb9:	vmovsd (%rax,%r14,8),%xmm1
  1e8bbf:	vmovsd (%r15,%r14,8),%xmm2
  1e8bc5:	vmovsd %xmm2,0x58(%rsp)
  1e8bcb:	mov    %rbp,%rdi
  1e8bce:	call   *%rbx
  1e8bd0:	vmovsd 0x10(%rsp),%xmm2
  1e8bd6:	vaddsd %xmm2,%xmm0,%xmm2
  1e8bda:	vmovsd %xmm2,0x238(%rsp)
  1e8be3:	vmovsd 0x20(%rsp),%xmm0
  1e8be9:	vaddsd %xmm0,%xmm1,%xmm0
  1e8bed:	vmovsd %xmm0,0x240(%rsp)
  1e8bf6:	cmp    0x3c0(%rsp),%r13
  1e8bfe:	jae    1ebcb1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8b01>
  1e8c04:	vmovsd %xmm0,0x20(%rsp)
  1e8c0a:	vmovsd %xmm2,0x10(%rsp)
  1e8c10:	cmp    0x330(%rsp),%r13
  1e8c18:	jae    1ebc89 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8ad9>
  1e8c1e:	mov    0x670(%rsp),%rax
  1e8c26:	vmovsd (%rax,%r14,8),%xmm0
  1e8c2c:	mov    0x650(%rsp),%rax
  1e8c34:	vmovsd (%rax,%r14,8),%xmm1
  1e8c3a:	vmovsd 0x58(%rsp),%xmm2
  1e8c40:	mov    %rbp,%rdi
  1e8c43:	call   *%rbx
  1e8c45:	vmovsd 0x1b0(%rsp),%xmm3
  1e8c4e:	vaddsd %xmm3,%xmm0,%xmm3
  1e8c52:	vmovsd %xmm3,0x248(%rsp)
  1e8c5b:	vmovsd 0x70(%rsp),%xmm4
  1e8c61:	vaddsd %xmm4,%xmm1,%xmm4
  1e8c65:	mov    0x160(%rsp),%rsi
  1e8c6d:	mov    %r12,%rdx
  1e8c70:	inc    %r14
  1e8c73:	vmovsd %xmm4,0x250(%rsp)
  1e8c7c:	cmp    %r14,0x40(%rsp)
  1e8c81:	jne    1e8a60 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x58b0>
  1e8c87:	jmp    1e8ece <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5d1e>
  1e8c8c:	nopl   0x0(%rax)
  1e8c90:	vmovsd (%r15,%r14,8),%xmm0
  1e8c96:	vxorpd %xmm1,%xmm1,%xmm1
  1e8c9a:	vucomisd %xmm1,%xmm0
  1e8c9e:	jne    1e8ca2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5af2>
  1e8ca0:	jnp    1e8ce8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5b38>
  1e8ca2:	vandpd -0x1c362a(%rip),%xmm0,%xmm1        # 25680 <__abi_tag+0x25384>
  1e8caa:	vmovq  %xmm0,%rax
  1e8caf:	shr    $0x34,%rax
  1e8cb3:	and    $0x7ff,%eax
  1e8cb8:	cmp    $0x7ff,%eax
  1e8cbd:	setb   %al
  1e8cc0:	vucomisd -0x1c2928(%rip),%xmm1        # 263a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x5d0>
  1e8cc8:	jb     1e8a7e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x58ce>
  1e8cce:	test   %al,%al
  1e8cd0:	je     1e8a7e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x58ce>
  1e8cd6:	vmovsd -0x1c29b6(%rip),%xmm2        # 26328 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x558>
  1e8cde:	vucomisd %xmm1,%xmm2
  1e8ce2:	jb     1e8a7e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x58ce>
  1e8ce8:	mov    0x1e0(%rsp),%rax
  1e8cf0:	lea    (%rax,%r14,1),%rdi
  1e8cf4:	cmp    0x50(%rsp),%rdi
  1e8cf9:	jae    1ec0a7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8ef7>
  1e8cff:	vmulsd (%rdx,%r14,8),%xmm0,%xmm1
  1e8d05:	vmovsd 0x28(%rsp),%xmm2
  1e8d0b:	vaddsd %xmm1,%xmm2,%xmm2
  1e8d0f:	vmovsd %xmm2,0x28(%rsp)
  1e8d15:	vmovsd %xmm2,0x218(%rsp)
  1e8d1e:	cmp    0x48(%rsp),%rdi
  1e8d23:	jae    1ec0f1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8f41>
  1e8d29:	mov    0x280(%rsp),%rax
  1e8d31:	vmulsd (%rax,%r14,8),%xmm0,%xmm1
  1e8d37:	vmovsd 0x18(%rsp),%xmm2
  1e8d3d:	vaddsd %xmm1,%xmm2,%xmm2
  1e8d41:	vmovsd %xmm2,0x18(%rsp)
  1e8d47:	vmovsd %xmm2,0x220(%rsp)
  1e8d50:	cmp    0x68(%rsp),%rdi
  1e8d55:	jae    1ec088 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8ed8>
  1e8d5b:	mov    0x360(%rsp),%rax
  1e8d63:	vmulsd (%rax,%r14,8),%xmm0,%xmm1
  1e8d69:	vmovsd 0x120(%rsp),%xmm2
  1e8d72:	vaddsd %xmm1,%xmm2,%xmm2
  1e8d76:	vmovsd %xmm2,0x120(%rsp)
  1e8d7f:	vmovsd %xmm2,0x228(%rsp)
  1e8d88:	cmp    0x190(%rsp),%rdi
  1e8d90:	jae    1ec0cc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8f1c>
  1e8d96:	mov    0x310(%rsp),%rax
  1e8d9e:	vmulsd (%rax,%r14,8),%xmm0,%xmm1
  1e8da4:	vmovsd 0x140(%rsp),%xmm2
  1e8dad:	vaddsd %xmm1,%xmm2,%xmm2
  1e8db1:	vmovsd %xmm2,0x140(%rsp)
  1e8dba:	vmovsd %xmm2,0x230(%rsp)
  1e8dc3:	cmp    0x60(%rsp),%rdi
  1e8dc8:	jae    1ec09d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8eed>
  1e8dce:	mov    0x2a0(%rsp),%rax
  1e8dd6:	vmulsd (%rax,%r14,8),%xmm0,%xmm1
  1e8ddc:	vmovsd 0x10(%rsp),%xmm2
  1e8de2:	vaddsd %xmm1,%xmm2,%xmm2
  1e8de6:	vmovsd %xmm2,0x10(%rsp)
  1e8dec:	vmovsd %xmm2,0x238(%rsp)
  1e8df5:	cmp    0x260(%rsp),%rdi
  1e8dfd:	jae    1ec0e4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8f34>
  1e8e03:	mov    0x2f0(%rsp),%rax
  1e8e0b:	vmulsd (%rax,%r14,8),%xmm0,%xmm1
  1e8e11:	vmovsd 0x20(%rsp),%xmm2
  1e8e17:	vaddsd %xmm1,%xmm2,%xmm2
  1e8e1b:	vmovsd %xmm2,0x20(%rsp)
  1e8e21:	vmovsd %xmm2,0x240(%rsp)
  1e8e2a:	cmp    0x3c0(%rsp),%rdi
  1e8e32:	jae    1ec07b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8ecb>
  1e8e38:	mov    0x670(%rsp),%rax
  1e8e40:	vmulsd (%rax,%r14,8),%xmm0,%xmm1
  1e8e46:	vaddsd %xmm1,%xmm3,%xmm3
  1e8e4a:	vmovsd %xmm3,0x248(%rsp)
  1e8e53:	cmp    0x330(%rsp),%rdi
  1e8e5b:	jae    1ec0bc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8f0c>
  1e8e61:	mov    0x650(%rsp),%rax
  1e8e69:	vmulsd (%rax,%r14,8),%xmm0,%xmm0
  1e8e6f:	vaddsd %xmm0,%xmm4,%xmm4
  1e8e73:	inc    %r14
  1e8e76:	vmovsd %xmm4,0x250(%rsp)
  1e8e7f:	cmp    %r14,0x40(%rsp)
  1e8e84:	jne    1e8a60 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x58b0>
  1e8e8a:	jmp    1e8ece <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5d1e>
  1e8e8c:	vmovsd 0x230(%rsp),%xmm0
  1e8e95:	vmovsd %xmm0,0x140(%rsp)
  1e8e9e:	vmovsd 0x238(%rsp),%xmm0
  1e8ea7:	vmovsd %xmm0,0x10(%rsp)
  1e8ead:	vmovsd 0x240(%rsp),%xmm0
  1e8eb6:	vmovsd %xmm0,0x20(%rsp)
  1e8ebc:	vmovsd 0x248(%rsp),%xmm3
  1e8ec5:	vmovsd 0x250(%rsp),%xmm4
  1e8ece:	mov    0x30(%rsp),%rsi
  1e8ed3:	mov    0x3e8(%rsp),%rdi
  1e8edb:	cmp    %rsi,%rdi
  1e8ede:	jae    1ec398 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x91e8>
  1e8ee4:	mov    %rdi,%rax
  1e8ee7:	shl    $0x4,%rax
  1e8eeb:	mov    0x78(%rsp),%rcx
  1e8ef0:	vmovsd 0x28(%rsp),%xmm0
  1e8ef6:	vmovsd %xmm0,(%rcx,%rax,1)
  1e8efb:	vmovsd 0x18(%rsp),%xmm0
  1e8f01:	vmovsd %xmm0,0x8(%rcx,%rax,1)
  1e8f07:	mov    0x38(%rsp),%r8
  1e8f0c:	cmp    %r8,%rdi
  1e8f0f:	mov    0x2e8(%rsp),%rcx
  1e8f17:	jae    1ec3a8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x91f8>
  1e8f1d:	mov    0x80(%rsp),%r9
  1e8f25:	vmovsd 0x10(%rsp),%xmm0
  1e8f2b:	vmovsd %xmm0,(%r9,%rax,1)
  1e8f31:	mov    0x188(%rsp),%rdx
  1e8f39:	add    %rdx,%rcx
  1e8f3c:	add    $0xfffffffffffffffe,%rcx
  1e8f40:	vmovq  0x20(%rsp),%xmm0
  1e8f46:	vmovq  %xmm0,0x8(%r9,%rax,1)
  1e8f4d:	cmp    0xe0(%rsp),%rcx
  1e8f55:	jae    1e8fa8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5df8>
  1e8f57:	inc    %rdi
  1e8f5a:	cmp    %rsi,%rdi
  1e8f5d:	jae    1ec58c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x93dc>
  1e8f63:	mov    %rdi,%rax
  1e8f66:	shl    $0x4,%rax
  1e8f6a:	mov    0x78(%rsp),%rcx
  1e8f6f:	vmovsd 0x120(%rsp),%xmm0
  1e8f78:	vmovsd %xmm0,(%rcx,%rax,1)
  1e8f7d:	vmovq  0x140(%rsp),%xmm0
  1e8f86:	vmovq  %xmm0,0x8(%rcx,%rax,1)
  1e8f8c:	cmp    %r8,%rdi
  1e8f8f:	jae    1ec59c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x93ec>
  1e8f95:	mov    0x80(%rsp),%rcx
  1e8f9d:	vmovsd %xmm3,(%rcx,%rax,1)
  1e8fa2:	vmovsd %xmm4,0x8(%rcx,%rax,1)
  1e8fa8:	mov    $0x1,%al
  1e8faa:	jmp    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e8faf:	mov    %r12,0x88(%rsp)
  1e8fb7:	mov    %rbp,0x160(%rsp)
  1e8fbf:	mov    %r8,%rbp
  1e8fc2:	mov    %rdi,%r8
  1e8fc5:	movabs $0x1ffffffffffffffe,%rcx
  1e8fcf:	and    %rcx,%r8
  1e8fd2:	vxorpd %xmm1,%xmm1,%xmm1
  1e8fd6:	mov    %r14,%r12
  1e8fd9:	mov    %r9,%r14
  1e8fdc:	mov    $0x60,%r9d
  1e8fe2:	xor    %ecx,%ecx
  1e8fe4:	vxorpd %xmm3,%xmm3,%xmm3
  1e8fe8:	vxorpd %xmm2,%xmm2,%xmm2
  1e8fec:	vxorpd %xmm7,%xmm7,%xmm7
  1e8ff0:	vxorpd %xmm6,%xmm6,%xmm6
  1e8ff4:	vxorpd %xmm5,%xmm5,%xmm5
  1e8ff8:	vxorpd %xmm4,%xmm4,%xmm4
  1e8ffc:	vxorpd %xmm8,%xmm8,%xmm8
  1e9001:	mov    %rax,%r10
  1e9004:	mov    0x28(%rsp),%rax
  1e9009:	nopl   0x0(%rax)
  1e9010:	vmovupd -0x60(%r14,%r9,1),%ymm9
  1e9017:	vmovupd -0x40(%r14,%r9,1),%ymm10
  1e901e:	vmovupd -0x20(%r14,%r9,1),%ymm11
  1e9025:	vfmadd231pd -0x60(%r12,%r9,1),%ymm9,%ymm4
  1e902c:	vfmadd231pd -0x60(%rax,%r9,1),%ymm9,%ymm5
  1e9033:	vfmadd231pd -0x60(%rbp,%r9,1),%ymm9,%ymm6
  1e903a:	vfmadd231pd -0x60(%r10,%r9,1),%ymm9,%ymm7
  1e9041:	vfmadd231pd -0x40(%r12,%r9,1),%ymm10,%ymm2
  1e9048:	vfmadd231pd -0x40(%rax,%r9,1),%ymm10,%ymm3
  1e904f:	vfmadd231pd -0x40(%rbp,%r9,1),%ymm10,%ymm1
  1e9056:	vfmadd231pd -0x40(%r10,%r9,1),%ymm10,%ymm8
  1e905d:	vmovupd (%r14,%r9,1),%ymm9
  1e9063:	add    $0x2,%rcx
  1e9067:	vfmadd231pd -0x20(%r12,%r9,1),%ymm11,%ymm4
  1e906e:	vfmadd231pd -0x20(%rax,%r9,1),%ymm11,%ymm5
  1e9075:	vfmadd231pd -0x20(%rbp,%r9,1),%ymm11,%ymm6
  1e907c:	vfmadd231pd -0x20(%r10,%r9,1),%ymm11,%ymm7
  1e9083:	vfmadd231pd (%r12,%r9,1),%ymm9,%ymm2
  1e9089:	vfmadd231pd (%rax,%r9,1),%ymm9,%ymm3
  1e908f:	vfmadd231pd 0x0(%rbp,%r9,1),%ymm9,%ymm1
  1e9096:	vfmadd231pd (%r10,%r9,1),%ymm9,%ymm8
  1e909c:	sub    $0xffffffffffffff80,%r9
  1e90a0:	cmp    %rcx,%r8
  1e90a3:	jne    1e9010 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5e60>
  1e90a9:	test   $0x1,%dil
  1e90ad:	mov    %r14,%r9
  1e90b0:	mov    %r12,%r14
  1e90b3:	mov    %rbp,%r8
  1e90b6:	mov    %r10,%rax
  1e90b9:	movabs $0x3fffffffffffffe,%r10
  1e90c3:	mov    0x160(%rsp),%rbp
  1e90cb:	mov    0x88(%rsp),%r12
  1e90d3:	je     1e9129 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5f79>
  1e90d5:	shl    $0x6,%rcx
  1e90d9:	vmovupd (%r9,%rcx,1),%ymm9
  1e90df:	vmovupd 0x20(%r9,%rcx,1),%ymm10
  1e90e6:	vfmadd231pd (%r14,%rcx,1),%ymm9,%ymm4
  1e90ec:	mov    0x28(%rsp),%rax
  1e90f1:	vfmadd231pd (%rax,%rcx,1),%ymm9,%ymm5
  1e90f7:	vfmadd231pd (%r8,%rcx,1),%ymm9,%ymm6
  1e90fd:	mov    0x40(%rsp),%rdi
  1e9102:	vfmadd231pd (%rdi,%rcx,1),%ymm9,%ymm7
  1e9108:	vfmadd231pd 0x20(%r14,%rcx,1),%ymm10,%ymm2
  1e910f:	vfmadd231pd 0x20(%rax,%rcx,1),%ymm10,%ymm3
  1e9116:	mov    0x40(%rsp),%rax
  1e911b:	vfmadd231pd 0x20(%r8,%rcx,1),%ymm10,%ymm1
  1e9122:	vfmadd231pd 0x20(%rax,%rcx,1),%ymm10,%ymm8
  1e9129:	add    %r9,%rbp
  1e912c:	mov    %rbp,0x160(%rsp)
  1e9134:	testb  $0x4,0x1e0(%rsp)
  1e913c:	jne    1e914b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x5f9b>
  1e913e:	mov    0xf0(%rsp),%rbp
  1e9146:	jmp    1e920d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x605d>
  1e914b:	testb  $0x1,0x2c0(%rsp)
  1e9153:	mov    0xf0(%rsp),%rbp
  1e915b:	je     1ebd79 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8bc9>
  1e9161:	testb  $0x4,0x170(%rsp)
  1e9169:	je     1ebd8d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8bdd>
  1e916f:	testb  $0x4,0x180(%rsp)
  1e9177:	je     1ebda1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8bf1>
  1e917d:	testb  $0x4,0x178(%rsp)
  1e9185:	je     1ebdb5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8c05>
  1e918b:	testb  $0x4,0x1d8(%rsp)
  1e9193:	je     1ebdc9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8c19>
  1e9199:	mov    0x358(%rsp),%rcx
  1e91a1:	and    %r10,%rcx
  1e91a4:	mov    0x210(%rsp),%rdi
  1e91ac:	and    %r10,%rdi
  1e91af:	mov    0x5d0(%rsp),%rsi
  1e91b7:	and    %r10,%rsi
  1e91ba:	mov    0x5c0(%rsp),%r8
  1e91c2:	and    %r10,%r8
  1e91c5:	shl    $0x5,%rcx
  1e91c9:	shl    $0x5,%rdi
  1e91cd:	shl    $0x5,%rsi
  1e91d1:	shl    $0x5,%r8
  1e91d5:	add    %r14,%rcx
  1e91d8:	add    0x28(%rsp),%rdi
  1e91dd:	add    0x20(%rsp),%rsi
  1e91e2:	add    %rax,%r8
  1e91e5:	mov    0x160(%rsp),%rax
  1e91ed:	vmovupd (%rax),%ymm9
  1e91f1:	vfmadd231pd (%rcx),%ymm9,%ymm4
  1e91f6:	vfmadd231pd (%rdi),%ymm9,%ymm5
  1e91fb:	vfmadd231pd (%rsi),%ymm9,%ymm6
  1e9200:	vfmadd231pd (%r8),%ymm9,%ymm7
  1e9205:	mov    0x380(%rsp),%rsi
  1e920d:	vaddpd %ymm7,%ymm8,%ymm7
  1e9211:	vaddpd %ymm6,%ymm1,%ymm6
  1e9215:	vaddpd %ymm5,%ymm3,%ymm3
  1e9219:	vaddpd %ymm4,%ymm2,%ymm1
  1e921d:	vextractf128 $0x1,%ymm1,%xmm2
  1e9223:	vaddpd %xmm2,%xmm1,%xmm1
  1e9227:	vshufpd $0x1,%xmm1,%xmm1,%xmm2
  1e922c:	vaddsd %xmm2,%xmm1,%xmm1
  1e9230:	vextractf128 $0x1,%ymm3,%xmm2
  1e9236:	vaddpd %xmm2,%xmm3,%xmm2
  1e923a:	vshufpd $0x1,%xmm2,%xmm2,%xmm3
  1e923f:	vaddsd %xmm3,%xmm2,%xmm2
  1e9243:	vextractf128 $0x1,%ymm6,%xmm3
  1e9249:	vaddpd %xmm3,%xmm6,%xmm3
  1e924d:	vshufpd $0x1,%xmm3,%xmm3,%xmm4
  1e9252:	vaddsd %xmm4,%xmm3,%xmm3
  1e9256:	vextractf128 $0x1,%ymm7,%xmm4
  1e925c:	vaddpd %xmm4,%xmm7,%xmm4
  1e9260:	vshufpd $0x1,%xmm4,%xmm4,%xmm5
  1e9265:	vaddsd %xmm5,%xmm4,%xmm4
  1e9269:	mov    0x260(%rsp),%rax
  1e9271:	test   %rax,%rax
  1e9274:	mov    0x110(%rsp),%rdi
  1e927c:	je     1e937d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x61cd>
  1e9282:	lea    -0x1(%rax),%rcx
  1e9286:	cmp    %rdi,%rcx
  1e9289:	cmovae %rdi,%rcx
  1e928d:	cmp    %rbp,%rcx
  1e9290:	cmovae %rbp,%rcx
  1e9294:	cmp    %r12,%rcx
  1e9297:	cmovae %r12,%rcx
  1e929b:	mov    0x98(%rsp),%rax
  1e92a3:	cmp    %rax,%rcx
  1e92a6:	cmovae %rax,%rcx
  1e92aa:	jae    1ec4b4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9304>
  1e92b0:	cmp    %ecx,%r12d
  1e92b3:	je     1ec4ca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x931a>
  1e92b9:	cmp    %ecx,%ebp
  1e92bb:	je     1ec4e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9330>
  1e92c1:	mov    %rdx,0x10(%rsp)
  1e92c6:	cmp    %ecx,%edi
  1e92c8:	je     1ec20b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x905b>
  1e92ce:	vmovsd (%r9,%rsi,8),%xmm5
  1e92d4:	mov    0x2a0(%rsp),%rdi
  1e92dc:	vfmadd231sd (%r14,%rdi,8),%xmm5,%xmm1
  1e92e2:	mov    0x28(%rsp),%rax
  1e92e7:	mov    0x520(%rsp),%r8
  1e92ef:	vfmadd231sd (%rax,%r8,8),%xmm5,%xmm2
  1e92f5:	mov    0x4f0(%rsp),%r10
  1e92fd:	mov    0x20(%rsp),%rdx
  1e9302:	vfmadd231sd (%rdx,%r10,8),%xmm5,%xmm3
  1e9308:	mov    0x40(%rsp),%rcx
  1e930d:	mov    %rsi,%rbp
  1e9310:	mov    0x600(%rsp),%rsi
  1e9318:	vfmadd231sd (%rcx,%rsi,8),%xmm5,%xmm4
  1e931e:	mov    0x260(%rsp),%r12
  1e9326:	cmp    $0x1,%r12d
  1e932a:	je     1e9378 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x61c8>
  1e932c:	vmovsd 0x8(%r9,%rbp,8),%xmm5
  1e9333:	vfmadd231sd 0x8(%r14,%rdi,8),%xmm5,%xmm1
  1e933a:	vfmadd231sd 0x8(%rax,%r8,8),%xmm5,%xmm2
  1e9341:	vfmadd231sd 0x8(%rdx,%r10,8),%xmm5,%xmm3
  1e9348:	vfmadd231sd 0x8(%rcx,%rsi,8),%xmm5,%xmm4
  1e934f:	cmp    $0x2,%r12d
  1e9353:	je     1e9378 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x61c8>
  1e9355:	vmovsd 0x10(%r9,%rbp,8),%xmm5
  1e935c:	vfmadd231sd 0x10(%r14,%rdi,8),%xmm5,%xmm1
  1e9363:	vfmadd231sd 0x10(%rax,%r8,8),%xmm5,%xmm2
  1e936a:	vfmadd231sd 0x10(%rdx,%r10,8),%xmm5,%xmm3
  1e9371:	vfmadd231sd 0x10(%rcx,%rsi,8),%xmm5,%xmm4
  1e9378:	mov    0x10(%rsp),%rdx
  1e937d:	mov    0x330(%rsp),%rcx
  1e9385:	shr    $0x3,%rcx
  1e9389:	mov    0x580(%rsp),%r12
  1e9391:	mov    %r12,%rdi
  1e9394:	shr    $0x3,%rdi
  1e9398:	cmp    %rcx,%rdi
  1e939b:	cmovae %rcx,%rdi
  1e939f:	mov    0x5a0(%rsp),%r14
  1e93a7:	mov    %r14,%r8
  1e93aa:	shr    $0x3,%r8
  1e93ae:	cmp    %rdi,%r8
  1e93b1:	cmovae %rdi,%r8
  1e93b5:	mov    0x410(%rsp),%r10
  1e93bd:	mov    %r10,%rcx
  1e93c0:	shr    $0x3,%rcx
  1e93c4:	cmp    %r8,%rcx
  1e93c7:	cmovae %r8,%rcx
  1e93cb:	cmp    %rcx,%rdx
  1e93ce:	cmovb  %rdx,%rcx
  1e93d2:	mov    0x200(%rsp),%rsi
  1e93da:	cmp    %rcx,%rsi
  1e93dd:	cmovb  %rsi,%rcx
  1e93e1:	test   %rcx,%rcx
  1e93e4:	mov    0x160(%rsp),%rbp
  1e93ec:	je     1e9430 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6280>
  1e93ee:	cmp    $0x1,%rcx
  1e93f2:	mov    0x330(%rsp),%rsi
  1e93fa:	jne    1e946a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x62ba>
  1e93fc:	vxorpd %xmm5,%xmm5,%xmm5
  1e9400:	xor    %edx,%edx
  1e9402:	vxorpd %xmm7,%xmm7,%xmm7
  1e9406:	vxorpd %xmm6,%xmm6,%xmm6
  1e940a:	vxorpd %xmm11,%xmm11,%xmm11
  1e940f:	vxorpd %xmm10,%xmm10,%xmm10
  1e9414:	vxorpd %xmm9,%xmm9,%xmm9
  1e9419:	vxorpd %xmm8,%xmm8,%xmm8
  1e941e:	vxorpd %xmm12,%xmm12,%xmm12
  1e9423:	mov    0x1e0(%rsp),%rax
  1e942b:	jmp    1e9556 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x63a6>
  1e9430:	vxorpd %xmm12,%xmm12,%xmm12
  1e9435:	vxorpd %xmm8,%xmm8,%xmm8
  1e943a:	vxorpd %xmm9,%xmm9,%xmm9
  1e943f:	vxorpd %xmm10,%xmm10,%xmm10
  1e9444:	vxorpd %xmm11,%xmm11,%xmm11
  1e9449:	vxorpd %xmm6,%xmm6,%xmm6
  1e944d:	vxorpd %xmm7,%xmm7,%xmm7
  1e9451:	vxorpd %xmm5,%xmm5,%xmm5
  1e9455:	mov    0x1e0(%rsp),%rax
  1e945d:	mov    0x330(%rsp),%rsi
  1e9465:	jmp    1e959c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x63ec>
  1e946a:	movabs $0x1ffffffffffffffe,%rax
  1e9474:	and    %rcx,%rax
  1e9477:	vxorpd %xmm5,%xmm5,%xmm5
  1e947b:	mov    $0x60,%edi
  1e9480:	xor    %edx,%edx
  1e9482:	vxorpd %xmm7,%xmm7,%xmm7
  1e9486:	vxorpd %xmm6,%xmm6,%xmm6
  1e948a:	vxorpd %xmm11,%xmm11,%xmm11
  1e948f:	vxorpd %xmm10,%xmm10,%xmm10
  1e9494:	vxorpd %xmm9,%xmm9,%xmm9
  1e9499:	vxorpd %xmm8,%xmm8,%xmm8
  1e949e:	vxorpd %xmm12,%xmm12,%xmm12
  1e94a3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e94b0:	vmovupd -0x60(%r9,%rdi,1),%ymm13
  1e94b7:	vmovupd -0x40(%r9,%rdi,1),%ymm14
  1e94be:	vmovupd -0x20(%r9,%rdi,1),%ymm15
  1e94c5:	vfmadd231pd -0x60(%r11,%rdi,1),%ymm13,%ymm8
  1e94cc:	vfmadd231pd -0x60(%rbx,%rdi,1),%ymm13,%ymm9
  1e94d3:	vfmadd231pd -0x60(%r15,%rdi,1),%ymm13,%ymm10
  1e94da:	vfmadd231pd -0x60(%r13,%rdi,1),%ymm13,%ymm11
  1e94e1:	vfmadd231pd -0x40(%r11,%rdi,1),%ymm14,%ymm6
  1e94e8:	vfmadd231pd -0x40(%rbx,%rdi,1),%ymm14,%ymm7
  1e94ef:	vfmadd231pd -0x40(%r15,%rdi,1),%ymm14,%ymm5
  1e94f6:	vfmadd231pd -0x40(%r13,%rdi,1),%ymm14,%ymm12
  1e94fd:	vmovupd (%r9,%rdi,1),%ymm13
  1e9503:	add    $0x2,%rdx
  1e9507:	vfmadd231pd -0x20(%r11,%rdi,1),%ymm15,%ymm8
  1e950e:	vfmadd231pd -0x20(%rbx,%rdi,1),%ymm15,%ymm9
  1e9515:	vfmadd231pd -0x20(%r15,%rdi,1),%ymm15,%ymm10
  1e951c:	vfmadd231pd -0x20(%r13,%rdi,1),%ymm15,%ymm11
  1e9523:	vfmadd231pd (%r11,%rdi,1),%ymm13,%ymm6
  1e9529:	vfmadd231pd (%rbx,%rdi,1),%ymm13,%ymm7
  1e952f:	vfmadd231pd (%r15,%rdi,1),%ymm13,%ymm5
  1e9535:	vfmadd231pd 0x0(%r13,%rdi,1),%ymm13,%ymm12
  1e953c:	sub    $0xffffffffffffff80,%rdi
  1e9540:	cmp    %rdx,%rax
  1e9543:	jne    1e94b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6300>
  1e9549:	test   $0x1,%cl
  1e954c:	mov    0x1e0(%rsp),%rax
  1e9554:	je     1e959c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x63ec>
  1e9556:	shl    $0x6,%rdx
  1e955a:	vmovupd (%r9,%rdx,1),%ymm13
  1e9560:	vmovupd 0x20(%r9,%rdx,1),%ymm14
  1e9567:	vfmadd231pd (%r11,%rdx,1),%ymm13,%ymm8
  1e956d:	vfmadd231pd (%rbx,%rdx,1),%ymm13,%ymm9
  1e9573:	vfmadd231pd (%r15,%rdx,1),%ymm13,%ymm10
  1e9579:	vfmadd231pd 0x0(%r13,%rdx,1),%ymm13,%ymm11
  1e9580:	vfmadd231pd 0x20(%r11,%rdx,1),%ymm14,%ymm6
  1e9587:	vfmadd231pd 0x20(%rbx,%rdx,1),%ymm14,%ymm7
  1e958e:	vfmadd231pd 0x20(%r15,%rdx,1),%ymm14,%ymm5
  1e9595:	vfmadd231pd 0x20(%r13,%rdx,1),%ymm14,%ymm12
  1e959c:	test   $0x4,%al
  1e959e:	je     1e9641 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6491>
  1e95a4:	testb  $0x1,0x2c0(%rsp)
  1e95ac:	je     1ebd79 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8bc9>
  1e95b2:	test   $0x4,%sil
  1e95b6:	je     1ebd8d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8bdd>
  1e95bc:	test   $0x4,%r12b
  1e95c0:	je     1ebda1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8bf1>
  1e95c6:	test   $0x4,%r14b
  1e95ca:	je     1ebdb5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8c05>
  1e95d0:	test   $0x4,%r10b
  1e95d4:	je     1ebdc9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8c19>
  1e95da:	mov    %rsi,%rdx
  1e95dd:	shr    $0x2,%rdx
  1e95e1:	mov    %r12,%rcx
  1e95e4:	shr    $0x2,%rcx
  1e95e8:	mov    %r14,%rdi
  1e95eb:	shr    $0x2,%rdi
  1e95ef:	mov    %r10,%r8
  1e95f2:	shr    $0x2,%r8
  1e95f6:	movabs $0x3fffffffffffffe,%rax
  1e9600:	and    %rax,%rdx
  1e9603:	and    %rax,%rcx
  1e9606:	and    %rax,%rdi
  1e9609:	and    %rax,%r8
  1e960c:	shl    $0x5,%rdx
  1e9610:	shl    $0x5,%rcx
  1e9614:	shl    $0x5,%rdi
  1e9618:	shl    $0x5,%r8
  1e961c:	add    %r11,%rdx
  1e961f:	add    %rbx,%rcx
  1e9622:	add    %r15,%rdi
  1e9625:	add    %r13,%r8
  1e9628:	vmovupd 0x0(%rbp),%ymm13
  1e962d:	vfmadd231pd (%rdx),%ymm13,%ymm8
  1e9632:	vfmadd231pd (%rcx),%ymm13,%ymm9
  1e9637:	vfmadd231pd (%rdi),%ymm13,%ymm10
  1e963c:	vfmadd231pd (%r8),%ymm13,%ymm11
  1e9641:	mov    0x38(%rsp),%rax
  1e9646:	vaddpd %ymm11,%ymm12,%ymm11
  1e964b:	vaddpd %ymm5,%ymm10,%ymm5
  1e964f:	vaddpd %ymm7,%ymm9,%ymm9
  1e9653:	vaddpd %ymm6,%ymm8,%ymm6
  1e9657:	vextractf128 $0x1,%ymm6,%xmm7
  1e965d:	vaddpd %xmm7,%xmm6,%xmm6
  1e9661:	vshufpd $0x1,%xmm6,%xmm6,%xmm7
  1e9666:	vaddsd %xmm7,%xmm6,%xmm7
  1e966a:	vextractf128 $0x1,%ymm9,%xmm6
  1e9670:	vaddpd %xmm6,%xmm9,%xmm6
  1e9674:	vshufpd $0x1,%xmm6,%xmm6,%xmm8
  1e9679:	vaddsd %xmm6,%xmm8,%xmm8
  1e967d:	vextractf128 $0x1,%ymm5,%xmm6
  1e9683:	vaddpd %xmm6,%xmm5,%xmm5
  1e9687:	vshufpd $0x1,%xmm5,%xmm5,%xmm6
  1e968c:	vaddsd %xmm6,%xmm5,%xmm5
  1e9690:	vextractf128 $0x1,%ymm11,%xmm6
  1e9696:	vaddpd %xmm6,%xmm11,%xmm6
  1e969a:	vshufpd $0x1,%xmm6,%xmm6,%xmm9
  1e969f:	vaddsd %xmm6,%xmm9,%xmm6
  1e96a3:	mov    0x260(%rsp),%rbp
  1e96ab:	test   %rbp,%rbp
  1e96ae:	je     1e97b1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6601>
  1e96b4:	mov    %r9,%rcx
  1e96b7:	mov    %esi,%r8d
  1e96ba:	and    $0x3,%r8d
  1e96be:	mov    %r12d,%eax
  1e96c1:	and    $0x3,%eax
  1e96c4:	mov    %r14d,%r9d
  1e96c7:	and    $0x3,%r9d
  1e96cb:	mov    %r10d,%edi
  1e96ce:	and    $0x3,%edi
  1e96d1:	lea    -0x1(%rbp),%rdx
  1e96d5:	cmp    %rdi,%rdx
  1e96d8:	cmovae %rdi,%rdx
  1e96dc:	cmp    %r9,%rdx
  1e96df:	cmovae %r9,%rdx
  1e96e3:	cmp    %rax,%rdx
  1e96e6:	cmovae %rax,%rdx
  1e96ea:	cmp    %r8,%rdx
  1e96ed:	cmovae %r8,%rdx
  1e96f1:	jae    1ec4f6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9346>
  1e96f7:	cmp    %edx,%eax
  1e96f9:	je     1ec50c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x935c>
  1e96ff:	cmp    %edx,%r9d
  1e9702:	je     1ec522 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9372>
  1e9708:	cmp    %edx,%edi
  1e970a:	je     1ec20b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x905b>
  1e9710:	movabs $0xffffffffffffffc,%rax
  1e971a:	and    %rax,%rsi
  1e971d:	and    %rax,%r12
  1e9720:	and    %rax,%r14
  1e9723:	mov    0x380(%rsp),%rdi
  1e972b:	vmovsd (%rcx,%rdi,8),%xmm9
  1e9730:	vfmadd231sd (%r11,%rsi,8),%xmm9,%xmm7
  1e9736:	vfmadd231sd (%rbx,%r12,8),%xmm9,%xmm8
  1e973c:	vfmadd231sd (%r15,%r14,8),%xmm9,%xmm5
  1e9742:	and    %rax,%r10
  1e9745:	vfmadd231sd 0x0(%r13,%r10,8),%xmm9,%xmm6
  1e974c:	cmp    $0x1,%ebp
  1e974f:	mov    0x38(%rsp),%rax
  1e9754:	mov    %rsi,%rdx
  1e9757:	mov    0x30(%rsp),%rsi
  1e975c:	mov    0x2e8(%rsp),%r8
  1e9764:	je     1e97be <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x660e>
  1e9766:	vmovsd 0x8(%rcx,%rdi,8),%xmm9
  1e976c:	vfmadd231sd 0x8(%r11,%rdx,8),%xmm9,%xmm7
  1e9773:	vfmadd231sd 0x8(%rbx,%r12,8),%xmm9,%xmm8
  1e977a:	vfmadd231sd 0x8(%r15,%r14,8),%xmm9,%xmm5
  1e9781:	vfmadd231sd 0x8(%r13,%r10,8),%xmm9,%xmm6
  1e9788:	cmp    $0x2,%ebp
  1e978b:	je     1e97be <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x660e>
  1e978d:	vmovsd 0x10(%rcx,%rdi,8),%xmm9
  1e9793:	vfmadd231sd 0x10(%r11,%rdx,8),%xmm9,%xmm7
  1e979a:	vfmadd231sd 0x10(%rbx,%r12,8),%xmm9,%xmm8
  1e97a1:	vfmadd231sd 0x10(%r15,%r14,8),%xmm9,%xmm5
  1e97a8:	vfmadd231sd 0x10(%r13,%r10,8),%xmm9,%xmm6
  1e97af:	jmp    1e97be <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x660e>
  1e97b1:	mov    0x30(%rsp),%rsi
  1e97b6:	mov    0x2e8(%rsp),%r8
  1e97be:	and    $0xfffffffffffffffe,%r8
  1e97c2:	lea    -0x2(%r8),%rdi
  1e97c6:	cmp    %rax,%rdi
  1e97c9:	jae    1ec17b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8fcb>
  1e97cf:	mov    %rdi,%rax
  1e97d2:	shl    $0x4,%rax
  1e97d6:	mov    0x80(%rsp),%rdx
  1e97de:	vmovsd %xmm7,(%rdx,%rax,1)
  1e97e3:	mov    0x188(%rsp),%rcx
  1e97eb:	add    %r8,%rcx
  1e97ee:	add    $0xfffffffffffffffe,%rcx
  1e97f2:	vmovsd %xmm8,0x8(%rdx,%rax,1)
  1e97f8:	cmp    0xe0(%rsp),%rcx
  1e9800:	jae    1e9864 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x66b4>
  1e9802:	dec    %r8
  1e9805:	mov    0x38(%rsp),%rcx
  1e980a:	cmp    %rcx,%r8
  1e980d:	jae    1ec576 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x93c6>
  1e9813:	mov    %r8,%rcx
  1e9816:	shl    $0x4,%rcx
  1e981a:	mov    0x80(%rsp),%rdx
  1e9822:	vmovsd %xmm5,(%rdx,%rcx,1)
  1e9827:	vmovsd %xmm6,0x8(%rdx,%rcx,1)
  1e982d:	cmp    %rsi,%rdi
  1e9830:	jae    1ec301 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9151>
  1e9836:	mov    0x78(%rsp),%rcx
  1e983b:	vmovsd %xmm1,(%rcx,%rax,1)
  1e9840:	vmovsd %xmm2,0x8(%rcx,%rax,1)
  1e9846:	cmp    %rsi,%r8
  1e9849:	movzbl 0x190(%rsp),%edx
  1e9851:	jae    1ec579 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x93c9>
  1e9857:	mov    %r8,%rdi
  1e985a:	vmovapd %xmm3,%xmm1
  1e985e:	vmovapd %xmm4,%xmm2
  1e9862:	jmp    1e9875 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x66c5>
  1e9864:	cmp    %rsi,%rdi
  1e9867:	jae    1ec301 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9151>
  1e986d:	movzbl 0x190(%rsp),%edx
  1e9875:	shl    $0x4,%rdi
  1e9879:	mov    0x78(%rsp),%rax
  1e987e:	vmovsd %xmm1,(%rax,%rdi,1)
  1e9883:	vmovsd %xmm2,0x8(%rax,%rdi,1)
  1e9889:	vxorpd %xmm1,%xmm1,%xmm1
  1e988d:	vpcmpgtq %ymm0,%ymm1,%ymm0
  1e9892:	vpbroadcastq -0x1c35f3(%rip),%ymm1        # 262a8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x4d8>
  1e989b:	vpand  %ymm1,%ymm0,%ymm0
  1e989f:	vextracti128 $0x1,%ymm0,%xmm1
  1e98a5:	vminpd %xmm1,%xmm0,%xmm0
  1e98a9:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e98ae:	vminsd %xmm1,%xmm0,%xmm0
  1e98b2:	xor    %ecx,%ecx
  1e98b4:	vxorpd %xmm1,%xmm1,%xmm1
  1e98b8:	vucomisd %xmm1,%xmm0
  1e98bc:	movzbl %dl,%eax
  1e98bf:	cmovbe %ecx,%eax
  1e98c2:	mov    0x878(%rsp),%rcx
  1e98ca:	mov    %al,0x8(%rcx)
  1e98cd:	movq   $0xffffffffffffffff,(%rcx)
  1e98d4:	add    $0xb28,%rsp
  1e98db:	pop    %rbx
  1e98dc:	pop    %r12
  1e98de:	pop    %r13
  1e98e0:	pop    %r14
  1e98e2:	pop    %r15
  1e98e4:	pop    %rbp
  1e98e5:	vzeroupper
  1e98e8:	ret
  1e98e9:	mov    %rbx,0x140(%rsp)
  1e98f1:	movabs $0xffffffffffffffc,%rax
  1e98fb:	mov    %rdi,%rdx
  1e98fe:	jmp    1e3e69 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0xcb9>
  1e9903:	lea    0x4(%r14),%rsi
  1e9907:	lea    0x108a4a(%rip),%rcx        # 2f2358 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf98>
  1e990e:	mov    %r14,%rdi
  1e9911:	mov    0x200(%rsp),%rdx
  1e9919:	vzeroupper
  1e991c:	call   *0x113aae(%rip)        # 2fd3d0 <_DYNAMIC+0x348>
  1e9922:	cmp    %r13,0x210(%rsp)
  1e992a:	jne    1e6d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bad>
  1e9930:	mov    0x850(%rsp),%rcx
  1e9938:	inc    %rcx
  1e993b:	xor    %eax,%eax
  1e993d:	cmp    %rcx,%rsi
  1e9940:	jb     1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e9942:	cmp    %r13,0x1d8(%rsp)
  1e994a:	mov    0x410(%rsp),%rcx
  1e9952:	mov    0x5a0(%rsp),%rdx
  1e995a:	mov    0x580(%rsp),%rsi
  1e9962:	mov    0x330(%rsp),%r8
  1e996a:	mov    0x178(%rsp),%r9
  1e9972:	mov    0x180(%rsp),%r10
  1e997a:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e9980:	cmp    %r13,%r9
  1e9983:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e9989:	cmp    %r13,%r10
  1e998c:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e9992:	cmp    %r13,0x170(%rsp)
  1e999a:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e99a0:	cmp    %r13,0x3c0(%rsp)
  1e99a8:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e99ae:	cmp    %r13,%r8
  1e99b1:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e99b7:	cmp    %r13,%rsi
  1e99ba:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e99c0:	cmp    %r13,%rdx
  1e99c3:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e99c9:	cmp    %r13,%rcx
  1e99cc:	jne    1e98c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6712>
  1e99d2:	xor    %ecx,%ecx
  1e99d4:	mov    0x118(%rsp),%rax
  1e99dc:	sub    $0x2,%rax
  1e99e0:	cmovae %rax,%rcx
  1e99e4:	movb   $0x1,0x140(%rsp)
  1e99ec:	mov    0xd0(%rsp),%r10
  1e99f4:	mov    %rcx,0x310(%rsp)
  1e99fc:	cmp    %rcx,%r10
  1e99ff:	jae    1e9b4f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x699f>
  1e9a05:	mov    0xc0(%rsp),%rsi
  1e9a0d:	mov    0xf0(%rsp),%r8
  1e9a15:	cmp    %r8,%rsi
  1e9a18:	mov    %r8,%rcx
  1e9a1b:	cmovb  %rsi,%rcx
  1e9a1f:	mov    0xc8(%rsp),%rax
  1e9a27:	cmp    %rax,%rcx
  1e9a2a:	cmovae %rax,%rcx
  1e9a2e:	mov    0xb0(%rsp),%rax
  1e9a36:	cmp    %rax,%rcx
  1e9a39:	cmovae %rax,%rcx
  1e9a3d:	mov    0x60(%rsp),%rdx
  1e9a42:	cmp    %rdx,%rcx
  1e9a45:	cmovae %rdx,%rcx
  1e9a49:	mov    0x510(%rsp),%r11
  1e9a51:	cmp    %r11,%rcx
  1e9a54:	cmovae %r11,%rcx
  1e9a58:	mov    %rcx,0x330(%rsp)
  1e9a60:	mov    0x2c0(%rsp),%rax
  1e9a68:	mov    0x108(%rsp),%r9
  1e9a70:	cmp    %rax,%r9
  1e9a73:	cmovb  %r9,%rax
  1e9a77:	mov    %rax,0x120(%rsp)
  1e9a7f:	mov    0xd8(%rsp),%rbx
  1e9a87:	mov    0x100(%rsp),%rcx
  1e9a8f:	cmp    %rbx,%rcx
  1e9a92:	cmovb  %rcx,%rbx
  1e9a96:	mov    0xf8(%rsp),%rax
  1e9a9e:	cmp    %rbx,%rax
  1e9aa1:	cmovb  %rax,%rbx
  1e9aa5:	mov    0x88(%rsp),%rax
  1e9aad:	cmp    %rbx,%rax
  1e9ab0:	cmovb  %rax,%rbx
  1e9ab4:	cmp    %rbx,%rsi
  1e9ab7:	cmovb  %rsi,%rbx
  1e9abb:	mov    %rbx,0x2a0(%rsp)
  1e9ac3:	cmp    %r8,%rsi
  1e9ac6:	jne    1ea582 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x73d2>
  1e9acc:	mov    %r8,%rax
  1e9acf:	cmp    %r8,0xc8(%rsp)
  1e9ad7:	jne    1ea582 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x73d2>
  1e9add:	cmp    %rax,0xb0(%rsp)
  1e9ae5:	jne    1ea582 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x73d2>
  1e9aeb:	mov    %r9,%rcx
  1e9aee:	xor    0x2c0(%rsp),%rcx
  1e9af6:	mov    %rdx,%rax
  1e9af9:	mov    0xc0(%rsp),%rsi
  1e9b01:	xor    %rsi,%rax
  1e9b04:	mov    %r11,%rdx
  1e9b07:	xor    %rsi,%rdx
  1e9b0a:	or     %rcx,%rdx
  1e9b0d:	or     %rax,%rdx
  1e9b10:	je     1eaddc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7c2c>
  1e9b16:	mov    0xd0(%rsp),%rax
  1e9b1e:	cmp    0xa8(%rsp),%rax
  1e9b26:	jb     1ea590 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x73e0>
  1e9b2c:	jmp    1ec6ca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x951a>
  1e9b31:	lea    0x107e30(%rip),%rcx        # 2f1968 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x5a8>
  1e9b38:	mov    0x160(%rsp),%rdi
  1e9b40:	mov    %r14,%rsi
  1e9b43:	mov    %rdi,%rdx
  1e9b46:	vzeroupper
  1e9b49:	call   *0x113881(%rip)        # 2fd3d0 <_DYNAMIC+0x348>
  1e9b4f:	mov    0x98(%rsp),%rax
  1e9b57:	mov    0x70(%rsp),%r8
  1e9b5c:	mov    0x10(%rsp),%rdx
  1e9b61:	mov    0x20(%rsp),%r12
  1e9b66:	mov    %r10,%rcx
  1e9b69:	mov    %rax,0x18(%rsp)
  1e9b6e:	mov    %rdx,0x10(%rsp)
  1e9b73:	vxorpd %xmm0,%xmm0,%xmm0
  1e9b77:	vcmpeqpd %ymm0,%ymm0,%ymm0
  1e9b7c:	mov    0x118(%rsp),%rax
  1e9b84:	dec    %rax
  1e9b87:	movabs $0x3fffffffffffffe,%rdx
  1e9b91:	mov    %rax,0x118(%rsp)
  1e9b99:	cmp    %rax,%rcx
  1e9b9c:	jae    1ea4d6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7326>
  1e9ba2:	mov    0xd8(%rsp),%rax
  1e9baa:	and    %rdx,%rax
  1e9bad:	shl    $0x5,%rax
  1e9bb1:	mov    0x68(%rsp),%r15
  1e9bb6:	add    %r15,%rax
  1e9bb9:	mov    %rax,0x260(%rsp)
  1e9bc1:	mov    0x100(%rsp),%rax
  1e9bc9:	and    %rdx,%rax
  1e9bcc:	shl    $0x5,%rax
  1e9bd0:	add    0x50(%rsp),%rax
  1e9bd5:	mov    %rax,0x3c0(%rsp)
  1e9bdd:	mov    0xf8(%rsp),%rax
  1e9be5:	and    %rdx,%rax
  1e9be8:	shl    $0x5,%rax
  1e9bec:	add    0x48(%rsp),%rax
  1e9bf1:	mov    %rax,0x160(%rsp)
  1e9bf9:	mov    0x88(%rsp),%rax
  1e9c01:	and    %rdx,%rax
  1e9c04:	shl    $0x5,%rax
  1e9c08:	add    %r8,%rax
  1e9c0b:	mov    %rax,0x2a0(%rsp)
  1e9c13:	mov    0x2f0(%rsp),%rbp
  1e9c1b:	mov    %rbp,%rsi
  1e9c1e:	shr    $0x3,%rsi
  1e9c22:	mov    0xa8(%rsp),%rax
  1e9c2a:	cmp    %rax,%rcx
  1e9c2d:	cmova  %rcx,%rax
  1e9c31:	mov    %rax,0x1e0(%rsp)
  1e9c39:	mov    0xa0(%rsp),%rax
  1e9c41:	cmp    %rax,%rcx
  1e9c44:	mov    %rcx,0xd0(%rsp)
  1e9c4c:	cmova  %rcx,%rax
  1e9c50:	mov    %rax,0x190(%rsp)
  1e9c58:	mov    0xc0(%rsp),%rdi
  1e9c60:	mov    0xf0(%rsp),%rcx
  1e9c68:	cmp    %rdi,%rcx
  1e9c6b:	cmovb  %rcx,%rdi
  1e9c6f:	mov    0xc8(%rsp),%rax
  1e9c77:	cmp    %rdi,%rax
  1e9c7a:	cmovb  %rax,%rdi
  1e9c7e:	mov    0xb0(%rsp),%rax
  1e9c86:	cmp    %rdi,%rax
  1e9c89:	cmovb  %rax,%rdi
  1e9c8d:	mov    %ebp,%r13d
  1e9c90:	and    $0x3,%r13d
  1e9c94:	and    %rbp,0x1d0(%rsp)
  1e9c9c:	mov    0x60(%rsp),%rax
  1e9ca1:	mov    %rax,%r8
  1e9ca4:	and    %rdx,%r8
  1e9ca7:	mov    %rsi,%rdx
  1e9caa:	cmp    %rdi,%rax
  1e9cad:	cmovb  %rax,%rdi
  1e9cb1:	cmp    %rdi,%rax
  1e9cb4:	cmovb  %rax,%rdi
  1e9cb8:	cmp    %rdi,%rax
  1e9cbb:	cmovb  %rax,%rdi
  1e9cbf:	mov    0x510(%rsp),%rcx
  1e9cc7:	cmp    %rdi,%rcx
  1e9cca:	cmovb  %rcx,%rdi
  1e9cce:	cmp    %rdi,%rax
  1e9cd1:	cmovb  %rax,%rdi
  1e9cd5:	mov    %rdi,0x280(%rsp)
  1e9cdd:	lea    -0x1(%r13),%rax
  1e9ce1:	mov    %rax,0x310(%rsp)
  1e9ce9:	mov    0x2c0(%rsp),%rax
  1e9cf1:	mov    0x108(%rsp),%r10
  1e9cf9:	cmp    %rax,%r10
  1e9cfc:	cmovae %rax,%r10
  1e9d00:	cmp    %r10,%r13
  1e9d03:	cmovb  %r13,%r10
  1e9d07:	mov    %rsi,%rax
  1e9d0a:	and    $0xfffffffffffffffe,%rax
  1e9d0e:	mov    %rax,0x410(%rsp)
  1e9d16:	shl    $0x5,%r8
  1e9d1a:	mov    %r8,0x330(%rsp)
  1e9d22:	vxorpd %xmm2,%xmm2,%xmm2
  1e9d26:	vmovapd %ymm0,%ymm1
  1e9d2a:	mov    0x38(%rsp),%r14
  1e9d2f:	mov    0x90(%rsp),%rdi
  1e9d37:	vbroadcastsd -0x1c3bc8(%rip),%ymm14        # 26178 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x3a8>
  1e9d40:	vmovupd 0x380(%rsp),%ymm15
  1e9d49:	movzbl 0x140(%rsp),%r11d
  1e9d52:	mov    0x110(%rsp),%rcx
  1e9d5a:	mov    %rsi,0xb8(%rsp)
  1e9d62:	mov    %r10,0x108(%rsp)
  1e9d6a:	mov    %r13,0x1b0(%rsp)
  1e9d72:	jmp    1e9da6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6bf6>
  1e9d74:	vandpd %ymm1,%ymm3,%ymm1
  1e9d78:	and    %al,%r11b
  1e9d7b:	mov    0xd0(%rsp),%rax
  1e9d83:	inc    %rax
  1e9d86:	mov    0x10(%rsp),%rcx
  1e9d8b:	mov    %r8,0x10(%rsp)
  1e9d90:	mov    %rax,0xd0(%rsp)
  1e9d98:	cmp    0x118(%rsp),%rax
  1e9da0:	je     1ea504 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7354>
  1e9da6:	mov    0x18(%rsp),%r8
  1e9dab:	mov    %rcx,0x18(%rsp)
  1e9db0:	vxorpd %xmm10,%xmm10,%xmm10
  1e9db5:	vxorpd %xmm6,%xmm6,%xmm6
  1e9db9:	vxorpd %xmm7,%xmm7,%xmm7
  1e9dbd:	vxorpd %xmm8,%xmm8,%xmm8
  1e9dc2:	vxorpd %xmm9,%xmm9,%xmm9
  1e9dc7:	vxorpd %xmm4,%xmm4,%xmm4
  1e9dcb:	vxorpd %xmm5,%xmm5,%xmm5
  1e9dcf:	vxorpd %xmm3,%xmm3,%xmm3
  1e9dd3:	test   %rdx,%rdx
  1e9dd6:	je     1e9f1a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6d6a>
  1e9ddc:	cmp    $0x1,%rdx
  1e9de0:	jne    1e9de9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6c39>
  1e9de2:	xor    %ecx,%ecx
  1e9de4:	jmp    1e9ebe <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6d0e>
  1e9de9:	mov    %rbp,%rdi
  1e9dec:	mov    $0x60,%esi
  1e9df1:	xor    %ecx,%ecx
  1e9df3:	mov    0x50(%rsp),%rax
  1e9df8:	mov    0x48(%rsp),%r12
  1e9dfd:	mov    0x70(%rsp),%rbp
  1e9e02:	mov    0x10(%rsp),%r9
  1e9e07:	mov    0x410(%rsp),%rdx
  1e9e0f:	vmovupd -0x60(%r9,%rsi,1),%ymm11
  1e9e16:	vmovupd -0x40(%r9,%rsi,1),%ymm12
  1e9e1d:	vmovupd -0x20(%r9,%rsi,1),%ymm13
  1e9e24:	vfmadd231pd -0x60(%r15,%rsi,1),%ymm11,%ymm6
  1e9e2b:	vfmadd231pd -0x60(%rax,%rsi,1),%ymm11,%ymm7
  1e9e32:	vfmadd231pd -0x60(%r12,%rsi,1),%ymm11,%ymm8
  1e9e39:	vfmadd231pd -0x60(%rbp,%rsi,1),%ymm11,%ymm9
  1e9e40:	vfmadd231pd -0x40(%r15,%rsi,1),%ymm12,%ymm4
  1e9e47:	vfmadd231pd -0x40(%rax,%rsi,1),%ymm12,%ymm5
  1e9e4e:	vfmadd231pd -0x40(%r12,%rsi,1),%ymm12,%ymm3
  1e9e55:	vfmadd231pd -0x40(%rbp,%rsi,1),%ymm12,%ymm10
  1e9e5c:	vmovupd (%r9,%rsi,1),%ymm11
  1e9e62:	add    $0x2,%rcx
  1e9e66:	vfmadd231pd -0x20(%r15,%rsi,1),%ymm13,%ymm6
  1e9e6d:	vfmadd231pd -0x20(%rax,%rsi,1),%ymm13,%ymm7
  1e9e74:	vfmadd231pd -0x20(%r12,%rsi,1),%ymm13,%ymm8
  1e9e7b:	vfmadd231pd -0x20(%rbp,%rsi,1),%ymm13,%ymm9
  1e9e82:	vfmadd231pd (%r15,%rsi,1),%ymm11,%ymm4
  1e9e88:	vfmadd231pd (%rax,%rsi,1),%ymm11,%ymm5
  1e9e8e:	vfmadd231pd (%r12,%rsi,1),%ymm11,%ymm3
  1e9e94:	vfmadd231pd 0x0(%rbp,%rsi,1),%ymm11,%ymm10
  1e9e9b:	sub    $0xffffffffffffff80,%rsi
  1e9e9f:	cmp    %rcx,%rdx
  1e9ea2:	jne    1e9e0f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6c5f>
  1e9ea8:	mov    %rdi,%rbp
  1e9eab:	test   $0x8,%bpl
  1e9eaf:	mov    0x20(%rsp),%r12
  1e9eb4:	mov    0x90(%rsp),%rdi
  1e9ebc:	je     1e9f1a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6d6a>
  1e9ebe:	shl    $0x6,%rcx
  1e9ec2:	mov    0x10(%rsp),%rax
  1e9ec7:	vmovupd (%rax,%rcx,1),%ymm11
  1e9ecc:	vmovupd 0x20(%rax,%rcx,1),%ymm12
  1e9ed2:	vfmadd231pd (%r15,%rcx,1),%ymm11,%ymm6
  1e9ed8:	mov    0x50(%rsp),%rax
  1e9edd:	vfmadd231pd (%rax,%rcx,1),%ymm11,%ymm7
  1e9ee3:	mov    0x48(%rsp),%rsi
  1e9ee8:	vfmadd231pd (%rsi,%rcx,1),%ymm11,%ymm8
  1e9eee:	mov    0x70(%rsp),%r12
  1e9ef3:	vfmadd231pd (%r12,%rcx,1),%ymm11,%ymm9
  1e9ef9:	vfmadd231pd 0x20(%r15,%rcx,1),%ymm12,%ymm4
  1e9f00:	vfmadd231pd 0x20(%rax,%rcx,1),%ymm12,%ymm5
  1e9f07:	vfmadd231pd 0x20(%rsi,%rcx,1),%ymm12,%ymm3
  1e9f0e:	vfmadd231pd 0x20(%r12,%rcx,1),%ymm12,%ymm10
  1e9f15:	mov    0x20(%rsp),%r12
  1e9f1a:	test   $0x4,%bpl
  1e9f1e:	je     1e9f72 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6dc2>
  1e9f20:	test   $0x4,%bpl
  1e9f24:	je     1ebd79 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8bc9>
  1e9f2a:	mov    0x10(%rsp),%rax
  1e9f2f:	mov    0x330(%rsp),%rcx
  1e9f37:	add    %rax,%rcx
  1e9f3a:	vmovupd (%rcx),%ymm11
  1e9f3e:	mov    0x260(%rsp),%rax
  1e9f46:	vfmadd231pd (%rax),%ymm11,%ymm6
  1e9f4b:	mov    0x3c0(%rsp),%rax
  1e9f53:	vfmadd231pd (%rax),%ymm11,%ymm7
  1e9f58:	mov    0x160(%rsp),%rax
  1e9f60:	vfmadd231pd (%rax),%ymm11,%ymm8
  1e9f65:	mov    0x2a0(%rsp),%rax
  1e9f6d:	vfmadd231pd (%rax),%ymm11,%ymm9
  1e9f72:	vaddpd %ymm9,%ymm10,%ymm9
  1e9f77:	vaddpd %ymm3,%ymm8,%ymm3
  1e9f7b:	vaddpd %ymm7,%ymm5,%ymm5
  1e9f7f:	vaddpd %ymm6,%ymm4,%ymm4
  1e9f83:	vextractf128 $0x1,%ymm4,%xmm6
  1e9f89:	vaddpd %xmm6,%xmm4,%xmm4
  1e9f8d:	vshufpd $0x1,%xmm4,%xmm4,%xmm6
  1e9f92:	vaddsd %xmm6,%xmm4,%xmm4
  1e9f96:	vextractf128 $0x1,%ymm5,%xmm6
  1e9f9c:	vaddpd %xmm6,%xmm5,%xmm5
  1e9fa0:	vshufpd $0x1,%xmm5,%xmm5,%xmm6
  1e9fa5:	vaddsd %xmm6,%xmm5,%xmm6
  1e9fa9:	vextractf128 $0x1,%ymm3,%xmm5
  1e9faf:	vaddpd %xmm5,%xmm3,%xmm3
  1e9fb3:	vshufpd $0x1,%xmm3,%xmm3,%xmm5
  1e9fb8:	vaddsd %xmm5,%xmm3,%xmm3
  1e9fbc:	vextractf128 $0x1,%ymm9,%xmm5
  1e9fc2:	vaddpd %xmm5,%xmm9,%xmm5
  1e9fc6:	vshufpd $0x1,%xmm5,%xmm5,%xmm7
  1e9fcb:	vaddsd %xmm7,%xmm5,%xmm5
  1e9fcf:	test   %r13,%r13
  1e9fd2:	je     1ea079 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6ec9>
  1e9fd8:	mov    0x310(%rsp),%rax
  1e9fe0:	cmp    %eax,0x2c0(%rsp)
  1e9fe7:	jbe    1ec664 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x94b4>
  1e9fed:	mov    0x10(%rsp),%r9
  1e9ff2:	mov    0x1d0(%rsp),%rdx
  1e9ffa:	vmovsd (%r9,%rdx,8),%xmm7
  1ea000:	vfmadd231sd (%r15,%rdi,8),%xmm7,%xmm4
  1ea006:	mov    0x50(%rsp),%rax
  1ea00b:	vfmadd231sd (%rax,%rdi,8),%xmm7,%xmm6
  1ea011:	mov    0x48(%rsp),%rcx
  1ea016:	vfmadd231sd (%rcx,%rdi,8),%xmm7,%xmm3
  1ea01c:	mov    0x70(%rsp),%rsi
  1ea021:	vfmadd231sd (%rsi,%rdi,8),%xmm7,%xmm5
  1ea027:	cmp    $0x1,%r13d
  1ea02b:	je     1ea079 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6ec9>
  1ea02d:	vmovsd 0x8(%r9,%rdx,8),%xmm7
  1ea034:	vfmadd231sd 0x8(%r15,%rdi,8),%xmm7,%xmm4
  1ea03b:	vfmadd231sd 0x8(%rax,%rdi,8),%xmm7,%xmm6
  1ea042:	vfmadd231sd 0x8(%rcx,%rdi,8),%xmm7,%xmm3
  1ea049:	vfmadd231sd 0x8(%rsi,%rdi,8),%xmm7,%xmm5
  1ea050:	cmp    $0x2,%r13d
  1ea054:	je     1ea079 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6ec9>
  1ea056:	vmovsd 0x10(%r9,%rdx,8),%xmm7
  1ea05d:	vfmadd231sd 0x10(%r15,%rdi,8),%xmm7,%xmm4
  1ea064:	vfmadd231sd 0x10(%rax,%rdi,8),%xmm7,%xmm6
  1ea06b:	vfmadd231sd 0x10(%rcx,%rdi,8),%xmm7,%xmm3
  1ea072:	vfmadd231sd 0x10(%rsi,%rdi,8),%xmm7,%xmm5
  1ea079:	mov    0xd0(%rsp),%rdx
  1ea081:	lea    (%rdx,%rdx,1),%rcx
  1ea085:	cmp    %r14,%rcx
  1ea088:	jae    1ec639 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9489>
  1ea08e:	mov    %rcx,%rbx
  1ea091:	shl    $0x4,%rbx
  1ea095:	mov    0x80(%rsp),%rsi
  1ea09d:	vmovsd %xmm4,(%rsi,%rbx,1)
  1ea0a2:	mov    0x188(%rsp),%rax
  1ea0aa:	lea    (%rax,%rdx,2),%rdi
  1ea0ae:	vmovsd %xmm6,0x8(%rsi,%rbx,1)
  1ea0b4:	cmp    0xe0(%rsp),%rdi
  1ea0bc:	mov    0x18(%rsp),%r14
  1ea0c1:	jae    1ea0e9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6f39>
  1ea0c3:	lea    0x1(%rcx),%rsi
  1ea0c7:	cmp    0x38(%rsp),%rsi
  1ea0cc:	jae    1ec692 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x94e2>
  1ea0d2:	shl    $0x4,%rsi
  1ea0d6:	mov    0x80(%rsp),%rax
  1ea0de:	vmovsd %xmm3,(%rax,%rsi,1)
  1ea0e3:	vmovsd %xmm5,0x8(%rax,%rsi,1)
  1ea0e9:	cmp    0x1e0(%rsp),%rdx
  1ea0f1:	je     1ec5f9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9449>
  1ea0f7:	cmp    0x190(%rsp),%rdx
  1ea0ff:	je     1ec619 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9469>
  1ea105:	mov    %rdi,0x120(%rsp)
  1ea10d:	mov    0x670(%rsp),%rax
  1ea115:	vbroadcastsd (%rax,%rdx,8),%ymm5
  1ea11b:	mov    0x650(%rsp),%rax
  1ea123:	vbroadcastsd (%rax,%rdx,8),%ymm4
  1ea129:	mov    0x280(%rsp),%rsi
  1ea131:	test   %rsi,%rsi
  1ea134:	je     1ea1c9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7019>
  1ea13a:	vxorpd %xmm8,%xmm8,%xmm8
  1ea13f:	xor    %r15d,%r15d
  1ea142:	vmovapd %ymm0,%ymm3
  1ea146:	vxorpd %xmm6,%xmm6,%xmm6
  1ea14a:	vxorpd %xmm9,%xmm9,%xmm9
  1ea14f:	vxorpd %xmm7,%xmm7,%xmm7
  1ea153:	mov    0x10(%rsp),%rax
  1ea158:	mov    0x58(%rsp),%r9
  1ea15d:	mov    0x28(%rsp),%rdx
  1ea162:	mov    0x40(%rsp),%rdi
  1ea167:	mov    0x360(%rsp),%r13
  1ea16f:	vmovupd (%rax,%r15,1),%ymm10
  1ea175:	vfmadd231pd (%r9,%r15,1),%ymm10,%ymm7
  1ea17b:	vfmadd231pd (%rdx,%r15,1),%ymm10,%ymm9
  1ea181:	vfmadd231pd (%r12,%r15,1),%ymm10,%ymm6
  1ea187:	vfmadd231pd (%rdi,%r15,1),%ymm10,%ymm8
  1ea18d:	vmovupd 0x0(%r13,%r15,1),%ymm11
  1ea194:	vfmadd213pd %ymm4,%ymm5,%ymm11
  1ea199:	vfmadd213pd (%r14,%r15,1),%ymm10,%ymm11
  1ea19f:	vmovupd %ymm11,(%r8,%r15,1)
  1ea1a5:	vandpd %ymm15,%ymm11,%ymm10
  1ea1aa:	vcmpeqpd %ymm2,%ymm10,%ymm11
  1ea1af:	vcmpge_oqpd %ymm14,%ymm10,%ymm10
  1ea1b5:	vorpd  %ymm11,%ymm10,%ymm10
  1ea1ba:	vandpd %ymm3,%ymm10,%ymm3
  1ea1be:	add    $0x20,%r15
  1ea1c2:	dec    %rsi
  1ea1c5:	jne    1ea16f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6fbf>
  1ea1c7:	jmp    1ea1df <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x702f>
  1ea1c9:	vxorpd %xmm7,%xmm7,%xmm7
  1ea1cd:	vxorpd %xmm9,%xmm9,%xmm9
  1ea1d2:	vxorpd %xmm6,%xmm6,%xmm6
  1ea1d6:	vxorpd %xmm8,%xmm8,%xmm8
  1ea1db:	vmovapd %ymm0,%ymm3
  1ea1df:	vextractf128 $0x1,%ymm7,%xmm10
  1ea1e5:	vaddpd %xmm7,%xmm10,%xmm7
  1ea1e9:	vshufpd $0x1,%xmm7,%xmm7,%xmm10
  1ea1ee:	vaddsd %xmm7,%xmm10,%xmm7
  1ea1f2:	vextractf128 $0x1,%ymm9,%xmm10
  1ea1f8:	vaddpd %xmm10,%xmm9,%xmm9
  1ea1fd:	vshufpd $0x1,%xmm9,%xmm9,%xmm10
  1ea203:	vaddsd %xmm10,%xmm9,%xmm9
  1ea208:	vextractf128 $0x1,%ymm6,%xmm10
  1ea20e:	vaddpd %xmm6,%xmm10,%xmm6
  1ea212:	vshufpd $0x1,%xmm6,%xmm6,%xmm10
  1ea217:	vaddsd %xmm6,%xmm10,%xmm6
  1ea21b:	vextractf128 $0x1,%ymm8,%xmm10
  1ea221:	vaddpd %xmm10,%xmm8,%xmm8
  1ea226:	vshufpd $0x1,%xmm8,%xmm8,%xmm10
  1ea22c:	vaddsd %xmm10,%xmm8,%xmm8
  1ea231:	test   %r10,%r10
  1ea234:	je     1ea30b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x715b>
  1ea23a:	mov    %r11b,0x140(%rsp)
  1ea242:	mov    0x10(%rsp),%r9
  1ea247:	mov    0x1d0(%rsp),%r14
  1ea24f:	vmovsd (%r9,%r14,8),%xmm10
  1ea255:	mov    0x258(%rsp),%rax
  1ea25d:	vmovsd (%rax),%xmm11
  1ea261:	vfmadd213sd %xmm4,%xmm5,%xmm11
  1ea266:	mov    0x18(%rsp),%rbp
  1ea26b:	vfmadd213sd 0x0(%rbp,%r14,8),%xmm10,%xmm11
  1ea272:	vmovq  %xmm11,%rsi
  1ea277:	mov    $0x3f,%al
  1ea279:	bzhi   %rax,%rsi,%rsi
  1ea27e:	movabs $0x7ff0000000000000,%rax
  1ea288:	cmp    %rax,%rsi
  1ea28b:	sete   %r15b
  1ea28f:	test   %rsi,%rsi
  1ea292:	mov    %r12,%r13
  1ea295:	sete   %r12b
  1ea299:	or     %r15b,%r12b
  1ea29c:	movabs $0xfff0000000000000,%r15
  1ea2a6:	add    %r15,%rsi
  1ea2a9:	shr    $0x35,%rsi
  1ea2ad:	cmp    $0x3ff,%esi
  1ea2b3:	setb   %al
  1ea2b6:	mov    0x58(%rsp),%rsi
  1ea2bb:	mov    %r10,%r11
  1ea2be:	mov    0x90(%rsp),%r10
  1ea2c6:	vfmadd231sd (%rsi,%r10,8),%xmm10,%xmm7
  1ea2cc:	mov    0x28(%rsp),%rdx
  1ea2d1:	vfmadd231sd (%rdx,%r10,8),%xmm10,%xmm9
  1ea2d7:	vfmadd231sd 0x0(%r13,%r10,8),%xmm10,%xmm6
  1ea2de:	mov    0x40(%rsp),%rdi
  1ea2e3:	vfmadd231sd (%rdi,%r10,8),%xmm10,%xmm8
  1ea2e9:	or     %r12b,%al
  1ea2ec:	vmovsd %xmm11,(%r8,%r14,8)
  1ea2f2:	cmp    $0x1,%r11d
  1ea2f6:	jne    1ea312 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7162>
  1ea2f8:	mov    %r13,%r12
  1ea2fb:	mov    0x2f0(%rsp),%rbp
  1ea303:	mov    %r11,%r10
  1ea306:	jmp    1ea450 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x72a0>
  1ea30b:	mov    $0x1,%al
  1ea30d:	jmp    1ea459 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x72a9>
  1ea312:	mov    %r9,0x10(%rsp)
  1ea317:	vmovsd 0x8(%r9,%r14,8),%xmm10
  1ea31e:	mov    0x258(%rsp),%r9
  1ea326:	vmovsd 0x8(%r9),%xmm11
  1ea32c:	vfmadd213sd %xmm4,%xmm5,%xmm11
  1ea331:	vfmadd213sd 0x8(%rbp,%r14,8),%xmm10,%xmm11
  1ea338:	mov    %r15,%r12
  1ea33b:	vmovq  %xmm11,%r15
  1ea340:	mov    $0x3f,%r9b
  1ea343:	bzhi   %r9,%r15,%r15
  1ea348:	add    %r15,%r12
  1ea34b:	shr    $0x35,%r12
  1ea34f:	cmp    $0x3ff,%r12d
  1ea356:	movzbl %al,%r12d
  1ea35a:	mov    $0x0,%eax
  1ea35f:	cmovb  %r12d,%eax
  1ea363:	movabs $0x7ff0000000000000,%r9
  1ea36d:	cmp    %r9,%r15
  1ea370:	cmove  %r12d,%eax
  1ea374:	test   %r15,%r15
  1ea377:	cmove  %r12d,%eax
  1ea37b:	vfmadd231sd 0x8(%rsi,%r10,8),%xmm10,%xmm7
  1ea382:	vfmadd231sd 0x8(%rdx,%r10,8),%xmm10,%xmm9
  1ea389:	vfmadd231sd 0x8(%r13,%r10,8),%xmm10,%xmm6
  1ea390:	vfmadd231sd 0x8(%rdi,%r10,8),%xmm10,%xmm8
  1ea397:	vmovsd %xmm11,0x8(%r8,%r14,8)
  1ea39e:	cmp    $0x2,%r11d
  1ea3a2:	jne    1ea3ac <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x71fc>
  1ea3a4:	mov    %r13,%r12
  1ea3a7:	jmp    1ea440 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7290>
  1ea3ac:	mov    0x258(%rsp),%r9
  1ea3b4:	vfmadd231sd 0x10(%r9),%xmm5,%xmm4
  1ea3ba:	mov    0x10(%rsp),%r9
  1ea3bf:	vmovsd 0x10(%r9,%r14,8),%xmm5
  1ea3c6:	vfmadd213sd 0x10(%rbp,%r14,8),%xmm5,%xmm4
  1ea3cd:	vmovq  %xmm4,%r15
  1ea3d2:	mov    $0x3f,%r9b
  1ea3d5:	bzhi   %r9,%r15,%r15
  1ea3da:	movabs $0xfff0000000000000,%r9
  1ea3e4:	lea    (%r15,%r9,1),%r12
  1ea3e8:	shr    $0x35,%r12
  1ea3ec:	cmp    $0x3ff,%r12d
  1ea3f3:	movzbl %al,%r12d
  1ea3f7:	mov    $0x0,%eax
  1ea3fc:	cmovb  %r12d,%eax
  1ea400:	movabs $0x7ff0000000000000,%r9
  1ea40a:	cmp    %r9,%r15
  1ea40d:	cmove  %r12d,%eax
  1ea411:	test   %r15,%r15
  1ea414:	cmove  %r12d,%eax
  1ea418:	mov    0x20(%rsp),%r12
  1ea41d:	vfmadd231sd 0x10(%rsi,%r10,8),%xmm5,%xmm7
  1ea424:	vfmadd231sd 0x10(%rdx,%r10,8),%xmm5,%xmm9
  1ea42b:	vfmadd231sd 0x10(%r12,%r10,8),%xmm5,%xmm6
  1ea432:	vfmadd231sd 0x10(%rdi,%r10,8),%xmm5,%xmm8
  1ea439:	vmovsd %xmm4,0x10(%r8,%r14,8)
  1ea440:	mov    0x2f0(%rsp),%rbp
  1ea448:	mov    0x108(%rsp),%r10
  1ea450:	movzbl 0x140(%rsp),%r11d
  1ea459:	mov    0x1b0(%rsp),%r13
  1ea461:	mov    0x30(%rsp),%rsi
  1ea466:	cmp    %rsi,%rcx
  1ea469:	mov    0xb8(%rsp),%rdx
  1ea471:	jae    1ec651 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x94a1>
  1ea477:	mov    0x78(%rsp),%r15
  1ea47c:	vmovsd %xmm7,(%r15,%rbx,1)
  1ea482:	vmovsd %xmm9,0x8(%r15,%rbx,1)
  1ea489:	mov    0x120(%rsp),%rdi
  1ea491:	cmp    0xe0(%rsp),%rdi
  1ea499:	mov    0x38(%rsp),%r14
  1ea49e:	mov    0x68(%rsp),%r15
  1ea4a3:	mov    0x90(%rsp),%rdi
  1ea4ab:	jae    1e9d74 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6bc4>
  1ea4b1:	inc    %rcx
  1ea4b4:	cmp    %rsi,%rcx
  1ea4b7:	jae    1ec67f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x94cf>
  1ea4bd:	shl    $0x4,%rcx
  1ea4c1:	mov    0x78(%rsp),%rsi
  1ea4c6:	vmovsd %xmm6,(%rsi,%rcx,1)
  1ea4cb:	vmovsd %xmm8,0x8(%rsi,%rcx,1)
  1ea4d1:	jmp    1e9d74 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x6bc4>
  1ea4d6:	mov    0x2f0(%rsp),%rcx
  1ea4de:	shr    $0x3,%rcx
  1ea4e2:	mov    0x90(%rsp),%rax
  1ea4ea:	mov    %rax,0x1d0(%rsp)
  1ea4f2:	mov    0x2c0(%rsp),%rax
  1ea4fa:	mov    %rax,0x1b0(%rsp)
  1ea502:	jmp    1ea529 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7379>
  1ea504:	mov    %r11b,0x140(%rsp)
  1ea50c:	cmp    %rdx,%rdx
  1ea50f:	cmovb  %rdx,%rdx
  1ea513:	vmovapd %ymm1,%ymm0
  1ea517:	mov    %r8,0x10(%rsp)
  1ea51c:	mov    %rdx,%rcx
  1ea51f:	movabs $0x3fffffffffffffe,%rdx
  1ea529:	mov    0x60(%rsp),%rbx
  1ea52e:	and    %rdx,%rbx
  1ea531:	shl    $0x5,%rbx
  1ea535:	test   %rcx,%rcx
  1ea538:	je     1ea5da <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x742a>
  1ea53e:	mov    %rcx,%r15
  1ea541:	cmp    $0x1,%rcx
  1ea545:	jne    1ea612 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7462>
  1ea54b:	vxorpd %xmm1,%xmm1,%xmm1
  1ea54f:	xor    %eax,%eax
  1ea551:	vxorpd %xmm2,%xmm2,%xmm2
  1ea555:	vxorpd %xmm3,%xmm3,%xmm3
  1ea559:	vxorpd %xmm4,%xmm4,%xmm4
  1ea55d:	vxorpd %xmm5,%xmm5,%xmm5
  1ea561:	vxorpd %xmm6,%xmm6,%xmm6
  1ea565:	vxorpd %xmm7,%xmm7,%xmm7
  1ea569:	vxorpd %xmm8,%xmm8,%xmm8
  1ea56e:	mov    0x58(%rsp),%r8
  1ea573:	mov    0x28(%rsp),%r9
  1ea578:	mov    0x20(%rsp),%rdx
  1ea57d:	jmp    1ea6f4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7544>
  1ea582:	cmp    0xa8(%rsp),%r10
  1ea58a:	jae    1ec6ca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x951a>
  1ea590:	mov    0xd0(%rsp),%rax
  1ea598:	cmp    0xa0(%rsp),%rax
  1ea5a0:	jae    1ec6aa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x94fa>
  1ea5a6:	cmp    0xa8(%rsp),%rdi
  1ea5ae:	jae    1ec6ea <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x953a>
  1ea5b4:	cmp    0xa0(%rsp),%rdi
  1ea5bc:	jb     1e6d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bad>
  1ea5c2:	lea    0x107477(%rip),%rdx        # 2f1a40 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x680>
  1ea5c9:	mov    0xa0(%rsp),%rsi
  1ea5d1:	vzeroupper
  1ea5d4:	call   *0x112d66(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ea5da:	mov    %rcx,%r15
  1ea5dd:	vxorpd %xmm8,%xmm8,%xmm8
  1ea5e2:	vxorpd %xmm7,%xmm7,%xmm7
  1ea5e6:	vxorpd %xmm6,%xmm6,%xmm6
  1ea5ea:	vxorpd %xmm5,%xmm5,%xmm5
  1ea5ee:	vxorpd %xmm4,%xmm4,%xmm4
  1ea5f2:	vxorpd %xmm3,%xmm3,%xmm3
  1ea5f6:	vxorpd %xmm2,%xmm2,%xmm2
  1ea5fa:	vxorpd %xmm1,%xmm1,%xmm1
  1ea5fe:	mov    0x58(%rsp),%r8
  1ea603:	mov    0x28(%rsp),%r9
  1ea608:	mov    0x20(%rsp),%rdx
  1ea60d:	jmp    1ea741 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7591>
  1ea612:	mov    %r15,%rcx
  1ea615:	and    $0xfffffffffffffffe,%rcx
  1ea619:	vxorpd %xmm1,%xmm1,%xmm1
  1ea61d:	mov    $0x60,%esi
  1ea622:	xor    %eax,%eax
  1ea624:	vxorpd %xmm2,%xmm2,%xmm2
  1ea628:	vxorpd %xmm3,%xmm3,%xmm3
  1ea62c:	vxorpd %xmm4,%xmm4,%xmm4
  1ea630:	vxorpd %xmm5,%xmm5,%xmm5
  1ea634:	vxorpd %xmm6,%xmm6,%xmm6
  1ea638:	vxorpd %xmm7,%xmm7,%xmm7
  1ea63c:	vxorpd %xmm8,%xmm8,%xmm8
  1ea641:	mov    0x10(%rsp),%rdi
  1ea646:	mov    0x58(%rsp),%r8
  1ea64b:	mov    0x28(%rsp),%r9
  1ea650:	mov    0x20(%rsp),%rdx
  1ea655:	mov    0x40(%rsp),%r11
  1ea65a:	vmovupd -0x60(%rdi,%rsi,1),%ymm9
  1ea660:	vmovupd -0x40(%rdi,%rsi,1),%ymm10
  1ea666:	vmovupd -0x20(%rdi,%rsi,1),%ymm11
  1ea66c:	vfmadd231pd -0x60(%r8,%rsi,1),%ymm9,%ymm7
  1ea673:	vfmadd231pd -0x60(%r9,%rsi,1),%ymm9,%ymm6
  1ea67a:	vfmadd231pd -0x60(%rdx,%rsi,1),%ymm9,%ymm5
  1ea681:	vfmadd231pd -0x60(%r11,%rsi,1),%ymm9,%ymm4
  1ea688:	vfmadd231pd -0x40(%r8,%rsi,1),%ymm10,%ymm3
  1ea68f:	vfmadd231pd -0x40(%r9,%rsi,1),%ymm10,%ymm2
  1ea696:	vfmadd231pd -0x40(%rdx,%rsi,1),%ymm10,%ymm1
  1ea69d:	vfmadd231pd -0x40(%r11,%rsi,1),%ymm10,%ymm8
  1ea6a4:	vmovupd (%rdi,%rsi,1),%ymm9
  1ea6a9:	add    $0x2,%rax
  1ea6ad:	vfmadd231pd -0x20(%r8,%rsi,1),%ymm11,%ymm7
  1ea6b4:	vfmadd231pd -0x20(%r9,%rsi,1),%ymm11,%ymm6
  1ea6bb:	vfmadd231pd -0x20(%rdx,%rsi,1),%ymm11,%ymm5
  1ea6c2:	vfmadd231pd -0x20(%r11,%rsi,1),%ymm11,%ymm4
  1ea6c9:	vfmadd231pd (%r8,%rsi,1),%ymm9,%ymm3
  1ea6cf:	vfmadd231pd (%r9,%rsi,1),%ymm9,%ymm2
  1ea6d5:	vfmadd231pd (%rdx,%rsi,1),%ymm9,%ymm1
  1ea6db:	vfmadd231pd (%r11,%rsi,1),%ymm9,%ymm8
  1ea6e1:	sub    $0xffffffffffffff80,%rsi
  1ea6e5:	cmp    %rax,%rcx
  1ea6e8:	jne    1ea65a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x74aa>
  1ea6ee:	test   $0x1,%r15b
  1ea6f2:	je     1ea741 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7591>
  1ea6f4:	shl    $0x6,%rax
  1ea6f8:	mov    0x10(%rsp),%rcx
  1ea6fd:	vmovupd (%rcx,%rax,1),%ymm9
  1ea702:	vmovupd 0x20(%rcx,%rax,1),%ymm10
  1ea708:	vfmadd231pd (%r8,%rax,1),%ymm9,%ymm7
  1ea70e:	vfmadd231pd (%r9,%rax,1),%ymm9,%ymm6
  1ea714:	vfmadd231pd (%rdx,%rax,1),%ymm9,%ymm5
  1ea71a:	mov    0x40(%rsp),%rcx
  1ea71f:	vfmadd231pd (%rcx,%rax,1),%ymm9,%ymm4
  1ea725:	vfmadd231pd 0x20(%r8,%rax,1),%ymm10,%ymm3
  1ea72c:	vfmadd231pd 0x20(%r9,%rax,1),%ymm10,%ymm2
  1ea733:	vfmadd231pd 0x20(%rdx,%rax,1),%ymm10,%ymm1
  1ea73a:	vfmadd231pd 0x20(%rcx,%rax,1),%ymm10,%ymm8
  1ea741:	add    0x10(%rsp),%rbx
  1ea746:	testb  $0x4,0x2f0(%rsp)
  1ea74e:	jne    1ea755 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x75a5>
  1ea750:	mov    %rbx,%r14
  1ea753:	jmp    1ea7c4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7614>
  1ea755:	mov    0xc0(%rsp),%rax
  1ea75d:	movabs $0x3fffffffffffffe,%r10
  1ea767:	and    %r10,%rax
  1ea76a:	mov    0xf0(%rsp),%rcx
  1ea772:	and    %r10,%rcx
  1ea775:	mov    0xc8(%rsp),%rsi
  1ea77d:	and    %r10,%rsi
  1ea780:	mov    0xb0(%rsp),%rdi
  1ea788:	and    %r10,%rdi
  1ea78b:	shl    $0x5,%rax
  1ea78f:	shl    $0x5,%rcx
  1ea793:	shl    $0x5,%rsi
  1ea797:	shl    $0x5,%rdi
  1ea79b:	add    %r8,%rax
  1ea79e:	add    %r9,%rcx
  1ea7a1:	add    %rdx,%rsi
  1ea7a4:	add    0x40(%rsp),%rdi
  1ea7a9:	mov    %rbx,%r14
  1ea7ac:	vmovupd (%rbx),%ymm9
  1ea7b0:	vfmadd231pd (%rax),%ymm9,%ymm7
  1ea7b5:	vfmadd231pd (%rcx),%ymm9,%ymm6
  1ea7ba:	vfmadd231pd (%rsi),%ymm9,%ymm5
  1ea7bf:	vfmadd231pd (%rdi),%ymm9,%ymm4
  1ea7c4:	vaddpd %ymm4,%ymm8,%ymm4
  1ea7c8:	vaddpd %ymm5,%ymm1,%ymm5
  1ea7cc:	vaddpd %ymm6,%ymm2,%ymm2
  1ea7d0:	vaddpd %ymm7,%ymm3,%ymm1
  1ea7d4:	vextractf128 $0x1,%ymm1,%xmm3
  1ea7da:	vaddpd %xmm3,%xmm1,%xmm1
  1ea7de:	vshufpd $0x1,%xmm1,%xmm1,%xmm3
  1ea7e3:	vaddsd %xmm3,%xmm1,%xmm1
  1ea7e7:	vextractf128 $0x1,%ymm2,%xmm3
  1ea7ed:	vaddpd %xmm3,%xmm2,%xmm2
  1ea7f1:	vshufpd $0x1,%xmm2,%xmm2,%xmm3
  1ea7f6:	vaddsd %xmm3,%xmm2,%xmm2
  1ea7fa:	vextractf128 $0x1,%ymm5,%xmm3
  1ea800:	vaddpd %xmm3,%xmm5,%xmm3
  1ea804:	vshufpd $0x1,%xmm3,%xmm3,%xmm5
  1ea809:	vaddsd %xmm5,%xmm3,%xmm3
  1ea80d:	vextractf128 $0x1,%ymm4,%xmm5
  1ea813:	vaddpd %xmm5,%xmm4,%xmm4
  1ea817:	vshufpd $0x1,%xmm4,%xmm4,%xmm5
  1ea81c:	vaddsd %xmm5,%xmm4,%xmm4
  1ea820:	mov    0x1b0(%rsp),%rdx
  1ea828:	test   %rdx,%rdx
  1ea82b:	je     1ea930 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7780>
  1ea831:	lea    -0x1(%rdx),%eax
  1ea834:	cmp    %eax,0x2c0(%rsp)
  1ea83b:	jbe    1ec664 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x94b4>
  1ea841:	mov    0x1d0(%rsp),%rax
  1ea849:	mov    0x10(%rsp),%rcx
  1ea84e:	vmovsd (%rcx,%rax,8),%xmm5
  1ea853:	mov    0x58(%rsp),%rax
  1ea858:	mov    0x90(%rsp),%rcx
  1ea860:	vfmadd231sd (%rax,%rcx,8),%xmm5,%xmm1
  1ea866:	mov    0x28(%rsp),%rax
  1ea86b:	vfmadd231sd (%rax,%rcx,8),%xmm5,%xmm2
  1ea871:	mov    0x20(%rsp),%rax
  1ea876:	vfmadd231sd (%rax,%rcx,8),%xmm5,%xmm3
  1ea87c:	mov    0x40(%rsp),%rax
  1ea881:	vfmadd231sd (%rax,%rcx,8),%xmm5,%xmm4
  1ea887:	cmp    $0x1,%edx
  1ea88a:	je     1ea930 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7780>
  1ea890:	mov    0x1d0(%rsp),%rax
  1ea898:	mov    0x10(%rsp),%rcx
  1ea89d:	vmovsd 0x8(%rcx,%rax,8),%xmm5
  1ea8a3:	mov    0x58(%rsp),%rax
  1ea8a8:	mov    0x90(%rsp),%rcx
  1ea8b0:	vfmadd231sd 0x8(%rax,%rcx,8),%xmm5,%xmm1
  1ea8b7:	mov    0x28(%rsp),%rax
  1ea8bc:	vfmadd231sd 0x8(%rax,%rcx,8),%xmm5,%xmm2
  1ea8c3:	mov    0x20(%rsp),%rax
  1ea8c8:	vfmadd231sd 0x8(%rax,%rcx,8),%xmm5,%xmm3
  1ea8cf:	mov    0x40(%rsp),%rax
  1ea8d4:	vfmadd231sd 0x8(%rax,%rcx,8),%xmm5,%xmm4
  1ea8db:	cmpl   $0x2,0x1b0(%rsp)
  1ea8e3:	je     1ea930 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7780>
  1ea8e5:	mov    0x1d0(%rsp),%rax
  1ea8ed:	mov    0x10(%rsp),%rcx
  1ea8f2:	vmovsd 0x10(%rcx,%rax,8),%xmm5
  1ea8f8:	mov    0x58(%rsp),%rax
  1ea8fd:	mov    0x90(%rsp),%rcx
  1ea905:	vfmadd231sd 0x10(%rax,%rcx,8),%xmm5,%xmm1
  1ea90c:	mov    0x28(%rsp),%rax
  1ea911:	vfmadd231sd 0x10(%rax,%rcx,8),%xmm5,%xmm2
  1ea918:	mov    0x20(%rsp),%rax
  1ea91d:	vfmadd231sd 0x10(%rax,%rcx,8),%xmm5,%xmm3
  1ea924:	mov    0x40(%rsp),%rax
  1ea929:	vfmadd231sd 0x10(%rax,%rcx,8),%xmm5,%xmm4
  1ea930:	test   %r15,%r15
  1ea933:	je     1ea97b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x77cb>
  1ea935:	cmp    $0x1,%r15
  1ea939:	jne    1ea9b9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7809>
  1ea93b:	vxorpd %xmm5,%xmm5,%xmm5
  1ea93f:	xor    %eax,%eax
  1ea941:	vxorpd %xmm6,%xmm6,%xmm6
  1ea945:	vxorpd %xmm7,%xmm7,%xmm7
  1ea949:	vxorpd %xmm8,%xmm8,%xmm8
  1ea94e:	vxorpd %xmm9,%xmm9,%xmm9
  1ea953:	vxorpd %xmm10,%xmm10,%xmm10
  1ea958:	vxorpd %xmm11,%xmm11,%xmm11
  1ea95d:	vxorpd %xmm12,%xmm12,%xmm12
  1ea962:	mov    0x68(%rsp),%rdi
  1ea967:	mov    0x50(%rsp),%r8
  1ea96c:	mov    0x48(%rsp),%r11
  1ea971:	mov    0x70(%rsp),%rbx
  1ea976:	jmp    1eaaa5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x78f5>
  1ea97b:	vxorpd %xmm12,%xmm12,%xmm12
  1ea980:	vxorpd %xmm11,%xmm11,%xmm11
  1ea985:	vxorpd %xmm10,%xmm10,%xmm10
  1ea98a:	vxorpd %xmm9,%xmm9,%xmm9
  1ea98f:	vxorpd %xmm8,%xmm8,%xmm8
  1ea994:	vxorpd %xmm7,%xmm7,%xmm7
  1ea998:	vxorpd %xmm6,%xmm6,%xmm6
  1ea99c:	vxorpd %xmm5,%xmm5,%xmm5
  1ea9a0:	mov    0x68(%rsp),%rdi
  1ea9a5:	mov    0x50(%rsp),%r8
  1ea9aa:	mov    0x48(%rsp),%r11
  1ea9af:	mov    0x70(%rsp),%rbx
  1ea9b4:	jmp    1eaaed <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x793d>
  1ea9b9:	mov    %r15,%rdx
  1ea9bc:	mov    %r15,%rcx
  1ea9bf:	and    $0xfffffffffffffffe,%rcx
  1ea9c3:	vxorpd %xmm5,%xmm5,%xmm5
  1ea9c7:	mov    $0x60,%esi
  1ea9cc:	xor    %eax,%eax
  1ea9ce:	vxorpd %xmm6,%xmm6,%xmm6
  1ea9d2:	vxorpd %xmm7,%xmm7,%xmm7
  1ea9d6:	vxorpd %xmm8,%xmm8,%xmm8
  1ea9db:	vxorpd %xmm9,%xmm9,%xmm9
  1ea9e0:	vxorpd %xmm10,%xmm10,%xmm10
  1ea9e5:	vxorpd %xmm11,%xmm11,%xmm11
  1ea9ea:	vxorpd %xmm12,%xmm12,%xmm12
  1ea9ef:	mov    0x68(%rsp),%rdi
  1ea9f4:	mov    0x50(%rsp),%r8
  1ea9f9:	mov    0x48(%rsp),%r11
  1ea9fe:	mov    0x70(%rsp),%rbx
  1eaa03:	mov    0x10(%rsp),%r9
  1eaa08:	vmovupd -0x60(%r9,%rsi,1),%ymm13
  1eaa0f:	vmovupd -0x40(%r9,%rsi,1),%ymm14
  1eaa16:	vmovupd -0x20(%r9,%rsi,1),%ymm15
  1eaa1d:	vfmadd231pd -0x60(%rdi,%rsi,1),%ymm13,%ymm11
  1eaa24:	vfmadd231pd -0x60(%r8,%rsi,1),%ymm13,%ymm10
  1eaa2b:	vfmadd231pd -0x60(%r11,%rsi,1),%ymm13,%ymm9
  1eaa32:	vfmadd231pd -0x60(%rbx,%rsi,1),%ymm13,%ymm8
  1eaa39:	vfmadd231pd -0x40(%rdi,%rsi,1),%ymm14,%ymm7
  1eaa40:	vfmadd231pd -0x40(%r8,%rsi,1),%ymm14,%ymm6
  1eaa47:	vfmadd231pd -0x40(%r11,%rsi,1),%ymm14,%ymm5
  1eaa4e:	vfmadd231pd -0x40(%rbx,%rsi,1),%ymm14,%ymm12
  1eaa55:	vmovupd (%r9,%rsi,1),%ymm13
  1eaa5b:	add    $0x2,%rax
  1eaa5f:	vfmadd231pd -0x20(%rdi,%rsi,1),%ymm15,%ymm11
  1eaa66:	vfmadd231pd -0x20(%r8,%rsi,1),%ymm15,%ymm10
  1eaa6d:	vfmadd231pd -0x20(%r11,%rsi,1),%ymm15,%ymm9
  1eaa74:	vfmadd231pd -0x20(%rbx,%rsi,1),%ymm15,%ymm8
  1eaa7b:	vfmadd231pd (%rdi,%rsi,1),%ymm13,%ymm7
  1eaa81:	vfmadd231pd (%r8,%rsi,1),%ymm13,%ymm6
  1eaa87:	vfmadd231pd (%r11,%rsi,1),%ymm13,%ymm5
  1eaa8d:	vfmadd231pd (%rbx,%rsi,1),%ymm13,%ymm12
  1eaa93:	sub    $0xffffffffffffff80,%rsi
  1eaa97:	cmp    %rax,%rcx
  1eaa9a:	jne    1eaa08 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7858>
  1eaaa0:	test   $0x1,%dl
  1eaaa3:	je     1eaaed <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x793d>
  1eaaa5:	shl    $0x6,%rax
  1eaaa9:	mov    0x10(%rsp),%rcx
  1eaaae:	vmovupd (%rcx,%rax,1),%ymm13
  1eaab3:	vmovupd 0x20(%rcx,%rax,1),%ymm14
  1eaab9:	vfmadd231pd (%rdi,%rax,1),%ymm13,%ymm11
  1eaabf:	vfmadd231pd (%r8,%rax,1),%ymm13,%ymm10
  1eaac5:	vfmadd231pd (%r11,%rax,1),%ymm13,%ymm9
  1eaacb:	vfmadd231pd (%rbx,%rax,1),%ymm13,%ymm8
  1eaad1:	vfmadd231pd 0x20(%rdi,%rax,1),%ymm14,%ymm7
  1eaad8:	vfmadd231pd 0x20(%r8,%rax,1),%ymm14,%ymm6
  1eaadf:	vfmadd231pd 0x20(%r11,%rax,1),%ymm14,%ymm5
  1eaae6:	vfmadd231pd 0x20(%rbx,%rax,1),%ymm14,%ymm12
  1eaaed:	testb  $0x4,0x2f0(%rsp)
  1eaaf5:	je     1eab62 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x79b2>
  1eaaf7:	mov    0xd8(%rsp),%rax
  1eaaff:	movabs $0x3fffffffffffffe,%r9
  1eab09:	and    %r9,%rax
  1eab0c:	mov    0x100(%rsp),%rcx
  1eab14:	and    %r9,%rcx
  1eab17:	mov    0xf8(%rsp),%rdx
  1eab1f:	and    %r9,%rdx
  1eab22:	mov    0x88(%rsp),%rsi
  1eab2a:	and    %r9,%rsi
  1eab2d:	shl    $0x5,%rax
  1eab31:	shl    $0x5,%rcx
  1eab35:	shl    $0x5,%rdx
  1eab39:	shl    $0x5,%rsi
  1eab3d:	add    %rdi,%rax
  1eab40:	add    %r8,%rcx
  1eab43:	add    %r11,%rdx
  1eab46:	add    %rbx,%rsi
  1eab49:	vmovupd (%r14),%ymm13
  1eab4e:	vfmadd231pd (%rax),%ymm13,%ymm11
  1eab53:	vfmadd231pd (%rcx),%ymm13,%ymm10
  1eab58:	vfmadd231pd (%rdx),%ymm13,%ymm9
  1eab5d:	vfmadd231pd (%rsi),%ymm13,%ymm8
  1eab62:	vaddpd %ymm8,%ymm12,%ymm12
  1eab67:	vaddpd %ymm5,%ymm9,%ymm5
  1eab6b:	vaddpd %ymm6,%ymm10,%ymm6
  1eab6f:	vaddpd %ymm7,%ymm11,%ymm7
  1eab73:	vextractf128 $0x1,%ymm7,%xmm8
  1eab79:	vaddpd %xmm7,%xmm8,%xmm7
  1eab7d:	vshufpd $0x1,%xmm7,%xmm7,%xmm8
  1eab82:	vaddsd %xmm7,%xmm8,%xmm7
  1eab86:	vextractf128 $0x1,%ymm6,%xmm8
  1eab8c:	vaddpd %xmm6,%xmm8,%xmm6
  1eab90:	vshufpd $0x1,%xmm6,%xmm6,%xmm8
  1eab95:	vaddsd %xmm6,%xmm8,%xmm8
  1eab99:	vextractf128 $0x1,%ymm5,%xmm6
  1eab9f:	vaddpd %xmm6,%xmm5,%xmm5
  1eaba3:	vshufpd $0x1,%xmm5,%xmm5,%xmm6
  1eaba8:	vaddsd %xmm6,%xmm5,%xmm5
  1eabac:	vextractf128 $0x1,%ymm12,%xmm6
  1eabb2:	vaddpd %xmm6,%xmm12,%xmm6
  1eabb6:	vshufpd $0x1,%xmm6,%xmm6,%xmm9
  1eabbb:	vaddsd %xmm6,%xmm9,%xmm6
  1eabbf:	mov    0x1b0(%rsp),%rdx
  1eabc7:	test   %rdx,%rdx
  1eabca:	je     1eaccf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7b1f>
  1eabd0:	lea    -0x1(%rdx),%eax
  1eabd3:	cmp    %eax,0x2c0(%rsp)
  1eabda:	jbe    1ec664 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x94b4>
  1eabe0:	mov    0x1d0(%rsp),%rax
  1eabe8:	mov    0x10(%rsp),%rcx
  1eabed:	vmovsd (%rcx,%rax,8),%xmm9
  1eabf2:	mov    0x68(%rsp),%rax
  1eabf7:	mov    0x90(%rsp),%rcx
  1eabff:	vfmadd231sd (%rax,%rcx,8),%xmm9,%xmm7
  1eac05:	mov    0x50(%rsp),%rax
  1eac0a:	vfmadd231sd (%rax,%rcx,8),%xmm9,%xmm8
  1eac10:	mov    0x48(%rsp),%rax
  1eac15:	vfmadd231sd (%rax,%rcx,8),%xmm9,%xmm5
  1eac1b:	mov    0x70(%rsp),%rax
  1eac20:	vfmadd231sd (%rax,%rcx,8),%xmm9,%xmm6
  1eac26:	cmp    $0x1,%edx
  1eac29:	je     1eaccf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7b1f>
  1eac2f:	mov    0x1d0(%rsp),%rax
  1eac37:	mov    0x10(%rsp),%rcx
  1eac3c:	vmovsd 0x8(%rcx,%rax,8),%xmm9
  1eac42:	mov    0x68(%rsp),%rax
  1eac47:	mov    0x90(%rsp),%rcx
  1eac4f:	vfmadd231sd 0x8(%rax,%rcx,8),%xmm9,%xmm7
  1eac56:	mov    0x50(%rsp),%rax
  1eac5b:	vfmadd231sd 0x8(%rax,%rcx,8),%xmm9,%xmm8
  1eac62:	mov    0x48(%rsp),%rax
  1eac67:	vfmadd231sd 0x8(%rax,%rcx,8),%xmm9,%xmm5
  1eac6e:	mov    0x70(%rsp),%rax
  1eac73:	vfmadd231sd 0x8(%rax,%rcx,8),%xmm9,%xmm6
  1eac7a:	cmpl   $0x2,0x1b0(%rsp)
  1eac82:	je     1eaccf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7b1f>
  1eac84:	mov    0x1d0(%rsp),%rax
  1eac8c:	mov    0x10(%rsp),%rcx
  1eac91:	vmovsd 0x10(%rcx,%rax,8),%xmm9
  1eac97:	mov    0x68(%rsp),%rax
  1eac9c:	mov    0x90(%rsp),%rcx
  1eaca4:	vfmadd231sd 0x10(%rax,%rcx,8),%xmm9,%xmm7
  1eacab:	mov    0x50(%rsp),%rax
  1eacb0:	vfmadd231sd 0x10(%rax,%rcx,8),%xmm9,%xmm8
  1eacb7:	mov    0x48(%rsp),%rax
  1eacbc:	vfmadd231sd 0x10(%rax,%rcx,8),%xmm9,%xmm5
  1eacc3:	mov    0x70(%rsp),%rax
  1eacc8:	vfmadd231sd 0x10(%rax,%rcx,8),%xmm9,%xmm6
  1eaccf:	mov    0x2e8(%rsp),%rsi
  1eacd7:	lea    -0x2(%rsi),%rdi
  1eacdb:	cmp    0x38(%rsp),%rdi
  1eace0:	jae    1ec17b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8fcb>
  1eace6:	mov    %rdi,%rax
  1eace9:	shl    $0x4,%rax
  1eaced:	mov    0x80(%rsp),%r8
  1eacf5:	vmovsd %xmm7,(%r8,%rax,1)
  1eacfb:	mov    0x188(%rsp),%rcx
  1ead03:	add    %rsi,%rcx
  1ead06:	add    $0xfffffffffffffffe,%rcx
  1ead0a:	vmovsd %xmm8,0x8(%r8,%rax,1)
  1ead11:	cmp    0xe0(%rsp),%rcx
  1ead19:	jae    1ead7a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7bca>
  1ead1b:	dec    %rsi
  1ead1e:	mov    %rsi,%r8
  1ead21:	cmp    0x38(%rsp),%rsi
  1ead26:	jae    1ec77d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x95cd>
  1ead2c:	mov    %r8,%rcx
  1ead2f:	shl    $0x4,%rcx
  1ead33:	mov    0x80(%rsp),%rsi
  1ead3b:	vmovsd %xmm5,(%rsi,%rcx,1)
  1ead40:	vmovsd %xmm6,0x8(%rsi,%rcx,1)
  1ead46:	mov    0x30(%rsp),%rsi
  1ead4b:	cmp    %rsi,%rdi
  1ead4e:	jae    1ec301 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9151>
  1ead54:	mov    0x78(%rsp),%rcx
  1ead59:	vmovsd %xmm1,(%rcx,%rax,1)
  1ead5e:	vmovsd %xmm2,0x8(%rcx,%rax,1)
  1ead64:	cmp    %rsi,%r8
  1ead67:	jae    1ec795 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x95e5>
  1ead6d:	mov    %r8,%rdi
  1ead70:	vmovapd %xmm3,%xmm1
  1ead74:	vmovapd %xmm4,%xmm2
  1ead78:	jmp    1ead88 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7bd8>
  1ead7a:	mov    0x30(%rsp),%rsi
  1ead7f:	cmp    %rsi,%rdi
  1ead82:	jae    1ec301 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9151>
  1ead88:	shl    $0x4,%rdi
  1ead8c:	mov    0x78(%rsp),%rax
  1ead91:	vmovsd %xmm1,(%rax,%rdi,1)
  1ead96:	vmovsd %xmm2,0x8(%rax,%rdi,1)
  1ead9c:	vxorpd %xmm1,%xmm1,%xmm1
  1eada0:	vpcmpgtq %ymm0,%ymm1,%ymm0
  1eada5:	vpbroadcastq -0x1c4b06(%rip),%ymm1        # 262a8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x4d8>
  1eadae:	vpand  %ymm1,%ymm0,%ymm0
  1eadb2:	vextracti128 $0x1,%ymm0,%xmm1
  1eadb8:	vminpd %xmm1,%xmm0,%xmm0
  1eadbc:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1eadc1:	vminsd %xmm1,%xmm0,%xmm0
  1eadc5:	xor    %ecx,%ecx
  1eadc7:	vxorpd %xmm1,%xmm1,%xmm1
  1eadcb:	vucomisd %xmm1,%xmm0
  1eadcf:	movzbl 0x140(%rsp),%eax
  1eadd7:	jmp    1e98bf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x670f>
  1eaddc:	mov    0x68(%rsp),%rdx
  1eade1:	mov    0x90(%rsp),%rcx
  1eade9:	lea    (%rdx,%rcx,8),%rsi
  1eaded:	mov    %rsi,0x5a0(%rsp)
  1eadf5:	mov    0x50(%rsp),%rsi
  1eadfa:	lea    (%rsi,%rcx,8),%rdi
  1eadfe:	mov    %rdi,0x580(%rsp)
  1eae06:	mov    0x48(%rsp),%rdi
  1eae0b:	lea    (%rdi,%rcx,8),%r8
  1eae0f:	mov    %r8,0x620(%rsp)
  1eae17:	mov    0x70(%rsp),%r8
  1eae1c:	lea    (%r8,%rcx,8),%rcx
  1eae20:	mov    %rcx,0x430(%rsp)
  1eae28:	mov    0x108(%rsp),%rcx
  1eae30:	lea    -0x1(%rcx),%r9
  1eae34:	cmp    %rcx,%r9
  1eae37:	mov    %r9,0xe8(%rsp)
  1eae3f:	cmovb  %r9,%rcx
  1eae43:	mov    %rcx,0x200(%rsp)
  1eae4b:	mov    0x60(%rsp),%r9
  1eae50:	mov    %r9,%rcx
  1eae53:	xor    0xf0(%rsp),%rcx
  1eae5b:	or     %rax,%rcx
  1eae5e:	setne  0x410(%rsp)
  1eae66:	mov    0x2a0(%rsp),%r13
  1eae6e:	mov    %r13,%rax
  1eae71:	and    $0xfffffffffffffffe,%rax
  1eae75:	mov    %rax,0x3f0(%rsp)
  1eae7d:	mov    0x3c0(%rsp),%rax
  1eae85:	and    $0x2,%eax
  1eae88:	mov    %rax,0x3a0(%rsp)
  1eae90:	mov    $0x3a,%al
  1eae92:	bzhi   %rax,%r9,%rax
  1eae97:	shl    $0x5,%rax
  1eae9b:	lea    0x8(%rax),%rcx
  1eae9f:	mov    %rcx,0x4d0(%rsp)
  1eaea7:	lea    (%rdx,%rax,1),%rbp
  1eaeab:	add    $0x8,%rbp
  1eaeaf:	lea    0x8(%rsi,%rax,1),%r14
  1eaeb4:	lea    0x8(%rdi,%rax,1),%r15
  1eaeb9:	lea    0x8(%r8,%rax,1),%r10
  1eaebe:	movb   $0x1,0x140(%rsp)
  1eaec6:	mov    0x10(%rsp),%rdx
  1eaecb:	mov    0x28(%rsp),%r11
  1eaed0:	mov    0x20(%rsp),%r12
  1eaed5:	mov    0xd0(%rsp),%rcx
  1eaedd:	jmp    1eaf3c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7d8c>
  1eaedf:	shl    $0x4,%rax
  1eaee3:	mov    0x80(%rsp),%rcx
  1eaeeb:	vmovsd %xmm0,(%rcx,%rax,1)
  1eaef0:	vmovsd %xmm2,0x8(%rcx,%rax,1)
  1eaef6:	movzbl 0x1b0(%rsp),%eax
  1eaefe:	and    %al,0x140(%rsp)
  1eaf05:	mov    0xd0(%rsp),%rcx
  1eaf0d:	add    $0x2,%rcx
  1eaf11:	mov    0x98(%rsp),%rax
  1eaf19:	mov    %rax,0x110(%rsp)
  1eaf21:	mov    0x18(%rsp),%rax
  1eaf26:	mov    %rax,0x98(%rsp)
  1eaf2e:	cmp    0x310(%rsp),%rcx
  1eaf36:	jae    1e9b69 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x69b9>
  1eaf3c:	mov    %rdx,0x18(%rsp)
  1eaf41:	mov    0x110(%rsp),%r8
  1eaf49:	cmp    0xa8(%rsp),%rcx
  1eaf51:	mov    %rcx,0xd0(%rsp)
  1eaf59:	jae    1ec6ca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x951a>
  1eaf5f:	cmp    0xa0(%rsp),%rcx
  1eaf67:	jae    1ec6aa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x94fa>
  1eaf6d:	lea    0x1(%rcx),%rdi
  1eaf71:	cmp    0xa8(%rsp),%rdi
  1eaf79:	jae    1ec6ea <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x953a>
  1eaf7f:	cmp    0xa0(%rsp),%rdi
  1eaf87:	jae    1ea5c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7412>
  1eaf8d:	cmpb   $0x0,0x410(%rsp)
  1eaf95:	jne    1e6d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bad>
  1eaf9b:	mov    0x670(%rsp),%rax
  1eafa3:	mov    0xd0(%rsp),%rdx
  1eafab:	vmovsd (%rax,%rdx,8),%xmm0
  1eafb0:	mov    0x650(%rsp),%rcx
  1eafb8:	vmovsd (%rcx,%rdx,8),%xmm3
  1eafbd:	vmovsd 0x8(%rax,%rdx,8),%xmm1
  1eafc3:	vmovsd 0x8(%rcx,%rdx,8),%xmm2
  1eafc9:	mov    0x330(%rsp),%rax
  1eafd1:	test   %rax,%rax
  1eafd4:	vmovapd %xmm0,0x1e0(%rsp)
  1eafdd:	vmovapd %xmm1,0x260(%rsp)
  1eafe6:	vmovapd %xmm2,0x190(%rsp)
  1eafef:	vmovapd %xmm3,0x160(%rsp)
  1eaff8:	je     1eb0cd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7f1d>
  1eaffe:	vbroadcastsd %xmm0,%ymm12
  1eb003:	vbroadcastsd %xmm3,%ymm13
  1eb008:	vbroadcastsd %xmm1,%ymm14
  1eb00d:	vbroadcastsd %xmm2,%ymm15
  1eb012:	vxorpd %xmm4,%xmm4,%xmm4
  1eb016:	xor    %ecx,%ecx
  1eb018:	vxorpd %xmm2,%xmm2,%xmm2
  1eb01c:	vxorpd %xmm5,%xmm5,%xmm5
  1eb020:	vxorpd %xmm3,%xmm3,%xmm3
  1eb024:	vxorpd %xmm7,%xmm7,%xmm7
  1eb028:	vxorpd %xmm6,%xmm6,%xmm6
  1eb02c:	vxorpd %xmm9,%xmm9,%xmm9
  1eb031:	vxorpd %xmm8,%xmm8,%xmm8
  1eb036:	mov    0x58(%rsp),%rsi
  1eb03b:	mov    0x40(%rsp),%rdx
  1eb040:	mov    0x360(%rsp),%rdi
  1eb048:	mov    0x98(%rsp),%r9
  1eb050:	mov    0x18(%rsp),%rbx
  1eb055:	vmovupd (%rbx,%rcx,1),%ymm10
  1eb05a:	vmovupd (%rsi,%rcx,1),%ymm11
  1eb05f:	vfmadd231pd %ymm10,%ymm11,%ymm8
  1eb064:	vmovupd (%rdi,%rcx,1),%ymm0
  1eb069:	vmovapd %ymm0,%ymm1
  1eb06d:	vfmadd213pd %ymm13,%ymm12,%ymm1
  1eb072:	vfmadd213pd (%r8,%rcx,1),%ymm10,%ymm1
  1eb078:	vfmadd231pd %ymm11,%ymm1,%ymm3
  1eb07d:	vmovupd (%r11,%rcx,1),%ymm11
  1eb083:	vfmadd231pd %ymm10,%ymm11,%ymm9
  1eb088:	vfmadd231pd %ymm11,%ymm1,%ymm5
  1eb08d:	vmovupd (%r12,%rcx,1),%ymm11
  1eb093:	vfmadd231pd %ymm10,%ymm11,%ymm6
  1eb098:	vfmadd231pd %ymm11,%ymm1,%ymm2
  1eb09d:	vmovupd (%rdx,%rcx,1),%ymm11
  1eb0a2:	vfmadd231pd %ymm10,%ymm11,%ymm7
  1eb0a7:	vfmadd231pd %ymm11,%ymm1,%ymm4
  1eb0ac:	vfmadd213pd %ymm15,%ymm14,%ymm0
  1eb0b1:	vfmadd213pd %ymm10,%ymm1,%ymm0
  1eb0b6:	vmovupd %ymm1,(%r9,%rcx,1)
  1eb0bc:	vmovupd %ymm0,(%r8,%rcx,1)
  1eb0c2:	add    $0x20,%rcx
  1eb0c6:	dec    %rax
  1eb0c9:	jne    1eb055 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7ea5>
  1eb0cb:	jmp    1eb0fc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7f4c>
  1eb0cd:	vxorpd %xmm8,%xmm8,%xmm8
  1eb0d2:	vxorpd %xmm9,%xmm9,%xmm9
  1eb0d7:	vxorpd %xmm6,%xmm6,%xmm6
  1eb0db:	vxorpd %xmm7,%xmm7,%xmm7
  1eb0df:	vxorpd %xmm3,%xmm3,%xmm3
  1eb0e3:	vxorpd %xmm5,%xmm5,%xmm5
  1eb0e7:	vxorpd %xmm2,%xmm2,%xmm2
  1eb0eb:	vxorpd %xmm4,%xmm4,%xmm4
  1eb0ef:	mov    0x98(%rsp),%r9
  1eb0f7:	mov    0x18(%rsp),%rbx
  1eb0fc:	mov    0x90(%rsp),%rax
  1eb104:	lea    (%rbx,%rax,8),%rdx
  1eb108:	lea    (%r9,%rax,8),%rcx
  1eb10c:	vextractf128 $0x1,%ymm8,%xmm0
  1eb112:	vaddpd %xmm0,%xmm8,%xmm0
  1eb116:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1eb11b:	vaddsd %xmm1,%xmm0,%xmm8
  1eb11f:	vextractf128 $0x1,%ymm9,%xmm0
  1eb125:	vaddpd %xmm0,%xmm9,%xmm0
  1eb129:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1eb12e:	vaddsd %xmm1,%xmm0,%xmm9
  1eb132:	vextractf128 $0x1,%ymm6,%xmm0
  1eb138:	vaddpd %xmm0,%xmm6,%xmm0
  1eb13c:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1eb141:	vaddsd %xmm1,%xmm0,%xmm6
  1eb145:	vextractf128 $0x1,%ymm7,%xmm0
  1eb14b:	vaddpd %xmm0,%xmm7,%xmm0
  1eb14f:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1eb154:	vaddsd %xmm1,%xmm0,%xmm7
  1eb158:	vextractf128 $0x1,%ymm3,%xmm0
  1eb15e:	vaddpd %xmm0,%xmm3,%xmm0
  1eb162:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1eb167:	vaddsd %xmm1,%xmm0,%xmm3
  1eb16b:	vextractf128 $0x1,%ymm5,%xmm0
  1eb171:	vaddpd %xmm0,%xmm5,%xmm0
  1eb175:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1eb17a:	vaddsd %xmm1,%xmm0,%xmm5
  1eb17e:	vextractf128 $0x1,%ymm2,%xmm0
  1eb184:	vaddpd %xmm0,%xmm2,%xmm0
  1eb188:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1eb18d:	vaddsd %xmm1,%xmm0,%xmm2
  1eb191:	vextractf128 $0x1,%ymm4,%xmm0
  1eb197:	vaddpd %xmm0,%xmm4,%xmm0
  1eb19b:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1eb1a0:	vaddsd %xmm1,%xmm0,%xmm4
  1eb1a4:	cmpq   $0x0,0x120(%rsp)
  1eb1ad:	mov    %r8,0x10(%rsp)
  1eb1b2:	mov    %rcx,0xb8(%rsp)
  1eb1ba:	mov    %rdx,0x280(%rsp)
  1eb1c2:	je     1eb30c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x815c>
  1eb1c8:	cmpq   $0x0,0x108(%rsp)
  1eb1d1:	vmovapd 0x1e0(%rsp),%xmm1
  1eb1da:	vmovapd 0x260(%rsp),%xmm11
  1eb1e3:	vmovapd 0x190(%rsp),%xmm15
  1eb1ec:	vmovapd 0x160(%rsp),%xmm10
  1eb1f5:	je     1e6d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bad>
  1eb1fb:	mov    0x258(%rsp),%rax
  1eb203:	vmovsd (%rax),%xmm12
  1eb207:	vmovapd %xmm12,%xmm13
  1eb20c:	vfmadd213sd %xmm10,%xmm1,%xmm13
  1eb211:	vmovsd (%rdx),%xmm14
  1eb215:	mov    0x90(%rsp),%rdx
  1eb21d:	vfmadd213sd (%r8,%rdx,8),%xmm14,%xmm13
  1eb223:	vfmadd213sd %xmm15,%xmm11,%xmm12
  1eb228:	vfmadd213sd %xmm14,%xmm13,%xmm12
  1eb22d:	mov    0x40(%rsp),%rax
  1eb232:	vmovsd (%rax,%rdx,8),%xmm0
  1eb237:	vfmadd231sd %xmm13,%xmm0,%xmm4
  1eb23c:	vfmadd231sd %xmm0,%xmm14,%xmm7
  1eb241:	vmovsd (%r12,%rdx,8),%xmm0
  1eb247:	vfmadd231sd %xmm13,%xmm0,%xmm2
  1eb24c:	vfmadd231sd %xmm0,%xmm14,%xmm6
  1eb251:	vmovsd (%r11,%rdx,8),%xmm0
  1eb257:	vfmadd231sd %xmm13,%xmm0,%xmm5
  1eb25c:	vfmadd231sd %xmm0,%xmm14,%xmm9
  1eb261:	mov    0x58(%rsp),%rax
  1eb266:	vmovsd (%rax,%rdx,8),%xmm0
  1eb26b:	vfmadd231sd %xmm14,%xmm0,%xmm8
  1eb270:	vfmadd231sd %xmm13,%xmm0,%xmm3
  1eb275:	vmovsd %xmm13,(%rcx)
  1eb279:	vmovq  %xmm13,%rax
  1eb27e:	vmovq  %xmm12,%rcx
  1eb283:	vmovsd %xmm12,(%r8,%rdx,8)
  1eb289:	mov    $0x3f,%r9b
  1eb28c:	bzhi   %r9,%rax,%rax
  1eb291:	movabs $0x7ff0000000000000,%rdx
  1eb29b:	cmp    %rdx,%rax
  1eb29e:	sete   %sil
  1eb2a2:	test   %rax,%rax
  1eb2a5:	sete   %dil
  1eb2a9:	or     %sil,%dil
  1eb2ac:	movabs $0xfff0000000000000,%r13
  1eb2b6:	add    %r13,%rax
  1eb2b9:	shr    $0x35,%rax
  1eb2bd:	cmp    $0x3ff,%eax
  1eb2c2:	setb   %al
  1eb2c5:	or     %dil,%al
  1eb2c8:	bzhi   %r9,%rcx,%rcx
  1eb2cd:	cmp    %rdx,%rcx
  1eb2d0:	sete   %sil
  1eb2d4:	test   %rcx,%rcx
  1eb2d7:	sete   %dil
  1eb2db:	or     %sil,%dil
  1eb2de:	add    %r13,%rcx
  1eb2e1:	shr    $0x35,%rcx
  1eb2e5:	cmp    $0x3ff,%ecx
  1eb2eb:	setb   %r13b
  1eb2ef:	or     %dil,%r13b
  1eb2f2:	and    %al,%r13b
  1eb2f5:	cmpl   $0x1,0x120(%rsp)
  1eb2fd:	jne    1eb31e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x816e>
  1eb2ff:	mov    %r13b,0x1b0(%rsp)
  1eb307:	jmp    1eb599 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x83e9>
  1eb30c:	movb   $0x1,0x1b0(%rsp)
  1eb314:	mov    0x30(%rsp),%rax
  1eb319:	jmp    1eb5a6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x83f6>
  1eb31e:	cmpl   $0x1,0x108(%rsp)
  1eb326:	je     1e6d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bad>
  1eb32c:	mov    0x258(%rsp),%rax
  1eb334:	vmovsd 0x8(%rax),%xmm12
  1eb339:	vmovapd %xmm12,%xmm13
  1eb33e:	vfmadd213sd %xmm10,%xmm1,%xmm13
  1eb343:	mov    0x280(%rsp),%rax
  1eb34b:	vmovsd 0x8(%rax),%xmm14
  1eb350:	mov    0x90(%rsp),%rdx
  1eb358:	vfmadd213sd 0x8(%r8,%rdx,8),%xmm14,%xmm13
  1eb35f:	vfmadd213sd %xmm15,%xmm11,%xmm12
  1eb364:	vfmadd213sd %xmm14,%xmm13,%xmm12
  1eb369:	mov    0x40(%rsp),%rax
  1eb36e:	vmovsd 0x8(%rax,%rdx,8),%xmm0
  1eb374:	vfmadd231sd %xmm13,%xmm0,%xmm4
  1eb379:	vfmadd231sd %xmm0,%xmm14,%xmm7
  1eb37e:	vmovsd 0x8(%r12,%rdx,8),%xmm0
  1eb385:	vfmadd231sd %xmm13,%xmm0,%xmm2
  1eb38a:	vfmadd231sd %xmm0,%xmm14,%xmm6
  1eb38f:	vmovsd 0x8(%r11,%rdx,8),%xmm0
  1eb396:	vfmadd231sd %xmm13,%xmm0,%xmm5
  1eb39b:	vfmadd231sd %xmm0,%xmm14,%xmm9
  1eb3a0:	mov    0x58(%rsp),%rax
  1eb3a5:	vmovsd 0x8(%rax,%rdx,8),%xmm0
  1eb3ab:	vfmadd231sd %xmm14,%xmm0,%xmm8
  1eb3b0:	vfmadd231sd %xmm13,%xmm0,%xmm3
  1eb3b5:	vmovq  %xmm13,%rax
  1eb3ba:	mov    0xb8(%rsp),%rcx
  1eb3c2:	vmovsd %xmm13,0x8(%rcx)
  1eb3c7:	vmovq  %xmm12,%rcx
  1eb3cc:	vmovsd %xmm12,0x8(%r8,%rdx,8)
  1eb3d3:	mov    $0x3f,%r8b
  1eb3d6:	bzhi   %r8,%rax,%rax
  1eb3db:	movabs $0x7ff0000000000000,%rdx
  1eb3e5:	cmp    %rdx,%rax
  1eb3e8:	sete   %sil
  1eb3ec:	test   %rax,%rax
  1eb3ef:	sete   %dil
  1eb3f3:	or     %sil,%dil
  1eb3f6:	movabs $0xfff0000000000000,%r9
  1eb400:	add    %r9,%rax
  1eb403:	shr    $0x35,%rax
  1eb407:	cmp    $0x3ff,%eax
  1eb40c:	setb   %al
  1eb40f:	or     %dil,%al
  1eb412:	bzhi   %r8,%rcx,%rcx
  1eb417:	cmp    %rdx,%rcx
  1eb41a:	sete   %sil
  1eb41e:	test   %rcx,%rcx
  1eb421:	sete   %dil
  1eb425:	or     %sil,%dil
  1eb428:	add    %r9,%rcx
  1eb42b:	shr    $0x35,%rcx
  1eb42f:	cmp    $0x3ff,%ecx
  1eb435:	setb   %cl
  1eb438:	or     %dil,%cl
  1eb43b:	and    %al,%cl
  1eb43d:	and    %cl,%r13b
  1eb440:	mov    %r13b,0x1b0(%rsp)
  1eb448:	cmpl   $0x2,0x120(%rsp)
  1eb450:	je     1eb599 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x83e9>
  1eb456:	cmpl   $0x2,0x108(%rsp)
  1eb45e:	je     1e6d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x3bad>
  1eb464:	vmovapd %xmm11,%xmm1
  1eb468:	mov    0x258(%rsp),%rax
  1eb470:	vmovsd 0x10(%rax),%xmm0
  1eb475:	vmovapd 0x1e0(%rsp),%xmm13
  1eb47e:	vfmadd213sd %xmm10,%xmm0,%xmm13
  1eb483:	mov    0x280(%rsp),%rax
  1eb48b:	vmovsd 0x10(%rax),%xmm11
  1eb490:	mov    0x10(%rsp),%r8
  1eb495:	mov    0x90(%rsp),%rdx
  1eb49d:	vfmadd213sd 0x10(%r8,%rdx,8),%xmm11,%xmm13
  1eb4a4:	vmovq  %xmm13,%rax
  1eb4a9:	mov    $0x3f,%r9b
  1eb4ac:	bzhi   %r9,%rax,%rax
  1eb4b1:	movabs $0x7ff0000000000000,%rdi
  1eb4bb:	cmp    %rdi,%rax
  1eb4be:	sete   %cl
  1eb4c1:	test   %rax,%rax
  1eb4c4:	sete   %sil
  1eb4c8:	or     %cl,%sil
  1eb4cb:	movabs $0xfff0000000000000,%r11
  1eb4d5:	add    %r11,%rax
  1eb4d8:	shr    $0x35,%rax
  1eb4dc:	cmp    $0x3ff,%eax
  1eb4e1:	setb   %al
  1eb4e4:	or     %sil,%al
  1eb4e7:	vmovapd %xmm1,%xmm14
  1eb4eb:	vfmadd213sd 0x190(%rsp),%xmm0,%xmm14
  1eb4f5:	vfmadd213sd %xmm11,%xmm13,%xmm14
  1eb4fa:	vmovq  %xmm14,%rcx
  1eb4ff:	bzhi   %r9,%rcx,%rcx
  1eb504:	cmp    %rdi,%rcx
  1eb507:	sete   %sil
  1eb50b:	test   %rcx,%rcx
  1eb50e:	sete   %dil
  1eb512:	or     %sil,%dil
  1eb515:	add    %r11,%rcx
  1eb518:	shr    $0x35,%rcx
  1eb51c:	cmp    $0x3ff,%ecx
  1eb522:	setb   %cl
  1eb525:	or     %dil,%cl
  1eb528:	and    %al,%cl
  1eb52a:	and    %cl,0x1b0(%rsp)
  1eb531:	mov    0x40(%rsp),%rax
  1eb536:	vmovsd 0x10(%rax,%rdx,8),%xmm0
  1eb53c:	vfmadd231sd %xmm13,%xmm0,%xmm4
  1eb541:	mov    0x20(%rsp),%rax
  1eb546:	vmovsd 0x10(%rax,%rdx,8),%xmm1
  1eb54c:	vfmadd231sd %xmm13,%xmm1,%xmm2
  1eb551:	mov    0x28(%rsp),%rax
  1eb556:	vmovsd 0x10(%rax,%rdx,8),%xmm10
  1eb55c:	vfmadd231sd %xmm13,%xmm10,%xmm5
  1eb561:	mov    0x58(%rsp),%rax
  1eb566:	vmovsd 0x10(%rax,%rdx,8),%xmm12
  1eb56c:	vfmadd231sd %xmm13,%xmm12,%xmm3
  1eb571:	vfmadd231sd %xmm0,%xmm11,%xmm7
  1eb576:	vfmadd231sd %xmm1,%xmm11,%xmm6
  1eb57b:	vfmadd231sd %xmm10,%xmm11,%xmm9
  1eb580:	vfmadd231sd %xmm11,%xmm12,%xmm8
  1eb585:	mov    0xb8(%rsp),%rax
  1eb58d:	vmovsd %xmm13,0x10(%rax)
  1eb592:	vmovsd %xmm14,0x10(%r8,%rdx,8)
  1eb599:	mov    0x30(%rsp),%rax
  1eb59e:	mov    0x2a0(%rsp),%r13
  1eb5a6:	mov    0xd0(%rsp),%rdx
  1eb5ae:	lea    (%rdx,%rdx,1),%rdi
  1eb5b2:	cmp    %rax,%rdi
  1eb5b5:	jae    1ec1c6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9016>
  1eb5bb:	mov    %rdi,%r9
  1eb5be:	shl    $0x4,%r9
  1eb5c2:	mov    0x78(%rsp),%rax
  1eb5c7:	vmovsd %xmm8,(%rax,%r9,1)
  1eb5cd:	mov    0x188(%rsp),%rcx
  1eb5d5:	lea    (%rcx,%rdx,2),%rbx
  1eb5d9:	vmovsd %xmm9,0x8(%rax,%r9,1)
  1eb5e0:	cmp    0xe0(%rsp),%rbx
  1eb5e8:	jae    1eb60d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x845d>
  1eb5ea:	lea    0x1(%rdi),%rax
  1eb5ee:	cmp    0x30(%rsp),%rax
  1eb5f3:	jae    1ec74d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x959d>
  1eb5f9:	shl    $0x4,%rax
  1eb5fd:	mov    0x78(%rsp),%rcx
  1eb602:	vmovsd %xmm6,(%rcx,%rax,1)
  1eb607:	vmovsd %xmm7,0x8(%rcx,%rax,1)
  1eb60d:	lea    0x2(%rbx),%rdx
  1eb611:	mov    %rdx,%rax
  1eb614:	sub    0x188(%rsp),%rax
  1eb61c:	cmp    0x30(%rsp),%rax
  1eb621:	jae    1ec702 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9552>
  1eb627:	mov    %rax,%r8
  1eb62a:	shl    $0x4,%r8
  1eb62e:	mov    0x78(%rsp),%rcx
  1eb633:	vmovsd %xmm3,(%rcx,%r8,1)
  1eb639:	vmovsd %xmm5,0x8(%rcx,%r8,1)
  1eb640:	cmp    0xe0(%rsp),%rdx
  1eb648:	jae    1eb66d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x84bd>
  1eb64a:	lea    0x1(%rax),%rcx
  1eb64e:	cmp    0x30(%rsp),%rcx
  1eb653:	jae    1ec765 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x95b5>
  1eb659:	shl    $0x4,%rcx
  1eb65d:	mov    0x78(%rsp),%rsi
  1eb662:	vmovsd %xmm2,(%rsi,%rcx,1)
  1eb667:	vmovsd %xmm4,0x8(%rsi,%rcx,1)
  1eb66d:	vxorpd %xmm2,%xmm2,%xmm2
  1eb671:	test   %r13,%r13
  1eb674:	mov    %rdx,0x1e0(%rsp)
  1eb67c:	mov    %r8,0x190(%rsp)
  1eb684:	je     1eb6b5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8505>
  1eb686:	cmp    $0x1,%r13
  1eb68a:	jne    1eb6dc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x852c>
  1eb68c:	vxorpd %xmm0,%xmm0,%xmm0
  1eb690:	vxorpd %xmm6,%xmm6,%xmm6
  1eb694:	vxorpd %xmm3,%xmm3,%xmm3
  1eb698:	vxorpd %xmm1,%xmm1,%xmm1
  1eb69c:	vxorpd %xmm5,%xmm5,%xmm5
  1eb6a0:	xor    %ecx,%ecx
  1eb6a2:	vxorpd %xmm4,%xmm4,%xmm4
  1eb6a6:	vxorpd %xmm8,%xmm8,%xmm8
  1eb6ab:	mov    0x70(%rsp),%r8
  1eb6b0:	jmp    1eb806 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8656>
  1eb6b5:	vxorpd %xmm0,%xmm0,%xmm0
  1eb6b9:	vxorpd %xmm6,%xmm6,%xmm6
  1eb6bd:	vxorpd %xmm3,%xmm3,%xmm3
  1eb6c1:	vxorpd %xmm1,%xmm1,%xmm1
  1eb6c5:	vxorpd %xmm5,%xmm5,%xmm5
  1eb6c9:	vxorpd %xmm8,%xmm8,%xmm8
  1eb6ce:	vxorpd %xmm4,%xmm4,%xmm4
  1eb6d2:	mov    0x70(%rsp),%r8
  1eb6d7:	jmp    1eb86d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x86bd>
  1eb6dc:	mov    %rbx,0x160(%rsp)
  1eb6e4:	mov    %r9,0x260(%rsp)
  1eb6ec:	mov    $0x20,%esi
  1eb6f1:	vxorpd %xmm0,%xmm0,%xmm0
  1eb6f5:	vxorpd %xmm6,%xmm6,%xmm6
  1eb6f9:	vxorpd %xmm3,%xmm3,%xmm3
  1eb6fd:	vxorpd %xmm1,%xmm1,%xmm1
  1eb701:	vxorpd %xmm5,%xmm5,%xmm5
  1eb705:	xor    %ecx,%ecx
  1eb707:	vxorpd %xmm4,%xmm4,%xmm4
  1eb70b:	vxorpd %xmm8,%xmm8,%xmm8
  1eb710:	mov    0x68(%rsp),%r11
  1eb715:	mov    0x50(%rsp),%r13
  1eb71a:	mov    0x48(%rsp),%r8
  1eb71f:	mov    0x70(%rsp),%r12
  1eb724:	mov    0x98(%rsp),%rdx
  1eb72c:	mov    0x3f0(%rsp),%r9
  1eb734:	mov    0x18(%rsp),%rbx
  1eb739:	vmovupd -0x20(%r11,%rsi,1),%ymm7
  1eb740:	vmovupd -0x20(%rbx,%rsi,1),%ymm9
  1eb746:	vfmadd231pd %ymm9,%ymm7,%ymm4
  1eb74b:	vmovupd -0x20(%r13,%rsi,1),%ymm10
  1eb752:	vfmadd231pd %ymm9,%ymm10,%ymm5
  1eb757:	vmovupd -0x20(%r8,%rsi,1),%ymm11
  1eb75e:	vfmadd231pd %ymm9,%ymm11,%ymm1
  1eb763:	vmovupd -0x20(%r12,%rsi,1),%ymm12
  1eb76a:	vfmadd231pd %ymm9,%ymm12,%ymm3
  1eb76f:	vmovupd -0x20(%rdx,%rsi,1),%ymm9
  1eb775:	vfmadd231pd %ymm7,%ymm9,%ymm8
  1eb77a:	vmovupd (%r11,%rsi,1),%ymm7
  1eb780:	vfmadd231pd %ymm10,%ymm9,%ymm6
  1eb785:	vmovupd (%rbx,%rsi,1),%ymm10
  1eb78a:	vfmadd231pd %ymm11,%ymm9,%ymm0
  1eb78f:	vmovupd 0x0(%r13,%rsi,1),%ymm11
  1eb796:	vfmadd231pd %ymm9,%ymm12,%ymm2
  1eb79b:	vmovupd (%r8,%rsi,1),%ymm9
  1eb7a1:	vmovupd (%r12,%rsi,1),%ymm12
  1eb7a7:	vfmadd231pd %ymm10,%ymm7,%ymm4
  1eb7ac:	vfmadd231pd %ymm10,%ymm11,%ymm5
  1eb7b1:	vfmadd231pd %ymm10,%ymm9,%ymm1
  1eb7b6:	vfmadd231pd %ymm10,%ymm12,%ymm3
  1eb7bb:	vmovupd (%rdx,%rsi,1),%ymm10
  1eb7c0:	vfmadd231pd %ymm7,%ymm10,%ymm8
  1eb7c5:	vfmadd231pd %ymm11,%ymm10,%ymm6
  1eb7ca:	vfmadd231pd %ymm9,%ymm10,%ymm0
  1eb7cf:	vfmadd231pd %ymm10,%ymm12,%ymm2
  1eb7d4:	add    $0x2,%rcx
  1eb7d8:	add    $0x40,%rsi
  1eb7dc:	cmp    %rcx,%r9
  1eb7df:	jne    1eb739 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8589>
  1eb7e5:	mov    0x2a0(%rsp),%r13
  1eb7ed:	test   $0x1,%r13b
  1eb7f1:	mov    %r12,%r8
  1eb7f4:	mov    0x260(%rsp),%r9
  1eb7fc:	mov    0x160(%rsp),%rbx
  1eb804:	je     1eb86d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x86bd>
  1eb806:	shl    $0x5,%rcx
  1eb80a:	mov    0x68(%rsp),%rsi
  1eb80f:	vmovupd (%rsi,%rcx,1),%ymm7
  1eb814:	mov    0x18(%rsp),%rdx
  1eb819:	vmovupd (%rdx,%rcx,1),%ymm9
  1eb81e:	vfmadd231pd %ymm9,%ymm7,%ymm4
  1eb823:	mov    0x50(%rsp),%rsi
  1eb828:	vmovupd (%rsi,%rcx,1),%ymm10
  1eb82d:	vfmadd231pd %ymm9,%ymm10,%ymm5
  1eb832:	mov    0x48(%rsp),%rsi
  1eb837:	vmovupd (%rsi,%rcx,1),%ymm11
  1eb83c:	vfmadd231pd %ymm9,%ymm11,%ymm1
  1eb841:	vmovupd (%r8,%rcx,1),%ymm12
  1eb847:	vfmadd231pd %ymm9,%ymm12,%ymm3
  1eb84c:	mov    0x98(%rsp),%rdx
  1eb854:	vmovupd (%rdx,%rcx,1),%ymm9
  1eb859:	vfmadd231pd %ymm7,%ymm9,%ymm8
  1eb85e:	vfmadd231pd %ymm10,%ymm9,%ymm6
  1eb863:	vfmadd231pd %ymm11,%ymm9,%ymm0
  1eb868:	vfmadd231pd %ymm9,%ymm12,%ymm2
  1eb86d:	vextractf128 $0x1,%ymm4,%xmm7
  1eb873:	vaddpd %xmm7,%xmm4,%xmm4
  1eb877:	vshufpd $0x1,%xmm4,%xmm4,%xmm7
  1eb87c:	vaddsd %xmm7,%xmm4,%xmm4
  1eb880:	vextractf128 $0x1,%ymm5,%xmm7
  1eb886:	vaddpd %xmm7,%xmm5,%xmm5
  1eb88a:	vshufpd $0x1,%xmm5,%xmm5,%xmm7
  1eb88f:	vaddsd %xmm7,%xmm5,%xmm7
  1eb893:	vextractf128 $0x1,%ymm1,%xmm5
  1eb899:	vaddpd %xmm5,%xmm1,%xmm1
  1eb89d:	vshufpd $0x1,%xmm1,%xmm1,%xmm5
  1eb8a2:	vaddsd %xmm5,%xmm1,%xmm1
  1eb8a6:	vextractf128 $0x1,%ymm3,%xmm5
  1eb8ac:	vaddpd %xmm5,%xmm3,%xmm3
  1eb8b0:	vshufpd $0x1,%xmm3,%xmm3,%xmm5
  1eb8b5:	vaddsd %xmm5,%xmm3,%xmm5
  1eb8b9:	vextractf128 $0x1,%ymm8,%xmm3
  1eb8bf:	vaddpd %xmm3,%xmm8,%xmm3
  1eb8c3:	vshufpd $0x1,%xmm3,%xmm3,%xmm8
  1eb8c8:	vaddsd %xmm3,%xmm8,%xmm3
  1eb8cc:	vextractf128 $0x1,%ymm6,%xmm8
  1eb8d2:	vaddpd %xmm6,%xmm8,%xmm6
  1eb8d6:	vshufpd $0x1,%xmm6,%xmm6,%xmm8
  1eb8db:	vaddsd %xmm6,%xmm8,%xmm6
  1eb8df:	vextractf128 $0x1,%ymm0,%xmm8
  1eb8e5:	vaddpd %xmm0,%xmm8,%xmm0
  1eb8e9:	vshufpd $0x1,%xmm0,%xmm0,%xmm8
  1eb8ee:	vaddsd %xmm0,%xmm8,%xmm0
  1eb8f2:	vextractf128 $0x1,%ymm2,%xmm8
  1eb8f8:	vaddpd %xmm2,%xmm8,%xmm2
  1eb8fc:	vshufpd $0x1,%xmm2,%xmm2,%xmm8
  1eb901:	vaddsd %xmm2,%xmm8,%xmm2
  1eb905:	cmpq   $0x0,0x2c0(%rsp)
  1eb90e:	je     1eba20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8870>
  1eb914:	mov    0x200(%rsp),%rcx
  1eb91c:	cmp    %ecx,0x108(%rsp)
  1eb923:	je     1ec732 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x9582>
  1eb929:	cmpq   $0x0,0xe8(%rsp)
  1eb932:	je     1eba2f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x887f>
  1eb938:	mov    0x4d0(%rsp),%rdx
  1eb940:	mov    0x18(%rsp),%rcx
  1eb945:	lea    (%rcx,%rdx,1),%rsi
  1eb949:	mov    0x98(%rsp),%rcx
  1eb951:	lea    (%rcx,%rdx,1),%r11
  1eb955:	xor    %ecx,%ecx
  1eb957:	mov    0x3a0(%rsp),%rdx
  1eb95f:	vmovsd -0x8(%rbp,%rcx,8),%xmm8
  1eb965:	vmovsd -0x8(%rsi,%rcx,8),%xmm9
  1eb96b:	vfmadd231sd %xmm9,%xmm8,%xmm4
  1eb970:	vmovsd -0x8(%r14,%rcx,8),%xmm10
  1eb977:	vfmadd231sd %xmm9,%xmm10,%xmm7
  1eb97c:	vmovsd -0x8(%r15,%rcx,8),%xmm11
  1eb983:	vfmadd231sd %xmm9,%xmm11,%xmm1
  1eb988:	vmovsd -0x8(%r10,%rcx,8),%xmm12
  1eb98f:	vfmadd231sd %xmm9,%xmm12,%xmm5
  1eb994:	vmovsd -0x8(%r11,%rcx,8),%xmm9
  1eb99b:	vfmadd231sd %xmm8,%xmm9,%xmm3
  1eb9a0:	vmovsd 0x0(%rbp,%rcx,8),%xmm8
  1eb9a6:	vfmadd231sd %xmm10,%xmm9,%xmm6
  1eb9ab:	vmovsd (%rsi,%rcx,8),%xmm10
  1eb9b0:	vfmadd231sd %xmm11,%xmm9,%xmm0
  1eb9b5:	vmovsd (%r14,%rcx,8),%xmm11
  1eb9bb:	vfmadd231sd %xmm9,%xmm12,%xmm2
  1eb9c0:	vmovsd (%r15,%rcx,8),%xmm9
  1eb9c6:	vmovsd (%r10,%rcx,8),%xmm12
  1eb9cc:	vfmadd231sd %xmm10,%xmm8,%xmm4
  1eb9d1:	vfmadd231sd %xmm10,%xmm11,%xmm7
  1eb9d6:	vfmadd231sd %xmm10,%xmm9,%xmm1
  1eb9db:	vfmadd231sd %xmm10,%xmm12,%xmm5
  1eb9e0:	vmovsd (%r11,%rcx,8),%xmm10
  1eb9e6:	vfmadd231sd %xmm8,%xmm10,%xmm3
  1eb9eb:	vfmadd231sd %xmm11,%xmm10,%xmm6
  1eb9f0:	vfmadd231sd %xmm9,%xmm10,%xmm0
  1eb9f5:	vfmadd231sd %xmm10,%xmm12,%xmm2
  1eb9fa:	add    $0x2,%rcx
  1eb9fe:	cmp    %rcx,%rdx
  1eba01:	jne    1eb95f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x87af>
  1eba07:	testb  $0x1,0x3c0(%rsp)
  1eba0f:	mov    0x28(%rsp),%r11
  1eba14:	mov    0x20(%rsp),%r12
  1eba19:	jne    1eba3b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x888b>
  1eba1b:	jmp    1ebab1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8901>
  1eba20:	mov    0x28(%rsp),%r11
  1eba25:	mov    0x20(%rsp),%r12
  1eba2a:	jmp    1ebab1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8901>
  1eba2f:	xor    %ecx,%ecx
  1eba31:	mov    0x28(%rsp),%r11
  1eba36:	mov    0x20(%rsp),%r12
  1eba3b:	mov    0x5a0(%rsp),%rdx
  1eba43:	vmovsd (%rdx,%rcx,8),%xmm8
  1eba48:	mov    0x280(%rsp),%rdx
  1eba50:	vmovsd (%rdx,%rcx,8),%xmm9
  1eba55:	vfmadd231sd %xmm9,%xmm8,%xmm4
  1eba5a:	mov    0x580(%rsp),%rdx
  1eba62:	vmovsd (%rdx,%rcx,8),%xmm10
  1eba67:	vfmadd231sd %xmm9,%xmm10,%xmm7
  1eba6c:	mov    0x620(%rsp),%rdx
  1eba74:	vmovsd (%rdx,%rcx,8),%xmm11
  1eba79:	vfmadd231sd %xmm9,%xmm11,%xmm1
  1eba7e:	mov    0x430(%rsp),%rdx
  1eba86:	vmovsd (%rdx,%rcx,8),%xmm12
  1eba8b:	vfmadd231sd %xmm9,%xmm12,%xmm5
  1eba90:	mov    0xb8(%rsp),%rdx
  1eba98:	vmovsd (%rdx,%rcx,8),%xmm9
  1eba9d:	vfmadd231sd %xmm8,%xmm9,%xmm3
  1ebaa2:	vfmadd231sd %xmm10,%xmm9,%xmm6
  1ebaa7:	vfmadd231sd %xmm11,%xmm9,%xmm0
  1ebaac:	vfmadd231sd %xmm9,%xmm12,%xmm2
  1ebab1:	cmp    0x38(%rsp),%rdi
  1ebab6:	jae    1ec17b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8fcb>
  1ebabc:	mov    0x80(%rsp),%rcx
  1ebac4:	vmovsd %xmm4,(%rcx,%r9,1)
  1ebaca:	vmovsd %xmm7,0x8(%rcx,%r9,1)
  1ebad1:	cmp    0xe0(%rsp),%rbx
  1ebad9:	jae    1ebb00 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x8950>
  1ebadb:	inc    %rdi
  1ebade:	cmp    0x38(%rsp),%rdi
  1ebae3:	jae    1e7acf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x491f>
  1ebae9:	shl    $0x4,%rdi
  1ebaed:	mov    0x80(%rsp),%rcx
  1ebaf5:	vmovsd %xmm1,(%rcx,%rdi,1)
  1ebafa:	vmovsd %xmm5,0x8(%rcx,%rdi,1)
  1ebb00:	cmp    0x38(%rsp),%rax
  1ebb05:	jae    1ec71a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x956a>
  1ebb0b:	mov    0x80(%rsp),%rcx
  1ebb13:	mov    0x190(%rsp),%rdx
  1ebb1b:	vmovsd %xmm3,(%rcx,%rdx,1)
  1ebb20:	vmovsd %xmm6,0x8(%rcx,%rdx,1)
  1ebb26:	mov    0x1e0(%rsp),%rcx
  1ebb2e:	cmp    0xe0(%rsp),%rcx
  1ebb36:	mov    0x10(%rsp),%rdx
  1ebb3b:	jae    1eaef6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7d46>
  1ebb41:	inc    %rax
  1ebb44:	cmp    0x38(%rsp),%rax
  1ebb49:	jb     1eaedf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<false>>>+0x7d2f>
  1ebb4f:	lea    0x106a2a(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1ebb56:	mov    %rax,%rdi
  1ebb59:	mov    0x38(%rsp),%rsi
  1ebb5e:	vzeroupper
  1ebb61:	call   *0x1117d9(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebb67:	lea    0x1069fa(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1ebb6e:	mov    %r15,%rdi
  1ebb71:	vzeroupper
  1ebb74:	call   *0x1117c6(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebb7a:	lea    0x106627(%rip),%rdx        # 2f21a8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xde8>
  1ebb81:	mov    %rcx,%rdi
  1ebb84:	mov    %rcx,%rsi
  1ebb87:	vzeroupper
  1ebb8a:	call   *0x1117b0(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebb90:	lea    0x106611(%rip),%rdx        # 2f21a8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xde8>
  1ebb97:	mov    %rsi,%rdi
  1ebb9a:	vzeroupper
  1ebb9d:	call   *0x11179d(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebba3:	lea    0x105e1e(%rip),%rdx        # 2f19c8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x608>
  1ebbaa:	mov    0x430(%rsp),%rdi
  1ebbb2:	mov    0xa8(%rsp),%rsi
  1ebbba:	vzeroupper
  1ebbbd:	call   *0x11177d(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebbc3:	lea    0x105e16(%rip),%rdx        # 2f19e0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x620>
  1ebbca:	mov    0x3a0(%rsp),%rdi
  1ebbd2:	mov    0xa0(%rsp),%rsi
  1ebbda:	vzeroupper
  1ebbdd:	call   *0x11175d(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebbe3:	mov    0x560(%rsp),%rax
  1ebbeb:	mov    %rax,0x430(%rsp)
  1ebbf3:	lea    0x106626(%rip),%rdx        # 2f2220 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe60>
  1ebbfa:	mov    %r14,%rdi
  1ebbfd:	mov    0x430(%rsp),%rsi
  1ebc05:	vzeroupper
  1ebc08:	call   *0x111732(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebc0e:	mov    0x540(%rsp),%rax
  1ebc16:	mov    %rax,0x3a0(%rsp)
  1ebc1e:	lea    0x106613(%rip),%rdx        # 2f2238 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe78>
  1ebc25:	mov    %r14,%rdi
  1ebc28:	mov    0x3a0(%rsp),%rsi
  1ebc30:	vzeroupper
  1ebc33:	call   *0x111707(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebc39:	mov    0x4f0(%rsp),%rax
  1ebc41:	mov    %rax,0x4d0(%rsp)
  1ebc49:	lea    0x106600(%rip),%rdx        # 2f2250 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe90>
  1ebc50:	mov    %r14,%rdi
  1ebc53:	mov    0x4d0(%rsp),%rsi
  1ebc5b:	call   *0x1116df(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebc61:	mov    0x5e0(%rsp),%rax
  1ebc69:	mov    %rax,0x3f0(%rsp)
  1ebc71:	lea    0x1065f0(%rip),%rdx        # 2f2268 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xea8>
  1ebc78:	mov    %r14,%rdi
  1ebc7b:	mov    0x3f0(%rsp),%rsi
  1ebc83:	call   *0x1116b7(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebc89:	mov    0x330(%rsp),%rax
  1ebc91:	mov    %rax,0x190(%rsp)
  1ebc99:	lea    0x1065c8(%rip),%rdx        # 2f2268 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xea8>
  1ebca0:	mov    %r13,%rdi
  1ebca3:	mov    0x190(%rsp),%rsi
  1ebcab:	call   *0x11168f(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebcb1:	mov    0x3c0(%rsp),%rax
  1ebcb9:	mov    %rax,0x68(%rsp)
  1ebcbe:	lea    0x10658b(%rip),%rdx        # 2f2250 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe90>
  1ebcc5:	mov    %r13,%rdi
  1ebcc8:	mov    0x68(%rsp),%rsi
  1ebccd:	call   *0x11166d(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebcd3:	mov    0x260(%rsp),%rax
  1ebcdb:	mov    %rax,0x48(%rsp)
  1ebce0:	lea    0x106551(%rip),%rdx        # 2f2238 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe78>
  1ebce7:	mov    %r13,%rdi
  1ebcea:	mov    0x48(%rsp),%rsi
  1ebcef:	vzeroupper
  1ebcf2:	call   *0x111648(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebcf8:	mov    0x60(%rsp),%rax
  1ebcfd:	mov    %rax,0x50(%rsp)
  1ebd02:	lea    0x106517(%rip),%rdx        # 2f2220 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe60>
  1ebd09:	mov    %r13,%rdi
  1ebd0c:	mov    0x50(%rsp),%rsi
  1ebd11:	vzeroupper
  1ebd14:	call   *0x111626(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebd1a:	lea    0x106127(%rip),%rdx        # 2f1e48 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa88>
  1ebd21:	mov    0x310(%rsp),%rdi
  1ebd29:	mov    %rdi,%rsi
  1ebd2c:	vzeroupper
  1ebd2f:	call   *0x11160b(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebd35:	lea    0x1060c4(%rip),%rdx        # 2f1e00 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa40>
  1ebd3c:	mov    0x5e0(%rsp),%rdi
  1ebd44:	mov    %rdi,%rsi
  1ebd47:	vzeroupper
  1ebd4a:	call   *0x1115f0(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebd50:	lea    0x1060c1(%rip),%rdx        # 2f1e18 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa58>
  1ebd57:	mov    %rdi,%rsi
  1ebd5a:	vzeroupper
  1ebd5d:	call   *0x1115dd(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebd63:	lea    0x1060c6(%rip),%rdx        # 2f1e30 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa70>
  1ebd6a:	mov    %r8,%rdi
  1ebd6d:	mov    %r8,%rsi
  1ebd70:	vzeroupper
  1ebd73:	call   *0x1115c7(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebd79:	lea    0x106008(%rip),%rdx        # 2f1d88 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9c8>
  1ebd80:	xor    %edi,%edi
  1ebd82:	xor    %esi,%esi
  1ebd84:	vzeroupper
  1ebd87:	call   *0x1115b3(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebd8d:	lea    0x10600c(%rip),%rdx        # 2f1da0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9e0>
  1ebd94:	xor    %edi,%edi
  1ebd96:	xor    %esi,%esi
  1ebd98:	vzeroupper
  1ebd9b:	call   *0x11159f(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebda1:	lea    0x106010(%rip),%rdx        # 2f1db8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9f8>
  1ebda8:	xor    %edi,%edi
  1ebdaa:	xor    %esi,%esi
  1ebdac:	vzeroupper
  1ebdaf:	call   *0x11158b(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebdb5:	lea    0x106014(%rip),%rdx        # 2f1dd0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa10>
  1ebdbc:	xor    %edi,%edi
  1ebdbe:	xor    %esi,%esi
  1ebdc0:	vzeroupper
  1ebdc3:	call   *0x111577(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebdc9:	lea    0x106018(%rip),%rdx        # 2f1de8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa28>
  1ebdd0:	xor    %edi,%edi
  1ebdd2:	xor    %esi,%esi
  1ebdd4:	vzeroupper
  1ebdd7:	call   *0x111563(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebddd:	lea    0x10679c(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1ebde4:	mov    %r12,%rdi
  1ebde7:	vzeroupper
  1ebdea:	call   *0x111550(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebdf0:	lea    0x106789(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1ebdf7:	mov    %r15,%rdi
  1ebdfa:	vzeroupper
  1ebdfd:	call   *0x11153d(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebe03:	lea    0x106506(%rip),%rdx        # 2f2310 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf50>
  1ebe0a:	mov    %r13,%rdi
  1ebe0d:	mov    0xb0(%rsp),%rsi
  1ebe15:	vzeroupper
  1ebe18:	call   *0x111522(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebe1e:	lea    0x10645b(%rip),%rdx        # 2f2280 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xec0>
  1ebe25:	mov    %r13,%rdi
  1ebe28:	mov    0xc0(%rsp),%rsi
  1ebe30:	vzeroupper
  1ebe33:	call   *0x111507(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebe39:	lea    0x106458(%rip),%rdx        # 2f2298 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xed8>
  1ebe40:	mov    %r13,%rdi
  1ebe43:	mov    0xd8(%rsp),%rsi
  1ebe4b:	vzeroupper
  1ebe4e:	call   *0x1114ec(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebe54:	lea    0x106485(%rip),%rdx        # 2f22e0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf20>
  1ebe5b:	mov    %r13,%rdi
  1ebe5e:	mov    0xc8(%rsp),%rsi
  1ebe66:	vzeroupper
  1ebe69:	call   *0x1114d1(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebe6f:	lea    0x106482(%rip),%rdx        # 2f22f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf38>
  1ebe76:	mov    %r13,%rdi
  1ebe79:	mov    0xf8(%rsp),%rsi
  1ebe81:	vzeroupper
  1ebe84:	call   *0x1114b6(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebe8a:	lea    0x10641f(%rip),%rdx        # 2f22b0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xef0>
  1ebe91:	mov    %r13,%rdi
  1ebe94:	vzeroupper
  1ebe97:	call   *0x1114a3(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebe9d:	lea    0x106424(%rip),%rdx        # 2f22c8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf08>
  1ebea4:	mov    %r13,%rdi
  1ebea7:	mov    0x100(%rsp),%rsi
  1ebeaf:	vzeroupper
  1ebeb2:	call   *0x111488(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebeb8:	lea    0x106469(%rip),%rdx        # 2f2328 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf68>
  1ebebf:	mov    %r13,%rdi
  1ebec2:	mov    0x88(%rsp),%rsi
  1ebeca:	vzeroupper
  1ebecd:	call   *0x11146d(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebed3:	lea    0x106466(%rip),%rdx        # 2f2340 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf80>
  1ebeda:	mov    %r13,%rdi
  1ebedd:	mov    0x60(%rsp),%rsi
  1ebee2:	vzeroupper
  1ebee5:	call   *0x111455(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebeeb:	mov    0x5e0(%rsp),%rax
  1ebef3:	mov    %rax,0x3f0(%rsp)
  1ebefb:	lea    0x106306(%rip),%rdx        # 2f2208 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe48>
  1ebf02:	mov    0x3f0(%rsp),%rsi
  1ebf0a:	vzeroupper
  1ebf0d:	call   *0x11142d(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebf13:	mov    0x560(%rsp),%rax
  1ebf1b:	mov    %rax,0x430(%rsp)
  1ebf23:	lea    0x106296(%rip),%rdx        # 2f21c0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe00>
  1ebf2a:	mov    0x430(%rsp),%rsi
  1ebf32:	vzeroupper
  1ebf35:	call   *0x111405(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebf3b:	mov    0x540(%rsp),%rax
  1ebf43:	mov    %rax,0x3a0(%rsp)
  1ebf4b:	lea    0x106286(%rip),%rdx        # 2f21d8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe18>
  1ebf52:	mov    0x3a0(%rsp),%rsi
  1ebf5a:	vzeroupper
  1ebf5d:	call   *0x1113dd(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebf63:	mov    0x4f0(%rsp),%rax
  1ebf6b:	mov    %rax,0x4d0(%rsp)
  1ebf73:	lea    0x106276(%rip),%rdx        # 2f21f0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe30>
  1ebf7a:	mov    0x4d0(%rsp),%rsi
  1ebf82:	vzeroupper
  1ebf85:	call   *0x1113b5(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebf8b:	lea    0x10634e(%rip),%rdx        # 2f22e0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf20>
  1ebf92:	mov    %r15,%rdi
  1ebf95:	mov    0xc8(%rsp),%rsi
  1ebf9d:	vzeroupper
  1ebfa0:	call   *0x11139a(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebfa6:	lea    0x1062d3(%rip),%rdx        # 2f2280 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xec0>
  1ebfad:	mov    %r15,%rdi
  1ebfb0:	mov    0xc0(%rsp),%rsi
  1ebfb8:	vzeroupper
  1ebfbb:	call   *0x11137f(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebfc1:	lea    0x106330(%rip),%rdx        # 2f22f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf38>
  1ebfc8:	mov    %r15,%rdi
  1ebfcb:	mov    0xf8(%rsp),%rsi
  1ebfd3:	vzeroupper
  1ebfd6:	call   *0x111364(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebfdc:	lea    0x1062b5(%rip),%rdx        # 2f2298 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xed8>
  1ebfe3:	mov    %r15,%rdi
  1ebfe6:	mov    0xd8(%rsp),%rsi
  1ebfee:	vzeroupper
  1ebff1:	call   *0x111349(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ebff7:	lea    0x106312(%rip),%rdx        # 2f2310 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf50>
  1ebffe:	mov    %r15,%rdi
  1ec001:	mov    0xb0(%rsp),%rsi
  1ec009:	vzeroupper
  1ec00c:	call   *0x11132e(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec012:	lea    0x106297(%rip),%rdx        # 2f22b0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xef0>
  1ec019:	mov    %r15,%rdi
  1ec01c:	mov    0xf0(%rsp),%rsi
  1ec024:	vzeroupper
  1ec027:	call   *0x111313(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec02d:	lea    0x1062f4(%rip),%rdx        # 2f2328 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf68>
  1ec034:	mov    %r15,%rdi
  1ec037:	mov    0x88(%rsp),%rsi
  1ec03f:	vzeroupper
  1ec042:	call   *0x1112f8(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec048:	lea    0x106279(%rip),%rdx        # 2f22c8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf08>
  1ec04f:	mov    %r15,%rdi
  1ec052:	mov    0x100(%rsp),%rsi
  1ec05a:	vzeroupper
  1ec05d:	call   *0x1112dd(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec063:	lea    0x1062d6(%rip),%rdx        # 2f2340 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf80>
  1ec06a:	mov    %r15,%rdi
  1ec06d:	mov    0x60(%rsp),%rsi
  1ec072:	vzeroupper
  1ec075:	call   *0x1112c5(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec07b:	mov    0x3c0(%rsp),%rax
  1ec083:	mov    %rax,0x68(%rsp)
  1ec088:	lea    0x106161(%rip),%rdx        # 2f21f0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe30>
  1ec08f:	mov    0x68(%rsp),%rsi
  1ec094:	vzeroupper
  1ec097:	call   *0x1112a3(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec09d:	mov    0x60(%rsp),%rax
  1ec0a2:	mov    %rax,0x50(%rsp)
  1ec0a7:	lea    0x106112(%rip),%rdx        # 2f21c0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe00>
  1ec0ae:	mov    0x50(%rsp),%rsi
  1ec0b3:	vzeroupper
  1ec0b6:	call   *0x111284(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec0bc:	mov    0x330(%rsp),%rax
  1ec0c4:	mov    %rax,0x190(%rsp)
  1ec0cc:	lea    0x106135(%rip),%rdx        # 2f2208 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe48>
  1ec0d3:	mov    0x190(%rsp),%rsi
  1ec0db:	vzeroupper
  1ec0de:	call   *0x11125c(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec0e4:	mov    0x260(%rsp),%rax
  1ec0ec:	mov    %rax,0x48(%rsp)
  1ec0f1:	lea    0x1060e0(%rip),%rdx        # 2f21d8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe18>
  1ec0f8:	mov    0x48(%rsp),%rsi
  1ec0fd:	vzeroupper
  1ec100:	call   *0x11123a(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec106:	lea    0x10582b(%rip),%rdx        # 2f1938 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x578>
  1ec10d:	mov    0x108(%rsp),%rdi
  1ec115:	mov    %rdi,%rsi
  1ec118:	vzeroupper
  1ec11b:	call   *0x11121f(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec121:	lea    0x105828(%rip),%rdx        # 2f1950 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x590>
  1ec128:	mov    0x2c0(%rsp),%rdi
  1ec130:	mov    %rdi,%rsi
  1ec133:	vzeroupper
  1ec136:	call   *0x111204(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec13c:	lea    0x10586d(%rip),%rdx        # 2f19b0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x5f0>
  1ec143:	mov    %r11,%rdi
  1ec146:	mov    %r11,%rsi
  1ec149:	vzeroupper
  1ec14c:	call   *0x1111ee(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec152:	lea    0x10583f(%rip),%rdx        # 2f1998 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x5d8>
  1ec159:	mov    %rdi,%rsi
  1ec15c:	vzeroupper
  1ec15f:	call   *0x1111db(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec165:	lea    0x105814(%rip),%rdx        # 2f1980 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x5c0>
  1ec16c:	mov    %r8,%rdi
  1ec16f:	mov    %r8,%rsi
  1ec172:	vzeroupper
  1ec175:	call   *0x1111c5(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec17b:	lea    0x1063e6(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1ec182:	mov    0x38(%rsp),%rsi
  1ec187:	vzeroupper
  1ec18a:	call   *0x1111b0(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec190:	mov    %r8,%rdi
  1ec193:	lea    0x10585e(%rip),%rdx        # 2f19f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x638>
  1ec19a:	mov    0xa8(%rsp),%rsi
  1ec1a2:	vzeroupper
  1ec1a5:	call   *0x111195(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec1ab:	mov    %r8,%rdi
  1ec1ae:	lea    0x10585b(%rip),%rdx        # 2f1a10 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x650>
  1ec1b5:	mov    0xa0(%rsp),%rsi
  1ec1bd:	vzeroupper
  1ec1c0:	call   *0x11117a(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec1c6:	lea    0x10639b(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1ec1cd:	mov    0x30(%rsp),%rsi
  1ec1d2:	vzeroupper
  1ec1d5:	call   *0x111165(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec1db:	lea    0x106386(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1ec1e2:	mov    %r9,%rdi
  1ec1e5:	mov    0x38(%rsp),%rsi
  1ec1ea:	vzeroupper
  1ec1ed:	call   *0x11114d(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec1f3:	lea    0x10636e(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1ec1fa:	mov    %r9,%rdi
  1ec1fd:	mov    0x30(%rsp),%rsi
  1ec202:	vzeroupper
  1ec205:	call   *0x111135(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec20b:	lea    0x105c36(%rip),%rdx        # 2f1e48 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa88>
  1ec212:	mov    %rdi,%rsi
  1ec215:	vzeroupper
  1ec218:	call   *0x111122(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec21e:	lea    0x10617b(%rip),%rdx        # 2f23a0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xfe0>
  1ec225:	mov    0xc0(%rsp),%rdi
  1ec22d:	mov    %rdi,%rsi
  1ec230:	vzeroupper
  1ec233:	call   *0x111107(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec239:	lea    0x106190(%rip),%rdx        # 2f23d0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1010>
  1ec240:	mov    0xc8(%rsp),%rdi
  1ec248:	mov    %rdi,%rsi
  1ec24b:	vzeroupper
  1ec24e:	call   *0x1110ec(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec254:	lea    0x10618d(%rip),%rdx        # 2f23e8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1028>
  1ec25b:	mov    0xb0(%rsp),%rdi
  1ec263:	mov    %rdi,%rsi
  1ec266:	vzeroupper
  1ec269:	call   *0x1110d1(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec26f:	lea    0x10618a(%rip),%rdx        # 2f2400 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1040>
  1ec276:	mov    0xd8(%rsp),%rdi
  1ec27e:	mov    %rdi,%rsi
  1ec281:	vzeroupper
  1ec284:	call   *0x1110b6(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec28a:	lea    0x106187(%rip),%rdx        # 2f2418 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1058>
  1ec291:	mov    0x100(%rsp),%rdi
  1ec299:	mov    %rdi,%rsi
  1ec29c:	vzeroupper
  1ec29f:	call   *0x11109b(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec2a5:	lea    0x106184(%rip),%rdx        # 2f2430 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1070>
  1ec2ac:	mov    0xf8(%rsp),%rdi
  1ec2b4:	mov    %rdi,%rsi
  1ec2b7:	vzeroupper
  1ec2ba:	call   *0x111080(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec2c0:	lea    0x106181(%rip),%rdx        # 2f2448 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1088>
  1ec2c7:	mov    0x88(%rsp),%rdi
  1ec2cf:	mov    %rdi,%rsi
  1ec2d2:	vzeroupper
  1ec2d5:	call   *0x111065(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec2db:	lea    0x10557e(%rip),%rdx        # 2f1860 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x4a0>
  1ec2e2:	mov    %rdi,%rsi
  1ec2e5:	vzeroupper
  1ec2e8:	call   *0x111052(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec2ee:	lea    0x105553(%rip),%rdx        # 2f1848 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x488>
  1ec2f5:	mov    %rdi,%rsi
  1ec2f8:	vzeroupper
  1ec2fb:	call   *0x11103f(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec301:	lea    0x106260(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1ec308:	vzeroupper
  1ec30b:	call   *0x11102f(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec311:	lea    0x105980(%rip),%rdx        # 2f1c98 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x8d8>
  1ec318:	mov    0x2c0(%rsp),%rdi
  1ec320:	mov    %rdi,%rsi
  1ec323:	vzeroupper
  1ec326:	call   *0x111014(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec32c:	lea    0x1059c5(%rip),%rdx        # 2f1cf8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x938>
  1ec333:	mov    0x140(%rsp),%rdi
  1ec33b:	mov    %rdi,%rsi
  1ec33e:	vzeroupper
  1ec341:	call   *0x110ff9(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec347:	lea    0x105992(%rip),%rdx        # 2f1ce0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x920>
  1ec34e:	mov    0xb0(%rsp),%rdi
  1ec356:	mov    %rdi,%rsi
  1ec359:	vzeroupper
  1ec35c:	call   *0x110fde(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec362:	lea    0x10595f(%rip),%rdx        # 2f1cc8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x908>
  1ec369:	mov    0x690(%rsp),%rdi
  1ec371:	mov    %rdi,%rsi
  1ec374:	vzeroupper
  1ec377:	call   *0x110fc3(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec37d:	lea    0x10592c(%rip),%rdx        # 2f1cb0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x8f0>
  1ec384:	mov    0x600(%rsp),%rdi
  1ec38c:	mov    %rdi,%rsi
  1ec38f:	vzeroupper
  1ec392:	call   *0x110fa8(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec398:	lea    0x105539(%rip),%rdx        # 2f18d8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x518>
  1ec39f:	vzeroupper
  1ec3a2:	call   *0x110f98(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec3a8:	lea    0x105541(%rip),%rdx        # 2f18f0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x530>
  1ec3af:	mov    %r8,%rsi
  1ec3b2:	vzeroupper
  1ec3b5:	call   *0x110f85(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec3bb:	xor    %edi,%edi
  1ec3bd:	lea    0x105634(%rip),%rdx        # 2f19f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x638>
  1ec3c4:	mov    0xa8(%rsp),%rsi
  1ec3cc:	call   *0x110f6e(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec3d2:	xor    %edi,%edi
  1ec3d4:	lea    0x105635(%rip),%rdx        # 2f1a10 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x650>
  1ec3db:	mov    0xa0(%rsp),%rsi
  1ec3e3:	call   *0x110f57(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec3e9:	mov    $0x1,%r9d
  1ec3ef:	lea    0x105632(%rip),%rdx        # 2f1a28 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x668>
  1ec3f6:	mov    %r9,%rdi
  1ec3f9:	mov    0xa8(%rsp),%rsi
  1ec401:	vzeroupper
  1ec404:	call   *0x110f36(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec40a:	mov    $0x1,%r9d
  1ec410:	lea    0x105629(%rip),%rdx        # 2f1a40 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x680>
  1ec417:	mov    %r9,%rdi
  1ec41a:	mov    0xa0(%rsp),%rsi
  1ec422:	vzeroupper
  1ec425:	call   *0x110f15(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec42b:	lea    0x10614e(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1ec432:	mov    %r10,%rdi
  1ec435:	mov    0x30(%rsp),%rsi
  1ec43a:	vzeroupper
  1ec43d:	call   *0x110efd(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec443:	lea    0x106136(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1ec44a:	mov    %r11,%rdi
  1ec44d:	mov    0x30(%rsp),%rsi
  1ec452:	vzeroupper
  1ec455:	call   *0x110ee5(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec45b:	lea    0x10611e(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1ec462:	mov    %r9,%rdi
  1ec465:	mov    0x38(%rsp),%rsi
  1ec46a:	vzeroupper
  1ec46d:	call   *0x110ecd(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec473:	lea    0x105f3e(%rip),%rdx        # 2f23b8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xff8>
  1ec47a:	mov    0xf0(%rsp),%rdi
  1ec482:	mov    %rdi,%rsi
  1ec485:	vzeroupper
  1ec488:	call   *0x110eb2(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec48e:	lea    0x105ef3(%rip),%rdx        # 2f2388 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xfc8>
  1ec495:	mov    %rsi,%rdi
  1ec498:	vzeroupper
  1ec49b:	call   *0x110e9f(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec4a1:	lea    0x105ec8(%rip),%rdx        # 2f2370 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xfb0>
  1ec4a8:	mov    %rdi,%rsi
  1ec4ab:	vzeroupper
  1ec4ae:	call   *0x110e8c(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec4b4:	lea    0x105945(%rip),%rdx        # 2f1e00 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa40>
  1ec4bb:	mov    %rax,%rdi
  1ec4be:	mov    %rax,%rsi
  1ec4c1:	vzeroupper
  1ec4c4:	call   *0x110e76(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec4ca:	lea    0x105947(%rip),%rdx        # 2f1e18 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa58>
  1ec4d1:	mov    %r12,%rdi
  1ec4d4:	mov    %r12,%rsi
  1ec4d7:	vzeroupper
  1ec4da:	call   *0x110e60(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec4e0:	lea    0x105949(%rip),%rdx        # 2f1e30 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa70>
  1ec4e7:	mov    %rbp,%rdi
  1ec4ea:	mov    %rbp,%rsi
  1ec4ed:	vzeroupper
  1ec4f0:	call   *0x110e4a(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec4f6:	lea    0x105903(%rip),%rdx        # 2f1e00 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa40>
  1ec4fd:	mov    %r8,%rdi
  1ec500:	mov    %r8,%rsi
  1ec503:	vzeroupper
  1ec506:	call   *0x110e34(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec50c:	lea    0x105905(%rip),%rdx        # 2f1e18 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa58>
  1ec513:	mov    %rax,%rdi
  1ec516:	mov    %rax,%rsi
  1ec519:	vzeroupper
  1ec51c:	call   *0x110e1e(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec522:	lea    0x105907(%rip),%rdx        # 2f1e30 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa70>
  1ec529:	mov    %r9,%rdi
  1ec52c:	mov    %r9,%rsi
  1ec52f:	vzeroupper
  1ec532:	call   *0x110e08(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec538:	lea    0x105e31(%rip),%rdx        # 2f2370 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xfb0>
  1ec53f:	mov    %rsi,%rdi
  1ec542:	vzeroupper
  1ec545:	call   *0x110df5(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec54b:	lea    0x105e36(%rip),%rdx        # 2f2388 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xfc8>
  1ec552:	mov    0x60(%rsp),%rdi
  1ec557:	mov    %rdi,%rsi
  1ec55a:	vzeroupper
  1ec55d:	call   *0x110ddd(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec563:	lea    0x105e4e(%rip),%rdx        # 2f23b8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xff8>
  1ec56a:	mov    %rdi,%rsi
  1ec56d:	vzeroupper
  1ec570:	call   *0x110dca(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec576:	mov    %rcx,%rsi
  1ec579:	lea    0x106000(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1ec580:	mov    %r8,%rdi
  1ec583:	vzeroupper
  1ec586:	call   *0x110db4(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec58c:	lea    0x105375(%rip),%rdx        # 2f1908 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x548>
  1ec593:	vzeroupper
  1ec596:	call   *0x110da4(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec59c:	lea    0x10537d(%rip),%rdx        # 2f1920 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x560>
  1ec5a3:	mov    %r8,%rsi
  1ec5a6:	vzeroupper
  1ec5a9:	call   *0x110d91(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec5af:	lea    0x1052c2(%rip),%rdx        # 2f1878 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x4b8>
  1ec5b6:	mov    0x30(%rsp),%rsi
  1ec5bb:	vzeroupper
  1ec5be:	call   *0x110d7c(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec5c4:	lea    0x1052c5(%rip),%rdx        # 2f1890 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x4d0>
  1ec5cb:	vzeroupper
  1ec5ce:	call   *0x110d6c(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec5d4:	lea    0x1052cd(%rip),%rdx        # 2f18a8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x4e8>
  1ec5db:	mov    0x30(%rsp),%rsi
  1ec5e0:	vzeroupper
  1ec5e3:	call   *0x110d57(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec5e9:	lea    0x1052d0(%rip),%rdx        # 2f18c0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x500>
  1ec5f0:	vzeroupper
  1ec5f3:	call   *0x110d47(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec5f9:	lea    0x1053c8(%rip),%rdx        # 2f19c8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x608>
  1ec600:	mov    0x1e0(%rsp),%rdi
  1ec608:	mov    0xa8(%rsp),%rsi
  1ec610:	vzeroupper
  1ec613:	call   *0x110d27(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec619:	lea    0x1053c0(%rip),%rdx        # 2f19e0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x620>
  1ec620:	mov    0x190(%rsp),%rdi
  1ec628:	mov    0xa0(%rsp),%rsi
  1ec630:	vzeroupper
  1ec633:	call   *0x110d07(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec639:	lea    0x105f28(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1ec640:	mov    %rcx,%rdi
  1ec643:	mov    0x38(%rsp),%rsi
  1ec648:	vzeroupper
  1ec64b:	call   *0x110cef(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec651:	lea    0x105f10(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1ec658:	mov    %rcx,%rdi
  1ec65b:	vzeroupper
  1ec65e:	call   *0x110cdc(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec664:	lea    0x105795(%rip),%rdx        # 2f1e00 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa40>
  1ec66b:	mov    0x2c0(%rsp),%rdi
  1ec673:	mov    %rdi,%rsi
  1ec676:	vzeroupper
  1ec679:	call   *0x110cc1(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec67f:	lea    0x105efa(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1ec686:	mov    %rcx,%rdi
  1ec689:	vzeroupper
  1ec68c:	call   *0x110cae(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec692:	lea    0x105ee7(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1ec699:	mov    %rsi,%rdi
  1ec69c:	mov    0x38(%rsp),%rsi
  1ec6a1:	vzeroupper
  1ec6a4:	call   *0x110c96(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec6aa:	lea    0x10535f(%rip),%rdx        # 2f1a10 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x650>
  1ec6b1:	mov    0xd0(%rsp),%rdi
  1ec6b9:	mov    0xa0(%rsp),%rsi
  1ec6c1:	vzeroupper
  1ec6c4:	call   *0x110c76(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec6ca:	lea    0x105327(%rip),%rdx        # 2f19f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x638>
  1ec6d1:	mov    0xd0(%rsp),%rdi
  1ec6d9:	mov    0xa8(%rsp),%rsi
  1ec6e1:	vzeroupper
  1ec6e4:	call   *0x110c56(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec6ea:	lea    0x105337(%rip),%rdx        # 2f1a28 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x668>
  1ec6f1:	mov    0xa8(%rsp),%rsi
  1ec6f9:	vzeroupper
  1ec6fc:	call   *0x110c3e(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec702:	lea    0x105e5f(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1ec709:	mov    %rax,%rdi
  1ec70c:	mov    0x30(%rsp),%rsi
  1ec711:	vzeroupper
  1ec714:	call   *0x110c26(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec71a:	lea    0x105e47(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1ec721:	mov    %rax,%rdi
  1ec724:	mov    0x38(%rsp),%rsi
  1ec729:	vzeroupper
  1ec72c:	call   *0x110c0e(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec732:	lea    0x10555f(%rip),%rdx        # 2f1c98 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x8d8>
  1ec739:	mov    0x108(%rsp),%rdi
  1ec741:	mov    %rdi,%rsi
  1ec744:	vzeroupper
  1ec747:	call   *0x110bf3(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec74d:	lea    0x105e2c(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1ec754:	mov    %rax,%rdi
  1ec757:	mov    0x30(%rsp),%rsi
  1ec75c:	vzeroupper
  1ec75f:	call   *0x110bdb(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec765:	lea    0x105e14(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1ec76c:	mov    %rcx,%rdi
  1ec76f:	mov    0x30(%rsp),%rsi
  1ec774:	vzeroupper
  1ec777:	call   *0x110bc3(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec77d:	lea    0x105dfc(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1ec784:	mov    %r8,%rdi
  1ec787:	mov    0x38(%rsp),%rsi
  1ec78c:	vzeroupper
  1ec78f:	call   *0x110bab(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1ec795:	lea    0x105de4(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1ec79c:	mov    %r8,%rdi
  1ec79f:	mov    0x30(%rsp),%rsi
  1ec7a4:	vzeroupper
  1ec7a7:	call   *0x110b93(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
