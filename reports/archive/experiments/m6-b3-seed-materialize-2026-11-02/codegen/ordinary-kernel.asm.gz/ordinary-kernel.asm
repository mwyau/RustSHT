
/tmp/rsh-b3-dynamic-leaf-profile-ceae53e2/target-b3-seed/release/examples/ducc_spin1_full_transform_parity:     file format elf64-x86-64


Disassembly of section .text:

00000000001dd3c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>>:
  1dd3c0:	push   %rbp
  1dd3c1:	push   %r15
  1dd3c3:	push   %r14
  1dd3c5:	push   %r13
  1dd3c7:	push   %r12
  1dd3c9:	push   %rbx
  1dd3ca:	sub    $0x238,%rsp
  1dd3d1:	mov    0xa0(%rdi),%rax
  1dd3d8:	cmp    0xb0(%rdi),%rax
  1dd3df:	jne    1dfc4e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1dd3e5:	mov    0x10(%rdi),%r12
  1dd3e9:	mov    0x20(%rdi),%rbp
  1dd3ed:	mov    0x50(%rdi),%r13
  1dd3f1:	mov    0x60(%rdi),%r10
  1dd3f5:	mov    0x70(%rdi),%r11
  1dd3f9:	mov    0x80(%rdi),%r15
  1dd400:	mov    0xe0(%rdi),%rcx
  1dd407:	mov    0xe8(%rdi),%rbx
  1dd40e:	mov    0xc0(%rdi),%rdx
  1dd415:	xor    %rax,%rdx
  1dd418:	mov    %r12,%rsi
  1dd41b:	xor    %rax,%rsi
  1dd41e:	or     %rdx,%rsi
  1dd421:	mov    %rbp,%rdx
  1dd424:	xor    %rax,%rdx
  1dd427:	mov    %r13,%r8
  1dd42a:	xor    %rax,%r8
  1dd42d:	or     %rdx,%r8
  1dd430:	or     %rsi,%r8
  1dd433:	mov    %r10,%rdx
  1dd436:	xor    %rax,%rdx
  1dd439:	mov    %r11,%rsi
  1dd43c:	xor    %rax,%rsi
  1dd43f:	or     %rdx,%rsi
  1dd442:	mov    %r15,%rdx
  1dd445:	xor    %rax,%rdx
  1dd448:	or     %rsi,%rdx
  1dd44b:	or     %r8,%rdx
  1dd44e:	test   %rcx,%rcx
  1dd451:	setne  %sil
  1dd455:	xor    %rbx,%rax
  1dd458:	or     %rdx,%rax
  1dd45b:	sete   %al
  1dd45e:	test   %sil,%al
  1dd461:	je     1dfc4e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1dd467:	cmp    %rbx,0xf8(%rdi)
  1dd46e:	jne    1dfc4e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1dd474:	cmp    %rbx,0x108(%rdi)
  1dd47b:	jne    1dfc4e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1dd481:	cmp    %rbx,0x118(%rdi)
  1dd488:	jne    1dfc4e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1dd48e:	mov    0xc8(%rdi),%rdx
  1dd495:	mov    0xd0(%rdi),%rsi
  1dd49c:	mov    %rdi,%r9
  1dd49f:	mov    0x128(%rdi),%rdi
  1dd4a6:	mov    %rsi,%r14
  1dd4a9:	mov    %rdx,0x130(%rsp)
  1dd4b1:	sub    %rdx,%r14
  1dd4b4:	lea    0x1(%r14),%rax
  1dd4b8:	mov    %rdi,0x18(%rsp)
  1dd4bd:	cmp    %rax,%rdi
  1dd4c0:	jb     1dfc4e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1dd4c6:	mov    %rsi,0x68(%rsp)
  1dd4cb:	mov    %rbp,0x118(%rsp)
  1dd4d3:	mov    %r12,0x98(%rsp)
  1dd4db:	mov    %r15,0x70(%rsp)
  1dd4e0:	mov    %r11,0x78(%rsp)
  1dd4e5:	mov    %r10,0x50(%rsp)
  1dd4ea:	mov    0xd8(%r9),%rdi
  1dd4f1:	mov    0x18(%r9),%rax
  1dd4f5:	mov    %rax,0xd0(%rsp)
  1dd4fd:	mov    0x28(%r9),%rax
  1dd501:	mov    %rax,0x1e8(%rsp)
  1dd509:	mov    0x30(%r9),%rax
  1dd50d:	mov    %rax,0xd8(%rsp)
  1dd515:	mov    0x38(%r9),%rax
  1dd519:	mov    %rax,0x1e0(%rsp)
  1dd521:	mov    0x40(%r9),%rax
  1dd525:	mov    %rax,0x58(%rsp)
  1dd52a:	mov    0x48(%r9),%r10
  1dd52e:	mov    0x58(%r9),%rax
  1dd532:	mov    %rax,0x30(%rsp)
  1dd537:	mov    0x68(%r9),%r15
  1dd53b:	add    $0x2,%r14
  1dd53f:	mov    %r14,%r8
  1dd542:	shr    $1,%r8
  1dd545:	xor    %eax,%eax
  1dd547:	mov    %r8,%rdx
  1dd54a:	sub    $0x1,%rdx
  1dd54e:	cmovb  %rax,%rdx
  1dd552:	mov    %rdx,0x1d8(%rsp)
  1dd55a:	mov    0x78(%r9),%rdx
  1dd55e:	mov    %rdx,0x20(%rsp)
  1dd563:	sub    $0x2,%r8
  1dd567:	cmovb  %rax,%r8
  1dd56b:	mov    0x88(%r9),%rax
  1dd572:	mov    %rax,0xc8(%rsp)
  1dd57a:	mov    0x90(%r9),%rax
  1dd581:	mov    %rax,0x8(%rsp)
  1dd586:	mov    0xf0(%r9),%rdx
  1dd58d:	mov    0x100(%r9),%rbp
  1dd594:	mov    0x110(%r9),%r12
  1dd59b:	mov    0x120(%r9),%rax
  1dd5a2:	mov    %rax,0x100(%rsp)
  1dd5aa:	mov    0x98(%r9),%rax
  1dd5b1:	mov    0xa8(%r9),%r11
  1dd5b8:	mov    0xb8(%r9),%r9
  1dd5bf:	mov    %r9,0x90(%rsp)
  1dd5c7:	mov    %r8,0xb8(%rsp)
  1dd5cf:	cmp    %r8,%rdi
  1dd5d2:	mov    %r12,0xc0(%rsp)
  1dd5da:	mov    %r10,0x38(%rsp)
  1dd5df:	mov    %r15,0x60(%rsp)
  1dd5e4:	mov    %r14,0x200(%rsp)
  1dd5ec:	mov    %rbx,0x108(%rsp)
  1dd5f4:	jae    1dd673 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b3>
  1dd5f6:	mov    %r13,%r8
  1dd5f9:	shr    $0x2,%r8
  1dd5fd:	mov    0x50(%rsp),%r9
  1dd602:	shr    $0x2,%r9
  1dd606:	mov    %rbx,%r12
  1dd609:	mov    0x78(%rsp),%rbx
  1dd60e:	shr    $0x2,%rbx
  1dd612:	mov    0x70(%rsp),%r15
  1dd617:	shr    $0x2,%r15
  1dd61b:	shr    $0x2,%r12
  1dd61f:	mov    %r8,%rsi
  1dd622:	xor    %r9,%rsi
  1dd625:	xor    %r9,%rbx
  1dd628:	or     %rsi,%rbx
  1dd62b:	xor    %r9,%r15
  1dd62e:	cmp    %r12,%r8
  1dd631:	cmovb  %r8,%r12
  1dd635:	mov    %r12,0xb0(%rsp)
  1dd63d:	or     %rbx,%r15
  1dd640:	je     1de3f3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1033>
  1dd646:	mov    0xd8(%rsp),%rax
  1dd64e:	cmp    %rax,%rdi
  1dd651:	jae    1dfd8b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29cb>
  1dd657:	cmp    0x58(%rsp),%rdi
  1dd65c:	jae    1dfda6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29e6>
  1dd662:	inc    %rdi
  1dd665:	cmp    %rax,%rdi
  1dd668:	jb     1dfc43 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2883>
  1dd66e:	jmp    1dfd70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29b0>
  1dd673:	mov    %r13,0x128(%rsp)
  1dd67b:	movb   $0x1,0x7(%rsp)
  1dd680:	mov    0x98(%rsp),%rsi
  1dd688:	mov    %rsi,0x10(%rsp)
  1dd68d:	mov    %rbx,0x28(%rsp)
  1dd692:	mov    %rbx,0x48(%rsp)
  1dd697:	mov    %rax,%r13
  1dd69a:	mov    %rdi,%r8
  1dd69d:	mov    0x90(%rsp),%r10
  1dd6a5:	vxorpd %xmm0,%xmm0,%xmm0
  1dd6a9:	vcmpeqpd %ymm0,%ymm0,%ymm0
  1dd6ae:	movabs $0x3fffffffffffffe,%rdi
  1dd6b8:	cmp    0x1d8(%rsp),%r8
  1dd6c0:	jae    1de23c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xe7c>
  1dd6c6:	mov    %rbx,%r15
  1dd6c9:	shr    $0x2,%r15
  1dd6cd:	mov    %ebx,%eax
  1dd6cf:	and    $0x3,%eax
  1dd6d2:	mov    %rax,0x1c8(%rsp)
  1dd6da:	mov    %rbx,%rsi
  1dd6dd:	movabs $0xffffffffffffffc,%r14
  1dd6e7:	and    %r14,%rsi
  1dd6ea:	mov    %rsi,0xf8(%rsp)
  1dd6f2:	mov    0x98(%rsp),%rsi
  1dd6fa:	mov    %rsi,%r9
  1dd6fd:	shr    $0x2,%r9
  1dd701:	mov    %r9,0xb0(%rsp)
  1dd709:	and    %rdi,%r15
  1dd70c:	shl    $0x5,%r15
  1dd710:	lea    (%rcx,%r15,1),%rax
  1dd714:	mov    %rax,0x218(%rsp)
  1dd71c:	shr    $0x3,%rbx
  1dd720:	mov    %rbx,0x1f0(%rsp)
  1dd728:	lea    (%rdx,%r15,1),%rax
  1dd72c:	mov    %rax,0x210(%rsp)
  1dd734:	lea    (%r15,%rbp,1),%rax
  1dd738:	mov    %rax,0x208(%rsp)
  1dd740:	add    %r12,%r15
  1dd743:	mov    %r15,0x220(%rsp)
  1dd74b:	mov    %rsi,%rdi
  1dd74e:	shr    $0x3,%rdi
  1dd752:	mov    %rdi,0x88(%rsp)
  1dd75a:	mov    0x128(%rsp),%r15
  1dd762:	mov    %r15,%rax
  1dd765:	shr    $0x2,%rax
  1dd769:	mov    %rax,0x178(%rsp)
  1dd771:	mov    %r15d,%eax
  1dd774:	and    $0x3,%eax
  1dd777:	mov    %rax,0x190(%rsp)
  1dd77f:	and    %r14,%r15
  1dd782:	mov    %r15,0x150(%rsp)
  1dd78a:	mov    0x50(%rsp),%rdi
  1dd78f:	mov    %rdi,%rbx
  1dd792:	shr    $0x2,%rbx
  1dd796:	mov    %edi,%eax
  1dd798:	and    $0x3,%eax
  1dd79b:	mov    %rax,0x188(%rsp)
  1dd7a3:	and    %r14,%rdi
  1dd7a6:	mov    %rdi,0xa8(%rsp)
  1dd7ae:	mov    0x78(%rsp),%rdi
  1dd7b3:	mov    %rdi,%rsi
  1dd7b6:	shr    $0x2,%rsi
  1dd7ba:	mov    %edi,%eax
  1dd7bc:	and    $0x3,%eax
  1dd7bf:	mov    %rax,0x180(%rsp)
  1dd7c7:	and    %r14,%rdi
  1dd7ca:	mov    %rdi,0x80(%rsp)
  1dd7d2:	mov    0x70(%rsp),%rdi
  1dd7d7:	mov    %rdi,%rax
  1dd7da:	shr    $0x2,%rax
  1dd7de:	mov    %edi,%r9d
  1dd7e1:	and    $0x3,%r9d
  1dd7e5:	and    %r14,%rdi
  1dd7e8:	mov    %rdi,0x230(%rsp)
  1dd7f0:	mov    0x118(%rsp),%rdi
  1dd7f8:	mov    %rdi,%r14
  1dd7fb:	movabs $0xffffffffffffffc,%r15
  1dd805:	and    %r15,%r14
  1dd808:	mov    %r14,0x228(%rsp)
  1dd810:	mov    0xd8(%rsp),%r14
  1dd818:	cmp    %r14,%r8
  1dd81b:	cmova  %r8,%r14
  1dd81f:	mov    %r14,0xf0(%rsp)
  1dd827:	mov    0x58(%rsp),%r14
  1dd82c:	cmp    %r14,%r8
  1dd82f:	cmova  %r8,%r14
  1dd833:	mov    %r14,0xe8(%rsp)
  1dd83b:	mov    0x178(%rsp),%r14
  1dd843:	cmp    %r14,%rbx
  1dd846:	mov    %rbx,0x1b8(%rsp)
  1dd84e:	cmovb  %rbx,%r14
  1dd852:	cmp    %r14,%rsi
  1dd855:	mov    %rsi,0x1b0(%rsp)
  1dd85d:	cmovb  %rsi,%r14
  1dd861:	cmp    %r14,%rax
  1dd864:	mov    %rax,0x1a8(%rsp)
  1dd86c:	cmovb  %rax,%r14
  1dd870:	mov    %r14,0x1a0(%rsp)
  1dd878:	mov    %rdi,%rax
  1dd87b:	shr    $0x2,%rax
  1dd87f:	mov    %rax,0x120(%rsp)
  1dd887:	mov    0x190(%rsp),%rax
  1dd88f:	mov    0x188(%rsp),%rsi
  1dd897:	cmp    %rax,%rsi
  1dd89a:	cmovb  %rsi,%rax
  1dd89e:	mov    0x180(%rsp),%rsi
  1dd8a6:	cmp    %rax,%rsi
  1dd8a9:	cmovb  %rsi,%rax
  1dd8ad:	cmp    %rax,%r9
  1dd8b0:	mov    %r9,0x1c0(%rsp)
  1dd8b8:	cmovb  %r9,%rax
  1dd8bc:	mov    %rax,0xe0(%rsp)
  1dd8c4:	mov    0x98(%rsp),%rax
  1dd8cc:	and    $0x3,%eax
  1dd8cf:	mov    %rax,0x198(%rsp)
  1dd8d7:	and    $0x3,%edi
  1dd8da:	mov    %rdi,0x118(%rsp)
  1dd8e2:	vxorpd %xmm2,%xmm2,%xmm2
  1dd8e6:	vbroadcastsd -0x1b7777(%rip),%ymm3        # 26178 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x3a8>
  1dd8ef:	vmovapd %ymm0,%ymm1
  1dd8f3:	mov    0x28(%rsp),%rsi
  1dd8f8:	mov    %rbp,0xa0(%rsp)
  1dd900:	mov    0x48(%rsp),%rax
  1dd905:	mov    0x10(%rsp),%r14
  1dd90a:	mov    %rcx,0x110(%rsp)
  1dd912:	mov    %rdx,0x1d0(%rsp)
  1dd91a:	jmp    1dd942 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x582>
  1dd91c:	vandpd %ymm1,%ymm4,%ymm1
  1dd920:	inc    %r8
  1dd923:	mov    %r11,%r13
  1dd926:	mov    %rsi,%rax
  1dd929:	mov    %rbx,%r11
  1dd92c:	mov    0x48(%rsp),%rdi
  1dd931:	mov    %rdi,%rsi
  1dd934:	cmp    0x1d8(%rsp),%r8
  1dd93c:	jae    1de317 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xf57>
  1dd942:	mov    %r14,0x48(%rsp)
  1dd947:	mov    %r10,%rbx
  1dd94a:	mov    %rax,%r10
  1dd94d:	mov    %rsi,%rdi
  1dd950:	shr    $0x3,%rdi
  1dd954:	mov    0x1f0(%rsp),%rax
  1dd95c:	cmp    %rax,%rdi
  1dd95f:	cmovae %rax,%rdi
  1dd963:	mov    0x88(%rsp),%rax
  1dd96b:	cmp    %rdi,%rax
  1dd96e:	cmovb  %rax,%rdi
  1dd972:	vxorpd %xmm11,%xmm11,%xmm11
  1dd977:	vxorpd %xmm7,%xmm7,%xmm7
  1dd97b:	vxorpd %xmm8,%xmm8,%xmm8
  1dd980:	vxorpd %xmm9,%xmm9,%xmm9
  1dd985:	vxorpd %xmm10,%xmm10,%xmm10
  1dd98a:	vxorpd %xmm5,%xmm5,%xmm5
  1dd98e:	vxorpd %xmm6,%xmm6,%xmm6
  1dd992:	vxorpd %xmm4,%xmm4,%xmm4
  1dd996:	test   %rdi,%rdi
  1dd999:	je     1ddab5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x6f5>
  1dd99f:	cmp    $0x1,%rdi
  1dd9a3:	jne    1dd9ac <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x5ec>
  1dd9a5:	xor    %eax,%eax
  1dd9a7:	jmp    1dda6f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x6af>
  1dd9ac:	mov    %rdi,%r9
  1dd9af:	movabs $0x1ffffffffffffffe,%rax
  1dd9b9:	and    %rax,%r9
  1dd9bc:	mov    $0x60,%r15d
  1dd9c2:	xor    %eax,%eax
  1dd9c4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1dd9d0:	vmovupd -0x60(%r11,%r15,1),%ymm12
  1dd9d7:	vmovupd -0x40(%r11,%r15,1),%ymm13
  1dd9de:	vmovupd -0x20(%r11,%r15,1),%ymm14
  1dd9e5:	vfmadd231pd -0x60(%rcx,%r15,1),%ymm12,%ymm7
  1dd9ec:	vfmadd231pd -0x60(%rdx,%r15,1),%ymm12,%ymm8
  1dd9f3:	vfmadd231pd -0x60(%rbp,%r15,1),%ymm12,%ymm9
  1dd9fa:	vfmadd231pd -0x60(%r12,%r15,1),%ymm12,%ymm10
  1dda01:	vfmadd231pd -0x40(%rcx,%r15,1),%ymm13,%ymm5
  1dda08:	vfmadd231pd -0x40(%rdx,%r15,1),%ymm13,%ymm6
  1dda0f:	vfmadd231pd -0x40(%rbp,%r15,1),%ymm13,%ymm4
  1dda16:	vfmadd231pd -0x40(%r12,%r15,1),%ymm13,%ymm11
  1dda1d:	vmovupd (%r11,%r15,1),%ymm12
  1dda23:	add    $0x2,%rax
  1dda27:	vfmadd231pd -0x20(%rcx,%r15,1),%ymm14,%ymm7
  1dda2e:	vfmadd231pd -0x20(%rdx,%r15,1),%ymm14,%ymm8
  1dda35:	vfmadd231pd -0x20(%rbp,%r15,1),%ymm14,%ymm9
  1dda3c:	vfmadd231pd -0x20(%r12,%r15,1),%ymm14,%ymm10
  1dda43:	vfmadd231pd (%rcx,%r15,1),%ymm12,%ymm5
  1dda49:	vfmadd231pd (%rdx,%r15,1),%ymm12,%ymm6
  1dda4f:	vfmadd231pd 0x0(%rbp,%r15,1),%ymm12,%ymm4
  1dda56:	vfmadd231pd (%r12,%r15,1),%ymm12,%ymm11
  1dda5c:	sub    $0xffffffffffffff80,%r15
  1dda60:	cmp    %rax,%r9
  1dda63:	jne    1dd9d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x610>
  1dda69:	test   $0x1,%dil
  1dda6d:	je     1ddab5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x6f5>
  1dda6f:	shl    $0x6,%rax
  1dda73:	vmovupd (%r11,%rax,1),%ymm12
  1dda79:	vmovupd 0x20(%r11,%rax,1),%ymm13
  1dda80:	vfmadd231pd (%rcx,%rax,1),%ymm12,%ymm7
  1dda86:	vfmadd231pd (%rdx,%rax,1),%ymm12,%ymm8
  1dda8c:	vfmadd231pd 0x0(%rbp,%rax,1),%ymm12,%ymm9
  1dda93:	vfmadd231pd (%r12,%rax,1),%ymm12,%ymm10
  1dda99:	vfmadd231pd 0x20(%rcx,%rax,1),%ymm13,%ymm5
  1ddaa0:	vfmadd231pd 0x20(%rdx,%rax,1),%ymm13,%ymm6
  1ddaa7:	vfmadd231pd 0x20(%rbp,%rax,1),%ymm13,%ymm4
  1ddaae:	vfmadd231pd 0x20(%r12,%rax,1),%ymm13,%ymm11
  1ddab5:	mov    %rsi,%r12
  1ddab8:	shr    $0x2,%r12
  1ddabc:	test   $0x4,%sil
  1ddac0:	je     1ddb2d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x76d>
  1ddac2:	testb  $0x4,0x98(%rsp)
  1ddaca:	je     1dfd05 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2945>
  1ddad0:	testb  $0x4,0x108(%rsp)
  1ddad8:	je     1dfd19 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2959>
  1ddade:	mov    %r12,%rax
  1ddae1:	movabs $0x3fffffffffffffe,%rdi
  1ddaeb:	and    %rdi,%rax
  1ddaee:	shl    $0x5,%rax
  1ddaf2:	add    %r11,%rax
  1ddaf5:	vmovupd (%rax),%ymm12
  1ddaf9:	mov    0x218(%rsp),%rax
  1ddb01:	vfmadd231pd (%rax),%ymm12,%ymm7
  1ddb06:	mov    0x210(%rsp),%rax
  1ddb0e:	vfmadd231pd (%rax),%ymm12,%ymm8
  1ddb13:	mov    0x208(%rsp),%rax
  1ddb1b:	vfmadd231pd (%rax),%ymm12,%ymm9
  1ddb20:	mov    0x220(%rsp),%rax
  1ddb28:	vfmadd231pd (%rax),%ymm12,%ymm10
  1ddb2d:	mov    0xf8(%rsp),%rdi
  1ddb35:	vaddpd %ymm10,%ymm11,%ymm10
  1ddb3a:	vaddpd %ymm4,%ymm9,%ymm4
  1ddb3e:	vaddpd %ymm6,%ymm8,%ymm6
  1ddb42:	vaddpd %ymm7,%ymm5,%ymm5
  1ddb46:	mov    %esi,%r9d
  1ddb49:	and    $0x3,%r9d
  1ddb4d:	mov    %rsi,%r14
  1ddb50:	movabs $0xffffffffffffffc,%rax
  1ddb5a:	and    %rax,%r14
  1ddb5d:	vextractf128 $0x1,%ymm5,%xmm7
  1ddb63:	vaddpd %xmm7,%xmm5,%xmm5
  1ddb67:	vshufpd $0x1,%xmm5,%xmm5,%xmm7
  1ddb6c:	vaddsd %xmm7,%xmm5,%xmm5
  1ddb70:	vextractf128 $0x1,%ymm6,%xmm7
  1ddb76:	vaddpd %xmm7,%xmm6,%xmm6
  1ddb7a:	vshufpd $0x1,%xmm6,%xmm6,%xmm7
  1ddb7f:	vaddsd %xmm7,%xmm6,%xmm7
  1ddb83:	vextractf128 $0x1,%ymm4,%xmm6
  1ddb89:	vaddpd %xmm6,%xmm4,%xmm4
  1ddb8d:	vshufpd $0x1,%xmm4,%xmm4,%xmm6
  1ddb92:	vaddsd %xmm6,%xmm4,%xmm4
  1ddb96:	vextractf128 $0x1,%ymm10,%xmm6
  1ddb9c:	vaddpd %xmm6,%xmm10,%xmm6
  1ddba0:	vshufpd $0x1,%xmm6,%xmm6,%xmm8
  1ddba5:	vaddsd %xmm6,%xmm8,%xmm6
  1ddba9:	test   %r9,%r9
  1ddbac:	je     1ddc3c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x87c>
  1ddbb2:	lea    -0x1(%r9),%eax
  1ddbb6:	cmp    %eax,0x1c8(%rsp)
  1ddbbd:	jbe    1dfcea <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x292a>
  1ddbc3:	vmovsd (%r11,%r14,8),%xmm8
  1ddbc9:	vfmadd231sd (%rcx,%rdi,8),%xmm8,%xmm5
  1ddbcf:	vfmadd231sd (%rdx,%rdi,8),%xmm8,%xmm7
  1ddbd5:	vfmadd231sd 0x0(%rbp,%rdi,8),%xmm8,%xmm4
  1ddbdc:	mov    0xc0(%rsp),%rax
  1ddbe4:	vfmadd231sd (%rax,%rdi,8),%xmm8,%xmm6
  1ddbea:	cmp    $0x1,%r9d
  1ddbee:	je     1ddc3c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x87c>
  1ddbf0:	vmovsd 0x8(%r11,%r14,8),%xmm8
  1ddbf7:	vfmadd231sd 0x8(%rcx,%rdi,8),%xmm8,%xmm5
  1ddbfe:	vfmadd231sd 0x8(%rdx,%rdi,8),%xmm8,%xmm7
  1ddc05:	vfmadd231sd 0x8(%rbp,%rdi,8),%xmm8,%xmm4
  1ddc0c:	vfmadd231sd 0x8(%rax,%rdi,8),%xmm8,%xmm6
  1ddc13:	cmp    $0x2,%r9d
  1ddc17:	je     1ddc3c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x87c>
  1ddc19:	vmovsd 0x10(%r11,%r14,8),%xmm8
  1ddc20:	vfmadd231sd 0x10(%rcx,%rdi,8),%xmm8,%xmm5
  1ddc27:	vfmadd231sd 0x10(%rdx,%rdi,8),%xmm8,%xmm7
  1ddc2e:	vfmadd231sd 0x10(%rbp,%rdi,8),%xmm8,%xmm4
  1ddc35:	vfmadd231sd 0x10(%rax,%rdi,8),%xmm8,%xmm6
  1ddc3c:	mov    %r13,%rbp
  1ddc3f:	mov    %rsi,0x28(%rsp)
  1ddc44:	lea    (%r8,%r8,1),%r13
  1ddc48:	cmp    0x18(%rsp),%r13
  1ddc4d:	mov    0x48(%rsp),%rdi
  1ddc52:	jae    1dfcd2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2912>
  1ddc58:	mov    %r14,%rcx
  1ddc5b:	mov    %r13,%r15
  1ddc5e:	shl    $0x4,%r15
  1ddc62:	mov    0x100(%rsp),%rsi
  1ddc6a:	vmovsd %xmm5,(%rsi,%r15,1)
  1ddc70:	mov    0x130(%rsp),%rax
  1ddc78:	lea    (%rax,%r8,2),%rax
  1ddc7c:	vmovsd %xmm7,0x8(%rsi,%r15,1)
  1ddc83:	mov    %rax,0x138(%rsp)
  1ddc8b:	cmp    0x68(%rsp),%rax
  1ddc90:	jae    1ddcb8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x8f8>
  1ddc92:	lea    0x1(%r13),%rax
  1ddc96:	cmp    0x18(%rsp),%rax
  1ddc9b:	jae    1dfd43 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2983>
  1ddca1:	shl    $0x4,%rax
  1ddca5:	mov    0x100(%rsp),%rsi
  1ddcad:	vmovsd %xmm4,(%rsi,%rax,1)
  1ddcb2:	vmovsd %xmm6,0x8(%rsi,%rax,1)
  1ddcb8:	cmp    0xf0(%rsp),%r8
  1ddcc0:	je     1dfc7f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x28bf>
  1ddcc6:	cmp    0xe8(%rsp),%r8
  1ddcce:	je     1dfc9f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x28df>
  1ddcd4:	shr    $0x2,%rdi
  1ddcd8:	mov    %r10,0x10(%rsp)
  1ddcdd:	mov    %r10,%rax
  1ddce0:	shr    $0x2,%rax
  1ddce4:	mov    0x1a0(%rsp),%rdx
  1ddcec:	cmp    %rdx,%rax
  1ddcef:	cmovae %rdx,%rax
  1ddcf3:	cmp    %rax,%r12
  1ddcf6:	cmovb  %r12,%rax
  1ddcfa:	mov    0x1e8(%rsp),%rsi
  1ddd02:	vbroadcastsd (%rsi,%r8,8),%ymm6
  1ddd08:	mov    0xb0(%rsp),%rdx
  1ddd10:	cmp    %rax,%rdx
  1ddd13:	cmovb  %rdx,%rax
  1ddd17:	mov    0x1e0(%rsp),%rsi
  1ddd1f:	mov    %r8,0x40(%rsp)
  1ddd24:	vbroadcastsd (%rsi,%r8,8),%ymm5
  1ddd2a:	mov    0x120(%rsp),%rdx
  1ddd32:	cmp    %rax,%rdx
  1ddd35:	cmovb  %rdx,%rax
  1ddd39:	cmp    %rax,%rdi
  1ddd3c:	mov    %rdi,0x160(%rsp)
  1ddd44:	cmovb  %rdi,%rax
  1ddd48:	test   %rax,%rax
  1ddd4b:	je     1dddf1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xa31>
  1ddd51:	vxorpd %xmm8,%xmm8,%xmm8
  1ddd56:	xor    %r12d,%r12d
  1ddd59:	vxorpd %xmm9,%xmm9,%xmm9
  1ddd5e:	vxorpd %xmm7,%xmm7,%xmm7
  1ddd62:	vxorpd %xmm10,%xmm10,%xmm10
  1ddd67:	vmovapd %ymm0,%ymm4
  1ddd6b:	mov    0x38(%rsp),%rdi
  1ddd70:	mov    0x30(%rsp),%rsi
  1ddd75:	mov    0x60(%rsp),%r10
  1ddd7a:	mov    0x20(%rsp),%r8
  1ddd7f:	mov    0xd0(%rsp),%r14
  1ddd87:	mov    %rbp,%rdx
  1ddd8a:	nopw   0x0(%rax,%rax,1)
  1ddd90:	vmovupd (%r11,%r12,1),%ymm11
  1ddd96:	vfmadd231pd (%rdi,%r12,1),%ymm11,%ymm8
  1ddd9c:	vfmadd231pd (%rsi,%r12,1),%ymm11,%ymm9
  1ddda2:	vfmadd231pd (%r10,%r12,1),%ymm11,%ymm7
  1ddda8:	vfmadd231pd (%r8,%r12,1),%ymm11,%ymm10
  1dddae:	vmovupd (%r14,%r12,1),%ymm12
  1dddb4:	vfmadd213pd %ymm5,%ymm6,%ymm12
  1dddb9:	vfmadd213pd (%rdx,%r12,1),%ymm11,%ymm12
  1dddbf:	vmovupd %ymm12,(%rbx,%r12,1)
  1dddc5:	vbroadcastsd -0x1b7b2e(%rip),%ymm11        # 262a0 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x4d0>
  1dddce:	vandpd %ymm11,%ymm12,%ymm11
  1dddd3:	vcmpeqpd %ymm2,%ymm11,%ymm12
  1dddd8:	vcmpge_oqpd %ymm3,%ymm11,%ymm11
  1ddddd:	vorpd  %ymm12,%ymm11,%ymm11
  1ddde2:	vandpd %ymm4,%ymm11,%ymm4
  1ddde6:	add    $0x20,%r12
  1dddea:	dec    %rax
  1ddded:	jne    1ddd90 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x9d0>
  1dddef:	jmp    1dde08 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xa48>
  1dddf1:	vxorpd %xmm10,%xmm10,%xmm10
  1dddf6:	vmovapd %ymm0,%ymm4
  1dddfa:	vxorpd %xmm7,%xmm7,%xmm7
  1dddfe:	vxorpd %xmm9,%xmm9,%xmm9
  1dde03:	vxorpd %xmm8,%xmm8,%xmm8
  1dde08:	mov    0x48(%rsp),%r10
  1dde0d:	mov    %r10d,%edx
  1dde10:	and    $0x3,%edx
  1dde13:	movabs $0xffffffffffffffc,%rsi
  1dde1d:	and    %rsi,%r10
  1dde20:	vextractf128 $0x1,%ymm8,%xmm11
  1dde26:	vaddpd %xmm11,%xmm8,%xmm8
  1dde2b:	vshufpd $0x1,%xmm8,%xmm8,%xmm11
  1dde31:	vaddsd %xmm11,%xmm8,%xmm8
  1dde36:	vextractf128 $0x1,%ymm9,%xmm11
  1dde3c:	vaddpd %xmm11,%xmm9,%xmm9
  1dde41:	vshufpd $0x1,%xmm9,%xmm9,%xmm11
  1dde47:	vaddsd %xmm11,%xmm9,%xmm9
  1dde4c:	vextractf128 $0x1,%ymm7,%xmm11
  1dde52:	vaddpd %xmm7,%xmm11,%xmm7
  1dde56:	vshufpd $0x1,%xmm7,%xmm7,%xmm11
  1dde5b:	vaddsd %xmm7,%xmm11,%xmm7
  1dde5f:	vextractf128 $0x1,%ymm10,%xmm11
  1dde65:	mov    0x10(%rsp),%r14
  1dde6a:	mov    %r14d,%r12d
  1dde6d:	and    $0x3,%r12d
  1dde71:	mov    0xe0(%rsp),%rax
  1dde79:	cmp    %rax,%r12
  1dde7c:	cmovae %rax,%r12
  1dde80:	vaddpd %xmm11,%xmm10,%xmm10
  1dde85:	cmp    %r12,%r9
  1dde88:	cmovb  %r9,%r12
  1dde8c:	vshufpd $0x1,%xmm10,%xmm10,%xmm11
  1dde92:	mov    0x198(%rsp),%rax
  1dde9a:	cmp    %r12,%rax
  1dde9d:	cmovb  %rax,%r12
  1ddea1:	vaddsd %xmm11,%xmm10,%xmm10
  1ddea6:	mov    0x118(%rsp),%rax
  1ddeae:	cmp    %r12,%rax
  1ddeb1:	cmovb  %rax,%r12
  1ddeb5:	cmp    %r12,%rdx
  1ddeb8:	mov    %rdx,0xb8(%rsp)
  1ddec0:	cmovb  %rdx,%r12
  1ddec4:	test   %r12,%r12
  1ddec7:	mov    %r10,0x140(%rsp)
  1ddecf:	je     1ddfd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xc14>
  1dded5:	mov    %r14,%rax
  1dded8:	and    %rsi,%rax
  1ddedb:	vmovsd (%r11,%rcx,8),%xmm11
  1ddee1:	mov    0xd0(%rsp),%rsi
  1ddee9:	mov    0x228(%rsp),%rdi
  1ddef1:	vmovsd (%rsi,%rdi,8),%xmm12
  1ddef6:	vfmadd213sd %xmm5,%xmm6,%xmm12
  1ddefb:	mov    %rbp,0x90(%rsp)
  1ddf03:	vfmadd213sd 0x0(%rbp,%rax,8),%xmm11,%xmm12
  1ddf0a:	vmovq  %xmm12,%r9
  1ddf0f:	mov    $0x3f,%dl
  1ddf11:	bzhi   %rdx,%r9,%r9
  1ddf16:	movabs $0x7ff0000000000000,%rdx
  1ddf20:	cmp    %rdx,%r9
  1ddf23:	sete   %r8b
  1ddf27:	test   %r9,%r9
  1ddf2a:	sete   %r14b
  1ddf2e:	or     %r8b,%r14b
  1ddf31:	mov    0x38(%rsp),%rdx
  1ddf36:	mov    0x150(%rsp),%r8
  1ddf3e:	vfmadd231sd (%rdx,%r8,8),%xmm11,%xmm8
  1ddf44:	mov    0x30(%rsp),%rdx
  1ddf49:	mov    0xa8(%rsp),%r8
  1ddf51:	vfmadd231sd (%rdx,%r8,8),%xmm11,%xmm9
  1ddf57:	mov    0x60(%rsp),%rdx
  1ddf5c:	mov    0x80(%rsp),%r8
  1ddf64:	vfmadd231sd (%rdx,%r8,8),%xmm11,%xmm7
  1ddf6a:	movabs $0xfff0000000000000,%rdx
  1ddf74:	add    %rdx,%r9
  1ddf77:	shr    $0x35,%r9
  1ddf7b:	cmp    $0x3ff,%r9d
  1ddf82:	mov    0x230(%rsp),%rdx
  1ddf8a:	mov    0x20(%rsp),%r8
  1ddf8f:	vfmadd231sd (%r8,%rdx,8),%xmm11,%xmm10
  1ddf95:	setb   %r9b
  1ddf99:	or     %r14b,%r9b
  1ddf9c:	vmovsd %xmm12,(%rbx,%r10,8)
  1ddfa2:	cmp    $0x1,%r12d
  1ddfa6:	jne    1de00b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xc4b>
  1ddfa8:	mov    0x68(%rsp),%rsi
  1ddfad:	mov    0xc0(%rsp),%r12
  1ddfb5:	mov    0x90(%rsp),%r10
  1ddfbd:	mov    0xa0(%rsp),%rbp
  1ddfc5:	mov    0x40(%rsp),%r8
  1ddfca:	mov    0x8(%rsp),%rdi
  1ddfcf:	jmp    1de1c7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xe07>
  1ddfd4:	mov    0x68(%rsp),%rsi
  1ddfd9:	mov    0xc0(%rsp),%r12
  1ddfe1:	mov    %rbp,%r10
  1ddfe4:	mov    0x1d0(%rsp),%rdx
  1ddfec:	mov    0xa0(%rsp),%rbp
  1ddff4:	mov    0x40(%rsp),%r8
  1ddff9:	mov    0x8(%rsp),%rdi
  1ddffe:	mov    0x110(%rsp),%rcx
  1de006:	jmp    1de1e1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xe21>
  1de00b:	mov    %r10,%rbp
  1de00e:	vmovsd 0x8(%r11,%rcx,8),%xmm11
  1de015:	vmovsd 0x8(%rsi,%rdi,8),%xmm12
  1de01b:	vfmadd213sd %xmm5,%xmm6,%xmm12
  1de020:	mov    0x90(%rsp),%r8
  1de028:	vfmadd213sd 0x8(%r8,%rax,8),%xmm11,%xmm12
  1de02f:	vmovq  %xmm12,%r8
  1de034:	mov    $0x3f,%r10b
  1de037:	bzhi   %r10,%r8,%r8
  1de03c:	movabs $0x7ff0000000000000,%r10
  1de046:	cmp    %r10,%r8
  1de049:	sete   %r14b
  1de04d:	test   %r8,%r8
  1de050:	sete   %r10b
  1de054:	or     %r14b,%r10b
  1de057:	movabs $0xfff0000000000000,%rsi
  1de061:	add    %rsi,%r8
  1de064:	shr    $0x35,%r8
  1de068:	cmp    $0x3ff,%r8d
  1de06f:	setb   %r8b
  1de073:	or     %r10b,%r8b
  1de076:	mov    0x38(%rsp),%rsi
  1de07b:	mov    0x150(%rsp),%r10
  1de083:	vfmadd231sd 0x8(%rsi,%r10,8),%xmm11,%xmm8
  1de08a:	mov    0x30(%rsp),%rsi
  1de08f:	mov    0xa8(%rsp),%r10
  1de097:	vfmadd231sd 0x8(%rsi,%r10,8),%xmm11,%xmm9
  1de09e:	mov    0x60(%rsp),%r10
  1de0a3:	mov    0x80(%rsp),%r14
  1de0ab:	vfmadd231sd 0x8(%r10,%r14,8),%xmm11,%xmm7
  1de0b2:	mov    0x20(%rsp),%r10
  1de0b7:	vfmadd231sd 0x8(%r10,%rdx,8),%xmm11,%xmm10
  1de0be:	and    %r8b,%r9b
  1de0c1:	vmovsd %xmm12,0x8(%rbx,%rbp,8)
  1de0c7:	cmp    $0x2,%r12d
  1de0cb:	mov    %rbp,%r14
  1de0ce:	mov    0xa0(%rsp),%rbp
  1de0d6:	jne    1de0f7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xd37>
  1de0d8:	mov    0x8(%rsp),%rdi
  1de0dd:	mov    0x68(%rsp),%rsi
  1de0e2:	mov    0xc0(%rsp),%r12
  1de0ea:	mov    0x90(%rsp),%r10
  1de0f2:	jmp    1de1c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xe02>
  1de0f7:	vmovsd 0x10(%r11,%rcx,8),%xmm11
  1de0fe:	mov    0xd0(%rsp),%rcx
  1de106:	vfmadd231sd 0x10(%rcx,%rdi,8),%xmm6,%xmm5
  1de10d:	mov    0x90(%rsp),%rcx
  1de115:	vfmadd213sd 0x10(%rcx,%rax,8),%xmm11,%xmm5
  1de11c:	vmovq  %xmm5,%rax
  1de121:	mov    $0x3f,%dil
  1de124:	bzhi   %rdi,%rax,%rax
  1de129:	movabs $0x7ff0000000000000,%rdi
  1de133:	cmp    %rdi,%rax
  1de136:	sete   %r10b
  1de13a:	test   %rax,%rax
  1de13d:	sete   %r8b
  1de141:	or     %r10b,%r8b
  1de144:	movabs $0xfff0000000000000,%rdi
  1de14e:	add    %rdi,%rax
  1de151:	shr    $0x35,%rax
  1de155:	cmp    $0x3ff,%eax
  1de15a:	setb   %al
  1de15d:	or     %r8b,%al
  1de160:	and    %al,%r9b
  1de163:	mov    0x38(%rsp),%rax
  1de168:	mov    0x150(%rsp),%rdi
  1de170:	vfmadd231sd 0x10(%rax,%rdi,8),%xmm11,%xmm8
  1de177:	mov    0xa8(%rsp),%rax
  1de17f:	vfmadd231sd 0x10(%rsi,%rax,8),%xmm11,%xmm9
  1de186:	mov    0x60(%rsp),%rax
  1de18b:	mov    0x80(%rsp),%rsi
  1de193:	vfmadd231sd 0x10(%rax,%rsi,8),%xmm11,%xmm7
  1de19a:	mov    0x20(%rsp),%rax
  1de19f:	vfmadd231sd 0x10(%rax,%rdx,8),%xmm11,%xmm10
  1de1a6:	vmovsd %xmm5,0x10(%rbx,%r14,8)
  1de1ad:	mov    0x8(%rsp),%rdi
  1de1b2:	mov    0x68(%rsp),%rsi
  1de1b7:	mov    0xc0(%rsp),%r12
  1de1bf:	mov    %rcx,%r10
  1de1c2:	mov    0x40(%rsp),%r8
  1de1c7:	mov    0x10(%rsp),%r14
  1de1cc:	mov    0x110(%rsp),%rcx
  1de1d4:	and    %r9b,0x7(%rsp)
  1de1d9:	mov    0x1d0(%rsp),%rdx
  1de1e1:	cmp    %rdi,%r13
  1de1e4:	jae    1dfcbc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x28fc>
  1de1ea:	mov    0xc8(%rsp),%rax
  1de1f2:	vmovsd %xmm8,(%rax,%r15,1)
  1de1f8:	vmovsd %xmm9,0x8(%rax,%r15,1)
  1de1ff:	cmp    %rsi,0x138(%rsp)
  1de207:	mov    0x28(%rsp),%rsi
  1de20c:	jae    1dd91c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x55c>
  1de212:	inc    %r13
  1de215:	cmp    %rdi,%r13
  1de218:	jae    1dfd2d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x296d>
  1de21e:	shl    $0x4,%r13
  1de222:	mov    0xc8(%rsp),%rax
  1de22a:	vmovsd %xmm7,(%rax,%r13,1)
  1de230:	vmovsd %xmm10,0x8(%rax,%r13,1)
  1de237:	jmp    1dd91c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x55c>
  1de23c:	mov    0x128(%rsp),%r13
  1de244:	mov    %r13,%rax
  1de247:	shr    $0x2,%rax
  1de24b:	mov    %rax,0x178(%rsp)
  1de253:	mov    %r13d,%eax
  1de256:	and    $0x3,%eax
  1de259:	mov    %rax,0x190(%rsp)
  1de261:	mov    0x50(%rsp),%r9
  1de266:	mov    %r9,%rax
  1de269:	shr    $0x2,%rax
  1de26d:	mov    %rax,0x1b8(%rsp)
  1de275:	mov    %r9d,%eax
  1de278:	and    $0x3,%eax
  1de27b:	mov    %rax,0x188(%rsp)
  1de283:	mov    0x78(%rsp),%rsi
  1de288:	mov    %rsi,%rax
  1de28b:	shr    $0x2,%rax
  1de28f:	mov    %rax,0x1b0(%rsp)
  1de297:	mov    %esi,%eax
  1de299:	and    $0x3,%eax
  1de29c:	mov    %rax,0x180(%rsp)
  1de2a4:	mov    0x70(%rsp),%r10
  1de2a9:	mov    %r10,%rax
  1de2ac:	shr    $0x2,%rax
  1de2b0:	mov    %rax,0x1a8(%rsp)
  1de2b8:	mov    %r10d,%eax
  1de2bb:	and    $0x3,%eax
  1de2be:	mov    %rax,0x1c0(%rsp)
  1de2c6:	mov    0x28(%rsp),%rdi
  1de2cb:	mov    %rdi,%r12
  1de2ce:	shr    $0x2,%r12
  1de2d2:	mov    %edi,%eax
  1de2d4:	and    $0x3,%eax
  1de2d7:	mov    %rax,0xb8(%rsp)
  1de2df:	mov    %rdi,%r8
  1de2e2:	movabs $0xffffffffffffffc,%rax
  1de2ec:	and    %rax,%r8
  1de2ef:	mov    %r8,0x140(%rsp)
  1de2f7:	mov    0x98(%rsp),%rax
  1de2ff:	mov    %rax,%r8
  1de302:	shr    $0x2,%r8
  1de306:	mov    %r8,0xb0(%rsp)
  1de30e:	shr    $0x3,%rax
  1de312:	mov    %rax,%r14
  1de315:	jmp    1de352 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0xf92>
  1de317:	vmovapd %ymm1,%ymm0
  1de31b:	mov    %rbx,%r11
  1de31e:	mov    0x108(%rsp),%rbx
  1de326:	mov    0x128(%rsp),%r13
  1de32e:	mov    0x50(%rsp),%r9
  1de333:	mov    0x78(%rsp),%rsi
  1de338:	mov    0x70(%rsp),%r10
  1de33d:	mov    0x60(%rsp),%r15
  1de342:	mov    0x88(%rsp),%r14
  1de34a:	mov    0x160(%rsp),%r12
  1de352:	movabs $0x3fffffffffffffe,%rax
  1de35c:	and    %rax,%r12
  1de35f:	shl    $0x5,%r12
  1de363:	mov    %rdi,0x28(%rsp)
  1de368:	shr    $0x3,%rdi
  1de36c:	mov    %r13,%rax
  1de36f:	shr    $0x3,%rax
  1de373:	shr    $0x3,%r9
  1de377:	cmp    %rax,%r9
  1de37a:	cmovae %rax,%r9
  1de37e:	mov    %rsi,%rax
  1de381:	shr    $0x3,%rax
  1de385:	cmp    %r9,%rax
  1de388:	cmovae %r9,%rax
  1de38c:	shr    $0x3,%r10
  1de390:	cmp    %rax,%r10
  1de393:	cmovae %rax,%r10
  1de397:	cmp    %r10,%rdi
  1de39a:	mov    %rdi,0x48(%rsp)
  1de39f:	cmovb  %rdi,%r10
  1de3a3:	cmp    %r10,%r14
  1de3a6:	cmovb  %r14,%r10
  1de3aa:	test   %r10,%r10
  1de3ad:	mov    %r14,0x88(%rsp)
  1de3b5:	je     1df325 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1f65>
  1de3bb:	cmp    $0x1,%r10
  1de3bf:	mov    0x38(%rsp),%rsi
  1de3c4:	jne    1df350 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1f90>
  1de3ca:	vxorpd %xmm1,%xmm1,%xmm1
  1de3ce:	xor    %r9d,%r9d
  1de3d1:	vxorpd %xmm3,%xmm3,%xmm3
  1de3d5:	vxorpd %xmm2,%xmm2,%xmm2
  1de3d9:	vxorpd %xmm7,%xmm7,%xmm7
  1de3dd:	vxorpd %xmm6,%xmm6,%xmm6
  1de3e1:	vxorpd %xmm5,%xmm5,%xmm5
  1de3e5:	vxorpd %xmm4,%xmm4,%xmm4
  1de3e9:	vxorpd %xmm8,%xmm8,%xmm8
  1de3ee:	jmp    1df43f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x207f>
  1de3f3:	mov    0x98(%rsp),%r9
  1de3fb:	shr    $0x2,%r9
  1de3ff:	cmp    %r8,%r9
  1de402:	mov    0x50(%rsp),%r12
  1de407:	jne    1dfc1b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x285b>
  1de40d:	mov    0x118(%rsp),%r9
  1de415:	shr    $0x2,%r9
  1de419:	cmp    %r8,%r9
  1de41c:	jne    1dfc1b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x285b>
  1de422:	mov    %r13d,%r15d
  1de425:	and    $0x3,%r15d
  1de429:	mov    %r12d,%r9d
  1de42c:	and    $0x3,%r9d
  1de430:	cmp    %r9d,%r15d
  1de433:	jne    1dfc1b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x285b>
  1de439:	mov    0x78(%rsp),%rbx
  1de43e:	and    $0x3,%ebx
  1de441:	cmp    %r9d,%ebx
  1de444:	jne    1dfc1b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x285b>
  1de44a:	mov    0x70(%rsp),%rbx
  1de44f:	and    $0x3,%ebx
  1de452:	cmp    %r9d,%ebx
  1de455:	jne    1dfc1b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x285b>
  1de45b:	mov    0x98(%rsp),%r9
  1de463:	and    $0x3,%r9d
  1de467:	cmp    %r15d,%r9d
  1de46a:	jne    1dfc1b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x285b>
  1de470:	mov    0x118(%rsp),%r9
  1de478:	and    $0x3,%r9d
  1de47c:	mov    %r9,0x1a0(%rsp)
  1de484:	cmp    %r15d,%r9d
  1de487:	jne    1dfc1b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x285b>
  1de48d:	mov    %r15,0x10(%rsp)
  1de492:	mov    %r8,0x138(%rsp)
  1de49a:	mov    %r13,0x128(%rsp)
  1de4a2:	movabs $0xffffffffffffffc,%r8
  1de4ac:	and    %r8,%r13
  1de4af:	mov    %r13,0xf8(%rsp)
  1de4b7:	and    %r8,%r12
  1de4ba:	mov    %r12,0x80(%rsp)
  1de4c2:	mov    0x78(%rsp),%r9
  1de4c7:	and    %r8,%r9
  1de4ca:	mov    %r9,0xf0(%rsp)
  1de4d2:	mov    0x70(%rsp),%r9
  1de4d7:	and    %r8,%r9
  1de4da:	mov    %r9,0xe8(%rsp)
  1de4e2:	mov    0x118(%rsp),%r9
  1de4ea:	and    %r8,%r9
  1de4ed:	mov    %r9,0xa0(%rsp)
  1de4f5:	mov    0x108(%rsp),%r9
  1de4fd:	mov    %r9d,%ebx
  1de500:	and    $0x3,%ebx
  1de503:	mov    %r9,%r14
  1de506:	and    %r8,%r14
  1de509:	mov    %r14,0x110(%rsp)
  1de511:	lea    -0x1(%rbx),%rsi
  1de515:	cmp    %rbx,%rsi
  1de518:	mov    %rbx,0xa8(%rsp)
  1de520:	cmovae %rbx,%rsi
  1de524:	mov    %rsi,0x198(%rsp)
  1de52c:	mov    0xb0(%rsp),%rsi
  1de534:	and    $0xfffffffffffffffe,%rsi
  1de538:	movb   $0x1,0x7(%rsp)
  1de53d:	mov    %rdi,%r8
  1de540:	mov    %r9,%rdi
  1de543:	mov    0x98(%rsp),%rbx
  1de54b:	mov    0xc0(%rsp),%r12
  1de553:	mov    0x60(%rsp),%r15
  1de558:	mov    0x90(%rsp),%r14
  1de560:	mov    %rsi,0xe0(%rsp)
  1de568:	jmp    1de593 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x11d3>
  1de56a:	add    $0x2,%r8
  1de56e:	mov    %r13,%rax
  1de571:	mov    0x48(%rsp),%rdi
  1de576:	mov    0x28(%rsp),%r9
  1de57b:	mov    0x50(%rsp),%rbx
  1de580:	cmp    0xb8(%rsp),%r8
  1de588:	mov    0x60(%rsp),%r15
  1de58d:	jae    1dfc65 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x28a5>
  1de593:	mov    %rbx,0x48(%rsp)
  1de598:	mov    %r14,%r13
  1de59b:	mov    %r11,%r14
  1de59e:	mov    %rdi,0x28(%rsp)
  1de5a3:	mov    %rax,%r11
  1de5a6:	mov    0xd8(%rsp),%rax
  1de5ae:	cmp    %rax,%r8
  1de5b1:	jae    1dfd88 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29c8>
  1de5b7:	cmp    0x58(%rsp),%r8
  1de5bc:	mov    0x30(%rsp),%rbx
  1de5c1:	jae    1dfda3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29e3>
  1de5c7:	lea    0x1(%r8),%rdi
  1de5cb:	cmp    %rax,%rdi
  1de5ce:	jae    1dfd70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29b0>
  1de5d4:	cmp    0x58(%rsp),%rdi
  1de5d9:	jae    1dfd5b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x299b>
  1de5df:	xor    %eax,%eax
  1de5e1:	cmp    %r9,0x28(%rsp)
  1de5e6:	jne    1dfc50 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2890>
  1de5ec:	cmp    %r9,0x50(%rsp)
  1de5f1:	mov    0x20(%rsp),%r9
  1de5f6:	mov    0x138(%rsp),%rdi
  1de5fe:	jne    1dfc50 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2890>
  1de604:	mov    0x28(%rsp),%rax
  1de609:	shr    $0x2,%rax
  1de60d:	cmp    %rdi,%rax
  1de610:	jne    1dfc4e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1de616:	mov    %r15,%rsi
  1de619:	mov    0x48(%rsp),%rax
  1de61e:	mov    %eax,%edi
  1de620:	and    $0x3,%edi
  1de623:	xor    %eax,%eax
  1de625:	mov    0x10(%rsp),%r15
  1de62a:	cmp    %r15d,%edi
  1de62d:	jne    1dfc50 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2890>
  1de633:	mov    0x28(%rsp),%rdi
  1de638:	and    $0x3,%edi
  1de63b:	cmp    %r15d,%edi
  1de63e:	jne    1dfc50 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2890>
  1de644:	mov    0x48(%rsp),%rdi
  1de649:	shr    $0x2,%rdi
  1de64d:	mov    0x138(%rsp),%r15
  1de655:	cmp    %r15,%rdi
  1de658:	jne    1dfc50 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2890>
  1de65e:	mov    0x1e8(%rsp),%rax
  1de666:	vmovsd (%rax,%r8,8),%xmm0
  1de66c:	mov    0x1e0(%rsp),%rdi
  1de674:	vmovsd (%rdi,%r8,8),%xmm3
  1de67a:	vmovsd 0x8(%rax,%r8,8),%xmm1
  1de681:	vmovsd 0x8(%rdi,%r8,8),%xmm2
  1de688:	test   %r15,%r15
  1de68b:	vmovapd %xmm0,0x160(%rsp)
  1de694:	vmovapd %xmm1,0x150(%rsp)
  1de69d:	vmovapd %xmm2,0x140(%rsp)
  1de6a6:	vmovapd %xmm3,0x1f0(%rsp)
  1de6af:	je     1de787 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x13c7>
  1de6b5:	vbroadcastsd %xmm0,%ymm12
  1de6ba:	vbroadcastsd %xmm3,%ymm13
  1de6bf:	vbroadcastsd %xmm1,%ymm14
  1de6c4:	vbroadcastsd %xmm2,%ymm15
  1de6c9:	vxorpd %xmm4,%xmm4,%xmm4
  1de6cd:	mov    %r15,%rax
  1de6d0:	xor    %edi,%edi
  1de6d2:	vxorpd %xmm2,%xmm2,%xmm2
  1de6d6:	vxorpd %xmm5,%xmm5,%xmm5
  1de6da:	vxorpd %xmm3,%xmm3,%xmm3
  1de6de:	vxorpd %xmm7,%xmm7,%xmm7
  1de6e2:	vxorpd %xmm6,%xmm6,%xmm6
  1de6e6:	vxorpd %xmm9,%xmm9,%xmm9
  1de6eb:	vxorpd %xmm8,%xmm8,%xmm8
  1de6f0:	mov    %rsi,%r15
  1de6f3:	mov    0x38(%rsp),%rsi
  1de6f8:	nopl   0x0(%rax,%rax,1)
  1de700:	vmovupd (%r14,%rdi,1),%ymm10
  1de706:	vmovupd (%rsi,%rdi,1),%ymm11
  1de70b:	vfmadd231pd %ymm10,%ymm11,%ymm8
  1de710:	mov    0xd0(%rsp),%r10
  1de718:	vmovupd (%r10,%rdi,1),%ymm0
  1de71e:	vmovapd %ymm0,%ymm1
  1de722:	vfmadd213pd %ymm13,%ymm12,%ymm1
  1de727:	vfmadd213pd (%r11,%rdi,1),%ymm10,%ymm1
  1de72d:	vfmadd231pd %ymm11,%ymm1,%ymm3
  1de732:	vmovupd (%rbx,%rdi,1),%ymm11
  1de737:	vfmadd231pd %ymm10,%ymm11,%ymm9
  1de73c:	vfmadd231pd %ymm11,%ymm1,%ymm5
  1de741:	vmovupd (%r15,%rdi,1),%ymm11
  1de747:	vfmadd231pd %ymm10,%ymm11,%ymm6
  1de74c:	vfmadd231pd %ymm11,%ymm1,%ymm2
  1de751:	vmovupd (%r9,%rdi,1),%ymm11
  1de757:	vfmadd231pd %ymm10,%ymm11,%ymm7
  1de75c:	vfmadd231pd %ymm11,%ymm1,%ymm4
  1de761:	vfmadd213pd %ymm15,%ymm14,%ymm0
  1de766:	vfmadd213pd %ymm10,%ymm1,%ymm0
  1de76b:	vmovupd %ymm1,0x0(%r13,%rdi,1)
  1de772:	vmovupd %ymm0,(%r11,%rdi,1)
  1de778:	add    $0x20,%rdi
  1de77c:	dec    %rax
  1de77f:	jne    1de700 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1340>
  1de785:	jmp    1de7ac <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x13ec>
  1de787:	vxorpd %xmm8,%xmm8,%xmm8
  1de78c:	vxorpd %xmm9,%xmm9,%xmm9
  1de791:	vxorpd %xmm6,%xmm6,%xmm6
  1de795:	vxorpd %xmm7,%xmm7,%xmm7
  1de799:	vxorpd %xmm3,%xmm3,%xmm3
  1de79d:	vxorpd %xmm5,%xmm5,%xmm5
  1de7a1:	vxorpd %xmm2,%xmm2,%xmm2
  1de7a5:	vxorpd %xmm4,%xmm4,%xmm4
  1de7a9:	mov    %rsi,%r15
  1de7ac:	mov    0x48(%rsp),%rsi
  1de7b1:	movabs $0xffffffffffffffc,%rax
  1de7bb:	and    %rax,%rsi
  1de7be:	vextractf128 $0x1,%ymm8,%xmm0
  1de7c4:	vaddpd %xmm0,%xmm8,%xmm0
  1de7c8:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1de7cd:	vaddsd %xmm1,%xmm0,%xmm8
  1de7d1:	vextractf128 $0x1,%ymm9,%xmm0
  1de7d7:	vaddpd %xmm0,%xmm9,%xmm0
  1de7db:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1de7e0:	vaddsd %xmm1,%xmm0,%xmm9
  1de7e4:	vextractf128 $0x1,%ymm6,%xmm0
  1de7ea:	vaddpd %xmm0,%xmm6,%xmm0
  1de7ee:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1de7f3:	vaddsd %xmm1,%xmm0,%xmm6
  1de7f7:	vextractf128 $0x1,%ymm7,%xmm0
  1de7fd:	vaddpd %xmm0,%xmm7,%xmm0
  1de801:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1de806:	vaddsd %xmm1,%xmm0,%xmm7
  1de80a:	vextractf128 $0x1,%ymm3,%xmm0
  1de810:	vaddpd %xmm0,%xmm3,%xmm0
  1de814:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1de819:	vaddsd %xmm1,%xmm0,%xmm3
  1de81d:	vextractf128 $0x1,%ymm5,%xmm0
  1de823:	vaddpd %xmm0,%xmm5,%xmm0
  1de827:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1de82c:	vaddsd %xmm1,%xmm0,%xmm5
  1de830:	vextractf128 $0x1,%ymm2,%xmm0
  1de836:	vaddpd %xmm0,%xmm2,%xmm0
  1de83a:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1de83f:	vaddsd %xmm1,%xmm0,%xmm2
  1de843:	vextractf128 $0x1,%ymm4,%xmm0
  1de849:	vaddpd %xmm0,%xmm4,%xmm0
  1de84d:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1de852:	vaddsd %xmm1,%xmm0,%xmm4
  1de856:	cmpq   $0x0,0x1a0(%rsp)
  1de85f:	mov    %rsi,0x88(%rsp)
  1de867:	mov    %r14,0x90(%rsp)
  1de86f:	je     1deddc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1a1c>
  1de875:	cmpq   $0x0,0x10(%rsp)
  1de87b:	je     1dfc4e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x288e>
  1de881:	mov    %rsi,%rax
  1de884:	mov    %r8,0x40(%rsp)
  1de889:	mov    0x28(%rsp),%rsi
  1de88e:	movabs $0xffffffffffffffc,%rdi
  1de898:	and    %rdi,%rsi
  1de89b:	mov    0xa0(%rsp),%rdi
  1de8a3:	mov    0xd0(%rsp),%r8
  1de8ab:	vmovsd (%r8,%rdi,8),%xmm12
  1de8b1:	vmovapd %xmm12,%xmm13
  1de8b6:	vmovapd 0x160(%rsp),%xmm15
  1de8bf:	vmovapd 0x1f0(%rsp),%xmm11
  1de8c8:	vfmadd213sd %xmm11,%xmm15,%xmm13
  1de8cd:	mov    0x80(%rsp),%rdi
  1de8d5:	vmovsd (%r14,%rdi,8),%xmm14
  1de8db:	vfmadd213sd (%r11,%rsi,8),%xmm14,%xmm13
  1de8e1:	vmovapd 0x150(%rsp),%xmm1
  1de8ea:	vmovapd 0x140(%rsp),%xmm10
  1de8f3:	vfmadd213sd %xmm10,%xmm1,%xmm12
  1de8f8:	vfmadd213sd %xmm14,%xmm13,%xmm12
  1de8fd:	mov    0xe8(%rsp),%r8
  1de905:	vmovsd (%r9,%r8,8),%xmm0
  1de90b:	vfmadd231sd %xmm13,%xmm0,%xmm4
  1de910:	vfmadd231sd %xmm0,%xmm14,%xmm7
  1de915:	mov    0xf0(%rsp),%r8
  1de91d:	vmovsd (%r15,%r8,8),%xmm0
  1de923:	vfmadd231sd %xmm13,%xmm0,%xmm2
  1de928:	vfmadd231sd %xmm0,%xmm14,%xmm6
  1de92d:	vmovsd (%rbx,%rdi,8),%xmm0
  1de932:	vfmadd231sd %xmm13,%xmm0,%xmm5
  1de937:	vfmadd231sd %xmm0,%xmm14,%xmm9
  1de93c:	mov    0x38(%rsp),%rdi
  1de941:	mov    0xf8(%rsp),%r8
  1de949:	vmovsd (%rdi,%r8,8),%xmm0
  1de94f:	vfmadd231sd %xmm14,%xmm0,%xmm8
  1de954:	vfmadd231sd %xmm13,%xmm0,%xmm3
  1de959:	vmovsd %xmm13,0x0(%r13,%rax,8)
  1de960:	vmovq  %xmm13,%rdi
  1de965:	vmovq  %xmm12,%r8
  1de96a:	mov    %rsi,0x120(%rsp)
  1de972:	vmovsd %xmm12,(%r11,%rsi,8)
  1de978:	mov    $0x3f,%sil
  1de97b:	bzhi   %rsi,%rdi,%rdi
  1de980:	movabs $0x7ff0000000000000,%rsi
  1de98a:	cmp    %rsi,%rdi
  1de98d:	sete   %r9b
  1de991:	test   %rdi,%rdi
  1de994:	sete   %r10b
  1de998:	or     %r9b,%r10b
  1de99b:	movabs $0xfff0000000000000,%rax
  1de9a5:	add    %rax,%rdi
  1de9a8:	shr    $0x35,%rdi
  1de9ac:	cmp    $0x3ff,%edi
  1de9b2:	setb   %r9b
  1de9b6:	or     %r10b,%r9b
  1de9b9:	mov    $0x3f,%dil
  1de9bc:	bzhi   %rdi,%r8,%rdi
  1de9c1:	cmp    %rsi,%rdi
  1de9c4:	sete   %r8b
  1de9c8:	test   %rdi,%rdi
  1de9cb:	sete   %r10b
  1de9cf:	or     %r8b,%r10b
  1de9d2:	add    %rax,%rdi
  1de9d5:	shr    $0x35,%rdi
  1de9d9:	cmp    $0x3ff,%edi
  1de9df:	setb   %dil
  1de9e3:	or     %r10b,%dil
  1de9e6:	and    %r9b,%dil
  1de9e9:	cmpl   $0x1,0x10(%rsp)
  1de9ee:	je     1dedbb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x19fb>
  1de9f4:	mov    0xa0(%rsp),%r8
  1de9fc:	mov    0xd0(%rsp),%rax
  1dea04:	vmovsd 0x8(%rax,%r8,8),%xmm12
  1dea0b:	vmovapd %xmm12,%xmm13
  1dea10:	vfmadd213sd %xmm11,%xmm15,%xmm13
  1dea15:	mov    0x80(%rsp),%r8
  1dea1d:	vmovsd 0x8(%r14,%r8,8),%xmm14
  1dea24:	mov    0x120(%rsp),%rsi
  1dea2c:	vfmadd213sd 0x8(%r11,%rsi,8),%xmm14,%xmm13
  1dea33:	vfmadd213sd %xmm10,%xmm1,%xmm12
  1dea38:	vfmadd213sd %xmm14,%xmm13,%xmm12
  1dea3d:	mov    0xe8(%rsp),%r9
  1dea45:	mov    0x20(%rsp),%r10
  1dea4a:	vmovsd 0x8(%r10,%r9,8),%xmm0
  1dea51:	vfmadd231sd %xmm13,%xmm0,%xmm4
  1dea56:	vfmadd231sd %xmm0,%xmm14,%xmm7
  1dea5b:	mov    0xf0(%rsp),%r9
  1dea63:	vmovsd 0x8(%r15,%r9,8),%xmm0
  1dea6a:	vfmadd231sd %xmm13,%xmm0,%xmm2
  1dea6f:	vfmadd231sd %xmm0,%xmm14,%xmm6
  1dea74:	vmovsd 0x8(%rbx,%r8,8),%xmm0
  1dea7b:	vfmadd231sd %xmm13,%xmm0,%xmm5
  1dea80:	vfmadd231sd %xmm0,%xmm14,%xmm9
  1dea85:	mov    0x38(%rsp),%r8
  1dea8a:	mov    0xf8(%rsp),%r9
  1dea92:	vmovsd 0x8(%r8,%r9,8),%xmm0
  1dea99:	vfmadd231sd %xmm14,%xmm0,%xmm8
  1dea9e:	vfmadd231sd %xmm13,%xmm0,%xmm3
  1deaa3:	vmovq  %xmm13,%r8
  1deaa8:	mov    0x88(%rsp),%r9
  1deab0:	vmovsd %xmm13,0x8(%r13,%r9,8)
  1deab7:	vmovq  %xmm12,%r9
  1deabc:	vmovsd %xmm12,0x8(%r11,%rsi,8)
  1deac3:	mov    $0x3f,%sil
  1deac6:	bzhi   %rsi,%r8,%r8
  1deacb:	movabs $0x7ff0000000000000,%rax
  1dead5:	cmp    %rax,%r8
  1dead8:	sete   %r10b
  1deadc:	test   %r8,%r8
  1deadf:	sete   %bl
  1deae2:	or     %r10b,%bl
  1deae5:	movabs $0xfff0000000000000,%r15
  1deaef:	add    %r15,%r8
  1deaf2:	shr    $0x35,%r8
  1deaf6:	cmp    $0x3ff,%r8d
  1deafd:	setb   %r8b
  1deb01:	or     %bl,%r8b
  1deb04:	bzhi   %rsi,%r9,%r9
  1deb09:	cmp    %rax,%r9
  1deb0c:	sete   %r10b
  1deb10:	test   %r9,%r9
  1deb13:	sete   %bl
  1deb16:	or     %r10b,%bl
  1deb19:	add    %r15,%r9
  1deb1c:	shr    $0x35,%r9
  1deb20:	cmp    $0x3ff,%r9d
  1deb27:	setb   %r9b
  1deb2b:	or     %bl,%r9b
  1deb2e:	and    %r8b,%r9b
  1deb31:	and    %r9b,%dil
  1deb34:	cmpl   $0x2,0x10(%rsp)
  1deb39:	je     1dedbb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x19fb>
  1deb3f:	mov    0xd0(%rsp),%rsi
  1deb47:	mov    0xa0(%rsp),%r8
  1deb4f:	vmovsd 0x10(%rsi,%r8,8),%xmm12
  1deb56:	vmovapd %xmm12,%xmm13
  1deb5b:	vfmadd213sd %xmm11,%xmm15,%xmm13
  1deb60:	mov    0x80(%rsp),%r8
  1deb68:	vmovsd 0x10(%r14,%r8,8),%xmm14
  1deb6f:	mov    0x120(%rsp),%rsi
  1deb77:	vfmadd213sd 0x10(%r11,%rsi,8),%xmm14,%xmm13
  1deb7e:	vfmadd213sd %xmm10,%xmm1,%xmm12
  1deb83:	vfmadd213sd %xmm14,%xmm13,%xmm12
  1deb88:	mov    0xe8(%rsp),%r9
  1deb90:	mov    0x20(%rsp),%r10
  1deb95:	vmovsd 0x10(%r10,%r9,8),%xmm0
  1deb9c:	vfmadd231sd %xmm13,%xmm0,%xmm4
  1deba1:	vfmadd231sd %xmm0,%xmm14,%xmm7
  1deba6:	mov    0xf0(%rsp),%r9
  1debae:	mov    0x60(%rsp),%rax
  1debb3:	vmovsd 0x10(%rax,%r9,8),%xmm0
  1debba:	vfmadd231sd %xmm13,%xmm0,%xmm2
  1debbf:	vfmadd231sd %xmm0,%xmm14,%xmm6
  1debc4:	mov    0x30(%rsp),%rax
  1debc9:	vmovsd 0x10(%rax,%r8,8),%xmm0
  1debd0:	vfmadd231sd %xmm13,%xmm0,%xmm5
  1debd5:	vfmadd231sd %xmm0,%xmm14,%xmm9
  1debda:	mov    0x38(%rsp),%r8
  1debdf:	mov    0xf8(%rsp),%r9
  1debe7:	vmovsd 0x10(%r8,%r9,8),%xmm0
  1debee:	vfmadd231sd %xmm14,%xmm0,%xmm8
  1debf3:	vfmadd231sd %xmm13,%xmm0,%xmm3
  1debf8:	vmovq  %xmm13,%r8
  1debfd:	mov    0x88(%rsp),%r9
  1dec05:	vmovsd %xmm13,0x10(%r13,%r9,8)
  1dec0c:	vmovq  %xmm12,%r9
  1dec11:	vmovsd %xmm12,0x10(%r11,%rsi,8)
  1dec18:	mov    $0x3f,%sil
  1dec1b:	bzhi   %rsi,%r8,%r8
  1dec20:	movabs $0x7ff0000000000000,%rax
  1dec2a:	cmp    %rax,%r8
  1dec2d:	sete   %r10b
  1dec31:	test   %r8,%r8
  1dec34:	sete   %bl
  1dec37:	or     %r10b,%bl
  1dec3a:	add    %r15,%r8
  1dec3d:	shr    $0x35,%r8
  1dec41:	cmp    $0x3ff,%r8d
  1dec48:	setb   %r8b
  1dec4c:	or     %bl,%r8b
  1dec4f:	bzhi   %rsi,%r9,%r9
  1dec54:	cmp    %rax,%r9
  1dec57:	sete   %r10b
  1dec5b:	test   %r9,%r9
  1dec5e:	sete   %bl
  1dec61:	or     %r10b,%bl
  1dec64:	add    %r15,%r9
  1dec67:	shr    $0x35,%r9
  1dec6b:	cmp    $0x3ff,%r9d
  1dec72:	setb   %r9b
  1dec76:	or     %bl,%r9b
  1dec79:	and    %r8b,%r9b
  1dec7c:	and    %r9b,%dil
  1dec7f:	cmpl   $0x3,0x10(%rsp)
  1dec84:	je     1dedbb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x19fb>
  1dec8a:	mov    0xd0(%rsp),%rsi
  1dec92:	mov    0xa0(%rsp),%r8
  1dec9a:	vmovsd 0x18(%rsi,%r8,8),%xmm0
  1deca1:	vfmadd213sd %xmm11,%xmm0,%xmm15
  1deca6:	mov    0x80(%rsp),%rsi
  1decae:	vmovsd 0x18(%r14,%rsi,8),%xmm11
  1decb5:	mov    0x120(%rsp),%r14
  1decbd:	vfmadd213sd 0x18(%r11,%r14,8),%xmm11,%xmm15
  1decc4:	vmovq  %xmm15,%r8
  1decc9:	mov    $0x3f,%bl
  1deccb:	bzhi   %rbx,%r8,%r8
  1decd0:	cmp    %rax,%r8
  1decd3:	sete   %r9b
  1decd7:	test   %r8,%r8
  1decda:	sete   %r10b
  1decde:	or     %r9b,%r10b
  1dece1:	add    %r15,%r8
  1dece4:	shr    $0x35,%r8
  1dece8:	cmp    $0x3ff,%r8d
  1decef:	setb   %r9b
  1decf3:	or     %r10b,%r9b
  1decf6:	vfmadd213sd %xmm10,%xmm0,%xmm1
  1decfb:	vfmadd213sd %xmm11,%xmm15,%xmm1
  1ded00:	vmovq  %xmm1,%r8
  1ded05:	bzhi   %rbx,%r8,%r8
  1ded0a:	cmp    %rax,%r8
  1ded0d:	sete   %r10b
  1ded11:	test   %r8,%r8
  1ded14:	sete   %bl
  1ded17:	or     %r10b,%bl
  1ded1a:	add    %r15,%r8
  1ded1d:	shr    $0x35,%r8
  1ded21:	cmp    $0x3ff,%r8d
  1ded28:	mov    0xe8(%rsp),%rax
  1ded30:	mov    0x20(%rsp),%r8
  1ded35:	vmovsd 0x18(%r8,%rax,8),%xmm0
  1ded3c:	vmovapd %xmm1,%xmm13
  1ded40:	mov    0xf0(%rsp),%rax
  1ded48:	mov    0x60(%rsp),%r15
  1ded4d:	vmovsd 0x18(%r15,%rax,8),%xmm1
  1ded54:	mov    0x30(%rsp),%rax
  1ded59:	vmovsd 0x18(%rax,%rsi,8),%xmm10
  1ded5f:	mov    0x38(%rsp),%rax
  1ded64:	mov    0xf8(%rsp),%rsi
  1ded6c:	vmovsd 0x18(%rax,%rsi,8),%xmm12
  1ded72:	mov    0x88(%rsp),%rax
  1ded7a:	vmovsd %xmm15,0x18(%r13,%rax,8)
  1ded81:	vmovsd %xmm13,0x18(%r11,%r14,8)
  1ded88:	setb   %al
  1ded8b:	or     %bl,%al
  1ded8d:	and    %r9b,%al
  1ded90:	and    %al,%dil
  1ded93:	vfmadd231sd %xmm15,%xmm0,%xmm4
  1ded98:	vfmadd231sd %xmm15,%xmm1,%xmm2
  1ded9d:	vfmadd231sd %xmm15,%xmm10,%xmm5
  1deda2:	vfmadd231sd %xmm15,%xmm12,%xmm3
  1deda7:	vfmadd231sd %xmm0,%xmm11,%xmm7
  1dedac:	vfmadd231sd %xmm1,%xmm11,%xmm6
  1dedb1:	vfmadd231sd %xmm10,%xmm11,%xmm9
  1dedb6:	vfmadd231sd %xmm11,%xmm12,%xmm8
  1dedbb:	mov    0xe0(%rsp),%r14
  1dedc3:	and    %dil,0x7(%rsp)
  1dedc8:	mov    0x8(%rsp),%rax
  1dedcd:	mov    0x40(%rsp),%r8
  1dedd2:	mov    0xa8(%rsp),%r10
  1dedda:	jmp    1dedf1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1a31>
  1deddc:	mov    0x8(%rsp),%rax
  1dede1:	mov    0xa8(%rsp),%r10
  1dede9:	mov    0xe0(%rsp),%r14
  1dedf1:	lea    (%r8,%r8,1),%r9
  1dedf5:	cmp    %rax,%r9
  1dedf8:	jae    1dfdd3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a13>
  1dedfe:	mov    %r9,%rbx
  1dee01:	shl    $0x4,%rbx
  1dee05:	mov    0xc8(%rsp),%rdi
  1dee0d:	vmovsd %xmm8,(%rdi,%rbx,1)
  1dee12:	mov    0x130(%rsp),%rax
  1dee1a:	lea    (%rax,%r8,2),%rsi
  1dee1e:	vmovsd %xmm9,0x8(%rdi,%rbx,1)
  1dee24:	cmp    0x68(%rsp),%rsi
  1dee29:	jae    1dee51 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1a91>
  1dee2b:	lea    0x1(%r9),%rax
  1dee2f:	cmp    0x8(%rsp),%rax
  1dee34:	jae    1dfe1b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a5b>
  1dee3a:	shl    $0x4,%rax
  1dee3e:	mov    0xc8(%rsp),%rdi
  1dee46:	vmovsd %xmm6,(%rdi,%rax,1)
  1dee4b:	vmovsd %xmm7,0x8(%rdi,%rax,1)
  1dee51:	mov    %rbx,0x160(%rsp)
  1dee59:	mov    %rsi,0x40(%rsp)
  1dee5e:	lea    0x2(%rsi),%rdi
  1dee62:	mov    %rdi,%r15
  1dee65:	sub    0x130(%rsp),%r15
  1dee6d:	cmp    0x8(%rsp),%r15
  1dee72:	jae    1dfe03 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a43>
  1dee78:	mov    %r15,%rbx
  1dee7b:	shl    $0x4,%rbx
  1dee7f:	mov    0xc8(%rsp),%rax
  1dee87:	vmovsd %xmm3,(%rax,%rbx,1)
  1dee8c:	mov    %rbx,0x150(%rsp)
  1dee94:	vmovsd %xmm5,0x8(%rax,%rbx,1)
  1dee9a:	cmp    0x68(%rsp),%rdi
  1dee9f:	mov    %r14,%rsi
  1deea2:	mov    0x90(%rsp),%r14
  1deeaa:	jae    1deef1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1b31>
  1deeac:	lea    0x1(%r15),%rax
  1deeb0:	cmp    0x8(%rsp),%rax
  1deeb5:	jae    1dfe1b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a5b>
  1deebb:	mov    %r9,%rbx
  1deebe:	mov    %r8,%r9
  1deec1:	shl    $0x4,%rax
  1deec5:	mov    0xc8(%rsp),%r8
  1deecd:	vmovsd %xmm2,(%r8,%rax,1)
  1deed3:	vmovsd %xmm4,0x8(%r8,%rax,1)
  1deeda:	mov    %r9,%r8
  1deedd:	mov    0xa8(%rsp),%r10
  1deee5:	mov    %rbx,%r9
  1deee8:	mov    0x40(%rsp),%rax
  1deeed:	lea    0x2(%rax),%rdi
  1deef1:	vxorpd %xmm0,%xmm0,%xmm0
  1deef5:	mov    0xb0(%rsp),%rax
  1deefd:	test   %rax,%rax
  1def00:	je     1def2b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1b6b>
  1def02:	cmp    $0x1,%rax
  1def06:	jne    1def4c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1b8c>
  1def08:	vxorpd %xmm1,%xmm1,%xmm1
  1def0c:	vxorpd %xmm2,%xmm2,%xmm2
  1def10:	vxorpd %xmm3,%xmm3,%xmm3
  1def14:	vxorpd %xmm4,%xmm4,%xmm4
  1def18:	vxorpd %xmm6,%xmm6,%xmm6
  1def1c:	xor    %eax,%eax
  1def1e:	vxorpd %xmm7,%xmm7,%xmm7
  1def22:	vxorpd %xmm5,%xmm5,%xmm5
  1def26:	jmp    1df043 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1c83>
  1def2b:	vxorpd %xmm1,%xmm1,%xmm1
  1def2f:	vxorpd %xmm2,%xmm2,%xmm2
  1def33:	vxorpd %xmm3,%xmm3,%xmm3
  1def37:	vxorpd %xmm4,%xmm4,%xmm4
  1def3b:	vxorpd %xmm6,%xmm6,%xmm6
  1def3f:	vxorpd %xmm5,%xmm5,%xmm5
  1def43:	vxorpd %xmm7,%xmm7,%xmm7
  1def47:	jmp    1df092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1cd2>
  1def4c:	mov    %r9,0x140(%rsp)
  1def54:	mov    $0x20,%r9d
  1def5a:	vxorpd %xmm1,%xmm1,%xmm1
  1def5e:	vxorpd %xmm2,%xmm2,%xmm2
  1def62:	vxorpd %xmm3,%xmm3,%xmm3
  1def66:	vxorpd %xmm4,%xmm4,%xmm4
  1def6a:	vxorpd %xmm6,%xmm6,%xmm6
  1def6e:	xor    %eax,%eax
  1def70:	vxorpd %xmm7,%xmm7,%xmm7
  1def74:	vxorpd %xmm5,%xmm5,%xmm5
  1def78:	vmovupd -0x20(%rcx,%r9,1),%ymm8
  1def7f:	vmovupd -0x20(%r14,%r9,1),%ymm9
  1def86:	vfmadd231pd %ymm9,%ymm8,%ymm7
  1def8b:	vmovupd -0x20(%rdx,%r9,1),%ymm10
  1def92:	vfmadd231pd %ymm9,%ymm10,%ymm6
  1def97:	vmovupd -0x20(%rbp,%r9,1),%ymm11
  1def9e:	vfmadd231pd %ymm9,%ymm11,%ymm4
  1defa3:	vmovupd -0x20(%r12,%r9,1),%ymm12
  1defaa:	vfmadd231pd %ymm9,%ymm12,%ymm3
  1defaf:	vmovupd -0x20(%r13,%r9,1),%ymm9
  1defb6:	vfmadd231pd %ymm8,%ymm9,%ymm5
  1defbb:	vmovupd (%rcx,%r9,1),%ymm8
  1defc1:	vfmadd231pd %ymm10,%ymm9,%ymm2
  1defc6:	vmovupd (%r14,%r9,1),%ymm10
  1defcc:	vfmadd231pd %ymm11,%ymm9,%ymm1
  1defd1:	vmovupd (%rdx,%r9,1),%ymm11
  1defd7:	vfmadd231pd %ymm9,%ymm12,%ymm0
  1defdc:	vmovupd 0x0(%rbp,%r9,1),%ymm9
  1defe3:	vmovupd (%r12,%r9,1),%ymm12
  1defe9:	vfmadd231pd %ymm10,%ymm8,%ymm7
  1defee:	vfmadd231pd %ymm10,%ymm11,%ymm6
  1deff3:	vfmadd231pd %ymm10,%ymm9,%ymm4
  1deff8:	vfmadd231pd %ymm10,%ymm12,%ymm3
  1deffd:	vmovupd 0x0(%r13,%r9,1),%ymm10
  1df004:	vfmadd231pd %ymm8,%ymm10,%ymm5
  1df009:	vfmadd231pd %ymm11,%ymm10,%ymm2
  1df00e:	vfmadd231pd %ymm9,%ymm10,%ymm1
  1df013:	vfmadd231pd %ymm10,%ymm12,%ymm0
  1df018:	add    $0x2,%rax
  1df01c:	add    $0x40,%r9
  1df020:	cmp    %rax,%rsi
  1df023:	jne    1def78 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1bb8>
  1df029:	testb  $0x1,0xb0(%rsp)
  1df031:	mov    0xa8(%rsp),%r10
  1df039:	mov    0x140(%rsp),%r9
  1df041:	je     1df092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1cd2>
  1df043:	shl    $0x5,%rax
  1df047:	vmovupd (%rcx,%rax,1),%ymm8
  1df04c:	vmovupd (%r14,%rax,1),%ymm9
  1df052:	vfmadd231pd %ymm9,%ymm8,%ymm7
  1df057:	vmovupd (%rdx,%rax,1),%ymm10
  1df05c:	vfmadd231pd %ymm9,%ymm10,%ymm6
  1df061:	vmovupd 0x0(%rbp,%rax,1),%ymm11
  1df067:	vfmadd231pd %ymm9,%ymm11,%ymm4
  1df06c:	vmovupd (%r12,%rax,1),%ymm12
  1df072:	vfmadd231pd %ymm9,%ymm12,%ymm3
  1df077:	vmovupd 0x0(%r13,%rax,1),%ymm9
  1df07e:	vfmadd231pd %ymm8,%ymm9,%ymm5
  1df083:	vfmadd231pd %ymm10,%ymm9,%ymm2
  1df088:	vfmadd231pd %ymm11,%ymm9,%ymm1
  1df08d:	vfmadd231pd %ymm9,%ymm12,%ymm0
  1df092:	vextractf128 $0x1,%ymm7,%xmm8
  1df098:	vaddpd %xmm7,%xmm8,%xmm7
  1df09c:	vshufpd $0x1,%xmm7,%xmm7,%xmm8
  1df0a1:	vaddsd %xmm7,%xmm8,%xmm7
  1df0a5:	vextractf128 $0x1,%ymm6,%xmm8
  1df0ab:	vaddpd %xmm6,%xmm8,%xmm6
  1df0af:	vshufpd $0x1,%xmm6,%xmm6,%xmm8
  1df0b4:	vaddsd %xmm6,%xmm8,%xmm8
  1df0b8:	vextractf128 $0x1,%ymm4,%xmm6
  1df0be:	vaddpd %xmm6,%xmm4,%xmm4
  1df0c2:	vshufpd $0x1,%xmm4,%xmm4,%xmm6
  1df0c7:	vaddsd %xmm6,%xmm4,%xmm4
  1df0cb:	vextractf128 $0x1,%ymm3,%xmm6
  1df0d1:	vaddpd %xmm6,%xmm3,%xmm3
  1df0d5:	vshufpd $0x1,%xmm3,%xmm3,%xmm6
  1df0da:	vaddsd %xmm6,%xmm3,%xmm6
  1df0de:	vextractf128 $0x1,%ymm5,%xmm3
  1df0e4:	vaddpd %xmm3,%xmm5,%xmm3
  1df0e8:	vshufpd $0x1,%xmm3,%xmm3,%xmm5
  1df0ed:	vaddsd %xmm5,%xmm3,%xmm3
  1df0f1:	vextractf128 $0x1,%ymm2,%xmm5
  1df0f7:	vaddpd %xmm5,%xmm2,%xmm2
  1df0fb:	vshufpd $0x1,%xmm2,%xmm2,%xmm5
  1df100:	vaddsd %xmm5,%xmm2,%xmm2
  1df104:	vextractf128 $0x1,%ymm1,%xmm5
  1df10a:	vaddpd %xmm5,%xmm1,%xmm1
  1df10e:	vshufpd $0x1,%xmm1,%xmm1,%xmm5
  1df113:	vaddsd %xmm5,%xmm1,%xmm1
  1df117:	vextractf128 $0x1,%ymm0,%xmm5
  1df11d:	vaddpd %xmm5,%xmm0,%xmm0
  1df121:	vshufpd $0x1,%xmm0,%xmm0,%xmm5
  1df126:	vaddsd %xmm5,%xmm0,%xmm0
  1df12a:	test   %r10,%r10
  1df12d:	je     1df268 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1ea8>
  1df133:	mov    0x198(%rsp),%rax
  1df13b:	cmp    %rax,0x10(%rsp)
  1df140:	mov    0x80(%rsp),%rax
  1df148:	jbe    1dfe6f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2aaf>
  1df14e:	mov    %r9,%rbx
  1df151:	mov    0x110(%rsp),%rsi
  1df159:	vmovsd (%rcx,%rsi,8),%xmm5
  1df15e:	vmovsd (%r14,%rax,8),%xmm9
  1df164:	vfmadd231sd %xmm9,%xmm5,%xmm7
  1df169:	vmovsd (%rdx,%rsi,8),%xmm10
  1df16e:	vfmadd231sd %xmm9,%xmm10,%xmm8
  1df173:	vmovsd 0x0(%rbp,%rsi,8),%xmm11
  1df179:	vfmadd231sd %xmm9,%xmm11,%xmm4
  1df17e:	vmovsd (%r12,%rsi,8),%xmm12
  1df184:	vfmadd231sd %xmm9,%xmm12,%xmm6
  1df189:	mov    0x88(%rsp),%r9
  1df191:	vmovsd 0x0(%r13,%r9,8),%xmm9
  1df198:	vfmadd231sd %xmm5,%xmm9,%xmm3
  1df19d:	vfmadd231sd %xmm10,%xmm9,%xmm2
  1df1a2:	vfmadd231sd %xmm11,%xmm9,%xmm1
  1df1a7:	vfmadd231sd %xmm9,%xmm12,%xmm0
  1df1ac:	cmp    $0x1,%r10d
  1df1b0:	je     1df25a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1e9a>
  1df1b6:	vmovsd 0x8(%rcx,%rsi,8),%xmm5
  1df1bc:	vmovsd 0x8(%r14,%rax,8),%xmm9
  1df1c3:	vfmadd231sd %xmm9,%xmm5,%xmm7
  1df1c8:	vmovsd 0x8(%rdx,%rsi,8),%xmm10
  1df1ce:	vfmadd231sd %xmm9,%xmm10,%xmm8
  1df1d3:	vmovsd 0x8(%rbp,%rsi,8),%xmm11
  1df1d9:	vfmadd231sd %xmm9,%xmm11,%xmm4
  1df1de:	vmovsd 0x8(%r12,%rsi,8),%xmm12
  1df1e5:	vfmadd231sd %xmm9,%xmm12,%xmm6
  1df1ea:	vmovsd 0x8(%r13,%r9,8),%xmm9
  1df1f1:	vfmadd231sd %xmm5,%xmm9,%xmm3
  1df1f6:	vfmadd231sd %xmm10,%xmm9,%xmm2
  1df1fb:	vfmadd231sd %xmm11,%xmm9,%xmm1
  1df200:	vfmadd231sd %xmm9,%xmm12,%xmm0
  1df205:	cmp    $0x2,%r10d
  1df209:	je     1df25a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1e9a>
  1df20b:	vmovsd 0x10(%rcx,%rsi,8),%xmm5
  1df211:	vmovsd 0x10(%r14,%rax,8),%xmm9
  1df218:	vfmadd231sd %xmm9,%xmm5,%xmm7
  1df21d:	vmovsd 0x10(%rdx,%rsi,8),%xmm10
  1df223:	vfmadd231sd %xmm9,%xmm10,%xmm8
  1df228:	vmovsd 0x10(%rbp,%rsi,8),%xmm11
  1df22e:	vfmadd231sd %xmm9,%xmm11,%xmm4
  1df233:	vmovsd 0x10(%r12,%rsi,8),%xmm12
  1df23a:	vfmadd231sd %xmm9,%xmm12,%xmm6
  1df23f:	vmovsd 0x10(%r13,%r9,8),%xmm9
  1df246:	vfmadd231sd %xmm5,%xmm9,%xmm3
  1df24b:	vfmadd231sd %xmm10,%xmm9,%xmm2
  1df250:	vfmadd231sd %xmm11,%xmm9,%xmm1
  1df255:	vfmadd231sd %xmm9,%xmm12,%xmm0
  1df25a:	mov    %rbx,%r9
  1df25d:	mov    0x40(%rsp),%rax
  1df262:	lea    0x2(%rax),%rdi
  1df266:	jmp    1df26d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1ead>
  1df268:	mov    0x40(%rsp),%rax
  1df26d:	cmp    0x18(%rsp),%r9
  1df272:	jae    1dfdbb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29fb>
  1df278:	mov    %rax,%rbx
  1df27b:	mov    0x100(%rsp),%rax
  1df283:	mov    0x160(%rsp),%r10
  1df28b:	vmovsd %xmm7,(%rax,%r10,1)
  1df291:	vmovsd %xmm8,0x8(%rax,%r10,1)
  1df298:	cmp    0x68(%rsp),%rbx
  1df29d:	jae    1df2c6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1f06>
  1df29f:	inc    %r9
  1df2a2:	cmp    0x18(%rsp),%r9
  1df2a7:	jae    1dfe87 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2ac7>
  1df2ad:	shl    $0x4,%r9
  1df2b1:	mov    0x100(%rsp),%rax
  1df2b9:	vmovsd %xmm4,(%rax,%r9,1)
  1df2bf:	vmovsd %xmm6,0x8(%rax,%r9,1)
  1df2c6:	cmp    0x18(%rsp),%r15
  1df2cb:	jae    1dfdeb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a2b>
  1df2d1:	mov    0x100(%rsp),%rax
  1df2d9:	mov    0x150(%rsp),%r9
  1df2e1:	vmovsd %xmm3,(%rax,%r9,1)
  1df2e7:	vmovsd %xmm2,0x8(%rax,%r9,1)
  1df2ee:	cmp    0x68(%rsp),%rdi
  1df2f3:	jae    1de56a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x11aa>
  1df2f9:	inc    %r15
  1df2fc:	cmp    0x18(%rsp),%r15
  1df301:	jae    1dfe9f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2adf>
  1df307:	shl    $0x4,%r15
  1df30b:	mov    0x100(%rsp),%rax
  1df313:	vmovsd %xmm1,(%rax,%r15,1)
  1df319:	vmovsd %xmm0,0x8(%rax,%r15,1)
  1df320:	jmp    1de56a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x11aa>
  1df325:	vxorpd %xmm8,%xmm8,%xmm8
  1df32a:	vxorpd %xmm4,%xmm4,%xmm4
  1df32e:	vxorpd %xmm5,%xmm5,%xmm5
  1df332:	vxorpd %xmm6,%xmm6,%xmm6
  1df336:	vxorpd %xmm7,%xmm7,%xmm7
  1df33a:	vxorpd %xmm2,%xmm2,%xmm2
  1df33e:	vxorpd %xmm3,%xmm3,%xmm3
  1df342:	vxorpd %xmm1,%xmm1,%xmm1
  1df346:	mov    0x38(%rsp),%rsi
  1df34b:	jmp    1df48e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x20ce>
  1df350:	mov    %r10,%rax
  1df353:	movabs $0x1ffffffffffffffe,%r8
  1df35d:	and    %r8,%rax
  1df360:	vxorpd %xmm1,%xmm1,%xmm1
  1df364:	mov    $0x60,%ebx
  1df369:	xor    %r9d,%r9d
  1df36c:	vxorpd %xmm3,%xmm3,%xmm3
  1df370:	vxorpd %xmm2,%xmm2,%xmm2
  1df374:	vxorpd %xmm7,%xmm7,%xmm7
  1df378:	vxorpd %xmm6,%xmm6,%xmm6
  1df37c:	vxorpd %xmm5,%xmm5,%xmm5
  1df380:	vxorpd %xmm4,%xmm4,%xmm4
  1df384:	vxorpd %xmm8,%xmm8,%xmm8
  1df389:	mov    %r15,%r8
  1df38c:	mov    0x30(%rsp),%r15
  1df391:	mov    0x20(%rsp),%r14
  1df396:	vmovupd -0x60(%r11,%rbx,1),%ymm9
  1df39d:	vmovupd -0x40(%r11,%rbx,1),%ymm10
  1df3a4:	vmovupd -0x20(%r11,%rbx,1),%ymm11
  1df3ab:	vfmadd231pd -0x60(%rsi,%rbx,1),%ymm9,%ymm4
  1df3b2:	vfmadd231pd -0x60(%r15,%rbx,1),%ymm9,%ymm5
  1df3b9:	vfmadd231pd -0x60(%r8,%rbx,1),%ymm9,%ymm6
  1df3c0:	vfmadd231pd -0x60(%r14,%rbx,1),%ymm9,%ymm7
  1df3c7:	vfmadd231pd -0x40(%rsi,%rbx,1),%ymm10,%ymm2
  1df3ce:	vfmadd231pd -0x40(%r15,%rbx,1),%ymm10,%ymm3
  1df3d5:	vfmadd231pd -0x40(%r8,%rbx,1),%ymm10,%ymm1
  1df3dc:	vfmadd231pd -0x40(%r14,%rbx,1),%ymm10,%ymm8
  1df3e3:	vmovupd (%r11,%rbx,1),%ymm9
  1df3e9:	add    $0x2,%r9
  1df3ed:	vfmadd231pd -0x20(%rsi,%rbx,1),%ymm11,%ymm4
  1df3f4:	vfmadd231pd -0x20(%r15,%rbx,1),%ymm11,%ymm5
  1df3fb:	vfmadd231pd -0x20(%r8,%rbx,1),%ymm11,%ymm6
  1df402:	vfmadd231pd -0x20(%r14,%rbx,1),%ymm11,%ymm7
  1df409:	vfmadd231pd (%rsi,%rbx,1),%ymm9,%ymm2
  1df40f:	vfmadd231pd (%r15,%rbx,1),%ymm9,%ymm3
  1df415:	vfmadd231pd (%r8,%rbx,1),%ymm9,%ymm1
  1df41b:	vfmadd231pd (%r14,%rbx,1),%ymm9,%ymm8
  1df421:	sub    $0xffffffffffffff80,%rbx
  1df425:	cmp    %r9,%rax
  1df428:	jne    1df396 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x1fd6>
  1df42e:	test   $0x1,%r10b
  1df432:	mov    0x108(%rsp),%rbx
  1df43a:	mov    %r8,%r15
  1df43d:	je     1df48e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x20ce>
  1df43f:	shl    $0x6,%r9
  1df443:	vmovupd (%r11,%r9,1),%ymm9
  1df449:	vmovupd 0x20(%r11,%r9,1),%ymm10
  1df450:	vfmadd231pd (%rsi,%r9,1),%ymm9,%ymm4
  1df456:	mov    0x30(%rsp),%rax
  1df45b:	vfmadd231pd (%rax,%r9,1),%ymm9,%ymm5
  1df461:	vfmadd231pd (%r15,%r9,1),%ymm9,%ymm6
  1df467:	mov    0x20(%rsp),%r8
  1df46c:	vfmadd231pd (%r8,%r9,1),%ymm9,%ymm7
  1df472:	vfmadd231pd 0x20(%rsi,%r9,1),%ymm10,%ymm2
  1df479:	vfmadd231pd 0x20(%rax,%r9,1),%ymm10,%ymm3
  1df480:	vfmadd231pd 0x20(%r15,%r9,1),%ymm10,%ymm1
  1df487:	vfmadd231pd 0x20(%r8,%r9,1),%ymm10,%ymm8
  1df48e:	add    %r11,%r12
  1df491:	testb  $0x4,0x28(%rsp)
  1df496:	mov    %r12,0x160(%rsp)
  1df49e:	je     1df554 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2194>
  1df4a4:	testb  $0x1,0xb0(%rsp)
  1df4ac:	mov    0x20(%rsp),%rax
  1df4b1:	je     1dfd05 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2945>
  1df4b7:	test   $0x4,%r13b
  1df4bb:	mov    0x50(%rsp),%rdi
  1df4c0:	je     1dfd19 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2959>
  1df4c6:	test   $0x4,%dil
  1df4ca:	je     1dfef9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b39>
  1df4d0:	testb  $0x4,0x78(%rsp)
  1df4d5:	je     1dff0d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b4d>
  1df4db:	testb  $0x4,0x70(%rsp)
  1df4e0:	je     1dff21 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b61>
  1df4e6:	movabs $0x3fffffffffffffe,%r8
  1df4f0:	mov    0x178(%rsp),%rdi
  1df4f8:	and    %r8,%rdi
  1df4fb:	mov    0x1b8(%rsp),%r9
  1df503:	and    %r8,%r9
  1df506:	mov    0x1b0(%rsp),%r10
  1df50e:	and    %r8,%r10
  1df511:	mov    0x1a8(%rsp),%r14
  1df519:	and    %r8,%r14
  1df51c:	shl    $0x5,%rdi
  1df520:	shl    $0x5,%r9
  1df524:	shl    $0x5,%r10
  1df528:	shl    $0x5,%r14
  1df52c:	add    %rsi,%rdi
  1df52f:	add    0x30(%rsp),%r9
  1df534:	add    %r15,%r10
  1df537:	add    %rax,%r14
  1df53a:	vmovupd (%r12),%ymm9
  1df540:	vfmadd231pd (%rdi),%ymm9,%ymm4
  1df545:	vfmadd231pd (%r9),%ymm9,%ymm5
  1df54a:	vfmadd231pd (%r10),%ymm9,%ymm6
  1df54f:	vfmadd231pd (%r14),%ymm9,%ymm7
  1df554:	vaddpd %ymm7,%ymm8,%ymm7
  1df558:	vaddpd %ymm6,%ymm1,%ymm6
  1df55c:	vaddpd %ymm5,%ymm3,%ymm3
  1df560:	vaddpd %ymm4,%ymm2,%ymm1
  1df564:	vextractf128 $0x1,%ymm1,%xmm2
  1df56a:	vaddpd %xmm2,%xmm1,%xmm1
  1df56e:	vshufpd $0x1,%xmm1,%xmm1,%xmm2
  1df573:	vaddsd %xmm2,%xmm1,%xmm1
  1df577:	vextractf128 $0x1,%ymm3,%xmm2
  1df57d:	vaddpd %xmm2,%xmm3,%xmm2
  1df581:	vshufpd $0x1,%xmm2,%xmm2,%xmm3
  1df586:	vaddsd %xmm3,%xmm2,%xmm2
  1df58a:	vextractf128 $0x1,%ymm6,%xmm3
  1df590:	vaddpd %xmm3,%xmm6,%xmm3
  1df594:	vshufpd $0x1,%xmm3,%xmm3,%xmm4
  1df599:	vaddsd %xmm4,%xmm3,%xmm3
  1df59d:	vextractf128 $0x1,%ymm7,%xmm4
  1df5a3:	vaddpd %xmm4,%xmm7,%xmm4
  1df5a7:	vshufpd $0x1,%xmm4,%xmm4,%xmm5
  1df5ac:	vaddsd %xmm5,%xmm4,%xmm4
  1df5b0:	mov    0xb8(%rsp),%r9
  1df5b8:	test   %r9,%r9
  1df5bb:	mov    0x190(%rsp),%rdi
  1df5c3:	mov    0x188(%rsp),%r8
  1df5cb:	mov    0x180(%rsp),%r10
  1df5d3:	mov    0x1c0(%rsp),%r14
  1df5db:	je     1df803 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2443>
  1df5e1:	cmp    %rdi,%r8
  1df5e4:	mov    %rdi,%rax
  1df5e7:	cmovb  %r8,%rax
  1df5eb:	cmp    %r10,%rax
  1df5ee:	cmovae %r10,%rax
  1df5f2:	dec    %r9
  1df5f5:	cmp    %r14,%rax
  1df5f8:	cmovae %r14,%rax
  1df5fc:	cmp    %rax,%r9
  1df5ff:	cmovb  %r9,%rax
  1df603:	cmp    %rax,%rdi
  1df606:	je     1dfe33 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a73>
  1df60c:	cmp    %rax,%r8
  1df60f:	je     1dfeb7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2af7>
  1df615:	cmp    %rax,%r10
  1df618:	je     1dfecd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b0d>
  1df61e:	cmp    %rax,%r14
  1df621:	je     1dfee3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b23>
  1df627:	mov    0xb8(%rsp),%rax
  1df62f:	mov    %eax,%r9d
  1df632:	and    $0x3,%r9d
  1df636:	cmp    $0x4,%rax
  1df63a:	jae    1df64e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x228e>
  1df63c:	xor    %r12d,%r12d
  1df63f:	mov    0x30(%rsp),%r8
  1df644:	mov    0x20(%rsp),%r14
  1df649:	jmp    1df775 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x23b5>
  1df64e:	and    $0xfffffffffffffffc,%rax
  1df652:	mov    %rsi,%r14
  1df655:	mov    %r13,%rsi
  1df658:	mov    %r13,%r10
  1df65b:	movabs $0xffffffffffffffc,%r13
  1df665:	and    %r13,%r10
  1df668:	lea    (%r14,%r10,8),%r10
  1df66c:	add    $0x18,%r10
  1df670:	mov    0x140(%rsp),%rdi
  1df678:	lea    (%r11,%rdi,8),%rbx
  1df67c:	add    $0x18,%rbx
  1df680:	mov    0x50(%rsp),%r14
  1df685:	and    %r13,%r14
  1df688:	mov    %r15,%r12
  1df68b:	mov    0x30(%rsp),%r15
  1df690:	lea    (%r15,%r14,8),%r14
  1df694:	add    $0x18,%r14
  1df698:	mov    0x78(%rsp),%r15
  1df69d:	and    %r13,%r15
  1df6a0:	lea    (%r12,%r15,8),%r15
  1df6a4:	add    $0x18,%r15
  1df6a8:	mov    0x70(%rsp),%r12
  1df6ad:	and    %r13,%r12
  1df6b0:	mov    0x20(%rsp),%r13
  1df6b5:	lea    0x18(%r13,%r12,8),%r13
  1df6ba:	xor    %r12d,%r12d
  1df6bd:	vmovsd -0x18(%rbx,%r12,8),%xmm5
  1df6c4:	vmovsd -0x10(%rbx,%r12,8),%xmm6
  1df6cb:	vfmadd231sd -0x18(%r10,%r12,8),%xmm5,%xmm1
  1df6d2:	vfmadd231sd -0x18(%r14,%r12,8),%xmm5,%xmm2
  1df6d9:	vfmadd231sd -0x18(%r15,%r12,8),%xmm5,%xmm3
  1df6e0:	vfmadd231sd -0x18(%r13,%r12,8),%xmm5,%xmm4
  1df6e7:	vfmadd231sd -0x10(%r10,%r12,8),%xmm6,%xmm1
  1df6ee:	vfmadd231sd -0x10(%r14,%r12,8),%xmm6,%xmm2
  1df6f5:	vfmadd231sd -0x10(%r15,%r12,8),%xmm6,%xmm3
  1df6fc:	vfmadd231sd -0x10(%r13,%r12,8),%xmm6,%xmm4
  1df703:	vmovsd -0x8(%rbx,%r12,8),%xmm5
  1df70a:	vfmadd231sd -0x8(%r10,%r12,8),%xmm5,%xmm1
  1df711:	vfmadd231sd -0x8(%r14,%r12,8),%xmm5,%xmm2
  1df718:	vfmadd231sd -0x8(%r15,%r12,8),%xmm5,%xmm3
  1df71f:	vfmadd231sd -0x8(%r13,%r12,8),%xmm5,%xmm4
  1df726:	vmovsd (%rbx,%r12,8),%xmm5
  1df72c:	vfmadd231sd (%r10,%r12,8),%xmm5,%xmm1
  1df732:	vfmadd231sd (%r14,%r12,8),%xmm5,%xmm2
  1df738:	vfmadd231sd (%r15,%r12,8),%xmm5,%xmm3
  1df73e:	vfmadd231sd 0x0(%r13,%r12,8),%xmm5,%xmm4
  1df745:	add    $0x4,%r12
  1df749:	cmp    %r12,%rax
  1df74c:	jne    1df6bd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x22fd>
  1df752:	test   %r9,%r9
  1df755:	mov    0x108(%rsp),%rbx
  1df75d:	mov    %rsi,%r13
  1df760:	mov    0x30(%rsp),%r8
  1df765:	mov    0x60(%rsp),%r15
  1df76a:	mov    0x20(%rsp),%r14
  1df76f:	je     1df803 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2443>
  1df775:	movabs $0xffffffffffffffc,%rsi
  1df77f:	mov    0x70(%rsp),%rax
  1df784:	and    %rsi,%rax
  1df787:	lea    0x0(,%r12,8),%r10
  1df78f:	lea    (%r10,%rax,8),%rax
  1df793:	add    %rax,%r14
  1df796:	mov    0x78(%rsp),%rax
  1df79b:	and    %rsi,%rax
  1df79e:	lea    (%r10,%rax,8),%rax
  1df7a2:	add    %rax,%r15
  1df7a5:	mov    0x50(%rsp),%rax
  1df7aa:	and    %rsi,%rax
  1df7ad:	lea    (%r10,%rax,8),%rax
  1df7b1:	add    %rax,%r8
  1df7b4:	mov    0x140(%rsp),%rax
  1df7bc:	lea    0x0(,%rax,8),%rax
  1df7c4:	lea    (%rax,%r12,8),%rax
  1df7c8:	add    %r11,%rax
  1df7cb:	and    %rsi,%r13
  1df7ce:	mov    0x38(%rsp),%rsi
  1df7d3:	lea    (%r10,%r13,8),%r10
  1df7d7:	add    %r10,%rsi
  1df7da:	xor    %r10d,%r10d
  1df7dd:	vmovsd (%rax,%r10,8),%xmm5
  1df7e3:	vfmadd231sd (%rsi,%r10,8),%xmm5,%xmm1
  1df7e9:	vfmadd231sd (%r8,%r10,8),%xmm5,%xmm2
  1df7ef:	vfmadd231sd (%r15,%r10,8),%xmm5,%xmm3
  1df7f5:	vfmadd231sd (%r14,%r10,8),%xmm5,%xmm4
  1df7fb:	inc    %r10
  1df7fe:	cmp    %r10,%r9
  1df801:	jne    1df7dd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x241d>
  1df803:	mov    %rbx,%rax
  1df806:	shr    $0x3,%rax
  1df80a:	mov    0x48(%rsp),%rsi
  1df80f:	cmp    %rax,%rsi
  1df812:	cmovb  %rsi,%rax
  1df816:	mov    0x88(%rsp),%rsi
  1df81e:	cmp    %rax,%rsi
  1df821:	cmovb  %rsi,%rax
  1df825:	test   %rax,%rax
  1df828:	je     1df884 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x24c4>
  1df82a:	cmp    $0x1,%rax
  1df82e:	mov    0x18(%rsp),%rsi
  1df833:	mov    0x8(%rsp),%r10
  1df838:	mov    0xc0(%rsp),%r12
  1df840:	movabs $0x3fffffffffffffe,%r9
  1df84a:	jne    1df8d2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2512>
  1df850:	vxorpd %xmm5,%xmm5,%xmm5
  1df854:	xor    %edi,%edi
  1df856:	vxorpd %xmm7,%xmm7,%xmm7
  1df85a:	vxorpd %xmm6,%xmm6,%xmm6
  1df85e:	vxorpd %xmm11,%xmm11,%xmm11
  1df863:	vxorpd %xmm10,%xmm10,%xmm10
  1df868:	vxorpd %xmm9,%xmm9,%xmm9
  1df86d:	vxorpd %xmm8,%xmm8,%xmm8
  1df872:	vxorpd %xmm12,%xmm12,%xmm12
  1df877:	mov    0xb8(%rsp),%r14
  1df87f:	jmp    1df9b1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x25f1>
  1df884:	vxorpd %xmm12,%xmm12,%xmm12
  1df889:	vxorpd %xmm8,%xmm8,%xmm8
  1df88e:	vxorpd %xmm9,%xmm9,%xmm9
  1df893:	vxorpd %xmm10,%xmm10,%xmm10
  1df898:	vxorpd %xmm11,%xmm11,%xmm11
  1df89d:	vxorpd %xmm6,%xmm6,%xmm6
  1df8a1:	vxorpd %xmm7,%xmm7,%xmm7
  1df8a5:	vxorpd %xmm5,%xmm5,%xmm5
  1df8a9:	mov    0x18(%rsp),%rsi
  1df8ae:	mov    0x8(%rsp),%r10
  1df8b3:	mov    0xc0(%rsp),%r12
  1df8bb:	movabs $0x3fffffffffffffe,%r9
  1df8c5:	mov    0xb8(%rsp),%r14
  1df8cd:	jmp    1df9f7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2637>
  1df8d2:	movabs $0x1ffffffffffffffe,%r14
  1df8dc:	and    %rax,%r14
  1df8df:	vxorpd %xmm5,%xmm5,%xmm5
  1df8e3:	mov    $0x60,%r8d
  1df8e9:	xor    %edi,%edi
  1df8eb:	vxorpd %xmm7,%xmm7,%xmm7
  1df8ef:	vxorpd %xmm6,%xmm6,%xmm6
  1df8f3:	vxorpd %xmm11,%xmm11,%xmm11
  1df8f8:	vxorpd %xmm10,%xmm10,%xmm10
  1df8fd:	vxorpd %xmm9,%xmm9,%xmm9
  1df902:	vxorpd %xmm8,%xmm8,%xmm8
  1df907:	vxorpd %xmm12,%xmm12,%xmm12
  1df90c:	vmovupd -0x60(%r11,%r8,1),%ymm13
  1df913:	vmovupd -0x40(%r11,%r8,1),%ymm14
  1df91a:	vmovupd -0x20(%r11,%r8,1),%ymm15
  1df921:	vfmadd231pd -0x60(%rcx,%r8,1),%ymm13,%ymm8
  1df928:	vfmadd231pd -0x60(%rdx,%r8,1),%ymm13,%ymm9
  1df92f:	vfmadd231pd -0x60(%rbp,%r8,1),%ymm13,%ymm10
  1df936:	vfmadd231pd -0x60(%r12,%r8,1),%ymm13,%ymm11
  1df93d:	vfmadd231pd -0x40(%rcx,%r8,1),%ymm14,%ymm6
  1df944:	vfmadd231pd -0x40(%rdx,%r8,1),%ymm14,%ymm7
  1df94b:	vfmadd231pd -0x40(%rbp,%r8,1),%ymm14,%ymm5
  1df952:	vfmadd231pd -0x40(%r12,%r8,1),%ymm14,%ymm12
  1df959:	vmovupd (%r11,%r8,1),%ymm13
  1df95f:	add    $0x2,%rdi
  1df963:	vfmadd231pd -0x20(%rcx,%r8,1),%ymm15,%ymm8
  1df96a:	vfmadd231pd -0x20(%rdx,%r8,1),%ymm15,%ymm9
  1df971:	vfmadd231pd -0x20(%rbp,%r8,1),%ymm15,%ymm10
  1df978:	vfmadd231pd -0x20(%r12,%r8,1),%ymm15,%ymm11
  1df97f:	vfmadd231pd (%rcx,%r8,1),%ymm13,%ymm6
  1df985:	vfmadd231pd (%rdx,%r8,1),%ymm13,%ymm7
  1df98b:	vfmadd231pd 0x0(%rbp,%r8,1),%ymm13,%ymm5
  1df992:	vfmadd231pd (%r12,%r8,1),%ymm13,%ymm12
  1df998:	sub    $0xffffffffffffff80,%r8
  1df99c:	cmp    %rdi,%r14
  1df99f:	jne    1df90c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x254c>
  1df9a5:	test   $0x1,%al
  1df9a7:	mov    0xb8(%rsp),%r14
  1df9af:	je     1df9f7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2637>
  1df9b1:	shl    $0x6,%rdi
  1df9b5:	vmovupd (%r11,%rdi,1),%ymm13
  1df9bb:	vmovupd 0x20(%r11,%rdi,1),%ymm14
  1df9c2:	vfmadd231pd (%rcx,%rdi,1),%ymm13,%ymm8
  1df9c8:	vfmadd231pd (%rdx,%rdi,1),%ymm13,%ymm9
  1df9ce:	vfmadd231pd 0x0(%rbp,%rdi,1),%ymm13,%ymm10
  1df9d5:	vfmadd231pd (%r12,%rdi,1),%ymm13,%ymm11
  1df9db:	vfmadd231pd 0x20(%rcx,%rdi,1),%ymm14,%ymm6
  1df9e2:	vfmadd231pd 0x20(%rdx,%rdi,1),%ymm14,%ymm7
  1df9e9:	vfmadd231pd 0x20(%rbp,%rdi,1),%ymm14,%ymm5
  1df9f0:	vfmadd231pd 0x20(%r12,%rdi,1),%ymm14,%ymm12
  1df9f7:	testb  $0x4,0x28(%rsp)
  1df9fc:	je     1dfa53 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2693>
  1df9fe:	testb  $0x1,0xb0(%rsp)
  1dfa06:	je     1dfd05 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2945>
  1dfa0c:	test   $0x4,%bl
  1dfa0f:	je     1dfd19 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2959>
  1dfa15:	mov    %rbx,%rax
  1dfa18:	shr    $0x2,%rax
  1dfa1c:	and    %r9,%rax
  1dfa1f:	shl    $0x5,%rax
  1dfa23:	lea    (%rcx,%rax,1),%rdi
  1dfa27:	lea    (%rdx,%rax,1),%r8
  1dfa2b:	lea    (%rax,%rbp,1),%r9
  1dfa2f:	add    %r12,%rax
  1dfa32:	mov    0x160(%rsp),%r15
  1dfa3a:	vmovupd (%r15),%ymm13
  1dfa3f:	vfmadd231pd (%rdi),%ymm13,%ymm8
  1dfa44:	vfmadd231pd (%r8),%ymm13,%ymm9
  1dfa49:	vfmadd231pd (%r9),%ymm13,%ymm10
  1dfa4e:	vfmadd231pd (%rax),%ymm13,%ymm11
  1dfa53:	vaddpd %ymm11,%ymm12,%ymm11
  1dfa58:	vaddpd %ymm5,%ymm10,%ymm5
  1dfa5c:	vaddpd %ymm7,%ymm9,%ymm9
  1dfa60:	vaddpd %ymm6,%ymm8,%ymm6
  1dfa64:	vextractf128 $0x1,%ymm6,%xmm7
  1dfa6a:	vaddpd %xmm7,%xmm6,%xmm6
  1dfa6e:	vshufpd $0x1,%xmm6,%xmm6,%xmm7
  1dfa73:	vaddsd %xmm7,%xmm6,%xmm7
  1dfa77:	vextractf128 $0x1,%ymm9,%xmm6
  1dfa7d:	vaddpd %xmm6,%xmm9,%xmm6
  1dfa81:	vshufpd $0x1,%xmm6,%xmm6,%xmm8
  1dfa86:	vaddsd %xmm6,%xmm8,%xmm8
  1dfa8a:	vextractf128 $0x1,%ymm5,%xmm6
  1dfa90:	vaddpd %xmm6,%xmm5,%xmm5
  1dfa94:	vshufpd $0x1,%xmm5,%xmm5,%xmm6
  1dfa99:	vaddsd %xmm6,%xmm5,%xmm5
  1dfa9d:	vextractf128 $0x1,%ymm11,%xmm6
  1dfaa3:	vaddpd %xmm6,%xmm11,%xmm6
  1dfaa7:	vshufpd $0x1,%xmm6,%xmm6,%xmm9
  1dfaac:	vaddsd %xmm6,%xmm9,%xmm6
  1dfab0:	test   %r14,%r14
  1dfab3:	je     1dfb24 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2764>
  1dfab5:	mov    %ebx,%edi
  1dfab7:	and    $0x3,%edi
  1dfaba:	lea    -0x1(%r14),%rax
  1dfabe:	cmp    %rax,%rdi
  1dfac1:	jbe    1dfe33 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a73>
  1dfac7:	movabs $0xffffffffffffffc,%rax
  1dfad1:	and    %rax,%rbx
  1dfad4:	mov    0x140(%rsp),%rax
  1dfadc:	lea    (%r11,%rax,8),%rax
  1dfae0:	lea    (%rcx,%rbx,8),%rcx
  1dfae4:	lea    (%rdx,%rbx,8),%rdi
  1dfae8:	lea    0x0(,%rbx,8),%rdx
  1dfaf0:	add    %rbp,%rdx
  1dfaf3:	lea    (%r12,%rbx,8),%r9
  1dfaf7:	and    $0x3,%r14d
  1dfafb:	xor    %r8d,%r8d
  1dfafe:	vmovsd (%rax,%r8,8),%xmm9
  1dfb04:	vfmadd231sd (%rcx,%r8,8),%xmm9,%xmm7
  1dfb0a:	vfmadd231sd (%rdi,%r8,8),%xmm9,%xmm8
  1dfb10:	vfmadd231sd (%rdx,%r8,8),%xmm9,%xmm5
  1dfb16:	vfmadd231sd (%r9,%r8,8),%xmm9,%xmm6
  1dfb1c:	inc    %r8
  1dfb1f:	cmp    %r8,%r14
  1dfb22:	jne    1dfafe <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x273e>
  1dfb24:	mov    0x200(%rsp),%rdi
  1dfb2c:	and    $0xfffffffffffffffe,%rdi
  1dfb30:	lea    -0x2(%rdi),%rax
  1dfb34:	cmp    %rsi,%rax
  1dfb37:	jae    1dfe46 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a86>
  1dfb3d:	mov    %rax,%rcx
  1dfb40:	shl    $0x4,%rcx
  1dfb44:	mov    0x100(%rsp),%r8
  1dfb4c:	vmovsd %xmm7,(%r8,%rcx,1)
  1dfb52:	mov    0x130(%rsp),%rdx
  1dfb5a:	add    %rdi,%rdx
  1dfb5d:	add    $0xfffffffffffffffe,%rdx
  1dfb61:	vmovsd %xmm8,0x8(%r8,%rcx,1)
  1dfb68:	cmp    0x68(%rsp),%rdx
  1dfb6d:	jae    1dfbc1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2801>
  1dfb6f:	dec    %rdi
  1dfb72:	cmp    %rsi,%rdi
  1dfb75:	jae    1dff35 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b75>
  1dfb7b:	mov    %rdi,%rdx
  1dfb7e:	shl    $0x4,%rdx
  1dfb82:	vmovsd %xmm5,(%r8,%rdx,1)
  1dfb88:	vmovsd %xmm6,0x8(%r8,%rdx,1)
  1dfb8f:	cmp    %r10,%rax
  1dfb92:	jae    1dfe59 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a99>
  1dfb98:	mov    0xc8(%rsp),%rax
  1dfba0:	vmovsd %xmm1,(%rax,%rcx,1)
  1dfba5:	vmovsd %xmm2,0x8(%rax,%rcx,1)
  1dfbab:	cmp    %r10,%rdi
  1dfbae:	jae    1dff45 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2b85>
  1dfbb4:	mov    %rdi,%rax
  1dfbb7:	vmovapd %xmm3,%xmm1
  1dfbbb:	vmovapd %xmm4,%xmm2
  1dfbbf:	jmp    1dfbca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x280a>
  1dfbc1:	cmp    %r10,%rax
  1dfbc4:	jae    1dfe59 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2a99>
  1dfbca:	shl    $0x4,%rax
  1dfbce:	mov    0xc8(%rsp),%rcx
  1dfbd6:	vmovsd %xmm1,(%rcx,%rax,1)
  1dfbdb:	vmovsd %xmm2,0x8(%rcx,%rax,1)
  1dfbe1:	vxorpd %xmm1,%xmm1,%xmm1
  1dfbe5:	vpcmpgtq %ymm0,%ymm1,%ymm0
  1dfbea:	vpbroadcastq -0x1b994b(%rip),%ymm1        # 262a8 <anon.b31e052118a1e3e33257ee8439ce742b.121.llvm.16793108214940917747+0x4d8>
  1dfbf3:	vpand  %ymm1,%ymm0,%ymm0
  1dfbf7:	vextracti128 $0x1,%ymm0,%xmm1
  1dfbfd:	vminpd %xmm1,%xmm0,%xmm0
  1dfc01:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1dfc06:	vminsd %xmm1,%xmm0,%xmm0
  1dfc0a:	vxorpd %xmm1,%xmm1,%xmm1
  1dfc0e:	vucomisd %xmm1,%xmm0
  1dfc12:	seta   %al
  1dfc15:	and    0x7(%rsp),%al
  1dfc19:	jmp    1dfc50 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2890>
  1dfc1b:	mov    0xd8(%rsp),%rax
  1dfc23:	cmp    %rax,%rdi
  1dfc26:	jae    1dfd8b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29cb>
  1dfc2c:	cmp    0x58(%rsp),%rdi
  1dfc31:	jae    1dfda6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29e6>
  1dfc37:	inc    %rdi
  1dfc3a:	cmp    %rax,%rdi
  1dfc3d:	jae    1dfd70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x29b0>
  1dfc43:	cmp    0x58(%rsp),%rdi
  1dfc48:	jae    1dfd5b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x299b>
  1dfc4e:	xor    %eax,%eax
  1dfc50:	add    $0x238,%rsp
  1dfc57:	pop    %rbx
  1dfc58:	pop    %r12
  1dfc5a:	pop    %r13
  1dfc5c:	pop    %r14
  1dfc5e:	pop    %r15
  1dfc60:	pop    %rbp
  1dfc61:	vzeroupper
  1dfc64:	ret
  1dfc65:	mov    %r14,%r10
  1dfc68:	mov    0x50(%rsp),%rax
  1dfc6d:	mov    %rax,0x10(%rsp)
  1dfc72:	mov    0x108(%rsp),%rbx
  1dfc7a:	jmp    1dd6a5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, false, true, true>>>+0x2e5>
  1dfc7f:	lea    0x111d42(%rip),%rdx        # 2f19c8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x608>
  1dfc86:	mov    0xf0(%rsp),%rdi
  1dfc8e:	mov    0xd8(%rsp),%rsi
  1dfc96:	vzeroupper
  1dfc99:	call   *0x11d6a1(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfc9f:	lea    0x111d3a(%rip),%rdx        # 2f19e0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x620>
  1dfca6:	mov    0xe8(%rsp),%rdi
  1dfcae:	mov    0x58(%rsp),%rsi
  1dfcb3:	vzeroupper
  1dfcb6:	call   *0x11d684(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfcbc:	lea    0x1128a5(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1dfcc3:	mov    %rdi,%rsi
  1dfcc6:	mov    %r13,%rdi
  1dfcc9:	vzeroupper
  1dfccc:	call   *0x11d66e(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfcd2:	lea    0x11288f(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1dfcd9:	mov    %r13,%rdi
  1dfcdc:	mov    0x18(%rsp),%rsi
  1dfce1:	vzeroupper
  1dfce4:	call   *0x11d656(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfcea:	lea    0x11210f(%rip),%rdx        # 2f1e00 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa40>
  1dfcf1:	mov    0x1c8(%rsp),%rdi
  1dfcf9:	mov    %rdi,%rsi
  1dfcfc:	vzeroupper
  1dfcff:	call   *0x11d63b(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfd05:	lea    0x11207c(%rip),%rdx        # 2f1d88 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9c8>
  1dfd0c:	xor    %edi,%edi
  1dfd0e:	xor    %esi,%esi
  1dfd10:	vzeroupper
  1dfd13:	call   *0x11d627(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfd19:	lea    0x112080(%rip),%rdx        # 2f1da0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9e0>
  1dfd20:	xor    %edi,%edi
  1dfd22:	xor    %esi,%esi
  1dfd24:	vzeroupper
  1dfd27:	call   *0x11d613(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfd2d:	lea    0x11284c(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1dfd34:	mov    %rdi,%rsi
  1dfd37:	mov    %r13,%rdi
  1dfd3a:	vzeroupper
  1dfd3d:	call   *0x11d5fd(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfd43:	lea    0x112836(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1dfd4a:	mov    %rax,%rdi
  1dfd4d:	mov    0x18(%rsp),%rsi
  1dfd52:	vzeroupper
  1dfd55:	call   *0x11d5e5(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfd5b:	lea    0x111cde(%rip),%rdx        # 2f1a40 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x680>
  1dfd62:	mov    0x58(%rsp),%rsi
  1dfd67:	vzeroupper
  1dfd6a:	call   *0x11d5d0(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfd70:	lea    0x111cb1(%rip),%rdx        # 2f1a28 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x668>
  1dfd77:	mov    0xd8(%rsp),%rsi
  1dfd7f:	vzeroupper
  1dfd82:	call   *0x11d5b8(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfd88:	mov    %r8,%rdi
  1dfd8b:	lea    0x111c66(%rip),%rdx        # 2f19f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x638>
  1dfd92:	mov    0xd8(%rsp),%rsi
  1dfd9a:	vzeroupper
  1dfd9d:	call   *0x11d59d(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfda3:	mov    %r8,%rdi
  1dfda6:	lea    0x111c63(%rip),%rdx        # 2f1a10 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x650>
  1dfdad:	mov    0x58(%rsp),%rsi
  1dfdb2:	vzeroupper
  1dfdb5:	call   *0x11d585(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfdbb:	lea    0x1127a6(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1dfdc2:	mov    %r9,%rdi
  1dfdc5:	mov    0x18(%rsp),%rsi
  1dfdca:	vzeroupper
  1dfdcd:	call   *0x11d56d(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfdd3:	lea    0x11278e(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1dfdda:	mov    %r9,%rdi
  1dfddd:	mov    0x8(%rsp),%rsi
  1dfde2:	vzeroupper
  1dfde5:	call   *0x11d555(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfdeb:	lea    0x112776(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1dfdf2:	mov    %r15,%rdi
  1dfdf5:	mov    0x18(%rsp),%rsi
  1dfdfa:	vzeroupper
  1dfdfd:	call   *0x11d53d(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfe03:	lea    0x11275e(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1dfe0a:	mov    %r15,%rdi
  1dfe0d:	mov    0x8(%rsp),%rsi
  1dfe12:	vzeroupper
  1dfe15:	call   *0x11d525(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfe1b:	lea    0x11275e(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1dfe22:	mov    %rax,%rdi
  1dfe25:	mov    0x8(%rsp),%rsi
  1dfe2a:	vzeroupper
  1dfe2d:	call   *0x11d50d(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfe33:	lea    0x111fc6(%rip),%rdx        # 2f1e00 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa40>
  1dfe3a:	mov    %rdi,%rsi
  1dfe3d:	vzeroupper
  1dfe40:	call   *0x11d4fa(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfe46:	lea    0x11271b(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1dfe4d:	mov    %rax,%rdi
  1dfe50:	vzeroupper
  1dfe53:	call   *0x11d4e7(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfe59:	lea    0x112708(%rip),%rdx        # 2f2568 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1dfe60:	mov    %rax,%rdi
  1dfe63:	mov    %r10,%rsi
  1dfe66:	vzeroupper
  1dfe69:	call   *0x11d4d1(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfe6f:	lea    0x111e22(%rip),%rdx        # 2f1c98 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x8d8>
  1dfe76:	mov    0x10(%rsp),%rdi
  1dfe7b:	mov    %rdi,%rsi
  1dfe7e:	vzeroupper
  1dfe81:	call   *0x11d4b9(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfe87:	lea    0x1126f2(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1dfe8e:	mov    %r9,%rdi
  1dfe91:	mov    0x18(%rsp),%rsi
  1dfe96:	vzeroupper
  1dfe99:	call   *0x11d4a1(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfe9f:	lea    0x1126da(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1dfea6:	mov    %r15,%rdi
  1dfea9:	mov    0x18(%rsp),%rsi
  1dfeae:	vzeroupper
  1dfeb1:	call   *0x11d489(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfeb7:	lea    0x111f5a(%rip),%rdx        # 2f1e18 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa58>
  1dfebe:	mov    %r8,%rdi
  1dfec1:	mov    %r8,%rsi
  1dfec4:	vzeroupper
  1dfec7:	call   *0x11d473(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfecd:	lea    0x111f5c(%rip),%rdx        # 2f1e30 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa70>
  1dfed4:	mov    %r10,%rdi
  1dfed7:	mov    %r10,%rsi
  1dfeda:	vzeroupper
  1dfedd:	call   *0x11d45d(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfee3:	lea    0x111f5e(%rip),%rdx        # 2f1e48 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa88>
  1dfeea:	mov    %r14,%rdi
  1dfeed:	mov    %r14,%rsi
  1dfef0:	vzeroupper
  1dfef3:	call   *0x11d447(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dfef9:	lea    0x111eb8(%rip),%rdx        # 2f1db8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9f8>
  1dff00:	xor    %edi,%edi
  1dff02:	xor    %esi,%esi
  1dff04:	vzeroupper
  1dff07:	call   *0x11d433(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dff0d:	lea    0x111ebc(%rip),%rdx        # 2f1dd0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa10>
  1dff14:	xor    %edi,%edi
  1dff16:	xor    %esi,%esi
  1dff18:	vzeroupper
  1dff1b:	call   *0x11d41f(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dff21:	lea    0x111ec0(%rip),%rdx        # 2f1de8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa28>
  1dff28:	xor    %edi,%edi
  1dff2a:	xor    %esi,%esi
  1dff2c:	vzeroupper
  1dff2f:	call   *0x11d40b(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dff35:	lea    0x112644(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1dff3c:	vzeroupper
  1dff3f:	call   *0x11d3fb(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
  1dff45:	lea    0x112634(%rip),%rdx        # 2f2580 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1dff4c:	mov    %r10,%rsi
  1dff4f:	vzeroupper
  1dff52:	call   *0x11d3e8(%rip)        # 2fd340 <_DYNAMIC+0x2b8>
