
/tmp/rustsht-b3-route-times-20261102/target-parent/release/examples/ducc_spin1_full_transform_parity:     file format elf64-x86-64


Disassembly of section .text:

00000000001cfae0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>>:
  1cfae0:	55                   	push   %rbp
  1cfae1:	41 57                	push   %r15
  1cfae3:	41 56                	push   %r14
  1cfae5:	41 55                	push   %r13
  1cfae7:	41 54                	push   %r12
  1cfae9:	53                   	push   %rbx
  1cfaea:	48 81 ec 78 02 00 00 	sub    $0x278,%rsp
  1cfaf1:	48 8b 87 a0 00 00 00 	mov    0xa0(%rdi),%rax
  1cfaf8:	48 3b 87 b0 00 00 00 	cmp    0xb0(%rdi),%rax
  1cfaff:	0f 85 2c 2c 00 00    	jne    1d2731 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c51>
  1cfb05:	4c 8b 7f 10          	mov    0x10(%rdi),%r15
  1cfb09:	4c 8b 67 20          	mov    0x20(%rdi),%r12
  1cfb0d:	4c 8b 6f 50          	mov    0x50(%rdi),%r13
  1cfb11:	4c 8b 4f 60          	mov    0x60(%rdi),%r9
  1cfb15:	4c 8b 57 70          	mov    0x70(%rdi),%r10
  1cfb19:	4c 8b 9f 80 00 00 00 	mov    0x80(%rdi),%r11
  1cfb20:	48 8b 9f e0 00 00 00 	mov    0xe0(%rdi),%rbx
  1cfb27:	4c 8b 87 e8 00 00 00 	mov    0xe8(%rdi),%r8
  1cfb2e:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
  1cfb35:	48 31 c1             	xor    %rax,%rcx
  1cfb38:	4c 89 fa             	mov    %r15,%rdx
  1cfb3b:	48 31 c2             	xor    %rax,%rdx
  1cfb3e:	48 09 ca             	or     %rcx,%rdx
  1cfb41:	4c 89 e1             	mov    %r12,%rcx
  1cfb44:	48 31 c1             	xor    %rax,%rcx
  1cfb47:	4c 89 ee             	mov    %r13,%rsi
  1cfb4a:	48 31 c6             	xor    %rax,%rsi
  1cfb4d:	48 09 ce             	or     %rcx,%rsi
  1cfb50:	48 09 d6             	or     %rdx,%rsi
  1cfb53:	4c 89 c9             	mov    %r9,%rcx
  1cfb56:	48 31 c1             	xor    %rax,%rcx
  1cfb59:	4c 89 d2             	mov    %r10,%rdx
  1cfb5c:	48 31 c2             	xor    %rax,%rdx
  1cfb5f:	48 09 ca             	or     %rcx,%rdx
  1cfb62:	4c 89 d9             	mov    %r11,%rcx
  1cfb65:	48 31 c1             	xor    %rax,%rcx
  1cfb68:	48 09 d1             	or     %rdx,%rcx
  1cfb6b:	48 09 f1             	or     %rsi,%rcx
  1cfb6e:	48 85 db             	test   %rbx,%rbx
  1cfb71:	0f 95 c2             	setne  %dl
  1cfb74:	4c 31 c0             	xor    %r8,%rax
  1cfb77:	48 09 c8             	or     %rcx,%rax
  1cfb7a:	0f 94 c0             	sete   %al
  1cfb7d:	84 d0                	test   %dl,%al
  1cfb7f:	0f 84 ac 2b 00 00    	je     1d2731 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c51>
  1cfb85:	4c 39 87 f8 00 00 00 	cmp    %r8,0xf8(%rdi)
  1cfb8c:	0f 85 9f 2b 00 00    	jne    1d2731 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c51>
  1cfb92:	4c 39 87 08 01 00 00 	cmp    %r8,0x108(%rdi)
  1cfb99:	0f 85 92 2b 00 00    	jne    1d2731 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c51>
  1cfb9f:	4c 39 87 18 01 00 00 	cmp    %r8,0x118(%rdi)
  1cfba6:	0f 85 85 2b 00 00    	jne    1d2731 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c51>
  1cfbac:	4c 89 84 24 f8 00 00 	mov    %r8,0xf8(%rsp)
  1cfbb3:	00 
  1cfbb4:	4c 8b 87 c8 00 00 00 	mov    0xc8(%rdi),%r8
  1cfbbb:	48 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%rcx
  1cfbc2:	48 8b b7 28 01 00 00 	mov    0x128(%rdi),%rsi
  1cfbc9:	49 89 ce             	mov    %rcx,%r14
  1cfbcc:	4c 89 84 24 58 01 00 	mov    %r8,0x158(%rsp)
  1cfbd3:	00 
  1cfbd4:	4d 29 c6             	sub    %r8,%r14
  1cfbd7:	49 8d 46 01          	lea    0x1(%r14),%rax
  1cfbdb:	48 39 c6             	cmp    %rax,%rsi
  1cfbde:	0f 82 4d 2b 00 00    	jb     1d2731 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c51>
  1cfbe4:	48 89 fa             	mov    %rdi,%rdx
  1cfbe7:	4c 89 a4 24 18 01 00 	mov    %r12,0x118(%rsp)
  1cfbee:	00 
  1cfbef:	4c 89 bc 24 a8 00 00 	mov    %r15,0xa8(%rsp)
  1cfbf6:	00 
  1cfbf7:	48 89 74 24 68       	mov    %rsi,0x68(%rsp)
  1cfbfc:	4c 89 9c 24 80 00 00 	mov    %r11,0x80(%rsp)
  1cfc03:	00 
  1cfc04:	4c 89 94 24 88 00 00 	mov    %r10,0x88(%rsp)
  1cfc0b:	00 
  1cfc0c:	4c 89 4c 24 58       	mov    %r9,0x58(%rsp)
  1cfc11:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  1cfc16:	48 8b 82 d8 00 00 00 	mov    0xd8(%rdx),%rax
  1cfc1d:	4c 8b 62 18          	mov    0x18(%rdx),%r12
  1cfc21:	48 8b 4a 28          	mov    0x28(%rdx),%rcx
  1cfc25:	48 89 8c 24 00 02 00 	mov    %rcx,0x200(%rsp)
  1cfc2c:	00 
  1cfc2d:	48 8b 4a 30          	mov    0x30(%rdx),%rcx
  1cfc31:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  1cfc38:	00 
  1cfc39:	48 8b 4a 38          	mov    0x38(%rdx),%rcx
  1cfc3d:	48 89 8c 24 f8 01 00 	mov    %rcx,0x1f8(%rsp)
  1cfc44:	00 
  1cfc45:	48 8b 4a 40          	mov    0x40(%rdx),%rcx
  1cfc49:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  1cfc50:	00 
  1cfc51:	48 8b 4a 48          	mov    0x48(%rdx),%rcx
  1cfc55:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  1cfc5a:	48 8b 4a 58          	mov    0x58(%rdx),%rcx
  1cfc5e:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  1cfc63:	4c 8b 4a 68          	mov    0x68(%rdx),%r9
  1cfc67:	48 8b 4a 78          	mov    0x78(%rdx),%rcx
  1cfc6b:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  1cfc70:	4c 8b 9a 88 00 00 00 	mov    0x88(%rdx),%r11
  1cfc77:	49 83 c6 02          	add    $0x2,%r14
  1cfc7b:	4d 89 f7             	mov    %r14,%r15
  1cfc7e:	49 d1 ef             	shr    $1,%r15
  1cfc81:	31 c9                	xor    %ecx,%ecx
  1cfc83:	4c 89 ff             	mov    %r15,%rdi
  1cfc86:	48 83 ef 01          	sub    $0x1,%rdi
  1cfc8a:	48 0f 42 f9          	cmovb  %rcx,%rdi
  1cfc8e:	48 89 bc 24 f0 01 00 	mov    %rdi,0x1f0(%rsp)
  1cfc95:	00 
  1cfc96:	48 8b ba 90 00 00 00 	mov    0x90(%rdx),%rdi
  1cfc9d:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  1cfca2:	49 83 ef 02          	sub    $0x2,%r15
  1cfca6:	4c 0f 42 f9          	cmovb  %rcx,%r15
  1cfcaa:	48 8b 8a f0 00 00 00 	mov    0xf0(%rdx),%rcx
  1cfcb1:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  1cfcb8:	00 
  1cfcb9:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  1cfcbd:	c5 7d c2 f8 00       	vcmpeqpd %ymm0,%ymm0,%ymm15
  1cfcc2:	48 8b 8a 00 01 00 00 	mov    0x100(%rdx),%rcx
  1cfcc9:	48 8b aa 10 01 00 00 	mov    0x110(%rdx),%rbp
  1cfcd0:	48 8b ba 20 01 00 00 	mov    0x120(%rdx),%rdi
  1cfcd7:	48 89 bc 24 c0 00 00 	mov    %rdi,0xc0(%rsp)
  1cfcde:	00 
  1cfcdf:	48 8b ba 98 00 00 00 	mov    0x98(%rdx),%rdi
  1cfce6:	4c 8b 92 a8 00 00 00 	mov    0xa8(%rdx),%r10
  1cfced:	48 8b b2 b8 00 00 00 	mov    0xb8(%rdx),%rsi
  1cfcf4:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
  1cfcf9:	4c 89 bc 24 98 01 00 	mov    %r15,0x198(%rsp)
  1cfd00:	00 
  1cfd01:	4c 39 f8             	cmp    %r15,%rax
  1cfd04:	4c 89 9c 24 e8 00 00 	mov    %r11,0xe8(%rsp)
  1cfd0b:	00 
  1cfd0c:	4c 89 ac 24 d0 00 00 	mov    %r13,0xd0(%rsp)
  1cfd13:	00 
  1cfd14:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
  1cfd19:	48 89 8c 24 b8 00 00 	mov    %rcx,0xb8(%rsp)
  1cfd20:	00 
  1cfd21:	4c 89 a4 24 a0 00 00 	mov    %r12,0xa0(%rsp)
  1cfd28:	00 
  1cfd29:	0f 83 97 00 00 00    	jae    1cfdc6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2e6>
  1cfd2f:	48 8b 12             	mov    (%rdx),%rdx
  1cfd32:	c6 02 01             	movb   $0x1,(%rdx)
  1cfd35:	4c 89 e9             	mov    %r13,%rcx
  1cfd38:	48 c1 e9 02          	shr    $0x2,%rcx
  1cfd3c:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
  1cfd41:	48 c1 ea 02          	shr    $0x2,%rdx
  1cfd45:	4c 8b 8c 24 88 00 00 	mov    0x88(%rsp),%r9
  1cfd4c:	00 
  1cfd4d:	49 c1 e9 02          	shr    $0x2,%r9
  1cfd51:	4c 8b 9c 24 80 00 00 	mov    0x80(%rsp),%r11
  1cfd58:	00 
  1cfd59:	49 c1 eb 02          	shr    $0x2,%r11
  1cfd5d:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  1cfd64:	00 
  1cfd65:	49 89 f0             	mov    %rsi,%r8
  1cfd68:	49 c1 e8 02          	shr    $0x2,%r8
  1cfd6c:	49 89 cf             	mov    %rcx,%r15
  1cfd6f:	49 31 d7             	xor    %rdx,%r15
  1cfd72:	49 31 d1             	xor    %rdx,%r9
  1cfd75:	4d 09 f9             	or     %r15,%r9
  1cfd78:	49 31 d3             	xor    %rdx,%r11
  1cfd7b:	4c 39 c1             	cmp    %r8,%rcx
  1cfd7e:	4c 0f 42 c1          	cmovb  %rcx,%r8
  1cfd82:	4c 89 84 24 98 00 00 	mov    %r8,0x98(%rsp)
  1cfd89:	00 
  1cfd8a:	4d 09 cb             	or     %r9,%r11
  1cfd8d:	0f 84 f8 0d 00 00    	je     1d0b8b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x10ab>
  1cfd93:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
  1cfd9a:	00 
  1cfd9b:	48 39 c8             	cmp    %rcx,%rax
  1cfd9e:	0f 83 72 2b 00 00    	jae    1d2916 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2e36>
  1cfda4:	48 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%rsi
  1cfdab:	00 
  1cfdac:	48 39 f0             	cmp    %rsi,%rax
  1cfdaf:	0f 83 83 2b 00 00    	jae    1d2938 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2e58>
  1cfdb5:	48 ff c0             	inc    %rax
  1cfdb8:	48 39 c8             	cmp    %rcx,%rax
  1cfdbb:	0f 82 67 29 00 00    	jb     1d2728 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c48>
  1cfdc1:	e9 6f 2a 00 00       	jmp    1d2835 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d55>
  1cfdc6:	c6 44 24 07 01       	movb   $0x1,0x7(%rsp)
  1cfdcb:	4c 89 b4 24 d8 01 00 	mov    %r14,0x1d8(%rsp)
  1cfdd2:	00 
  1cfdd3:	4c 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%r9
  1cfdda:	00 
  1cfddb:	48 8b 94 24 f8 00 00 	mov    0xf8(%rsp),%rdx
  1cfde2:	00 
  1cfde3:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  1cfde8:	49 89 fd             	mov    %rdi,%r13
  1cfdeb:	48 89 c6             	mov    %rax,%rsi
  1cfdee:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  1cfdf3:	48 ba fe ff ff ff ff 	movabs $0x3fffffffffffffe,%rdx
  1cfdfa:	ff ff 03 
  1cfdfd:	48 3b b4 24 f0 01 00 	cmp    0x1f0(%rsp),%rsi
  1cfe04:	00 
  1cfe05:	48 89 6c 24 70       	mov    %rbp,0x70(%rsp)
  1cfe0a:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
  1cfe0f:	0f 83 98 0b 00 00    	jae    1d09ad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0xecd>
  1cfe15:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  1cfe1c:	00 
  1cfe1d:	49 89 c7             	mov    %rax,%r15
  1cfe20:	49 c1 ef 02          	shr    $0x2,%r15
  1cfe24:	89 c7                	mov    %eax,%edi
  1cfe26:	83 e7 03             	and    $0x3,%edi
  1cfe29:	48 89 bc 24 e8 01 00 	mov    %rdi,0x1e8(%rsp)
  1cfe30:	00 
  1cfe31:	48 89 c7             	mov    %rax,%rdi
  1cfe34:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
  1cfe39:	49 89 d1             	mov    %rdx,%r9
  1cfe3c:	48 ba fc ff ff ff ff 	movabs $0xffffffffffffffc,%rdx
  1cfe43:	ff ff 0f 
  1cfe46:	48 21 d7             	and    %rdx,%rdi
  1cfe49:	48 89 bc 24 48 02 00 	mov    %rdi,0x248(%rsp)
  1cfe50:	00 
  1cfe51:	48 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%rdi
  1cfe58:	00 
  1cfe59:	49 89 fe             	mov    %rdi,%r14
  1cfe5c:	49 c1 ee 02          	shr    $0x2,%r14
  1cfe60:	4c 89 b4 24 a0 01 00 	mov    %r14,0x1a0(%rsp)
  1cfe67:	00 
  1cfe68:	4d 21 cf             	and    %r9,%r15
  1cfe6b:	49 c1 e7 05          	shl    $0x5,%r15
  1cfe6f:	4a 8d 14 3b          	lea    (%rbx,%r15,1),%rdx
  1cfe73:	48 89 94 24 18 02 00 	mov    %rdx,0x218(%rsp)
  1cfe7a:	00 
  1cfe7b:	48 c1 e8 03          	shr    $0x3,%rax
  1cfe7f:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
  1cfe86:	00 
  1cfe87:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  1cfe8e:	00 
  1cfe8f:	4c 01 f8             	add    %r15,%rax
  1cfe92:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  1cfe99:	00 
  1cfe9a:	4a 8d 04 39          	lea    (%rcx,%r15,1),%rax
  1cfe9e:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  1cfea5:	00 
  1cfea6:	49 01 ef             	add    %rbp,%r15
  1cfea9:	4c 89 bc 24 20 02 00 	mov    %r15,0x220(%rsp)
  1cfeb0:	00 
  1cfeb1:	48 89 f8             	mov    %rdi,%rax
  1cfeb4:	48 c1 e8 03          	shr    $0x3,%rax
  1cfeb8:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  1cfebd:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  1cfec4:	00 
  1cfec5:	48 89 c2             	mov    %rax,%rdx
  1cfec8:	48 c1 ea 02          	shr    $0x2,%rdx
  1cfecc:	48 89 94 24 78 01 00 	mov    %rdx,0x178(%rsp)
  1cfed3:	00 
  1cfed4:	89 c2                	mov    %eax,%edx
  1cfed6:	83 e2 03             	and    $0x3,%edx
  1cfed9:	48 89 94 24 48 01 00 	mov    %rdx,0x148(%rsp)
  1cfee0:	00 
  1cfee1:	49 be fc ff ff ff ff 	movabs $0xffffffffffffffc,%r14
  1cfee8:	ff ff 0f 
  1cfeeb:	4c 21 f0             	and    %r14,%rax
  1cfeee:	48 89 84 24 40 02 00 	mov    %rax,0x240(%rsp)
  1cfef5:	00 
  1cfef6:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  1cfefb:	49 89 c1             	mov    %rax,%r9
  1cfefe:	49 c1 e9 02          	shr    $0x2,%r9
  1cff02:	89 c7                	mov    %eax,%edi
  1cff04:	83 e7 03             	and    $0x3,%edi
  1cff07:	48 89 bc 24 80 01 00 	mov    %rdi,0x180(%rsp)
  1cff0e:	00 
  1cff0f:	4c 21 f0             	and    %r14,%rax
  1cff12:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
  1cff19:	00 
  1cff1a:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  1cff21:	00 
  1cff22:	49 89 c3             	mov    %rax,%r11
  1cff25:	49 c1 eb 02          	shr    $0x2,%r11
  1cff29:	41 89 c7             	mov    %eax,%r15d
  1cff2c:	41 83 e7 03          	and    $0x3,%r15d
  1cff30:	4c 21 f0             	and    %r14,%rax
  1cff33:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
  1cff3a:	00 
  1cff3b:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  1cff42:	00 
  1cff43:	48 89 c2             	mov    %rax,%rdx
  1cff46:	48 c1 ea 02          	shr    $0x2,%rdx
  1cff4a:	89 c7                	mov    %eax,%edi
  1cff4c:	83 e7 03             	and    $0x3,%edi
  1cff4f:	4c 21 f0             	and    %r14,%rax
  1cff52:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
  1cff59:	00 
  1cff5a:	4c 8b b4 24 18 01 00 	mov    0x118(%rsp),%r14
  1cff61:	00 
  1cff62:	4c 89 f0             	mov    %r14,%rax
  1cff65:	49 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%r8
  1cff6c:	ff ff 0f 
  1cff6f:	4c 21 c0             	and    %r8,%rax
  1cff72:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  1cff77:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1cff7e:	00 
  1cff7f:	48 39 c6             	cmp    %rax,%rsi
  1cff82:	48 0f 47 c6          	cmova  %rsi,%rax
  1cff86:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  1cff8d:	00 
  1cff8e:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  1cff95:	00 
  1cff96:	48 39 c6             	cmp    %rax,%rsi
  1cff99:	48 0f 47 c6          	cmova  %rsi,%rax
  1cff9d:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  1cffa4:	00 
  1cffa5:	48 8b 84 24 78 01 00 	mov    0x178(%rsp),%rax
  1cffac:	00 
  1cffad:	49 39 c1             	cmp    %rax,%r9
  1cffb0:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
  1cffb5:	4c 89 8c 24 c0 01 00 	mov    %r9,0x1c0(%rsp)
  1cffbc:	00 
  1cffbd:	49 0f 42 c1          	cmovb  %r9,%rax
  1cffc1:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
  1cffc6:	49 39 c3             	cmp    %rax,%r11
  1cffc9:	4c 89 9c 24 b8 01 00 	mov    %r11,0x1b8(%rsp)
  1cffd0:	00 
  1cffd1:	49 0f 42 c3          	cmovb  %r11,%rax
  1cffd5:	48 39 c2             	cmp    %rax,%rdx
  1cffd8:	48 89 94 24 b0 01 00 	mov    %rdx,0x1b0(%rsp)
  1cffdf:	00 
  1cffe0:	48 0f 42 c2          	cmovb  %rdx,%rax
  1cffe4:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
  1cffeb:	00 
  1cffec:	4c 89 f0             	mov    %r14,%rax
  1cffef:	48 c1 e8 02          	shr    $0x2,%rax
  1cfff3:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  1cfffa:	00 
  1cfffb:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  1d0002:	00 
  1d0003:	48 8b 94 24 80 01 00 	mov    0x180(%rsp),%rdx
  1d000a:	00 
  1d000b:	48 39 c2             	cmp    %rax,%rdx
  1d000e:	48 0f 42 c2          	cmovb  %rdx,%rax
  1d0012:	49 39 c7             	cmp    %rax,%r15
  1d0015:	4c 89 bc 24 d0 01 00 	mov    %r15,0x1d0(%rsp)
  1d001c:	00 
  1d001d:	49 0f 42 c7          	cmovb  %r15,%rax
  1d0021:	48 39 c7             	cmp    %rax,%rdi
  1d0024:	48 89 bc 24 c8 01 00 	mov    %rdi,0x1c8(%rsp)
  1d002b:	00 
  1d002c:	48 0f 42 c7          	cmovb  %rdi,%rax
  1d0030:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  1d0037:	00 
  1d0038:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  1d003f:	00 
  1d0040:	83 e0 03             	and    $0x3,%eax
  1d0043:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  1d004a:	00 
  1d004b:	41 83 e6 03          	and    $0x3,%r14d
  1d004f:	4c 89 b4 24 18 01 00 	mov    %r14,0x118(%rsp)
  1d0056:	00 
  1d0057:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1d005b:	c4 e2 7d 19 1d 14 60 	vbroadcastsd -0x1a9fec(%rip),%ymm3        # 26078 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x3a8>
  1d0062:	e5 ff 
  1d0064:	c5 7d 29 f9          	vmovapd %ymm15,%ymm1
  1d0068:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  1d006d:	49 89 c7             	mov    %rax,%r15
  1d0070:	48 89 9c 24 00 01 00 	mov    %rbx,0x100(%rsp)
  1d0077:	00 
  1d0078:	eb 1e                	jmp    1d0098 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x5b8>
  1d007a:	c5 dd 54 c9          	vandpd %ymm1,%ymm4,%ymm1
  1d007e:	48 ff c6             	inc    %rsi
  1d0081:	4d 89 d5             	mov    %r10,%r13
  1d0084:	49 89 d2             	mov    %rdx,%r10
  1d0087:	49 89 ff             	mov    %rdi,%r15
  1d008a:	48 3b b4 24 f0 01 00 	cmp    0x1f0(%rsp),%rsi
  1d0091:	00 
  1d0092:	0f 83 f4 09 00 00    	jae    1d0a8c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0xfac>
  1d0098:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
  1d009d:	4c 89 e2             	mov    %r12,%rdx
  1d00a0:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  1d00a5:	4c 89 ff             	mov    %r15,%rdi
  1d00a8:	48 c1 ef 03          	shr    $0x3,%rdi
  1d00ac:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
  1d00b3:	00 
  1d00b4:	48 39 c7             	cmp    %rax,%rdi
  1d00b7:	48 0f 43 f8          	cmovae %rax,%rdi
  1d00bb:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  1d00c0:	48 39 f8             	cmp    %rdi,%rax
  1d00c3:	48 0f 42 f8          	cmovb  %rax,%rdi
  1d00c7:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1d00cc:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1d00d0:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1d00d5:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1d00da:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1d00df:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1d00e3:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1d00e7:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1d00eb:	48 85 ff             	test   %rdi,%rdi
  1d00ee:	4c 8b b4 24 90 00 00 	mov    0x90(%rsp),%r14
  1d00f5:	00 
  1d00f6:	0f 84 1c 01 00 00    	je     1d0218 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x738>
  1d00fc:	48 83 ff 01          	cmp    $0x1,%rdi
  1d0100:	75 07                	jne    1d0109 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x629>
  1d0102:	31 c0                	xor    %eax,%eax
  1d0104:	e9 c9 00 00 00       	jmp    1d01d2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x6f2>
  1d0109:	4d 89 fc             	mov    %r15,%r12
  1d010c:	49 89 f9             	mov    %rdi,%r9
  1d010f:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
  1d0116:	ff ff 1f 
  1d0119:	49 21 c1             	and    %rax,%r9
  1d011c:	41 bf 60 00 00 00    	mov    $0x60,%r15d
  1d0122:	31 c0                	xor    %eax,%eax
  1d0124:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1d012b:	00 00 00 00 00 
  1d0130:	c4 81 7d 10 44 3a a0 	vmovupd -0x60(%r10,%r15,1),%ymm0
  1d0137:	c4 01 7d 10 64 3a c0 	vmovupd -0x40(%r10,%r15,1),%ymm12
  1d013e:	c4 01 7d 10 6c 3a e0 	vmovupd -0x20(%r10,%r15,1),%ymm13
  1d0145:	c4 a2 fd b8 7c 3b a0 	vfmadd231pd -0x60(%rbx,%r15,1),%ymm0,%ymm7
  1d014c:	c4 02 fd b8 44 3e a0 	vfmadd231pd -0x60(%r14,%r15,1),%ymm0,%ymm8
  1d0153:	c4 22 fd b8 4c 39 a0 	vfmadd231pd -0x60(%rcx,%r15,1),%ymm0,%ymm9
  1d015a:	c4 22 fd b8 54 3d a0 	vfmadd231pd -0x60(%rbp,%r15,1),%ymm0,%ymm10
  1d0161:	c4 a2 9d b8 6c 3b c0 	vfmadd231pd -0x40(%rbx,%r15,1),%ymm12,%ymm5
  1d0168:	c4 82 9d b8 74 3e c0 	vfmadd231pd -0x40(%r14,%r15,1),%ymm12,%ymm6
  1d016f:	c4 a2 9d b8 64 39 c0 	vfmadd231pd -0x40(%rcx,%r15,1),%ymm12,%ymm4
  1d0176:	c4 22 9d b8 5c 3d c0 	vfmadd231pd -0x40(%rbp,%r15,1),%ymm12,%ymm11
  1d017d:	c4 81 7d 10 04 3a    	vmovupd (%r10,%r15,1),%ymm0
  1d0183:	48 83 c0 02          	add    $0x2,%rax
  1d0187:	c4 a2 95 b8 7c 3b e0 	vfmadd231pd -0x20(%rbx,%r15,1),%ymm13,%ymm7
  1d018e:	c4 02 95 b8 44 3e e0 	vfmadd231pd -0x20(%r14,%r15,1),%ymm13,%ymm8
  1d0195:	c4 22 95 b8 4c 39 e0 	vfmadd231pd -0x20(%rcx,%r15,1),%ymm13,%ymm9
  1d019c:	c4 22 95 b8 54 3d e0 	vfmadd231pd -0x20(%rbp,%r15,1),%ymm13,%ymm10
  1d01a3:	c4 a2 fd b8 2c 3b    	vfmadd231pd (%rbx,%r15,1),%ymm0,%ymm5
  1d01a9:	c4 82 fd b8 34 3e    	vfmadd231pd (%r14,%r15,1),%ymm0,%ymm6
  1d01af:	c4 a2 fd b8 24 39    	vfmadd231pd (%rcx,%r15,1),%ymm0,%ymm4
  1d01b5:	c4 22 fd b8 5c 3d 00 	vfmadd231pd 0x0(%rbp,%r15,1),%ymm0,%ymm11
  1d01bc:	49 83 ef 80          	sub    $0xffffffffffffff80,%r15
  1d01c0:	49 39 c1             	cmp    %rax,%r9
  1d01c3:	0f 85 67 ff ff ff    	jne    1d0130 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x650>
  1d01c9:	40 f6 c7 01          	test   $0x1,%dil
  1d01cd:	4d 89 e7             	mov    %r12,%r15
  1d01d0:	74 46                	je     1d0218 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x738>
  1d01d2:	48 c1 e0 06          	shl    $0x6,%rax
  1d01d6:	c4 c1 7d 10 04 02    	vmovupd (%r10,%rax,1),%ymm0
  1d01dc:	c4 41 7d 10 64 02 20 	vmovupd 0x20(%r10,%rax,1),%ymm12
  1d01e3:	c4 e2 fd b8 3c 03    	vfmadd231pd (%rbx,%rax,1),%ymm0,%ymm7
  1d01e9:	c4 42 fd b8 04 06    	vfmadd231pd (%r14,%rax,1),%ymm0,%ymm8
  1d01ef:	c4 62 fd b8 0c 01    	vfmadd231pd (%rcx,%rax,1),%ymm0,%ymm9
  1d01f5:	c4 62 fd b8 54 05 00 	vfmadd231pd 0x0(%rbp,%rax,1),%ymm0,%ymm10
  1d01fc:	c4 e2 9d b8 6c 03 20 	vfmadd231pd 0x20(%rbx,%rax,1),%ymm12,%ymm5
  1d0203:	c4 c2 9d b8 74 06 20 	vfmadd231pd 0x20(%r14,%rax,1),%ymm12,%ymm6
  1d020a:	c4 e2 9d b8 64 01 20 	vfmadd231pd 0x20(%rcx,%rax,1),%ymm12,%ymm4
  1d0211:	c4 62 9d b8 5c 05 20 	vfmadd231pd 0x20(%rbp,%rax,1),%ymm12,%ymm11
  1d0218:	4d 89 f9             	mov    %r15,%r9
  1d021b:	49 c1 e9 02          	shr    $0x2,%r9
  1d021f:	41 f6 c7 04          	test   $0x4,%r15b
  1d0223:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  1d0228:	75 07                	jne    1d0231 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x751>
  1d022a:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  1d022f:	eb 76                	jmp    1d02a7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x7c7>
  1d0231:	f6 84 24 a8 00 00 00 	testb  $0x4,0xa8(%rsp)
  1d0238:	04 
  1d0239:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  1d023e:	0f 84 9d 25 00 00    	je     1d27e1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d01>
  1d0244:	f6 84 24 f8 00 00 00 	testb  $0x4,0xf8(%rsp)
  1d024b:	04 
  1d024c:	0f 84 a3 25 00 00    	je     1d27f5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d15>
  1d0252:	4d 89 fc             	mov    %r15,%r12
  1d0255:	4c 89 c8             	mov    %r9,%rax
  1d0258:	49 bf fe ff ff ff ff 	movabs $0x3fffffffffffffe,%r15
  1d025f:	ff ff 03 
  1d0262:	4c 21 f8             	and    %r15,%rax
  1d0265:	48 c1 e0 05          	shl    $0x5,%rax
  1d0269:	4c 01 d0             	add    %r10,%rax
  1d026c:	c5 fd 10 00          	vmovupd (%rax),%ymm0
  1d0270:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
  1d0277:	00 
  1d0278:	c4 e2 fd b8 38       	vfmadd231pd (%rax),%ymm0,%ymm7
  1d027d:	48 8b 84 24 10 02 00 	mov    0x210(%rsp),%rax
  1d0284:	00 
  1d0285:	c4 62 fd b8 00       	vfmadd231pd (%rax),%ymm0,%ymm8
  1d028a:	48 8b 84 24 08 02 00 	mov    0x208(%rsp),%rax
  1d0291:	00 
  1d0292:	c4 62 fd b8 08       	vfmadd231pd (%rax),%ymm0,%ymm9
  1d0297:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
  1d029e:	00 
  1d029f:	c4 62 fd b8 10       	vfmadd231pd (%rax),%ymm0,%ymm10
  1d02a4:	4d 89 e7             	mov    %r12,%r15
  1d02a7:	c4 c1 25 58 c2       	vaddpd %ymm10,%ymm11,%ymm0
  1d02ac:	c5 b5 58 e4          	vaddpd %ymm4,%ymm9,%ymm4
  1d02b0:	c5 bd 58 f6          	vaddpd %ymm6,%ymm8,%ymm6
  1d02b4:	c5 d5 58 ef          	vaddpd %ymm7,%ymm5,%ymm5
  1d02b8:	45 89 fc             	mov    %r15d,%r12d
  1d02bb:	41 83 e4 03          	and    $0x3,%r12d
  1d02bf:	4d 89 fd             	mov    %r15,%r13
  1d02c2:	48 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%rax
  1d02c9:	ff ff 0f 
  1d02cc:	49 21 c5             	and    %rax,%r13
  1d02cf:	c4 e3 7d 19 ef 01    	vextractf128 $0x1,%ymm5,%xmm7
  1d02d5:	c5 d1 58 ef          	vaddpd %xmm7,%xmm5,%xmm5
  1d02d9:	c5 d1 c6 fd 01       	vshufpd $0x1,%xmm5,%xmm5,%xmm7
  1d02de:	c5 d3 58 ef          	vaddsd %xmm7,%xmm5,%xmm5
  1d02e2:	c4 e3 7d 19 f7 01    	vextractf128 $0x1,%ymm6,%xmm7
  1d02e8:	c5 c9 58 f7          	vaddpd %xmm7,%xmm6,%xmm6
  1d02ec:	c5 c9 c6 fe 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm7
  1d02f1:	c5 cb 58 ff          	vaddsd %xmm7,%xmm6,%xmm7
  1d02f5:	c4 e3 7d 19 e6 01    	vextractf128 $0x1,%ymm4,%xmm6
  1d02fb:	c5 d9 58 e6          	vaddpd %xmm6,%xmm4,%xmm4
  1d02ff:	c5 d9 c6 f4 01       	vshufpd $0x1,%xmm4,%xmm4,%xmm6
  1d0304:	c5 db 58 e6          	vaddsd %xmm6,%xmm4,%xmm4
  1d0308:	c4 e3 7d 19 c6 01    	vextractf128 $0x1,%ymm0,%xmm6
  1d030e:	c5 f9 58 c6          	vaddpd %xmm6,%xmm0,%xmm0
  1d0312:	c5 f9 c6 f0 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm6
  1d0317:	c5 fb 58 f6          	vaddsd %xmm6,%xmm0,%xmm6
  1d031b:	4d 85 e4             	test   %r12,%r12
  1d031e:	4c 89 ac 24 20 01 00 	mov    %r13,0x120(%rsp)
  1d0325:	00 
  1d0326:	0f 84 8b 00 00 00    	je     1d03b7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x8d7>
  1d032c:	41 8d 44 24 ff       	lea    -0x1(%r12),%eax
  1d0331:	39 84 24 e8 01 00 00 	cmp    %eax,0x1e8(%rsp)
  1d0338:	0f 86 88 24 00 00    	jbe    1d27c6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2ce6>
  1d033e:	c4 81 7b 10 04 ea    	vmovsd (%r10,%r13,8),%xmm0
  1d0344:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
  1d034b:	00 
  1d034c:	c4 e2 f9 b9 2c c3    	vfmadd231sd (%rbx,%rax,8),%xmm0,%xmm5
  1d0352:	c4 c2 f9 b9 3c c6    	vfmadd231sd (%r14,%rax,8),%xmm0,%xmm7
  1d0358:	c4 e2 f9 b9 24 c1    	vfmadd231sd (%rcx,%rax,8),%xmm0,%xmm4
  1d035e:	c4 e2 f9 b9 74 c5 00 	vfmadd231sd 0x0(%rbp,%rax,8),%xmm0,%xmm6
  1d0365:	41 83 fc 01          	cmp    $0x1,%r12d
  1d0369:	74 4c                	je     1d03b7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x8d7>
  1d036b:	c4 81 7b 10 44 ea 08 	vmovsd 0x8(%r10,%r13,8),%xmm0
  1d0372:	c4 e2 f9 b9 6c c3 08 	vfmadd231sd 0x8(%rbx,%rax,8),%xmm0,%xmm5
  1d0379:	c4 c2 f9 b9 7c c6 08 	vfmadd231sd 0x8(%r14,%rax,8),%xmm0,%xmm7
  1d0380:	c4 e2 f9 b9 64 c1 08 	vfmadd231sd 0x8(%rcx,%rax,8),%xmm0,%xmm4
  1d0387:	c4 e2 f9 b9 74 c5 08 	vfmadd231sd 0x8(%rbp,%rax,8),%xmm0,%xmm6
  1d038e:	41 83 fc 02          	cmp    $0x2,%r12d
  1d0392:	74 23                	je     1d03b7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x8d7>
  1d0394:	c4 81 7b 10 44 ea 10 	vmovsd 0x10(%r10,%r13,8),%xmm0
  1d039b:	c4 e2 f9 b9 6c c3 10 	vfmadd231sd 0x10(%rbx,%rax,8),%xmm0,%xmm5
  1d03a2:	c4 c2 f9 b9 7c c6 10 	vfmadd231sd 0x10(%r14,%rax,8),%xmm0,%xmm7
  1d03a9:	c4 e2 f9 b9 64 c1 10 	vfmadd231sd 0x10(%rcx,%rax,8),%xmm0,%xmm4
  1d03b0:	c4 e2 f9 b9 74 c5 10 	vfmadd231sd 0x10(%rbp,%rax,8),%xmm0,%xmm6
  1d03b7:	4c 89 bc 24 98 01 00 	mov    %r15,0x198(%rsp)
  1d03be:	00 
  1d03bf:	4c 8d 2c 36          	lea    (%rsi,%rsi,1),%r13
  1d03c3:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
  1d03c8:	49 39 ed             	cmp    %rbp,%r13
  1d03cb:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  1d03d0:	48 8b 5c 24 78       	mov    0x78(%rsp),%rbx
  1d03d5:	0f 83 d5 23 00 00    	jae    1d27b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2cd0>
  1d03db:	4d 89 ef             	mov    %r13,%r15
  1d03de:	49 c1 e7 04          	shl    $0x4,%r15
  1d03e2:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
  1d03e9:	00 
  1d03ea:	c4 81 7b 11 2c 3e    	vmovsd %xmm5,(%r14,%r15,1)
  1d03f0:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  1d03f7:	00 
  1d03f8:	48 8d 04 70          	lea    (%rax,%rsi,2),%rax
  1d03fc:	c4 81 7b 11 7c 3e 08 	vmovsd %xmm7,0x8(%r14,%r15,1)
  1d0403:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  1d040a:	00 
  1d040b:	4c 39 c0             	cmp    %r8,%rax
  1d040e:	4c 8b 74 24 38       	mov    0x38(%rsp),%r14
  1d0413:	73 26                	jae    1d043b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x95b>
  1d0415:	49 8d 45 01          	lea    0x1(%r13),%rax
  1d0419:	48 39 e8             	cmp    %rbp,%rax
  1d041c:	0f 83 fd 23 00 00    	jae    1d281f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d3f>
  1d0422:	48 c1 e0 04          	shl    $0x4,%rax
  1d0426:	4c 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%r8
  1d042d:	00 
  1d042e:	c4 c1 7b 11 24 00    	vmovsd %xmm4,(%r8,%rax,1)
  1d0434:	c4 c1 7b 11 74 00 08 	vmovsd %xmm6,0x8(%r8,%rax,1)
  1d043b:	48 3b b4 24 e0 00 00 	cmp    0xe0(%rsp),%rsi
  1d0442:	00 
  1d0443:	0f 84 11 23 00 00    	je     1d275a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c7a>
  1d0449:	48 3b b4 24 d8 00 00 	cmp    0xd8(%rsp),%rsi
  1d0450:	00 
  1d0451:	48 8b ac 24 18 01 00 	mov    0x118(%rsp),%rbp
  1d0458:	00 
  1d0459:	0f 84 1b 23 00 00    	je     1d277a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c9a>
  1d045f:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
  1d0464:	49 c1 eb 02          	shr    $0x2,%r11
  1d0468:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  1d046d:	48 c1 e8 02          	shr    $0x2,%rax
  1d0471:	4c 8b 84 24 08 01 00 	mov    0x108(%rsp),%r8
  1d0478:	00 
  1d0479:	4c 39 c0             	cmp    %r8,%rax
  1d047c:	49 0f 43 c0          	cmovae %r8,%rax
  1d0480:	49 39 c1             	cmp    %rax,%r9
  1d0483:	49 0f 42 c1          	cmovb  %r9,%rax
  1d0487:	4c 8b 8c 24 00 02 00 	mov    0x200(%rsp),%r9
  1d048e:	00 
  1d048f:	c4 c2 7d 19 34 f1    	vbroadcastsd (%r9,%rsi,8),%ymm6
  1d0495:	4c 8b 84 24 a0 01 00 	mov    0x1a0(%rsp),%r8
  1d049c:	00 
  1d049d:	49 39 c0             	cmp    %rax,%r8
  1d04a0:	49 0f 42 c0          	cmovb  %r8,%rax
  1d04a4:	4c 8b 8c 24 f8 01 00 	mov    0x1f8(%rsp),%r9
  1d04ab:	00 
  1d04ac:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
  1d04b1:	c4 c2 7d 19 2c f1    	vbroadcastsd (%r9,%rsi,8),%ymm5
  1d04b7:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
  1d04be:	00 
  1d04bf:	48 39 c6             	cmp    %rax,%rsi
  1d04c2:	48 0f 42 c6          	cmovb  %rsi,%rax
  1d04c6:	49 39 c3             	cmp    %rax,%r11
  1d04c9:	4c 89 9c 24 30 01 00 	mov    %r11,0x130(%rsp)
  1d04d0:	00 
  1d04d1:	49 0f 42 c3          	cmovb  %r11,%rax
  1d04d5:	48 85 c0             	test   %rax,%rax
  1d04d8:	0f 84 93 00 00 00    	je     1d0571 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0xa91>
  1d04de:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1d04e3:	45 31 c9             	xor    %r9d,%r9d
  1d04e6:	c5 7d 29 fc          	vmovapd %ymm15,%ymm4
  1d04ea:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  1d04ee:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1d04f2:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1d04f7:	4c 8b 9c 24 a0 00 00 	mov    0xa0(%rsp),%r11
  1d04fe:	00 
  1d04ff:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  1d0504:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1d0509:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  1d0510:	c4 01 7d 10 0c 0a    	vmovupd (%r10,%r9,1),%ymm9
  1d0516:	c4 02 b5 b8 04 0e    	vfmadd231pd (%r14,%r9,1),%ymm9,%ymm8
  1d051c:	c4 a2 b5 b8 3c 0f    	vfmadd231pd (%rdi,%r9,1),%ymm9,%ymm7
  1d0522:	c4 a2 b5 b8 04 0e    	vfmadd231pd (%rsi,%r9,1),%ymm9,%ymm0
  1d0528:	c4 22 b5 b8 14 09    	vfmadd231pd (%rcx,%r9,1),%ymm9,%ymm10
  1d052e:	c4 01 7d 10 1c 0b    	vmovupd (%r11,%r9,1),%ymm11
  1d0534:	c4 62 cd a8 dd       	vfmadd213pd %ymm5,%ymm6,%ymm11
  1d0539:	c4 02 b5 a8 1c 08    	vfmadd213pd (%r8,%r9,1),%ymm9,%ymm11
  1d053f:	c4 21 7d 11 1c 0a    	vmovupd %ymm11,(%rdx,%r9,1)
  1d0545:	c4 62 7d 19 0d 52 5c 	vbroadcastsd -0x1aa3ae(%rip),%ymm9        # 261a0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x4d0>
  1d054c:	e5 ff 
  1d054e:	c4 41 25 54 c9       	vandpd %ymm9,%ymm11,%ymm9
  1d0553:	c5 35 c2 da 00       	vcmpeqpd %ymm2,%ymm9,%ymm11
  1d0558:	c5 35 c2 cb 1d       	vcmpge_oqpd %ymm3,%ymm9,%ymm9
  1d055d:	c4 41 35 56 cb       	vorpd  %ymm11,%ymm9,%ymm9
  1d0562:	c5 b5 54 e4          	vandpd %ymm4,%ymm9,%ymm4
  1d0566:	49 83 c1 20          	add    $0x20,%r9
  1d056a:	48 ff c8             	dec    %rax
  1d056d:	75 a1                	jne    1d0510 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0xa30>
  1d056f:	eb 1b                	jmp    1d058c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0xaac>
  1d0571:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1d0576:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1d057a:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  1d057e:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1d0583:	c5 7d 29 fc          	vmovapd %ymm15,%ymm4
  1d0587:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1d058c:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
  1d0591:	44 89 d9             	mov    %r11d,%ecx
  1d0594:	83 e1 03             	and    $0x3,%ecx
  1d0597:	49 be fc ff ff ff ff 	movabs $0xffffffffffffffc,%r14
  1d059e:	ff ff 0f 
  1d05a1:	4d 21 f3             	and    %r14,%r11
  1d05a4:	c4 43 7d 19 c1 01    	vextractf128 $0x1,%ymm8,%xmm9
  1d05aa:	c4 41 39 58 c1       	vaddpd %xmm9,%xmm8,%xmm8
  1d05af:	c4 41 39 c6 c8 01    	vshufpd $0x1,%xmm8,%xmm8,%xmm9
  1d05b5:	c4 41 3b 58 c1       	vaddsd %xmm9,%xmm8,%xmm8
  1d05ba:	c4 c3 7d 19 f9 01    	vextractf128 $0x1,%ymm7,%xmm9
  1d05c0:	c5 b1 58 ff          	vaddpd %xmm7,%xmm9,%xmm7
  1d05c4:	c5 41 c6 cf 01       	vshufpd $0x1,%xmm7,%xmm7,%xmm9
  1d05c9:	c5 33 58 cf          	vaddsd %xmm7,%xmm9,%xmm9
  1d05cd:	c4 e3 7d 19 c7 01    	vextractf128 $0x1,%ymm0,%xmm7
  1d05d3:	c5 f9 58 c7          	vaddpd %xmm7,%xmm0,%xmm0
  1d05d7:	c5 f9 c6 f8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm7
  1d05dc:	c5 fb 58 ff          	vaddsd %xmm7,%xmm0,%xmm7
  1d05e0:	c4 63 7d 19 d0 01    	vextractf128 $0x1,%ymm10,%xmm0
  1d05e6:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
  1d05eb:	44 89 c8             	mov    %r9d,%eax
  1d05ee:	83 e0 03             	and    $0x3,%eax
  1d05f1:	4c 8b 84 24 50 01 00 	mov    0x150(%rsp),%r8
  1d05f8:	00 
  1d05f9:	4c 39 c0             	cmp    %r8,%rax
  1d05fc:	49 0f 43 c0          	cmovae %r8,%rax
  1d0600:	c5 a9 58 c0          	vaddpd %xmm0,%xmm10,%xmm0
  1d0604:	49 39 c4             	cmp    %rax,%r12
  1d0607:	49 0f 42 c4          	cmovb  %r12,%rax
  1d060b:	c5 79 c6 d0 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm10
  1d0610:	4c 8b 84 24 88 01 00 	mov    0x188(%rsp),%r8
  1d0617:	00 
  1d0618:	49 39 c0             	cmp    %rax,%r8
  1d061b:	49 0f 42 c0          	cmovb  %r8,%rax
  1d061f:	c5 2b 58 d0          	vaddsd %xmm0,%xmm10,%xmm10
  1d0623:	48 39 c5             	cmp    %rax,%rbp
  1d0626:	48 0f 42 c5          	cmovb  %rbp,%rax
  1d062a:	48 39 c1             	cmp    %rax,%rcx
  1d062d:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  1d0634:	00 
  1d0635:	48 0f 42 c1          	cmovb  %rcx,%rax
  1d0639:	48 85 c0             	test   %rax,%rax
  1d063c:	4c 89 9c 24 98 00 00 	mov    %r11,0x98(%rsp)
  1d0643:	00 
  1d0644:	0f 84 fb 00 00 00    	je     1d0745 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0xc65>
  1d064a:	4d 89 cc             	mov    %r9,%r12
  1d064d:	4d 21 f4             	and    %r14,%r12
  1d0650:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  1d0657:	00 
  1d0658:	c4 c1 7b 10 04 ca    	vmovsd (%r10,%rcx,8),%xmm0
  1d065e:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  1d0665:	00 
  1d0666:	c5 7b 10 1c d9       	vmovsd (%rcx,%rbx,8),%xmm11
  1d066b:	c4 62 c9 a9 dd       	vfmadd213sd %xmm5,%xmm6,%xmm11
  1d0670:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  1d0675:	c4 22 f9 a9 1c e1    	vfmadd213sd (%rcx,%r12,8),%xmm0,%xmm11
  1d067b:	c4 41 f9 7e d9       	vmovq  %xmm11,%r9
  1d0680:	b1 3f                	mov    $0x3f,%cl
  1d0682:	c4 42 f0 f5 c9       	bzhi   %rcx,%r9,%r9
  1d0687:	48 b9 00 00 00 00 00 	movabs $0x7ff0000000000000,%rcx
  1d068e:	00 f0 7f 
  1d0691:	49 39 c9             	cmp    %rcx,%r9
  1d0694:	41 0f 94 c6          	sete   %r14b
  1d0698:	4d 85 c9             	test   %r9,%r9
  1d069b:	41 0f 94 c0          	sete   %r8b
  1d069f:	45 08 f0             	or     %r14b,%r8b
  1d06a2:	49 89 f6             	mov    %rsi,%r14
  1d06a5:	48 89 fe             	mov    %rdi,%rsi
  1d06a8:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  1d06ad:	48 8b 9c 24 40 02 00 	mov    0x240(%rsp),%rbx
  1d06b4:	00 
  1d06b5:	c4 62 f9 b9 04 df    	vfmadd231sd (%rdi,%rbx,8),%xmm0,%xmm8
  1d06bb:	48 8b 8c 24 38 02 00 	mov    0x238(%rsp),%rcx
  1d06c2:	00 
  1d06c3:	c4 62 f9 b9 0c ce    	vfmadd231sd (%rsi,%rcx,8),%xmm0,%xmm9
  1d06c9:	48 8b b4 24 30 02 00 	mov    0x230(%rsp),%rsi
  1d06d0:	00 
  1d06d1:	c4 c2 f9 b9 3c f6    	vfmadd231sd (%r14,%rsi,8),%xmm0,%xmm7
  1d06d7:	49 be 00 00 00 00 00 	movabs $0xfff0000000000000,%r14
  1d06de:	00 f0 ff 
  1d06e1:	4d 01 f1             	add    %r14,%r9
  1d06e4:	49 c1 e9 35          	shr    $0x35,%r9
  1d06e8:	41 81 f9 ff 03 00 00 	cmp    $0x3ff,%r9d
  1d06ef:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
  1d06f4:	48 8b ac 24 28 02 00 	mov    0x228(%rsp),%rbp
  1d06fb:	00 
  1d06fc:	c4 42 f9 b9 14 ee    	vfmadd231sd (%r14,%rbp,8),%xmm0,%xmm10
  1d0702:	41 0f 92 c1          	setb   %r9b
  1d0706:	45 08 c1             	or     %r8b,%r9b
  1d0709:	c4 21 7b 11 1c da    	vmovsd %xmm11,(%rdx,%r11,8)
  1d070f:	83 f8 01             	cmp    $0x1,%eax
  1d0712:	4c 8b 9c 24 e8 00 00 	mov    0xe8(%rsp),%r11
  1d0719:	00 
  1d071a:	75 5f                	jne    1d077b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0xc9b>
  1d071c:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  1d0721:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
  1d0726:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  1d072d:	00 
  1d072e:	48 8b 6c 24 70       	mov    0x70(%rsp),%rbp
  1d0733:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
  1d0738:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  1d073f:	00 
  1d0740:	e9 06 02 00 00       	jmp    1d094b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0xe6b>
  1d0745:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  1d074a:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
  1d074f:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  1d0756:	00 
  1d0757:	48 8b 6c 24 70       	mov    0x70(%rsp),%rbp
  1d075c:	4c 8b 9c 24 e8 00 00 	mov    0xe8(%rsp),%r11
  1d0763:	00 
  1d0764:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
  1d0769:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1d076e:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  1d0775:	00 
  1d0776:	e9 df 01 00 00       	jmp    1d095a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0xe7a>
  1d077b:	4c 89 bc 24 e0 01 00 	mov    %r15,0x1e0(%rsp)
  1d0782:	00 
  1d0783:	4c 8b 9c 24 20 01 00 	mov    0x120(%rsp),%r11
  1d078a:	00 
  1d078b:	c4 81 7b 10 44 da 08 	vmovsd 0x8(%r10,%r11,8),%xmm0
  1d0792:	4c 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%r8
  1d0799:	00 
  1d079a:	4c 8b 5c 24 78       	mov    0x78(%rsp),%r11
  1d079f:	c4 01 7b 10 5c d8 08 	vmovsd 0x8(%r8,%r11,8),%xmm11
  1d07a6:	c4 62 c9 a9 dd       	vfmadd213sd %xmm5,%xmm6,%xmm11
  1d07ab:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  1d07b0:	c4 02 f9 a9 5c e0 08 	vfmadd213sd 0x8(%r8,%r12,8),%xmm0,%xmm11
  1d07b7:	c4 41 f9 7e d8       	vmovq  %xmm11,%r8
  1d07bc:	41 b3 3f             	mov    $0x3f,%r11b
  1d07bf:	c4 42 a0 f5 c0       	bzhi   %r11,%r8,%r8
  1d07c4:	49 bb 00 00 00 00 00 	movabs $0x7ff0000000000000,%r11
  1d07cb:	00 f0 7f 
  1d07ce:	4d 39 d8             	cmp    %r11,%r8
  1d07d1:	4d 89 f7             	mov    %r14,%r15
  1d07d4:	41 0f 94 c6          	sete   %r14b
  1d07d8:	4d 85 c0             	test   %r8,%r8
  1d07db:	41 0f 94 c3          	sete   %r11b
  1d07df:	45 08 f3             	or     %r14b,%r11b
  1d07e2:	4d 89 fe             	mov    %r15,%r14
  1d07e5:	49 bf 00 00 00 00 00 	movabs $0xfff0000000000000,%r15
  1d07ec:	00 f0 ff 
  1d07ef:	4d 01 f8             	add    %r15,%r8
  1d07f2:	49 c1 e8 35          	shr    $0x35,%r8
  1d07f6:	41 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8d
  1d07fd:	41 0f 92 c0          	setb   %r8b
  1d0801:	45 08 d8             	or     %r11b,%r8b
  1d0804:	c4 62 f9 b9 44 df 08 	vfmadd231sd 0x8(%rdi,%rbx,8),%xmm0,%xmm8
  1d080b:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
  1d0810:	c4 42 f9 b9 4c cb 08 	vfmadd231sd 0x8(%r11,%rcx,8),%xmm0,%xmm9
  1d0817:	4c 8b 5c 24 28       	mov    0x28(%rsp),%r11
  1d081c:	c4 c2 f9 b9 7c f3 08 	vfmadd231sd 0x8(%r11,%rsi,8),%xmm0,%xmm7
  1d0823:	c4 42 f9 b9 54 ee 08 	vfmadd231sd 0x8(%r14,%rbp,8),%xmm0,%xmm10
  1d082a:	45 20 c1             	and    %r8b,%r9b
  1d082d:	4c 8b 84 24 98 00 00 	mov    0x98(%rsp),%r8
  1d0834:	00 
  1d0835:	c4 21 7b 11 5c c2 08 	vmovsd %xmm11,0x8(%rdx,%r8,8)
  1d083c:	83 f8 02             	cmp    $0x2,%eax
  1d083f:	75 29                	jne    1d086a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0xd8a>
  1d0841:	4c 8b 9c 24 e8 00 00 	mov    0xe8(%rsp),%r11
  1d0848:	00 
  1d0849:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  1d084e:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
  1d0853:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  1d085a:	00 
  1d085b:	48 8b 6c 24 70       	mov    0x70(%rsp),%rbp
  1d0860:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
  1d0865:	e9 d1 00 00 00       	jmp    1d093b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0xe5b>
  1d086a:	49 89 fb             	mov    %rdi,%r11
  1d086d:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
  1d0874:	00 
  1d0875:	c4 c1 7b 10 44 c2 10 	vmovsd 0x10(%r10,%rax,8),%xmm0
  1d087c:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  1d0883:	00 
  1d0884:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  1d0889:	c4 e2 c9 b9 6c f8 10 	vfmadd231sd 0x10(%rax,%rdi,8),%xmm6,%xmm5
  1d0890:	4d 89 f7             	mov    %r14,%r15
  1d0893:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  1d0898:	c4 82 f9 a9 6c e6 10 	vfmadd213sd 0x10(%r14,%r12,8),%xmm0,%xmm5
  1d089f:	c4 e1 f9 7e e8       	vmovq  %xmm5,%rax
  1d08a4:	40 b7 3f             	mov    $0x3f,%dil
  1d08a7:	c4 e2 c0 f5 c0       	bzhi   %rdi,%rax,%rax
  1d08ac:	48 bf 00 00 00 00 00 	movabs $0x7ff0000000000000,%rdi
  1d08b3:	00 f0 7f 
  1d08b6:	48 39 f8             	cmp    %rdi,%rax
  1d08b9:	40 0f 94 c7          	sete   %dil
  1d08bd:	48 85 c0             	test   %rax,%rax
  1d08c0:	4d 89 c4             	mov    %r8,%r12
  1d08c3:	41 0f 94 c0          	sete   %r8b
  1d08c7:	41 08 f8             	or     %dil,%r8b
  1d08ca:	48 bf 00 00 00 00 00 	movabs $0xfff0000000000000,%rdi
  1d08d1:	00 f0 ff 
  1d08d4:	48 01 f8             	add    %rdi,%rax
  1d08d7:	48 c1 e8 35          	shr    $0x35,%rax
  1d08db:	3d ff 03 00 00       	cmp    $0x3ff,%eax
  1d08e0:	0f 92 c0             	setb   %al
  1d08e3:	44 08 c0             	or     %r8b,%al
  1d08e6:	41 20 c1             	and    %al,%r9b
  1d08e9:	c4 42 f9 b9 44 db 10 	vfmadd231sd 0x10(%r11,%rbx,8),%xmm0,%xmm8
  1d08f0:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  1d08f5:	c4 62 f9 b9 4c c8 10 	vfmadd231sd 0x10(%rax,%rcx,8),%xmm0,%xmm9
  1d08fc:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  1d0901:	c4 e2 f9 b9 7c f0 10 	vfmadd231sd 0x10(%rax,%rsi,8),%xmm0,%xmm7
  1d0908:	c4 42 f9 b9 54 ef 10 	vfmadd231sd 0x10(%r15,%rbp,8),%xmm0,%xmm10
  1d090f:	c4 a1 7b 11 6c e2 10 	vmovsd %xmm5,0x10(%rdx,%r12,8)
  1d0916:	4c 8b 9c 24 e8 00 00 	mov    0xe8(%rsp),%r11
  1d091d:	00 
  1d091e:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  1d0923:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
  1d0928:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  1d092f:	00 
  1d0930:	48 8b 6c 24 70       	mov    0x70(%rsp),%rbp
  1d0935:	4d 89 f4             	mov    %r14,%r12
  1d0938:	49 89 c6             	mov    %rax,%r14
  1d093b:	48 8b 9c 24 00 01 00 	mov    0x100(%rsp),%rbx
  1d0942:	00 
  1d0943:	4c 8b bc 24 e0 01 00 	mov    0x1e0(%rsp),%r15
  1d094a:	00 
  1d094b:	44 20 4c 24 07       	and    %r9b,0x7(%rsp)
  1d0950:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1d0955:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
  1d095a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  1d095f:	4d 39 f5             	cmp    %r14,%r13
  1d0962:	0f 83 32 1e 00 00    	jae    1d279a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2cba>
  1d0968:	c4 01 7b 11 04 3b    	vmovsd %xmm8,(%r11,%r15,1)
  1d096e:	c4 01 7b 11 4c 3b 08 	vmovsd %xmm9,0x8(%r11,%r15,1)
  1d0975:	4c 39 84 24 60 01 00 	cmp    %r8,0x160(%rsp)
  1d097c:	00 
  1d097d:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
  1d0984:	00 
  1d0985:	0f 83 ef f6 ff ff    	jae    1d007a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x59a>
  1d098b:	49 ff c5             	inc    %r13
  1d098e:	4d 39 f5             	cmp    %r14,%r13
  1d0991:	0f 83 72 1e 00 00    	jae    1d2809 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d29>
  1d0997:	49 c1 e5 04          	shl    $0x4,%r13
  1d099b:	c4 81 7b 11 3c 2b    	vmovsd %xmm7,(%r11,%r13,1)
  1d09a1:	c4 01 7b 11 54 2b 08 	vmovsd %xmm10,0x8(%r11,%r13,1)
  1d09a8:	e9 cd f6 ff ff       	jmp    1d007a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x59a>
  1d09ad:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
  1d09b4:	00 
  1d09b5:	48 89 f8             	mov    %rdi,%rax
  1d09b8:	48 c1 e8 02          	shr    $0x2,%rax
  1d09bc:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
  1d09c3:	00 
  1d09c4:	41 89 fc             	mov    %edi,%r12d
  1d09c7:	41 83 e4 03          	and    $0x3,%r12d
  1d09cb:	4c 8b 44 24 58       	mov    0x58(%rsp),%r8
  1d09d0:	4c 89 c0             	mov    %r8,%rax
  1d09d3:	48 c1 e8 02          	shr    $0x2,%rax
  1d09d7:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  1d09de:	00 
  1d09df:	44 89 c0             	mov    %r8d,%eax
  1d09e2:	83 e0 03             	and    $0x3,%eax
  1d09e5:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  1d09ec:	00 
  1d09ed:	4c 8b 8c 24 88 00 00 	mov    0x88(%rsp),%r9
  1d09f4:	00 
  1d09f5:	4c 89 c8             	mov    %r9,%rax
  1d09f8:	48 c1 e8 02          	shr    $0x2,%rax
  1d09fc:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
  1d0a03:	00 
  1d0a04:	44 89 c8             	mov    %r9d,%eax
  1d0a07:	83 e0 03             	and    $0x3,%eax
  1d0a0a:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
  1d0a11:	00 
  1d0a12:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
  1d0a19:	00 
  1d0a1a:	4c 89 f8             	mov    %r15,%rax
  1d0a1d:	48 c1 e8 02          	shr    $0x2,%rax
  1d0a21:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
  1d0a28:	00 
  1d0a29:	44 89 f8             	mov    %r15d,%eax
  1d0a2c:	83 e0 03             	and    $0x3,%eax
  1d0a2f:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
  1d0a36:	00 
  1d0a37:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  1d0a3c:	4c 89 ee             	mov    %r13,%rsi
  1d0a3f:	48 c1 ee 02          	shr    $0x2,%rsi
  1d0a43:	44 89 e8             	mov    %r13d,%eax
  1d0a46:	83 e0 03             	and    $0x3,%eax
  1d0a49:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  1d0a50:	00 
  1d0a51:	4c 89 e9             	mov    %r13,%rcx
  1d0a54:	48 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%rax
  1d0a5b:	ff ff 0f 
  1d0a5e:	48 21 c1             	and    %rax,%rcx
  1d0a61:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  1d0a68:	00 
  1d0a69:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  1d0a70:	00 
  1d0a71:	48 89 c1             	mov    %rax,%rcx
  1d0a74:	48 c1 e9 02          	shr    $0x2,%rcx
  1d0a78:	48 89 8c 24 a0 01 00 	mov    %rcx,0x1a0(%rsp)
  1d0a7f:	00 
  1d0a80:	48 c1 e8 03          	shr    $0x3,%rax
  1d0a84:	48 89 c5             	mov    %rax,%rbp
  1d0a87:	4c 89 e8             	mov    %r13,%rax
  1d0a8a:	eb 46                	jmp    1d0ad2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0xff2>
  1d0a8c:	c5 7d 28 f9          	vmovapd %ymm1,%ymm15
  1d0a90:	48 89 f8             	mov    %rdi,%rax
  1d0a93:	49 89 d2             	mov    %rdx,%r10
  1d0a96:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
  1d0a9d:	00 
  1d0a9e:	4c 8b 44 24 58       	mov    0x58(%rsp),%r8
  1d0aa3:	4c 8b 8c 24 88 00 00 	mov    0x88(%rsp),%r9
  1d0aaa:	00 
  1d0aab:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
  1d0ab2:	00 
  1d0ab3:	48 ba fe ff ff ff ff 	movabs $0x3fffffffffffffe,%rdx
  1d0aba:	ff ff 03 
  1d0abd:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
  1d0ac2:	4c 8b a4 24 48 01 00 	mov    0x148(%rsp),%r12
  1d0ac9:	00 
  1d0aca:	48 8b b4 24 30 01 00 	mov    0x130(%rsp),%rsi
  1d0ad1:	00 
  1d0ad2:	48 21 d6             	and    %rdx,%rsi
  1d0ad5:	48 c1 e6 05          	shl    $0x5,%rsi
  1d0ad9:	48 89 b4 24 30 01 00 	mov    %rsi,0x130(%rsp)
  1d0ae0:	00 
  1d0ae1:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  1d0ae6:	48 89 c2             	mov    %rax,%rdx
  1d0ae9:	48 c1 ea 03          	shr    $0x3,%rdx
  1d0aed:	48 89 f8             	mov    %rdi,%rax
  1d0af0:	48 c1 e8 03          	shr    $0x3,%rax
  1d0af4:	4c 89 c7             	mov    %r8,%rdi
  1d0af7:	48 c1 ef 03          	shr    $0x3,%rdi
  1d0afb:	48 39 c7             	cmp    %rax,%rdi
  1d0afe:	48 0f 43 f8          	cmovae %rax,%rdi
  1d0b02:	4d 89 c8             	mov    %r9,%r8
  1d0b05:	49 c1 e8 03          	shr    $0x3,%r8
  1d0b09:	49 39 f8             	cmp    %rdi,%r8
  1d0b0c:	4c 0f 43 c7          	cmovae %rdi,%r8
  1d0b10:	4c 89 f8             	mov    %r15,%rax
  1d0b13:	48 c1 e8 03          	shr    $0x3,%rax
  1d0b17:	4c 39 c0             	cmp    %r8,%rax
  1d0b1a:	49 0f 43 c0          	cmovae %r8,%rax
  1d0b1e:	48 39 c2             	cmp    %rax,%rdx
  1d0b21:	48 0f 42 c2          	cmovb  %rdx,%rax
  1d0b25:	48 39 c5             	cmp    %rax,%rbp
  1d0b28:	48 0f 42 c5          	cmovb  %rbp,%rax
  1d0b2c:	48 85 c0             	test   %rax,%rax
  1d0b2f:	4c 8b ac 24 d8 01 00 	mov    0x1d8(%rsp),%r13
  1d0b36:	00 
  1d0b37:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  1d0b3c:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1d0b41:	48 bf fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rdi
  1d0b48:	ff ff 1f 
  1d0b4b:	0f 84 69 12 00 00    	je     1d1dba <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x22da>
  1d0b51:	48 83 f8 01          	cmp    $0x1,%rax
  1d0b55:	0f 85 8d 12 00 00    	jne    1d1de8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2308>
  1d0b5b:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1d0b5f:	31 ff                	xor    %edi,%edi
  1d0b61:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1d0b65:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1d0b69:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1d0b6d:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1d0b71:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1d0b75:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1d0b79:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1d0b7e:	4c 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%r15
  1d0b85:	00 
  1d0b86:	e9 56 13 00 00       	jmp    1d1ee1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2401>
  1d0b8b:	49 89 cf             	mov    %rcx,%r15
  1d0b8e:	45 89 e8             	mov    %r13d,%r8d
  1d0b91:	41 83 e0 03          	and    $0x3,%r8d
  1d0b95:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
  1d0b9c:	00 
  1d0b9d:	89 ca                	mov    %ecx,%edx
  1d0b9f:	83 e2 03             	and    $0x3,%edx
  1d0ba2:	44 39 c2             	cmp    %r8d,%edx
  1d0ba5:	4c 8b 5c 24 58       	mov    0x58(%rsp),%r11
  1d0baa:	0f 85 4a 1b 00 00    	jne    1d26fa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c1a>
  1d0bb0:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
  1d0bb7:	00 
  1d0bb8:	83 e1 03             	and    $0x3,%ecx
  1d0bbb:	48 89 8c 24 90 01 00 	mov    %rcx,0x190(%rsp)
  1d0bc2:	00 
  1d0bc3:	44 39 c1             	cmp    %r8d,%ecx
  1d0bc6:	0f 85 2e 1b 00 00    	jne    1d26fa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c1a>
  1d0bcc:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
  1d0bd3:	00 
  1d0bd4:	48 c1 ea 02          	shr    $0x2,%rdx
  1d0bd8:	4c 39 fa             	cmp    %r15,%rdx
  1d0bdb:	0f 85 19 1b 00 00    	jne    1d26fa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c1a>
  1d0be1:	48 8b 94 24 18 01 00 	mov    0x118(%rsp),%rdx
  1d0be8:	00 
  1d0be9:	48 c1 ea 02          	shr    $0x2,%rdx
  1d0bed:	4c 39 fa             	cmp    %r15,%rdx
  1d0bf0:	0f 85 04 1b 00 00    	jne    1d26fa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c1a>
  1d0bf6:	44 89 da             	mov    %r11d,%edx
  1d0bf9:	83 e2 03             	and    $0x3,%edx
  1d0bfc:	41 39 d0             	cmp    %edx,%r8d
  1d0bff:	0f 85 f5 1a 00 00    	jne    1d26fa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c1a>
  1d0c05:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
  1d0c0a:	4c 8b 8c 24 88 00 00 	mov    0x88(%rsp),%r9
  1d0c11:	00 
  1d0c12:	41 83 e1 03          	and    $0x3,%r9d
  1d0c16:	41 39 d1             	cmp    %edx,%r9d
  1d0c19:	0f 85 db 1a 00 00    	jne    1d26fa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c1a>
  1d0c1f:	4c 8b 8c 24 80 00 00 	mov    0x80(%rsp),%r9
  1d0c26:	00 
  1d0c27:	41 83 e1 03          	and    $0x3,%r9d
  1d0c2b:	41 39 d1             	cmp    %edx,%r9d
  1d0c2e:	0f 85 c6 1a 00 00    	jne    1d26fa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c1a>
  1d0c34:	4c 89 b4 24 d8 01 00 	mov    %r14,0x1d8(%rsp)
  1d0c3b:	00 
  1d0c3c:	49 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%r8
  1d0c43:	ff ff 0f 
  1d0c46:	4d 21 c5             	and    %r8,%r13
  1d0c49:	4c 89 ac 24 10 01 00 	mov    %r13,0x110(%rsp)
  1d0c50:	00 
  1d0c51:	4d 21 c3             	and    %r8,%r11
  1d0c54:	4c 89 5c 24 78       	mov    %r11,0x78(%rsp)
  1d0c59:	48 8b 94 24 88 00 00 	mov    0x88(%rsp),%rdx
  1d0c60:	00 
  1d0c61:	4c 21 c2             	and    %r8,%rdx
  1d0c64:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  1d0c6b:	00 
  1d0c6c:	4c 21 c1             	and    %r8,%rcx
  1d0c6f:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  1d0c76:	00 
  1d0c77:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
  1d0c7e:	00 
  1d0c7f:	4c 21 c1             	and    %r8,%rcx
  1d0c82:	48 89 8c 24 d8 00 00 	mov    %rcx,0xd8(%rsp)
  1d0c89:	00 
  1d0c8a:	89 f1                	mov    %esi,%ecx
  1d0c8c:	83 e1 03             	and    $0x3,%ecx
  1d0c8f:	4c 21 c6             	and    %r8,%rsi
  1d0c92:	48 89 b4 24 00 01 00 	mov    %rsi,0x100(%rsp)
  1d0c99:	00 
  1d0c9a:	48 8d 71 ff          	lea    -0x1(%rcx),%rsi
  1d0c9e:	48 39 ce             	cmp    %rcx,%rsi
  1d0ca1:	48 89 8c 24 b0 00 00 	mov    %rcx,0xb0(%rsp)
  1d0ca8:	00 
  1d0ca9:	48 0f 43 f1          	cmovae %rcx,%rsi
  1d0cad:	48 89 b4 24 88 01 00 	mov    %rsi,0x188(%rsp)
  1d0cb4:	00 
  1d0cb5:	4c 89 f9             	mov    %r15,%rcx
  1d0cb8:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  1d0cbc:	48 89 8c 24 50 01 00 	mov    %rcx,0x150(%rsp)
  1d0cc3:	00 
  1d0cc4:	4c 8b 8c 24 98 00 00 	mov    0x98(%rsp),%r9
  1d0ccb:	00 
  1d0ccc:	49 83 e1 fe          	and    $0xfffffffffffffffe,%r9
  1d0cd0:	c6 44 24 07 01       	movb   $0x1,0x7(%rsp)
  1d0cd5:	48 89 c6             	mov    %rax,%rsi
  1d0cd8:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  1d0cdf:	00 
  1d0ce0:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  1d0ce5:	4c 8b 9c 24 e8 00 00 	mov    0xe8(%rsp),%r11
  1d0cec:	00 
  1d0ced:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  1d0cf2:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
  1d0cf7:	c5 7d 11 bc 24 50 02 	vmovupd %ymm15,0x250(%rsp)
  1d0cfe:	00 00 
  1d0d00:	48 89 94 24 08 01 00 	mov    %rdx,0x108(%rsp)
  1d0d07:	00 
  1d0d08:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
  1d0d0d:	eb 1f                	jmp    1d0d2e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x124e>
  1d0d0f:	48 83 c6 02          	add    $0x2,%rsi
  1d0d13:	4c 89 ef             	mov    %r13,%rdi
  1d0d16:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  1d0d1b:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  1d0d20:	48 3b b4 24 98 01 00 	cmp    0x198(%rsp),%rsi
  1d0d27:	00 
  1d0d28:	0f 83 1a 1a 00 00    	jae    1d2748 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c68>
  1d0d2e:	4c 8b 6c 24 10       	mov    0x10(%rsp),%r13
  1d0d33:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
  1d0d38:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
  1d0d3f:	00 
  1d0d40:	48 39 ce             	cmp    %rcx,%rsi
  1d0d43:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
  1d0d48:	0f 83 cd 1b 00 00    	jae    1d291b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2e3b>
  1d0d4e:	48 89 f0             	mov    %rsi,%rax
  1d0d51:	48 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%rsi
  1d0d58:	00 
  1d0d59:	48 39 f0             	cmp    %rsi,%rax
  1d0d5c:	0f 83 db 1b 00 00    	jae    1d293d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2e5d>
  1d0d62:	48 ff c0             	inc    %rax
  1d0d65:	48 39 c8             	cmp    %rcx,%rax
  1d0d68:	0f 83 c7 1a 00 00    	jae    1d2835 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d55>
  1d0d6e:	48 39 f0             	cmp    %rsi,%rax
  1d0d71:	0f 83 d9 1a 00 00    	jae    1d2850 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d70>
  1d0d77:	49 89 fa             	mov    %rdi,%r10
  1d0d7a:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  1d0d7f:	48 89 cf             	mov    %rcx,%rdi
  1d0d82:	48 c1 ef 02          	shr    $0x2,%rdi
  1d0d86:	31 c0                	xor    %eax,%eax
  1d0d88:	4c 39 ff             	cmp    %r15,%rdi
  1d0d8b:	0f 85 a2 19 00 00    	jne    1d2733 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c53>
  1d0d91:	89 cf                	mov    %ecx,%edi
  1d0d93:	83 e7 03             	and    $0x3,%edi
  1d0d96:	3b 7c 24 08          	cmp    0x8(%rsp),%edi
  1d0d9a:	0f 85 93 19 00 00    	jne    1d2733 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c53>
  1d0da0:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  1d0da7:	00 
  1d0da8:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  1d0dad:	c5 fb 10 04 d0       	vmovsd (%rax,%rdx,8),%xmm0
  1d0db2:	48 8b 8c 24 f8 01 00 	mov    0x1f8(%rsp),%rcx
  1d0db9:	00 
  1d0dba:	c5 fb 10 24 d1       	vmovsd (%rcx,%rdx,8),%xmm4
  1d0dbf:	c5 fb 10 4c d0 08    	vmovsd 0x8(%rax,%rdx,8),%xmm1
  1d0dc5:	c5 fb 10 5c d1 08    	vmovsd 0x8(%rcx,%rdx,8),%xmm3
  1d0dcb:	4d 85 ff             	test   %r15,%r15
  1d0dce:	c5 f9 29 8c 24 20 01 	vmovapd %xmm1,0x120(%rsp)
  1d0dd5:	00 00 
  1d0dd7:	c5 f9 29 84 24 60 01 	vmovapd %xmm0,0x160(%rsp)
  1d0dde:	00 00 
  1d0de0:	c5 f9 29 9c 24 a0 01 	vmovapd %xmm3,0x1a0(%rsp)
  1d0de7:	00 00 
  1d0de9:	c5 f9 29 a4 24 30 01 	vmovapd %xmm4,0x130(%rsp)
  1d0df0:	00 00 
  1d0df2:	0f 84 d2 00 00 00    	je     1d0eca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x13ea>
  1d0df8:	c4 e2 7d 19 d0       	vbroadcastsd %xmm0,%ymm2
  1d0dfd:	c4 e2 7d 19 c4       	vbroadcastsd %xmm4,%ymm0
  1d0e02:	c4 62 7d 19 f1       	vbroadcastsd %xmm1,%ymm14
  1d0e07:	c4 62 7d 19 e3       	vbroadcastsd %xmm3,%ymm12
  1d0e0c:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1d0e10:	4c 89 f8             	mov    %r15,%rax
  1d0e13:	31 ff                	xor    %edi,%edi
  1d0e15:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1d0e19:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1d0e1e:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1d0e22:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1d0e27:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1d0e2b:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1d0e30:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1d0e35:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  1d0e3a:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1d0e3f:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  1d0e44:	4c 8b 7c 24 48       	mov    0x48(%rsp),%r15
  1d0e49:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  1d0e4e:	66 90                	xchg   %ax,%ax
  1d0e50:	c5 7d 10 3c 3a       	vmovupd (%rdx,%rdi,1),%ymm15
  1d0e55:	c4 41 7d 10 2c 39    	vmovupd (%r9,%rdi,1),%ymm13
  1d0e5b:	c4 42 95 b8 d7       	vfmadd231pd %ymm15,%ymm13,%ymm10
  1d0e60:	c4 c1 7d 10 0c 3c    	vmovupd (%r12,%rdi,1),%ymm1
  1d0e66:	c5 fd 28 d9          	vmovapd %ymm1,%ymm3
  1d0e6a:	c4 e2 ed a8 d8       	vfmadd213pd %ymm0,%ymm2,%ymm3
  1d0e6f:	c4 c2 85 a8 1c 3a    	vfmadd213pd (%r10,%rdi,1),%ymm15,%ymm3
  1d0e75:	c4 c2 e5 b8 ed       	vfmadd231pd %ymm13,%ymm3,%ymm5
  1d0e7a:	c5 7d 10 2c 3e       	vmovupd (%rsi,%rdi,1),%ymm13
  1d0e7f:	c4 42 95 b8 df       	vfmadd231pd %ymm15,%ymm13,%ymm11
  1d0e84:	c4 42 e5 b8 c5       	vfmadd231pd %ymm13,%ymm3,%ymm8
  1d0e89:	c5 7d 10 2c 39       	vmovupd (%rcx,%rdi,1),%ymm13
  1d0e8e:	c4 c2 95 b8 ff       	vfmadd231pd %ymm15,%ymm13,%ymm7
  1d0e93:	c4 c2 e5 b8 e5       	vfmadd231pd %ymm13,%ymm3,%ymm4
  1d0e98:	c4 41 7d 10 2c 3f    	vmovupd (%r15,%rdi,1),%ymm13
  1d0e9e:	c4 42 95 b8 cf       	vfmadd231pd %ymm15,%ymm13,%ymm9
  1d0ea3:	c4 c2 e5 b8 f5       	vfmadd231pd %ymm13,%ymm3,%ymm6
  1d0ea8:	c4 c2 8d a8 cc       	vfmadd213pd %ymm12,%ymm14,%ymm1
  1d0ead:	c4 c2 e5 a8 cf       	vfmadd213pd %ymm15,%ymm3,%ymm1
  1d0eb2:	c4 c1 7d 11 5c 3d 00 	vmovupd %ymm3,0x0(%r13,%rdi,1)
  1d0eb9:	c4 c1 7d 11 0c 3a    	vmovupd %ymm1,(%r10,%rdi,1)
  1d0ebf:	48 83 c7 20          	add    $0x20,%rdi
  1d0ec3:	48 ff c8             	dec    %rax
  1d0ec6:	75 88                	jne    1d0e50 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1370>
  1d0ec8:	eb 24                	jmp    1d0eee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x140e>
  1d0eca:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1d0ecf:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1d0ed4:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1d0ed8:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1d0edd:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1d0ee1:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1d0ee6:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1d0eea:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1d0eee:	c4 63 7d 19 d0 01    	vextractf128 $0x1,%ymm10,%xmm0
  1d0ef4:	c5 a9 58 c0          	vaddpd %xmm0,%xmm10,%xmm0
  1d0ef8:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d0efd:	c5 7b 58 f9          	vaddsd %xmm1,%xmm0,%xmm15
  1d0f01:	c4 63 7d 19 d8 01    	vextractf128 $0x1,%ymm11,%xmm0
  1d0f07:	c5 a1 58 c0          	vaddpd %xmm0,%xmm11,%xmm0
  1d0f0b:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d0f10:	c5 7b 58 d9          	vaddsd %xmm1,%xmm0,%xmm11
  1d0f14:	c4 e3 7d 19 f8 01    	vextractf128 $0x1,%ymm7,%xmm0
  1d0f1a:	c5 c1 58 c0          	vaddpd %xmm0,%xmm7,%xmm0
  1d0f1e:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d0f23:	c5 7b 58 e1          	vaddsd %xmm1,%xmm0,%xmm12
  1d0f27:	c4 63 7d 19 c8 01    	vextractf128 $0x1,%ymm9,%xmm0
  1d0f2d:	c5 b1 58 c0          	vaddpd %xmm0,%xmm9,%xmm0
  1d0f31:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d0f36:	c5 7b 58 c9          	vaddsd %xmm1,%xmm0,%xmm9
  1d0f3a:	c4 e3 7d 19 e8 01    	vextractf128 $0x1,%ymm5,%xmm0
  1d0f40:	c5 d1 58 c0          	vaddpd %xmm0,%xmm5,%xmm0
  1d0f44:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d0f49:	c5 fb 58 e9          	vaddsd %xmm1,%xmm0,%xmm5
  1d0f4d:	c4 63 7d 19 c0 01    	vextractf128 $0x1,%ymm8,%xmm0
  1d0f53:	c5 b9 58 c0          	vaddpd %xmm0,%xmm8,%xmm0
  1d0f57:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d0f5c:	c5 7b 58 d1          	vaddsd %xmm1,%xmm0,%xmm10
  1d0f60:	c4 e3 7d 19 e0 01    	vextractf128 $0x1,%ymm4,%xmm0
  1d0f66:	c5 d9 58 c0          	vaddpd %xmm0,%xmm4,%xmm0
  1d0f6a:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d0f6f:	c5 fb 58 e1          	vaddsd %xmm1,%xmm0,%xmm4
  1d0f73:	c4 e3 7d 19 f0 01    	vextractf128 $0x1,%ymm6,%xmm0
  1d0f79:	c5 c9 58 c0          	vaddpd %xmm0,%xmm6,%xmm0
  1d0f7d:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d0f82:	c5 fb 58 f9          	vaddsd %xmm1,%xmm0,%xmm7
  1d0f86:	48 83 bc 24 90 01 00 	cmpq   $0x0,0x190(%rsp)
  1d0f8d:	00 00 
  1d0f8f:	0f 84 a2 01 00 00    	je     1d1137 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1657>
  1d0f95:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
  1d0f9b:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  1d0fa0:	4c 8b 64 24 28       	mov    0x28(%rsp),%r12
  1d0fa5:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  1d0fac:	00 
  1d0fad:	48 8b 94 24 10 01 00 	mov    0x110(%rsp),%rdx
  1d0fb4:	00 
  1d0fb5:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
  1d0fba:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  1d0fc1:	00 
  1d0fc2:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
  1d0fc9:	00 
  1d0fca:	c4 41 11 57 ed       	vxorpd %xmm13,%xmm13,%xmm13
  1d0fcf:	c4 62 7d 19 35 a0 50 	vbroadcastsd -0x1aaf60(%rip),%ymm14        # 26078 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x3a8>
  1d0fd6:	e5 ff 
  1d0fd8:	0f 84 53 17 00 00    	je     1d2731 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c51>
  1d0fde:	4c 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%r8
  1d0fe5:	00 
  1d0fe6:	c4 c1 7b 10 04 f8    	vmovsd (%r8,%rdi,8),%xmm0
  1d0fec:	c5 f9 28 d0          	vmovapd %xmm0,%xmm2
  1d0ff0:	c5 f9 28 f4          	vmovapd %xmm4,%xmm6
  1d0ff4:	c5 f9 28 8c 24 30 01 	vmovapd 0x130(%rsp),%xmm1
  1d0ffb:	00 00 
  1d0ffd:	c4 e2 f1 99 94 24 60 	vfmadd132sd 0x160(%rsp),%xmm1,%xmm2
  1d1004:	01 00 00 
  1d1007:	c5 79 28 c5          	vmovapd %xmm5,%xmm8
  1d100b:	c5 79 29 cd          	vmovapd %xmm9,%xmm5
  1d100f:	c4 41 79 28 cc       	vmovapd %xmm12,%xmm9
  1d1014:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  1d1019:	c4 41 7b 10 24 f0    	vmovsd (%r8,%rsi,8),%xmm12
  1d101f:	c4 c2 99 a9 14 f2    	vfmadd213sd (%r10,%rsi,8),%xmm12,%xmm2
  1d1025:	c5 f9 28 a4 24 a0 01 	vmovapd 0x1a0(%rsp),%xmm4
  1d102c:	00 00 
  1d102e:	c4 e2 d9 99 84 24 20 	vfmadd132sd 0x120(%rsp),%xmm4,%xmm0
  1d1035:	01 00 00 
  1d1038:	c4 c2 e9 a9 c4       	vfmadd213sd %xmm12,%xmm2,%xmm0
  1d103d:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
  1d1042:	c4 c1 7b 10 0c c0    	vmovsd (%r8,%rax,8),%xmm1
  1d1048:	c4 e2 f1 b9 fa       	vfmadd231sd %xmm2,%xmm1,%xmm7
  1d104d:	c4 e2 99 b9 e9       	vfmadd231sd %xmm1,%xmm12,%xmm5
  1d1052:	4c 8b 84 24 08 01 00 	mov    0x108(%rsp),%r8
  1d1059:	00 
  1d105a:	c4 81 7b 10 0c c4    	vmovsd (%r12,%r8,8),%xmm1
  1d1060:	c4 e2 f1 b9 f2       	vfmadd231sd %xmm2,%xmm1,%xmm6
  1d1065:	c4 62 99 b9 c9       	vfmadd231sd %xmm1,%xmm12,%xmm9
  1d106a:	c4 c1 7b 10 0c f7    	vmovsd (%r15,%rsi,8),%xmm1
  1d1070:	c4 62 f1 b9 d2       	vfmadd231sd %xmm2,%xmm1,%xmm10
  1d1075:	c5 79 29 db          	vmovapd %xmm11,%xmm3
  1d1079:	c4 e2 99 b9 d9       	vfmadd231sd %xmm1,%xmm12,%xmm3
  1d107e:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
  1d1083:	c4 c1 7b 10 0c d0    	vmovsd (%r8,%rdx,8),%xmm1
  1d1089:	c4 42 f1 b9 fc       	vfmadd231sd %xmm12,%xmm1,%xmm15
  1d108e:	c4 62 f1 b9 c2       	vfmadd231sd %xmm2,%xmm1,%xmm8
  1d1093:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  1d1098:	48 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%rax
  1d109f:	ff ff 0f 
  1d10a2:	48 21 c7             	and    %rax,%rdi
  1d10a5:	c4 c1 7b 11 54 fd 00 	vmovsd %xmm2,0x0(%r13,%rdi,8)
  1d10ac:	c4 e1 f9 7e d0       	vmovq  %xmm2,%rax
  1d10b1:	c4 c1 f9 7e c0       	vmovq  %xmm0,%r8
  1d10b6:	c4 c1 7b 11 04 f2    	vmovsd %xmm0,(%r10,%rsi,8)
  1d10bc:	41 b4 3f             	mov    $0x3f,%r12b
  1d10bf:	c4 e2 98 f5 c0       	bzhi   %r12,%rax,%rax
  1d10c4:	49 bf 00 00 00 00 00 	movabs $0x7ff0000000000000,%r15
  1d10cb:	00 f0 7f 
  1d10ce:	4c 39 f8             	cmp    %r15,%rax
  1d10d1:	41 0f 94 c1          	sete   %r9b
  1d10d5:	48 85 c0             	test   %rax,%rax
  1d10d8:	41 0f 94 c3          	sete   %r11b
  1d10dc:	45 08 cb             	or     %r9b,%r11b
  1d10df:	48 ba 00 00 00 00 00 	movabs $0xfff0000000000000,%rdx
  1d10e6:	00 f0 ff 
  1d10e9:	48 01 d0             	add    %rdx,%rax
  1d10ec:	48 c1 e8 35          	shr    $0x35,%rax
  1d10f0:	3d ff 03 00 00       	cmp    $0x3ff,%eax
  1d10f5:	41 0f 92 c1          	setb   %r9b
  1d10f9:	45 08 d9             	or     %r11b,%r9b
  1d10fc:	c4 c2 98 f5 c0       	bzhi   %r12,%r8,%rax
  1d1101:	4c 39 f8             	cmp    %r15,%rax
  1d1104:	41 0f 94 c0          	sete   %r8b
  1d1108:	48 85 c0             	test   %rax,%rax
  1d110b:	41 0f 94 c3          	sete   %r11b
  1d110f:	45 08 c3             	or     %r8b,%r11b
  1d1112:	48 01 d0             	add    %rdx,%rax
  1d1115:	48 c1 e8 35          	shr    $0x35,%rax
  1d1119:	3d ff 03 00 00       	cmp    $0x3ff,%eax
  1d111e:	0f 92 c0             	setb   %al
  1d1121:	44 08 d8             	or     %r11b,%al
  1d1124:	44 20 c8             	and    %r9b,%al
  1d1127:	83 7c 24 08 01       	cmpl   $0x1,0x8(%rsp)
  1d112c:	75 47                	jne    1d1175 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1695>
  1d112e:	c5 79 28 db          	vmovapd %xmm3,%xmm11
  1d1132:	e9 0a 04 00 00       	jmp    1d1541 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1a61>
  1d1137:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  1d113e:	00 
  1d113f:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1d1144:	4c 8b 44 24 70       	mov    0x70(%rsp),%r8
  1d1149:	48 8b bc 24 50 01 00 	mov    0x150(%rsp),%rdi
  1d1150:	00 
  1d1151:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  1d1156:	c4 41 11 57 ed       	vxorpd %xmm13,%xmm13,%xmm13
  1d115b:	b2 3f                	mov    $0x3f,%dl
  1d115d:	49 bf 00 00 00 00 00 	movabs $0x7ff0000000000000,%r15
  1d1164:	00 f0 7f 
  1d1167:	c4 62 7d 19 35 08 4f 	vbroadcastsd -0x1ab0f8(%rip),%ymm14        # 26078 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x3a8>
  1d116e:	e5 ff 
  1d1170:	e9 02 04 00 00       	jmp    1d1577 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1a97>
  1d1175:	4c 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%r8
  1d117c:	00 
  1d117d:	4c 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%r9
  1d1184:	00 
  1d1185:	c4 81 7b 10 44 c8 08 	vmovsd 0x8(%r8,%r9,8),%xmm0
  1d118c:	c5 f9 28 d0          	vmovapd %xmm0,%xmm2
  1d1190:	c5 79 28 9c 24 30 01 	vmovapd 0x130(%rsp),%xmm11
  1d1197:	00 00 
  1d1199:	c4 e2 a1 99 94 24 60 	vfmadd132sd 0x160(%rsp),%xmm11,%xmm2
  1d11a0:	01 00 00 
  1d11a3:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  1d11a8:	c4 41 7b 10 64 f0 08 	vmovsd 0x8(%r8,%rsi,8),%xmm12
  1d11af:	c4 c2 99 a9 54 f2 08 	vfmadd213sd 0x8(%r10,%rsi,8),%xmm12,%xmm2
  1d11b6:	c4 e2 d9 99 84 24 20 	vfmadd132sd 0x120(%rsp),%xmm4,%xmm0
  1d11bd:	01 00 00 
  1d11c0:	c4 c2 e9 a9 c4       	vfmadd213sd %xmm12,%xmm2,%xmm0
  1d11c5:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
  1d11ca:	4c 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%r9
  1d11d1:	00 
  1d11d2:	c4 81 7b 10 4c c8 08 	vmovsd 0x8(%r8,%r9,8),%xmm1
  1d11d9:	c4 e2 f1 b9 fa       	vfmadd231sd %xmm2,%xmm1,%xmm7
  1d11de:	c4 e2 99 b9 e9       	vfmadd231sd %xmm1,%xmm12,%xmm5
  1d11e3:	4c 8b 84 24 08 01 00 	mov    0x108(%rsp),%r8
  1d11ea:	00 
  1d11eb:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  1d11f0:	c4 81 7b 10 4c c1 08 	vmovsd 0x8(%r9,%r8,8),%xmm1
  1d11f7:	c4 e2 f1 b9 f2       	vfmadd231sd %xmm2,%xmm1,%xmm6
  1d11fc:	c4 62 99 b9 c9       	vfmadd231sd %xmm1,%xmm12,%xmm9
  1d1201:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
  1d1206:	c4 c1 7b 10 4c f0 08 	vmovsd 0x8(%r8,%rsi,8),%xmm1
  1d120d:	c4 62 f1 b9 d2       	vfmadd231sd %xmm2,%xmm1,%xmm10
  1d1212:	c4 e2 99 b9 d9       	vfmadd231sd %xmm1,%xmm12,%xmm3
  1d1217:	4c 8b 84 24 10 01 00 	mov    0x110(%rsp),%r8
  1d121e:	00 
  1d121f:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  1d1224:	c4 81 7b 10 4c c1 08 	vmovsd 0x8(%r9,%r8,8),%xmm1
  1d122b:	c4 42 f1 b9 fc       	vfmadd231sd %xmm12,%xmm1,%xmm15
  1d1230:	c4 62 f1 b9 c2       	vfmadd231sd %xmm2,%xmm1,%xmm8
  1d1235:	c4 c1 f9 7e d0       	vmovq  %xmm2,%r8
  1d123a:	c4 c1 7b 11 54 fd 08 	vmovsd %xmm2,0x8(%r13,%rdi,8)
  1d1241:	c4 c1 f9 7e c1       	vmovq  %xmm0,%r9
  1d1246:	c4 c1 7b 11 44 f2 08 	vmovsd %xmm0,0x8(%r10,%rsi,8)
  1d124d:	41 b4 3f             	mov    $0x3f,%r12b
  1d1250:	c4 42 98 f5 c0       	bzhi   %r12,%r8,%r8
  1d1255:	4d 39 f8             	cmp    %r15,%r8
  1d1258:	41 0f 94 c3          	sete   %r11b
  1d125c:	4d 85 c0             	test   %r8,%r8
  1d125f:	41 0f 94 c6          	sete   %r14b
  1d1263:	45 08 de             	or     %r11b,%r14b
  1d1266:	49 01 d0             	add    %rdx,%r8
  1d1269:	49 c1 e8 35          	shr    $0x35,%r8
  1d126d:	41 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8d
  1d1274:	41 0f 92 c0          	setb   %r8b
  1d1278:	45 08 f0             	or     %r14b,%r8b
  1d127b:	c4 42 98 f5 c9       	bzhi   %r12,%r9,%r9
  1d1280:	4d 39 f9             	cmp    %r15,%r9
  1d1283:	41 0f 94 c3          	sete   %r11b
  1d1287:	4d 85 c9             	test   %r9,%r9
  1d128a:	41 0f 94 c6          	sete   %r14b
  1d128e:	45 08 de             	or     %r11b,%r14b
  1d1291:	49 01 d1             	add    %rdx,%r9
  1d1294:	49 c1 e9 35          	shr    $0x35,%r9
  1d1298:	41 81 f9 ff 03 00 00 	cmp    $0x3ff,%r9d
  1d129f:	41 0f 92 c1          	setb   %r9b
  1d12a3:	45 08 f1             	or     %r14b,%r9b
  1d12a6:	45 20 c1             	and    %r8b,%r9b
  1d12a9:	44 20 c8             	and    %r9b,%al
  1d12ac:	83 7c 24 08 02       	cmpl   $0x2,0x8(%rsp)
  1d12b1:	0f 84 35 01 00 00    	je     1d13ec <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x190c>
  1d12b7:	4c 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%r8
  1d12be:	00 
  1d12bf:	4c 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%r9
  1d12c6:	00 
  1d12c7:	c4 81 7b 10 44 c8 10 	vmovsd 0x10(%r8,%r9,8),%xmm0
  1d12ce:	c5 f9 28 d0          	vmovapd %xmm0,%xmm2
  1d12d2:	c4 e2 a1 99 94 24 60 	vfmadd132sd 0x160(%rsp),%xmm11,%xmm2
  1d12d9:	01 00 00 
  1d12dc:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  1d12e1:	c4 41 7b 10 64 f0 10 	vmovsd 0x10(%r8,%rsi,8),%xmm12
  1d12e8:	c4 c2 99 a9 54 f2 10 	vfmadd213sd 0x10(%r10,%rsi,8),%xmm12,%xmm2
  1d12ef:	c4 e2 d9 99 84 24 20 	vfmadd132sd 0x120(%rsp),%xmm4,%xmm0
  1d12f6:	01 00 00 
  1d12f9:	c4 c2 e9 a9 c4       	vfmadd213sd %xmm12,%xmm2,%xmm0
  1d12fe:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
  1d1303:	4c 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%r9
  1d130a:	00 
  1d130b:	c4 81 7b 10 4c c8 10 	vmovsd 0x10(%r8,%r9,8),%xmm1
  1d1312:	c4 e2 f1 b9 fa       	vfmadd231sd %xmm2,%xmm1,%xmm7
  1d1317:	c4 e2 99 b9 e9       	vfmadd231sd %xmm1,%xmm12,%xmm5
  1d131c:	4c 8b 84 24 08 01 00 	mov    0x108(%rsp),%r8
  1d1323:	00 
  1d1324:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  1d1329:	c4 81 7b 10 4c c1 10 	vmovsd 0x10(%r9,%r8,8),%xmm1
  1d1330:	c4 e2 f1 b9 f2       	vfmadd231sd %xmm2,%xmm1,%xmm6
  1d1335:	c4 62 99 b9 c9       	vfmadd231sd %xmm1,%xmm12,%xmm9
  1d133a:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
  1d133f:	c4 c1 7b 10 4c f0 10 	vmovsd 0x10(%r8,%rsi,8),%xmm1
  1d1346:	c4 62 f1 b9 d2       	vfmadd231sd %xmm2,%xmm1,%xmm10
  1d134b:	c4 e2 99 b9 d9       	vfmadd231sd %xmm1,%xmm12,%xmm3
  1d1350:	4c 8b 84 24 10 01 00 	mov    0x110(%rsp),%r8
  1d1357:	00 
  1d1358:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  1d135d:	c4 81 7b 10 4c c1 10 	vmovsd 0x10(%r9,%r8,8),%xmm1
  1d1364:	c4 42 f1 b9 fc       	vfmadd231sd %xmm12,%xmm1,%xmm15
  1d1369:	c4 62 f1 b9 c2       	vfmadd231sd %xmm2,%xmm1,%xmm8
  1d136e:	c4 c1 f9 7e d0       	vmovq  %xmm2,%r8
  1d1373:	c4 c1 7b 11 54 fd 10 	vmovsd %xmm2,0x10(%r13,%rdi,8)
  1d137a:	c4 c1 f9 7e c1       	vmovq  %xmm0,%r9
  1d137f:	c4 c1 7b 11 44 f2 10 	vmovsd %xmm0,0x10(%r10,%rsi,8)
  1d1386:	41 b4 3f             	mov    $0x3f,%r12b
  1d1389:	c4 42 98 f5 c0       	bzhi   %r12,%r8,%r8
  1d138e:	4d 39 f8             	cmp    %r15,%r8
  1d1391:	41 0f 94 c3          	sete   %r11b
  1d1395:	4d 85 c0             	test   %r8,%r8
  1d1398:	41 0f 94 c6          	sete   %r14b
  1d139c:	45 08 de             	or     %r11b,%r14b
  1d139f:	49 01 d0             	add    %rdx,%r8
  1d13a2:	49 c1 e8 35          	shr    $0x35,%r8
  1d13a6:	41 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8d
  1d13ad:	41 0f 92 c0          	setb   %r8b
  1d13b1:	45 08 f0             	or     %r14b,%r8b
  1d13b4:	c4 42 98 f5 c9       	bzhi   %r12,%r9,%r9
  1d13b9:	4d 39 f9             	cmp    %r15,%r9
  1d13bc:	41 0f 94 c3          	sete   %r11b
  1d13c0:	4d 85 c9             	test   %r9,%r9
  1d13c3:	41 0f 94 c6          	sete   %r14b
  1d13c7:	45 08 de             	or     %r11b,%r14b
  1d13ca:	49 01 d1             	add    %rdx,%r9
  1d13cd:	49 c1 e9 35          	shr    $0x35,%r9
  1d13d1:	41 81 f9 ff 03 00 00 	cmp    $0x3ff,%r9d
  1d13d8:	41 0f 92 c1          	setb   %r9b
  1d13dc:	45 08 f1             	or     %r14b,%r9b
  1d13df:	45 20 c1             	and    %r8b,%r9b
  1d13e2:	44 20 c8             	and    %r9b,%al
  1d13e5:	83 7c 24 08 03       	cmpl   $0x3,0x8(%rsp)
  1d13ea:	75 09                	jne    1d13f5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1915>
  1d13ec:	c5 79 28 db          	vmovapd %xmm3,%xmm11
  1d13f0:	e9 47 01 00 00       	jmp    1d153c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1a5c>
  1d13f5:	4c 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%r8
  1d13fc:	00 
  1d13fd:	4c 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%r9
  1d1404:	00 
  1d1405:	c4 81 7b 10 4c c8 18 	vmovsd 0x18(%r8,%r9,8),%xmm1
  1d140c:	c5 f9 28 94 24 60 01 	vmovapd 0x160(%rsp),%xmm2
  1d1413:	00 00 
  1d1415:	c4 c2 f1 a9 d3       	vfmadd213sd %xmm11,%xmm1,%xmm2
  1d141a:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  1d141f:	c4 c1 7b 10 44 f0 18 	vmovsd 0x18(%r8,%rsi,8),%xmm0
  1d1426:	c4 c2 f9 a9 54 f2 18 	vfmadd213sd 0x18(%r10,%rsi,8),%xmm0,%xmm2
  1d142d:	c4 c1 f9 7e d0       	vmovq  %xmm2,%r8
  1d1432:	41 b6 3f             	mov    $0x3f,%r14b
  1d1435:	c4 42 88 f5 c0       	bzhi   %r14,%r8,%r8
  1d143a:	4d 39 f8             	cmp    %r15,%r8
  1d143d:	41 0f 94 c1          	sete   %r9b
  1d1441:	4d 85 c0             	test   %r8,%r8
  1d1444:	41 0f 94 c3          	sete   %r11b
  1d1448:	45 08 cb             	or     %r9b,%r11b
  1d144b:	49 01 d0             	add    %rdx,%r8
  1d144e:	49 c1 e8 35          	shr    $0x35,%r8
  1d1452:	41 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8d
  1d1459:	41 0f 92 c1          	setb   %r9b
  1d145d:	45 08 d9             	or     %r11b,%r9b
  1d1460:	c5 79 28 9c 24 20 01 	vmovapd 0x120(%rsp),%xmm11
  1d1467:	00 00 
  1d1469:	c4 62 f1 a9 dc       	vfmadd213sd %xmm4,%xmm1,%xmm11
  1d146e:	c4 62 e9 a9 d8       	vfmadd213sd %xmm0,%xmm2,%xmm11
  1d1473:	c5 79 29 9c 24 20 01 	vmovapd %xmm11,0x120(%rsp)
  1d147a:	00 00 
  1d147c:	c4 41 f9 7e d8       	vmovq  %xmm11,%r8
  1d1481:	c4 42 88 f5 c0       	bzhi   %r14,%r8,%r8
  1d1486:	4d 39 f8             	cmp    %r15,%r8
  1d1489:	41 0f 94 c6          	sete   %r14b
  1d148d:	4d 85 c0             	test   %r8,%r8
  1d1490:	41 0f 94 c3          	sete   %r11b
  1d1494:	45 08 f3             	or     %r14b,%r11b
  1d1497:	49 01 d0             	add    %rdx,%r8
  1d149a:	49 c1 e8 35          	shr    $0x35,%r8
  1d149e:	41 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8d
  1d14a5:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  1d14aa:	4c 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%r8
  1d14b1:	00 
  1d14b2:	c4 a1 7b 10 4c c2 18 	vmovsd 0x18(%rdx,%r8,8),%xmm1
  1d14b9:	48 8b 94 24 08 01 00 	mov    0x108(%rsp),%rdx
  1d14c0:	00 
  1d14c1:	4c 8b 44 24 28       	mov    0x28(%rsp),%r8
  1d14c6:	c4 c1 7b 10 64 d0 18 	vmovsd 0x18(%r8,%rdx,8),%xmm4
  1d14cd:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  1d14d2:	c5 7b 10 5c f2 18    	vmovsd 0x18(%rdx,%rsi,8),%xmm11
  1d14d8:	48 8b 94 24 10 01 00 	mov    0x110(%rsp),%rdx
  1d14df:	00 
  1d14e0:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
  1d14e5:	c4 41 7b 10 64 d0 18 	vmovsd 0x18(%r8,%rdx,8),%xmm12
  1d14ec:	c4 c1 7b 11 54 fd 18 	vmovsd %xmm2,0x18(%r13,%rdi,8)
  1d14f3:	40 0f 92 c7          	setb   %dil
  1d14f7:	44 08 df             	or     %r11b,%dil
  1d14fa:	44 20 cf             	and    %r9b,%dil
  1d14fd:	40 20 f8             	and    %dil,%al
  1d1500:	c4 e2 f1 b9 fa       	vfmadd231sd %xmm2,%xmm1,%xmm7
  1d1505:	c4 e2 d9 b9 f2       	vfmadd231sd %xmm2,%xmm4,%xmm6
  1d150a:	c4 62 a1 b9 d2       	vfmadd231sd %xmm2,%xmm11,%xmm10
  1d150f:	c4 62 99 b9 c2       	vfmadd231sd %xmm2,%xmm12,%xmm8
  1d1514:	c4 e2 f9 b9 e9       	vfmadd231sd %xmm1,%xmm0,%xmm5
  1d1519:	c4 62 f9 b9 cc       	vfmadd231sd %xmm4,%xmm0,%xmm9
  1d151e:	c4 c2 f9 b9 db       	vfmadd231sd %xmm11,%xmm0,%xmm3
  1d1523:	c5 79 28 db          	vmovapd %xmm3,%xmm11
  1d1527:	c4 62 99 b9 f8       	vfmadd231sd %xmm0,%xmm12,%xmm15
  1d152c:	c5 f9 28 84 24 20 01 	vmovapd 0x120(%rsp),%xmm0
  1d1533:	00 00 
  1d1535:	c4 c1 7b 11 44 f2 18 	vmovsd %xmm0,0x18(%r10,%rsi,8)
  1d153c:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  1d1541:	20 44 24 07          	and    %al,0x7(%rsp)
  1d1545:	4c 8b 9c 24 e8 00 00 	mov    0xe8(%rsp),%r11
  1d154c:	00 
  1d154d:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1d1552:	4c 8b 44 24 70       	mov    0x70(%rsp),%r8
  1d1557:	48 8b bc 24 50 01 00 	mov    0x150(%rsp),%rdi
  1d155e:	00 
  1d155f:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  1d1564:	b2 3f                	mov    $0x3f,%dl
  1d1566:	c5 f9 28 e6          	vmovapd %xmm6,%xmm4
  1d156a:	c4 41 79 28 e1       	vmovapd %xmm9,%xmm12
  1d156f:	c5 79 28 cd          	vmovapd %xmm5,%xmm9
  1d1573:	c5 79 29 c5          	vmovapd %xmm8,%xmm5
  1d1577:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  1d157c:	48 3b 44 24 58       	cmp    0x58(%rsp),%rax
  1d1581:	0f 85 aa 11 00 00    	jne    1d2731 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c51>
  1d1587:	c5 fd 10 84 24 50 02 	vmovupd 0x250(%rsp),%ymm0
  1d158e:	00 00 
  1d1590:	4d 85 c0             	test   %r8,%r8
  1d1593:	0f 84 f7 00 00 00    	je     1d1690 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1bb0>
  1d1599:	49 83 f8 01          	cmp    $0x1,%r8
  1d159d:	75 10                	jne    1d15af <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1acf>
  1d159f:	c5 fd 10 84 24 50 02 	vmovupd 0x250(%rsp),%ymm0
  1d15a6:	00 00 
  1d15a8:	31 c0                	xor    %eax,%eax
  1d15aa:	e9 a1 00 00 00       	jmp    1d1650 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1b70>
  1d15af:	c5 79 29 e6          	vmovapd %xmm12,%xmm6
  1d15b3:	ba 20 00 00 00       	mov    $0x20,%edx
  1d15b8:	c5 fd 10 84 24 50 02 	vmovupd 0x250(%rsp),%ymm0
  1d15bf:	00 00 
  1d15c1:	31 c0                	xor    %eax,%eax
  1d15c3:	c4 e2 7d 19 0d d4 4b 	vbroadcastsd -0x1ab42c(%rip),%ymm1        # 261a0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x4d0>
  1d15ca:	e5 ff 
  1d15cc:	c4 c1 75 54 54 15 e0 	vandpd -0x20(%r13,%rdx,1),%ymm1,%ymm2
  1d15d3:	c4 c1 75 54 5c 12 e0 	vandpd -0x20(%r10,%rdx,1),%ymm1,%ymm3
  1d15da:	c5 15 c2 e2 00       	vcmpeqpd %ymm2,%ymm13,%ymm12
  1d15df:	c4 c1 6d c2 d6 1d    	vcmpge_oqpd %ymm14,%ymm2,%ymm2
  1d15e5:	c5 9d 56 d2          	vorpd  %ymm2,%ymm12,%ymm2
  1d15e9:	c5 ed 54 c0          	vandpd %ymm0,%ymm2,%ymm0
  1d15ed:	c5 95 c2 d3 00       	vcmpeqpd %ymm3,%ymm13,%ymm2
  1d15f2:	c4 c1 65 c2 de 1d    	vcmpge_oqpd %ymm14,%ymm3,%ymm3
  1d15f8:	c5 e5 56 d2          	vorpd  %ymm2,%ymm3,%ymm2
  1d15fc:	c4 c1 75 54 5c 15 00 	vandpd 0x0(%r13,%rdx,1),%ymm1,%ymm3
  1d1603:	c4 c1 75 54 0c 12    	vandpd (%r10,%rdx,1),%ymm1,%ymm1
  1d1609:	48 83 c0 02          	add    $0x2,%rax
  1d160d:	c5 15 c2 e3 00       	vcmpeqpd %ymm3,%ymm13,%ymm12
  1d1612:	c4 c1 65 c2 de 1d    	vcmpge_oqpd %ymm14,%ymm3,%ymm3
  1d1618:	c5 9d 56 db          	vorpd  %ymm3,%ymm12,%ymm3
  1d161c:	c5 e5 54 d2          	vandpd %ymm2,%ymm3,%ymm2
  1d1620:	c5 ed 54 c0          	vandpd %ymm0,%ymm2,%ymm0
  1d1624:	c5 95 c2 d1 00       	vcmpeqpd %ymm1,%ymm13,%ymm2
  1d1629:	c4 c1 75 c2 ce 1d    	vcmpge_oqpd %ymm14,%ymm1,%ymm1
  1d162f:	c5 f5 56 ca          	vorpd  %ymm2,%ymm1,%ymm1
  1d1633:	c5 fd 54 c1          	vandpd %ymm1,%ymm0,%ymm0
  1d1637:	48 83 c2 40          	add    $0x40,%rdx
  1d163b:	48 39 c7             	cmp    %rax,%rdi
  1d163e:	75 83                	jne    1d15c3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1ae3>
  1d1640:	f6 84 24 d0 00 00 00 	testb  $0x4,0xd0(%rsp)
  1d1647:	04 
  1d1648:	b2 3f                	mov    $0x3f,%dl
  1d164a:	c5 79 28 e6          	vmovapd %xmm6,%xmm12
  1d164e:	74 40                	je     1d1690 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1bb0>
  1d1650:	48 c1 e0 05          	shl    $0x5,%rax
  1d1654:	c4 e2 7d 19 0d 43 4b 	vbroadcastsd -0x1ab4bd(%rip),%ymm1        # 261a0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x4d0>
  1d165b:	e5 ff 
  1d165d:	c4 c1 75 54 54 05 00 	vandpd 0x0(%r13,%rax,1),%ymm1,%ymm2
  1d1664:	c4 c1 75 54 0c 02    	vandpd (%r10,%rax,1),%ymm1,%ymm1
  1d166a:	c5 95 c2 da 00       	vcmpeqpd %ymm2,%ymm13,%ymm3
  1d166f:	c4 c1 6d c2 d6 1d    	vcmpge_oqpd %ymm14,%ymm2,%ymm2
  1d1675:	c5 ed 56 d3          	vorpd  %ymm3,%ymm2,%ymm2
  1d1679:	c5 95 c2 d9 00       	vcmpeqpd %ymm1,%ymm13,%ymm3
  1d167e:	c4 c1 75 c2 ce 1d    	vcmpge_oqpd %ymm14,%ymm1,%ymm1
  1d1684:	c5 f5 56 cb          	vorpd  %ymm3,%ymm1,%ymm1
  1d1688:	c5 ed 54 c9          	vandpd %ymm1,%ymm2,%ymm1
  1d168c:	c5 f5 54 c0          	vandpd %ymm0,%ymm1,%ymm0
  1d1690:	c4 e2 15 37 c0       	vpcmpgtq %ymm0,%ymm13,%ymm0
  1d1695:	c4 e2 7d 59 0d 0a 4b 	vpbroadcastq -0x1ab4f6(%rip),%ymm1        # 261a8 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x4d8>
  1d169c:	e5 ff 
  1d169e:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
  1d16a2:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
  1d16a8:	c5 f9 5d c1          	vminpd %xmm1,%xmm0,%xmm0
  1d16ac:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d16b1:	c5 fb 5d c1          	vminsd %xmm1,%xmm0,%xmm0
  1d16b5:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1d16b9:	c5 f9 2e c1          	vucomisd %xmm1,%xmm0
  1d16bd:	0f 86 6e 10 00 00    	jbe    1d2731 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c51>
  1d16c3:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
  1d16c9:	74 7f                	je     1d174a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1c6a>
  1d16cb:	4c 8b 4c 24 78       	mov    0x78(%rsp),%r9
  1d16d0:	c4 82 e8 f5 44 cd 00 	bzhi   %rdx,0x0(%r13,%r9,8),%rax
  1d16d7:	4c 39 f8             	cmp    %r15,%rax
  1d16da:	41 b7 3f             	mov    $0x3f,%r15b
  1d16dd:	0f 95 c2             	setne  %dl
  1d16e0:	48 85 c0             	test   %rax,%rax
  1d16e3:	40 0f 95 c7          	setne  %dil
  1d16e7:	40 20 d7             	and    %dl,%dil
  1d16ea:	48 ba 00 00 00 00 00 	movabs $0xfff0000000000000,%rdx
  1d16f1:	00 f0 ff 
  1d16f4:	48 01 d0             	add    %rdx,%rax
  1d16f7:	48 c1 e8 35          	shr    $0x35,%rax
  1d16fb:	3d ff 03 00 00       	cmp    $0x3ff,%eax
  1d1700:	0f 93 c0             	setae  %al
  1d1703:	40 84 c7             	test   %al,%dil
  1d1706:	75 31                	jne    1d1739 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1c59>
  1d1708:	c4 82 80 f5 04 ca    	bzhi   %r15,(%r10,%r9,8),%rax
  1d170e:	48 ba 01 00 00 00 00 	movabs $0x7ff0000000000001,%rdx
  1d1715:	00 f0 7f 
  1d1718:	48 39 d0             	cmp    %rdx,%rax
  1d171b:	0f 9c c2             	setl   %dl
  1d171e:	48 ff c8             	dec    %rax
  1d1721:	48 bf fe ff ff ff ff 	movabs $0xffffffffffffe,%rdi
  1d1728:	ff 0f 00 
  1d172b:	48 39 f8             	cmp    %rdi,%rax
  1d172e:	0f 97 c0             	seta   %al
  1d1731:	84 d0                	test   %dl,%al
  1d1733:	0f 85 6a 05 00 00    	jne    1d1ca3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x21c3>
  1d1739:	31 c0                	xor    %eax,%eax
  1d173b:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  1d1740:	3b 44 24 08          	cmp    0x8(%rsp),%eax
  1d1744:	0f 82 e7 0f 00 00    	jb     1d2731 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c51>
  1d174a:	48 8d 3c 36          	lea    (%rsi,%rsi,1),%rdi
  1d174e:	4c 39 f7             	cmp    %r14,%rdi
  1d1751:	0f 83 0c 11 00 00    	jae    1d2863 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d83>
  1d1757:	48 89 fa             	mov    %rdi,%rdx
  1d175a:	48 c1 e2 04          	shl    $0x4,%rdx
  1d175e:	c4 41 7b 11 3c 13    	vmovsd %xmm15,(%r11,%rdx,1)
  1d1764:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  1d176b:	00 
  1d176c:	48 8d 04 70          	lea    (%rax,%rsi,2),%rax
  1d1770:	c4 41 7b 11 5c 13 08 	vmovsd %xmm11,0x8(%r11,%rdx,1)
  1d1777:	48 3b 44 24 60       	cmp    0x60(%rsp),%rax
  1d177c:	4d 89 c7             	mov    %r8,%r15
  1d177f:	c5 7d 10 bc 24 50 02 	vmovupd 0x250(%rsp),%ymm15
  1d1786:	00 00 
  1d1788:	73 24                	jae    1d17ae <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1cce>
  1d178a:	49 89 c0             	mov    %rax,%r8
  1d178d:	48 8d 47 01          	lea    0x1(%rdi),%rax
  1d1791:	4c 39 f0             	cmp    %r14,%rax
  1d1794:	0f 83 25 11 00 00    	jae    1d28bf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2ddf>
  1d179a:	48 c1 e0 04          	shl    $0x4,%rax
  1d179e:	c4 41 7b 11 24 03    	vmovsd %xmm12,(%r11,%rax,1)
  1d17a4:	c4 41 7b 11 4c 03 08 	vmovsd %xmm9,0x8(%r11,%rax,1)
  1d17ab:	4c 89 c0             	mov    %r8,%rax
  1d17ae:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  1d17b3:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  1d17ba:	00 
  1d17bb:	48 83 c0 02          	add    $0x2,%rax
  1d17bf:	48 89 c2             	mov    %rax,%rdx
  1d17c2:	48 2b 94 24 58 01 00 	sub    0x158(%rsp),%rdx
  1d17c9:	00 
  1d17ca:	4c 39 f2             	cmp    %r14,%rdx
  1d17cd:	0f 83 be 10 00 00    	jae    1d2891 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2db1>
  1d17d3:	49 89 d0             	mov    %rdx,%r8
  1d17d6:	49 c1 e0 04          	shl    $0x4,%r8
  1d17da:	c4 81 7b 11 2c 03    	vmovsd %xmm5,(%r11,%r8,1)
  1d17e0:	4c 89 84 24 30 01 00 	mov    %r8,0x130(%rsp)
  1d17e7:	00 
  1d17e8:	c4 01 7b 11 54 03 08 	vmovsd %xmm10,0x8(%r11,%r8,1)
  1d17ef:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
  1d17f4:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  1d17fb:	00 
  1d17fc:	4c 39 c0             	cmp    %r8,%rax
  1d17ff:	73 1e                	jae    1d181f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1d3f>
  1d1801:	48 8d 42 01          	lea    0x1(%rdx),%rax
  1d1805:	4c 39 f0             	cmp    %r14,%rax
  1d1808:	0f 83 b1 10 00 00    	jae    1d28bf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2ddf>
  1d180e:	48 c1 e0 04          	shl    $0x4,%rax
  1d1812:	c4 c1 7b 11 24 03    	vmovsd %xmm4,(%r11,%rax,1)
  1d1818:	c4 c1 7b 11 7c 03 08 	vmovsd %xmm7,0x8(%r11,%rax,1)
  1d181f:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1d1823:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  1d182a:	00 
  1d182b:	48 85 c0             	test   %rax,%rax
  1d182e:	74 2d                	je     1d185d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1d7d>
  1d1830:	48 83 f8 01          	cmp    $0x1,%rax
  1d1834:	75 4c                	jne    1d1882 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1da2>
  1d1836:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1d183a:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1d183e:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1d1842:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1d1847:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1d184c:	31 c0                	xor    %eax,%eax
  1d184e:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1d1853:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1d1858:	e9 26 01 00 00       	jmp    1d1983 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1ea3>
  1d185d:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1d1861:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1d1865:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1d1869:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1d186e:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1d1873:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1d1878:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1d187d:	e9 61 01 00 00       	jmp    1d19e3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1f03>
  1d1882:	4d 89 ce             	mov    %r9,%r14
  1d1885:	41 b9 20 00 00 00    	mov    $0x20,%r9d
  1d188b:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1d188f:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1d1893:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1d1897:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1d189c:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1d18a1:	31 c0                	xor    %eax,%eax
  1d18a3:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1d18a8:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1d18ad:	4c 8b bc 24 90 00 00 	mov    0x90(%rsp),%r15
  1d18b4:	00 
  1d18b5:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  1d18ba:	c4 a1 7d 10 44 0b e0 	vmovupd -0x20(%rbx,%r9,1),%ymm0
  1d18c1:	c4 a1 7d 10 4c 0f e0 	vmovupd -0x20(%rdi,%r9,1),%ymm1
  1d18c8:	c4 62 fd b8 d9       	vfmadd231pd %ymm1,%ymm0,%ymm11
  1d18cd:	c4 81 7d 10 54 0f e0 	vmovupd -0x20(%r15,%r9,1),%ymm2
  1d18d4:	c4 62 ed b8 d1       	vfmadd231pd %ymm1,%ymm2,%ymm10
  1d18d9:	c4 a1 7d 10 5c 09 e0 	vmovupd -0x20(%rcx,%r9,1),%ymm3
  1d18e0:	c4 62 e5 b8 c1       	vfmadd231pd %ymm1,%ymm3,%ymm8
  1d18e5:	c4 21 7d 10 64 0d e0 	vmovupd -0x20(%rbp,%r9,1),%ymm12
  1d18ec:	c4 e2 9d b8 f9       	vfmadd231pd %ymm1,%ymm12,%ymm7
  1d18f1:	c4 81 7d 10 4c 0d e0 	vmovupd -0x20(%r13,%r9,1),%ymm1
  1d18f8:	c4 62 f5 b8 c8       	vfmadd231pd %ymm0,%ymm1,%ymm9
  1d18fd:	c4 a1 7d 10 04 0b    	vmovupd (%rbx,%r9,1),%ymm0
  1d1903:	c4 e2 f5 b8 f2       	vfmadd231pd %ymm2,%ymm1,%ymm6
  1d1908:	c4 a1 7d 10 14 0f    	vmovupd (%rdi,%r9,1),%ymm2
  1d190e:	c4 e2 f5 b8 eb       	vfmadd231pd %ymm3,%ymm1,%ymm5
  1d1913:	c4 81 7d 10 1c 0f    	vmovupd (%r15,%r9,1),%ymm3
  1d1919:	c4 e2 9d b8 e1       	vfmadd231pd %ymm1,%ymm12,%ymm4
  1d191e:	c4 a1 7d 10 0c 09    	vmovupd (%rcx,%r9,1),%ymm1
  1d1924:	c4 21 7d 10 64 0d 00 	vmovupd 0x0(%rbp,%r9,1),%ymm12
  1d192b:	c4 62 fd b8 da       	vfmadd231pd %ymm2,%ymm0,%ymm11
  1d1930:	c4 62 e5 b8 d2       	vfmadd231pd %ymm2,%ymm3,%ymm10
  1d1935:	c4 62 f5 b8 c2       	vfmadd231pd %ymm2,%ymm1,%ymm8
  1d193a:	c4 e2 9d b8 fa       	vfmadd231pd %ymm2,%ymm12,%ymm7
  1d193f:	c4 81 7d 10 54 0d 00 	vmovupd 0x0(%r13,%r9,1),%ymm2
  1d1946:	c4 62 ed b8 c8       	vfmadd231pd %ymm0,%ymm2,%ymm9
  1d194b:	c4 e2 ed b8 f3       	vfmadd231pd %ymm3,%ymm2,%ymm6
  1d1950:	c4 e2 ed b8 e9       	vfmadd231pd %ymm1,%ymm2,%ymm5
  1d1955:	c4 e2 9d b8 e2       	vfmadd231pd %ymm2,%ymm12,%ymm4
  1d195a:	48 83 c0 02          	add    $0x2,%rax
  1d195e:	49 83 c1 40          	add    $0x40,%r9
  1d1962:	49 39 c6             	cmp    %rax,%r14
  1d1965:	0f 85 4f ff ff ff    	jne    1d18ba <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1dda>
  1d196b:	f6 84 24 98 00 00 00 	testb  $0x1,0x98(%rsp)
  1d1972:	01 
  1d1973:	4c 8b 7c 24 70       	mov    0x70(%rsp),%r15
  1d1978:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  1d197d:	48 8d 3c 36          	lea    (%rsi,%rsi,1),%rdi
  1d1981:	74 60                	je     1d19e3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1f03>
  1d1983:	48 c1 e0 05          	shl    $0x5,%rax
  1d1987:	c5 fd 10 04 03       	vmovupd (%rbx,%rax,1),%ymm0
  1d198c:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  1d1991:	c5 fd 10 0c 06       	vmovupd (%rsi,%rax,1),%ymm1
  1d1996:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1d199b:	c4 62 fd b8 d9       	vfmadd231pd %ymm1,%ymm0,%ymm11
  1d19a0:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
  1d19a7:	00 
  1d19a8:	c4 c1 7d 10 14 01    	vmovupd (%r9,%rax,1),%ymm2
  1d19ae:	c4 62 ed b8 d1       	vfmadd231pd %ymm1,%ymm2,%ymm10
  1d19b3:	c5 fd 10 1c 01       	vmovupd (%rcx,%rax,1),%ymm3
  1d19b8:	c4 62 e5 b8 c1       	vfmadd231pd %ymm1,%ymm3,%ymm8
  1d19bd:	c5 7d 10 64 05 00    	vmovupd 0x0(%rbp,%rax,1),%ymm12
  1d19c3:	c4 e2 9d b8 f9       	vfmadd231pd %ymm1,%ymm12,%ymm7
  1d19c8:	c4 c1 7d 10 4c 05 00 	vmovupd 0x0(%r13,%rax,1),%ymm1
  1d19cf:	c4 62 f5 b8 c8       	vfmadd231pd %ymm0,%ymm1,%ymm9
  1d19d4:	c4 e2 f5 b8 f2       	vfmadd231pd %ymm2,%ymm1,%ymm6
  1d19d9:	c4 e2 f5 b8 eb       	vfmadd231pd %ymm3,%ymm1,%ymm5
  1d19de:	c4 e2 9d b8 e1       	vfmadd231pd %ymm1,%ymm12,%ymm4
  1d19e3:	c4 63 7d 19 d8 01    	vextractf128 $0x1,%ymm11,%xmm0
  1d19e9:	c5 a1 58 c0          	vaddpd %xmm0,%xmm11,%xmm0
  1d19ed:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d19f2:	c5 7b 58 d9          	vaddsd %xmm1,%xmm0,%xmm11
  1d19f6:	c4 63 7d 19 d0 01    	vextractf128 $0x1,%ymm10,%xmm0
  1d19fc:	c5 a9 58 c0          	vaddpd %xmm0,%xmm10,%xmm0
  1d1a00:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d1a05:	c5 7b 58 e1          	vaddsd %xmm1,%xmm0,%xmm12
  1d1a09:	c4 63 7d 19 c0 01    	vextractf128 $0x1,%ymm8,%xmm0
  1d1a0f:	c5 b9 58 c0          	vaddpd %xmm0,%xmm8,%xmm0
  1d1a13:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d1a18:	c5 7b 58 c1          	vaddsd %xmm1,%xmm0,%xmm8
  1d1a1c:	c4 e3 7d 19 f8 01    	vextractf128 $0x1,%ymm7,%xmm0
  1d1a22:	c5 c1 58 c0          	vaddpd %xmm0,%xmm7,%xmm0
  1d1a26:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d1a2b:	c5 7b 58 d1          	vaddsd %xmm1,%xmm0,%xmm10
  1d1a2f:	c4 63 7d 19 c8 01    	vextractf128 $0x1,%ymm9,%xmm0
  1d1a35:	c5 b1 58 c0          	vaddpd %xmm0,%xmm9,%xmm0
  1d1a39:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d1a3e:	c5 fb 58 f9          	vaddsd %xmm1,%xmm0,%xmm7
  1d1a42:	c4 e3 7d 19 f0 01    	vextractf128 $0x1,%ymm6,%xmm0
  1d1a48:	c5 c9 58 c0          	vaddpd %xmm0,%xmm6,%xmm0
  1d1a4c:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d1a51:	c5 fb 58 f1          	vaddsd %xmm1,%xmm0,%xmm6
  1d1a55:	c4 e3 7d 19 e8 01    	vextractf128 $0x1,%ymm5,%xmm0
  1d1a5b:	c5 d1 58 c0          	vaddpd %xmm0,%xmm5,%xmm0
  1d1a5f:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d1a64:	c5 fb 58 e9          	vaddsd %xmm1,%xmm0,%xmm5
  1d1a68:	c4 e3 7d 19 e0 01    	vextractf128 $0x1,%ymm4,%xmm0
  1d1a6e:	c5 d9 58 c0          	vaddpd %xmm0,%xmm4,%xmm0
  1d1a72:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d1a77:	c5 fb 58 e1          	vaddsd %xmm1,%xmm0,%xmm4
  1d1a7b:	48 83 bc 24 b0 00 00 	cmpq   $0x0,0xb0(%rsp)
  1d1a82:	00 00 
  1d1a84:	0f 84 53 01 00 00    	je     1d1bdd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x20fd>
  1d1a8a:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
  1d1a8f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  1d1a94:	48 3b 84 24 88 01 00 	cmp    0x188(%rsp),%rax
  1d1a9b:	00 
  1d1a9c:	0f 86 5c 0e 00 00    	jbe    1d28fe <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2e1e>
  1d1aa2:	4d 89 f8             	mov    %r15,%r8
  1d1aa5:	4c 8b bc 24 00 01 00 	mov    0x100(%rsp),%r15
  1d1aac:	00 
  1d1aad:	c4 a1 7b 10 04 fb    	vmovsd (%rbx,%r15,8),%xmm0
  1d1ab3:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  1d1ab8:	4c 8b 4c 24 78       	mov    0x78(%rsp),%r9
  1d1abd:	c4 a1 7b 10 0c cf    	vmovsd (%rdi,%r9,8),%xmm1
  1d1ac3:	c4 62 f9 b9 d9       	vfmadd231sd %xmm1,%xmm0,%xmm11
  1d1ac8:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  1d1acf:	00 
  1d1ad0:	c4 a1 7b 10 14 f8    	vmovsd (%rax,%r15,8),%xmm2
  1d1ad6:	c4 62 e9 b9 e1       	vfmadd231sd %xmm1,%xmm2,%xmm12
  1d1adb:	c4 a1 7b 10 1c f9    	vmovsd (%rcx,%r15,8),%xmm3
  1d1ae1:	c4 62 e1 b9 c1       	vfmadd231sd %xmm1,%xmm3,%xmm8
  1d1ae6:	c4 21 7b 10 4c fd 00 	vmovsd 0x0(%rbp,%r15,8),%xmm9
  1d1aed:	c4 62 b1 b9 d1       	vfmadd231sd %xmm1,%xmm9,%xmm10
  1d1af2:	c4 81 7b 10 4c cd 00 	vmovsd 0x0(%r13,%r9,8),%xmm1
  1d1af9:	c4 e2 f1 b9 f8       	vfmadd231sd %xmm0,%xmm1,%xmm7
  1d1afe:	c4 e2 f1 b9 f2       	vfmadd231sd %xmm2,%xmm1,%xmm6
  1d1b03:	c4 e2 f1 b9 eb       	vfmadd231sd %xmm3,%xmm1,%xmm5
  1d1b08:	c4 e2 b1 b9 e1       	vfmadd231sd %xmm1,%xmm9,%xmm4
  1d1b0d:	4c 8b b4 24 b0 00 00 	mov    0xb0(%rsp),%r14
  1d1b14:	00 
  1d1b15:	41 83 fe 01          	cmp    $0x1,%r14d
  1d1b19:	0f 84 aa 00 00 00    	je     1d1bc9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x20e9>
  1d1b1f:	c4 a1 7b 10 44 fb 08 	vmovsd 0x8(%rbx,%r15,8),%xmm0
  1d1b26:	c4 a1 7b 10 4c cf 08 	vmovsd 0x8(%rdi,%r9,8),%xmm1
  1d1b2d:	c4 62 f9 b9 d9       	vfmadd231sd %xmm1,%xmm0,%xmm11
  1d1b32:	c4 a1 7b 10 54 f8 08 	vmovsd 0x8(%rax,%r15,8),%xmm2
  1d1b39:	c4 62 e9 b9 e1       	vfmadd231sd %xmm1,%xmm2,%xmm12
  1d1b3e:	c4 a1 7b 10 5c f9 08 	vmovsd 0x8(%rcx,%r15,8),%xmm3
  1d1b45:	c4 62 e1 b9 c1       	vfmadd231sd %xmm1,%xmm3,%xmm8
  1d1b4a:	c4 21 7b 10 4c fd 08 	vmovsd 0x8(%rbp,%r15,8),%xmm9
  1d1b51:	c4 62 b1 b9 d1       	vfmadd231sd %xmm1,%xmm9,%xmm10
  1d1b56:	c4 81 7b 10 4c cd 08 	vmovsd 0x8(%r13,%r9,8),%xmm1
  1d1b5d:	c4 e2 f1 b9 f8       	vfmadd231sd %xmm0,%xmm1,%xmm7
  1d1b62:	c4 e2 f1 b9 f2       	vfmadd231sd %xmm2,%xmm1,%xmm6
  1d1b67:	c4 e2 f1 b9 eb       	vfmadd231sd %xmm3,%xmm1,%xmm5
  1d1b6c:	c4 e2 b1 b9 e1       	vfmadd231sd %xmm1,%xmm9,%xmm4
  1d1b71:	41 83 fe 02          	cmp    $0x2,%r14d
  1d1b75:	74 52                	je     1d1bc9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x20e9>
  1d1b77:	c4 a1 7b 10 44 fb 10 	vmovsd 0x10(%rbx,%r15,8),%xmm0
  1d1b7e:	c4 a1 7b 10 4c cf 10 	vmovsd 0x10(%rdi,%r9,8),%xmm1
  1d1b85:	c4 62 f9 b9 d9       	vfmadd231sd %xmm1,%xmm0,%xmm11
  1d1b8a:	c4 a1 7b 10 54 f8 10 	vmovsd 0x10(%rax,%r15,8),%xmm2
  1d1b91:	c4 62 e9 b9 e1       	vfmadd231sd %xmm1,%xmm2,%xmm12
  1d1b96:	c4 a1 7b 10 5c f9 10 	vmovsd 0x10(%rcx,%r15,8),%xmm3
  1d1b9d:	c4 62 e1 b9 c1       	vfmadd231sd %xmm1,%xmm3,%xmm8
  1d1ba2:	c4 21 7b 10 4c fd 10 	vmovsd 0x10(%rbp,%r15,8),%xmm9
  1d1ba9:	c4 62 b1 b9 d1       	vfmadd231sd %xmm1,%xmm9,%xmm10
  1d1bae:	c4 81 7b 10 4c cd 10 	vmovsd 0x10(%r13,%r9,8),%xmm1
  1d1bb5:	c4 e2 f1 b9 f8       	vfmadd231sd %xmm0,%xmm1,%xmm7
  1d1bba:	c4 e2 f1 b9 f2       	vfmadd231sd %xmm2,%xmm1,%xmm6
  1d1bbf:	c4 e2 f1 b9 eb       	vfmadd231sd %xmm3,%xmm1,%xmm5
  1d1bc4:	c4 e2 b1 b9 e1       	vfmadd231sd %xmm1,%xmm9,%xmm4
  1d1bc9:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
  1d1bce:	4d 89 c7             	mov    %r8,%r15
  1d1bd1:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
  1d1bd6:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  1d1bdb:	eb 03                	jmp    1d1be0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2100>
  1d1bdd:	4d 89 f4             	mov    %r14,%r12
  1d1be0:	48 3b 7c 24 68       	cmp    0x68(%rsp),%rdi
  1d1be5:	0f 83 bf 0c 00 00    	jae    1d28aa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2dca>
  1d1beb:	4d 89 c1             	mov    %r8,%r9
  1d1bee:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  1d1bf5:	00 
  1d1bf6:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  1d1bfb:	c4 21 7b 11 1c 00    	vmovsd %xmm11,(%rax,%r8,1)
  1d1c01:	c4 21 7b 11 64 00 08 	vmovsd %xmm12,0x8(%rax,%r8,1)
  1d1c08:	4d 89 c8             	mov    %r9,%r8
  1d1c0b:	4c 39 8c 24 20 01 00 	cmp    %r9,0x120(%rsp)
  1d1c12:	00 
  1d1c13:	4d 89 e6             	mov    %r12,%r14
  1d1c16:	4c 8b a4 24 a0 00 00 	mov    0xa0(%rsp),%r12
  1d1c1d:	00 
  1d1c1e:	73 25                	jae    1d1c45 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2165>
  1d1c20:	48 ff c7             	inc    %rdi
  1d1c23:	48 3b 7c 24 68       	cmp    0x68(%rsp),%rdi
  1d1c28:	0f 83 2c 0d 00 00    	jae    1d295a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2e7a>
  1d1c2e:	48 c1 e7 04          	shl    $0x4,%rdi
  1d1c32:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  1d1c39:	00 
  1d1c3a:	c5 7b 11 04 38       	vmovsd %xmm8,(%rax,%rdi,1)
  1d1c3f:	c5 7b 11 54 38 08    	vmovsd %xmm10,0x8(%rax,%rdi,1)
  1d1c45:	48 3b 54 24 68       	cmp    0x68(%rsp),%rdx
  1d1c4a:	0f 83 26 0c 00 00    	jae    1d2876 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d96>
  1d1c50:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  1d1c57:	00 
  1d1c58:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
  1d1c5f:	00 
  1d1c60:	c5 fb 11 3c 38       	vmovsd %xmm7,(%rax,%rdi,1)
  1d1c65:	c5 fb 11 74 38 08    	vmovsd %xmm6,0x8(%rax,%rdi,1)
  1d1c6b:	4c 39 84 24 60 01 00 	cmp    %r8,0x160(%rsp)
  1d1c72:	00 
  1d1c73:	0f 83 96 f0 ff ff    	jae    1d0d0f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x122f>
  1d1c79:	48 ff c2             	inc    %rdx
  1d1c7c:	48 3b 54 24 68       	cmp    0x68(%rsp),%rdx
  1d1c81:	0f 83 e8 0c 00 00    	jae    1d296f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2e8f>
  1d1c87:	48 c1 e2 04          	shl    $0x4,%rdx
  1d1c8b:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  1d1c92:	00 
  1d1c93:	c5 fb 11 2c 10       	vmovsd %xmm5,(%rax,%rdx,1)
  1d1c98:	c5 fb 11 64 10 08    	vmovsd %xmm4,0x8(%rax,%rdx,1)
  1d1c9e:	e9 6c f0 ff ff       	jmp    1d0d0f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x122f>
  1d1ca3:	83 7c 24 08 01       	cmpl   $0x1,0x8(%rsp)
  1d1ca8:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  1d1cad:	b0 3f                	mov    $0x3f,%al
  1d1caf:	49 bf 00 00 00 00 00 	movabs $0x7ff0000000000000,%r15
  1d1cb6:	00 f0 7f 
  1d1cb9:	0f 84 8b fa ff ff    	je     1d174a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1c6a>
  1d1cbf:	4c 8b 4c 24 78       	mov    0x78(%rsp),%r9
  1d1cc4:	c4 82 f8 f5 44 cd 08 	bzhi   %rax,0x8(%r13,%r9,8),%rax
  1d1ccb:	4c 39 f8             	cmp    %r15,%rax
  1d1cce:	0f 95 c2             	setne  %dl
  1d1cd1:	48 85 c0             	test   %rax,%rax
  1d1cd4:	40 0f 95 c7          	setne  %dil
  1d1cd8:	40 20 d7             	and    %dl,%dil
  1d1cdb:	48 ba 00 00 00 00 00 	movabs $0xfff0000000000000,%rdx
  1d1ce2:	00 f0 ff 
  1d1ce5:	48 01 d0             	add    %rdx,%rax
  1d1ce8:	48 c1 e8 35          	shr    $0x35,%rax
  1d1cec:	3d ff 03 00 00       	cmp    $0x3ff,%eax
  1d1cf1:	0f 93 c2             	setae  %dl
  1d1cf4:	b8 01 00 00 00       	mov    $0x1,%eax
  1d1cf9:	40 84 d7             	test   %dl,%dil
  1d1cfc:	0f 85 39 fa ff ff    	jne    1d173b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1c5b>
  1d1d02:	b2 3f                	mov    $0x3f,%dl
  1d1d04:	c4 82 e8 f5 54 ca 08 	bzhi   %rdx,0x8(%r10,%r9,8),%rdx
  1d1d0b:	4c 39 fa             	cmp    %r15,%rdx
  1d1d0e:	40 0f 9f c7          	setg   %dil
  1d1d12:	48 ff ca             	dec    %rdx
  1d1d15:	49 b9 ff ff ff ff ff 	movabs $0xfffffffffffff,%r9
  1d1d1c:	ff 0f 00 
  1d1d1f:	4c 39 ca             	cmp    %r9,%rdx
  1d1d22:	0f 92 c2             	setb   %dl
  1d1d25:	40 08 fa             	or     %dil,%dl
  1d1d28:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  1d1d2d:	b2 3f                	mov    $0x3f,%dl
  1d1d2f:	0f 85 0b fa ff ff    	jne    1d1740 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1c60>
  1d1d35:	83 7c 24 08 02       	cmpl   $0x2,0x8(%rsp)
  1d1d3a:	0f 84 0a fa ff ff    	je     1d174a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1c6a>
  1d1d40:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  1d1d45:	c4 c2 e8 f5 44 c5 10 	bzhi   %rdx,0x10(%r13,%rax,8),%rax
  1d1d4c:	4c 39 f8             	cmp    %r15,%rax
  1d1d4f:	0f 95 c2             	setne  %dl
  1d1d52:	48 85 c0             	test   %rax,%rax
  1d1d55:	40 0f 95 c7          	setne  %dil
  1d1d59:	40 20 d7             	and    %dl,%dil
  1d1d5c:	48 ba 00 00 00 00 00 	movabs $0xfff0000000000000,%rdx
  1d1d63:	00 f0 ff 
  1d1d66:	48 01 d0             	add    %rdx,%rax
  1d1d69:	48 c1 e8 35          	shr    $0x35,%rax
  1d1d6d:	3d ff 03 00 00       	cmp    $0x3ff,%eax
  1d1d72:	0f 93 c2             	setae  %dl
  1d1d75:	b8 02 00 00 00       	mov    $0x2,%eax
  1d1d7a:	40 84 d7             	test   %dl,%dil
  1d1d7d:	0f 85 bd f9 ff ff    	jne    1d1740 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1c60>
  1d1d83:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  1d1d88:	40 b7 3f             	mov    $0x3f,%dil
  1d1d8b:	c4 c2 c0 f5 54 d2 10 	bzhi   %rdi,0x10(%r10,%rdx,8),%rdx
  1d1d92:	4c 39 fa             	cmp    %r15,%rdx
  1d1d95:	40 0f 9f c7          	setg   %dil
  1d1d99:	48 ff ca             	dec    %rdx
  1d1d9c:	49 bf ff ff ff ff ff 	movabs $0xfffffffffffff,%r15
  1d1da3:	ff 0f 00 
  1d1da6:	4c 39 fa             	cmp    %r15,%rdx
  1d1da9:	0f 92 c2             	setb   %dl
  1d1dac:	40 08 fa             	or     %dil,%dl
  1d1daf:	0f 85 8b f9 ff ff    	jne    1d1740 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1c60>
  1d1db5:	e9 90 f9 ff ff       	jmp    1d174a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x1c6a>
  1d1dba:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1d1dbf:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1d1dc3:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1d1dc7:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1d1dcb:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1d1dcf:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1d1dd3:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1d1dd7:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1d1ddb:	4c 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%r15
  1d1de2:	00 
  1d1de3:	e9 57 01 00 00       	jmp    1d1f3f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x245f>
  1d1de8:	4c 89 a4 24 48 01 00 	mov    %r12,0x148(%rsp)
  1d1def:	00 
  1d1df0:	49 89 c0             	mov    %rax,%r8
  1d1df3:	49 21 f8             	and    %rdi,%r8
  1d1df6:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1d1dfa:	41 b9 60 00 00 00    	mov    $0x60,%r9d
  1d1e00:	31 ff                	xor    %edi,%edi
  1d1e02:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1d1e06:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1d1e0a:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1d1e0e:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1d1e12:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1d1e16:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1d1e1a:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1d1e1f:	4c 8b 7c 24 38       	mov    0x38(%rsp),%r15
  1d1e24:	49 89 cc             	mov    %rcx,%r12
  1d1e27:	48 89 f1             	mov    %rsi,%rcx
  1d1e2a:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1d1e2f:	c4 81 7d 10 44 0a a0 	vmovupd -0x60(%r10,%r9,1),%ymm0
  1d1e36:	c4 01 7d 10 4c 0a c0 	vmovupd -0x40(%r10,%r9,1),%ymm9
  1d1e3d:	c4 01 7d 10 54 0a e0 	vmovupd -0x20(%r10,%r9,1),%ymm10
  1d1e44:	c4 82 fd b8 64 0f a0 	vfmadd231pd -0x60(%r15,%r9,1),%ymm0,%ymm4
  1d1e4b:	c4 a2 fd b8 6c 0e a0 	vfmadd231pd -0x60(%rsi,%r9,1),%ymm0,%ymm5
  1d1e52:	c4 a2 fd b8 74 09 a0 	vfmadd231pd -0x60(%rcx,%r9,1),%ymm0,%ymm6
  1d1e59:	c4 82 fd b8 7c 0c a0 	vfmadd231pd -0x60(%r12,%r9,1),%ymm0,%ymm7
  1d1e60:	c4 82 b5 b8 54 0f c0 	vfmadd231pd -0x40(%r15,%r9,1),%ymm9,%ymm2
  1d1e67:	c4 a2 b5 b8 5c 0e c0 	vfmadd231pd -0x40(%rsi,%r9,1),%ymm9,%ymm3
  1d1e6e:	c4 a2 b5 b8 4c 09 c0 	vfmadd231pd -0x40(%rcx,%r9,1),%ymm9,%ymm1
  1d1e75:	c4 02 b5 b8 44 0c c0 	vfmadd231pd -0x40(%r12,%r9,1),%ymm9,%ymm8
  1d1e7c:	c4 81 7d 10 04 0a    	vmovupd (%r10,%r9,1),%ymm0
  1d1e82:	48 83 c7 02          	add    $0x2,%rdi
  1d1e86:	c4 82 ad b8 64 0f e0 	vfmadd231pd -0x20(%r15,%r9,1),%ymm10,%ymm4
  1d1e8d:	c4 a2 ad b8 6c 0e e0 	vfmadd231pd -0x20(%rsi,%r9,1),%ymm10,%ymm5
  1d1e94:	c4 a2 ad b8 74 09 e0 	vfmadd231pd -0x20(%rcx,%r9,1),%ymm10,%ymm6
  1d1e9b:	c4 82 ad b8 7c 0c e0 	vfmadd231pd -0x20(%r12,%r9,1),%ymm10,%ymm7
  1d1ea2:	c4 82 fd b8 14 0f    	vfmadd231pd (%r15,%r9,1),%ymm0,%ymm2
  1d1ea8:	c4 a2 fd b8 1c 0e    	vfmadd231pd (%rsi,%r9,1),%ymm0,%ymm3
  1d1eae:	c4 a2 fd b8 0c 09    	vfmadd231pd (%rcx,%r9,1),%ymm0,%ymm1
  1d1eb4:	c4 02 fd b8 04 0c    	vfmadd231pd (%r12,%r9,1),%ymm0,%ymm8
  1d1eba:	49 83 e9 80          	sub    $0xffffffffffffff80,%r9
  1d1ebe:	49 39 f8             	cmp    %rdi,%r8
  1d1ec1:	0f 85 68 ff ff ff    	jne    1d1e2f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x234f>
  1d1ec7:	a8 01                	test   $0x1,%al
  1d1ec9:	48 89 ce             	mov    %rcx,%rsi
  1d1ecc:	4c 89 e1             	mov    %r12,%rcx
  1d1ecf:	4c 8b a4 24 48 01 00 	mov    0x148(%rsp),%r12
  1d1ed6:	00 
  1d1ed7:	4c 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%r15
  1d1ede:	00 
  1d1edf:	74 5e                	je     1d1f3f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x245f>
  1d1ee1:	48 c1 e7 06          	shl    $0x6,%rdi
  1d1ee5:	c4 c1 7d 10 04 3a    	vmovupd (%r10,%rdi,1),%ymm0
  1d1eeb:	c4 41 7d 10 4c 3a 20 	vmovupd 0x20(%r10,%rdi,1),%ymm9
  1d1ef2:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  1d1ef7:	c4 e2 fd b8 24 38    	vfmadd231pd (%rax,%rdi,1),%ymm0,%ymm4
  1d1efd:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1d1f02:	c4 e2 fd b8 2c 3e    	vfmadd231pd (%rsi,%rdi,1),%ymm0,%ymm5
  1d1f08:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  1d1f0d:	c4 e2 fd b8 34 39    	vfmadd231pd (%rcx,%rdi,1),%ymm0,%ymm6
  1d1f13:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  1d1f18:	c4 e2 fd b8 3c 39    	vfmadd231pd (%rcx,%rdi,1),%ymm0,%ymm7
  1d1f1e:	c4 e2 b5 b8 54 38 20 	vfmadd231pd 0x20(%rax,%rdi,1),%ymm9,%ymm2
  1d1f25:	c4 e2 b5 b8 5c 3e 20 	vfmadd231pd 0x20(%rsi,%rdi,1),%ymm9,%ymm3
  1d1f2c:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1d1f31:	c4 e2 b5 b8 4c 3e 20 	vfmadd231pd 0x20(%rsi,%rdi,1),%ymm9,%ymm1
  1d1f38:	c4 62 b5 b8 44 39 20 	vfmadd231pd 0x20(%rcx,%rdi,1),%ymm9,%ymm8
  1d1f3f:	4c 01 94 24 30 01 00 	add    %r10,0x130(%rsp)
  1d1f46:	00 
  1d1f47:	f6 44 24 08 04       	testb  $0x4,0x8(%rsp)
  1d1f4c:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
  1d1f51:	0f 84 d3 00 00 00    	je     1d202a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x254a>
  1d1f57:	f6 84 24 a0 01 00 00 	testb  $0x1,0x1a0(%rsp)
  1d1f5e:	01 
  1d1f5f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  1d1f64:	0f 84 77 08 00 00    	je     1d27e1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d01>
  1d1f6a:	f6 84 24 d0 00 00 00 	testb  $0x4,0xd0(%rsp)
  1d1f71:	04 
  1d1f72:	0f 84 7d 08 00 00    	je     1d27f5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d15>
  1d1f78:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  1d1f7d:	f6 44 24 58 04       	testb  $0x4,0x58(%rsp)
  1d1f82:	0f 84 67 0a 00 00    	je     1d29ef <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2f0f>
  1d1f88:	f6 84 24 88 00 00 00 	testb  $0x4,0x88(%rsp)
  1d1f8f:	04 
  1d1f90:	0f 84 6d 0a 00 00    	je     1d2a03 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2f23>
  1d1f96:	f6 84 24 80 00 00 00 	testb  $0x4,0x80(%rsp)
  1d1f9d:	04 
  1d1f9e:	0f 84 73 0a 00 00    	je     1d2a17 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2f37>
  1d1fa4:	4c 89 ea             	mov    %r13,%rdx
  1d1fa7:	4d 89 dd             	mov    %r11,%r13
  1d1faa:	48 bf fe ff ff ff ff 	movabs $0x3fffffffffffffe,%rdi
  1d1fb1:	ff ff 03 
  1d1fb4:	4c 8b 84 24 78 01 00 	mov    0x178(%rsp),%r8
  1d1fbb:	00 
  1d1fbc:	49 21 f8             	and    %rdi,%r8
  1d1fbf:	4c 8b 8c 24 c0 01 00 	mov    0x1c0(%rsp),%r9
  1d1fc6:	00 
  1d1fc7:	49 21 f9             	and    %rdi,%r9
  1d1fca:	4c 8b 9c 24 b8 01 00 	mov    0x1b8(%rsp),%r11
  1d1fd1:	00 
  1d1fd2:	49 21 fb             	and    %rdi,%r11
  1d1fd5:	48 8b ac 24 b0 01 00 	mov    0x1b0(%rsp),%rbp
  1d1fdc:	00 
  1d1fdd:	48 21 fd             	and    %rdi,%rbp
  1d1fe0:	49 c1 e0 05          	shl    $0x5,%r8
  1d1fe4:	49 c1 e1 05          	shl    $0x5,%r9
  1d1fe8:	49 c1 e3 05          	shl    $0x5,%r11
  1d1fec:	48 c1 e5 05          	shl    $0x5,%rbp
  1d1ff0:	4c 03 44 24 38       	add    0x38(%rsp),%r8
  1d1ff5:	49 01 c1             	add    %rax,%r9
  1d1ff8:	49 01 f3             	add    %rsi,%r11
  1d1ffb:	48 01 cd             	add    %rcx,%rbp
  1d1ffe:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  1d2005:	00 
  1d2006:	c5 fd 10 00          	vmovupd (%rax),%ymm0
  1d200a:	c4 c2 fd b8 20       	vfmadd231pd (%r8),%ymm0,%ymm4
  1d200f:	c4 c2 fd b8 29       	vfmadd231pd (%r9),%ymm0,%ymm5
  1d2014:	c4 c2 fd b8 33       	vfmadd231pd (%r11),%ymm0,%ymm6
  1d2019:	c4 e2 fd b8 7d 00    	vfmadd231pd 0x0(%rbp),%ymm0,%ymm7
  1d201f:	4d 89 eb             	mov    %r13,%r11
  1d2022:	49 89 d5             	mov    %rdx,%r13
  1d2025:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  1d202a:	c5 bd 58 c7          	vaddpd %ymm7,%ymm8,%ymm0
  1d202e:	c5 f5 58 f6          	vaddpd %ymm6,%ymm1,%ymm6
  1d2032:	c5 e5 58 dd          	vaddpd %ymm5,%ymm3,%ymm3
  1d2036:	c5 ed 58 cc          	vaddpd %ymm4,%ymm2,%ymm1
  1d203a:	c4 e3 7d 19 ca 01    	vextractf128 $0x1,%ymm1,%xmm2
  1d2040:	c5 f1 58 ca          	vaddpd %xmm2,%xmm1,%xmm1
  1d2044:	c5 f1 c6 d1 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm2
  1d2049:	c5 f3 58 ca          	vaddsd %xmm2,%xmm1,%xmm1
  1d204d:	c4 e3 7d 19 da 01    	vextractf128 $0x1,%ymm3,%xmm2
  1d2053:	c5 e1 58 d2          	vaddpd %xmm2,%xmm3,%xmm2
  1d2057:	c5 e9 c6 da 01       	vshufpd $0x1,%xmm2,%xmm2,%xmm3
  1d205c:	c5 eb 58 d3          	vaddsd %xmm3,%xmm2,%xmm2
  1d2060:	c4 e3 7d 19 f3 01    	vextractf128 $0x1,%ymm6,%xmm3
  1d2066:	c5 c9 58 db          	vaddpd %xmm3,%xmm6,%xmm3
  1d206a:	c5 e1 c6 e3 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm4
  1d206f:	c5 e3 58 dc          	vaddsd %xmm4,%xmm3,%xmm3
  1d2073:	c4 e3 7d 19 c4 01    	vextractf128 $0x1,%ymm0,%xmm4
  1d2079:	c5 f9 58 c4          	vaddpd %xmm4,%xmm0,%xmm0
  1d207d:	c5 f9 c6 e0 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm4
  1d2082:	c5 fb 58 e4          	vaddsd %xmm4,%xmm0,%xmm4
  1d2086:	4d 85 ff             	test   %r15,%r15
  1d2089:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
  1d2090:	00 
  1d2091:	48 8b bc 24 d0 01 00 	mov    0x1d0(%rsp),%rdi
  1d2098:	00 
  1d2099:	4c 8b 84 24 c8 01 00 	mov    0x1c8(%rsp),%r8
  1d20a0:	00 
  1d20a1:	0f 84 46 02 00 00    	je     1d22ed <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x280d>
  1d20a7:	4c 39 e6             	cmp    %r12,%rsi
  1d20aa:	4c 89 e0             	mov    %r12,%rax
  1d20ad:	48 0f 42 c6          	cmovb  %rsi,%rax
  1d20b1:	48 39 f8             	cmp    %rdi,%rax
  1d20b4:	48 0f 43 c7          	cmovae %rdi,%rax
  1d20b8:	49 8d 4f ff          	lea    -0x1(%r15),%rcx
  1d20bc:	4c 39 c0             	cmp    %r8,%rax
  1d20bf:	49 0f 43 c0          	cmovae %r8,%rax
  1d20c3:	48 39 c1             	cmp    %rax,%rcx
  1d20c6:	48 0f 42 c1          	cmovb  %rcx,%rax
  1d20ca:	49 39 c4             	cmp    %rax,%r12
  1d20cd:	0f 84 b7 08 00 00    	je     1d298a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2eaa>
  1d20d3:	48 39 c6             	cmp    %rax,%rsi
  1d20d6:	0f 84 c4 08 00 00    	je     1d29a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2ec0>
  1d20dc:	48 39 c7             	cmp    %rax,%rdi
  1d20df:	0f 84 ce 08 00 00    	je     1d29b3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2ed3>
  1d20e5:	49 39 c0             	cmp    %rax,%r8
  1d20e8:	0f 84 d8 08 00 00    	je     1d29c6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2ee6>
  1d20ee:	44 89 ff             	mov    %r15d,%edi
  1d20f1:	83 e7 03             	and    $0x3,%edi
  1d20f4:	49 83 ff 04          	cmp    $0x4,%r15
  1d20f8:	73 1c                	jae    1d2116 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2636>
  1d20fa:	45 31 ff             	xor    %r15d,%r15d
  1d20fd:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  1d2102:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1d2107:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  1d210c:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
  1d2111:	e9 3f 01 00 00       	jmp    1d2255 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2775>
  1d2116:	4c 89 f8             	mov    %r15,%rax
  1d2119:	48 83 e0 fc          	and    $0xfffffffffffffffc,%rax
  1d211d:	4c 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%r8
  1d2124:	00 
  1d2125:	49 bc fc ff ff ff ff 	movabs $0xffffffffffffffc,%r12
  1d212c:	ff ff 0f 
  1d212f:	4d 21 e0             	and    %r12,%r8
  1d2132:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  1d2137:	4f 8d 04 c1          	lea    (%r9,%r8,8),%r8
  1d213b:	49 83 c0 18          	add    $0x18,%r8
  1d213f:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  1d2146:	00 
  1d2147:	4d 8d 0c ca          	lea    (%r10,%rcx,8),%r9
  1d214b:	49 83 c1 18          	add    $0x18,%r9
  1d214f:	4c 8b 5c 24 58       	mov    0x58(%rsp),%r11
  1d2154:	4d 21 e3             	and    %r12,%r11
  1d2157:	4c 8b 74 24 20       	mov    0x20(%rsp),%r14
  1d215c:	4f 8d 1c de          	lea    (%r14,%r11,8),%r11
  1d2160:	49 83 c3 18          	add    $0x18,%r11
  1d2164:	4c 8b b4 24 88 00 00 	mov    0x88(%rsp),%r14
  1d216b:	00 
  1d216c:	4d 21 e6             	and    %r12,%r14
  1d216f:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  1d2174:	4e 8d 34 f1          	lea    (%rcx,%r14,8),%r14
  1d2178:	49 83 c6 18          	add    $0x18,%r14
  1d217c:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
  1d2183:	00 
  1d2184:	4d 21 e7             	and    %r12,%r15
  1d2187:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  1d218c:	4e 8d 24 f9          	lea    (%rcx,%r15,8),%r12
  1d2190:	49 83 c4 18          	add    $0x18,%r12
  1d2194:	45 31 ff             	xor    %r15d,%r15d
  1d2197:	c4 81 7b 10 44 f9 e8 	vmovsd -0x18(%r9,%r15,8),%xmm0
  1d219e:	c4 81 7b 10 6c f9 f0 	vmovsd -0x10(%r9,%r15,8),%xmm5
  1d21a5:	c4 82 f9 b9 4c f8 e8 	vfmadd231sd -0x18(%r8,%r15,8),%xmm0,%xmm1
  1d21ac:	c4 82 f9 b9 54 fb e8 	vfmadd231sd -0x18(%r11,%r15,8),%xmm0,%xmm2
  1d21b3:	c4 82 f9 b9 5c fe e8 	vfmadd231sd -0x18(%r14,%r15,8),%xmm0,%xmm3
  1d21ba:	c4 82 f9 b9 64 fc e8 	vfmadd231sd -0x18(%r12,%r15,8),%xmm0,%xmm4
  1d21c1:	c4 82 d1 b9 4c f8 f0 	vfmadd231sd -0x10(%r8,%r15,8),%xmm5,%xmm1
  1d21c8:	c4 82 d1 b9 54 fb f0 	vfmadd231sd -0x10(%r11,%r15,8),%xmm5,%xmm2
  1d21cf:	c4 82 d1 b9 5c fe f0 	vfmadd231sd -0x10(%r14,%r15,8),%xmm5,%xmm3
  1d21d6:	c4 82 d1 b9 64 fc f0 	vfmadd231sd -0x10(%r12,%r15,8),%xmm5,%xmm4
  1d21dd:	c4 81 7b 10 44 f9 f8 	vmovsd -0x8(%r9,%r15,8),%xmm0
  1d21e4:	c4 82 f9 b9 4c f8 f8 	vfmadd231sd -0x8(%r8,%r15,8),%xmm0,%xmm1
  1d21eb:	c4 82 f9 b9 54 fb f8 	vfmadd231sd -0x8(%r11,%r15,8),%xmm0,%xmm2
  1d21f2:	c4 82 f9 b9 5c fe f8 	vfmadd231sd -0x8(%r14,%r15,8),%xmm0,%xmm3
  1d21f9:	c4 82 f9 b9 64 fc f8 	vfmadd231sd -0x8(%r12,%r15,8),%xmm0,%xmm4
  1d2200:	c4 81 7b 10 04 f9    	vmovsd (%r9,%r15,8),%xmm0
  1d2206:	c4 82 f9 b9 0c f8    	vfmadd231sd (%r8,%r15,8),%xmm0,%xmm1
  1d220c:	c4 82 f9 b9 14 fb    	vfmadd231sd (%r11,%r15,8),%xmm0,%xmm2
  1d2212:	c4 82 f9 b9 1c fe    	vfmadd231sd (%r14,%r15,8),%xmm0,%xmm3
  1d2218:	c4 82 f9 b9 24 fc    	vfmadd231sd (%r12,%r15,8),%xmm0,%xmm4
  1d221e:	49 83 c7 04          	add    $0x4,%r15
  1d2222:	4c 39 f8             	cmp    %r15,%rax
  1d2225:	0f 85 6c ff ff ff    	jne    1d2197 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x26b7>
  1d222b:	48 85 ff             	test   %rdi,%rdi
  1d222e:	4c 8b 9c 24 e8 00 00 	mov    0xe8(%rsp),%r11
  1d2235:	00 
  1d2236:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  1d223b:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  1d2240:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1d2245:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  1d224a:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
  1d224f:	0f 84 98 00 00 00    	je     1d22ed <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x280d>
  1d2255:	49 b9 fc ff ff ff ff 	movabs $0xffffffffffffffc,%r9
  1d225c:	ff ff 0f 
  1d225f:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  1d2266:	00 
  1d2267:	4c 21 c8             	and    %r9,%rax
  1d226a:	4e 8d 04 fd 00 00 00 	lea    0x0(,%r15,8),%r8
  1d2271:	00 
  1d2272:	49 8d 04 c0          	lea    (%r8,%rax,8),%rax
  1d2276:	48 01 c5             	add    %rax,%rbp
  1d2279:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  1d2280:	00 
  1d2281:	4c 21 c8             	and    %r9,%rax
  1d2284:	49 8d 04 c0          	lea    (%r8,%rax,8),%rax
  1d2288:	48 01 c1             	add    %rax,%rcx
  1d228b:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  1d2290:	4c 21 c8             	and    %r9,%rax
  1d2293:	49 8d 04 c0          	lea    (%r8,%rax,8),%rax
  1d2297:	48 01 c6             	add    %rax,%rsi
  1d229a:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  1d22a1:	00 
  1d22a2:	48 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%rax
  1d22a9:	00 
  1d22aa:	4a 8d 04 f8          	lea    (%rax,%r15,8),%rax
  1d22ae:	4c 01 d0             	add    %r10,%rax
  1d22b1:	4c 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%r15
  1d22b8:	00 
  1d22b9:	4d 21 cf             	and    %r9,%r15
  1d22bc:	4f 8d 04 f8          	lea    (%r8,%r15,8),%r8
  1d22c0:	4d 01 c4             	add    %r8,%r12
  1d22c3:	45 31 c0             	xor    %r8d,%r8d
  1d22c6:	c4 a1 7b 10 04 c0    	vmovsd (%rax,%r8,8),%xmm0
  1d22cc:	c4 82 f9 b9 0c c4    	vfmadd231sd (%r12,%r8,8),%xmm0,%xmm1
  1d22d2:	c4 a2 f9 b9 14 c6    	vfmadd231sd (%rsi,%r8,8),%xmm0,%xmm2
  1d22d8:	c4 a2 f9 b9 1c c1    	vfmadd231sd (%rcx,%r8,8),%xmm0,%xmm3
  1d22de:	c4 a2 f9 b9 64 c5 00 	vfmadd231sd 0x0(%rbp,%r8,8),%xmm0,%xmm4
  1d22e5:	49 ff c0             	inc    %r8
  1d22e8:	4c 39 c7             	cmp    %r8,%rdi
  1d22eb:	75 d9                	jne    1d22c6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x27e6>
  1d22ed:	4c 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%r8
  1d22f4:	00 
  1d22f5:	4c 89 c0             	mov    %r8,%rax
  1d22f8:	48 c1 e8 03          	shr    $0x3,%rax
  1d22fc:	48 39 c2             	cmp    %rax,%rdx
  1d22ff:	48 0f 42 c2          	cmovb  %rdx,%rax
  1d2303:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  1d2308:	48 39 c1             	cmp    %rax,%rcx
  1d230b:	48 0f 42 c1          	cmovb  %rcx,%rax
  1d230f:	48 85 c0             	test   %rax,%rax
  1d2312:	74 44                	je     1d2358 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2878>
  1d2314:	48 83 f8 01          	cmp    $0x1,%rax
  1d2318:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  1d231f:	00 
  1d2320:	4c 8b 7c 24 70       	mov    0x70(%rsp),%r15
  1d2325:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  1d232a:	75 68                	jne    1d2394 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x28b4>
  1d232c:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1d2330:	31 d2                	xor    %edx,%edx
  1d2332:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1d2336:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1d233a:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1d233f:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1d2344:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1d2349:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1d234e:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1d2353:	e9 19 01 00 00       	jmp    1d2471 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2991>
  1d2358:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1d235d:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1d2362:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1d2367:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1d236c:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1d2371:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1d2375:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1d2379:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1d237d:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  1d2384:	00 
  1d2385:	4c 8b 7c 24 70       	mov    0x70(%rsp),%r15
  1d238a:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  1d238f:	e9 2a 01 00 00       	jmp    1d24be <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x29de>
  1d2394:	49 bc fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%r12
  1d239b:	ff ff 1f 
  1d239e:	49 21 c4             	and    %rax,%r12
  1d23a1:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1d23a5:	bf 60 00 00 00       	mov    $0x60,%edi
  1d23aa:	31 d2                	xor    %edx,%edx
  1d23ac:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1d23b0:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1d23b4:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1d23b9:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1d23be:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1d23c3:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1d23c8:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1d23cd:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
  1d23d4:	00 
  1d23d5:	c4 c1 7d 10 44 3a a0 	vmovupd -0x60(%r10,%rdi,1),%ymm0
  1d23dc:	c4 41 7d 10 6c 3a c0 	vmovupd -0x40(%r10,%rdi,1),%ymm13
  1d23e3:	c4 41 7d 10 74 3a e0 	vmovupd -0x20(%r10,%rdi,1),%ymm14
  1d23ea:	c4 62 fd b8 44 3b a0 	vfmadd231pd -0x60(%rbx,%rdi,1),%ymm0,%ymm8
  1d23f1:	c4 42 fd b8 4c 39 a0 	vfmadd231pd -0x60(%r9,%rdi,1),%ymm0,%ymm9
  1d23f8:	c4 62 fd b8 54 39 a0 	vfmadd231pd -0x60(%rcx,%rdi,1),%ymm0,%ymm10
  1d23ff:	c4 42 fd b8 5c 3f a0 	vfmadd231pd -0x60(%r15,%rdi,1),%ymm0,%ymm11
  1d2406:	c4 e2 95 b8 74 3b c0 	vfmadd231pd -0x40(%rbx,%rdi,1),%ymm13,%ymm6
  1d240d:	c4 c2 95 b8 7c 39 c0 	vfmadd231pd -0x40(%r9,%rdi,1),%ymm13,%ymm7
  1d2414:	c4 e2 95 b8 6c 39 c0 	vfmadd231pd -0x40(%rcx,%rdi,1),%ymm13,%ymm5
  1d241b:	c4 42 95 b8 64 3f c0 	vfmadd231pd -0x40(%r15,%rdi,1),%ymm13,%ymm12
  1d2422:	c4 c1 7d 10 04 3a    	vmovupd (%r10,%rdi,1),%ymm0
  1d2428:	48 83 c2 02          	add    $0x2,%rdx
  1d242c:	c4 62 8d b8 44 3b e0 	vfmadd231pd -0x20(%rbx,%rdi,1),%ymm14,%ymm8
  1d2433:	c4 42 8d b8 4c 39 e0 	vfmadd231pd -0x20(%r9,%rdi,1),%ymm14,%ymm9
  1d243a:	c4 62 8d b8 54 39 e0 	vfmadd231pd -0x20(%rcx,%rdi,1),%ymm14,%ymm10
  1d2441:	c4 42 8d b8 5c 3f e0 	vfmadd231pd -0x20(%r15,%rdi,1),%ymm14,%ymm11
  1d2448:	c4 e2 fd b8 34 3b    	vfmadd231pd (%rbx,%rdi,1),%ymm0,%ymm6
  1d244e:	c4 c2 fd b8 3c 39    	vfmadd231pd (%r9,%rdi,1),%ymm0,%ymm7
  1d2454:	c4 e2 fd b8 2c 39    	vfmadd231pd (%rcx,%rdi,1),%ymm0,%ymm5
  1d245a:	c4 42 fd b8 24 3f    	vfmadd231pd (%r15,%rdi,1),%ymm0,%ymm12
  1d2460:	48 83 ef 80          	sub    $0xffffffffffffff80,%rdi
  1d2464:	49 39 d4             	cmp    %rdx,%r12
  1d2467:	0f 85 68 ff ff ff    	jne    1d23d5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x28f5>
  1d246d:	a8 01                	test   $0x1,%al
  1d246f:	74 4d                	je     1d24be <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x29de>
  1d2471:	48 c1 e2 06          	shl    $0x6,%rdx
  1d2475:	c4 c1 7d 10 04 12    	vmovupd (%r10,%rdx,1),%ymm0
  1d247b:	c4 41 7d 10 6c 12 20 	vmovupd 0x20(%r10,%rdx,1),%ymm13
  1d2482:	c4 62 fd b8 04 13    	vfmadd231pd (%rbx,%rdx,1),%ymm0,%ymm8
  1d2488:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  1d248f:	00 
  1d2490:	c4 62 fd b8 0c 10    	vfmadd231pd (%rax,%rdx,1),%ymm0,%ymm9
  1d2496:	c4 62 fd b8 14 11    	vfmadd231pd (%rcx,%rdx,1),%ymm0,%ymm10
  1d249c:	c4 42 fd b8 1c 17    	vfmadd231pd (%r15,%rdx,1),%ymm0,%ymm11
  1d24a2:	c4 e2 95 b8 74 13 20 	vfmadd231pd 0x20(%rbx,%rdx,1),%ymm13,%ymm6
  1d24a9:	c4 e2 95 b8 7c 10 20 	vfmadd231pd 0x20(%rax,%rdx,1),%ymm13,%ymm7
  1d24b0:	c4 e2 95 b8 6c 11 20 	vfmadd231pd 0x20(%rcx,%rdx,1),%ymm13,%ymm5
  1d24b7:	c4 42 95 b8 64 17 20 	vfmadd231pd 0x20(%r15,%rdx,1),%ymm13,%ymm12
  1d24be:	f6 44 24 08 04       	testb  $0x4,0x8(%rsp)
  1d24c3:	74 6f                	je     1d2534 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2a54>
  1d24c5:	f6 84 24 a0 01 00 00 	testb  $0x1,0x1a0(%rsp)
  1d24cc:	01 
  1d24cd:	0f 84 0e 03 00 00    	je     1d27e1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d01>
  1d24d3:	41 f6 c0 04          	test   $0x4,%r8b
  1d24d7:	48 ba fe ff ff ff ff 	movabs $0x3fffffffffffffe,%rdx
  1d24de:	ff ff 03 
  1d24e1:	0f 84 0e 03 00 00    	je     1d27f5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d15>
  1d24e7:	4c 89 c0             	mov    %r8,%rax
  1d24ea:	48 c1 e8 02          	shr    $0x2,%rax
  1d24ee:	48 21 d0             	and    %rdx,%rax
  1d24f1:	48 c1 e0 05          	shl    $0x5,%rax
  1d24f5:	48 8d 14 03          	lea    (%rbx,%rax,1),%rdx
  1d24f9:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  1d2500:	00 
  1d2501:	48 01 c7             	add    %rax,%rdi
  1d2504:	4c 8d 04 01          	lea    (%rcx,%rax,1),%r8
  1d2508:	4c 01 f8             	add    %r15,%rax
  1d250b:	4c 8b 8c 24 30 01 00 	mov    0x130(%rsp),%r9
  1d2512:	00 
  1d2513:	c4 c1 7d 10 01       	vmovupd (%r9),%ymm0
  1d2518:	c4 62 fd b8 02       	vfmadd231pd (%rdx),%ymm0,%ymm8
  1d251d:	c4 62 fd b8 0f       	vfmadd231pd (%rdi),%ymm0,%ymm9
  1d2522:	c4 42 fd b8 10       	vfmadd231pd (%r8),%ymm0,%ymm10
  1d2527:	4c 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%r8
  1d252e:	00 
  1d252f:	c4 62 fd b8 18       	vfmadd231pd (%rax),%ymm0,%ymm11
  1d2534:	c4 c1 1d 58 c3       	vaddpd %ymm11,%ymm12,%ymm0
  1d2539:	c5 ad 58 ed          	vaddpd %ymm5,%ymm10,%ymm5
  1d253d:	c5 35 58 cf          	vaddpd %ymm7,%ymm9,%ymm9
  1d2541:	c5 bd 58 f6          	vaddpd %ymm6,%ymm8,%ymm6
  1d2545:	c4 e3 7d 19 f7 01    	vextractf128 $0x1,%ymm6,%xmm7
  1d254b:	c5 c9 58 f7          	vaddpd %xmm7,%xmm6,%xmm6
  1d254f:	c5 c9 c6 fe 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm7
  1d2554:	c5 cb 58 ff          	vaddsd %xmm7,%xmm6,%xmm7
  1d2558:	c4 63 7d 19 ce 01    	vextractf128 $0x1,%ymm9,%xmm6
  1d255e:	c5 b1 58 f6          	vaddpd %xmm6,%xmm9,%xmm6
  1d2562:	c5 49 c6 c6 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm8
  1d2567:	c5 3b 58 c6          	vaddsd %xmm6,%xmm8,%xmm8
  1d256b:	c4 e3 7d 19 ee 01    	vextractf128 $0x1,%ymm5,%xmm6
  1d2571:	c5 d1 58 ee          	vaddpd %xmm6,%xmm5,%xmm5
  1d2575:	c5 d1 c6 f5 01       	vshufpd $0x1,%xmm5,%xmm5,%xmm6
  1d257a:	c5 d3 58 ee          	vaddsd %xmm6,%xmm5,%xmm5
  1d257e:	c4 e3 7d 19 c6 01    	vextractf128 $0x1,%ymm0,%xmm6
  1d2584:	c5 f9 58 c6          	vaddpd %xmm6,%xmm0,%xmm0
  1d2588:	c5 f9 c6 f0 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm6
  1d258d:	c5 fb 58 f6          	vaddsd %xmm6,%xmm0,%xmm6
  1d2591:	4c 8b a4 24 b0 00 00 	mov    0xb0(%rsp),%r12
  1d2598:	00 
  1d2599:	4d 85 e4             	test   %r12,%r12
  1d259c:	74 75                	je     1d2613 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2b33>
  1d259e:	44 89 c7             	mov    %r8d,%edi
  1d25a1:	83 e7 03             	and    $0x3,%edi
  1d25a4:	49 8d 44 24 ff       	lea    -0x1(%r12),%rax
  1d25a9:	48 39 c7             	cmp    %rax,%rdi
  1d25ac:	0f 86 2a 04 00 00    	jbe    1d29dc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2efc>
  1d25b2:	48 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%rax
  1d25b9:	ff ff 0f 
  1d25bc:	49 21 c0             	and    %rax,%r8
  1d25bf:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  1d25c6:	00 
  1d25c7:	49 8d 04 c2          	lea    (%r10,%rax,8),%rax
  1d25cb:	4a 8d 14 c3          	lea    (%rbx,%r8,8),%rdx
  1d25cf:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  1d25d6:	00 
  1d25d7:	4a 8d 3c c7          	lea    (%rdi,%r8,8),%rdi
  1d25db:	4a 8d 0c c1          	lea    (%rcx,%r8,8),%rcx
  1d25df:	4f 8d 0c c7          	lea    (%r15,%r8,8),%r9
  1d25e3:	41 83 e4 03          	and    $0x3,%r12d
  1d25e7:	45 31 c0             	xor    %r8d,%r8d
  1d25ea:	4d 89 e2             	mov    %r12,%r10
  1d25ed:	c4 a1 7b 10 04 c0    	vmovsd (%rax,%r8,8),%xmm0
  1d25f3:	c4 a2 f9 b9 3c c2    	vfmadd231sd (%rdx,%r8,8),%xmm0,%xmm7
  1d25f9:	c4 22 f9 b9 04 c7    	vfmadd231sd (%rdi,%r8,8),%xmm0,%xmm8
  1d25ff:	c4 a2 f9 b9 2c c1    	vfmadd231sd (%rcx,%r8,8),%xmm0,%xmm5
  1d2605:	c4 82 f9 b9 34 c1    	vfmadd231sd (%r9,%r8,8),%xmm0,%xmm6
  1d260b:	49 ff c0             	inc    %r8
  1d260e:	4d 39 c2             	cmp    %r8,%r10
  1d2611:	75 da                	jne    1d25ed <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2b0d>
  1d2613:	49 83 e5 fe          	and    $0xfffffffffffffffe,%r13
  1d2617:	49 8d 45 fe          	lea    -0x2(%r13),%rax
  1d261b:	48 39 f0             	cmp    %rsi,%rax
  1d261e:	0f 83 b1 02 00 00    	jae    1d28d5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2df5>
  1d2624:	48 89 c1             	mov    %rax,%rcx
  1d2627:	48 c1 e1 04          	shl    $0x4,%rcx
  1d262b:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
  1d2632:	00 
  1d2633:	c5 fb 11 3c 0f       	vmovsd %xmm7,(%rdi,%rcx,1)
  1d2638:	48 8b 94 24 58 01 00 	mov    0x158(%rsp),%rdx
  1d263f:	00 
  1d2640:	4c 01 ea             	add    %r13,%rdx
  1d2643:	48 83 c2 fe          	add    $0xfffffffffffffffe,%rdx
  1d2647:	c5 7b 11 44 0f 08    	vmovsd %xmm8,0x8(%rdi,%rcx,1)
  1d264d:	48 3b 54 24 60       	cmp    0x60(%rsp),%rdx
  1d2652:	73 52                	jae    1d26a6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2bc6>
  1d2654:	49 ff cd             	dec    %r13
  1d2657:	49 39 f5             	cmp    %rsi,%r13
  1d265a:	0f 83 cb 03 00 00    	jae    1d2a2b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2f4b>
  1d2660:	4c 89 ea             	mov    %r13,%rdx
  1d2663:	48 c1 e2 04          	shl    $0x4,%rdx
  1d2667:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  1d266e:	00 
  1d266f:	c5 fb 11 2c 16       	vmovsd %xmm5,(%rsi,%rdx,1)
  1d2674:	c5 fb 11 74 16 08    	vmovsd %xmm6,0x8(%rsi,%rdx,1)
  1d267a:	4c 39 f0             	cmp    %r14,%rax
  1d267d:	0f 83 65 02 00 00    	jae    1d28e8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2e08>
  1d2683:	c4 c1 7b 11 0c 0b    	vmovsd %xmm1,(%r11,%rcx,1)
  1d2689:	c4 c1 7b 11 54 0b 08 	vmovsd %xmm2,0x8(%r11,%rcx,1)
  1d2690:	4d 39 f5             	cmp    %r14,%r13
  1d2693:	0f 83 70 01 00 00    	jae    1d2809 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d29>
  1d2699:	4c 89 e8             	mov    %r13,%rax
  1d269c:	c5 f9 28 cb          	vmovapd %xmm3,%xmm1
  1d26a0:	c5 f9 28 d4          	vmovapd %xmm4,%xmm2
  1d26a4:	eb 09                	jmp    1d26af <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2bcf>
  1d26a6:	4c 39 f0             	cmp    %r14,%rax
  1d26a9:	0f 83 39 02 00 00    	jae    1d28e8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2e08>
  1d26af:	48 c1 e0 04          	shl    $0x4,%rax
  1d26b3:	c4 c1 7b 11 0c 03    	vmovsd %xmm1,(%r11,%rax,1)
  1d26b9:	c4 c1 7b 11 54 03 08 	vmovsd %xmm2,0x8(%r11,%rax,1)
  1d26c0:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  1d26c4:	c4 c2 7d 37 c7       	vpcmpgtq %ymm15,%ymm0,%ymm0
  1d26c9:	c4 e2 7d 59 0d d6 3a 	vpbroadcastq -0x1ac52a(%rip),%ymm1        # 261a8 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x4d8>
  1d26d0:	e5 ff 
  1d26d2:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
  1d26d6:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
  1d26dc:	c5 f9 5d c1          	vminpd %xmm1,%xmm0,%xmm0
  1d26e0:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1d26e5:	c5 fb 5d c1          	vminsd %xmm1,%xmm0,%xmm0
  1d26e9:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1d26ed:	c5 f9 2e c1          	vucomisd %xmm1,%xmm0
  1d26f1:	0f 97 c0             	seta   %al
  1d26f4:	22 44 24 07          	and    0x7(%rsp),%al
  1d26f8:	eb 39                	jmp    1d2733 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2c53>
  1d26fa:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
  1d2701:	00 
  1d2702:	48 39 c8             	cmp    %rcx,%rax
  1d2705:	0f 83 0b 02 00 00    	jae    1d2916 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2e36>
  1d270b:	48 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%rsi
  1d2712:	00 
  1d2713:	48 39 f0             	cmp    %rsi,%rax
  1d2716:	0f 83 1c 02 00 00    	jae    1d2938 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2e58>
  1d271c:	48 ff c0             	inc    %rax
  1d271f:	48 39 c8             	cmp    %rcx,%rax
  1d2722:	0f 83 0d 01 00 00    	jae    1d2835 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d55>
  1d2728:	48 39 f0             	cmp    %rsi,%rax
  1d272b:	0f 83 1f 01 00 00    	jae    1d2850 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x2d70>
  1d2731:	31 c0                	xor    %eax,%eax
  1d2733:	48 81 c4 78 02 00 00 	add    $0x278,%rsp
  1d273a:	5b                   	pop    %rbx
  1d273b:	41 5c                	pop    %r12
  1d273d:	41 5d                	pop    %r13
  1d273f:	41 5e                	pop    %r14
  1d2741:	41 5f                	pop    %r15
  1d2743:	5d                   	pop    %rbp
  1d2744:	c5 f8 77             	vzeroupper
  1d2747:	c3                   	ret
  1d2748:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  1d274d:	49 89 c1             	mov    %rax,%r9
  1d2750:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  1d2755:	e9 99 d6 ff ff       	jmp    1cfdf3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, false, true, true>>>+0x313>
  1d275a:	48 8d 15 57 c0 10 00 	lea    0x10c057(%rip),%rdx        # 2de7b8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x608>
  1d2761:	48 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%rdi
  1d2768:	00 
  1d2769:	48 8b b4 24 c8 00 00 	mov    0xc8(%rsp),%rsi
  1d2770:	00 
  1d2771:	c5 f8 77             	vzeroupper
  1d2774:	ff 15 56 79 11 00    	call   *0x117956(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d277a:	48 8d 15 4f c0 10 00 	lea    0x10c04f(%rip),%rdx        # 2de7d0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x620>
  1d2781:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
  1d2788:	00 
  1d2789:	48 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%rsi
  1d2790:	00 
  1d2791:	c5 f8 77             	vzeroupper
  1d2794:	ff 15 36 79 11 00    	call   *0x117936(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d279a:	48 8d 15 57 cb 10 00 	lea    0x10cb57(%rip),%rdx        # 2df2f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1148>
  1d27a1:	4c 89 ef             	mov    %r13,%rdi
  1d27a4:	4c 89 f6             	mov    %r14,%rsi
  1d27a7:	c5 f8 77             	vzeroupper
  1d27aa:	ff 15 20 79 11 00    	call   *0x117920(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d27b0:	48 8d 15 41 cb 10 00 	lea    0x10cb41(%rip),%rdx        # 2df2f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1148>
  1d27b7:	4c 89 ef             	mov    %r13,%rdi
  1d27ba:	48 89 ee             	mov    %rbp,%rsi
  1d27bd:	c5 f8 77             	vzeroupper
  1d27c0:	ff 15 0a 79 11 00    	call   *0x11790a(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d27c6:	48 8d 15 c3 c3 10 00 	lea    0x10c3c3(%rip),%rdx        # 2deb90 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9e0>
  1d27cd:	48 8b bc 24 e8 01 00 	mov    0x1e8(%rsp),%rdi
  1d27d4:	00 
  1d27d5:	48 89 fe             	mov    %rdi,%rsi
  1d27d8:	c5 f8 77             	vzeroupper
  1d27db:	ff 15 ef 78 11 00    	call   *0x1178ef(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d27e1:	48 8d 15 30 c3 10 00 	lea    0x10c330(%rip),%rdx        # 2deb18 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x968>
  1d27e8:	31 ff                	xor    %edi,%edi
  1d27ea:	31 f6                	xor    %esi,%esi
  1d27ec:	c5 f8 77             	vzeroupper
  1d27ef:	ff 15 db 78 11 00    	call   *0x1178db(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d27f5:	48 8d 15 34 c3 10 00 	lea    0x10c334(%rip),%rdx        # 2deb30 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x980>
  1d27fc:	31 ff                	xor    %edi,%edi
  1d27fe:	31 f6                	xor    %esi,%esi
  1d2800:	c5 f8 77             	vzeroupper
  1d2803:	ff 15 c7 78 11 00    	call   *0x1178c7(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d2809:	48 8d 15 00 cb 10 00 	lea    0x10cb00(%rip),%rdx        # 2df310 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1160>
  1d2810:	4c 89 ef             	mov    %r13,%rdi
  1d2813:	4c 89 f6             	mov    %r14,%rsi
  1d2816:	c5 f8 77             	vzeroupper
  1d2819:	ff 15 b1 78 11 00    	call   *0x1178b1(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d281f:	48 8d 15 ea ca 10 00 	lea    0x10caea(%rip),%rdx        # 2df310 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1160>
  1d2826:	48 89 c7             	mov    %rax,%rdi
  1d2829:	48 89 ee             	mov    %rbp,%rsi
  1d282c:	c5 f8 77             	vzeroupper
  1d282f:	ff 15 9b 78 11 00    	call   *0x11789b(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d2835:	48 8d 15 dc bf 10 00 	lea    0x10bfdc(%rip),%rdx        # 2de818 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x668>
  1d283c:	48 89 c7             	mov    %rax,%rdi
  1d283f:	48 8b b4 24 c8 00 00 	mov    0xc8(%rsp),%rsi
  1d2846:	00 
  1d2847:	c5 f8 77             	vzeroupper
  1d284a:	ff 15 80 78 11 00    	call   *0x117880(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d2850:	48 8d 15 d9 bf 10 00 	lea    0x10bfd9(%rip),%rdx        # 2de830 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x680>
  1d2857:	48 89 c7             	mov    %rax,%rdi
  1d285a:	c5 f8 77             	vzeroupper
  1d285d:	ff 15 6d 78 11 00    	call   *0x11786d(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d2863:	48 8d 15 8e ca 10 00 	lea    0x10ca8e(%rip),%rdx        # 2df2f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1148>
  1d286a:	4c 89 f6             	mov    %r14,%rsi
  1d286d:	c5 f8 77             	vzeroupper
  1d2870:	ff 15 5a 78 11 00    	call   *0x11785a(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d2876:	48 8d 05 7b ca 10 00 	lea    0x10ca7b(%rip),%rax        # 2df2f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1148>
  1d287d:	48 89 d7             	mov    %rdx,%rdi
  1d2880:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  1d2885:	48 89 c2             	mov    %rax,%rdx
  1d2888:	c5 f8 77             	vzeroupper
  1d288b:	ff 15 3f 78 11 00    	call   *0x11783f(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d2891:	48 8d 05 60 ca 10 00 	lea    0x10ca60(%rip),%rax        # 2df2f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1148>
  1d2898:	48 89 d7             	mov    %rdx,%rdi
  1d289b:	4c 89 f6             	mov    %r14,%rsi
  1d289e:	48 89 c2             	mov    %rax,%rdx
  1d28a1:	c5 f8 77             	vzeroupper
  1d28a4:	ff 15 26 78 11 00    	call   *0x117826(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d28aa:	48 8d 15 47 ca 10 00 	lea    0x10ca47(%rip),%rdx        # 2df2f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1148>
  1d28b1:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  1d28b6:	c5 f8 77             	vzeroupper
  1d28b9:	ff 15 11 78 11 00    	call   *0x117811(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d28bf:	48 8d 15 4a ca 10 00 	lea    0x10ca4a(%rip),%rdx        # 2df310 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1160>
  1d28c6:	48 89 c7             	mov    %rax,%rdi
  1d28c9:	4c 89 f6             	mov    %r14,%rsi
  1d28cc:	c5 f8 77             	vzeroupper
  1d28cf:	ff 15 fb 77 11 00    	call   *0x1177fb(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d28d5:	48 8d 15 1c ca 10 00 	lea    0x10ca1c(%rip),%rdx        # 2df2f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1148>
  1d28dc:	48 89 c7             	mov    %rax,%rdi
  1d28df:	c5 f8 77             	vzeroupper
  1d28e2:	ff 15 e8 77 11 00    	call   *0x1177e8(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d28e8:	48 8d 15 09 ca 10 00 	lea    0x10ca09(%rip),%rdx        # 2df2f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1148>
  1d28ef:	48 89 c7             	mov    %rax,%rdi
  1d28f2:	4c 89 f6             	mov    %r14,%rsi
  1d28f5:	c5 f8 77             	vzeroupper
  1d28f8:	ff 15 d2 77 11 00    	call   *0x1177d2(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d28fe:	48 8d 15 83 c1 10 00 	lea    0x10c183(%rip),%rdx        # 2dea88 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x8d8>
  1d2905:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  1d290a:	48 89 fe             	mov    %rdi,%rsi
  1d290d:	c5 f8 77             	vzeroupper
  1d2910:	ff 15 ba 77 11 00    	call   *0x1177ba(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d2916:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  1d291b:	48 8d 15 c6 be 10 00 	lea    0x10bec6(%rip),%rdx        # 2de7e8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x638>
  1d2922:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  1d2927:	48 8b b4 24 c8 00 00 	mov    0xc8(%rsp),%rsi
  1d292e:	00 
  1d292f:	c5 f8 77             	vzeroupper
  1d2932:	ff 15 98 77 11 00    	call   *0x117798(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d2938:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  1d293d:	48 8d 15 bc be 10 00 	lea    0x10bebc(%rip),%rdx        # 2de800 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x650>
  1d2944:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  1d2949:	48 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%rsi
  1d2950:	00 
  1d2951:	c5 f8 77             	vzeroupper
  1d2954:	ff 15 76 77 11 00    	call   *0x117776(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d295a:	48 8d 15 af c9 10 00 	lea    0x10c9af(%rip),%rdx        # 2df310 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1160>
  1d2961:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  1d2966:	c5 f8 77             	vzeroupper
  1d2969:	ff 15 61 77 11 00    	call   *0x117761(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d296f:	48 8d 05 9a c9 10 00 	lea    0x10c99a(%rip),%rax        # 2df310 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1160>
  1d2976:	48 89 d7             	mov    %rdx,%rdi
  1d2979:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  1d297e:	48 89 c2             	mov    %rax,%rdx
  1d2981:	c5 f8 77             	vzeroupper
  1d2984:	ff 15 46 77 11 00    	call   *0x117746(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d298a:	48 8d 15 ff c1 10 00 	lea    0x10c1ff(%rip),%rdx        # 2deb90 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9e0>
  1d2991:	4c 89 e7             	mov    %r12,%rdi
  1d2994:	4c 89 e6             	mov    %r12,%rsi
  1d2997:	c5 f8 77             	vzeroupper
  1d299a:	ff 15 30 77 11 00    	call   *0x117730(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d29a0:	48 8d 15 01 c2 10 00 	lea    0x10c201(%rip),%rdx        # 2deba8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9f8>
  1d29a7:	48 89 f7             	mov    %rsi,%rdi
  1d29aa:	c5 f8 77             	vzeroupper
  1d29ad:	ff 15 1d 77 11 00    	call   *0x11771d(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d29b3:	48 8d 15 06 c2 10 00 	lea    0x10c206(%rip),%rdx        # 2debc0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa10>
  1d29ba:	48 89 fe             	mov    %rdi,%rsi
  1d29bd:	c5 f8 77             	vzeroupper
  1d29c0:	ff 15 0a 77 11 00    	call   *0x11770a(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d29c6:	48 8d 15 0b c2 10 00 	lea    0x10c20b(%rip),%rdx        # 2debd8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa28>
  1d29cd:	4c 89 c7             	mov    %r8,%rdi
  1d29d0:	4c 89 c6             	mov    %r8,%rsi
  1d29d3:	c5 f8 77             	vzeroupper
  1d29d6:	ff 15 f4 76 11 00    	call   *0x1176f4(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d29dc:	48 8d 15 ad c1 10 00 	lea    0x10c1ad(%rip),%rdx        # 2deb90 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9e0>
  1d29e3:	48 89 fe             	mov    %rdi,%rsi
  1d29e6:	c5 f8 77             	vzeroupper
  1d29e9:	ff 15 e1 76 11 00    	call   *0x1176e1(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d29ef:	48 8d 15 52 c1 10 00 	lea    0x10c152(%rip),%rdx        # 2deb48 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x998>
  1d29f6:	31 ff                	xor    %edi,%edi
  1d29f8:	31 f6                	xor    %esi,%esi
  1d29fa:	c5 f8 77             	vzeroupper
  1d29fd:	ff 15 cd 76 11 00    	call   *0x1176cd(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d2a03:	48 8d 15 56 c1 10 00 	lea    0x10c156(%rip),%rdx        # 2deb60 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9b0>
  1d2a0a:	31 ff                	xor    %edi,%edi
  1d2a0c:	31 f6                	xor    %esi,%esi
  1d2a0e:	c5 f8 77             	vzeroupper
  1d2a11:	ff 15 b9 76 11 00    	call   *0x1176b9(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d2a17:	48 8d 15 5a c1 10 00 	lea    0x10c15a(%rip),%rdx        # 2deb78 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9c8>
  1d2a1e:	31 ff                	xor    %edi,%edi
  1d2a20:	31 f6                	xor    %esi,%esi
  1d2a22:	c5 f8 77             	vzeroupper
  1d2a25:	ff 15 a5 76 11 00    	call   *0x1176a5(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1d2a2b:	48 8d 15 de c8 10 00 	lea    0x10c8de(%rip),%rdx        # 2df310 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1160>
  1d2a32:	4c 89 ef             	mov    %r13,%rdi
  1d2a35:	c5 f8 77             	vzeroupper
  1d2a38:	ff 15 92 76 11 00    	call   *0x117692(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
