
/tmp/rustsht-b3-route-times-20261102/target-parent/release/examples/ducc_spin1_full_transform_parity:     file format elf64-x86-64


Disassembly of section .text:

00000000001e0170 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>>:
  1e0170:	55                   	push   %rbp
  1e0171:	41 57                	push   %r15
  1e0173:	41 56                	push   %r14
  1e0175:	41 55                	push   %r13
  1e0177:	41 54                	push   %r12
  1e0179:	53                   	push   %rbx
  1e017a:	48 81 ec a8 0a 00 00 	sub    $0xaa8,%rsp
  1e0181:	48 89 bc 24 98 07 00 	mov    %rdi,0x798(%rsp)
  1e0188:	00 
  1e0189:	48 8b 8e 28 01 00 00 	mov    0x128(%rsi),%rcx
  1e0190:	48 8b 96 30 01 00 00 	mov    0x130(%rsi),%rdx
  1e0197:	48 89 d7             	mov    %rdx,%rdi
  1e019a:	48 29 cf             	sub    %rcx,%rdi
  1e019d:	4c 8d 47 02          	lea    0x2(%rdi),%r8
  1e01a1:	4c 89 c0             	mov    %r8,%rax
  1e01a4:	48 d1 e8             	shr    $1,%rax
  1e01a7:	0f 84 d2 36 00 00    	je     1e387f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x370f>
  1e01ad:	48 89 8c 24 78 01 00 	mov    %rcx,0x178(%rsp)
  1e01b4:	00 
  1e01b5:	48 89 bc 24 78 07 00 	mov    %rdi,0x778(%rsp)
  1e01bc:	00 
  1e01bd:	4c 8b 7e 50          	mov    0x50(%rsi),%r15
  1e01c1:	4c 8b 4e 60          	mov    0x60(%rsi),%r9
  1e01c5:	4c 8b 66 70          	mov    0x70(%rsi),%r12
  1e01c9:	4c 8b ae 90 00 00 00 	mov    0x90(%rsi),%r13
  1e01d0:	48 8b ae b0 00 00 00 	mov    0xb0(%rsi),%rbp
  1e01d7:	4c 89 c1             	mov    %r8,%rcx
  1e01da:	4c 8b 86 20 01 00 00 	mov    0x120(%rsi),%r8
  1e01e1:	49 ba fc ff ff ff ff 	movabs $0xffffffffffffffc,%r10
  1e01e8:	ff ff 0f 
  1e01eb:	4c 89 c7             	mov    %r8,%rdi
  1e01ee:	48 c1 ef 02          	shr    $0x2,%rdi
  1e01f2:	48 89 94 24 f0 00 00 	mov    %rdx,0xf0(%rsp)
  1e01f9:	00 
  1e01fa:	44 89 c2             	mov    %r8d,%edx
  1e01fd:	83 e2 03             	and    $0x3,%edx
  1e0200:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  1e0207:	00 
  1e0208:	4c 89 84 24 88 01 00 	mov    %r8,0x188(%rsp)
  1e020f:	00 
  1e0210:	4c 89 c0             	mov    %r8,%rax
  1e0213:	4c 21 d0             	and    %r10,%rax
  1e0216:	4c 89 bc 24 98 02 00 	mov    %r15,0x298(%rsp)
  1e021d:	00 
  1e021e:	49 c1 ef 02          	shr    $0x2,%r15
  1e0222:	4c 89 a4 24 f8 04 00 	mov    %r12,0x4f8(%rsp)
  1e0229:	00 
  1e022a:	49 c1 ec 02          	shr    $0x2,%r12
  1e022e:	4c 89 ac 24 00 05 00 	mov    %r13,0x500(%rsp)
  1e0235:	00 
  1e0236:	49 c1 ed 02          	shr    $0x2,%r13
  1e023a:	48 89 ac 24 08 05 00 	mov    %rbp,0x508(%rsp)
  1e0241:	00 
  1e0242:	48 c1 ed 02          	shr    $0x2,%rbp
  1e0246:	4c 89 8c 24 f0 04 00 	mov    %r9,0x4f0(%rsp)
  1e024d:	00 
  1e024e:	49 c1 e9 02          	shr    $0x2,%r9
  1e0252:	4c 8b 96 80 00 00 00 	mov    0x80(%rsi),%r10
  1e0259:	4c 89 94 24 e8 04 00 	mov    %r10,0x4e8(%rsp)
  1e0260:	00 
  1e0261:	49 c1 ea 02          	shr    $0x2,%r10
  1e0265:	4c 8b 9e a0 00 00 00 	mov    0xa0(%rsi),%r11
  1e026c:	4c 89 9c 24 e0 04 00 	mov    %r11,0x4e0(%rsp)
  1e0273:	00 
  1e0274:	49 c1 eb 02          	shr    $0x2,%r11
  1e0278:	48 8b 9e c0 00 00 00 	mov    0xc0(%rsi),%rbx
  1e027f:	48 89 9c 24 d8 04 00 	mov    %rbx,0x4d8(%rsp)
  1e0286:	00 
  1e0287:	48 c1 eb 02          	shr    $0x2,%rbx
  1e028b:	4c 8b 46 10          	mov    0x10(%rsi),%r8
  1e028f:	4d 89 c6             	mov    %r8,%r14
  1e0292:	49 c1 ee 02          	shr    $0x2,%r14
  1e0296:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  1e029a:	48 89 8c 24 e8 01 00 	mov    %rcx,0x1e8(%rsp)
  1e02a1:	00 
  1e02a2:	49 39 fe             	cmp    %rdi,%r14
  1e02a5:	48 89 bc 24 d0 04 00 	mov    %rdi,0x4d0(%rsp)
  1e02ac:	00 
  1e02ad:	49 0f 42 fe          	cmovb  %r14,%rdi
  1e02b1:	49 8d 4e ff          	lea    -0x1(%r14),%rcx
  1e02b5:	48 39 d9             	cmp    %rbx,%rcx
  1e02b8:	48 89 9c 24 a0 00 00 	mov    %rbx,0xa0(%rsp)
  1e02bf:	00 
  1e02c0:	48 0f 43 cb          	cmovae %rbx,%rcx
  1e02c4:	4c 39 d9             	cmp    %r11,%rcx
  1e02c7:	4c 89 9c 24 a8 00 00 	mov    %r11,0xa8(%rsp)
  1e02ce:	00 
  1e02cf:	49 0f 43 cb          	cmovae %r11,%rcx
  1e02d3:	4c 39 d1             	cmp    %r10,%rcx
  1e02d6:	4c 89 94 24 b0 00 00 	mov    %r10,0xb0(%rsp)
  1e02dd:	00 
  1e02de:	49 0f 43 ca          	cmovae %r10,%rcx
  1e02e2:	4c 39 c9             	cmp    %r9,%rcx
  1e02e5:	4c 89 8c 24 b8 00 00 	mov    %r9,0xb8(%rsp)
  1e02ec:	00 
  1e02ed:	49 0f 43 c9          	cmovae %r9,%rcx
  1e02f1:	48 39 e9             	cmp    %rbp,%rcx
  1e02f4:	48 89 6c 24 70       	mov    %rbp,0x70(%rsp)
  1e02f9:	48 0f 43 cd          	cmovae %rbp,%rcx
  1e02fd:	4c 39 e9             	cmp    %r13,%rcx
  1e0300:	4c 89 6c 24 78       	mov    %r13,0x78(%rsp)
  1e0305:	49 0f 43 cd          	cmovae %r13,%rcx
  1e0309:	4c 39 e1             	cmp    %r12,%rcx
  1e030c:	4c 89 a4 24 f8 00 00 	mov    %r12,0xf8(%rsp)
  1e0313:	00 
  1e0314:	49 0f 43 cc          	cmovae %r12,%rcx
  1e0318:	4c 8b 8e 18 01 00 00 	mov    0x118(%rsi),%r9
  1e031f:	4c 89 8c 24 80 01 00 	mov    %r9,0x180(%rsp)
  1e0326:	00 
  1e0327:	49 8d 04 c1          	lea    (%r9,%rax,8),%rax
  1e032b:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
  1e0332:	00 
  1e0333:	4c 39 f9             	cmp    %r15,%rcx
  1e0336:	4c 89 bc 24 d8 00 00 	mov    %r15,0xd8(%rsp)
  1e033d:	00 
  1e033e:	49 0f 43 cf          	cmovae %r15,%rcx
  1e0342:	48 39 f9             	cmp    %rdi,%rcx
  1e0345:	48 0f 43 cf          	cmovae %rdi,%rcx
  1e0349:	48 89 8c 24 80 07 00 	mov    %rcx,0x780(%rsp)
  1e0350:	00 
  1e0351:	48 8b 46 08          	mov    0x8(%rsi),%rax
  1e0355:	48 89 84 24 98 05 00 	mov    %rax,0x598(%rsp)
  1e035c:	00 
  1e035d:	48 8b 6e 48          	mov    0x48(%rsi),%rbp
  1e0361:	4c 8b 5e 58          	mov    0x58(%rsi),%r11
  1e0365:	48 8b 46 68          	mov    0x68(%rsi),%rax
  1e0369:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  1e0370:	00 
  1e0371:	48 8b 5e 78          	mov    0x78(%rsi),%rbx
  1e0375:	48 8b 86 88 00 00 00 	mov    0x88(%rsi),%rax
  1e037c:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  1e0381:	4c 8b be 98 00 00 00 	mov    0x98(%rsi),%r15
  1e0388:	48 8b 86 a8 00 00 00 	mov    0xa8(%rsi),%rax
  1e038f:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  1e0394:	4c 8b a6 b8 00 00 00 	mov    0xb8(%rsi),%r12
  1e039b:	48 8b 86 c8 00 00 00 	mov    0xc8(%rsi),%rax
  1e03a2:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  1e03a9:	00 
  1e03aa:	4c 8b 8e d0 00 00 00 	mov    0xd0(%rsi),%r9
  1e03b1:	48 8b 86 d8 00 00 00 	mov    0xd8(%rsi),%rax
  1e03b8:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  1e03bf:	00 
  1e03c0:	48 8b 86 e0 00 00 00 	mov    0xe0(%rsi),%rax
  1e03c7:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  1e03cc:	4c 8b 96 00 01 00 00 	mov    0x100(%rsi),%r10
  1e03d3:	4c 8b ae f8 00 00 00 	mov    0xf8(%rsi),%r13
  1e03da:	48 83 bc 24 f0 01 00 	cmpq   $0x1,0x1f0(%rsp)
  1e03e1:	00 01 
  1e03e3:	4c 89 9c 24 e0 00 00 	mov    %r11,0xe0(%rsp)
  1e03ea:	00 
  1e03eb:	48 89 9c 24 98 00 00 	mov    %rbx,0x98(%rsp)
  1e03f2:	00 
  1e03f3:	4c 89 7c 24 68       	mov    %r15,0x68(%rsp)
  1e03f8:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
  1e03fd:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
  1e0402:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
  1e0407:	4c 89 44 24 60       	mov    %r8,0x60(%rsp)
  1e040c:	48 89 94 24 c0 00 00 	mov    %rdx,0xc0(%rsp)
  1e0413:	00 
  1e0414:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
  1e0419:	0f 85 1c 03 00 00    	jne    1e073b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5cb>
  1e041f:	48 c7 84 24 90 02 00 	movq   $0x0,0x290(%rsp)
  1e0426:	00 00 00 00 00 
  1e042b:	48 89 ac 24 60 03 00 	mov    %rbp,0x360(%rsp)
  1e0432:	00 
  1e0433:	48 8b 84 24 98 02 00 	mov    0x298(%rsp),%rax
  1e043a:	00 
  1e043b:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
  1e0442:	00 
  1e0443:	4c 89 9c 24 70 03 00 	mov    %r11,0x370(%rsp)
  1e044a:	00 
  1e044b:	48 8b 84 24 f0 04 00 	mov    0x4f0(%rsp),%rax
  1e0452:	00 
  1e0453:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
  1e045a:	00 
  1e045b:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  1e0462:	00 
  1e0463:	48 89 84 24 80 03 00 	mov    %rax,0x380(%rsp)
  1e046a:	00 
  1e046b:	48 8b 84 24 f8 04 00 	mov    0x4f8(%rsp),%rax
  1e0472:	00 
  1e0473:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
  1e047a:	00 
  1e047b:	48 89 9c 24 90 03 00 	mov    %rbx,0x390(%rsp)
  1e0482:	00 
  1e0483:	48 8b 84 24 e8 04 00 	mov    0x4e8(%rsp),%rax
  1e048a:	00 
  1e048b:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  1e0492:	00 
  1e0493:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  1e0498:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
  1e049f:	00 
  1e04a0:	48 8b 84 24 00 05 00 	mov    0x500(%rsp),%rax
  1e04a7:	00 
  1e04a8:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
  1e04af:	00 
  1e04b0:	4c 89 bc 24 b0 03 00 	mov    %r15,0x3b0(%rsp)
  1e04b7:	00 
  1e04b8:	48 8b 84 24 e0 04 00 	mov    0x4e0(%rsp),%rax
  1e04bf:	00 
  1e04c0:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
  1e04c7:	00 
  1e04c8:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  1e04cd:	48 89 84 24 c0 03 00 	mov    %rax,0x3c0(%rsp)
  1e04d4:	00 
  1e04d5:	48 8b 84 24 08 05 00 	mov    0x508(%rsp),%rax
  1e04dc:	00 
  1e04dd:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
  1e04e4:	00 
  1e04e5:	4c 89 a4 24 d0 03 00 	mov    %r12,0x3d0(%rsp)
  1e04ec:	00 
  1e04ed:	48 8b 84 24 d8 04 00 	mov    0x4d8(%rsp),%rax
  1e04f4:	00 
  1e04f5:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
  1e04fc:	00 
  1e04fd:	4c 89 d1             	mov    %r10,%rcx
  1e0500:	48 c1 e9 02          	shr    $0x2,%rcx
  1e0504:	4c 8b b4 24 80 01 00 	mov    0x180(%rsp),%r14
  1e050b:	00 
  1e050c:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  1e0511:	4c 89 94 24 30 05 00 	mov    %r10,0x530(%rsp)
  1e0518:	00 
  1e0519:	0f 84 78 20 00 00    	je     1e2597 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2427>
  1e051f:	48 8d 41 ff          	lea    -0x1(%rcx),%rax
  1e0523:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
  1e052a:	00 
  1e052b:	48 39 d0             	cmp    %rdx,%rax
  1e052e:	48 0f 43 c2          	cmovae %rdx,%rax
  1e0532:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
  1e0539:	00 
  1e053a:	48 39 d0             	cmp    %rdx,%rax
  1e053d:	48 0f 43 c2          	cmovae %rdx,%rax
  1e0541:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
  1e0548:	00 
  1e0549:	48 39 d0             	cmp    %rdx,%rax
  1e054c:	48 0f 43 c2          	cmovae %rdx,%rax
  1e0550:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
  1e0557:	00 
  1e0558:	48 39 d0             	cmp    %rdx,%rax
  1e055b:	48 0f 43 c2          	cmovae %rdx,%rax
  1e055f:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  1e0564:	48 39 d0             	cmp    %rdx,%rax
  1e0567:	48 0f 43 c2          	cmovae %rdx,%rax
  1e056b:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  1e0570:	48 39 d0             	cmp    %rdx,%rax
  1e0573:	48 0f 43 c2          	cmovae %rdx,%rax
  1e0577:	48 8b 94 24 f8 00 00 	mov    0xf8(%rsp),%rdx
  1e057e:	00 
  1e057f:	48 39 d0             	cmp    %rdx,%rax
  1e0582:	48 0f 43 c2          	cmovae %rdx,%rax
  1e0586:	48 89 fe             	mov    %rdi,%rsi
  1e0589:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
  1e0590:	00 
  1e0591:	48 39 f8             	cmp    %rdi,%rax
  1e0594:	48 0f 43 c7          	cmovae %rdi,%rax
  1e0598:	48 39 f0             	cmp    %rsi,%rax
  1e059b:	48 0f 43 c6          	cmovae %rsi,%rax
  1e059f:	48 8b b4 24 d0 04 00 	mov    0x4d0(%rsp),%rsi
  1e05a6:	00 
  1e05a7:	48 39 c6             	cmp    %rax,%rsi
  1e05aa:	0f 84 f4 5b 00 00    	je     1e61a4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6034>
  1e05b0:	48 39 44 24 30       	cmp    %rax,0x30(%rsp)
  1e05b5:	0f 84 8f 5c 00 00    	je     1e624a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x60da>
  1e05bb:	48 39 c7             	cmp    %rax,%rdi
  1e05be:	0f 84 9e 5c 00 00    	je     1e6262 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x60f2>
  1e05c4:	48 39 c2             	cmp    %rax,%rdx
  1e05c7:	0f 84 a8 5c 00 00    	je     1e6275 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6105>
  1e05cd:	48 39 44 24 78       	cmp    %rax,0x78(%rsp)
  1e05d2:	0f 84 b4 5b 00 00    	je     1e618c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x601c>
  1e05d8:	48 39 44 24 70       	cmp    %rax,0x70(%rsp)
  1e05dd:	0f 84 91 5b 00 00    	je     1e6174 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6004>
  1e05e3:	48 39 84 24 b8 00 00 	cmp    %rax,0xb8(%rsp)
  1e05ea:	00 
  1e05eb:	0f 84 68 5b 00 00    	je     1e6159 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5fe9>
  1e05f1:	48 39 84 24 b0 00 00 	cmp    %rax,0xb0(%rsp)
  1e05f8:	00 
  1e05f9:	0f 84 3f 5b 00 00    	je     1e613e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5fce>
  1e05ff:	48 39 84 24 a8 00 00 	cmp    %rax,0xa8(%rsp)
  1e0606:	00 
  1e0607:	0f 84 16 5b 00 00    	je     1e6123 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5fb3>
  1e060d:	48 39 84 24 a0 00 00 	cmp    %rax,0xa0(%rsp)
  1e0614:	00 
  1e0615:	0f 84 ed 5a 00 00    	je     1e6108 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5f98>
  1e061b:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1e0620:	31 c0                	xor    %eax,%eax
  1e0622:	c4 62 7d 19 0d 75 5b 	vbroadcastsd -0x1ba48b(%rip),%ymm9        # 261a0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x4d0>
  1e0629:	e4 ff 
  1e062b:	c4 62 7d 19 15 8c 5c 	vbroadcastsd -0x1ba374(%rip),%ymm10        # 262c0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x5f0>
  1e0632:	e4 ff 
  1e0634:	c4 62 7d 19 1d 0b 5c 	vbroadcastsd -0x1ba3f5(%rip),%ymm11        # 26248 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x578>
  1e063b:	e4 ff 
  1e063d:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1e0641:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1e0645:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  1e0649:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e064d:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e0651:	c5 d1 ef ed          	vpxor  %xmm5,%xmm5,%xmm5
  1e0655:	45 31 d2             	xor    %r10d,%r10d
  1e0658:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1e065c:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
  1e0660:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  1e0667:	00 
  1e0668:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  1e066d:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
  1e0672:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e0679:	1f 84 00 00 00 00 00 
  1e0680:	c4 41 7d 10 64 c5 00 	vmovupd 0x0(%r13,%rax,8),%ymm12
  1e0687:	c4 41 1d 54 e9       	vandpd %ymm9,%ymm12,%ymm13
  1e068c:	c4 41 15 c2 f2 1d    	vcmpge_oqpd %ymm10,%ymm13,%ymm14
  1e0692:	c4 41 15 c2 f8 00    	vcmpeqpd %ymm8,%ymm13,%ymm15
  1e0698:	c4 41 05 56 f6       	vorpd  %ymm14,%ymm15,%ymm14
  1e069d:	c4 41 15 c2 eb 12    	vcmple_oqpd %ymm11,%ymm13,%ymm13
  1e06a3:	c4 41 0d 54 ed       	vandpd %ymm13,%ymm14,%ymm13
  1e06a8:	c4 42 3d 29 34 c6    	vpcmpeqq (%r14,%rax,8),%ymm8,%ymm14
  1e06ae:	c4 42 3d 37 fd       	vpcmpgtq %ymm13,%ymm8,%ymm15
  1e06b3:	c4 41 0d db ed       	vpand  %ymm13,%ymm14,%ymm13
  1e06b8:	c4 c1 7d 50 d5       	vmovmskpd %ymm13,%edx
  1e06bd:	80 f2 0f             	xor    $0xf,%dl
  1e06c0:	0f b6 d2             	movzbl %dl,%edx
  1e06c3:	89 c6                	mov    %eax,%esi
  1e06c5:	40 80 e6 3c          	and    $0x3c,%sil
  1e06c9:	c4 e2 c9 f7 d2       	shlx   %rsi,%rdx,%rdx
  1e06ce:	49 09 d2             	or     %rdx,%r10
  1e06d1:	c4 41 0d db e4       	vpand  %ymm12,%ymm14,%ymm12
  1e06d6:	c4 41 1d db e7       	vpand  %ymm15,%ymm12,%ymm12
  1e06db:	c5 1d 59 6c c5 00    	vmulpd 0x0(%rbp,%rax,8),%ymm12,%ymm13
  1e06e1:	c5 95 58 e4          	vaddpd %ymm4,%ymm13,%ymm4
  1e06e5:	c5 1d 59 2c c7       	vmulpd (%rdi,%rax,8),%ymm12,%ymm13
  1e06ea:	c5 95 58 ed          	vaddpd %ymm5,%ymm13,%ymm5
  1e06ee:	c4 41 1d 59 2c c0    	vmulpd (%r8,%rax,8),%ymm12,%ymm13
  1e06f4:	c4 41 1d 59 34 c1    	vmulpd (%r9,%rax,8),%ymm12,%ymm14
  1e06fa:	c5 95 58 ff          	vaddpd %ymm7,%ymm13,%ymm7
  1e06fe:	c5 8d 58 f6          	vaddpd %ymm6,%ymm14,%ymm6
  1e0702:	c4 41 1d 59 2c c3    	vmulpd (%r11,%rax,8),%ymm12,%ymm13
  1e0708:	c5 95 58 db          	vaddpd %ymm3,%ymm13,%ymm3
  1e070c:	c5 1d 59 2c c3       	vmulpd (%rbx,%rax,8),%ymm12,%ymm13
  1e0711:	c5 95 58 c0          	vaddpd %ymm0,%ymm13,%ymm0
  1e0715:	c4 41 1d 59 2c c7    	vmulpd (%r15,%rax,8),%ymm12,%ymm13
  1e071b:	c4 41 1d 59 24 c4    	vmulpd (%r12,%rax,8),%ymm12,%ymm12
  1e0721:	c5 95 58 d2          	vaddpd %ymm2,%ymm13,%ymm2
  1e0725:	c5 9d 58 c9          	vaddpd %ymm1,%ymm12,%ymm1
  1e0729:	48 83 c0 04          	add    $0x4,%rax
  1e072d:	48 ff c9             	dec    %rcx
  1e0730:	0f 85 4a ff ff ff    	jne    1e0680 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x510>
  1e0736:	e9 7f 1e 00 00       	jmp    1e25ba <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x244a>
  1e073b:	48 89 bc 24 60 07 00 	mov    %rdi,0x760(%rsp)
  1e0742:	00 
  1e0743:	48 8b 06             	mov    (%rsi),%rax
  1e0746:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  1e074d:	00 
  1e074e:	48 8b 4e 18          	mov    0x18(%rsi),%rcx
  1e0752:	48 8b 56 20          	mov    0x20(%rsi),%rdx
  1e0756:	48 8b 46 28          	mov    0x28(%rsi),%rax
  1e075a:	48 89 84 24 c0 04 00 	mov    %rax,0x4c0(%rsp)
  1e0761:	00 
  1e0762:	4c 8b 4e 30          	mov    0x30(%rsi),%r9
  1e0766:	48 8b 46 38          	mov    0x38(%rsi),%rax
  1e076a:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
  1e0771:	00 
  1e0772:	48 8b 46 40          	mov    0x40(%rsi),%rax
  1e0776:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  1e077d:	00 
  1e077e:	48 8b 86 f0 00 00 00 	mov    0xf0(%rsi),%rax
  1e0785:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
  1e078c:	00 
  1e078d:	48 89 d0             	mov    %rdx,%rax
  1e0790:	48 c1 e8 02          	shr    $0x2,%rax
  1e0794:	48 89 84 24 a8 04 00 	mov    %rax,0x4a8(%rsp)
  1e079b:	00 
  1e079c:	41 89 d3             	mov    %edx,%r11d
  1e079f:	41 83 e3 03          	and    $0x3,%r11d
  1e07a3:	48 89 d0             	mov    %rdx,%rax
  1e07a6:	48 89 94 24 88 02 00 	mov    %rdx,0x288(%rsp)
  1e07ad:	00 
  1e07ae:	48 bf fc ff ff ff ff 	movabs $0xffffffffffffffc,%rdi
  1e07b5:	ff ff 0f 
  1e07b8:	48 21 f8             	and    %rdi,%rax
  1e07bb:	48 89 8c 24 b0 04 00 	mov    %rcx,0x4b0(%rsp)
  1e07c2:	00 
  1e07c3:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  1e07c7:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
  1e07ce:	00 
  1e07cf:	44 89 c2             	mov    %r8d,%edx
  1e07d2:	83 e2 03             	and    $0x3,%edx
  1e07d5:	4c 89 c1             	mov    %r8,%rcx
  1e07d8:	48 89 bc 24 00 01 00 	mov    %rdi,0x100(%rsp)
  1e07df:	00 
  1e07e0:	48 21 f9             	and    %rdi,%rcx
  1e07e3:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  1e07ea:	00 
  1e07eb:	4c 89 c0             	mov    %r8,%rax
  1e07ee:	48 83 e0 fc          	and    $0xfffffffffffffffc,%rax
  1e07f2:	48 89 84 24 00 04 00 	mov    %rax,0x400(%rsp)
  1e07f9:	00 
  1e07fa:	48 8b 86 e8 00 00 00 	mov    0xe8(%rsi),%rax
  1e0801:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  1e0806:	48 8b 86 08 01 00 00 	mov    0x108(%rsi),%rax
  1e080d:	48 8b 8e 10 01 00 00 	mov    0x110(%rsi),%rcx
  1e0814:	49 c1 e6 05          	shl    $0x5,%r14
  1e0818:	4c 89 b4 24 70 07 00 	mov    %r14,0x770(%rsp)
  1e081f:	00 
  1e0820:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1e0825:	c4 62 7d 19 2d 1a 5a 	vbroadcastsd -0x1ba5e6(%rip),%ymm13        # 26248 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x578>
  1e082c:	e4 ff 
  1e082e:	c4 62 7d 19 3d 89 5a 	vbroadcastsd -0x1ba577(%rip),%ymm15        # 262c0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x5f0>
  1e0835:	e4 ff 
  1e0837:	c4 62 7d 19 35 60 59 	vbroadcastsd -0x1ba6a0(%rip),%ymm14        # 261a0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x4d0>
  1e083e:	e4 ff 
  1e0840:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  1e0847:	00 
  1e0848:	8d 34 f5 00 00 00 00 	lea    0x0(,%rsi,8),%esi
  1e084f:	48 89 b4 24 88 07 00 	mov    %rsi,0x788(%rsp)
  1e0856:	00 
  1e0857:	48 89 94 24 e0 03 00 	mov    %rdx,0x3e0(%rsp)
  1e085e:	00 
  1e085f:	8d 14 d5 00 00 00 00 	lea    0x0(,%rdx,8),%edx
  1e0866:	48 89 94 24 e0 07 00 	mov    %rdx,0x7e0(%rsp)
  1e086d:	00 
  1e086e:	4c 89 9c 24 88 00 00 	mov    %r11,0x88(%rsp)
  1e0875:	00 
  1e0876:	42 8d 14 dd 00 00 00 	lea    0x0(,%r11,8),%edx
  1e087d:	00 
  1e087e:	48 89 94 24 90 07 00 	mov    %rdx,0x790(%rsp)
  1e0885:	00 
  1e0886:	ba 01 00 00 00       	mov    $0x1,%edx
  1e088b:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
  1e0890:	48 c7 84 24 90 02 00 	movq   $0x0,0x290(%rsp)
  1e0897:	00 00 00 00 00 
  1e089c:	48 8b b4 24 78 01 00 	mov    0x178(%rsp),%rsi
  1e08a3:	00 
  1e08a4:	31 d2                	xor    %edx,%edx
  1e08a6:	4c 89 8c 24 08 01 00 	mov    %r9,0x108(%rsp)
  1e08ad:	00 
  1e08ae:	c5 7d 11 b4 24 20 04 	vmovupd %ymm14,0x420(%rsp)
  1e08b5:	00 00 
  1e08b7:	48 89 b4 24 68 07 00 	mov    %rsi,0x768(%rsp)
  1e08be:	00 
  1e08bf:	4c 39 ca             	cmp    %r9,%rdx
  1e08c2:	0f 84 0a 59 00 00    	je     1e61d2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6062>
  1e08c8:	48 3b 94 24 90 00 00 	cmp    0x90(%rsp),%rdx
  1e08cf:	00 
  1e08d0:	0f 84 e1 58 00 00    	je     1e61b7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6047>
  1e08d6:	48 89 c6             	mov    %rax,%rsi
  1e08d9:	31 c0                	xor    %eax,%eax
  1e08db:	4c 3b 94 24 88 02 00 	cmp    0x288(%rsp),%r10
  1e08e2:	00 
  1e08e3:	0f 85 c4 31 00 00    	jne    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e08e9:	4d 39 c2             	cmp    %r8,%r10
  1e08ec:	0f 85 bb 31 00 00    	jne    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e08f2:	49 39 ca             	cmp    %rcx,%r10
  1e08f5:	0f 85 b2 31 00 00    	jne    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e08fb:	4c 3b 94 24 88 01 00 	cmp    0x188(%rsp),%r10
  1e0902:	00 
  1e0903:	0f 85 a4 31 00 00    	jne    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e0909:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  1e090e:	4c 39 94 24 c8 04 00 	cmp    %r10,0x4c8(%rsp)
  1e0915:	00 
  1e0916:	0f 85 91 31 00 00    	jne    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e091c:	4d 89 ee             	mov    %r13,%r14
  1e091f:	48 8b 84 24 c0 04 00 	mov    0x4c0(%rsp),%rax
  1e0926:	00 
  1e0927:	c5 fb 10 04 d0       	vmovsd (%rax,%rdx,8),%xmm0
  1e092c:	c5 f8 29 84 24 c0 07 	vmovaps %xmm0,0x7c0(%rsp)
  1e0933:	00 00 
  1e0935:	48 8b 84 24 b8 04 00 	mov    0x4b8(%rsp),%rax
  1e093c:	00 
  1e093d:	c5 fb 10 04 d0       	vmovsd (%rax,%rdx,8),%xmm0
  1e0942:	c5 f9 29 84 24 a0 07 	vmovapd %xmm0,0x7a0(%rsp)
  1e0949:	00 00 
  1e094b:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  1e0950:	48 89 84 24 60 03 00 	mov    %rax,0x360(%rsp)
  1e0957:	00 
  1e0958:	48 8b 84 24 98 02 00 	mov    0x298(%rsp),%rax
  1e095f:	00 
  1e0960:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
  1e0967:	00 
  1e0968:	4c 8b 9c 24 e0 00 00 	mov    0xe0(%rsp),%r11
  1e096f:	00 
  1e0970:	4c 89 9c 24 70 03 00 	mov    %r11,0x370(%rsp)
  1e0977:	00 
  1e0978:	48 8b 84 24 f0 04 00 	mov    0x4f0(%rsp),%rax
  1e097f:	00 
  1e0980:	48 89 84 24 78 03 00 	mov    %rax,0x378(%rsp)
  1e0987:	00 
  1e0988:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
  1e098f:	00 
  1e0990:	4c 89 bc 24 80 03 00 	mov    %r15,0x380(%rsp)
  1e0997:	00 
  1e0998:	48 8b 84 24 f8 04 00 	mov    0x4f8(%rsp),%rax
  1e099f:	00 
  1e09a0:	48 89 84 24 88 03 00 	mov    %rax,0x388(%rsp)
  1e09a7:	00 
  1e09a8:	4c 8b 84 24 98 00 00 	mov    0x98(%rsp),%r8
  1e09af:	00 
  1e09b0:	4c 89 84 24 90 03 00 	mov    %r8,0x390(%rsp)
  1e09b7:	00 
  1e09b8:	48 8b 84 24 e8 04 00 	mov    0x4e8(%rsp),%rax
  1e09bf:	00 
  1e09c0:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  1e09c7:	00 
  1e09c8:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
  1e09cd:	4c 89 ac 24 a0 03 00 	mov    %r13,0x3a0(%rsp)
  1e09d4:	00 
  1e09d5:	48 8b 84 24 00 05 00 	mov    0x500(%rsp),%rax
  1e09dc:	00 
  1e09dd:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
  1e09e4:	00 
  1e09e5:	4c 8b 4c 24 68       	mov    0x68(%rsp),%r9
  1e09ea:	4c 89 8c 24 b0 03 00 	mov    %r9,0x3b0(%rsp)
  1e09f1:	00 
  1e09f2:	48 8b 84 24 e0 04 00 	mov    0x4e0(%rsp),%rax
  1e09f9:	00 
  1e09fa:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
  1e0a01:	00 
  1e0a02:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
  1e0a07:	48 89 ac 24 c0 03 00 	mov    %rbp,0x3c0(%rsp)
  1e0a0e:	00 
  1e0a0f:	48 8b 84 24 08 05 00 	mov    0x508(%rsp),%rax
  1e0a16:	00 
  1e0a17:	48 89 84 24 c8 03 00 	mov    %rax,0x3c8(%rsp)
  1e0a1e:	00 
  1e0a1f:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
  1e0a24:	4c 89 94 24 d0 03 00 	mov    %r10,0x3d0(%rsp)
  1e0a2b:	00 
  1e0a2c:	48 8b 84 24 d8 04 00 	mov    0x4d8(%rsp),%rax
  1e0a33:	00 
  1e0a34:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
  1e0a3b:	00 
  1e0a3c:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  1e0a41:	48 85 ff             	test   %rdi,%rdi
  1e0a44:	4c 89 b4 24 b0 06 00 	mov    %r14,0x6b0(%rsp)
  1e0a4b:	00 
  1e0a4c:	0f 84 97 01 00 00    	je     1e0be9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xa79>
  1e0a52:	48 8b b4 24 d0 04 00 	mov    0x4d0(%rsp),%rsi
  1e0a59:	00 
  1e0a5a:	48 8b 94 24 80 07 00 	mov    0x780(%rsp),%rdx
  1e0a61:	00 
  1e0a62:	48 39 d6             	cmp    %rdx,%rsi
  1e0a65:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
  1e0a6c:	00 
  1e0a6d:	0f 84 31 57 00 00    	je     1e61a4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6034>
  1e0a73:	48 39 d7             	cmp    %rdx,%rdi
  1e0a76:	48 8b 8c 24 f8 00 00 	mov    0xf8(%rsp),%rcx
  1e0a7d:	00 
  1e0a7e:	0f 84 b3 57 00 00    	je     1e6237 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x60c7>
  1e0a84:	48 39 d0             	cmp    %rdx,%rax
  1e0a87:	0f 84 94 57 00 00    	je     1e6221 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x60b1>
  1e0a8d:	48 39 d1             	cmp    %rdx,%rcx
  1e0a90:	0f 84 75 57 00 00    	je     1e620b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x609b>
  1e0a96:	48 39 54 24 78       	cmp    %rdx,0x78(%rsp)
  1e0a9b:	0f 84 eb 56 00 00    	je     1e618c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x601c>
  1e0aa1:	48 39 54 24 70       	cmp    %rdx,0x70(%rsp)
  1e0aa6:	0f 84 c8 56 00 00    	je     1e6174 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6004>
  1e0aac:	48 39 94 24 b8 00 00 	cmp    %rdx,0xb8(%rsp)
  1e0ab3:	00 
  1e0ab4:	0f 84 9f 56 00 00    	je     1e6159 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5fe9>
  1e0aba:	48 39 94 24 b0 00 00 	cmp    %rdx,0xb0(%rsp)
  1e0ac1:	00 
  1e0ac2:	0f 84 76 56 00 00    	je     1e613e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5fce>
  1e0ac8:	48 39 94 24 a8 00 00 	cmp    %rdx,0xa8(%rsp)
  1e0acf:	00 
  1e0ad0:	0f 84 4d 56 00 00    	je     1e6123 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5fb3>
  1e0ad6:	48 39 94 24 a0 00 00 	cmp    %rdx,0xa0(%rsp)
  1e0add:	00 
  1e0ade:	0f 84 24 56 00 00    	je     1e6108 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5f98>
  1e0ae4:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  1e0ae8:	48 89 f8             	mov    %rdi,%rax
  1e0aeb:	31 c9                	xor    %ecx,%ecx
  1e0aed:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1e0af1:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1e0af5:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1e0af9:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e0afd:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1e0b01:	45 31 e4             	xor    %r12d,%r12d
  1e0b04:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e0b08:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1e0b0c:	48 8b 9c 24 80 01 00 	mov    0x180(%rsp),%rbx
  1e0b13:	00 
  1e0b14:	4c 8b b4 24 b0 06 00 	mov    0x6b0(%rsp),%r14
  1e0b1b:	00 
  1e0b1c:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  1e0b21:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e0b28:	0f 1f 84 00 00 00 00 
  1e0b2f:	00 
  1e0b30:	c4 41 7d 10 04 ce    	vmovupd (%r14,%rcx,8),%ymm8
  1e0b36:	c4 41 3d 54 ce       	vandpd %ymm14,%ymm8,%ymm9
  1e0b3b:	c4 41 35 c2 d7 1d    	vcmpge_oqpd %ymm15,%ymm9,%ymm10
  1e0b41:	c4 41 35 c2 dc 00    	vcmpeqpd %ymm12,%ymm9,%ymm11
  1e0b47:	c4 41 25 56 d2       	vorpd  %ymm10,%ymm11,%ymm10
  1e0b4c:	c4 41 35 c2 cd 12    	vcmple_oqpd %ymm13,%ymm9,%ymm9
  1e0b52:	c4 41 2d 54 c9       	vandpd %ymm9,%ymm10,%ymm9
  1e0b57:	c4 62 1d 29 14 cb    	vpcmpeqq (%rbx,%rcx,8),%ymm12,%ymm10
  1e0b5d:	c4 42 1d 37 d9       	vpcmpgtq %ymm9,%ymm12,%ymm11
  1e0b62:	c4 41 2d db c9       	vpand  %ymm9,%ymm10,%ymm9
  1e0b67:	c4 c1 7d 50 d1       	vmovmskpd %ymm9,%edx
  1e0b6c:	80 f2 0f             	xor    $0xf,%dl
  1e0b6f:	0f b6 d2             	movzbl %dl,%edx
  1e0b72:	89 ce                	mov    %ecx,%esi
  1e0b74:	40 80 e6 3c          	and    $0x3c,%sil
  1e0b78:	c4 e2 c9 f7 d2       	shlx   %rsi,%rdx,%rdx
  1e0b7d:	49 09 d4             	or     %rdx,%r12
  1e0b80:	c4 41 2d db c0       	vpand  %ymm8,%ymm10,%ymm8
  1e0b85:	c4 41 3d db c3       	vpand  %ymm11,%ymm8,%ymm8
  1e0b8a:	c5 3d 59 0c cf       	vmulpd (%rdi,%rcx,8),%ymm8,%ymm9
  1e0b8f:	c5 b5 58 ff          	vaddpd %ymm7,%ymm9,%ymm7
  1e0b93:	c4 41 3d 59 0c cf    	vmulpd (%r15,%rcx,8),%ymm8,%ymm9
  1e0b99:	c5 b5 58 ed          	vaddpd %ymm5,%ymm9,%ymm5
  1e0b9d:	c4 41 3d 59 4c cd 00 	vmulpd 0x0(%r13,%rcx,8),%ymm8,%ymm9
  1e0ba4:	c5 3d 59 54 cd 00    	vmulpd 0x0(%rbp,%rcx,8),%ymm8,%ymm10
  1e0baa:	c5 b5 58 f6          	vaddpd %ymm6,%ymm9,%ymm6
  1e0bae:	c5 ad 58 e4          	vaddpd %ymm4,%ymm10,%ymm4
  1e0bb2:	c4 41 3d 59 0c cb    	vmulpd (%r11,%rcx,8),%ymm8,%ymm9
  1e0bb8:	c5 b5 58 db          	vaddpd %ymm3,%ymm9,%ymm3
  1e0bbc:	c4 41 3d 59 0c c8    	vmulpd (%r8,%rcx,8),%ymm8,%ymm9
  1e0bc2:	c5 b5 58 c9          	vaddpd %ymm1,%ymm9,%ymm1
  1e0bc6:	c4 41 3d 59 0c c9    	vmulpd (%r9,%rcx,8),%ymm8,%ymm9
  1e0bcc:	c4 41 3d 59 04 ca    	vmulpd (%r10,%rcx,8),%ymm8,%ymm8
  1e0bd2:	c5 b5 58 d2          	vaddpd %ymm2,%ymm9,%ymm2
  1e0bd6:	c5 bd 58 c0          	vaddpd %ymm0,%ymm8,%ymm0
  1e0bda:	48 83 c1 04          	add    $0x4,%rcx
  1e0bde:	48 ff c8             	dec    %rax
  1e0be1:	0f 85 49 ff ff ff    	jne    1e0b30 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x9c0>
  1e0be7:	eb 2b                	jmp    1e0c14 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xaa4>
  1e0be9:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  1e0bed:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1e0bf1:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1e0bf5:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1e0bf9:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1e0bfd:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e0c01:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1e0c05:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e0c09:	45 31 e4             	xor    %r12d,%r12d
  1e0c0c:	48 8b 9c 24 80 01 00 	mov    0x180(%rsp),%rbx
  1e0c13:	00 
  1e0c14:	c4 63 4d 06 c4 31    	vperm2f128 $0x31,%ymm4,%ymm6,%ymm8
  1e0c1a:	c4 e3 4d 18 e4 01    	vinsertf128 $0x1,%xmm4,%ymm6,%ymm4
  1e0c20:	c5 bd 58 e4          	vaddpd %ymm4,%ymm8,%ymm4
  1e0c24:	c4 e3 45 06 f5 31    	vperm2f128 $0x31,%ymm5,%ymm7,%ymm6
  1e0c2a:	c4 e3 45 18 ed 01    	vinsertf128 $0x1,%xmm5,%ymm7,%ymm5
  1e0c30:	c5 d5 58 ee          	vaddpd %ymm6,%ymm5,%ymm5
  1e0c34:	c5 d5 7c e4          	vhaddpd %ymm4,%ymm5,%ymm4
  1e0c38:	c4 e3 fd 01 e4 d8    	vpermpd $0xd8,%ymm4,%ymm4
  1e0c3e:	c5 fd 11 a4 24 10 01 	vmovupd %ymm4,0x110(%rsp)
  1e0c45:	00 00 
  1e0c47:	c4 e3 6d 06 e0 31    	vperm2f128 $0x31,%ymm0,%ymm2,%ymm4
  1e0c4d:	c4 e3 6d 18 c0 01    	vinsertf128 $0x1,%xmm0,%ymm2,%ymm0
  1e0c53:	c5 fd 58 c4          	vaddpd %ymm4,%ymm0,%ymm0
  1e0c57:	c4 e3 65 06 d1 31    	vperm2f128 $0x31,%ymm1,%ymm3,%ymm2
  1e0c5d:	c4 e3 65 18 c9 01    	vinsertf128 $0x1,%xmm1,%ymm3,%ymm1
  1e0c63:	c5 f5 58 ca          	vaddpd %ymm2,%ymm1,%ymm1
  1e0c67:	c5 f5 7c c0          	vhaddpd %ymm0,%ymm1,%ymm0
  1e0c6b:	c4 e3 fd 01 c0 d8    	vpermpd $0xd8,%ymm0,%ymm0
  1e0c71:	c5 fd 11 84 24 30 01 	vmovupd %ymm0,0x130(%rsp)
  1e0c78:	00 00 
  1e0c7a:	48 8d 84 24 60 03 00 	lea    0x360(%rsp),%rax
  1e0c81:	00 
  1e0c82:	48 89 84 24 e0 05 00 	mov    %rax,0x5e0(%rsp)
  1e0c89:	00 
  1e0c8a:	48 8d 84 24 80 03 00 	lea    0x380(%rsp),%rax
  1e0c91:	00 
  1e0c92:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
  1e0c99:	00 
  1e0c9a:	4c 89 b4 24 f0 05 00 	mov    %r14,0x5f0(%rsp)
  1e0ca1:	00 
  1e0ca2:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  1e0ca7:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
  1e0cae:	00 
  1e0caf:	48 89 9c 24 00 06 00 	mov    %rbx,0x600(%rsp)
  1e0cb6:	00 
  1e0cb7:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
  1e0cbe:	00 
  1e0cbf:	48 89 8c 24 08 06 00 	mov    %rcx,0x608(%rsp)
  1e0cc6:	00 
  1e0cc7:	48 8d 8c 24 a0 03 00 	lea    0x3a0(%rsp),%rcx
  1e0cce:	00 
  1e0ccf:	48 89 8c 24 10 06 00 	mov    %rcx,0x610(%rsp)
  1e0cd6:	00 
  1e0cd7:	48 8d 8c 24 c0 03 00 	lea    0x3c0(%rsp),%rcx
  1e0cde:	00 
  1e0cdf:	48 89 8c 24 18 06 00 	mov    %rcx,0x618(%rsp)
  1e0ce6:	00 
  1e0ce7:	48 8b 8c 24 98 05 00 	mov    0x598(%rsp),%rcx
  1e0cee:	00 
  1e0cef:	48 89 8c 24 20 06 00 	mov    %rcx,0x620(%rsp)
  1e0cf6:	00 
  1e0cf7:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
  1e0cfe:	00 
  1e0cff:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  1e0d05:	0f 84 45 0a 00 00    	je     1e1750 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x15e0>
  1e0d0b:	45 31 ed             	xor    %r13d,%r13d
  1e0d0e:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
  1e0d13:	eb 61                	jmp    1e0d76 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xc06>
  1e0d15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  1e0d1c:	00 00 00 00 
  1e0d20:	4c 8d 7d 01          	lea    0x1(%rbp),%r15
  1e0d24:	49 89 fc             	mov    %rdi,%r12
  1e0d27:	48 89 ee             	mov    %rbp,%rsi
  1e0d2a:	49 89 d6             	mov    %rdx,%r14
  1e0d2d:	c5 f8 77             	vzeroupper
  1e0d30:	e8 eb 69 00 00       	call   1e7720 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e0d35:	48 83 cd 02          	or     $0x2,%rbp
  1e0d39:	4c 89 e7             	mov    %r12,%rdi
  1e0d3c:	4c 89 fe             	mov    %r15,%rsi
  1e0d3f:	4c 89 f2             	mov    %r14,%rdx
  1e0d42:	e8 d9 69 00 00       	call   1e7720 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e0d47:	4c 89 e7             	mov    %r12,%rdi
  1e0d4a:	48 89 ee             	mov    %rbp,%rsi
  1e0d4d:	4c 89 f2             	mov    %r14,%rdx
  1e0d50:	e8 cb 69 00 00       	call   1e7720 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e0d55:	4c 89 e7             	mov    %r12,%rdi
  1e0d58:	48 89 de             	mov    %rbx,%rsi
  1e0d5b:	4c 89 f2             	mov    %r14,%rdx
  1e0d5e:	e8 bd 69 00 00       	call   1e7720 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e0d63:	49 ff c5             	inc    %r13
  1e0d66:	4c 3b 6c 24 30       	cmp    0x30(%rsp),%r13
  1e0d6b:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
  1e0d70:	0f 84 da 09 00 00    	je     1e1750 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x15e0>
  1e0d76:	4a 8d 2c ad 00 00 00 	lea    0x0(,%r13,4),%rbp
  1e0d7d:	00 
  1e0d7e:	c4 c2 d3 f7 c4       	shrx   %rbp,%r12,%rax
  1e0d83:	89 c3                	mov    %eax,%ebx
  1e0d85:	80 e3 0f             	and    $0xf,%bl
  1e0d88:	4c 8d a4 24 e0 05 00 	lea    0x5e0(%rsp),%r12
  1e0d8f:	00 
  1e0d90:	4c 8d b4 24 10 01 00 	lea    0x110(%rsp),%r14
  1e0d97:	00 
  1e0d98:	74 c9                	je     1e0d63 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xbf3>
  1e0d9a:	83 e0 0f             	and    $0xf,%eax
  1e0d9d:	83 f8 0f             	cmp    $0xf,%eax
  1e0da0:	0f 85 ea 01 00 00    	jne    1e0f90 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xe20>
  1e0da6:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
  1e0dad:	00 
  1e0dae:	49 39 f5             	cmp    %rsi,%r13
  1e0db1:	0f 83 f0 4f 00 00    	jae    1e5da7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5c37>
  1e0db7:	4c 3b ac 24 b8 00 00 	cmp    0xb8(%rsp),%r13
  1e0dbe:	00 
  1e0dbf:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  1e0dc6:	00 
  1e0dc7:	c4 62 7d 19 0d a8 52 	vbroadcastsd -0x1bad58(%rip),%ymm9        # 26078 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x3a8>
  1e0dce:	e4 ff 
  1e0dd0:	c4 62 7d 19 25 5f 51 	vbroadcastsd -0x1baea1(%rip),%ymm12        # 25f38 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x268>
  1e0dd7:	e4 ff 
  1e0dd9:	48 8d 94 24 10 01 00 	lea    0x110(%rsp),%rdx
  1e0de0:	00 
  1e0de1:	0f 83 d3 4f 00 00    	jae    1e5dba <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5c4a>
  1e0de7:	49 39 c5             	cmp    %rax,%r13
  1e0dea:	0f 83 18 50 00 00    	jae    1e5e08 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5c98>
  1e0df0:	4c 3b ac 24 b0 00 00 	cmp    0xb0(%rsp),%r13
  1e0df7:	00 
  1e0df8:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  1e0dff:	00 
  1e0e00:	c5 7d 10 9c 24 20 04 	vmovupd 0x420(%rsp),%ymm11
  1e0e07:	00 00 
  1e0e09:	48 8b b4 24 b0 06 00 	mov    0x6b0(%rsp),%rsi
  1e0e10:	00 
  1e0e11:	c4 41 11 57 ed       	vxorpd %xmm13,%xmm13,%xmm13
  1e0e16:	c4 41 09 57 f6       	vxorpd %xmm14,%xmm14,%xmm14
  1e0e1b:	4c 8d 84 24 28 09 00 	lea    0x928(%rsp),%r8
  1e0e22:	00 
  1e0e23:	0f 83 fa 4f 00 00    	jae    1e5e23 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5cb3>
  1e0e29:	4c 3b 6c 24 78       	cmp    0x78(%rsp),%r13
  1e0e2e:	0f 83 a1 4f 00 00    	jae    1e5dd5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5c65>
  1e0e34:	4c 3b ac 24 a8 00 00 	cmp    0xa8(%rsp),%r13
  1e0e3b:	00 
  1e0e3c:	0f 83 ab 4f 00 00    	jae    1e5ded <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5c7d>
  1e0e42:	4c 3b 6c 24 70       	cmp    0x70(%rsp),%r13
  1e0e47:	0f 83 42 4f 00 00    	jae    1e5d8f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5c1f>
  1e0e4d:	4c 3b ac 24 a0 00 00 	cmp    0xa0(%rsp),%r13
  1e0e54:	00 
  1e0e55:	0f 83 e3 4f 00 00    	jae    1e5e3e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5cce>
  1e0e5b:	48 8d 5d 03          	lea    0x3(%rbp),%rbx
  1e0e5f:	48 3b 9c 24 88 01 00 	cmp    0x188(%rsp),%rbx
  1e0e66:	00 
  1e0e67:	0f 83 19 2a 00 00    	jae    1e3886 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3716>
  1e0e6d:	4c 3b 6c 24 30       	cmp    0x30(%rsp),%r13
  1e0e72:	0f 83 e1 4f 00 00    	jae    1e5e59 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5ce9>
  1e0e78:	4c 89 e8             	mov    %r13,%rax
  1e0e7b:	48 c1 e0 05          	shl    $0x5,%rax
  1e0e7f:	48 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%rcx
  1e0e86:	00 
  1e0e87:	c5 fd 10 0c 01       	vmovupd (%rcx,%rax,1),%ymm1
  1e0e8c:	c5 fd 10 14 07       	vmovupd (%rdi,%rax,1),%ymm2
  1e0e91:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  1e0e98:	00 
  1e0e99:	c5 fd 10 2c 01       	vmovupd (%rcx,%rax,1),%ymm5
  1e0e9e:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  1e0ea3:	c5 fd 10 1c 01       	vmovupd (%rcx,%rax,1),%ymm3
  1e0ea8:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  1e0ead:	c5 fd 10 34 01       	vmovupd (%rcx,%rax,1),%ymm6
  1e0eb2:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  1e0eb7:	c5 fd 10 3c 01       	vmovupd (%rcx,%rax,1),%ymm7
  1e0ebc:	c5 7d 10 04 06       	vmovupd (%rsi,%rax,1),%ymm8
  1e0ec1:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  1e0ec6:	c5 bd 59 24 01       	vmulpd (%rcx,%rax,1),%ymm8,%ymm4
  1e0ecb:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  1e0ed0:	c5 7d 10 14 01       	vmovupd (%rcx,%rax,1),%ymm10
  1e0ed5:	c5 fd 11 a4 24 a8 08 	vmovupd %ymm4,0x8a8(%rsp)
  1e0edc:	00 00 
  1e0ede:	c5 bd 59 c2          	vmulpd %ymm2,%ymm8,%ymm0
  1e0ee2:	c5 fd 11 84 24 20 02 	vmovupd %ymm0,0x220(%rsp)
  1e0ee9:	00 00 
  1e0eeb:	c5 fd 11 84 24 c8 08 	vmovupd %ymm0,0x8c8(%rsp)
  1e0ef2:	00 00 
  1e0ef4:	c5 bd 59 db          	vmulpd %ymm3,%ymm8,%ymm3
  1e0ef8:	c5 bd 59 d7          	vmulpd %ymm7,%ymm8,%ymm2
  1e0efc:	c5 fd 11 9c 24 c0 01 	vmovupd %ymm3,0x1c0(%rsp)
  1e0f03:	00 00 
  1e0f05:	c5 fd 11 9c 24 a8 09 	vmovupd %ymm3,0x9a8(%rsp)
  1e0f0c:	00 00 
  1e0f0e:	c5 fd 11 94 24 90 01 	vmovupd %ymm2,0x190(%rsp)
  1e0f15:	00 00 
  1e0f17:	c5 fd 11 94 24 c8 09 	vmovupd %ymm2,0x9c8(%rsp)
  1e0f1e:	00 00 
  1e0f20:	c5 bd 59 c1          	vmulpd %ymm1,%ymm8,%ymm0
  1e0f24:	c5 fd 11 84 24 50 01 	vmovupd %ymm0,0x150(%rsp)
  1e0f2b:	00 00 
  1e0f2d:	c5 fd 11 84 24 e8 08 	vmovupd %ymm0,0x8e8(%rsp)
  1e0f34:	00 00 
  1e0f36:	c5 bd 59 d5          	vmulpd %ymm5,%ymm8,%ymm2
  1e0f3a:	c5 fd 11 94 24 08 09 	vmovupd %ymm2,0x908(%rsp)
  1e0f41:	00 00 
  1e0f43:	c5 bd 59 ee          	vmulpd %ymm6,%ymm8,%ymm5
  1e0f47:	c4 c1 2d 59 c8       	vmulpd %ymm8,%ymm10,%ymm1
  1e0f4c:	c5 fd 11 ac 24 40 02 	vmovupd %ymm5,0x240(%rsp)
  1e0f53:	00 00 
  1e0f55:	c5 fd 11 ac 24 e8 09 	vmovupd %ymm5,0x9e8(%rsp)
  1e0f5c:	00 00 
  1e0f5e:	c5 fd 11 8c 24 00 02 	vmovupd %ymm1,0x200(%rsp)
  1e0f65:	00 00 
  1e0f67:	c5 fd 11 8c 24 08 0a 	vmovupd %ymm1,0xa08(%rsp)
  1e0f6e:	00 00 
  1e0f70:	c4 c1 15 c2 cd 00    	vcmpeqpd %ymm13,%ymm13,%ymm1
  1e0f76:	48 8d 8c 24 a8 08 00 	lea    0x8a8(%rsp),%rcx
  1e0f7d:	00 
  1e0f7e:	31 c0                	xor    %eax,%eax
  1e0f80:	48 8d bc 24 e0 05 00 	lea    0x5e0(%rsp),%rdi
  1e0f87:	00 
  1e0f88:	eb 55                	jmp    1e0fdf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xe6f>
  1e0f8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  1e0f90:	44 0f b6 fb          	movzbl %bl,%r15d
  1e0f94:	31 f6                	xor    %esi,%esi
  1e0f96:	f3 41 0f bc f7       	tzcnt  %r15d,%esi
  1e0f9b:	41 8d 5f ff          	lea    -0x1(%r15),%ebx
  1e0f9f:	48 01 ee             	add    %rbp,%rsi
  1e0fa2:	4c 89 e7             	mov    %r12,%rdi
  1e0fa5:	4c 89 f2             	mov    %r14,%rdx
  1e0fa8:	c5 f8 77             	vzeroupper
  1e0fab:	e8 70 67 00 00       	call   1e7720 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e0fb0:	44 20 fb             	and    %r15b,%bl
  1e0fb3:	75 db                	jne    1e0f90 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xe20>
  1e0fb5:	e9 a9 fd ff ff       	jmp    1e0d63 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xbf3>
  1e0fba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  1e0fc0:	48 8d 71 20          	lea    0x20(%rcx),%rsi
  1e0fc4:	c5 a5 54 29          	vandpd (%rcx),%ymm11,%ymm5
  1e0fc8:	c4 c1 55 c2 f1 1d    	vcmpge_oqpd %ymm9,%ymm5,%ymm6
  1e0fce:	c4 c1 55 c2 ec 12    	vcmple_oqpd %ymm12,%ymm5,%ymm5
  1e0fd4:	c5 cd 54 ed          	vandpd %ymm5,%ymm6,%ymm5
  1e0fd8:	c5 d5 54 c9          	vandpd %ymm1,%ymm5,%ymm1
  1e0fdc:	48 89 f1             	mov    %rsi,%rcx
  1e0fdf:	48 85 c9             	test   %rcx,%rcx
  1e0fe2:	74 05                	je     1e0fe9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xe79>
  1e0fe4:	4c 39 c1             	cmp    %r8,%rcx
  1e0fe7:	75 d7                	jne    1e0fc0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xe50>
  1e0fe9:	48 3d 80 00 00 00    	cmp    $0x80,%rax
  1e0fef:	74 1f                	je     1e1010 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xea0>
  1e0ff1:	48 8d 0c 04          	lea    (%rsp,%rax,1),%rcx
  1e0ff5:	48 81 c1 a8 09 00 00 	add    $0x9a8,%rcx
  1e0ffc:	48 83 c0 20          	add    $0x20,%rax
  1e1000:	31 f6                	xor    %esi,%esi
  1e1002:	eb c0                	jmp    1e0fc4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xe54>
  1e1004:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e100b:	00 00 00 00 00 
  1e1010:	c4 e2 15 37 c9       	vpcmpgtq %ymm1,%ymm13,%ymm1
  1e1015:	c4 62 7d 59 1d 8a 51 	vpbroadcastq -0x1bae76(%rip),%ymm11        # 261a8 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x4d8>
  1e101c:	e4 ff 
  1e101e:	c5 a5 db c9          	vpand  %ymm1,%ymm11,%ymm1
  1e1022:	c4 e3 7d 39 cd 01    	vextracti128 $0x1,%ymm1,%xmm5
  1e1028:	c5 f1 5d cd          	vminpd %xmm5,%xmm1,%xmm1
  1e102c:	c5 f1 c6 e9 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm5
  1e1031:	c5 f3 5d cd          	vminsd %xmm5,%xmm1,%xmm1
  1e1035:	c4 c1 79 2e ce       	vucomisd %xmm14,%xmm1
  1e103a:	0f 86 e0 fc ff ff    	jbe    1e0d20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xbb0>
  1e1040:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  1e1047:	00 
  1e1048:	c5 fd 10 1c e8       	vmovupd (%rax,%rbp,8),%ymm3
  1e104d:	c4 62 7d 59 15 ea 55 	vpbroadcastq -0x1baa16(%rip),%ymm10        # 26640 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x970>
  1e1054:	e4 ff 
  1e1056:	c4 e2 7d 59 0d d9 52 	vpbroadcastq -0x1bad27(%rip),%ymm1        # 26338 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x668>
  1e105d:	e4 ff 
  1e105f:	c4 62 7d 59 2d 38 58 	vpbroadcastq -0x1ba7c8(%rip),%ymm13        # 268a0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0xbd0>
  1e1066:	e4 ff 
  1e1068:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  1e106c:	c5 fd 10 bc 24 20 02 	vmovupd 0x220(%rsp),%ymm7
  1e1073:	00 00 
  1e1075:	c5 45 c2 c8 00       	vcmpeqpd %ymm0,%ymm7,%ymm9
  1e107a:	c5 b5 55 eb          	vandnpd %ymm3,%ymm9,%ymm5
  1e107e:	c5 ad d4 f5          	vpaddq %ymm5,%ymm10,%ymm6
  1e1082:	c4 62 7d 59 3d 65 52 	vpbroadcastq -0x1bad9b(%rip),%ymm15        # 262f0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x620>
  1e1089:	e4 ff 
  1e108b:	c5 85 ef f6          	vpxor  %ymm6,%ymm15,%ymm6
  1e108f:	c4 62 7d 59 05 38 4e 	vpbroadcastq -0x1bb1c8(%rip),%ymm8        # 25ed0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x200>
  1e1096:	e4 ff 
  1e1098:	c5 7d 11 8c 24 40 03 	vmovupd %ymm9,0x340(%rsp)
  1e109f:	00 00 
  1e10a1:	c4 c3 45 4b fb 90    	vblendvpd %ymm9,%ymm11,%ymm7,%ymm7
  1e10a7:	c4 e2 3d 37 f6       	vpcmpgtq %ymm6,%ymm8,%ymm6
  1e10ac:	c5 fd 11 bc 24 20 03 	vmovupd %ymm7,0x320(%rsp)
  1e10b3:	00 00 
  1e10b5:	c5 c5 73 d7 34       	vpsrlq $0x34,%ymm7,%ymm7
  1e10ba:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
  1e10be:	c5 c5 d4 ed          	vpaddq %ymm5,%ymm7,%ymm5
  1e10c2:	c5 fe 7f ac 24 a0 02 	vmovdqu %ymm5,0x2a0(%rsp)
  1e10c9:	00 00 
  1e10cb:	c5 95 d4 ed          	vpaddq %ymm5,%ymm13,%ymm5
  1e10cf:	c5 85 ef fd          	vpxor  %ymm5,%ymm15,%ymm7
  1e10d3:	c4 e2 7d 59 2d c4 54 	vpbroadcastq -0x1bab3c(%rip),%ymm5        # 265a0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x8d0>
  1e10da:	e4 ff 
  1e10dc:	c4 e2 55 37 ff       	vpcmpgtq %ymm7,%ymm5,%ymm7
  1e10e1:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
  1e10e5:	c5 7d 10 b4 24 50 01 	vmovupd 0x150(%rsp),%ymm14
  1e10ec:	00 00 
  1e10ee:	c5 0d c2 e0 00       	vcmpeqpd %ymm0,%ymm14,%ymm12
  1e10f3:	c5 9d 55 fb          	vandnpd %ymm3,%ymm12,%ymm7
  1e10f7:	c5 2d d4 cf          	vpaddq %ymm7,%ymm10,%ymm9
  1e10fb:	c4 41 35 ef cf       	vpxor  %ymm15,%ymm9,%ymm9
  1e1100:	c4 42 3d 37 c9       	vpcmpgtq %ymm9,%ymm8,%ymm9
  1e1105:	c5 7d 11 a4 24 60 02 	vmovupd %ymm12,0x260(%rsp)
  1e110c:	00 00 
  1e110e:	c4 43 0d 4b e3 c0    	vblendvpd %ymm12,%ymm11,%ymm14,%ymm12
  1e1114:	c5 7d 11 a4 24 00 03 	vmovupd %ymm12,0x300(%rsp)
  1e111b:	00 00 
  1e111d:	c4 c1 1d 73 d4 34    	vpsrlq $0x34,%ymm12,%ymm12
  1e1123:	c5 1d db e1          	vpand  %ymm1,%ymm12,%ymm12
  1e1127:	c5 9d d4 ff          	vpaddq %ymm7,%ymm12,%ymm7
  1e112b:	c5 fe 7f bc 24 e0 02 	vmovdqu %ymm7,0x2e0(%rsp)
  1e1132:	00 00 
  1e1134:	c5 95 d4 ff          	vpaddq %ymm7,%ymm13,%ymm7
  1e1138:	c5 85 ef ff          	vpxor  %ymm7,%ymm15,%ymm7
  1e113c:	c4 e2 55 37 ff       	vpcmpgtq %ymm7,%ymm5,%ymm7
  1e1141:	c5 35 eb cf          	vpor   %ymm7,%ymm9,%ymm9
  1e1145:	c5 ed c2 f8 00       	vcmpeqpd %ymm0,%ymm2,%ymm7
  1e114a:	c4 43 6d 4b e3 70    	vblendvpd %ymm7,%ymm11,%ymm2,%ymm12
  1e1150:	c5 7d 11 a4 24 10 05 	vmovupd %ymm12,0x510(%rsp)
  1e1157:	00 00 
  1e1159:	c4 c1 1d 73 d4 34    	vpsrlq $0x34,%ymm12,%ymm12
  1e115f:	c5 1d db e1          	vpand  %ymm1,%ymm12,%ymm12
  1e1163:	c5 fd 11 bc 24 c0 02 	vmovupd %ymm7,0x2c0(%rsp)
  1e116a:	00 00 
  1e116c:	c5 c5 55 fb          	vandnpd %ymm3,%ymm7,%ymm7
  1e1170:	c5 1d d4 e7          	vpaddq %ymm7,%ymm12,%ymm12
  1e1174:	c5 ad d4 ff          	vpaddq %ymm7,%ymm10,%ymm7
  1e1178:	c5 85 ef ff          	vpxor  %ymm7,%ymm15,%ymm7
  1e117c:	c4 e2 3d 37 ff       	vpcmpgtq %ymm7,%ymm8,%ymm7
  1e1181:	c5 7e 7f a4 24 70 05 	vmovdqu %ymm12,0x570(%rsp)
  1e1188:	00 00 
  1e118a:	c4 41 1d d4 e5       	vpaddq %ymm13,%ymm12,%ymm12
  1e118f:	c4 41 1d ef e7       	vpxor  %ymm15,%ymm12,%ymm12
  1e1194:	c4 42 55 37 e4       	vpcmpgtq %ymm12,%ymm5,%ymm12
  1e1199:	c5 9d eb ff          	vpor   %ymm7,%ymm12,%ymm7
  1e119d:	c5 b5 eb ff          	vpor   %ymm7,%ymm9,%ymm7
  1e11a1:	c5 c5 eb fe          	vpor   %ymm6,%ymm7,%ymm7
  1e11a5:	c5 dd c2 f0 00       	vcmpeqpd %ymm0,%ymm4,%ymm6
  1e11aa:	c4 c3 5d 4b c3 60    	vblendvpd %ymm6,%ymm11,%ymm4,%ymm0
  1e11b0:	c5 fd 11 84 24 80 04 	vmovupd %ymm0,0x480(%rsp)
  1e11b7:	00 00 
  1e11b9:	c5 b5 73 d0 34       	vpsrlq $0x34,%ymm0,%ymm9
  1e11be:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
  1e11c2:	c5 4d 55 e3          	vandnpd %ymm3,%ymm6,%ymm12
  1e11c6:	c4 c1 35 d4 c4       	vpaddq %ymm12,%ymm9,%ymm0
  1e11cb:	c4 41 1d d4 ca       	vpaddq %ymm10,%ymm12,%ymm9
  1e11d0:	c4 41 35 ef cf       	vpxor  %ymm15,%ymm9,%ymm9
  1e11d5:	c4 42 3d 37 c9       	vpcmpgtq %ymm9,%ymm8,%ymm9
  1e11da:	c5 fe 7f 84 24 60 04 	vmovdqu %ymm0,0x460(%rsp)
  1e11e1:	00 00 
  1e11e3:	c5 15 d4 e0          	vpaddq %ymm0,%ymm13,%ymm12
  1e11e7:	c4 41 1d ef e7       	vpxor  %ymm15,%ymm12,%ymm12
  1e11ec:	c4 42 55 37 e4       	vpcmpgtq %ymm12,%ymm5,%ymm12
  1e11f1:	c4 41 35 eb cc       	vpor   %ymm12,%ymm9,%ymm9
  1e11f6:	c5 c5 73 f7 3f       	vpsllq $0x3f,%ymm7,%ymm7
  1e11fb:	c5 b5 eb ff          	vpor   %ymm7,%ymm9,%ymm7
  1e11ff:	c4 e2 7d 0f ff       	vtestpd %ymm7,%ymm7
  1e1204:	0f 85 16 fb ff ff    	jne    1e0d20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xbb0>
  1e120a:	c5 7d 10 a4 24 90 01 	vmovupd 0x190(%rsp),%ymm12
  1e1211:	00 00 
  1e1213:	c4 41 09 57 f6       	vxorpd %xmm14,%xmm14,%xmm14
  1e1218:	c4 c1 1d c2 c6 00    	vcmpeqpd %ymm14,%ymm12,%ymm0
  1e121e:	c5 fd 55 fb          	vandnpd %ymm3,%ymm0,%ymm7
  1e1222:	c5 2d d4 cf          	vpaddq %ymm7,%ymm10,%ymm9
  1e1226:	c4 41 35 ef cf       	vpxor  %ymm15,%ymm9,%ymm9
  1e122b:	c4 42 3d 37 c9       	vpcmpgtq %ymm9,%ymm8,%ymm9
  1e1230:	c5 fd 11 84 24 50 05 	vmovupd %ymm0,0x550(%rsp)
  1e1237:	00 00 
  1e1239:	c4 c3 1d 4b c3 00    	vblendvpd %ymm0,%ymm11,%ymm12,%ymm0
  1e123f:	c5 fd 11 84 24 40 04 	vmovupd %ymm0,0x440(%rsp)
  1e1246:	00 00 
  1e1248:	c5 9d 73 d0 34       	vpsrlq $0x34,%ymm0,%ymm12
  1e124d:	c5 1d db e1          	vpand  %ymm1,%ymm12,%ymm12
  1e1251:	c5 9d d4 c7          	vpaddq %ymm7,%ymm12,%ymm0
  1e1255:	c5 fe 7f 84 24 a0 05 	vmovdqu %ymm0,0x5a0(%rsp)
  1e125c:	00 00 
  1e125e:	c5 95 d4 f8          	vpaddq %ymm0,%ymm13,%ymm7
  1e1262:	c5 85 ef ff          	vpxor  %ymm7,%ymm15,%ymm7
  1e1266:	c4 e2 55 37 ff       	vpcmpgtq %ymm7,%ymm5,%ymm7
  1e126b:	c5 b5 eb c7          	vpor   %ymm7,%ymm9,%ymm0
  1e126f:	c5 fe 7f 84 24 30 05 	vmovdqu %ymm0,0x530(%rsp)
  1e1276:	00 00 
  1e1278:	c5 fd 10 bc 24 40 02 	vmovupd 0x240(%rsp),%ymm7
  1e127f:	00 00 
  1e1281:	c5 8d c2 c7 00       	vcmpeqpd %ymm7,%ymm14,%ymm0
  1e1286:	c4 43 45 4b cb 00    	vblendvpd %ymm0,%ymm11,%ymm7,%ymm9
  1e128c:	c5 fd 11 84 24 c0 05 	vmovupd %ymm0,0x5c0(%rsp)
  1e1293:	00 00 
  1e1295:	c5 fd 55 fb          	vandnpd %ymm3,%ymm0,%ymm7
  1e1299:	c5 7d 11 8c 24 80 08 	vmovupd %ymm9,0x880(%rsp)
  1e12a0:	00 00 
  1e12a2:	c4 c1 35 73 d1 34    	vpsrlq $0x34,%ymm9,%ymm9
  1e12a8:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
  1e12ac:	c5 b5 d4 c7          	vpaddq %ymm7,%ymm9,%ymm0
  1e12b0:	c5 ad d4 ff          	vpaddq %ymm7,%ymm10,%ymm7
  1e12b4:	c5 85 ef ff          	vpxor  %ymm7,%ymm15,%ymm7
  1e12b8:	c4 e2 3d 37 ff       	vpcmpgtq %ymm7,%ymm8,%ymm7
  1e12bd:	c5 fe 7f 84 24 60 08 	vmovdqu %ymm0,0x860(%rsp)
  1e12c4:	00 00 
  1e12c6:	c5 15 d4 c8          	vpaddq %ymm0,%ymm13,%ymm9
  1e12ca:	c4 41 35 ef cf       	vpxor  %ymm15,%ymm9,%ymm9
  1e12cf:	c4 42 55 37 c9       	vpcmpgtq %ymm9,%ymm5,%ymm9
  1e12d4:	c5 b5 eb ff          	vpor   %ymm7,%ymm9,%ymm7
  1e12d8:	c5 7d 10 8c 24 c0 01 	vmovupd 0x1c0(%rsp),%ymm9
  1e12df:	00 00 
  1e12e1:	c4 c1 35 c2 c6 00    	vcmpeqpd %ymm14,%ymm9,%ymm0
  1e12e7:	c4 43 35 4b cb 00    	vblendvpd %ymm0,%ymm11,%ymm9,%ymm9
  1e12ed:	c5 7d 11 8c 24 20 08 	vmovupd %ymm9,0x820(%rsp)
  1e12f4:	00 00 
  1e12f6:	c4 c1 35 73 d1 34    	vpsrlq $0x34,%ymm9,%ymm9
  1e12fc:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
  1e1300:	c5 7d 10 a4 24 00 02 	vmovupd 0x200(%rsp),%ymm12
  1e1307:	00 00 
  1e1309:	c4 41 1d c2 f6 00    	vcmpeqpd %ymm14,%ymm12,%ymm14
  1e130f:	c5 fd 11 a4 24 00 08 	vmovupd %ymm4,0x800(%rsp)
  1e1316:	00 00 
  1e1318:	c4 c3 1d 4b e3 e0    	vblendvpd %ymm14,%ymm11,%ymm12,%ymm4
  1e131e:	c5 a5 73 d4 34       	vpsrlq $0x34,%ymm4,%ymm11
  1e1323:	c5 a5 db c9          	vpand  %ymm1,%ymm11,%ymm1
  1e1327:	c5 fd 11 84 24 40 08 	vmovupd %ymm0,0x840(%rsp)
  1e132e:	00 00 
  1e1330:	c5 7d 55 e3          	vandnpd %ymm3,%ymm0,%ymm12
  1e1334:	c4 41 35 d4 dc       	vpaddq %ymm12,%ymm9,%ymm11
  1e1339:	c4 41 1d d4 ca       	vpaddq %ymm10,%ymm12,%ymm9
  1e133e:	c5 0d 55 e3          	vandnpd %ymm3,%ymm14,%ymm12
  1e1342:	c4 41 1d d4 d2       	vpaddq %ymm10,%ymm12,%ymm10
  1e1347:	c5 9d d4 c9          	vpaddq %ymm1,%ymm12,%ymm1
  1e134b:	c4 41 2d ef d7       	vpxor  %ymm15,%ymm10,%ymm10
  1e1350:	c4 42 3d 37 d2       	vpcmpgtq %ymm10,%ymm8,%ymm10
  1e1355:	c5 15 d4 e1          	vpaddq %ymm1,%ymm13,%ymm12
  1e1359:	c4 41 1d ef e7       	vpxor  %ymm15,%ymm12,%ymm12
  1e135e:	c4 42 55 37 e4       	vpcmpgtq %ymm12,%ymm5,%ymm12
  1e1363:	c4 41 2d eb d4       	vpor   %ymm12,%ymm10,%ymm10
  1e1368:	c5 ad eb ff          	vpor   %ymm7,%ymm10,%ymm7
  1e136c:	c5 c5 eb bc 24 30 05 	vpor   0x530(%rsp),%ymm7,%ymm7
  1e1373:	00 00 
  1e1375:	c4 41 25 d4 d5       	vpaddq %ymm13,%ymm11,%ymm10
  1e137a:	c4 41 2d ef d7       	vpxor  %ymm15,%ymm10,%ymm10
  1e137f:	c4 c2 55 37 ea       	vpcmpgtq %ymm10,%ymm5,%ymm5
  1e1384:	c4 41 35 ef cf       	vpxor  %ymm15,%ymm9,%ymm9
  1e1389:	c4 42 3d 37 c1       	vpcmpgtq %ymm9,%ymm8,%ymm8
  1e138e:	c5 bd eb ed          	vpor   %ymm5,%ymm8,%ymm5
  1e1392:	c5 c5 73 f7 3f       	vpsllq $0x3f,%ymm7,%ymm7
  1e1397:	c5 c5 eb ed          	vpor   %ymm5,%ymm7,%ymm5
  1e139b:	c4 e2 7d 0f ed       	vtestpd %ymm5,%ymm5
  1e13a0:	0f 85 7a f9 ff ff    	jne    1e0d20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xbb0>
  1e13a6:	c5 7d 6f d4          	vmovdqa %ymm4,%ymm10
  1e13aa:	c5 fe 6f a4 24 70 05 	vmovdqu 0x570(%rsp),%ymm4
  1e13b1:	00 00 
  1e13b3:	c5 c5 73 f4 34       	vpsllq $0x34,%ymm4,%ymm7
  1e13b8:	c4 e2 7d 59 2d 07 4f 	vpbroadcastq -0x1bb0f9(%rip),%ymm5        # 262c8 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x5f8>
  1e13bf:	e4 ff 
  1e13c1:	c5 55 db 84 24 10 05 	vpand  0x510(%rsp),%ymm5,%ymm8
  1e13c8:	00 00 
  1e13ca:	c5 bd eb ff          	vpor   %ymm7,%ymm8,%ymm7
  1e13ce:	c5 fd 10 a4 24 c0 02 	vmovupd 0x2c0(%rsp),%ymm4
  1e13d5:	00 00 
  1e13d7:	c4 e3 45 4b d2 40    	vblendvpd %ymm4,%ymm2,%ymm7,%ymm2
  1e13dd:	c5 fe 6f a4 24 e0 02 	vmovdqu 0x2e0(%rsp),%ymm4
  1e13e4:	00 00 
  1e13e6:	c5 c5 73 f4 34       	vpsllq $0x34,%ymm4,%ymm7
  1e13eb:	c5 55 db 84 24 00 03 	vpand  0x300(%rsp),%ymm5,%ymm8
  1e13f2:	00 00 
  1e13f4:	c5 bd eb ff          	vpor   %ymm7,%ymm8,%ymm7
  1e13f8:	c5 fd 10 a4 24 60 02 	vmovupd 0x260(%rsp),%ymm4
  1e13ff:	00 00 
  1e1401:	c4 e3 45 4b 9c 24 50 	vblendvpd %ymm4,0x150(%rsp),%ymm7,%ymm3
  1e1408:	01 00 00 40 
  1e140c:	c5 fe 6f a4 24 a0 02 	vmovdqu 0x2a0(%rsp),%ymm4
  1e1413:	00 00 
  1e1415:	c5 c5 73 f4 34       	vpsllq $0x34,%ymm4,%ymm7
  1e141a:	c5 55 db 84 24 20 03 	vpand  0x320(%rsp),%ymm5,%ymm8
  1e1421:	00 00 
  1e1423:	c5 bd eb ff          	vpor   %ymm7,%ymm8,%ymm7
  1e1427:	c5 fd 10 a4 24 40 03 	vmovupd 0x340(%rsp),%ymm4
  1e142e:	00 00 
  1e1430:	c4 e3 45 4b a4 24 20 	vblendvpd %ymm4,0x220(%rsp),%ymm7,%ymm4
  1e1437:	02 00 00 40 
  1e143b:	c5 fe 6f bc 24 60 04 	vmovdqu 0x460(%rsp),%ymm7
  1e1442:	00 00 
  1e1444:	c5 c5 73 f7 34       	vpsllq $0x34,%ymm7,%ymm7
  1e1449:	c5 55 db 84 24 80 04 	vpand  0x480(%rsp),%ymm5,%ymm8
  1e1450:	00 00 
  1e1452:	c5 bd eb ff          	vpor   %ymm7,%ymm8,%ymm7
  1e1456:	c4 e3 45 4b 84 24 00 	vblendvpd %ymm6,0x800(%rsp),%ymm7,%ymm0
  1e145d:	08 00 00 60 
  1e1461:	c4 c1 4d 73 f3 34    	vpsllq $0x34,%ymm11,%ymm6
  1e1467:	c5 d5 db bc 24 20 08 	vpand  0x820(%rsp),%ymm5,%ymm7
  1e146e:	00 00 
  1e1470:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
  1e1474:	c5 fd 10 bc 24 40 08 	vmovupd 0x840(%rsp),%ymm7
  1e147b:	00 00 
  1e147d:	c4 63 4d 4b 84 24 c0 	vblendvpd %ymm7,0x1c0(%rsp),%ymm6,%ymm8
  1e1484:	01 00 00 70 
  1e1488:	c5 fe 6f b4 24 a0 05 	vmovdqu 0x5a0(%rsp),%ymm6
  1e148f:	00 00 
  1e1491:	c5 cd 73 f6 34       	vpsllq $0x34,%ymm6,%ymm6
  1e1496:	c5 d5 db bc 24 40 04 	vpand  0x440(%rsp),%ymm5,%ymm7
  1e149d:	00 00 
  1e149f:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
  1e14a3:	c5 fd 10 bc 24 50 05 	vmovupd 0x550(%rsp),%ymm7
  1e14aa:	00 00 
  1e14ac:	c4 e3 4d 4b bc 24 90 	vblendvpd %ymm7,0x190(%rsp),%ymm6,%ymm7
  1e14b3:	01 00 00 70 
  1e14b7:	c5 fe 6f b4 24 60 08 	vmovdqu 0x860(%rsp),%ymm6
  1e14be:	00 00 
  1e14c0:	c5 cd 73 f6 34       	vpsllq $0x34,%ymm6,%ymm6
  1e14c5:	c5 55 db 8c 24 80 08 	vpand  0x880(%rsp),%ymm5,%ymm9
  1e14cc:	00 00 
  1e14ce:	c5 b5 eb f6          	vpor   %ymm6,%ymm9,%ymm6
  1e14d2:	c5 7d 10 8c 24 c0 05 	vmovupd 0x5c0(%rsp),%ymm9
  1e14d9:	00 00 
  1e14db:	c4 e3 4d 4b b4 24 40 	vblendvpd %ymm9,0x240(%rsp),%ymm6,%ymm6
  1e14e2:	02 00 00 90 
  1e14e6:	c5 ad db ed          	vpand  %ymm5,%ymm10,%ymm5
  1e14ea:	c5 f5 73 f1 34       	vpsllq $0x34,%ymm1,%ymm1
  1e14ef:	c5 f5 eb cd          	vpor   %ymm5,%ymm1,%ymm1
  1e14f3:	c4 e3 75 4b ac 24 00 	vblendvpd %ymm14,0x200(%rsp),%ymm1,%ymm5
  1e14fa:	02 00 00 e0 
  1e14fe:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
  1e1505:	00 
  1e1506:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1e150a:	c5 fd 11 0e          	vmovupd %ymm1,(%rsi)
  1e150e:	c5 fd 11 8c 24 30 07 	vmovupd %ymm1,0x730(%rsp)
  1e1515:	00 00 
  1e1517:	c5 fd 11 8c 24 10 07 	vmovupd %ymm1,0x710(%rsp)
  1e151e:	00 00 
  1e1520:	c5 fd 11 8c 24 f0 06 	vmovupd %ymm1,0x6f0(%rsp)
  1e1527:	00 00 
  1e1529:	c5 fd 11 8c 24 d0 06 	vmovupd %ymm1,0x6d0(%rsp)
  1e1530:	00 00 
  1e1532:	c5 fd 11 8c 24 30 06 	vmovupd %ymm1,0x630(%rsp)
  1e1539:	00 00 
  1e153b:	c5 fd 11 8c 24 50 06 	vmovupd %ymm1,0x650(%rsp)
  1e1542:	00 00 
  1e1544:	c5 fd 11 8c 24 70 06 	vmovupd %ymm1,0x670(%rsp)
  1e154b:	00 00 
  1e154d:	48 8b 3d 24 93 10 00 	mov    0x109324(%rip),%rdi        # 2ea878 <_DYNAMIC+0xa60>
  1e1554:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e155b:	48 8d 84 24 d0 06 00 	lea    0x6d0(%rsp),%rax
  1e1562:	00 
  1e1563:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e156c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x13fc>
  1e156a:	ff e2                	jmp    *%rdx
  1e156c:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e1573:	48 8d 84 24 30 06 00 	lea    0x630(%rsp),%rax
  1e157a:	00 
  1e157b:	c5 7d 29 c0          	vmovapd %ymm8,%ymm0
  1e157f:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e1588 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x1418>
  1e1586:	ff e2                	jmp    *%rdx
  1e1588:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e158f:	48 8d 84 24 f0 06 00 	lea    0x6f0(%rsp),%rax
  1e1596:	00 
  1e1597:	c5 fd 28 c4          	vmovapd %ymm4,%ymm0
  1e159b:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e15a4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x1434>
  1e15a2:	ff e2                	jmp    *%rdx
  1e15a4:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e15ab:	48 8d 84 24 50 06 00 	lea    0x650(%rsp),%rax
  1e15b2:	00 
  1e15b3:	c5 fd 28 c7          	vmovapd %ymm7,%ymm0
  1e15b7:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e15c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x1450>
  1e15be:	ff e2                	jmp    *%rdx
  1e15c0:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e15c7:	48 8d 84 24 10 07 00 	lea    0x710(%rsp),%rax
  1e15ce:	00 
  1e15cf:	c5 fd 28 c3          	vmovapd %ymm3,%ymm0
  1e15d3:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e15dc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x146c>
  1e15da:	ff e2                	jmp    *%rdx
  1e15dc:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e15e3:	48 8d 84 24 70 06 00 	lea    0x670(%rsp),%rax
  1e15ea:	00 
  1e15eb:	c5 fd 28 c6          	vmovapd %ymm6,%ymm0
  1e15ef:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e15f8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x1488>
  1e15f6:	ff e2                	jmp    *%rdx
  1e15f8:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e15ff:	48 8d 84 24 30 07 00 	lea    0x730(%rsp),%rax
  1e1606:	00 
  1e1607:	c5 fd 28 c2          	vmovapd %ymm2,%ymm0
  1e160b:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e1614 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x14a4>
  1e1612:	ff e2                	jmp    *%rdx
  1e1614:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e161b:	48 89 f0             	mov    %rsi,%rax
  1e161e:	c5 fd 28 c5          	vmovapd %ymm5,%ymm0
  1e1622:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e162b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x14bb>
  1e1629:	ff e2                	jmp    *%rdx
  1e162b:	c5 fd 10 84 24 d0 06 	vmovupd 0x6d0(%rsp),%ymm0
  1e1632:	00 00 
  1e1634:	c5 fd 10 8c 24 f0 06 	vmovupd 0x6f0(%rsp),%ymm1
  1e163b:	00 00 
  1e163d:	c4 e3 75 18 8c 24 50 	vinsertf128 $0x1,0x650(%rsp),%ymm1,%ymm1
  1e1644:	06 00 00 01 
  1e1648:	c4 e3 7d 18 84 24 30 	vinsertf128 $0x1,0x630(%rsp),%ymm0,%ymm0
  1e164f:	06 00 00 01 
  1e1653:	c5 fd 14 d1          	vunpcklpd %ymm1,%ymm0,%ymm2
  1e1657:	c5 ed 58 94 24 10 01 	vaddpd 0x110(%rsp),%ymm2,%ymm2
  1e165e:	00 00 
  1e1660:	c5 fd 15 c1          	vunpckhpd %ymm1,%ymm0,%ymm0
  1e1664:	c5 ed 58 c0          	vaddpd %ymm0,%ymm2,%ymm0
  1e1668:	c5 f9 28 8c 24 00 07 	vmovapd 0x700(%rsp),%xmm1
  1e166f:	00 00 
  1e1671:	c5 f9 28 94 24 e0 06 	vmovapd 0x6e0(%rsp),%xmm2
  1e1678:	00 00 
  1e167a:	c5 e9 14 d9          	vunpcklpd %xmm1,%xmm2,%xmm3
  1e167e:	c5 fd 10 a4 24 30 06 	vmovupd 0x630(%rsp),%ymm4
  1e1685:	00 00 
  1e1687:	c5 fd 10 ac 24 50 06 	vmovupd 0x650(%rsp),%ymm5
  1e168e:	00 00 
  1e1690:	c5 dd 14 f5          	vunpcklpd %ymm5,%ymm4,%ymm6
  1e1694:	c4 e3 65 0d de 0c    	vblendpd $0xc,%ymm6,%ymm3,%ymm3
  1e169a:	c5 fd 10 b4 24 70 06 	vmovupd 0x670(%rsp),%ymm6
  1e16a1:	00 00 
  1e16a3:	c5 fd 58 c3          	vaddpd %ymm3,%ymm0,%ymm0
  1e16a7:	c5 e9 15 c9          	vunpckhpd %xmm1,%xmm2,%xmm1
  1e16ab:	c5 dd 15 d5          	vunpckhpd %ymm5,%ymm4,%ymm2
  1e16af:	c4 e3 75 0d ca 0c    	vblendpd $0xc,%ymm2,%ymm1,%ymm1
  1e16b5:	c5 fd 58 c1          	vaddpd %ymm1,%ymm0,%ymm0
  1e16b9:	c5 fd 11 84 24 10 01 	vmovupd %ymm0,0x110(%rsp)
  1e16c0:	00 00 
  1e16c2:	c5 fd 10 84 24 90 06 	vmovupd 0x690(%rsp),%ymm0
  1e16c9:	00 00 
  1e16cb:	c5 fd 10 8c 24 30 07 	vmovupd 0x730(%rsp),%ymm1
  1e16d2:	00 00 
  1e16d4:	c4 e3 75 18 8c 24 90 	vinsertf128 $0x1,0x690(%rsp),%ymm1,%ymm1
  1e16db:	06 00 00 01 
  1e16df:	c5 fd 10 94 24 10 07 	vmovupd 0x710(%rsp),%ymm2
  1e16e6:	00 00 
  1e16e8:	c4 e3 6d 18 94 24 70 	vinsertf128 $0x1,0x670(%rsp),%ymm2,%ymm2
  1e16ef:	06 00 00 01 
  1e16f3:	c5 ed 14 d9          	vunpcklpd %ymm1,%ymm2,%ymm3
  1e16f7:	c5 e5 58 9c 24 30 01 	vaddpd 0x130(%rsp),%ymm3,%ymm3
  1e16fe:	00 00 
  1e1700:	c5 ed 15 c9          	vunpckhpd %ymm1,%ymm2,%ymm1
  1e1704:	c5 e5 58 c9          	vaddpd %ymm1,%ymm3,%ymm1
  1e1708:	c5 f9 28 94 24 40 07 	vmovapd 0x740(%rsp),%xmm2
  1e170f:	00 00 
  1e1711:	c5 f9 28 9c 24 20 07 	vmovapd 0x720(%rsp),%xmm3
  1e1718:	00 00 
  1e171a:	c5 e1 14 e2          	vunpcklpd %xmm2,%xmm3,%xmm4
  1e171e:	c5 cd 14 e8          	vunpcklpd %ymm0,%ymm6,%ymm5
  1e1722:	c4 e3 5d 0d e5 0c    	vblendpd $0xc,%ymm5,%ymm4,%ymm4
  1e1728:	c5 f5 58 cc          	vaddpd %ymm4,%ymm1,%ymm1
  1e172c:	c5 e1 15 d2          	vunpckhpd %xmm2,%xmm3,%xmm2
  1e1730:	c5 cd 15 c0          	vunpckhpd %ymm0,%ymm6,%ymm0
  1e1734:	c4 e3 6d 0d c0 0c    	vblendpd $0xc,%ymm0,%ymm2,%ymm0
  1e173a:	c5 f5 58 c0          	vaddpd %ymm0,%ymm1,%ymm0
  1e173e:	c5 fd 11 84 24 30 01 	vmovupd %ymm0,0x130(%rsp)
  1e1745:	00 00 
  1e1747:	e9 17 f6 ff ff       	jmp    1e0d63 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0xbf3>
  1e174c:	0f 1f 40 00          	nopl   0x0(%rax)
  1e1750:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1e1757:	00 
  1e1758:	48 8b 8c 24 b0 06 00 	mov    0x6b0(%rsp),%rcx
  1e175f:	00 
  1e1760:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  1e1764:	48 89 84 24 40 02 00 	mov    %rax,0x240(%rsp)
  1e176b:	00 
  1e176c:	c5 fb 10 84 24 10 01 	vmovsd 0x110(%rsp),%xmm0
  1e1773:	00 00 
  1e1775:	c5 fb 11 44 24 10    	vmovsd %xmm0,0x10(%rsp)
  1e177b:	c5 fb 10 84 24 18 01 	vmovsd 0x118(%rsp),%xmm0
  1e1782:	00 00 
  1e1784:	c5 fb 11 84 24 20 02 	vmovsd %xmm0,0x220(%rsp)
  1e178b:	00 00 
  1e178d:	c5 fb 10 84 24 20 01 	vmovsd 0x120(%rsp),%xmm0
  1e1794:	00 00 
  1e1796:	c5 fb 11 84 24 00 02 	vmovsd %xmm0,0x200(%rsp)
  1e179d:	00 00 
  1e179f:	48 8b b4 24 e0 03 00 	mov    0x3e0(%rsp),%rsi
  1e17a6:	00 
  1e17a7:	48 85 f6             	test   %rsi,%rsi
  1e17aa:	0f 84 1d 06 00 00    	je     1e1dcd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x1c5d>
  1e17b0:	c5 fb 10 84 24 28 01 	vmovsd 0x128(%rsp),%xmm0
  1e17b7:	00 00 
  1e17b9:	c5 fb 11 84 24 c0 01 	vmovsd %xmm0,0x1c0(%rsp)
  1e17c0:	00 00 
  1e17c2:	c5 fb 10 84 24 30 01 	vmovsd 0x130(%rsp),%xmm0
  1e17c9:	00 00 
  1e17cb:	c5 fb 11 84 24 50 01 	vmovsd %xmm0,0x150(%rsp)
  1e17d2:	00 00 
  1e17d4:	c5 7b 10 9c 24 40 01 	vmovsd 0x140(%rsp),%xmm11
  1e17db:	00 00 
  1e17dd:	48 8b 84 24 68 03 00 	mov    0x368(%rsp),%rax
  1e17e4:	00 
  1e17e5:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
  1e17ec:	00 
  1e17ed:	48 8b 84 24 78 03 00 	mov    0x378(%rsp),%rax
  1e17f4:	00 
  1e17f5:	48 89 84 24 10 05 00 	mov    %rax,0x510(%rsp)
  1e17fc:	00 
  1e17fd:	48 8b 84 24 88 03 00 	mov    0x388(%rsp),%rax
  1e1804:	00 
  1e1805:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  1e180c:	00 
  1e180d:	48 8b 84 24 98 03 00 	mov    0x398(%rsp),%rax
  1e1814:	00 
  1e1815:	48 89 84 24 80 04 00 	mov    %rax,0x480(%rsp)
  1e181c:	00 
  1e181d:	48 8b 84 24 a8 03 00 	mov    0x3a8(%rsp),%rax
  1e1824:	00 
  1e1825:	48 89 84 24 e0 02 00 	mov    %rax,0x2e0(%rsp)
  1e182c:	00 
  1e182d:	48 8b 84 24 b8 03 00 	mov    0x3b8(%rsp),%rax
  1e1834:	00 
  1e1835:	48 89 84 24 60 04 00 	mov    %rax,0x460(%rsp)
  1e183c:	00 
  1e183d:	48 8b 84 24 c8 03 00 	mov    0x3c8(%rsp),%rax
  1e1844:	00 
  1e1845:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  1e184c:	00 
  1e184d:	c5 fb 10 84 24 38 01 	vmovsd 0x138(%rsp),%xmm0
  1e1854:	00 00 
  1e1856:	c5 fb 11 84 24 90 01 	vmovsd %xmm0,0x190(%rsp)
  1e185d:	00 00 
  1e185f:	c5 fb 10 a4 24 48 01 	vmovsd 0x148(%rsp),%xmm4
  1e1866:	00 00 
  1e1868:	48 8b 8c 24 d0 03 00 	mov    0x3d0(%rsp),%rcx
  1e186f:	00 
  1e1870:	48 8b 84 24 70 07 00 	mov    0x770(%rsp),%rax
  1e1877:	00 
  1e1878:	48 01 c1             	add    %rax,%rcx
  1e187b:	48 89 8c 24 a0 05 00 	mov    %rcx,0x5a0(%rsp)
  1e1882:	00 
  1e1883:	48 8b 8c 24 b0 03 00 	mov    0x3b0(%rsp),%rcx
  1e188a:	00 
  1e188b:	48 01 c1             	add    %rax,%rcx
  1e188e:	48 89 8c 24 c0 05 00 	mov    %rcx,0x5c0(%rsp)
  1e1895:	00 
  1e1896:	48 8b 8c 24 90 03 00 	mov    0x390(%rsp),%rcx
  1e189d:	00 
  1e189e:	48 01 c1             	add    %rax,%rcx
  1e18a1:	48 89 8c 24 50 05 00 	mov    %rcx,0x550(%rsp)
  1e18a8:	00 
  1e18a9:	48 8b 8c 24 70 03 00 	mov    0x370(%rsp),%rcx
  1e18b0:	00 
  1e18b1:	48 01 c1             	add    %rax,%rcx
  1e18b4:	48 89 8c 24 30 05 00 	mov    %rcx,0x530(%rsp)
  1e18bb:	00 
  1e18bc:	48 8b 8c 24 c0 03 00 	mov    0x3c0(%rsp),%rcx
  1e18c3:	00 
  1e18c4:	48 01 c1             	add    %rax,%rcx
  1e18c7:	48 89 8c 24 70 05 00 	mov    %rcx,0x570(%rsp)
  1e18ce:	00 
  1e18cf:	4c 8b b4 24 a0 03 00 	mov    0x3a0(%rsp),%r14
  1e18d6:	00 
  1e18d7:	49 01 c6             	add    %rax,%r14
  1e18da:	4c 8b a4 24 80 03 00 	mov    0x380(%rsp),%r12
  1e18e1:	00 
  1e18e2:	49 01 c4             	add    %rax,%r12
  1e18e5:	48 8b 9c 24 60 03 00 	mov    0x360(%rsp),%rbx
  1e18ec:	00 
  1e18ed:	48 01 c3             	add    %rax,%rbx
  1e18f0:	48 8b 84 24 d8 03 00 	mov    0x3d8(%rsp),%rax
  1e18f7:	00 
  1e18f8:	48 89 84 24 40 04 00 	mov    %rax,0x440(%rsp)
  1e18ff:	00 
  1e1900:	45 31 ff             	xor    %r15d,%r15d
  1e1903:	c4 62 7d 19 2d 6c 47 	vbroadcastsd -0x1bb894(%rip),%ymm13        # 26078 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x3a8>
  1e190a:	e4 ff 
  1e190c:	c5 7d 10 b4 24 20 04 	vmovupd 0x420(%rsp),%ymm14
  1e1913:	00 00 
  1e1915:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
  1e191c:	00 
  1e191d:	c4 41 19 ef e4       	vpxor  %xmm12,%xmm12,%xmm12
  1e1922:	c4 41 01 57 ff       	vxorpd %xmm15,%xmm15,%xmm15
  1e1927:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  1e192e:	00 00 
  1e1930:	4c 39 f9             	cmp    %r15,%rcx
  1e1933:	0f 84 e1 42 00 00    	je     1e5c1a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5aaa>
  1e1939:	48 8b 84 24 b0 01 00 	mov    0x1b0(%rsp),%rax
  1e1940:	00 
  1e1941:	4a 8b 2c f8          	mov    (%rax,%r15,8),%rbp
  1e1945:	48 85 ed             	test   %rbp,%rbp
  1e1948:	0f 84 72 02 00 00    	je     1e1bc0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x1a50>
  1e194e:	48 8b 84 24 00 04 00 	mov    0x400(%rsp),%rax
  1e1955:	00 
  1e1956:	4e 8d 2c 38          	lea    (%rax,%r15,1),%r13
  1e195a:	4c 3b ac 24 60 02 00 	cmp    0x260(%rsp),%r13
  1e1961:	00 
  1e1962:	0f 83 eb 42 00 00    	jae    1e5c53 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5ae3>
  1e1968:	c5 fb 11 a4 24 40 03 	vmovsd %xmm4,0x340(%rsp)
  1e196f:	00 00 
  1e1971:	c5 7b 11 9c 24 20 03 	vmovsd %xmm11,0x320(%rsp)
  1e1978:	00 00 
  1e197a:	4c 3b ac 24 00 03 00 	cmp    0x300(%rsp),%r13
  1e1981:	00 
  1e1982:	0f 83 f6 42 00 00    	jae    1e5c7e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5b0e>
  1e1988:	c4 a1 7b 10 04 fb    	vmovsd (%rbx,%r15,8),%xmm0
  1e198e:	c4 81 7b 10 0c fc    	vmovsd (%r12,%r15,8),%xmm1
  1e1994:	48 8b 84 24 40 02 00 	mov    0x240(%rsp),%rax
  1e199b:	00 
  1e199c:	c4 a1 7b 10 14 f8    	vmovsd (%rax,%r15,8),%xmm2
  1e19a2:	c5 fb 11 94 24 a0 02 	vmovsd %xmm2,0x2a0(%rsp)
  1e19a9:	00 00 
  1e19ab:	48 89 ef             	mov    %rbp,%rdi
  1e19ae:	c5 f8 77             	vzeroupper
  1e19b1:	ff 15 b1 8e 10 00    	call   *0x108eb1(%rip)        # 2ea868 <_DYNAMIC+0xa50>
  1e19b7:	c5 fb 10 54 24 10    	vmovsd 0x10(%rsp),%xmm2
  1e19bd:	c5 fb 58 d2          	vaddsd %xmm2,%xmm0,%xmm2
  1e19c1:	c5 fb 11 94 24 10 01 	vmovsd %xmm2,0x110(%rsp)
  1e19c8:	00 00 
  1e19ca:	c5 fb 10 84 24 20 02 	vmovsd 0x220(%rsp),%xmm0
  1e19d1:	00 00 
  1e19d3:	c5 f3 58 c0          	vaddsd %xmm0,%xmm1,%xmm0
  1e19d7:	c5 fb 11 84 24 18 01 	vmovsd %xmm0,0x118(%rsp)
  1e19de:	00 00 
  1e19e0:	4c 3b ac 24 e0 02 00 	cmp    0x2e0(%rsp),%r13
  1e19e7:	00 
  1e19e8:	0f 83 bb 42 00 00    	jae    1e5ca9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5b39>
  1e19ee:	c5 fb 11 84 24 20 02 	vmovsd %xmm0,0x220(%rsp)
  1e19f5:	00 00 
  1e19f7:	c5 fb 11 54 24 10    	vmovsd %xmm2,0x10(%rsp)
  1e19fd:	4c 3b ac 24 c0 02 00 	cmp    0x2c0(%rsp),%r13
  1e1a04:	00 
  1e1a05:	0f 83 c6 42 00 00    	jae    1e5cd1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5b61>
  1e1a0b:	c4 81 7b 10 04 fe    	vmovsd (%r14,%r15,8),%xmm0
  1e1a11:	48 8b 84 24 70 05 00 	mov    0x570(%rsp),%rax
  1e1a18:	00 
  1e1a19:	c4 a1 7b 10 0c f8    	vmovsd (%rax,%r15,8),%xmm1
  1e1a1f:	c5 fb 10 94 24 a0 02 	vmovsd 0x2a0(%rsp),%xmm2
  1e1a26:	00 00 
  1e1a28:	48 89 ef             	mov    %rbp,%rdi
  1e1a2b:	ff 15 37 8e 10 00    	call   *0x108e37(%rip)        # 2ea868 <_DYNAMIC+0xa50>
  1e1a31:	c5 fb 10 94 24 00 02 	vmovsd 0x200(%rsp),%xmm2
  1e1a38:	00 00 
  1e1a3a:	c5 fb 58 d2          	vaddsd %xmm2,%xmm0,%xmm2
  1e1a3e:	c5 fb 11 94 24 20 01 	vmovsd %xmm2,0x120(%rsp)
  1e1a45:	00 00 
  1e1a47:	c5 fb 10 84 24 c0 01 	vmovsd 0x1c0(%rsp),%xmm0
  1e1a4e:	00 00 
  1e1a50:	c5 f3 58 c0          	vaddsd %xmm0,%xmm1,%xmm0
  1e1a54:	c5 fb 11 84 24 28 01 	vmovsd %xmm0,0x128(%rsp)
  1e1a5b:	00 00 
  1e1a5d:	4c 3b ac 24 10 05 00 	cmp    0x510(%rsp),%r13
  1e1a64:	00 
  1e1a65:	0f 83 d8 41 00 00    	jae    1e5c43 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5ad3>
  1e1a6b:	c5 fb 11 84 24 c0 01 	vmovsd %xmm0,0x1c0(%rsp)
  1e1a72:	00 00 
  1e1a74:	c5 fb 11 94 24 00 02 	vmovsd %xmm2,0x200(%rsp)
  1e1a7b:	00 00 
  1e1a7d:	4c 3b ac 24 80 04 00 	cmp    0x480(%rsp),%r13
  1e1a84:	00 
  1e1a85:	0f 83 e3 41 00 00    	jae    1e5c6e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5afe>
  1e1a8b:	48 8b 84 24 30 05 00 	mov    0x530(%rsp),%rax
  1e1a92:	00 
  1e1a93:	c4 a1 7b 10 04 f8    	vmovsd (%rax,%r15,8),%xmm0
  1e1a99:	48 8b 84 24 50 05 00 	mov    0x550(%rsp),%rax
  1e1aa0:	00 
  1e1aa1:	c4 a1 7b 10 0c f8    	vmovsd (%rax,%r15,8),%xmm1
  1e1aa7:	48 8b 84 24 40 02 00 	mov    0x240(%rsp),%rax
  1e1aae:	00 
  1e1aaf:	c4 a1 7b 10 14 f8    	vmovsd (%rax,%r15,8),%xmm2
  1e1ab5:	c5 fb 11 94 24 a0 02 	vmovsd %xmm2,0x2a0(%rsp)
  1e1abc:	00 00 
  1e1abe:	48 89 ef             	mov    %rbp,%rdi
  1e1ac1:	ff 15 a1 8d 10 00    	call   *0x108da1(%rip)        # 2ea868 <_DYNAMIC+0xa50>
  1e1ac7:	c5 fb 10 94 24 50 01 	vmovsd 0x150(%rsp),%xmm2
  1e1ace:	00 00 
  1e1ad0:	c5 fb 58 d2          	vaddsd %xmm2,%xmm0,%xmm2
  1e1ad4:	c5 fb 11 94 24 30 01 	vmovsd %xmm2,0x130(%rsp)
  1e1adb:	00 00 
  1e1add:	c5 fb 10 84 24 90 01 	vmovsd 0x190(%rsp),%xmm0
  1e1ae4:	00 00 
  1e1ae6:	c5 f3 58 c0          	vaddsd %xmm0,%xmm1,%xmm0
  1e1aea:	c5 fb 11 84 24 38 01 	vmovsd %xmm0,0x138(%rsp)
  1e1af1:	00 00 
  1e1af3:	4c 3b ac 24 60 04 00 	cmp    0x460(%rsp),%r13
  1e1afa:	00 
  1e1afb:	0f 83 98 41 00 00    	jae    1e5c99 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5b29>
  1e1b01:	c5 fb 11 84 24 90 01 	vmovsd %xmm0,0x190(%rsp)
  1e1b08:	00 00 
  1e1b0a:	c5 fb 11 94 24 50 01 	vmovsd %xmm2,0x150(%rsp)
  1e1b11:	00 00 
  1e1b13:	4c 3b ac 24 40 04 00 	cmp    0x440(%rsp),%r13
  1e1b1a:	00 
  1e1b1b:	0f 83 a0 41 00 00    	jae    1e5cc1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5b51>
  1e1b21:	48 8b 84 24 c0 05 00 	mov    0x5c0(%rsp),%rax
  1e1b28:	00 
  1e1b29:	c4 a1 7b 10 04 f8    	vmovsd (%rax,%r15,8),%xmm0
  1e1b2f:	48 8b 84 24 a0 05 00 	mov    0x5a0(%rsp),%rax
  1e1b36:	00 
  1e1b37:	c4 a1 7b 10 0c f8    	vmovsd (%rax,%r15,8),%xmm1
  1e1b3d:	c5 fb 10 94 24 a0 02 	vmovsd 0x2a0(%rsp),%xmm2
  1e1b44:	00 00 
  1e1b46:	48 89 ef             	mov    %rbp,%rdi
  1e1b49:	ff 15 19 8d 10 00    	call   *0x108d19(%rip)        # 2ea868 <_DYNAMIC+0xa50>
  1e1b4f:	c5 7b 10 9c 24 20 03 	vmovsd 0x320(%rsp),%xmm11
  1e1b56:	00 00 
  1e1b58:	c5 23 58 d8          	vaddsd %xmm0,%xmm11,%xmm11
  1e1b5c:	c5 7b 11 9c 24 40 01 	vmovsd %xmm11,0x140(%rsp)
  1e1b63:	00 00 
  1e1b65:	c5 fb 10 a4 24 40 03 	vmovsd 0x340(%rsp),%xmm4
  1e1b6c:	00 00 
  1e1b6e:	c5 f3 58 e4          	vaddsd %xmm4,%xmm1,%xmm4
  1e1b72:	48 8b b4 24 e0 03 00 	mov    0x3e0(%rsp),%rsi
  1e1b79:	00 
  1e1b7a:	c4 62 7d 19 2d f5 44 	vbroadcastsd -0x1bbb0b(%rip),%ymm13        # 26078 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x3a8>
  1e1b81:	e4 ff 
  1e1b83:	c5 7d 10 b4 24 20 04 	vmovupd 0x420(%rsp),%ymm14
  1e1b8a:	00 00 
  1e1b8c:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
  1e1b93:	00 
  1e1b94:	c4 41 19 ef e4       	vpxor  %xmm12,%xmm12,%xmm12
  1e1b99:	c4 41 01 57 ff       	vxorpd %xmm15,%xmm15,%xmm15
  1e1b9e:	49 ff c7             	inc    %r15
  1e1ba1:	c5 fb 11 a4 24 48 01 	vmovsd %xmm4,0x148(%rsp)
  1e1ba8:	00 00 
  1e1baa:	4c 39 fe             	cmp    %r15,%rsi
  1e1bad:	0f 85 7d fd ff ff    	jne    1e1930 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x17c0>
  1e1bb3:	e9 79 02 00 00       	jmp    1e1e31 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x1cc1>
  1e1bb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  1e1bbf:	00 
  1e1bc0:	48 8b 84 24 40 02 00 	mov    0x240(%rsp),%rax
  1e1bc7:	00 
  1e1bc8:	c4 a1 7b 10 04 f8    	vmovsd (%rax,%r15,8),%xmm0
  1e1bce:	c4 c1 79 2e c7       	vucomisd %xmm15,%xmm0
  1e1bd3:	75 02                	jne    1e1bd7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x1a67>
  1e1bd5:	7b 46                	jnp    1e1c1d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x1aad>
  1e1bd7:	c5 f9 54 0d a1 39 e4 	vandpd -0x1bc65f(%rip),%xmm0,%xmm1        # 25580 <__abi_tag+0x25284>
  1e1bde:	ff 
  1e1bdf:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  1e1be4:	48 c1 e8 34          	shr    $0x34,%rax
  1e1be8:	25 ff 07 00 00       	and    $0x7ff,%eax
  1e1bed:	3d ff 07 00 00       	cmp    $0x7ff,%eax
  1e1bf2:	0f 92 c0             	setb   %al
  1e1bf5:	c5 f9 2e 0d c3 46 e4 	vucomisd -0x1bb93d(%rip),%xmm1        # 262c0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x5f0>
  1e1bfc:	ff 
  1e1bfd:	0f 82 4b fd ff ff    	jb     1e194e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x17de>
  1e1c03:	84 c0                	test   %al,%al
  1e1c05:	0f 84 43 fd ff ff    	je     1e194e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x17de>
  1e1c0b:	c5 fb 10 15 35 46 e4 	vmovsd -0x1bb9cb(%rip),%xmm2        # 26248 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x578>
  1e1c12:	ff 
  1e1c13:	c5 f9 2e d1          	vucomisd %xmm1,%xmm2
  1e1c17:	0f 82 31 fd ff ff    	jb     1e194e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x17de>
  1e1c1d:	48 8b 84 24 00 04 00 	mov    0x400(%rsp),%rax
  1e1c24:	00 
  1e1c25:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
  1e1c29:	48 3b bc 24 60 02 00 	cmp    0x260(%rsp),%rdi
  1e1c30:	00 
  1e1c31:	0f 83 72 42 00 00    	jae    1e5ea9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5d39>
  1e1c37:	c4 a1 7b 59 0c fb    	vmulsd (%rbx,%r15,8),%xmm0,%xmm1
  1e1c3d:	c5 fb 10 54 24 10    	vmovsd 0x10(%rsp),%xmm2
  1e1c43:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  1e1c47:	c5 fb 11 54 24 10    	vmovsd %xmm2,0x10(%rsp)
  1e1c4d:	c5 fb 11 94 24 10 01 	vmovsd %xmm2,0x110(%rsp)
  1e1c54:	00 00 
  1e1c56:	48 3b bc 24 00 03 00 	cmp    0x300(%rsp),%rdi
  1e1c5d:	00 
  1e1c5e:	0f 83 6d 42 00 00    	jae    1e5ed1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5d61>
  1e1c64:	c4 81 7b 59 0c fc    	vmulsd (%r12,%r15,8),%xmm0,%xmm1
  1e1c6a:	c5 fb 10 94 24 20 02 	vmovsd 0x220(%rsp),%xmm2
  1e1c71:	00 00 
  1e1c73:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  1e1c77:	c5 fb 11 94 24 20 02 	vmovsd %xmm2,0x220(%rsp)
  1e1c7e:	00 00 
  1e1c80:	c5 fb 11 94 24 18 01 	vmovsd %xmm2,0x118(%rsp)
  1e1c87:	00 00 
  1e1c89:	48 3b bc 24 e0 02 00 	cmp    0x2e0(%rsp),%rdi
  1e1c90:	00 
  1e1c91:	0f 83 62 42 00 00    	jae    1e5ef9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5d89>
  1e1c97:	c4 81 7b 59 0c fe    	vmulsd (%r14,%r15,8),%xmm0,%xmm1
  1e1c9d:	c5 fb 10 94 24 00 02 	vmovsd 0x200(%rsp),%xmm2
  1e1ca4:	00 00 
  1e1ca6:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  1e1caa:	c5 fb 11 94 24 00 02 	vmovsd %xmm2,0x200(%rsp)
  1e1cb1:	00 00 
  1e1cb3:	c5 fb 11 94 24 20 01 	vmovsd %xmm2,0x120(%rsp)
  1e1cba:	00 00 
  1e1cbc:	48 3b bc 24 c0 02 00 	cmp    0x2c0(%rsp),%rdi
  1e1cc3:	00 
  1e1cc4:	0f 83 b7 41 00 00    	jae    1e5e81 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5d11>
  1e1cca:	48 8b 84 24 70 05 00 	mov    0x570(%rsp),%rax
  1e1cd1:	00 
  1e1cd2:	c4 a1 7b 59 0c f8    	vmulsd (%rax,%r15,8),%xmm0,%xmm1
  1e1cd8:	c5 fb 10 94 24 c0 01 	vmovsd 0x1c0(%rsp),%xmm2
  1e1cdf:	00 00 
  1e1ce1:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  1e1ce5:	c5 fb 11 94 24 c0 01 	vmovsd %xmm2,0x1c0(%rsp)
  1e1cec:	00 00 
  1e1cee:	c5 fb 11 94 24 28 01 	vmovsd %xmm2,0x128(%rsp)
  1e1cf5:	00 00 
  1e1cf7:	48 3b bc 24 10 05 00 	cmp    0x510(%rsp),%rdi
  1e1cfe:	00 
  1e1cff:	0f 83 94 41 00 00    	jae    1e5e99 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5d29>
  1e1d05:	48 8b 84 24 30 05 00 	mov    0x530(%rsp),%rax
  1e1d0c:	00 
  1e1d0d:	c4 a1 7b 59 0c f8    	vmulsd (%rax,%r15,8),%xmm0,%xmm1
  1e1d13:	c5 fb 10 94 24 50 01 	vmovsd 0x150(%rsp),%xmm2
  1e1d1a:	00 00 
  1e1d1c:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  1e1d20:	c5 fb 11 94 24 50 01 	vmovsd %xmm2,0x150(%rsp)
  1e1d27:	00 00 
  1e1d29:	c5 fb 11 94 24 30 01 	vmovsd %xmm2,0x130(%rsp)
  1e1d30:	00 00 
  1e1d32:	48 3b bc 24 80 04 00 	cmp    0x480(%rsp),%rdi
  1e1d39:	00 
  1e1d3a:	0f 83 81 41 00 00    	jae    1e5ec1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5d51>
  1e1d40:	48 8b 84 24 50 05 00 	mov    0x550(%rsp),%rax
  1e1d47:	00 
  1e1d48:	c4 a1 7b 59 0c f8    	vmulsd (%rax,%r15,8),%xmm0,%xmm1
  1e1d4e:	c5 fb 10 94 24 90 01 	vmovsd 0x190(%rsp),%xmm2
  1e1d55:	00 00 
  1e1d57:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  1e1d5b:	c5 fb 11 94 24 90 01 	vmovsd %xmm2,0x190(%rsp)
  1e1d62:	00 00 
  1e1d64:	c5 fb 11 94 24 38 01 	vmovsd %xmm2,0x138(%rsp)
  1e1d6b:	00 00 
  1e1d6d:	48 3b bc 24 60 04 00 	cmp    0x460(%rsp),%rdi
  1e1d74:	00 
  1e1d75:	0f 83 6e 41 00 00    	jae    1e5ee9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5d79>
  1e1d7b:	48 8b 84 24 c0 05 00 	mov    0x5c0(%rsp),%rax
  1e1d82:	00 
  1e1d83:	c4 a1 7b 59 0c f8    	vmulsd (%rax,%r15,8),%xmm0,%xmm1
  1e1d89:	c5 23 58 d9          	vaddsd %xmm1,%xmm11,%xmm11
  1e1d8d:	c5 7b 11 9c 24 40 01 	vmovsd %xmm11,0x140(%rsp)
  1e1d94:	00 00 
  1e1d96:	48 3b bc 24 40 04 00 	cmp    0x440(%rsp),%rdi
  1e1d9d:	00 
  1e1d9e:	0f 83 cd 40 00 00    	jae    1e5e71 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5d01>
  1e1da4:	48 8b 84 24 a0 05 00 	mov    0x5a0(%rsp),%rax
  1e1dab:	00 
  1e1dac:	c4 a1 7b 59 04 f8    	vmulsd (%rax,%r15,8),%xmm0,%xmm0
  1e1db2:	c5 db 58 e0          	vaddsd %xmm0,%xmm4,%xmm4
  1e1db6:	49 ff c7             	inc    %r15
  1e1db9:	c5 fb 11 a4 24 48 01 	vmovsd %xmm4,0x148(%rsp)
  1e1dc0:	00 00 
  1e1dc2:	4c 39 fe             	cmp    %r15,%rsi
  1e1dc5:	0f 85 65 fb ff ff    	jne    1e1930 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x17c0>
  1e1dcb:	eb 64                	jmp    1e1e31 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x1cc1>
  1e1dcd:	c5 fb 10 84 24 28 01 	vmovsd 0x128(%rsp),%xmm0
  1e1dd4:	00 00 
  1e1dd6:	c5 fb 11 84 24 c0 01 	vmovsd %xmm0,0x1c0(%rsp)
  1e1ddd:	00 00 
  1e1ddf:	c5 fb 10 84 24 30 01 	vmovsd 0x130(%rsp),%xmm0
  1e1de6:	00 00 
  1e1de8:	c5 fb 11 84 24 50 01 	vmovsd %xmm0,0x150(%rsp)
  1e1def:	00 00 
  1e1df1:	c5 fb 10 84 24 38 01 	vmovsd 0x138(%rsp),%xmm0
  1e1df8:	00 00 
  1e1dfa:	c5 fb 11 84 24 90 01 	vmovsd %xmm0,0x190(%rsp)
  1e1e01:	00 00 
  1e1e03:	c5 7b 10 9c 24 40 01 	vmovsd 0x140(%rsp),%xmm11
  1e1e0a:	00 00 
  1e1e0c:	c5 fb 10 a4 24 48 01 	vmovsd 0x148(%rsp),%xmm4
  1e1e13:	00 00 
  1e1e15:	c4 62 7d 19 2d 5a 42 	vbroadcastsd -0x1bbda6(%rip),%ymm13        # 26078 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x3a8>
  1e1e1c:	e4 ff 
  1e1e1e:	c5 7d 10 b4 24 20 04 	vmovupd 0x420(%rsp),%ymm14
  1e1e25:	00 00 
  1e1e27:	c4 41 19 ef e4       	vpxor  %xmm12,%xmm12,%xmm12
  1e1e2c:	c4 41 01 57 ff       	vxorpd %xmm15,%xmm15,%xmm15
  1e1e31:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  1e1e36:	48 85 ff             	test   %rdi,%rdi
  1e1e39:	c5 7b 11 9c 24 20 03 	vmovsd %xmm11,0x320(%rsp)
  1e1e40:	00 00 
  1e1e42:	c5 fb 11 a4 24 40 03 	vmovsd %xmm4,0x340(%rsp)
  1e1e49:	00 00 
  1e1e4b:	0f 84 63 04 00 00    	je     1e22b4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2144>
  1e1e51:	c4 e2 7d 19 84 24 c0 	vbroadcastsd 0x7c0(%rsp),%ymm0
  1e1e58:	07 00 00 
  1e1e5b:	c4 e2 7d 19 8c 24 a0 	vbroadcastsd 0x7a0(%rsp),%ymm1
  1e1e62:	07 00 00 
  1e1e65:	40 b5 01             	mov    $0x1,%bpl
  1e1e68:	31 c0                	xor    %eax,%eax
  1e1e6a:	4c 8b 84 24 b0 04 00 	mov    0x4b0(%rsp),%r8
  1e1e71:	00 
  1e1e72:	4c 8b 8c 24 a8 04 00 	mov    0x4a8(%rsp),%r9
  1e1e79:	00 
  1e1e7a:	4c 8b 54 24 58       	mov    0x58(%rsp),%r10
  1e1e7f:	4c 8b 9c 24 d0 04 00 	mov    0x4d0(%rsp),%r11
  1e1e86:	00 
  1e1e87:	4c 8b b4 24 b0 06 00 	mov    0x6b0(%rsp),%r14
  1e1e8e:	00 
  1e1e8f:	4c 39 c8             	cmp    %r9,%rax
  1e1e92:	0f 84 5a 42 00 00    	je     1e60f2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5f82>
  1e1e98:	48 39 f8             	cmp    %rdi,%rax
  1e1e9b:	0f 84 3e 42 00 00    	je     1e60df <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5f6f>
  1e1ea1:	4c 39 d8             	cmp    %r11,%rax
  1e1ea4:	0f 84 1f 42 00 00    	je     1e60c9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5f59>
  1e1eaa:	48 89 c1             	mov    %rax,%rcx
  1e1ead:	48 c1 e1 05          	shl    $0x5,%rcx
  1e1eb1:	c4 c1 7d 10 24 0e    	vmovupd (%r14,%rcx,1),%ymm4
  1e1eb7:	c4 c1 7d 10 14 08    	vmovupd (%r8,%rcx,1),%ymm2
  1e1ebd:	c4 e2 fd a8 d1       	vfmadd213pd %ymm1,%ymm0,%ymm2
  1e1ec2:	c4 c2 dd a8 14 0a    	vfmadd213pd (%r10,%rcx,1),%ymm4,%ymm2
  1e1ec8:	c5 8d 54 f4          	vandpd %ymm4,%ymm14,%ymm6
  1e1ecc:	c5 8d 54 fa          	vandpd %ymm2,%ymm14,%ymm7
  1e1ed0:	c4 e2 7d 19 2d 5f 40 	vbroadcastsd -0x1bbfa1(%rip),%ymm5        # 25f38 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x268>
  1e1ed7:	e4 ff 
  1e1ed9:	c5 cd c2 dd 12       	vcmple_oqpd %ymm5,%ymm6,%ymm3
  1e1ede:	c5 c5 c2 ed 12       	vcmple_oqpd %ymm5,%ymm7,%ymm5
  1e1ee3:	c5 d5 54 db          	vandpd %ymm3,%ymm5,%ymm3
  1e1ee7:	c4 e2 1d 37 db       	vpcmpgtq %ymm3,%ymm12,%ymm3
  1e1eec:	c4 e2 7d 59 2d b3 42 	vpbroadcastq -0x1bbd4d(%rip),%ymm5        # 261a8 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x4d8>
  1e1ef3:	e4 ff 
  1e1ef5:	c5 e5 db dd          	vpand  %ymm5,%ymm3,%ymm3
  1e1ef9:	c4 c3 7d 39 d8 01    	vextracti128 $0x1,%ymm3,%xmm8
  1e1eff:	c4 c1 61 5d d8       	vminpd %xmm8,%xmm3,%xmm3
  1e1f04:	c5 61 c6 c3 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm8
  1e1f09:	c4 c1 63 5d d8       	vminsd %xmm8,%xmm3,%xmm3
  1e1f0e:	c4 c1 79 2e df       	vucomisd %xmm15,%xmm3
  1e1f13:	0f 86 92 1b 00 00    	jbe    1e3aab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393b>
  1e1f19:	48 8b 94 24 80 01 00 	mov    0x180(%rsp),%rdx
  1e1f20:	00 
  1e1f21:	c5 fe 6f 1c 0a       	vmovdqu (%rdx,%rcx,1),%ymm3
  1e1f26:	c5 cd 5f f7          	vmaxpd %ymm7,%ymm6,%ymm6
  1e1f2a:	c4 62 7d 19 15 15 43 	vbroadcastsd -0x1bbceb(%rip),%ymm10        # 26248 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x578>
  1e1f31:	e4 ff 
  1e1f33:	c4 41 4d c2 c2 12    	vcmple_oqpd %ymm10,%ymm6,%ymm8
  1e1f39:	c5 9d c2 fe 00       	vcmpeqpd %ymm6,%ymm12,%ymm7
  1e1f3e:	c4 62 7d 19 0d 79 43 	vbroadcastsd -0x1bbc87(%rip),%ymm9        # 262c0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x5f0>
  1e1f45:	e4 ff 
  1e1f47:	c4 41 4d c2 c9 1d    	vcmpge_oqpd %ymm9,%ymm6,%ymm9
  1e1f4d:	c5 35 56 cf          	vorpd  %ymm7,%ymm9,%ymm9
  1e1f51:	c4 41 35 54 c0       	vandpd %ymm8,%ymm9,%ymm8
  1e1f56:	c4 42 1d 37 c0       	vpcmpgtq %ymm8,%ymm12,%ymm8
  1e1f5b:	c5 3d db c5          	vpand  %ymm5,%ymm8,%ymm8
  1e1f5f:	c4 43 7d 39 c1 01    	vextracti128 $0x1,%ymm8,%xmm9
  1e1f65:	c4 41 39 5d c1       	vminpd %xmm9,%xmm8,%xmm8
  1e1f6a:	c4 41 39 c6 c8 01    	vshufpd $0x1,%xmm8,%xmm8,%xmm9
  1e1f70:	c4 41 3b 5d c1       	vminsd %xmm9,%xmm8,%xmm8
  1e1f75:	c4 41 79 2e c7       	vucomisd %xmm15,%xmm8
  1e1f7a:	76 34                	jbe    1e1fb0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x1e40>
  1e1f7c:	c4 c2 65 29 e4       	vpcmpeqq %ymm12,%ymm3,%ymm4
  1e1f81:	c5 dd db e5          	vpand  %ymm5,%ymm4,%ymm4
  1e1f85:	c4 e3 7d 39 e5 01    	vextracti128 $0x1,%ymm4,%xmm5
  1e1f8b:	c5 d9 5d e5          	vminpd %xmm5,%xmm4,%xmm4
  1e1f8f:	c5 d9 c6 ec 01       	vshufpd $0x1,%xmm4,%xmm4,%xmm5
  1e1f94:	c5 db 5d e5          	vminsd %xmm5,%xmm4,%xmm4
  1e1f98:	c4 c1 79 2e e7       	vucomisd %xmm15,%xmm4
  1e1f9d:	0f 87 e1 02 00 00    	ja     1e2284 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2114>
  1e1fa3:	31 ed                	xor    %ebp,%ebp
  1e1fa5:	e9 da 02 00 00       	jmp    1e2284 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2114>
  1e1faa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  1e1fb0:	c4 41 4d c2 c2 1e    	vcmpgt_oqpd %ymm10,%ymm6,%ymm8
  1e1fb6:	c4 42 1d 37 c8       	vpcmpgtq %ymm8,%ymm12,%ymm9
  1e1fbb:	c5 35 db d5          	vpand  %ymm5,%ymm9,%ymm10
  1e1fbf:	c4 43 7d 39 d3 01    	vextracti128 $0x1,%ymm10,%xmm11
  1e1fc5:	c4 41 29 5f d3       	vmaxpd %xmm11,%xmm10,%xmm10
  1e1fca:	c4 41 29 c6 da 01    	vshufpd $0x1,%xmm10,%xmm10,%xmm11
  1e1fd0:	c4 41 2b 5f d3       	vmaxsd %xmm11,%xmm10,%xmm10
  1e1fd5:	c4 41 79 2e d7       	vucomisd %xmm15,%xmm10
  1e1fda:	0f 86 db 00 00 00    	jbe    1e20bb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x1f4b>
  1e1fe0:	c4 63 7d 39 ce 01    	vextracti128 $0x1,%ymm9,%xmm6
  1e1fe6:	c5 b1 6b fe          	vpackssdw %xmm6,%xmm9,%xmm7
  1e1fea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  1e1ff0:	c4 e2 7d 59 35 27 47 	vpbroadcastq -0x1bb8d9(%rip),%ymm6        # 26720 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0xa50>
  1e1ff7:	e4 ff 
  1e1ff9:	c4 e2 65 37 f6       	vpcmpgtq %ymm6,%ymm3,%ymm6
  1e1ffe:	c4 42 1d 37 c0       	vpcmpgtq %ymm8,%ymm12,%ymm8
  1e2003:	c5 3d db c5          	vpand  %ymm5,%ymm8,%ymm8
  1e2007:	c5 bd db f6          	vpand  %ymm6,%ymm8,%ymm6
  1e200b:	c4 c3 7d 39 f0 01    	vextracti128 $0x1,%ymm6,%xmm8
  1e2011:	c4 c1 49 5f f0       	vmaxpd %xmm8,%xmm6,%xmm6
  1e2016:	c5 49 c6 c6 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm8
  1e201b:	c4 c1 4b 5f f0       	vmaxsd %xmm8,%xmm6,%xmm6
  1e2020:	c4 c1 79 2e f7       	vucomisd %xmm15,%xmm6
  1e2025:	0f 87 80 1a 00 00    	ja     1e3aab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393b>
  1e202b:	c4 62 7d 19 05 5c 45 	vbroadcastsd -0x1bbaa4(%rip),%ymm8        # 26590 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x8c0>
  1e2032:	e4 ff 
  1e2034:	c5 bd 59 f4          	vmulpd %ymm4,%ymm8,%ymm6
  1e2038:	c5 c1 72 f7 1f       	vpslld $0x1f,%xmm7,%xmm7
  1e203d:	c5 c1 72 e7 1f       	vpsrad $0x1f,%xmm7,%xmm7
  1e2042:	c4 e2 7d 25 ff       	vpmovsxdq %xmm7,%ymm7
  1e2047:	c4 e3 5d 4b e6 70    	vblendvpd %ymm7,%ymm6,%ymm4,%ymm4
  1e204d:	c5 bd 59 f2          	vmulpd %ymm2,%ymm8,%ymm6
  1e2051:	c4 e3 6d 4b d6 70    	vblendvpd %ymm7,%ymm6,%ymm2,%ymm2
  1e2057:	c4 e2 7d 59 35 20 40 	vpbroadcastq -0x1bbfe0(%rip),%ymm6        # 26080 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x3b0>
  1e205e:	e4 ff 
  1e2060:	c5 c5 db f6          	vpand  %ymm6,%ymm7,%ymm6
  1e2064:	c5 e5 d4 de          	vpaddq %ymm6,%ymm3,%ymm3
  1e2068:	c5 8d 54 f4          	vandpd %ymm4,%ymm14,%ymm6
  1e206c:	c5 8d 54 fa          	vandpd %ymm2,%ymm14,%ymm7
  1e2070:	c5 cd 5f f7          	vmaxpd %ymm7,%ymm6,%ymm6
  1e2074:	c4 e2 7d 19 3d cb 41 	vbroadcastsd -0x1bbe35(%rip),%ymm7        # 26248 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x578>
  1e207b:	e4 ff 
  1e207d:	c5 4d c2 c7 1e       	vcmpgt_oqpd %ymm7,%ymm6,%ymm8
  1e2082:	c4 42 1d 37 c8       	vpcmpgtq %ymm8,%ymm12,%ymm9
  1e2087:	c4 63 7d 39 cf 01    	vextracti128 $0x1,%ymm9,%xmm7
  1e208d:	c5 b1 6b ff          	vpackssdw %xmm7,%xmm9,%xmm7
  1e2091:	c5 35 db cd          	vpand  %ymm5,%ymm9,%ymm9
  1e2095:	c4 43 7d 39 ca 01    	vextracti128 $0x1,%ymm9,%xmm10
  1e209b:	c4 41 31 5f ca       	vmaxpd %xmm10,%xmm9,%xmm9
  1e20a0:	c4 41 31 c6 d1 01    	vshufpd $0x1,%xmm9,%xmm9,%xmm10
  1e20a6:	c4 41 33 5f ca       	vmaxsd %xmm10,%xmm9,%xmm9
  1e20ab:	c4 41 79 2e cf       	vucomisd %xmm15,%xmm9
  1e20b0:	0f 87 3a ff ff ff    	ja     1e1ff0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x1e80>
  1e20b6:	c5 9d c2 fe 00       	vcmpeqpd %ymm6,%ymm12,%ymm7
  1e20bb:	c4 62 7d 19 05 fc 41 	vbroadcastsd -0x1bbe04(%rip),%ymm8        # 262c0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x5f0>
  1e20c2:	e4 ff 
  1e20c4:	c4 41 4d c2 c0 11    	vcmplt_oqpd %ymm8,%ymm6,%ymm8
  1e20ca:	c4 41 45 55 c0       	vandnpd %ymm8,%ymm7,%ymm8
  1e20cf:	c4 42 1d 37 c8       	vpcmpgtq %ymm8,%ymm12,%ymm9
  1e20d4:	c5 35 db d5          	vpand  %ymm5,%ymm9,%ymm10
  1e20d8:	c4 43 7d 39 d3 01    	vextracti128 $0x1,%ymm10,%xmm11
  1e20de:	c4 41 29 5f d3       	vmaxpd %xmm11,%xmm10,%xmm10
  1e20e3:	c4 41 29 c6 da 01    	vshufpd $0x1,%xmm10,%xmm10,%xmm11
  1e20e9:	c4 41 2b 5f d3       	vmaxsd %xmm11,%xmm10,%xmm10
  1e20ee:	c4 41 79 2e d7       	vucomisd %xmm15,%xmm10
  1e20f3:	0f 86 e9 00 00 00    	jbe    1e21e2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2072>
  1e20f9:	c4 63 7d 39 ce 01    	vextracti128 $0x1,%ymm9,%xmm6
  1e20ff:	c5 31 6b ce          	vpackssdw %xmm6,%xmm9,%xmm9
  1e2103:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e210a:	84 00 00 00 00 00 
  1e2110:	c4 e2 7d 59 35 9f 45 	vpbroadcastq -0x1bba61(%rip),%ymm6        # 266b8 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x9e8>
  1e2117:	e4 ff 
  1e2119:	c4 e2 65 37 f6       	vpcmpgtq %ymm6,%ymm3,%ymm6
  1e211e:	c4 c2 1d 37 f8       	vpcmpgtq %ymm8,%ymm12,%ymm7
  1e2123:	c5 cd df f7          	vpandn %ymm7,%ymm6,%ymm6
  1e2127:	c5 cd db f5          	vpand  %ymm5,%ymm6,%ymm6
  1e212b:	c4 e3 7d 39 f7 01    	vextracti128 $0x1,%ymm6,%xmm7
  1e2131:	c5 c9 5f f7          	vmaxpd %xmm7,%xmm6,%xmm6
  1e2135:	c5 c9 c6 fe 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm7
  1e213a:	c5 cb 5f f7          	vmaxsd %xmm7,%xmm6,%xmm6
  1e213e:	c4 c1 79 2e f7       	vucomisd %xmm15,%xmm6
  1e2143:	0f 87 62 19 00 00    	ja     1e3aab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393b>
  1e2149:	c4 e2 7d 59 35 66 46 	vpbroadcastq -0x1bb99a(%rip),%ymm6        # 267b8 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0xae8>
  1e2150:	e4 ff 
  1e2152:	c4 62 7d 19 15 a5 45 	vbroadcastsd -0x1bba5b(%rip),%ymm10        # 26700 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0xa30>
  1e2159:	e4 ff 
  1e215b:	c5 ad 59 fc          	vmulpd %ymm4,%ymm10,%ymm7
  1e215f:	c4 c1 39 72 f1 1f    	vpslld $0x1f,%xmm9,%xmm8
  1e2165:	c4 c1 39 72 e0 1f    	vpsrad $0x1f,%xmm8,%xmm8
  1e216b:	c4 42 7d 25 c0       	vpmovsxdq %xmm8,%ymm8
  1e2170:	c4 e3 5d 4b e7 80    	vblendvpd %ymm8,%ymm7,%ymm4,%ymm4
  1e2176:	c5 ad 59 fa          	vmulpd %ymm2,%ymm10,%ymm7
  1e217a:	c4 e3 6d 4b d7 80    	vblendvpd %ymm8,%ymm7,%ymm2,%ymm2
  1e2180:	c5 bd db f6          	vpand  %ymm6,%ymm8,%ymm6
  1e2184:	c5 e5 d4 de          	vpaddq %ymm6,%ymm3,%ymm3
  1e2188:	c5 8d 54 f4          	vandpd %ymm4,%ymm14,%ymm6
  1e218c:	c5 8d 54 fa          	vandpd %ymm2,%ymm14,%ymm7
  1e2190:	c5 cd 5f f7          	vmaxpd %ymm7,%ymm6,%ymm6
  1e2194:	c5 9d c2 fe 00       	vcmpeqpd %ymm6,%ymm12,%ymm7
  1e2199:	c4 62 7d 19 05 1e 41 	vbroadcastsd -0x1bbee2(%rip),%ymm8        # 262c0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x5f0>
  1e21a0:	e4 ff 
  1e21a2:	c4 41 4d c2 c0 11    	vcmplt_oqpd %ymm8,%ymm6,%ymm8
  1e21a8:	c4 41 45 55 c0       	vandnpd %ymm8,%ymm7,%ymm8
  1e21ad:	c4 42 1d 37 d0       	vpcmpgtq %ymm8,%ymm12,%ymm10
  1e21b2:	c4 43 7d 39 d1 01    	vextracti128 $0x1,%ymm10,%xmm9
  1e21b8:	c4 41 29 6b c9       	vpackssdw %xmm9,%xmm10,%xmm9
  1e21bd:	c5 2d db d5          	vpand  %ymm5,%ymm10,%ymm10
  1e21c1:	c4 43 7d 39 d3 01    	vextracti128 $0x1,%ymm10,%xmm11
  1e21c7:	c4 41 29 5f d3       	vmaxpd %xmm11,%xmm10,%xmm10
  1e21cc:	c4 41 29 c6 da 01    	vshufpd $0x1,%xmm10,%xmm10,%xmm11
  1e21d2:	c4 41 2b 5f d3       	vmaxsd %xmm11,%xmm10,%xmm10
  1e21d7:	c4 41 79 2e d7       	vucomisd %xmm15,%xmm10
  1e21dc:	0f 87 2e ff ff ff    	ja     1e2110 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x1fa0>
  1e21e2:	49 8d 14 0e          	lea    (%r14,%rcx,1),%rdx
  1e21e6:	c4 42 65 29 c4       	vpcmpeqq %ymm12,%ymm3,%ymm8
  1e21eb:	c5 3d db c5          	vpand  %ymm5,%ymm8,%ymm8
  1e21ef:	c4 43 7d 39 c1 01    	vextracti128 $0x1,%ymm8,%xmm9
  1e21f5:	c4 41 39 5d c1       	vminpd %xmm9,%xmm8,%xmm8
  1e21fa:	c4 41 39 c6 c8 01    	vshufpd $0x1,%xmm8,%xmm8,%xmm9
  1e2200:	c4 41 3b 5d c1       	vminsd %xmm9,%xmm8,%xmm8
  1e2205:	c4 41 79 2e c7       	vucomisd %xmm15,%xmm8
  1e220a:	76 69                	jbe    1e2275 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2105>
  1e220c:	c4 62 7d 19 05 ab 40 	vbroadcastsd -0x1bbf55(%rip),%ymm8        # 262c0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x5f0>
  1e2213:	e4 ff 
  1e2215:	c4 41 4d c2 c0 1d    	vcmpge_oqpd %ymm8,%ymm6,%ymm8
  1e221b:	c5 bd 56 ff          	vorpd  %ymm7,%ymm8,%ymm7
  1e221f:	c4 62 7d 19 05 20 40 	vbroadcastsd -0x1bbfe0(%rip),%ymm8        # 26248 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x578>
  1e2226:	e4 ff 
  1e2228:	c4 c1 4d c2 f0 12    	vcmple_oqpd %ymm8,%ymm6,%ymm6
  1e222e:	c5 c5 54 f6          	vandpd %ymm6,%ymm7,%ymm6
  1e2232:	c4 e2 1d 37 f6       	vpcmpgtq %ymm6,%ymm12,%ymm6
  1e2237:	c5 cd db ed          	vpand  %ymm5,%ymm6,%ymm5
  1e223b:	c4 e3 7d 39 ee 01    	vextracti128 $0x1,%ymm5,%xmm6
  1e2241:	c5 d1 5d ee          	vminpd %xmm6,%xmm5,%xmm5
  1e2245:	c5 d1 c6 f5 01       	vshufpd $0x1,%xmm5,%xmm5,%xmm6
  1e224a:	c5 d3 5d f6          	vminsd %xmm6,%xmm5,%xmm6
  1e224e:	c4 e3 51 0d ee 01    	vblendpd $0x1,%xmm6,%xmm5,%xmm5
  1e2254:	c4 c1 79 2e ef       	vucomisd %xmm15,%xmm5
  1e2259:	c5 fd 11 22          	vmovupd %ymm4,(%rdx)
  1e225d:	c5 7b 10 9c 24 20 03 	vmovsd 0x320(%rsp),%xmm11
  1e2264:	00 00 
  1e2266:	c5 fb 10 a4 24 40 03 	vmovsd 0x340(%rsp),%xmm4
  1e226d:	00 00 
  1e226f:	77 1c                	ja     1e228d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x211d>
  1e2271:	31 ed                	xor    %ebp,%ebp
  1e2273:	eb 18                	jmp    1e228d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x211d>
  1e2275:	c5 fd 11 22          	vmovupd %ymm4,(%rdx)
  1e2279:	31 ed                	xor    %ebp,%ebp
  1e227b:	c5 7b 10 9c 24 20 03 	vmovsd 0x320(%rsp),%xmm11
  1e2282:	00 00 
  1e2284:	c5 fb 10 a4 24 40 03 	vmovsd 0x340(%rsp),%xmm4
  1e228b:	00 00 
  1e228d:	48 ff c0             	inc    %rax
  1e2290:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  1e2295:	c5 fd 11 14 0a       	vmovupd %ymm2,(%rdx,%rcx,1)
  1e229a:	48 8b 94 24 80 01 00 	mov    0x180(%rsp),%rdx
  1e22a1:	00 
  1e22a2:	48 01 d1             	add    %rdx,%rcx
  1e22a5:	c5 fe 7f 19          	vmovdqu %ymm3,(%rcx)
  1e22a9:	48 39 f8             	cmp    %rdi,%rax
  1e22ac:	0f 85 dd fb ff ff    	jne    1e1e8f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x1d1f>
  1e22b2:	eb 10                	jmp    1e22c4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2154>
  1e22b4:	40 b5 01             	mov    $0x1,%bpl
  1e22b7:	4c 8b 54 24 58       	mov    0x58(%rsp),%r10
  1e22bc:	4c 8b b4 24 b0 06 00 	mov    0x6b0(%rsp),%r14
  1e22c3:	00 
  1e22c4:	48 85 f6             	test   %rsi,%rsi
  1e22c7:	0f 84 58 01 00 00    	je     1e2425 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x22b5>
  1e22cd:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
  1e22d4:	00 
  1e22d5:	4d 8d 3c ca          	lea    (%r10,%rcx,8),%r15
  1e22d9:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  1e22de:	4c 8d 24 c8          	lea    (%rax,%rcx,8),%r12
  1e22e2:	bb 01 00 00 00       	mov    $0x1,%ebx
  1e22e7:	45 31 ed             	xor    %r13d,%r13d
  1e22ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  1e22f0:	4c 39 ac 24 90 07 00 	cmp    %r13,0x790(%rsp)
  1e22f7:	00 
  1e22f8:	0f 84 95 3d 00 00    	je     1e6093 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5f23>
  1e22fe:	4c 39 ac 24 e0 07 00 	cmp    %r13,0x7e0(%rsp)
  1e2305:	00 
  1e2306:	0f 84 a2 3d 00 00    	je     1e60ae <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5f3e>
  1e230c:	48 8b 84 24 40 02 00 	mov    0x240(%rsp),%rax
  1e2313:	00 
  1e2314:	4a 8d 34 28          	lea    (%rax,%r13,1),%rsi
  1e2318:	c5 fa 7e 0e          	vmovq  (%rsi),%xmm1
  1e231c:	c4 e1 f9 7e ca       	vmovq  %xmm1,%rdx
  1e2321:	48 8b 84 24 f8 01 00 	mov    0x1f8(%rsp),%rax
  1e2328:	00 
  1e2329:	c4 a1 7b 10 04 28    	vmovsd (%rax,%r13,1),%xmm0
  1e232f:	c5 f9 28 94 24 a0 07 	vmovapd 0x7a0(%rsp),%xmm2
  1e2336:	00 00 
  1e2338:	c4 e2 e9 99 84 24 c0 	vfmadd132sd 0x7c0(%rsp),%xmm2,%xmm0
  1e233f:	07 00 00 
  1e2342:	c4 82 f1 a9 04 2f    	vfmadd213sd (%r15,%r13,1),%xmm1,%xmm0
  1e2348:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  1e234d:	48 c1 ea 34          	shr    $0x34,%rdx
  1e2351:	81 e2 ff 07 00 00    	and    $0x7ff,%edx
  1e2357:	48 c1 e8 34          	shr    $0x34,%rax
  1e235b:	25 ff 07 00 00       	and    $0x7ff,%eax
  1e2360:	3d ff 07 00 00       	cmp    $0x7ff,%eax
  1e2365:	0f 92 c1             	setb   %cl
  1e2368:	31 c0                	xor    %eax,%eax
  1e236a:	81 fa fe 07 00 00    	cmp    $0x7fe,%edx
  1e2370:	0f 87 37 17 00 00    	ja     1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e2376:	84 c9                	test   %cl,%cl
  1e2378:	0f 84 2f 17 00 00    	je     1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e237e:	c4 81 7b 11 04 2c    	vmovsd %xmm0,(%r12,%r13,1)
  1e2384:	4c 39 ac 24 88 07 00 	cmp    %r13,0x788(%rsp)
  1e238b:	00 
  1e238c:	0f 84 42 17 00 00    	je     1e3ad4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3964>
  1e2392:	4b 8d 0c 2c          	lea    (%r12,%r13,1),%rcx
  1e2396:	48 8b 84 24 b0 01 00 	mov    0x1b0(%rsp),%rax
  1e239d:	00 
  1e239e:	4e 8d 0c 28          	lea    (%rax,%r13,1),%r9
  1e23a2:	48 c7 04 24 01 00 00 	movq   $0x1,(%rsp)
  1e23a9:	00 
  1e23aa:	ba 01 00 00 00       	mov    $0x1,%edx
  1e23af:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  1e23b5:	48 8d bc 24 30 06 00 	lea    0x630(%rsp),%rdi
  1e23bc:	00 
  1e23bd:	c5 f8 77             	vzeroupper
  1e23c0:	ff 15 42 82 10 00    	call   *0x108242(%rip)        # 2ea608 <_DYNAMIC+0x7f0>
  1e23c6:	83 bc 24 30 06 00 00 	cmpl   $0xffffffff,0x630(%rsp)
  1e23cd:	ff 
  1e23ce:	0f 85 d7 16 00 00    	jne    1e3aab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393b>
  1e23d4:	40 22 ac 24 38 06 00 	and    0x638(%rsp),%bpl
  1e23db:	00 
  1e23dc:	49 83 c5 08          	add    $0x8,%r13
  1e23e0:	48 ff c3             	inc    %rbx
  1e23e3:	4c 39 ac 24 e0 07 00 	cmp    %r13,0x7e0(%rsp)
  1e23ea:	00 
  1e23eb:	c4 62 7d 19 2d 84 3c 	vbroadcastsd -0x1bc37c(%rip),%ymm13        # 26078 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x3a8>
  1e23f2:	e4 ff 
  1e23f4:	c5 7d 10 b4 24 20 04 	vmovupd 0x420(%rsp),%ymm14
  1e23fb:	00 00 
  1e23fd:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1e2402:	c4 62 7d 19 3d b5 3e 	vbroadcastsd -0x1bc14b(%rip),%ymm15        # 262c0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x5f0>
  1e2409:	e4 ff 
  1e240b:	c5 7b 10 9c 24 20 03 	vmovsd 0x320(%rsp),%xmm11
  1e2412:	00 00 
  1e2414:	c5 fb 10 a4 24 40 03 	vmovsd 0x340(%rsp),%xmm4
  1e241b:	00 00 
  1e241d:	0f 85 cd fe ff ff    	jne    1e22f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2180>
  1e2423:	eb 09                	jmp    1e242e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x22be>
  1e2425:	c4 62 7d 19 3d 92 3e 	vbroadcastsd -0x1bc16e(%rip),%ymm15        # 262c0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x5f0>
  1e242c:	e4 ff 
  1e242e:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1e2433:	48 8b bc 24 90 02 00 	mov    0x290(%rsp),%rdi
  1e243a:	00 
  1e243b:	48 39 f7             	cmp    %rsi,%rdi
  1e243e:	0f 83 6a 3e 00 00    	jae    1e62ae <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x613e>
  1e2444:	48 89 f8             	mov    %rdi,%rax
  1e2447:	48 c1 e0 04          	shl    $0x4,%rax
  1e244b:	48 8b 94 24 d0 00 00 	mov    0xd0(%rsp),%rdx
  1e2452:	00 
  1e2453:	c5 fb 10 44 24 10    	vmovsd 0x10(%rsp),%xmm0
  1e2459:	c5 fb 11 04 02       	vmovsd %xmm0,(%rdx,%rax,1)
  1e245e:	c5 fb 10 84 24 20 02 	vmovsd 0x220(%rsp),%xmm0
  1e2465:	00 00 
  1e2467:	c5 fb 11 44 02 08    	vmovsd %xmm0,0x8(%rdx,%rax,1)
  1e246d:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
  1e2472:	4c 39 d7             	cmp    %r10,%rdi
  1e2475:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  1e247c:	00 
  1e247d:	4c 8b 84 24 78 01 00 	mov    0x178(%rsp),%r8
  1e2484:	00 
  1e2485:	4c 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%r9
  1e248c:	00 
  1e248d:	48 8b 9c 24 98 00 00 	mov    0x98(%rsp),%rbx
  1e2494:	00 
  1e2495:	4c 8b 7c 24 68       	mov    0x68(%rsp),%r15
  1e249a:	0f 83 1e 3e 00 00    	jae    1e62be <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x614e>
  1e24a0:	c5 fb 10 84 24 50 01 	vmovsd 0x150(%rsp),%xmm0
  1e24a7:	00 00 
  1e24a9:	c4 c1 7b 11 04 01    	vmovsd %xmm0,(%r9,%rax,1)
  1e24af:	c5 fb 10 84 24 90 01 	vmovsd 0x190(%rsp),%xmm0
  1e24b6:	00 00 
  1e24b8:	c4 c1 7b 11 44 01 08 	vmovsd %xmm0,0x8(%r9,%rax,1)
  1e24bf:	48 39 8c 24 68 07 00 	cmp    %rcx,0x768(%rsp)
  1e24c6:	00 
  1e24c7:	73 46                	jae    1e250f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x239f>
  1e24c9:	48 ff c7             	inc    %rdi
  1e24cc:	48 39 f7             	cmp    %rsi,%rdi
  1e24cf:	0f 83 fc 3d 00 00    	jae    1e62d1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6161>
  1e24d5:	48 89 f8             	mov    %rdi,%rax
  1e24d8:	48 c1 e0 04          	shl    $0x4,%rax
  1e24dc:	c5 fb 10 84 24 00 02 	vmovsd 0x200(%rsp),%xmm0
  1e24e3:	00 00 
  1e24e5:	c5 fb 11 04 02       	vmovsd %xmm0,(%rdx,%rax,1)
  1e24ea:	c5 fb 10 84 24 c0 01 	vmovsd 0x1c0(%rsp),%xmm0
  1e24f1:	00 00 
  1e24f3:	c5 fb 11 44 02 08    	vmovsd %xmm0,0x8(%rdx,%rax,1)
  1e24f9:	4c 39 d7             	cmp    %r10,%rdi
  1e24fc:	0f 83 df 3d 00 00    	jae    1e62e1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6171>
  1e2502:	c4 41 7b 11 1c 01    	vmovsd %xmm11,(%r9,%rax,1)
  1e2508:	c4 c1 7b 11 64 01 08 	vmovsd %xmm4,0x8(%r9,%rax,1)
  1e250f:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  1e2514:	48 8d 7a 01          	lea    0x1(%rdx),%rdi
  1e2518:	40 f6 c5 01          	test   $0x1,%bpl
  1e251c:	0f 85 83 13 00 00    	jne    1e38a5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3735>
  1e2522:	48 8d 04 12          	lea    (%rdx,%rdx,1),%rax
  1e2526:	48 89 84 24 90 02 00 	mov    %rax,0x290(%rsp)
  1e252d:	00 
  1e252e:	49 8d 34 50          	lea    (%r8,%rdx,2),%rsi
  1e2532:	48 8b 8c 24 c8 04 00 	mov    0x4c8(%rsp),%rcx
  1e2539:	00 
  1e253a:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  1e253f:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
  1e2544:	4d 89 c2             	mov    %r8,%r10
  1e2547:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
  1e254c:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
  1e2551:	48 3b bc 24 f0 01 00 	cmp    0x1f0(%rsp),%rdi
  1e2558:	00 
  1e2559:	4c 8b 9c 24 e0 00 00 	mov    0xe0(%rsp),%r11
  1e2560:	00 
  1e2561:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  1e2566:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  1e256b:	48 8b 6c 24 40       	mov    0x40(%rsp),%rbp
  1e2570:	4c 8b 8c 24 08 01 00 	mov    0x108(%rsp),%r9
  1e2577:	00 
  1e2578:	c4 62 7d 19 2d c7 3c 	vbroadcastsd -0x1bc339(%rip),%ymm13        # 26248 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x578>
  1e257f:	e4 ff 
  1e2581:	0f 85 30 e3 ff ff    	jne    1e08b7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x747>
  1e2587:	4d 89 c2             	mov    %r8,%r10
  1e258a:	48 8b bc 24 60 07 00 	mov    0x760(%rsp),%rdi
  1e2591:	00 
  1e2592:	e9 94 de ff ff       	jmp    1e042b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2bb>
  1e2597:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1e259b:	45 31 d2             	xor    %r10d,%r10d
  1e259e:	c5 d1 ef ed          	vpxor  %xmm5,%xmm5,%xmm5
  1e25a2:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e25a6:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e25aa:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
  1e25ae:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  1e25b2:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1e25b6:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1e25ba:	c4 63 45 06 c6 31    	vperm2f128 $0x31,%ymm6,%ymm7,%ymm8
  1e25c0:	c4 e3 45 18 f6 01    	vinsertf128 $0x1,%xmm6,%ymm7,%ymm6
  1e25c6:	c5 bd 58 f6          	vaddpd %ymm6,%ymm8,%ymm6
  1e25ca:	c4 e3 5d 06 fd 31    	vperm2f128 $0x31,%ymm5,%ymm4,%ymm7
  1e25d0:	c4 e3 5d 18 e5 01    	vinsertf128 $0x1,%xmm5,%ymm4,%ymm4
  1e25d6:	c5 dd 58 e7          	vaddpd %ymm7,%ymm4,%ymm4
  1e25da:	c5 dd 7c e6          	vhaddpd %ymm6,%ymm4,%ymm4
  1e25de:	c4 e3 fd 01 e4 d8    	vpermpd $0xd8,%ymm4,%ymm4
  1e25e4:	c5 fd 11 a4 24 10 01 	vmovupd %ymm4,0x110(%rsp)
  1e25eb:	00 00 
  1e25ed:	c4 e3 6d 06 e1 31    	vperm2f128 $0x31,%ymm1,%ymm2,%ymm4
  1e25f3:	c4 e3 6d 18 c9 01    	vinsertf128 $0x1,%xmm1,%ymm2,%ymm1
  1e25f9:	c5 f5 58 cc          	vaddpd %ymm4,%ymm1,%ymm1
  1e25fd:	c4 e3 65 06 d0 31    	vperm2f128 $0x31,%ymm0,%ymm3,%ymm2
  1e2603:	c4 e3 65 18 c0 01    	vinsertf128 $0x1,%xmm0,%ymm3,%ymm0
  1e2609:	c5 fd 58 c2          	vaddpd %ymm2,%ymm0,%ymm0
  1e260d:	c5 fd 7c c1          	vhaddpd %ymm1,%ymm0,%ymm0
  1e2611:	c4 e3 fd 01 c0 d8    	vpermpd $0xd8,%ymm0,%ymm0
  1e2617:	c5 fd 11 84 24 30 01 	vmovupd %ymm0,0x130(%rsp)
  1e261e:	00 00 
  1e2620:	48 8d 84 24 60 03 00 	lea    0x360(%rsp),%rax
  1e2627:	00 
  1e2628:	48 89 84 24 e0 05 00 	mov    %rax,0x5e0(%rsp)
  1e262f:	00 
  1e2630:	48 8d 84 24 80 03 00 	lea    0x380(%rsp),%rax
  1e2637:	00 
  1e2638:	48 89 84 24 e8 05 00 	mov    %rax,0x5e8(%rsp)
  1e263f:	00 
  1e2640:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
  1e2645:	4c 89 ac 24 f0 05 00 	mov    %r13,0x5f0(%rsp)
  1e264c:	00 
  1e264d:	48 8b 84 24 30 05 00 	mov    0x530(%rsp),%rax
  1e2654:	00 
  1e2655:	48 89 84 24 f8 05 00 	mov    %rax,0x5f8(%rsp)
  1e265c:	00 
  1e265d:	4c 89 b4 24 00 06 00 	mov    %r14,0x600(%rsp)
  1e2664:	00 
  1e2665:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  1e266c:	00 
  1e266d:	48 89 84 24 08 06 00 	mov    %rax,0x608(%rsp)
  1e2674:	00 
  1e2675:	48 8d 84 24 a0 03 00 	lea    0x3a0(%rsp),%rax
  1e267c:	00 
  1e267d:	48 89 84 24 10 06 00 	mov    %rax,0x610(%rsp)
  1e2684:	00 
  1e2685:	48 8d 84 24 c0 03 00 	lea    0x3c0(%rsp),%rax
  1e268c:	00 
  1e268d:	48 89 84 24 18 06 00 	mov    %rax,0x618(%rsp)
  1e2694:	00 
  1e2695:	48 8b 84 24 98 05 00 	mov    0x598(%rsp),%rax
  1e269c:	00 
  1e269d:	48 89 84 24 20 06 00 	mov    %rax,0x620(%rsp)
  1e26a4:	00 
  1e26a5:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  1e26aa:	48 89 84 24 28 06 00 	mov    %rax,0x628(%rsp)
  1e26b1:	00 
  1e26b2:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  1e26b8:	0f 84 3c 0a 00 00    	je     1e30fa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2f8a>
  1e26be:	45 31 f6             	xor    %r14d,%r14d
  1e26c1:	4c 89 94 24 20 02 00 	mov    %r10,0x220(%rsp)
  1e26c8:	00 
  1e26c9:	eb 5e                	jmp    1e2729 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x25b9>
  1e26cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  1e26d0:	4c 8d 7d 01          	lea    0x1(%rbp),%r15
  1e26d4:	4c 89 ef             	mov    %r13,%rdi
  1e26d7:	48 89 ee             	mov    %rbp,%rsi
  1e26da:	4c 89 e2             	mov    %r12,%rdx
  1e26dd:	c5 f8 77             	vzeroupper
  1e26e0:	e8 3b 50 00 00       	call   1e7720 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e26e5:	48 83 cd 02          	or     $0x2,%rbp
  1e26e9:	4c 89 ef             	mov    %r13,%rdi
  1e26ec:	4c 89 fe             	mov    %r15,%rsi
  1e26ef:	4c 89 e2             	mov    %r12,%rdx
  1e26f2:	e8 29 50 00 00       	call   1e7720 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e26f7:	4c 89 ef             	mov    %r13,%rdi
  1e26fa:	48 89 ee             	mov    %rbp,%rsi
  1e26fd:	4c 89 e2             	mov    %r12,%rdx
  1e2700:	e8 1b 50 00 00       	call   1e7720 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e2705:	4c 89 ef             	mov    %r13,%rdi
  1e2708:	48 89 de             	mov    %rbx,%rsi
  1e270b:	4c 89 e2             	mov    %r12,%rdx
  1e270e:	e8 0d 50 00 00       	call   1e7720 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e2713:	49 ff c6             	inc    %r14
  1e2716:	4c 3b 74 24 10       	cmp    0x10(%rsp),%r14
  1e271b:	4c 8b 94 24 20 02 00 	mov    0x220(%rsp),%r10
  1e2722:	00 
  1e2723:	0f 84 d1 09 00 00    	je     1e30fa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2f8a>
  1e2729:	4a 8d 2c b5 00 00 00 	lea    0x0(,%r14,4),%rbp
  1e2730:	00 
  1e2731:	c4 c2 d3 f7 c2       	shrx   %rbp,%r10,%rax
  1e2736:	41 89 c7             	mov    %eax,%r15d
  1e2739:	41 80 e7 0f          	and    $0xf,%r15b
  1e273d:	4c 8d a4 24 e0 05 00 	lea    0x5e0(%rsp),%r12
  1e2744:	00 
  1e2745:	48 8d 9c 24 10 01 00 	lea    0x110(%rsp),%rbx
  1e274c:	00 
  1e274d:	74 c4                	je     1e2713 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x25a3>
  1e274f:	83 e0 0f             	and    $0xf,%eax
  1e2752:	83 f8 0f             	cmp    $0xf,%eax
  1e2755:	0f 85 c5 01 00 00    	jne    1e2920 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x27b0>
  1e275b:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
  1e2762:	00 
  1e2763:	49 39 f6             	cmp    %rsi,%r14
  1e2766:	0f 83 bd 37 00 00    	jae    1e5f29 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5db9>
  1e276c:	4c 3b b4 24 b8 00 00 	cmp    0xb8(%rsp),%r14
  1e2773:	00 
  1e2774:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  1e277b:	00 
  1e277c:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  1e2783:	00 
  1e2784:	4c 8d ac 24 e0 05 00 	lea    0x5e0(%rsp),%r13
  1e278b:	00 
  1e278c:	4c 8d a4 24 10 01 00 	lea    0x110(%rsp),%r12
  1e2793:	00 
  1e2794:	0f 83 bd 37 00 00    	jae    1e5f57 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5de7>
  1e279a:	49 39 c6             	cmp    %rax,%r14
  1e279d:	0f 83 e7 37 00 00    	jae    1e5f8a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5e1a>
  1e27a3:	4c 3b b4 24 b0 00 00 	cmp    0xb0(%rsp),%r14
  1e27aa:	00 
  1e27ab:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
  1e27b0:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1e27b5:	0f 83 05 38 00 00    	jae    1e5fc0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5e50>
  1e27bb:	4c 3b 74 24 78       	cmp    0x78(%rsp),%r14
  1e27c0:	0f 83 4b 37 00 00    	jae    1e5f11 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5da1>
  1e27c6:	4c 3b b4 24 a8 00 00 	cmp    0xa8(%rsp),%r14
  1e27cd:	00 
  1e27ce:	0f 83 68 37 00 00    	jae    1e5f3c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5dcc>
  1e27d4:	4c 3b 74 24 70       	cmp    0x70(%rsp),%r14
  1e27d9:	0f 83 93 37 00 00    	jae    1e5f72 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5e02>
  1e27df:	4c 3b b4 24 a0 00 00 	cmp    0xa0(%rsp),%r14
  1e27e6:	00 
  1e27e7:	0f 83 b8 37 00 00    	jae    1e5fa5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5e35>
  1e27ed:	48 8d 5d 03          	lea    0x3(%rbp),%rbx
  1e27f1:	48 3b 9c 24 88 01 00 	cmp    0x188(%rsp),%rbx
  1e27f8:	00 
  1e27f9:	0f 83 87 10 00 00    	jae    1e3886 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3716>
  1e27ff:	4c 3b 74 24 30       	cmp    0x30(%rsp),%r14
  1e2804:	0f 83 d1 37 00 00    	jae    1e5fdb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5e6b>
  1e280a:	4c 89 f0             	mov    %r14,%rax
  1e280d:	48 c1 e0 05          	shl    $0x5,%rax
  1e2811:	48 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%rcx
  1e2818:	00 
  1e2819:	c5 fd 10 0c 01       	vmovupd (%rcx,%rax,1),%ymm1
  1e281e:	c5 fd 10 14 06       	vmovupd (%rsi,%rax,1),%ymm2
  1e2823:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  1e282a:	00 
  1e282b:	c5 fd 10 2c 01       	vmovupd (%rcx,%rax,1),%ymm5
  1e2830:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  1e2835:	c5 fd 10 1c 01       	vmovupd (%rcx,%rax,1),%ymm3
  1e283a:	c5 fd 10 34 02       	vmovupd (%rdx,%rax,1),%ymm6
  1e283f:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  1e2844:	c5 fd 10 3c 01       	vmovupd (%rcx,%rax,1),%ymm7
  1e2849:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  1e284e:	c5 7d 10 04 01       	vmovupd (%rcx,%rax,1),%ymm8
  1e2853:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  1e2858:	c5 bd 59 24 01       	vmulpd (%rcx,%rax,1),%ymm8,%ymm4
  1e285d:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  1e2862:	c5 7d 10 0c 01       	vmovupd (%rcx,%rax,1),%ymm9
  1e2867:	c5 fd 11 a4 24 28 09 	vmovupd %ymm4,0x928(%rsp)
  1e286e:	00 00 
  1e2870:	c5 3d 59 e2          	vmulpd %ymm2,%ymm8,%ymm12
  1e2874:	c5 7d 11 a4 24 48 09 	vmovupd %ymm12,0x948(%rsp)
  1e287b:	00 00 
  1e287d:	c5 bd 59 db          	vmulpd %ymm3,%ymm8,%ymm3
  1e2881:	c5 bd 59 d7          	vmulpd %ymm7,%ymm8,%ymm2
  1e2885:	c5 fd 11 9c 24 c0 01 	vmovupd %ymm3,0x1c0(%rsp)
  1e288c:	00 00 
  1e288e:	c5 fd 11 9c 24 28 0a 	vmovupd %ymm3,0xa28(%rsp)
  1e2895:	00 00 
  1e2897:	c5 fd 11 94 24 90 01 	vmovupd %ymm2,0x190(%rsp)
  1e289e:	00 00 
  1e28a0:	c5 fd 11 94 24 48 0a 	vmovupd %ymm2,0xa48(%rsp)
  1e28a7:	00 00 
  1e28a9:	c5 bd 59 d9          	vmulpd %ymm1,%ymm8,%ymm3
  1e28ad:	c5 fd 11 9c 24 68 09 	vmovupd %ymm3,0x968(%rsp)
  1e28b4:	00 00 
  1e28b6:	c5 bd 59 c5          	vmulpd %ymm5,%ymm8,%ymm0
  1e28ba:	c5 fd 11 84 24 88 09 	vmovupd %ymm0,0x988(%rsp)
  1e28c1:	00 00 
  1e28c3:	c5 bd 59 ee          	vmulpd %ymm6,%ymm8,%ymm5
  1e28c7:	c4 c1 35 59 c8       	vmulpd %ymm8,%ymm9,%ymm1
  1e28cc:	c5 fd 11 ac 24 40 02 	vmovupd %ymm5,0x240(%rsp)
  1e28d3:	00 00 
  1e28d5:	c5 fd 11 ac 24 68 0a 	vmovupd %ymm5,0xa68(%rsp)
  1e28dc:	00 00 
  1e28de:	c5 fd 11 8c 24 00 02 	vmovupd %ymm1,0x200(%rsp)
  1e28e5:	00 00 
  1e28e7:	c5 fd 11 8c 24 88 0a 	vmovupd %ymm1,0xa88(%rsp)
  1e28ee:	00 00 
  1e28f0:	c4 c1 2d c2 ca 00    	vcmpeqpd %ymm10,%ymm10,%ymm1
  1e28f6:	48 8d 8c 24 28 09 00 	lea    0x928(%rsp),%rcx
  1e28fd:	00 
  1e28fe:	31 c0                	xor    %eax,%eax
  1e2900:	48 8d b4 24 a8 09 00 	lea    0x9a8(%rsp),%rsi
  1e2907:	00 
  1e2908:	c4 e2 7d 19 3d 67 37 	vbroadcastsd -0x1bc899(%rip),%ymm7        # 26078 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x3a8>
  1e290f:	e4 ff 
  1e2911:	c4 62 7d 19 05 1e 36 	vbroadcastsd -0x1bc9e2(%rip),%ymm8        # 25f38 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x268>
  1e2918:	e4 ff 
  1e291a:	eb 5b                	jmp    1e2977 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2807>
  1e291c:	0f 1f 40 00          	nopl   0x0(%rax)
  1e2920:	45 0f b6 ef          	movzbl %r15b,%r13d
  1e2924:	31 f6                	xor    %esi,%esi
  1e2926:	f3 41 0f bc f5       	tzcnt  %r13d,%esi
  1e292b:	45 8d 7d ff          	lea    -0x1(%r13),%r15d
  1e292f:	48 01 ee             	add    %rbp,%rsi
  1e2932:	4c 89 e7             	mov    %r12,%rdi
  1e2935:	48 89 da             	mov    %rbx,%rdx
  1e2938:	c5 f8 77             	vzeroupper
  1e293b:	e8 e0 4d 00 00       	call   1e7720 <<rustsht::legendre::scalar_paired::analysis::MixedAnalysisPairChannelsAccumulation<true> as pulp::WithSimd>::with_simd::<pulp::Scalar>::{closure#0}>
  1e2940:	45 20 ef             	and    %r13b,%r15b
  1e2943:	75 db                	jne    1e2920 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x27b0>
  1e2945:	e9 c9 fd ff ff       	jmp    1e2713 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x25a3>
  1e294a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  1e2950:	48 8d 51 20          	lea    0x20(%rcx),%rdx
  1e2954:	c4 e2 7d 19 2d 43 38 	vbroadcastsd -0x1bc7bd(%rip),%ymm5        # 261a0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x4d0>
  1e295b:	e4 ff 
  1e295d:	c5 d5 54 29          	vandpd (%rcx),%ymm5,%ymm5
  1e2961:	c5 d5 c2 f7 1d       	vcmpge_oqpd %ymm7,%ymm5,%ymm6
  1e2966:	c4 c1 55 c2 e8 12    	vcmple_oqpd %ymm8,%ymm5,%ymm5
  1e296c:	c5 cd 54 ed          	vandpd %ymm5,%ymm6,%ymm5
  1e2970:	c5 d5 54 c9          	vandpd %ymm1,%ymm5,%ymm1
  1e2974:	48 89 d1             	mov    %rdx,%rcx
  1e2977:	48 85 c9             	test   %rcx,%rcx
  1e297a:	74 05                	je     1e2981 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2811>
  1e297c:	48 39 f1             	cmp    %rsi,%rcx
  1e297f:	75 cf                	jne    1e2950 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x27e0>
  1e2981:	48 3d 80 00 00 00    	cmp    $0x80,%rax
  1e2987:	74 17                	je     1e29a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2830>
  1e2989:	48 8d 0c 04          	lea    (%rsp,%rax,1),%rcx
  1e298d:	48 81 c1 28 0a 00 00 	add    $0xa28,%rcx
  1e2994:	48 83 c0 20          	add    $0x20,%rax
  1e2998:	31 d2                	xor    %edx,%edx
  1e299a:	eb b8                	jmp    1e2954 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x27e4>
  1e299c:	0f 1f 40 00          	nopl   0x0(%rax)
  1e29a0:	c4 e2 2d 37 c9       	vpcmpgtq %ymm1,%ymm10,%ymm1
  1e29a5:	c4 62 7d 59 1d fa 37 	vpbroadcastq -0x1bc806(%rip),%ymm11        # 261a8 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x4d8>
  1e29ac:	e4 ff 
  1e29ae:	c5 a5 db c9          	vpand  %ymm1,%ymm11,%ymm1
  1e29b2:	c4 e3 7d 39 cd 01    	vextracti128 $0x1,%ymm1,%xmm5
  1e29b8:	c5 f1 5d cd          	vminpd %xmm5,%xmm1,%xmm1
  1e29bc:	c5 f1 c6 e9 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm5
  1e29c1:	c5 f3 5d cd          	vminsd %xmm5,%xmm1,%xmm1
  1e29c5:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1e29c9:	c5 f9 2e cd          	vucomisd %xmm5,%xmm1
  1e29cd:	0f 86 fd fc ff ff    	jbe    1e26d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2560>
  1e29d3:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  1e29da:	00 
  1e29db:	c5 7d 10 34 e8       	vmovupd (%rax,%rbp,8),%ymm14
  1e29e0:	c4 62 7d 59 15 57 3c 	vpbroadcastq -0x1bc3a9(%rip),%ymm10        # 26640 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x970>
  1e29e7:	e4 ff 
  1e29e9:	c4 e2 7d 59 0d 46 39 	vpbroadcastq -0x1bc6ba(%rip),%ymm1        # 26338 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x668>
  1e29f0:	e4 ff 
  1e29f2:	c4 62 7d 59 2d a5 3e 	vpbroadcastq -0x1bc15b(%rip),%ymm13        # 268a0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0xbd0>
  1e29f9:	e4 ff 
  1e29fb:	c5 fd 11 a4 24 50 01 	vmovupd %ymm4,0x150(%rsp)
  1e2a02:	00 00 
  1e2a04:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1e2a08:	c5 9d c2 fc 00       	vcmpeqpd %ymm4,%ymm12,%ymm7
  1e2a0d:	c4 c1 45 55 ee       	vandnpd %ymm14,%ymm7,%ymm5
  1e2a12:	c5 ad d4 f5          	vpaddq %ymm5,%ymm10,%ymm6
  1e2a16:	c4 62 7d 59 3d d1 38 	vpbroadcastq -0x1bc72f(%rip),%ymm15        # 262f0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x620>
  1e2a1d:	e4 ff 
  1e2a1f:	c5 85 ef f6          	vpxor  %ymm6,%ymm15,%ymm6
  1e2a23:	c4 62 7d 59 05 a4 34 	vpbroadcastq -0x1bcb5c(%rip),%ymm8        # 25ed0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x200>
  1e2a2a:	e4 ff 
  1e2a2c:	c5 fd 11 bc 24 20 03 	vmovupd %ymm7,0x320(%rsp)
  1e2a33:	00 00 
  1e2a35:	c4 c3 1d 4b fb 70    	vblendvpd %ymm7,%ymm11,%ymm12,%ymm7
  1e2a3b:	c4 e2 3d 37 f6       	vpcmpgtq %ymm6,%ymm8,%ymm6
  1e2a40:	c5 fd 11 bc 24 a0 02 	vmovupd %ymm7,0x2a0(%rsp)
  1e2a47:	00 00 
  1e2a49:	c5 b5 73 d7 34       	vpsrlq $0x34,%ymm7,%ymm9
  1e2a4e:	c5 35 db c9          	vpand  %ymm1,%ymm9,%ymm9
  1e2a52:	c5 b5 d4 ed          	vpaddq %ymm5,%ymm9,%ymm5
  1e2a56:	c5 fe 7f ac 24 20 04 	vmovdqu %ymm5,0x420(%rsp)
  1e2a5d:	00 00 
  1e2a5f:	c5 95 d4 ed          	vpaddq %ymm5,%ymm13,%ymm5
  1e2a63:	c5 05 ef cd          	vpxor  %ymm5,%ymm15,%ymm9
  1e2a67:	c4 e2 7d 59 2d 30 3b 	vpbroadcastq -0x1bc4d0(%rip),%ymm5        # 265a0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x8d0>
  1e2a6e:	e4 ff 
  1e2a70:	c4 42 55 37 c9       	vpcmpgtq %ymm9,%ymm5,%ymm9
  1e2a75:	c5 35 eb ce          	vpor   %ymm6,%ymm9,%ymm9
  1e2a79:	c5 fd 28 d3          	vmovapd %ymm3,%ymm2
  1e2a7d:	c5 fd 11 9c 24 00 03 	vmovupd %ymm3,0x300(%rsp)
  1e2a84:	00 00 
  1e2a86:	c5 e5 c2 dc 00       	vcmpeqpd %ymm4,%ymm3,%ymm3
  1e2a8b:	c4 c1 65 55 f6       	vandnpd %ymm14,%ymm3,%ymm6
  1e2a90:	c5 ad d4 fe          	vpaddq %ymm6,%ymm10,%ymm7
  1e2a94:	c5 85 ef ff          	vpxor  %ymm7,%ymm15,%ymm7
  1e2a98:	c4 e2 3d 37 ff       	vpcmpgtq %ymm7,%ymm8,%ymm7
  1e2a9d:	c5 fd 11 9c 24 00 04 	vmovupd %ymm3,0x400(%rsp)
  1e2aa4:	00 00 
  1e2aa6:	c4 c3 6d 4b db 30    	vblendvpd %ymm3,%ymm11,%ymm2,%ymm3
  1e2aac:	c5 fd 28 d0          	vmovapd %ymm0,%ymm2
  1e2ab0:	c5 7d 11 a4 24 40 03 	vmovupd %ymm12,0x340(%rsp)
  1e2ab7:	00 00 
  1e2ab9:	c5 fd 11 9c 24 60 02 	vmovupd %ymm3,0x260(%rsp)
  1e2ac0:	00 00 
  1e2ac2:	c5 9d 73 d3 34       	vpsrlq $0x34,%ymm3,%ymm12
  1e2ac7:	c5 1d db e1          	vpand  %ymm1,%ymm12,%ymm12
  1e2acb:	c5 9d d4 de          	vpaddq %ymm6,%ymm12,%ymm3
  1e2acf:	c5 95 d4 f3          	vpaddq %ymm3,%ymm13,%ymm6
  1e2ad3:	c5 85 ef f6          	vpxor  %ymm6,%ymm15,%ymm6
  1e2ad7:	c4 e2 55 37 f6       	vpcmpgtq %ymm6,%ymm5,%ymm6
  1e2adc:	c5 c5 eb fe          	vpor   %ymm6,%ymm7,%ymm7
  1e2ae0:	c5 fd c2 c4 00       	vcmpeqpd %ymm4,%ymm0,%ymm0
  1e2ae5:	c4 c3 6d 4b f3 00    	vblendvpd %ymm0,%ymm11,%ymm2,%ymm6
  1e2aeb:	c5 fd 11 b4 24 c0 02 	vmovupd %ymm6,0x2c0(%rsp)
  1e2af2:	00 00 
  1e2af4:	c5 9d 73 d6 34       	vpsrlq $0x34,%ymm6,%ymm12
  1e2af9:	c5 1d db e1          	vpand  %ymm1,%ymm12,%ymm12
  1e2afd:	c5 fd 11 84 24 e0 02 	vmovupd %ymm0,0x2e0(%rsp)
  1e2b04:	00 00 
  1e2b06:	c4 c1 7d 55 f6       	vandnpd %ymm14,%ymm0,%ymm6
  1e2b0b:	c5 9d d4 c6          	vpaddq %ymm6,%ymm12,%ymm0
  1e2b0f:	c5 ad d4 f6          	vpaddq %ymm6,%ymm10,%ymm6
  1e2b13:	c5 85 ef f6          	vpxor  %ymm6,%ymm15,%ymm6
  1e2b17:	c4 e2 3d 37 f6       	vpcmpgtq %ymm6,%ymm8,%ymm6
  1e2b1c:	c5 fe 7f 84 24 80 04 	vmovdqu %ymm0,0x480(%rsp)
  1e2b23:	00 00 
  1e2b25:	c5 15 d4 e0          	vpaddq %ymm0,%ymm13,%ymm12
  1e2b29:	c4 41 1d ef e7       	vpxor  %ymm15,%ymm12,%ymm12
  1e2b2e:	c4 42 55 37 e4       	vpcmpgtq %ymm12,%ymm5,%ymm12
  1e2b33:	c5 9d eb f6          	vpor   %ymm6,%ymm12,%ymm6
  1e2b37:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
  1e2b3b:	c5 b5 eb f6          	vpor   %ymm6,%ymm9,%ymm6
  1e2b3f:	c5 5d c2 8c 24 50 01 	vcmpeqpd 0x150(%rsp),%ymm4,%ymm9
  1e2b46:	00 00 00 
  1e2b49:	c5 fd 10 84 24 50 01 	vmovupd 0x150(%rsp),%ymm0
  1e2b50:	00 00 
  1e2b52:	c4 c3 7d 4b c3 90    	vblendvpd %ymm9,%ymm11,%ymm0,%ymm0
  1e2b58:	c5 fd 11 84 24 10 05 	vmovupd %ymm0,0x510(%rsp)
  1e2b5f:	00 00 
  1e2b61:	c5 c5 73 d0 34       	vpsrlq $0x34,%ymm0,%ymm7
  1e2b66:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
  1e2b6a:	c4 41 35 55 e6       	vandnpd %ymm14,%ymm9,%ymm12
  1e2b6f:	c5 9d d4 c7          	vpaddq %ymm7,%ymm12,%ymm0
  1e2b73:	c4 c1 1d d4 fa       	vpaddq %ymm10,%ymm12,%ymm7
  1e2b78:	c5 85 ef ff          	vpxor  %ymm7,%ymm15,%ymm7
  1e2b7c:	c4 e2 3d 37 ff       	vpcmpgtq %ymm7,%ymm8,%ymm7
  1e2b81:	c5 fe 7f 84 24 70 05 	vmovdqu %ymm0,0x570(%rsp)
  1e2b88:	00 00 
  1e2b8a:	c5 15 d4 e0          	vpaddq %ymm0,%ymm13,%ymm12
  1e2b8e:	c4 41 1d ef e7       	vpxor  %ymm15,%ymm12,%ymm12
  1e2b93:	c4 42 55 37 e4       	vpcmpgtq %ymm12,%ymm5,%ymm12
  1e2b98:	c5 9d eb ff          	vpor   %ymm7,%ymm12,%ymm7
  1e2b9c:	c5 cd 73 f6 3f       	vpsllq $0x3f,%ymm6,%ymm6
  1e2ba1:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
  1e2ba5:	c4 e2 7d 0f f6       	vtestpd %ymm6,%ymm6
  1e2baa:	0f 85 20 fb ff ff    	jne    1e26d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2560>
  1e2bb0:	c5 7d 10 a4 24 90 01 	vmovupd 0x190(%rsp),%ymm12
  1e2bb7:	00 00 
  1e2bb9:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
  1e2bbd:	c5 9d c2 e0 00       	vcmpeqpd %ymm0,%ymm12,%ymm4
  1e2bc2:	c4 c1 5d 55 f6       	vandnpd %ymm14,%ymm4,%ymm6
  1e2bc7:	c5 ad d4 fe          	vpaddq %ymm6,%ymm10,%ymm7
  1e2bcb:	c5 85 ef ff          	vpxor  %ymm7,%ymm15,%ymm7
  1e2bcf:	c4 e2 3d 37 ff       	vpcmpgtq %ymm7,%ymm8,%ymm7
  1e2bd4:	c5 fd 11 a4 24 50 05 	vmovupd %ymm4,0x550(%rsp)
  1e2bdb:	00 00 
  1e2bdd:	c4 c3 1d 4b e3 40    	vblendvpd %ymm4,%ymm11,%ymm12,%ymm4
  1e2be3:	c5 fd 11 a4 24 40 04 	vmovupd %ymm4,0x440(%rsp)
  1e2bea:	00 00 
  1e2bec:	c5 9d 73 d4 34       	vpsrlq $0x34,%ymm4,%ymm12
  1e2bf1:	c5 1d db e1          	vpand  %ymm1,%ymm12,%ymm12
  1e2bf5:	c5 9d d4 e6          	vpaddq %ymm6,%ymm12,%ymm4
  1e2bf9:	c5 fe 7f a4 24 a0 05 	vmovdqu %ymm4,0x5a0(%rsp)
  1e2c00:	00 00 
  1e2c02:	c5 95 d4 f4          	vpaddq %ymm4,%ymm13,%ymm6
  1e2c06:	c5 85 ef f6          	vpxor  %ymm6,%ymm15,%ymm6
  1e2c0a:	c4 e2 55 37 f6       	vpcmpgtq %ymm6,%ymm5,%ymm6
  1e2c0f:	c5 c5 eb c6          	vpor   %ymm6,%ymm7,%ymm0
  1e2c13:	c5 fe 7f 84 24 60 04 	vmovdqu %ymm0,0x460(%rsp)
  1e2c1a:	00 00 
  1e2c1c:	c5 fd 10 b4 24 40 02 	vmovupd 0x240(%rsp),%ymm6
  1e2c23:	00 00 
  1e2c25:	c4 41 19 ef e4       	vpxor  %xmm12,%xmm12,%xmm12
  1e2c2a:	c5 9d c2 e6 00       	vcmpeqpd %ymm6,%ymm12,%ymm4
  1e2c2f:	c4 c3 4d 4b fb 40    	vblendvpd %ymm4,%ymm11,%ymm6,%ymm7
  1e2c35:	c5 fd 11 a4 24 c0 05 	vmovupd %ymm4,0x5c0(%rsp)
  1e2c3c:	00 00 
  1e2c3e:	c4 c1 5d 55 f6       	vandnpd %ymm14,%ymm4,%ymm6
  1e2c43:	c5 fd 11 bc 24 e0 03 	vmovupd %ymm7,0x3e0(%rsp)
  1e2c4a:	00 00 
  1e2c4c:	c5 c5 73 d7 34       	vpsrlq $0x34,%ymm7,%ymm7
  1e2c51:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
  1e2c55:	c5 c5 d4 e6          	vpaddq %ymm6,%ymm7,%ymm4
  1e2c59:	c5 ad d4 f6          	vpaddq %ymm6,%ymm10,%ymm6
  1e2c5d:	c5 85 ef f6          	vpxor  %ymm6,%ymm15,%ymm6
  1e2c61:	c4 e2 3d 37 f6       	vpcmpgtq %ymm6,%ymm8,%ymm6
  1e2c66:	c5 fe 7f a4 24 b0 06 	vmovdqu %ymm4,0x6b0(%rsp)
  1e2c6d:	00 00 
  1e2c6f:	c5 95 d4 fc          	vpaddq %ymm4,%ymm13,%ymm7
  1e2c73:	c5 85 ef ff          	vpxor  %ymm7,%ymm15,%ymm7
  1e2c77:	c4 e2 55 37 ff       	vpcmpgtq %ymm7,%ymm5,%ymm7
  1e2c7c:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
  1e2c80:	c5 fd 10 bc 24 c0 01 	vmovupd 0x1c0(%rsp),%ymm7
  1e2c87:	00 00 
  1e2c89:	c5 fd 6f c3          	vmovdqa %ymm3,%ymm0
  1e2c8d:	c5 9d c2 df 00       	vcmpeqpd %ymm7,%ymm12,%ymm3
  1e2c92:	c4 c3 45 4b e3 30    	vblendvpd %ymm3,%ymm11,%ymm7,%ymm4
  1e2c98:	c5 fd 11 a4 24 a0 07 	vmovupd %ymm4,0x7a0(%rsp)
  1e2c9f:	00 00 
  1e2ca1:	c5 c5 73 d4 34       	vpsrlq $0x34,%ymm4,%ymm7
  1e2ca6:	c5 c5 db f9          	vpand  %ymm1,%ymm7,%ymm7
  1e2caa:	c5 7d 10 a4 24 00 02 	vmovupd 0x200(%rsp),%ymm12
  1e2cb1:	00 00 
  1e2cb3:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1e2cb7:	c5 9d c2 e4 00       	vcmpeqpd %ymm4,%ymm12,%ymm4
  1e2cbc:	c4 43 1d 4b db 40    	vblendvpd %ymm4,%ymm11,%ymm12,%ymm11
  1e2cc2:	c5 7d 11 9c 24 c0 07 	vmovupd %ymm11,0x7c0(%rsp)
  1e2cc9:	00 00 
  1e2ccb:	c4 c1 25 73 d3 34    	vpsrlq $0x34,%ymm11,%ymm11
  1e2cd1:	c5 a5 db c9          	vpand  %ymm1,%ymm11,%ymm1
  1e2cd5:	c5 fd 11 9c 24 e0 07 	vmovupd %ymm3,0x7e0(%rsp)
  1e2cdc:	00 00 
  1e2cde:	c4 41 65 55 e6       	vandnpd %ymm14,%ymm3,%ymm12
  1e2ce3:	c5 1d d4 df          	vpaddq %ymm7,%ymm12,%ymm11
  1e2ce7:	c4 c1 1d d4 fa       	vpaddq %ymm10,%ymm12,%ymm7
  1e2cec:	c4 41 5d 55 e6       	vandnpd %ymm14,%ymm4,%ymm12
  1e2cf1:	c5 7d 28 f4          	vmovapd %ymm4,%ymm14
  1e2cf5:	c4 41 1d d4 d2       	vpaddq %ymm10,%ymm12,%ymm10
  1e2cfa:	c5 9d d4 c9          	vpaddq %ymm1,%ymm12,%ymm1
  1e2cfe:	c4 41 2d ef d7       	vpxor  %ymm15,%ymm10,%ymm10
  1e2d03:	c4 42 3d 37 d2       	vpcmpgtq %ymm10,%ymm8,%ymm10
  1e2d08:	c5 15 d4 e1          	vpaddq %ymm1,%ymm13,%ymm12
  1e2d0c:	c4 41 1d ef e7       	vpxor  %ymm15,%ymm12,%ymm12
  1e2d11:	c4 42 55 37 e4       	vpcmpgtq %ymm12,%ymm5,%ymm12
  1e2d16:	c4 41 2d eb d4       	vpor   %ymm12,%ymm10,%ymm10
  1e2d1b:	c5 fd 10 a4 24 40 03 	vmovupd 0x340(%rsp),%ymm4
  1e2d22:	00 00 
  1e2d24:	c5 ad eb f6          	vpor   %ymm6,%ymm10,%ymm6
  1e2d28:	c5 cd eb b4 24 60 04 	vpor   0x460(%rsp),%ymm6,%ymm6
  1e2d2f:	00 00 
  1e2d31:	c4 41 25 d4 d5       	vpaddq %ymm13,%ymm11,%ymm10
  1e2d36:	c4 41 2d ef d7       	vpxor  %ymm15,%ymm10,%ymm10
  1e2d3b:	c4 c2 55 37 ea       	vpcmpgtq %ymm10,%ymm5,%ymm5
  1e2d40:	c5 85 ef ff          	vpxor  %ymm7,%ymm15,%ymm7
  1e2d44:	c4 e2 3d 37 ff       	vpcmpgtq %ymm7,%ymm8,%ymm7
  1e2d49:	c5 c5 eb ed          	vpor   %ymm5,%ymm7,%ymm5
  1e2d4d:	c5 cd 73 f6 3f       	vpsllq $0x3f,%ymm6,%ymm6
  1e2d52:	c5 cd eb ed          	vpor   %ymm5,%ymm6,%ymm5
  1e2d56:	c4 e2 7d 0f ed       	vtestpd %ymm5,%ymm5
  1e2d5b:	0f 85 6f f9 ff ff    	jne    1e26d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2560>
  1e2d61:	c5 fe 6f ac 24 80 04 	vmovdqu 0x480(%rsp),%ymm5
  1e2d68:	00 00 
  1e2d6a:	c5 cd 73 f5 34       	vpsllq $0x34,%ymm5,%ymm6
  1e2d6f:	c4 e2 7d 59 2d 50 35 	vpbroadcastq -0x1bcab0(%rip),%ymm5        # 262c8 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x5f8>
  1e2d76:	e4 ff 
  1e2d78:	c5 d5 db bc 24 c0 02 	vpand  0x2c0(%rsp),%ymm5,%ymm7
  1e2d7f:	00 00 
  1e2d81:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
  1e2d85:	c5 fd 10 bc 24 e0 02 	vmovupd 0x2e0(%rsp),%ymm7
  1e2d8c:	00 00 
  1e2d8e:	c4 e3 4d 4b d2 70    	vblendvpd %ymm7,%ymm2,%ymm6,%ymm2
  1e2d94:	c5 cd 73 f0 34       	vpsllq $0x34,%ymm0,%ymm6
  1e2d99:	c5 d5 db bc 24 60 02 	vpand  0x260(%rsp),%ymm5,%ymm7
  1e2da0:	00 00 
  1e2da2:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
  1e2da6:	c5 fd 10 bc 24 00 04 	vmovupd 0x400(%rsp),%ymm7
  1e2dad:	00 00 
  1e2daf:	c4 e3 4d 4b 9c 24 00 	vblendvpd %ymm7,0x300(%rsp),%ymm6,%ymm3
  1e2db6:	03 00 00 70 
  1e2dba:	c5 fe 6f b4 24 20 04 	vmovdqu 0x420(%rsp),%ymm6
  1e2dc1:	00 00 
  1e2dc3:	c5 cd 73 f6 34       	vpsllq $0x34,%ymm6,%ymm6
  1e2dc8:	c5 d5 db bc 24 a0 02 	vpand  0x2a0(%rsp),%ymm5,%ymm7
  1e2dcf:	00 00 
  1e2dd1:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
  1e2dd5:	c5 fd 10 bc 24 20 03 	vmovupd 0x320(%rsp),%ymm7
  1e2ddc:	00 00 
  1e2dde:	c4 e3 4d 4b e4 70    	vblendvpd %ymm7,%ymm4,%ymm6,%ymm4
  1e2de4:	c5 fe 6f b4 24 70 05 	vmovdqu 0x570(%rsp),%ymm6
  1e2deb:	00 00 
  1e2ded:	c5 cd 73 f6 34       	vpsllq $0x34,%ymm6,%ymm6
  1e2df2:	c5 d5 db bc 24 10 05 	vpand  0x510(%rsp),%ymm5,%ymm7
  1e2df9:	00 00 
  1e2dfb:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
  1e2dff:	c4 e3 4d 4b 84 24 50 	vblendvpd %ymm9,0x150(%rsp),%ymm6,%ymm0
  1e2e06:	01 00 00 90 
  1e2e0a:	c4 c1 4d 73 f3 34    	vpsllq $0x34,%ymm11,%ymm6
  1e2e10:	c5 d5 db bc 24 a0 07 	vpand  0x7a0(%rsp),%ymm5,%ymm7
  1e2e17:	00 00 
  1e2e19:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
  1e2e1d:	c5 fd 10 bc 24 e0 07 	vmovupd 0x7e0(%rsp),%ymm7
  1e2e24:	00 00 
  1e2e26:	c4 63 4d 4b 84 24 c0 	vblendvpd %ymm7,0x1c0(%rsp),%ymm6,%ymm8
  1e2e2d:	01 00 00 70 
  1e2e31:	c5 fe 6f b4 24 a0 05 	vmovdqu 0x5a0(%rsp),%ymm6
  1e2e38:	00 00 
  1e2e3a:	c5 cd 73 f6 34       	vpsllq $0x34,%ymm6,%ymm6
  1e2e3f:	c5 d5 db bc 24 40 04 	vpand  0x440(%rsp),%ymm5,%ymm7
  1e2e46:	00 00 
  1e2e48:	c5 cd eb f7          	vpor   %ymm7,%ymm6,%ymm6
  1e2e4c:	c5 fd 10 bc 24 50 05 	vmovupd 0x550(%rsp),%ymm7
  1e2e53:	00 00 
  1e2e55:	c4 e3 4d 4b bc 24 90 	vblendvpd %ymm7,0x190(%rsp),%ymm6,%ymm7
  1e2e5c:	01 00 00 70 
  1e2e60:	c5 fe 6f b4 24 b0 06 	vmovdqu 0x6b0(%rsp),%ymm6
  1e2e67:	00 00 
  1e2e69:	c5 cd 73 f6 34       	vpsllq $0x34,%ymm6,%ymm6
  1e2e6e:	c5 55 db 8c 24 e0 03 	vpand  0x3e0(%rsp),%ymm5,%ymm9
  1e2e75:	00 00 
  1e2e77:	c5 b5 eb f6          	vpor   %ymm6,%ymm9,%ymm6
  1e2e7b:	c5 7d 10 8c 24 c0 05 	vmovupd 0x5c0(%rsp),%ymm9
  1e2e82:	00 00 
  1e2e84:	c4 e3 4d 4b b4 24 40 	vblendvpd %ymm9,0x240(%rsp),%ymm6,%ymm6
  1e2e8b:	02 00 00 90 
  1e2e8f:	c5 d5 db ac 24 c0 07 	vpand  0x7c0(%rsp),%ymm5,%ymm5
  1e2e96:	00 00 
  1e2e98:	c5 f5 73 f1 34       	vpsllq $0x34,%ymm1,%ymm1
  1e2e9d:	c5 f5 eb cd          	vpor   %ymm5,%ymm1,%ymm1
  1e2ea1:	c4 e3 75 4b ac 24 00 	vblendvpd %ymm14,0x200(%rsp),%ymm1,%ymm5
  1e2ea8:	02 00 00 e0 
  1e2eac:	48 8d b4 24 90 06 00 	lea    0x690(%rsp),%rsi
  1e2eb3:	00 
  1e2eb4:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1e2eb8:	c5 fd 11 0e          	vmovupd %ymm1,(%rsi)
  1e2ebc:	c5 fd 11 8c 24 30 07 	vmovupd %ymm1,0x730(%rsp)
  1e2ec3:	00 00 
  1e2ec5:	c5 fd 11 8c 24 10 07 	vmovupd %ymm1,0x710(%rsp)
  1e2ecc:	00 00 
  1e2ece:	c5 fd 11 8c 24 f0 06 	vmovupd %ymm1,0x6f0(%rsp)
  1e2ed5:	00 00 
  1e2ed7:	c5 fd 11 8c 24 d0 06 	vmovupd %ymm1,0x6d0(%rsp)
  1e2ede:	00 00 
  1e2ee0:	c5 fd 11 8c 24 30 06 	vmovupd %ymm1,0x630(%rsp)
  1e2ee7:	00 00 
  1e2ee9:	c5 fd 11 8c 24 50 06 	vmovupd %ymm1,0x650(%rsp)
  1e2ef0:	00 00 
  1e2ef2:	c5 fd 11 8c 24 70 06 	vmovupd %ymm1,0x670(%rsp)
  1e2ef9:	00 00 
  1e2efb:	48 8b 3d 76 79 10 00 	mov    0x107976(%rip),%rdi        # 2ea878 <_DYNAMIC+0xa60>
  1e2f02:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e2f09:	48 8d 84 24 d0 06 00 	lea    0x6d0(%rsp),%rax
  1e2f10:	00 
  1e2f11:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e2f1a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2daa>
  1e2f18:	ff e2                	jmp    *%rdx
  1e2f1a:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e2f21:	48 8d 84 24 30 06 00 	lea    0x630(%rsp),%rax
  1e2f28:	00 
  1e2f29:	c5 7d 29 c0          	vmovapd %ymm8,%ymm0
  1e2f2d:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e2f36 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2dc6>
  1e2f34:	ff e2                	jmp    *%rdx
  1e2f36:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e2f3d:	48 8d 84 24 f0 06 00 	lea    0x6f0(%rsp),%rax
  1e2f44:	00 
  1e2f45:	c5 fd 28 c4          	vmovapd %ymm4,%ymm0
  1e2f49:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e2f52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2de2>
  1e2f50:	ff e2                	jmp    *%rdx
  1e2f52:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e2f59:	48 8d 84 24 50 06 00 	lea    0x650(%rsp),%rax
  1e2f60:	00 
  1e2f61:	c5 fd 28 c7          	vmovapd %ymm7,%ymm0
  1e2f65:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e2f6e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2dfe>
  1e2f6c:	ff e2                	jmp    *%rdx
  1e2f6e:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e2f75:	48 8d 84 24 10 07 00 	lea    0x710(%rsp),%rax
  1e2f7c:	00 
  1e2f7d:	c5 fd 28 c3          	vmovapd %ymm3,%ymm0
  1e2f81:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e2f8a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2e1a>
  1e2f88:	ff e2                	jmp    *%rdx
  1e2f8a:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e2f91:	48 8d 84 24 70 06 00 	lea    0x670(%rsp),%rax
  1e2f98:	00 
  1e2f99:	c5 fd 28 c6          	vmovapd %ymm6,%ymm0
  1e2f9d:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e2fa6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2e36>
  1e2fa4:	ff e2                	jmp    *%rdx
  1e2fa6:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e2fad:	48 8d 84 24 30 07 00 	lea    0x730(%rsp),%rax
  1e2fb4:	00 
  1e2fb5:	c5 fd 28 c2          	vmovapd %ymm2,%ymm0
  1e2fb9:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e2fc2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2e52>
  1e2fc0:	ff e2                	jmp    *%rdx
  1e2fc2:	48 8b 97 08 08 00 00 	mov    0x808(%rdi),%rdx
  1e2fc9:	48 89 f0             	mov    %rsi,%rax
  1e2fcc:	c5 fd 28 c5          	vmovapd %ymm5,%ymm0
  1e2fd0:	48 8d 0d 02 00 00 00 	lea    0x2(%rip),%rcx        # 1e2fd9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x2e69>
  1e2fd7:	ff e2                	jmp    *%rdx
  1e2fd9:	c5 fd 10 84 24 d0 06 	vmovupd 0x6d0(%rsp),%ymm0
  1e2fe0:	00 00 
  1e2fe2:	c5 fd 10 8c 24 f0 06 	vmovupd 0x6f0(%rsp),%ymm1
  1e2fe9:	00 00 
  1e2feb:	c4 e3 75 18 8c 24 50 	vinsertf128 $0x1,0x650(%rsp),%ymm1,%ymm1
  1e2ff2:	06 00 00 01 
  1e2ff6:	c4 e3 7d 18 84 24 30 	vinsertf128 $0x1,0x630(%rsp),%ymm0,%ymm0
  1e2ffd:	06 00 00 01 
  1e3001:	c5 fd 14 d1          	vunpcklpd %ymm1,%ymm0,%ymm2
  1e3005:	c5 ed 58 94 24 10 01 	vaddpd 0x110(%rsp),%ymm2,%ymm2
  1e300c:	00 00 
  1e300e:	c5 fd 15 c1          	vunpckhpd %ymm1,%ymm0,%ymm0
  1e3012:	c5 ed 58 c0          	vaddpd %ymm0,%ymm2,%ymm0
  1e3016:	c5 f9 28 8c 24 00 07 	vmovapd 0x700(%rsp),%xmm1
  1e301d:	00 00 
  1e301f:	c5 f9 28 94 24 e0 06 	vmovapd 0x6e0(%rsp),%xmm2
  1e3026:	00 00 
  1e3028:	c5 e9 14 d9          	vunpcklpd %xmm1,%xmm2,%xmm3
  1e302c:	c5 fd 10 a4 24 30 06 	vmovupd 0x630(%rsp),%ymm4
  1e3033:	00 00 
  1e3035:	c5 fd 10 ac 24 50 06 	vmovupd 0x650(%rsp),%ymm5
  1e303c:	00 00 
  1e303e:	c5 dd 14 f5          	vunpcklpd %ymm5,%ymm4,%ymm6
  1e3042:	c4 e3 65 0d de 0c    	vblendpd $0xc,%ymm6,%ymm3,%ymm3
  1e3048:	c5 fd 10 b4 24 70 06 	vmovupd 0x670(%rsp),%ymm6
  1e304f:	00 00 
  1e3051:	c5 fd 58 c3          	vaddpd %ymm3,%ymm0,%ymm0
  1e3055:	c5 e9 15 c9          	vunpckhpd %xmm1,%xmm2,%xmm1
  1e3059:	c5 dd 15 d5          	vunpckhpd %ymm5,%ymm4,%ymm2
  1e305d:	c4 e3 75 0d ca 0c    	vblendpd $0xc,%ymm2,%ymm1,%ymm1
  1e3063:	c5 fd 58 c1          	vaddpd %ymm1,%ymm0,%ymm0
  1e3067:	c5 fd 11 84 24 10 01 	vmovupd %ymm0,0x110(%rsp)
  1e306e:	00 00 
  1e3070:	c5 fd 10 84 24 90 06 	vmovupd 0x690(%rsp),%ymm0
  1e3077:	00 00 
  1e3079:	c5 fd 10 8c 24 30 07 	vmovupd 0x730(%rsp),%ymm1
  1e3080:	00 00 
  1e3082:	c4 e3 75 18 8c 24 90 	vinsertf128 $0x1,0x690(%rsp),%ymm1,%ymm1
  1e3089:	06 00 00 01 
  1e308d:	c5 fd 10 94 24 10 07 	vmovupd 0x710(%rsp),%ymm2
  1e3094:	00 00 
  1e3096:	c4 e3 6d 18 94 24 70 	vinsertf128 $0x1,0x670(%rsp),%ymm2,%ymm2
  1e309d:	06 00 00 01 
  1e30a1:	c5 ed 14 d9          	vunpcklpd %ymm1,%ymm2,%ymm3
  1e30a5:	c5 e5 58 9c 24 30 01 	vaddpd 0x130(%rsp),%ymm3,%ymm3
  1e30ac:	00 00 
  1e30ae:	c5 ed 15 c9          	vunpckhpd %ymm1,%ymm2,%ymm1
  1e30b2:	c5 e5 58 c9          	vaddpd %ymm1,%ymm3,%ymm1
  1e30b6:	c5 f9 28 94 24 40 07 	vmovapd 0x740(%rsp),%xmm2
  1e30bd:	00 00 
  1e30bf:	c5 f9 28 9c 24 20 07 	vmovapd 0x720(%rsp),%xmm3
  1e30c6:	00 00 
  1e30c8:	c5 e1 14 e2          	vunpcklpd %xmm2,%xmm3,%xmm4
  1e30cc:	c5 cd 14 e8          	vunpcklpd %ymm0,%ymm6,%ymm5
  1e30d0:	c4 e3 5d 0d e5 0c    	vblendpd $0xc,%ymm5,%ymm4,%ymm4
  1e30d6:	c5 f5 58 cc          	vaddpd %ymm4,%ymm1,%ymm1
  1e30da:	c5 e1 15 d2          	vunpckhpd %xmm2,%xmm3,%xmm2
  1e30de:	c5 cd 15 c0          	vunpckhpd %ymm0,%ymm6,%ymm0
  1e30e2:	c4 e3 6d 0d c0 0c    	vblendpd $0xc,%ymm0,%ymm2,%ymm0
  1e30e8:	c5 f5 58 c0          	vaddpd %ymm0,%ymm1,%ymm0
  1e30ec:	c5 fd 11 84 24 30 01 	vmovupd %ymm0,0x130(%rsp)
  1e30f3:	00 00 
  1e30f5:	e9 19 f6 ff ff       	jmp    1e2713 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x25a3>
  1e30fa:	48 8b 94 24 30 05 00 	mov    0x530(%rsp),%rdx
  1e3101:	00 
  1e3102:	89 d0                	mov    %edx,%eax
  1e3104:	c5 fb 10 84 24 10 01 	vmovsd 0x110(%rsp),%xmm0
  1e310b:	00 00 
  1e310d:	c5 fb 11 44 24 10    	vmovsd %xmm0,0x10(%rsp)
  1e3113:	c5 fb 10 84 24 18 01 	vmovsd 0x118(%rsp),%xmm0
  1e311a:	00 00 
  1e311c:	c5 fb 11 84 24 20 02 	vmovsd %xmm0,0x220(%rsp)
  1e3123:	00 00 
  1e3125:	c5 fb 10 84 24 20 01 	vmovsd 0x120(%rsp),%xmm0
  1e312c:	00 00 
  1e312e:	c5 fb 11 84 24 00 02 	vmovsd %xmm0,0x200(%rsp)
  1e3135:	00 00 
  1e3137:	83 e0 03             	and    $0x3,%eax
  1e313a:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  1e3141:	00 
  1e3142:	0f 84 0d 06 00 00    	je     1e3755 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x35e5>
  1e3148:	48 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%rax
  1e314f:	ff ff 0f 
  1e3152:	48 21 d0             	and    %rdx,%rax
  1e3155:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  1e315a:	4c 8d 34 c1          	lea    (%rcx,%rax,8),%r14
  1e315e:	48 89 d0             	mov    %rdx,%rax
  1e3161:	48 83 e0 fc          	and    $0xfffffffffffffffc,%rax
  1e3165:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  1e316c:	00 
  1e316d:	c5 fb 10 84 24 28 01 	vmovsd 0x128(%rsp),%xmm0
  1e3174:	00 00 
  1e3176:	c5 fb 11 84 24 c0 01 	vmovsd %xmm0,0x1c0(%rsp)
  1e317d:	00 00 
  1e317f:	c5 fb 10 84 24 30 01 	vmovsd 0x130(%rsp),%xmm0
  1e3186:	00 00 
  1e3188:	c5 fb 11 84 24 50 01 	vmovsd %xmm0,0x150(%rsp)
  1e318f:	00 00 
  1e3191:	c5 fb 10 9c 24 40 01 	vmovsd 0x140(%rsp),%xmm3
  1e3198:	00 00 
  1e319a:	48 8b 84 24 68 03 00 	mov    0x368(%rsp),%rax
  1e31a1:	00 
  1e31a2:	48 89 84 24 a0 02 00 	mov    %rax,0x2a0(%rsp)
  1e31a9:	00 
  1e31aa:	48 8b 84 24 78 03 00 	mov    0x378(%rsp),%rax
  1e31b1:	00 
  1e31b2:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  1e31b9:	00 
  1e31ba:	48 8b 84 24 88 03 00 	mov    0x388(%rsp),%rax
  1e31c1:	00 
  1e31c2:	48 89 84 24 20 04 00 	mov    %rax,0x420(%rsp)
  1e31c9:	00 
  1e31ca:	48 8b 84 24 98 03 00 	mov    0x398(%rsp),%rax
  1e31d1:	00 
  1e31d2:	48 89 84 24 80 04 00 	mov    %rax,0x480(%rsp)
  1e31d9:	00 
  1e31da:	48 8b 84 24 a8 03 00 	mov    0x3a8(%rsp),%rax
  1e31e1:	00 
  1e31e2:	48 89 84 24 00 04 00 	mov    %rax,0x400(%rsp)
  1e31e9:	00 
  1e31ea:	48 8b 84 24 b8 03 00 	mov    0x3b8(%rsp),%rax
  1e31f1:	00 
  1e31f2:	48 89 84 24 60 04 00 	mov    %rax,0x460(%rsp)
  1e31f9:	00 
  1e31fa:	c5 fb 10 84 24 38 01 	vmovsd 0x138(%rsp),%xmm0
  1e3201:	00 00 
  1e3203:	c5 fb 11 84 24 90 01 	vmovsd %xmm0,0x190(%rsp)
  1e320a:	00 00 
  1e320c:	c5 fb 10 a4 24 48 01 	vmovsd 0x148(%rsp),%xmm4
  1e3213:	00 00 
  1e3215:	48 c1 e2 03          	shl    $0x3,%rdx
  1e3219:	48 83 e2 e0          	and    $0xffffffffffffffe0,%rdx
  1e321d:	48 8b 84 24 d0 03 00 	mov    0x3d0(%rsp),%rax
  1e3224:	00 
  1e3225:	48 01 d0             	add    %rdx,%rax
  1e3228:	48 89 84 24 a0 05 00 	mov    %rax,0x5a0(%rsp)
  1e322f:	00 
  1e3230:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  1e3237:	00 
  1e3238:	48 01 d0             	add    %rdx,%rax
  1e323b:	48 89 84 24 c0 05 00 	mov    %rax,0x5c0(%rsp)
  1e3242:	00 
  1e3243:	48 8b 84 24 90 03 00 	mov    0x390(%rsp),%rax
  1e324a:	00 
  1e324b:	48 01 d0             	add    %rdx,%rax
  1e324e:	48 89 84 24 50 05 00 	mov    %rax,0x550(%rsp)
  1e3255:	00 
  1e3256:	48 8b 84 24 70 03 00 	mov    0x370(%rsp),%rax
  1e325d:	00 
  1e325e:	48 01 d0             	add    %rdx,%rax
  1e3261:	48 89 84 24 30 05 00 	mov    %rax,0x530(%rsp)
  1e3268:	00 
  1e3269:	48 8b 84 24 c0 03 00 	mov    0x3c0(%rsp),%rax
  1e3270:	00 
  1e3271:	48 01 d0             	add    %rdx,%rax
  1e3274:	48 89 84 24 70 05 00 	mov    %rax,0x570(%rsp)
  1e327b:	00 
  1e327c:	48 8b 84 24 a0 03 00 	mov    0x3a0(%rsp),%rax
  1e3283:	00 
  1e3284:	48 01 d0             	add    %rdx,%rax
  1e3287:	48 89 84 24 10 05 00 	mov    %rax,0x510(%rsp)
  1e328e:	00 
  1e328f:	48 8b 84 24 80 03 00 	mov    0x380(%rsp),%rax
  1e3296:	00 
  1e3297:	48 01 d0             	add    %rdx,%rax
  1e329a:	48 89 84 24 e0 02 00 	mov    %rax,0x2e0(%rsp)
  1e32a1:	00 
  1e32a2:	48 03 94 24 60 03 00 	add    0x360(%rsp),%rdx
  1e32a9:	00 
  1e32aa:	48 8b 84 24 c8 03 00 	mov    0x3c8(%rsp),%rax
  1e32b1:	00 
  1e32b2:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
  1e32b9:	00 
  1e32ba:	48 8b 84 24 d8 03 00 	mov    0x3d8(%rsp),%rax
  1e32c1:	00 
  1e32c2:	48 89 84 24 40 04 00 	mov    %rax,0x440(%rsp)
  1e32c9:	00 
  1e32ca:	31 db                	xor    %ebx,%ebx
  1e32cc:	4c 8b 3d 95 75 10 00 	mov    0x107595(%rip),%r15        # 2ea868 <_DYNAMIC+0xa50>
  1e32d3:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  1e32da:	00 
  1e32db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  1e32e0:	48 39 de             	cmp    %rbx,%rsi
  1e32e3:	0f 84 47 29 00 00    	je     1e5c30 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5ac0>
  1e32e9:	48 8b 84 24 b0 01 00 	mov    0x1b0(%rsp),%rax
  1e32f0:	00 
  1e32f1:	48 8b 2c d8          	mov    (%rax,%rbx,8),%rbp
  1e32f5:	48 85 ed             	test   %rbp,%rbp
  1e32f8:	0f 84 42 02 00 00    	je     1e3540 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x33d0>
  1e32fe:	48 8b 84 24 00 03 00 	mov    0x300(%rsp),%rax
  1e3305:	00 
  1e3306:	4c 8d 2c 18          	lea    (%rax,%rbx,1),%r13
  1e330a:	4c 3b ac 24 a0 02 00 	cmp    0x2a0(%rsp),%r13
  1e3311:	00 
  1e3312:	0f 83 5c 2a 00 00    	jae    1e5d74 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5c04>
  1e3318:	c5 fb 11 a4 24 40 03 	vmovsd %xmm4,0x340(%rsp)
  1e331f:	00 00 
  1e3321:	c5 fb 11 5c 24 30    	vmovsd %xmm3,0x30(%rsp)
  1e3327:	4c 3b ac 24 20 04 00 	cmp    0x420(%rsp),%r13
  1e332e:	00 
  1e332f:	0f 83 14 2a 00 00    	jae    1e5d49 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5bd9>
  1e3335:	49 89 d4             	mov    %rdx,%r12
  1e3338:	c5 fb 10 04 da       	vmovsd (%rdx,%rbx,8),%xmm0
  1e333d:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
  1e3344:	00 
  1e3345:	c5 fb 10 0c d8       	vmovsd (%rax,%rbx,8),%xmm1
  1e334a:	c4 c1 7b 10 14 de    	vmovsd (%r14,%rbx,8),%xmm2
  1e3350:	c5 fb 11 94 24 40 02 	vmovsd %xmm2,0x240(%rsp)
  1e3357:	00 00 
  1e3359:	48 89 ef             	mov    %rbp,%rdi
  1e335c:	c5 f8 77             	vzeroupper
  1e335f:	41 ff d7             	call   *%r15
  1e3362:	c5 fb 10 54 24 10    	vmovsd 0x10(%rsp),%xmm2
  1e3368:	c5 fb 58 d2          	vaddsd %xmm2,%xmm0,%xmm2
  1e336c:	c5 fb 11 94 24 10 01 	vmovsd %xmm2,0x110(%rsp)
  1e3373:	00 00 
  1e3375:	c5 fb 10 84 24 20 02 	vmovsd 0x220(%rsp),%xmm0
  1e337c:	00 00 
  1e337e:	c5 f3 58 c0          	vaddsd %xmm0,%xmm1,%xmm0
  1e3382:	c5 fb 11 84 24 18 01 	vmovsd %xmm0,0x118(%rsp)
  1e3389:	00 00 
  1e338b:	4c 3b ac 24 00 04 00 	cmp    0x400(%rsp),%r13
  1e3392:	00 
  1e3393:	0f 83 88 29 00 00    	jae    1e5d21 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5bb1>
  1e3399:	c5 fb 11 84 24 20 02 	vmovsd %xmm0,0x220(%rsp)
  1e33a0:	00 00 
  1e33a2:	c5 fb 11 54 24 10    	vmovsd %xmm2,0x10(%rsp)
  1e33a8:	4c 3b ac 24 60 02 00 	cmp    0x260(%rsp),%r13
  1e33af:	00 
  1e33b0:	0f 83 43 29 00 00    	jae    1e5cf9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5b89>
  1e33b6:	48 8b 84 24 10 05 00 	mov    0x510(%rsp),%rax
  1e33bd:	00 
  1e33be:	c5 fb 10 04 d8       	vmovsd (%rax,%rbx,8),%xmm0
  1e33c3:	48 8b 84 24 70 05 00 	mov    0x570(%rsp),%rax
  1e33ca:	00 
  1e33cb:	c5 fb 10 0c d8       	vmovsd (%rax,%rbx,8),%xmm1
  1e33d0:	c5 fb 10 94 24 40 02 	vmovsd 0x240(%rsp),%xmm2
  1e33d7:	00 00 
  1e33d9:	48 89 ef             	mov    %rbp,%rdi
  1e33dc:	41 ff d7             	call   *%r15
  1e33df:	c5 fb 10 94 24 00 02 	vmovsd 0x200(%rsp),%xmm2
  1e33e6:	00 00 
  1e33e8:	c5 fb 58 d2          	vaddsd %xmm2,%xmm0,%xmm2
  1e33ec:	c5 fb 11 94 24 00 02 	vmovsd %xmm2,0x200(%rsp)
  1e33f3:	00 00 
  1e33f5:	c5 fb 11 94 24 20 01 	vmovsd %xmm2,0x120(%rsp)
  1e33fc:	00 00 
  1e33fe:	c5 fb 10 84 24 c0 01 	vmovsd 0x1c0(%rsp),%xmm0
  1e3405:	00 00 
  1e3407:	c5 f3 58 c0          	vaddsd %xmm0,%xmm1,%xmm0
  1e340b:	c5 fb 11 84 24 c0 01 	vmovsd %xmm0,0x1c0(%rsp)
  1e3412:	00 00 
  1e3414:	c5 fb 11 84 24 28 01 	vmovsd %xmm0,0x128(%rsp)
  1e341b:	00 00 
  1e341d:	4c 3b ac 24 c0 02 00 	cmp    0x2c0(%rsp),%r13
  1e3424:	00 
  1e3425:	0f 83 39 29 00 00    	jae    1e5d64 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5bf4>
  1e342b:	4c 3b ac 24 80 04 00 	cmp    0x480(%rsp),%r13
  1e3432:	00 
  1e3433:	0f 83 00 29 00 00    	jae    1e5d39 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5bc9>
  1e3439:	48 8b 84 24 30 05 00 	mov    0x530(%rsp),%rax
  1e3440:	00 
  1e3441:	c5 fb 10 04 d8       	vmovsd (%rax,%rbx,8),%xmm0
  1e3446:	48 8b 84 24 50 05 00 	mov    0x550(%rsp),%rax
  1e344d:	00 
  1e344e:	c5 fb 10 0c d8       	vmovsd (%rax,%rbx,8),%xmm1
  1e3453:	c4 c1 7b 10 14 de    	vmovsd (%r14,%rbx,8),%xmm2
  1e3459:	c5 fb 11 94 24 40 02 	vmovsd %xmm2,0x240(%rsp)
  1e3460:	00 00 
  1e3462:	48 89 ef             	mov    %rbp,%rdi
  1e3465:	41 ff d7             	call   *%r15
  1e3468:	c5 fb 10 94 24 50 01 	vmovsd 0x150(%rsp),%xmm2
  1e346f:	00 00 
  1e3471:	c5 fb 58 d2          	vaddsd %xmm2,%xmm0,%xmm2
  1e3475:	c5 fb 11 94 24 30 01 	vmovsd %xmm2,0x130(%rsp)
  1e347c:	00 00 
  1e347e:	c5 fb 10 84 24 90 01 	vmovsd 0x190(%rsp),%xmm0
  1e3485:	00 00 
  1e3487:	c5 f3 58 c0          	vaddsd %xmm0,%xmm1,%xmm0
  1e348b:	c5 fb 11 84 24 38 01 	vmovsd %xmm0,0x138(%rsp)
  1e3492:	00 00 
  1e3494:	4c 3b ac 24 60 04 00 	cmp    0x460(%rsp),%r13
  1e349b:	00 
  1e349c:	0f 83 6f 28 00 00    	jae    1e5d11 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5ba1>
  1e34a2:	c5 fb 11 84 24 90 01 	vmovsd %xmm0,0x190(%rsp)
  1e34a9:	00 00 
  1e34ab:	c5 fb 11 94 24 50 01 	vmovsd %xmm2,0x150(%rsp)
  1e34b2:	00 00 
  1e34b4:	4c 3b ac 24 40 04 00 	cmp    0x440(%rsp),%r13
  1e34bb:	00 
  1e34bc:	0f 83 27 28 00 00    	jae    1e5ce9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5b79>
  1e34c2:	48 8b 84 24 c0 05 00 	mov    0x5c0(%rsp),%rax
  1e34c9:	00 
  1e34ca:	c5 fb 10 04 d8       	vmovsd (%rax,%rbx,8),%xmm0
  1e34cf:	48 8b 84 24 a0 05 00 	mov    0x5a0(%rsp),%rax
  1e34d6:	00 
  1e34d7:	c5 fb 10 0c d8       	vmovsd (%rax,%rbx,8),%xmm1
  1e34dc:	c5 fb 10 94 24 40 02 	vmovsd 0x240(%rsp),%xmm2
  1e34e3:	00 00 
  1e34e5:	48 89 ef             	mov    %rbp,%rdi
  1e34e8:	41 ff d7             	call   *%r15
  1e34eb:	c5 fb 10 5c 24 30    	vmovsd 0x30(%rsp),%xmm3
  1e34f1:	c5 fb 58 db          	vaddsd %xmm3,%xmm0,%xmm3
  1e34f5:	c5 fb 11 9c 24 40 01 	vmovsd %xmm3,0x140(%rsp)
  1e34fc:	00 00 
  1e34fe:	c5 fb 10 a4 24 40 03 	vmovsd 0x340(%rsp),%xmm4
  1e3505:	00 00 
  1e3507:	c5 f3 58 e4          	vaddsd %xmm4,%xmm1,%xmm4
  1e350b:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  1e3512:	00 
  1e3513:	4c 89 e2             	mov    %r12,%rdx
  1e3516:	48 ff c3             	inc    %rbx
  1e3519:	c5 fb 11 a4 24 48 01 	vmovsd %xmm4,0x148(%rsp)
  1e3520:	00 00 
  1e3522:	48 39 9c 24 20 03 00 	cmp    %rbx,0x320(%rsp)
  1e3529:	00 
  1e352a:	0f 85 b0 fd ff ff    	jne    1e32e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3170>
  1e3530:	e9 68 02 00 00       	jmp    1e379d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x362d>
  1e3535:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  1e353c:	00 00 00 00 
  1e3540:	c4 c1 7b 10 04 de    	vmovsd (%r14,%rbx,8),%xmm0
  1e3546:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1e354a:	c5 f9 2e c1          	vucomisd %xmm1,%xmm0
  1e354e:	75 02                	jne    1e3552 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x33e2>
  1e3550:	7b 46                	jnp    1e3598 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3428>
  1e3552:	c5 f9 54 0d 26 20 e4 	vandpd -0x1bdfda(%rip),%xmm0,%xmm1        # 25580 <__abi_tag+0x25284>
  1e3559:	ff 
  1e355a:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  1e355f:	48 c1 e8 34          	shr    $0x34,%rax
  1e3563:	25 ff 07 00 00       	and    $0x7ff,%eax
  1e3568:	3d ff 07 00 00       	cmp    $0x7ff,%eax
  1e356d:	0f 92 c0             	setb   %al
  1e3570:	c5 f9 2e 0d 48 2d e4 	vucomisd -0x1bd2b8(%rip),%xmm1        # 262c0 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x5f0>
  1e3577:	ff 
  1e3578:	0f 82 80 fd ff ff    	jb     1e32fe <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x318e>
  1e357e:	84 c0                	test   %al,%al
  1e3580:	0f 84 78 fd ff ff    	je     1e32fe <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x318e>
  1e3586:	c5 fb 10 15 ba 2c e4 	vmovsd -0x1bd346(%rip),%xmm2        # 26248 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x578>
  1e358d:	ff 
  1e358e:	c5 f9 2e d1          	vucomisd %xmm1,%xmm2
  1e3592:	0f 82 66 fd ff ff    	jb     1e32fe <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x318e>
  1e3598:	48 8b 84 24 00 03 00 	mov    0x300(%rsp),%rax
  1e359f:	00 
  1e35a0:	48 8d 3c 18          	lea    (%rax,%rbx,1),%rdi
  1e35a4:	48 3b bc 24 a0 02 00 	cmp    0x2a0(%rsp),%rdi
  1e35ab:	00 
  1e35ac:	0f 83 79 2a 00 00    	jae    1e602b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5ebb>
  1e35b2:	c5 fb 59 0c da       	vmulsd (%rdx,%rbx,8),%xmm0,%xmm1
  1e35b7:	c5 fb 10 54 24 10    	vmovsd 0x10(%rsp),%xmm2
  1e35bd:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  1e35c1:	c5 fb 11 54 24 10    	vmovsd %xmm2,0x10(%rsp)
  1e35c7:	c5 fb 11 94 24 10 01 	vmovsd %xmm2,0x110(%rsp)
  1e35ce:	00 00 
  1e35d0:	48 3b bc 24 20 04 00 	cmp    0x420(%rsp),%rdi
  1e35d7:	00 
  1e35d8:	0f 83 9d 2a 00 00    	jae    1e607b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5f0b>
  1e35de:	48 8b 84 24 e0 02 00 	mov    0x2e0(%rsp),%rax
  1e35e5:	00 
  1e35e6:	c5 fb 59 0c d8       	vmulsd (%rax,%rbx,8),%xmm0,%xmm1
  1e35eb:	c5 fb 10 94 24 20 02 	vmovsd 0x220(%rsp),%xmm2
  1e35f2:	00 00 
  1e35f4:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  1e35f8:	c5 fb 11 94 24 20 02 	vmovsd %xmm2,0x220(%rsp)
  1e35ff:	00 00 
  1e3601:	c5 fb 11 94 24 18 01 	vmovsd %xmm2,0x118(%rsp)
  1e3608:	00 00 
  1e360a:	48 3b bc 24 00 04 00 	cmp    0x400(%rsp),%rdi
  1e3611:	00 
  1e3612:	0f 83 eb 29 00 00    	jae    1e6003 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5e93>
  1e3618:	48 8b 84 24 10 05 00 	mov    0x510(%rsp),%rax
  1e361f:	00 
  1e3620:	c5 fb 59 0c d8       	vmulsd (%rax,%rbx,8),%xmm0,%xmm1
  1e3625:	c5 fb 10 94 24 00 02 	vmovsd 0x200(%rsp),%xmm2
  1e362c:	00 00 
  1e362e:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  1e3632:	c5 fb 11 94 24 00 02 	vmovsd %xmm2,0x200(%rsp)
  1e3639:	00 00 
  1e363b:	c5 fb 11 94 24 20 01 	vmovsd %xmm2,0x120(%rsp)
  1e3642:	00 00 
  1e3644:	48 3b bc 24 60 02 00 	cmp    0x260(%rsp),%rdi
  1e364b:	00 
  1e364c:	0f 83 01 2a 00 00    	jae    1e6053 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5ee3>
  1e3652:	48 8b 84 24 70 05 00 	mov    0x570(%rsp),%rax
  1e3659:	00 
  1e365a:	c5 fb 59 0c d8       	vmulsd (%rax,%rbx,8),%xmm0,%xmm1
  1e365f:	c5 fb 10 94 24 c0 01 	vmovsd 0x1c0(%rsp),%xmm2
  1e3666:	00 00 
  1e3668:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  1e366c:	c5 fb 11 94 24 c0 01 	vmovsd %xmm2,0x1c0(%rsp)
  1e3673:	00 00 
  1e3675:	c5 fb 11 94 24 28 01 	vmovsd %xmm2,0x128(%rsp)
  1e367c:	00 00 
  1e367e:	48 3b bc 24 c0 02 00 	cmp    0x2c0(%rsp),%rdi
  1e3685:	00 
  1e3686:	0f 83 8f 29 00 00    	jae    1e601b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5eab>
  1e368c:	48 8b 84 24 30 05 00 	mov    0x530(%rsp),%rax
  1e3693:	00 
  1e3694:	c5 fb 59 0c d8       	vmulsd (%rax,%rbx,8),%xmm0,%xmm1
  1e3699:	c5 fb 10 94 24 50 01 	vmovsd 0x150(%rsp),%xmm2
  1e36a0:	00 00 
  1e36a2:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  1e36a6:	c5 fb 11 94 24 50 01 	vmovsd %xmm2,0x150(%rsp)
  1e36ad:	00 00 
  1e36af:	c5 fb 11 94 24 30 01 	vmovsd %xmm2,0x130(%rsp)
  1e36b6:	00 00 
  1e36b8:	48 3b bc 24 80 04 00 	cmp    0x480(%rsp),%rdi
  1e36bf:	00 
  1e36c0:	0f 83 a5 29 00 00    	jae    1e606b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5efb>
  1e36c6:	48 8b 84 24 50 05 00 	mov    0x550(%rsp),%rax
  1e36cd:	00 
  1e36ce:	c5 fb 59 0c d8       	vmulsd (%rax,%rbx,8),%xmm0,%xmm1
  1e36d3:	c5 fb 10 94 24 90 01 	vmovsd 0x190(%rsp),%xmm2
  1e36da:	00 00 
  1e36dc:	c5 eb 58 d1          	vaddsd %xmm1,%xmm2,%xmm2
  1e36e0:	c5 fb 11 94 24 90 01 	vmovsd %xmm2,0x190(%rsp)
  1e36e7:	00 00 
  1e36e9:	c5 fb 11 94 24 38 01 	vmovsd %xmm2,0x138(%rsp)
  1e36f0:	00 00 
  1e36f2:	48 3b bc 24 60 04 00 	cmp    0x460(%rsp),%rdi
  1e36f9:	00 
  1e36fa:	0f 83 f3 28 00 00    	jae    1e5ff3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5e83>
  1e3700:	48 8b 84 24 c0 05 00 	mov    0x5c0(%rsp),%rax
  1e3707:	00 
  1e3708:	c5 fb 59 0c d8       	vmulsd (%rax,%rbx,8),%xmm0,%xmm1
  1e370d:	c5 e3 58 d9          	vaddsd %xmm1,%xmm3,%xmm3
  1e3711:	c5 fb 11 9c 24 40 01 	vmovsd %xmm3,0x140(%rsp)
  1e3718:	00 00 
  1e371a:	48 3b bc 24 40 04 00 	cmp    0x440(%rsp),%rdi
  1e3721:	00 
  1e3722:	0f 83 1b 29 00 00    	jae    1e6043 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5ed3>
  1e3728:	48 8b 84 24 a0 05 00 	mov    0x5a0(%rsp),%rax
  1e372f:	00 
  1e3730:	c5 fb 59 04 d8       	vmulsd (%rax,%rbx,8),%xmm0,%xmm0
  1e3735:	c5 db 58 e0          	vaddsd %xmm0,%xmm4,%xmm4
  1e3739:	48 ff c3             	inc    %rbx
  1e373c:	c5 fb 11 a4 24 48 01 	vmovsd %xmm4,0x148(%rsp)
  1e3743:	00 00 
  1e3745:	48 39 9c 24 20 03 00 	cmp    %rbx,0x320(%rsp)
  1e374c:	00 
  1e374d:	0f 85 8d fb ff ff    	jne    1e32e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3170>
  1e3753:	eb 48                	jmp    1e379d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x362d>
  1e3755:	c5 fb 10 84 24 28 01 	vmovsd 0x128(%rsp),%xmm0
  1e375c:	00 00 
  1e375e:	c5 fb 11 84 24 c0 01 	vmovsd %xmm0,0x1c0(%rsp)
  1e3765:	00 00 
  1e3767:	c5 fb 10 84 24 30 01 	vmovsd 0x130(%rsp),%xmm0
  1e376e:	00 00 
  1e3770:	c5 fb 11 84 24 50 01 	vmovsd %xmm0,0x150(%rsp)
  1e3777:	00 00 
  1e3779:	c5 fb 10 84 24 38 01 	vmovsd 0x138(%rsp),%xmm0
  1e3780:	00 00 
  1e3782:	c5 fb 11 84 24 90 01 	vmovsd %xmm0,0x190(%rsp)
  1e3789:	00 00 
  1e378b:	c5 fb 10 9c 24 40 01 	vmovsd 0x140(%rsp),%xmm3
  1e3792:	00 00 
  1e3794:	c5 fb 10 a4 24 48 01 	vmovsd 0x148(%rsp),%xmm4
  1e379b:	00 00 
  1e379d:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1e37a2:	48 8b bc 24 90 02 00 	mov    0x290(%rsp),%rdi
  1e37a9:	00 
  1e37aa:	48 39 f7             	cmp    %rsi,%rdi
  1e37ad:	0f 83 35 2a 00 00    	jae    1e61e8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6078>
  1e37b3:	48 89 f8             	mov    %rdi,%rax
  1e37b6:	48 c1 e0 04          	shl    $0x4,%rax
  1e37ba:	4c 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%r9
  1e37c1:	00 
  1e37c2:	c5 fb 10 44 24 10    	vmovsd 0x10(%rsp),%xmm0
  1e37c8:	c4 c1 7b 11 04 01    	vmovsd %xmm0,(%r9,%rax,1)
  1e37ce:	c5 fb 10 84 24 20 02 	vmovsd 0x220(%rsp),%xmm0
  1e37d5:	00 00 
  1e37d7:	c4 c1 7b 11 44 01 08 	vmovsd %xmm0,0x8(%r9,%rax,1)
  1e37de:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  1e37e3:	4c 39 c7             	cmp    %r8,%rdi
  1e37e6:	48 8b 8c 24 e8 01 00 	mov    0x1e8(%rsp),%rcx
  1e37ed:	00 
  1e37ee:	48 8b 94 24 f0 00 00 	mov    0xf0(%rsp),%rdx
  1e37f5:	00 
  1e37f6:	4c 8b 9c 24 78 01 00 	mov    0x178(%rsp),%r11
  1e37fd:	00 
  1e37fe:	4c 8b 94 24 e8 00 00 	mov    0xe8(%rsp),%r10
  1e3805:	00 
  1e3806:	0f 83 ec 29 00 00    	jae    1e61f8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6088>
  1e380c:	c5 fb 10 84 24 50 01 	vmovsd 0x150(%rsp),%xmm0
  1e3813:	00 00 
  1e3815:	c4 c1 7b 11 04 02    	vmovsd %xmm0,(%r10,%rax,1)
  1e381b:	4c 01 d9             	add    %r11,%rcx
  1e381e:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  1e3822:	c5 fb 10 84 24 90 01 	vmovsd 0x190(%rsp),%xmm0
  1e3829:	00 00 
  1e382b:	c4 c1 7b 11 44 02 08 	vmovsd %xmm0,0x8(%r10,%rax,1)
  1e3832:	48 39 d1             	cmp    %rdx,%rcx
  1e3835:	73 48                	jae    1e387f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x370f>
  1e3837:	48 ff c7             	inc    %rdi
  1e383a:	48 39 f7             	cmp    %rsi,%rdi
  1e383d:	0f 83 48 2a 00 00    	jae    1e628b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x611b>
  1e3843:	48 89 f8             	mov    %rdi,%rax
  1e3846:	48 c1 e0 04          	shl    $0x4,%rax
  1e384a:	c5 fb 10 84 24 00 02 	vmovsd 0x200(%rsp),%xmm0
  1e3851:	00 00 
  1e3853:	c4 c1 7b 11 04 01    	vmovsd %xmm0,(%r9,%rax,1)
  1e3859:	c5 fb 10 84 24 c0 01 	vmovsd 0x1c0(%rsp),%xmm0
  1e3860:	00 00 
  1e3862:	c4 c1 7b 11 44 01 08 	vmovsd %xmm0,0x8(%r9,%rax,1)
  1e3869:	4c 39 c7             	cmp    %r8,%rdi
  1e386c:	0f 83 29 2a 00 00    	jae    1e629b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x612b>
  1e3872:	c4 c1 7b 11 1c 02    	vmovsd %xmm3,(%r10,%rax,1)
  1e3878:	c4 c1 7b 11 64 02 08 	vmovsd %xmm4,0x8(%r10,%rax,1)
  1e387f:	b0 01                	mov    $0x1,%al
  1e3881:	e9 27 02 00 00       	jmp    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e3886:	48 8d 75 04          	lea    0x4(%rbp),%rsi
  1e388a:	48 8d 0d 57 b8 0f 00 	lea    0xfb857(%rip),%rcx        # 2df0e8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf38>
  1e3891:	48 89 ef             	mov    %rbp,%rdi
  1e3894:	48 8b 94 24 88 01 00 	mov    0x188(%rsp),%rdx
  1e389b:	00 
  1e389c:	c5 f8 77             	vzeroupper
  1e389f:	ff 15 bb 68 10 00    	call   *0x1068bb(%rip)        # 2ea160 <_DYNAMIC+0x348>
  1e38a5:	48 8b 84 24 c8 04 00 	mov    0x4c8(%rsp),%rax
  1e38ac:	00 
  1e38ad:	48 3b 44 24 60       	cmp    0x60(%rsp),%rax
  1e38b2:	0f 85 f3 01 00 00    	jne    1e3aab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393b>
  1e38b8:	48 8b 8c 24 78 07 00 	mov    0x778(%rsp),%rcx
  1e38bf:	00 
  1e38c0:	48 ff c1             	inc    %rcx
  1e38c3:	31 c0                	xor    %eax,%eax
  1e38c5:	49 39 ca             	cmp    %rcx,%r10
  1e38c8:	0f 82 df 01 00 00    	jb     1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e38ce:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  1e38d3:	48 39 8c 24 08 05 00 	cmp    %rcx,0x508(%rsp)
  1e38da:	00 
  1e38db:	0f 85 cc 01 00 00    	jne    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e38e1:	48 39 8c 24 00 05 00 	cmp    %rcx,0x500(%rsp)
  1e38e8:	00 
  1e38e9:	0f 85 be 01 00 00    	jne    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e38ef:	48 39 8c 24 f8 04 00 	cmp    %rcx,0x4f8(%rsp)
  1e38f6:	00 
  1e38f7:	0f 85 b0 01 00 00    	jne    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e38fd:	48 39 8c 24 98 02 00 	cmp    %rcx,0x298(%rsp)
  1e3904:	00 
  1e3905:	0f 85 a2 01 00 00    	jne    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e390b:	48 39 8c 24 88 02 00 	cmp    %rcx,0x288(%rsp)
  1e3912:	00 
  1e3913:	0f 85 94 01 00 00    	jne    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e3919:	48 39 8c 24 f0 04 00 	cmp    %rcx,0x4f0(%rsp)
  1e3920:	00 
  1e3921:	0f 85 86 01 00 00    	jne    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e3927:	48 39 8c 24 e8 04 00 	cmp    %rcx,0x4e8(%rsp)
  1e392e:	00 
  1e392f:	0f 85 78 01 00 00    	jne    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e3935:	48 39 8c 24 e0 04 00 	cmp    %rcx,0x4e0(%rsp)
  1e393c:	00 
  1e393d:	0f 85 6a 01 00 00    	jne    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e3943:	48 39 8c 24 d8 04 00 	cmp    %rcx,0x4d8(%rsp)
  1e394a:	00 
  1e394b:	0f 85 5c 01 00 00    	jne    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e3951:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  1e3955:	c5 7d c2 f8 00       	vcmpeqpd %ymm0,%ymm0,%ymm15
  1e395a:	31 c9                	xor    %ecx,%ecx
  1e395c:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
  1e3963:	00 
  1e3964:	48 83 e8 02          	sub    $0x2,%rax
  1e3968:	48 0f 43 c8          	cmovae %rax,%rcx
  1e396c:	b3 01                	mov    $0x1,%bl
  1e396e:	48 89 8c 24 40 03 00 	mov    %rcx,0x340(%rsp)
  1e3975:	00 
  1e3976:	48 39 4c 24 20       	cmp    %rcx,0x20(%rsp)
  1e397b:	0f 83 71 01 00 00    	jae    1e3af2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3982>
  1e3981:	4c 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%r9
  1e3988:	00 
  1e3989:	48 8b 94 24 f8 00 00 	mov    0xf8(%rsp),%rdx
  1e3990:	00 
  1e3991:	49 39 d1             	cmp    %rdx,%r9
  1e3994:	48 89 d3             	mov    %rdx,%rbx
  1e3997:	49 0f 42 d9          	cmovb  %r9,%rbx
  1e399b:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  1e39a0:	48 39 c3             	cmp    %rax,%rbx
  1e39a3:	48 0f 43 d8          	cmovae %rax,%rbx
  1e39a7:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  1e39ac:	48 39 c3             	cmp    %rax,%rbx
  1e39af:	48 0f 43 d8          	cmovae %rax,%rbx
  1e39b3:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
  1e39b8:	4c 39 c3             	cmp    %r8,%rbx
  1e39bb:	49 0f 43 d8          	cmovae %r8,%rbx
  1e39bf:	4c 8b 9c 24 a8 04 00 	mov    0x4a8(%rsp),%r11
  1e39c6:	00 
  1e39c7:	4c 39 db             	cmp    %r11,%rbx
  1e39ca:	49 0f 43 db          	cmovae %r11,%rbx
  1e39ce:	48 8b b4 24 e0 03 00 	mov    0x3e0(%rsp),%rsi
  1e39d5:	00 
  1e39d6:	4c 8b 94 24 88 00 00 	mov    0x88(%rsp),%r10
  1e39dd:	00 
  1e39de:	49 39 f2             	cmp    %rsi,%r10
  1e39e1:	48 89 f0             	mov    %rsi,%rax
  1e39e4:	49 0f 42 c2          	cmovb  %r10,%rax
  1e39e8:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  1e39ef:	00 
  1e39f0:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
  1e39f7:	00 
  1e39f8:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
  1e39ff:	00 
  1e3a00:	4c 39 f9             	cmp    %r15,%rcx
  1e3a03:	4c 0f 42 f9          	cmovb  %rcx,%r15
  1e3a07:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  1e3a0e:	00 
  1e3a0f:	4c 39 f8             	cmp    %r15,%rax
  1e3a12:	4c 0f 42 f8          	cmovb  %rax,%r15
  1e3a16:	48 8b 84 24 58 07 00 	mov    0x758(%rsp),%rax
  1e3a1d:	00 
  1e3a1e:	c6 00 01             	movb   $0x1,(%rax)
  1e3a21:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  1e3a28:	00 
  1e3a29:	4c 39 f8             	cmp    %r15,%rax
  1e3a2c:	4c 0f 42 f8          	cmovb  %rax,%r15
  1e3a30:	4d 39 f9             	cmp    %r15,%r9
  1e3a33:	4d 0f 42 f9          	cmovb  %r9,%r15
  1e3a37:	49 39 d1             	cmp    %rdx,%r9
  1e3a3a:	75 34                	jne    1e3a70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3900>
  1e3a3c:	48 39 54 24 78       	cmp    %rdx,0x78(%rsp)
  1e3a41:	75 2d                	jne    1e3a70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3900>
  1e3a43:	48 39 54 24 70       	cmp    %rdx,0x70(%rsp)
  1e3a48:	75 26                	jne    1e3a70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3900>
  1e3a4a:	48 89 9c 24 a0 02 00 	mov    %rbx,0x2a0(%rsp)
  1e3a51:	00 
  1e3a52:	4c 89 c0             	mov    %r8,%rax
  1e3a55:	4c 31 c8             	xor    %r9,%rax
  1e3a58:	4c 89 d1             	mov    %r10,%rcx
  1e3a5b:	48 31 f1             	xor    %rsi,%rcx
  1e3a5e:	4c 89 da             	mov    %r11,%rdx
  1e3a61:	4c 31 ca             	xor    %r9,%rdx
  1e3a64:	48 09 ca             	or     %rcx,%rdx
  1e3a67:	48 09 c2             	or     %rax,%rdx
  1e3a6a:	0f 84 e2 11 00 00    	je     1e4c52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4ae2>
  1e3a70:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  1e3a77:	00 
  1e3a78:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1e3a7d:	48 39 c6             	cmp    %rax,%rsi
  1e3a80:	0f 83 1d 29 00 00    	jae    1e63a3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6233>
  1e3a86:	48 3b b4 24 90 00 00 	cmp    0x90(%rsp),%rsi
  1e3a8d:	00 
  1e3a8e:	0f 83 2c 29 00 00    	jae    1e63c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6250>
  1e3a94:	48 39 c7             	cmp    %rax,%rdi
  1e3a97:	0f 83 3e 29 00 00    	jae    1e63db <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x626b>
  1e3a9d:	48 3b bc 24 90 00 00 	cmp    0x90(%rsp),%rdi
  1e3aa4:	00 
  1e3aa5:	0f 83 48 29 00 00    	jae    1e63f3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6283>
  1e3aab:	31 c0                	xor    %eax,%eax
  1e3aad:	48 8b 8c 24 98 07 00 	mov    0x798(%rsp),%rcx
  1e3ab4:	00 
  1e3ab5:	88 41 08             	mov    %al,0x8(%rcx)
  1e3ab8:	48 c7 01 ff ff ff ff 	movq   $0xffffffffffffffff,(%rcx)
  1e3abf:	48 81 c4 a8 0a 00 00 	add    $0xaa8,%rsp
  1e3ac6:	5b                   	pop    %rbx
  1e3ac7:	41 5c                	pop    %r12
  1e3ac9:	41 5d                	pop    %r13
  1e3acb:	41 5e                	pop    %r14
  1e3acd:	41 5f                	pop    %r15
  1e3acf:	5d                   	pop    %rbp
  1e3ad0:	c5 f8 77             	vzeroupper
  1e3ad3:	c3                   	ret
  1e3ad4:	48 8d 0d 7d ac 0f 00 	lea    0xfac7d(%rip),%rcx        # 2de758 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x5a8>
  1e3adb:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
  1e3ae2:	00 
  1e3ae3:	48 89 de             	mov    %rbx,%rsi
  1e3ae6:	48 89 fa             	mov    %rdi,%rdx
  1e3ae9:	c5 f8 77             	vzeroupper
  1e3aec:	ff 15 6e 66 10 00    	call   *0x10666e(%rip)        # 2ea160 <_DYNAMIC+0x348>
  1e3af2:	4c 8b 5c 24 58       	mov    0x58(%rsp),%r11
  1e3af7:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
  1e3afe:	00 
  1e3aff:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
  1e3b04:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1e3b09:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
  1e3b10:	00 
  1e3b11:	48 ff c8             	dec    %rax
  1e3b14:	49 b8 fe ff ff ff ff 	movabs $0x3fffffffffffffe,%r8
  1e3b1b:	ff ff 03 
  1e3b1e:	48 39 c6             	cmp    %rax,%rsi
  1e3b21:	0f 83 ff 08 00 00    	jae    1e4426 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x42b6>
  1e3b27:	4c 89 5c 24 10       	mov    %r11,0x10(%rsp)
  1e3b2c:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  1e3b33:	00 
  1e3b34:	4c 21 c1             	and    %r8,%rcx
  1e3b37:	48 c1 e1 05          	shl    $0x5,%rcx
  1e3b3b:	48 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%rbp
  1e3b42:	00 
  1e3b43:	48 01 e9             	add    %rbp,%rcx
  1e3b46:	48 89 8c 24 20 03 00 	mov    %rcx,0x320(%rsp)
  1e3b4d:	00 
  1e3b4e:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
  1e3b55:	00 
  1e3b56:	4c 21 c1             	and    %r8,%rcx
  1e3b59:	48 c1 e1 05          	shl    $0x5,%rcx
  1e3b5d:	48 03 8c 24 98 00 00 	add    0x98(%rsp),%rcx
  1e3b64:	00 
  1e3b65:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  1e3b6c:	00 
  1e3b6d:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
  1e3b74:	00 
  1e3b75:	4c 21 c1             	and    %r8,%rcx
  1e3b78:	48 c1 e1 05          	shl    $0x5,%rcx
  1e3b7c:	48 03 4c 24 68       	add    0x68(%rsp),%rcx
  1e3b81:	48 89 8c 24 a0 02 00 	mov    %rcx,0x2a0(%rsp)
  1e3b88:	00 
  1e3b89:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  1e3b90:	00 
  1e3b91:	4c 21 c1             	and    %r8,%rcx
  1e3b94:	48 c1 e1 05          	shl    $0x5,%rcx
  1e3b98:	48 03 4c 24 38       	add    0x38(%rsp),%rcx
  1e3b9d:	48 89 8c 24 00 04 00 	mov    %rcx,0x400(%rsp)
  1e3ba4:	00 
  1e3ba5:	4d 89 e9             	mov    %r13,%r9
  1e3ba8:	49 c1 e9 03          	shr    $0x3,%r9
  1e3bac:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
  1e3bb3:	00 
  1e3bb4:	48 39 ce             	cmp    %rcx,%rsi
  1e3bb7:	48 0f 47 ce          	cmova  %rsi,%rcx
  1e3bbb:	48 89 8c 24 c0 01 00 	mov    %rcx,0x1c0(%rsp)
  1e3bc2:	00 
  1e3bc3:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  1e3bca:	00 
  1e3bcb:	48 39 ce             	cmp    %rcx,%rsi
  1e3bce:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
  1e3bd3:	48 0f 47 ce          	cmova  %rsi,%rcx
  1e3bd7:	48 89 8c 24 b0 01 00 	mov    %rcx,0x1b0(%rsp)
  1e3bde:	00 
  1e3bdf:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  1e3be6:	00 
  1e3be7:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  1e3bee:	00 
  1e3bef:	48 39 d0             	cmp    %rdx,%rax
  1e3bf2:	48 0f 42 d0          	cmovb  %rax,%rdx
  1e3bf6:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  1e3bfb:	48 39 d0             	cmp    %rdx,%rax
  1e3bfe:	48 0f 42 d0          	cmovb  %rax,%rdx
  1e3c02:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  1e3c07:	48 39 d0             	cmp    %rdx,%rax
  1e3c0a:	48 0f 42 d0          	cmovb  %rax,%rdx
  1e3c0e:	45 89 eb             	mov    %r13d,%r11d
  1e3c11:	41 83 e3 03          	and    $0x3,%r11d
  1e3c15:	4c 21 ac 24 00 01 00 	and    %r13,0x100(%rsp)
  1e3c1c:	00 
  1e3c1d:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  1e3c22:	48 89 c6             	mov    %rax,%rsi
  1e3c25:	4c 21 c6             	and    %r8,%rsi
  1e3c28:	48 39 d0             	cmp    %rdx,%rax
  1e3c2b:	48 0f 42 d0          	cmovb  %rax,%rdx
  1e3c2f:	48 39 d0             	cmp    %rdx,%rax
  1e3c32:	48 0f 42 d0          	cmovb  %rax,%rdx
  1e3c36:	48 39 d0             	cmp    %rdx,%rax
  1e3c39:	48 0f 42 d0          	cmovb  %rax,%rdx
  1e3c3d:	48 8b 8c 24 a8 04 00 	mov    0x4a8(%rsp),%rcx
  1e3c44:	00 
  1e3c45:	48 39 d1             	cmp    %rdx,%rcx
  1e3c48:	48 0f 42 d1          	cmovb  %rcx,%rdx
  1e3c4c:	49 8d 4b ff          	lea    -0x1(%r11),%rcx
  1e3c50:	48 89 8c 24 40 03 00 	mov    %rcx,0x340(%rsp)
  1e3c57:	00 
  1e3c58:	48 39 d0             	cmp    %rdx,%rax
  1e3c5b:	48 0f 42 d0          	cmovb  %rax,%rdx
  1e3c5f:	48 89 94 24 40 02 00 	mov    %rdx,0x240(%rsp)
  1e3c66:	00 
  1e3c67:	48 8b bc 24 e0 03 00 	mov    0x3e0(%rsp),%rdi
  1e3c6e:	00 
  1e3c6f:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  1e3c76:	00 
  1e3c77:	48 39 f8             	cmp    %rdi,%rax
  1e3c7a:	48 0f 43 c7          	cmovae %rdi,%rax
  1e3c7e:	49 39 c3             	cmp    %rax,%r11
  1e3c81:	49 0f 42 c3          	cmovb  %r11,%rax
  1e3c85:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  1e3c8c:	00 
  1e3c8d:	4c 89 8c 24 90 01 00 	mov    %r9,0x190(%rsp)
  1e3c94:	00 
  1e3c95:	49 83 e1 fe          	and    $0xfffffffffffffffe,%r9
  1e3c99:	4c 89 8c 24 00 03 00 	mov    %r9,0x300(%rsp)
  1e3ca0:	00 
  1e3ca1:	48 c1 e6 05          	shl    $0x5,%rsi
  1e3ca5:	48 89 b4 24 60 02 00 	mov    %rsi,0x260(%rsp)
  1e3cac:	00 
  1e3cad:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1e3cb1:	c5 7d 29 f9          	vmovapd %ymm15,%ymm1
  1e3cb5:	4c 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%r15
  1e3cbc:	00 
  1e3cbd:	4c 8b a4 24 e8 00 00 	mov    0xe8(%rsp),%r12
  1e3cc4:	00 
  1e3cc5:	4c 89 9c 24 00 02 00 	mov    %r11,0x200(%rsp)
  1e3ccc:	00 
  1e3ccd:	eb 48                	jmp    1e3d17 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3ba7>
  1e3ccf:	48 c1 e1 04          	shl    $0x4,%rcx
  1e3cd3:	4c 8b a4 24 d0 00 00 	mov    0xd0(%rsp),%r12
  1e3cda:	00 
  1e3cdb:	c4 c1 7b 11 34 0c    	vmovsd %xmm6,(%r12,%rcx,1)
  1e3ce1:	c4 41 7b 11 44 0c 08 	vmovsd %xmm8,0x8(%r12,%rcx,1)
  1e3ce8:	c5 e5 54 c9          	vandpd %ymm1,%ymm3,%ymm1
  1e3cec:	40 20 f3             	and    %sil,%bl
  1e3cef:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  1e3cf4:	48 ff c1             	inc    %rcx
  1e3cf7:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  1e3cfc:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
  1e3d01:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  1e3d06:	48 39 c1             	cmp    %rax,%rcx
  1e3d09:	4c 8b a4 24 e8 00 00 	mov    0xe8(%rsp),%r12
  1e3d10:	00 
  1e3d11:	0f 84 4f 07 00 00    	je     1e4466 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x42f6>
  1e3d17:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  1e3d1c:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
  1e3d21:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1e3d26:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e3d2a:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e3d2e:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1e3d33:	c4 41 31 ef c9       	vpxor  %xmm9,%xmm9,%xmm9
  1e3d38:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1e3d3c:	c5 d1 ef ed          	vpxor  %xmm5,%xmm5,%xmm5
  1e3d40:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
  1e3d44:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  1e3d4b:	00 
  1e3d4c:	48 85 c0             	test   %rax,%rax
  1e3d4f:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
  1e3d56:	00 
  1e3d57:	0f 84 35 01 00 00    	je     1e3e92 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3d22>
  1e3d5d:	48 83 f8 01          	cmp    $0x1,%rax
  1e3d61:	75 07                	jne    1e3d6a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3bfa>
  1e3d63:	31 c9                	xor    %ecx,%ecx
  1e3d65:	e9 cd 00 00 00       	jmp    1e3e37 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3cc7>
  1e3d6a:	be 60 00 00 00       	mov    $0x60,%esi
  1e3d6f:	31 c9                	xor    %ecx,%ecx
  1e3d71:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  1e3d78:	00 
  1e3d79:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
  1e3d7e:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  1e3d83:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
  1e3d88:	48 8b 94 24 00 03 00 	mov    0x300(%rsp),%rdx
  1e3d8f:	00 
  1e3d90:	c4 c1 7d 10 44 32 a0 	vmovupd -0x60(%r10,%rsi,1),%ymm0
  1e3d97:	c4 41 7d 10 5c 32 c0 	vmovupd -0x40(%r10,%rsi,1),%ymm11
  1e3d9e:	c4 41 7d 10 64 32 e0 	vmovupd -0x20(%r10,%rsi,1),%ymm12
  1e3da5:	c4 e2 fd b8 74 35 a0 	vfmadd231pd -0x60(%rbp,%rsi,1),%ymm0,%ymm6
  1e3dac:	c4 e2 fd b8 7c 30 a0 	vfmadd231pd -0x60(%rax,%rsi,1),%ymm0,%ymm7
  1e3db3:	c4 42 fd b8 44 36 a0 	vfmadd231pd -0x60(%r14,%rsi,1),%ymm0,%ymm8
  1e3dba:	c4 42 fd b8 4c 31 a0 	vfmadd231pd -0x60(%r9,%rsi,1),%ymm0,%ymm9
  1e3dc1:	c4 e2 a5 b8 64 35 c0 	vfmadd231pd -0x40(%rbp,%rsi,1),%ymm11,%ymm4
  1e3dc8:	c4 e2 a5 b8 6c 30 c0 	vfmadd231pd -0x40(%rax,%rsi,1),%ymm11,%ymm5
  1e3dcf:	c4 c2 a5 b8 5c 36 c0 	vfmadd231pd -0x40(%r14,%rsi,1),%ymm11,%ymm3
  1e3dd6:	c4 42 a5 b8 54 31 c0 	vfmadd231pd -0x40(%r9,%rsi,1),%ymm11,%ymm10
  1e3ddd:	c4 c1 7d 10 04 32    	vmovupd (%r10,%rsi,1),%ymm0
  1e3de3:	48 83 c1 02          	add    $0x2,%rcx
  1e3de7:	c4 e2 9d b8 74 35 e0 	vfmadd231pd -0x20(%rbp,%rsi,1),%ymm12,%ymm6
  1e3dee:	c4 e2 9d b8 7c 30 e0 	vfmadd231pd -0x20(%rax,%rsi,1),%ymm12,%ymm7
  1e3df5:	c4 42 9d b8 44 36 e0 	vfmadd231pd -0x20(%r14,%rsi,1),%ymm12,%ymm8
  1e3dfc:	c4 42 9d b8 4c 31 e0 	vfmadd231pd -0x20(%r9,%rsi,1),%ymm12,%ymm9
  1e3e03:	c4 e2 fd b8 64 35 00 	vfmadd231pd 0x0(%rbp,%rsi,1),%ymm0,%ymm4
  1e3e0a:	c4 e2 fd b8 2c 30    	vfmadd231pd (%rax,%rsi,1),%ymm0,%ymm5
  1e3e10:	c4 c2 fd b8 1c 36    	vfmadd231pd (%r14,%rsi,1),%ymm0,%ymm3
  1e3e16:	c4 42 fd b8 14 31    	vfmadd231pd (%r9,%rsi,1),%ymm0,%ymm10
  1e3e1c:	48 83 ee 80          	sub    $0xffffffffffffff80,%rsi
  1e3e20:	48 39 ca             	cmp    %rcx,%rdx
  1e3e23:	0f 85 67 ff ff ff    	jne    1e3d90 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3c20>
  1e3e29:	41 f6 c5 08          	test   $0x8,%r13b
  1e3e2d:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
  1e3e34:	00 
  1e3e35:	74 5b                	je     1e3e92 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3d22>
  1e3e37:	48 c1 e1 06          	shl    $0x6,%rcx
  1e3e3b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  1e3e40:	c5 fd 10 04 08       	vmovupd (%rax,%rcx,1),%ymm0
  1e3e45:	c5 7d 10 5c 08 20    	vmovupd 0x20(%rax,%rcx,1),%ymm11
  1e3e4b:	c4 e2 fd b8 74 0d 00 	vfmadd231pd 0x0(%rbp,%rcx,1),%ymm0,%ymm6
  1e3e52:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  1e3e59:	00 
  1e3e5a:	c4 e2 fd b8 3c 08    	vfmadd231pd (%rax,%rcx,1),%ymm0,%ymm7
  1e3e60:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  1e3e65:	c4 62 fd b8 04 0e    	vfmadd231pd (%rsi,%rcx,1),%ymm0,%ymm8
  1e3e6b:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  1e3e70:	c4 42 fd b8 0c 09    	vfmadd231pd (%r9,%rcx,1),%ymm0,%ymm9
  1e3e76:	c4 e2 a5 b8 64 0d 20 	vfmadd231pd 0x20(%rbp,%rcx,1),%ymm11,%ymm4
  1e3e7d:	c4 e2 a5 b8 6c 08 20 	vfmadd231pd 0x20(%rax,%rcx,1),%ymm11,%ymm5
  1e3e84:	c4 e2 a5 b8 5c 0e 20 	vfmadd231pd 0x20(%rsi,%rcx,1),%ymm11,%ymm3
  1e3e8b:	c4 42 a5 b8 54 09 20 	vfmadd231pd 0x20(%r9,%rcx,1),%ymm11,%ymm10
  1e3e92:	41 f6 c5 04          	test   $0x4,%r13b
  1e3e96:	74 52                	je     1e3eea <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3d7a>
  1e3e98:	41 f6 c5 04          	test   $0x4,%r13b
  1e3e9c:	0f 84 ed 24 00 00    	je     1e638f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x621f>
  1e3ea2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  1e3ea7:	48 8b 8c 24 60 02 00 	mov    0x260(%rsp),%rcx
  1e3eae:	00 
  1e3eaf:	48 01 c1             	add    %rax,%rcx
  1e3eb2:	c5 fd 10 01          	vmovupd (%rcx),%ymm0
  1e3eb6:	48 8b 84 24 20 03 00 	mov    0x320(%rsp),%rax
  1e3ebd:	00 
  1e3ebe:	c4 e2 fd b8 30       	vfmadd231pd (%rax),%ymm0,%ymm6
  1e3ec3:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  1e3eca:	00 
  1e3ecb:	c4 e2 fd b8 38       	vfmadd231pd (%rax),%ymm0,%ymm7
  1e3ed0:	48 8b 84 24 a0 02 00 	mov    0x2a0(%rsp),%rax
  1e3ed7:	00 
  1e3ed8:	c4 62 fd b8 00       	vfmadd231pd (%rax),%ymm0,%ymm8
  1e3edd:	48 8b 84 24 00 04 00 	mov    0x400(%rsp),%rax
  1e3ee4:	00 
  1e3ee5:	c4 62 fd b8 08       	vfmadd231pd (%rax),%ymm0,%ymm9
  1e3eea:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  1e3ef1:	00 
  1e3ef2:	4c 8b ac 24 88 00 00 	mov    0x88(%rsp),%r13
  1e3ef9:	00 
  1e3efa:	c4 c1 2d 58 c1       	vaddpd %ymm9,%ymm10,%ymm0
  1e3eff:	c5 bd 58 db          	vaddpd %ymm3,%ymm8,%ymm3
  1e3f03:	c5 d5 58 ef          	vaddpd %ymm7,%ymm5,%ymm5
  1e3f07:	c5 dd 58 e6          	vaddpd %ymm6,%ymm4,%ymm4
  1e3f0b:	c4 e3 7d 19 e6 01    	vextractf128 $0x1,%ymm4,%xmm6
  1e3f11:	c5 d9 58 e6          	vaddpd %xmm6,%xmm4,%xmm4
  1e3f15:	c5 d9 c6 f4 01       	vshufpd $0x1,%xmm4,%xmm4,%xmm6
  1e3f1a:	c5 db 58 e6          	vaddsd %xmm6,%xmm4,%xmm4
  1e3f1e:	c4 e3 7d 19 ee 01    	vextractf128 $0x1,%ymm5,%xmm6
  1e3f24:	c5 d1 58 ee          	vaddpd %xmm6,%xmm5,%xmm5
  1e3f28:	c5 d1 c6 f5 01       	vshufpd $0x1,%xmm5,%xmm5,%xmm6
  1e3f2d:	c5 d3 58 f6          	vaddsd %xmm6,%xmm5,%xmm6
  1e3f31:	c4 e3 7d 19 dd 01    	vextractf128 $0x1,%ymm3,%xmm5
  1e3f37:	c5 e1 58 dd          	vaddpd %xmm5,%xmm3,%xmm3
  1e3f3b:	c5 e1 c6 eb 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm5
  1e3f40:	c5 e3 58 dd          	vaddsd %xmm5,%xmm3,%xmm3
  1e3f44:	c4 e3 7d 19 c5 01    	vextractf128 $0x1,%ymm0,%xmm5
  1e3f4a:	c5 f9 58 c5          	vaddpd %xmm5,%xmm0,%xmm0
  1e3f4e:	c5 f9 c6 e8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm5
  1e3f53:	c5 fb 58 ed          	vaddsd %xmm5,%xmm0,%xmm5
  1e3f57:	4d 85 db             	test   %r11,%r11
  1e3f5a:	0f 84 95 00 00 00    	je     1e3ff5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3e85>
  1e3f60:	3b bc 24 40 03 00 00 	cmp    0x340(%rsp),%edi
  1e3f67:	0f 86 f7 23 00 00    	jbe    1e6364 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x61f4>
  1e3f6d:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
  1e3f72:	c4 c1 7b 10 04 c2    	vmovsd (%r10,%rax,8),%xmm0
  1e3f78:	c4 e2 f9 b9 64 d5 00 	vfmadd231sd 0x0(%rbp,%rdx,8),%xmm0,%xmm4
  1e3f7f:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  1e3f86:	00 
  1e3f87:	c4 e2 f9 b9 34 d1    	vfmadd231sd (%rcx,%rdx,8),%xmm0,%xmm6
  1e3f8d:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  1e3f92:	c4 e2 f9 b9 1c d6    	vfmadd231sd (%rsi,%rdx,8),%xmm0,%xmm3
  1e3f98:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  1e3f9d:	c4 c2 f9 b9 2c d1    	vfmadd231sd (%r9,%rdx,8),%xmm0,%xmm5
  1e3fa3:	41 83 fb 01          	cmp    $0x1,%r11d
  1e3fa7:	74 4c                	je     1e3ff5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3e85>
  1e3fa9:	c4 c1 7b 10 44 c2 08 	vmovsd 0x8(%r10,%rax,8),%xmm0
  1e3fb0:	c4 e2 f9 b9 64 d5 08 	vfmadd231sd 0x8(%rbp,%rdx,8),%xmm0,%xmm4
  1e3fb7:	c4 e2 f9 b9 74 d1 08 	vfmadd231sd 0x8(%rcx,%rdx,8),%xmm0,%xmm6
  1e3fbe:	c4 e2 f9 b9 5c d6 08 	vfmadd231sd 0x8(%rsi,%rdx,8),%xmm0,%xmm3
  1e3fc5:	c4 c2 f9 b9 6c d1 08 	vfmadd231sd 0x8(%r9,%rdx,8),%xmm0,%xmm5
  1e3fcc:	41 83 fb 02          	cmp    $0x2,%r11d
  1e3fd0:	74 23                	je     1e3ff5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3e85>
  1e3fd2:	c4 c1 7b 10 44 c2 10 	vmovsd 0x10(%r10,%rax,8),%xmm0
  1e3fd9:	c4 e2 f9 b9 64 d5 10 	vfmadd231sd 0x10(%rbp,%rdx,8),%xmm0,%xmm4
  1e3fe0:	c4 e2 f9 b9 74 d1 10 	vfmadd231sd 0x10(%rcx,%rdx,8),%xmm0,%xmm6
  1e3fe7:	c4 e2 f9 b9 5c d6 10 	vfmadd231sd 0x10(%rsi,%rdx,8),%xmm0,%xmm3
  1e3fee:	c4 c2 f9 b9 6c d1 10 	vfmadd231sd 0x10(%r9,%rdx,8),%xmm0,%xmm5
  1e3ff5:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  1e3ffa:	48 8d 0c 12          	lea    (%rdx,%rdx,1),%rcx
  1e3ffe:	48 3b 4c 24 18       	cmp    0x18(%rsp),%rcx
  1e4003:	0f 83 2b 23 00 00    	jae    1e6334 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x61c4>
  1e4009:	48 89 cd             	mov    %rcx,%rbp
  1e400c:	48 c1 e5 04          	shl    $0x4,%rbp
  1e4010:	c4 c1 7b 11 24 2c    	vmovsd %xmm4,(%r12,%rbp,1)
  1e4016:	48 8b 84 24 78 01 00 	mov    0x178(%rsp),%rax
  1e401d:	00 
  1e401e:	48 8d 04 50          	lea    (%rax,%rdx,2),%rax
  1e4022:	c4 c1 7b 11 74 2c 08 	vmovsd %xmm6,0x8(%r12,%rbp,1)
  1e4029:	4c 39 f8             	cmp    %r15,%rax
  1e402c:	73 20                	jae    1e404e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3ede>
  1e402e:	48 8d 71 01          	lea    0x1(%rcx),%rsi
  1e4032:	48 3b 74 24 18       	cmp    0x18(%rsp),%rsi
  1e4037:	0f 83 3a 23 00 00    	jae    1e6377 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6207>
  1e403d:	48 c1 e6 04          	shl    $0x4,%rsi
  1e4041:	c4 c1 7b 11 1c 34    	vmovsd %xmm3,(%r12,%rsi,1)
  1e4047:	c4 c1 7b 11 6c 34 08 	vmovsd %xmm5,0x8(%r12,%rsi,1)
  1e404e:	48 3b 94 24 c0 01 00 	cmp    0x1c0(%rsp),%rdx
  1e4055:	00 
  1e4056:	0f 84 98 22 00 00    	je     1e62f4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6184>
  1e405c:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
  1e4063:	00 
  1e4064:	48 3b 94 24 b0 01 00 	cmp    0x1b0(%rsp),%rdx
  1e406b:	00 
  1e406c:	4c 8b a4 24 b0 04 00 	mov    0x4b0(%rsp),%r12
  1e4073:	00 
  1e4074:	0f 84 9a 22 00 00    	je     1e6314 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x61a4>
  1e407a:	48 8b 84 24 c0 04 00 	mov    0x4c0(%rsp),%rax
  1e4081:	00 
  1e4082:	c4 e2 7d 19 2c d0    	vbroadcastsd (%rax,%rdx,8),%ymm5
  1e4088:	48 8b 84 24 b8 04 00 	mov    0x4b8(%rsp),%rax
  1e408f:	00 
  1e4090:	c4 e2 7d 19 24 d0    	vbroadcastsd (%rax,%rdx,8),%ymm4
  1e4096:	48 8b b4 24 40 02 00 	mov    0x240(%rsp),%rsi
  1e409d:	00 
  1e409e:	48 85 f6             	test   %rsi,%rsi
  1e40a1:	0f 84 92 00 00 00    	je     1e4139 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3fc9>
  1e40a7:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  1e40ab:	45 31 ff             	xor    %r15d,%r15d
  1e40ae:	c5 7d 29 fb          	vmovapd %ymm15,%ymm3
  1e40b2:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e40b6:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1e40bb:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e40bf:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  1e40c4:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  1e40c9:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  1e40d0:	00 
  1e40d1:	4c 8b 54 24 50       	mov    0x50(%rsp),%r10
  1e40d6:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
  1e40db:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
  1e40e0:	c4 21 7d 10 0c 38    	vmovupd (%rax,%r15,1),%ymm9
  1e40e6:	c4 82 b5 b8 3c 39    	vfmadd231pd (%r9,%r15,1),%ymm9,%ymm7
  1e40ec:	c4 22 b5 b8 04 3a    	vfmadd231pd (%rdx,%r15,1),%ymm9,%ymm8
  1e40f2:	c4 82 b5 b8 34 3a    	vfmadd231pd (%r10,%r15,1),%ymm9,%ymm6
  1e40f8:	c4 82 b5 b8 04 3e    	vfmadd231pd (%r14,%r15,1),%ymm9,%ymm0
  1e40fe:	c4 01 7d 10 14 3c    	vmovupd (%r12,%r15,1),%ymm10
  1e4104:	c4 62 d5 a8 d4       	vfmadd213pd %ymm4,%ymm5,%ymm10
  1e4109:	c4 02 b5 a8 14 3b    	vfmadd213pd (%r11,%r15,1),%ymm9,%ymm10
  1e410f:	c4 01 7d 11 14 38    	vmovupd %ymm10,(%r8,%r15,1)
  1e4115:	c4 41 2d 54 ce       	vandpd %ymm14,%ymm10,%ymm9
  1e411a:	c5 35 c2 d2 00       	vcmpeqpd %ymm2,%ymm9,%ymm10
  1e411f:	c4 41 35 c2 cd 1d    	vcmpge_oqpd %ymm13,%ymm9,%ymm9
  1e4125:	c4 41 35 56 ca       	vorpd  %ymm10,%ymm9,%ymm9
  1e412a:	c5 b5 54 db          	vandpd %ymm3,%ymm9,%ymm3
  1e412e:	49 83 c7 20          	add    $0x20,%r15
  1e4132:	48 ff ce             	dec    %rsi
  1e4135:	75 a9                	jne    1e40e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3f70>
  1e4137:	eb 15                	jmp    1e414e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3fde>
  1e4139:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e413d:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1e4142:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e4146:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  1e414a:	c5 7d 29 fb          	vmovapd %ymm15,%ymm3
  1e414e:	c4 c3 7d 19 f9 01    	vextractf128 $0x1,%ymm7,%xmm9
  1e4154:	c5 b1 58 ff          	vaddpd %xmm7,%xmm9,%xmm7
  1e4158:	c5 41 c6 cf 01       	vshufpd $0x1,%xmm7,%xmm7,%xmm9
  1e415d:	c5 b3 58 ff          	vaddsd %xmm7,%xmm9,%xmm7
  1e4161:	c4 43 7d 19 c1 01    	vextractf128 $0x1,%ymm8,%xmm9
  1e4167:	c4 41 39 58 c1       	vaddpd %xmm9,%xmm8,%xmm8
  1e416c:	c4 41 39 c6 c8 01    	vshufpd $0x1,%xmm8,%xmm8,%xmm9
  1e4172:	c4 41 3b 58 c9       	vaddsd %xmm9,%xmm8,%xmm9
  1e4177:	c4 c3 7d 19 f0 01    	vextractf128 $0x1,%ymm6,%xmm8
  1e417d:	c5 b9 58 f6          	vaddpd %xmm6,%xmm8,%xmm6
  1e4181:	c5 49 c6 c6 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm8
  1e4186:	c5 bb 58 f6          	vaddsd %xmm6,%xmm8,%xmm6
  1e418a:	c4 c3 7d 19 c0 01    	vextractf128 $0x1,%ymm0,%xmm8
  1e4190:	c5 b9 58 c0          	vaddpd %xmm0,%xmm8,%xmm0
  1e4194:	c5 79 c6 c0 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm8
  1e4199:	c5 3b 58 c0          	vaddsd %xmm0,%xmm8,%xmm8
  1e419d:	4d 85 ed             	test   %r13,%r13
  1e41a0:	0f 84 fc 01 00 00    	je     1e43a2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4232>
  1e41a6:	88 9c 24 50 01 00 00 	mov    %bl,0x150(%rsp)
  1e41ad:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  1e41b4:	00 
  1e41b5:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
  1e41ba:	c4 c1 7b 10 04 c1    	vmovsd (%r9,%rax,8),%xmm0
  1e41c0:	48 8b bc 24 f8 01 00 	mov    0x1f8(%rsp),%rdi
  1e41c7:	00 
  1e41c8:	c5 7b 10 17          	vmovsd (%rdi),%xmm10
  1e41cc:	c4 62 d1 a9 d4       	vfmadd213sd %xmm4,%xmm5,%xmm10
  1e41d1:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
  1e41d6:	c4 42 f9 a9 14 c3    	vfmadd213sd (%r11,%rax,8),%xmm0,%xmm10
  1e41dc:	c4 61 f9 7e d6       	vmovq  %xmm10,%rsi
  1e41e1:	b2 3f                	mov    $0x3f,%dl
  1e41e3:	c4 e2 e8 f5 f6       	bzhi   %rdx,%rsi,%rsi
  1e41e8:	48 ba 00 00 00 00 00 	movabs $0x7ff0000000000000,%rdx
  1e41ef:	00 f0 7f 
  1e41f2:	48 39 d6             	cmp    %rdx,%rsi
  1e41f5:	41 0f 94 c7          	sete   %r15b
  1e41f9:	48 85 f6             	test   %rsi,%rsi
  1e41fc:	41 0f 94 c4          	sete   %r12b
  1e4200:	45 08 fc             	or     %r15b,%r12b
  1e4203:	48 ba 00 00 00 00 00 	movabs $0xfff0000000000000,%rdx
  1e420a:	00 f0 ff 
  1e420d:	48 01 d6             	add    %rdx,%rsi
  1e4210:	48 c1 ee 35          	shr    $0x35,%rsi
  1e4214:	81 fe ff 03 00 00    	cmp    $0x3ff,%esi
  1e421a:	40 0f 92 c6          	setb   %sil
  1e421e:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
  1e4223:	4c 8b b4 24 c8 00 00 	mov    0xc8(%rsp),%r14
  1e422a:	00 
  1e422b:	c4 82 f9 b9 3c f2    	vfmadd231sd (%r10,%r14,8),%xmm0,%xmm7
  1e4231:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  1e4238:	00 
  1e4239:	c4 22 f9 b9 0c f2    	vfmadd231sd (%rdx,%r14,8),%xmm0,%xmm9
  1e423f:	49 89 ff             	mov    %rdi,%r15
  1e4242:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
  1e4247:	c4 a2 f9 b9 34 f3    	vfmadd231sd (%rbx,%r14,8),%xmm0,%xmm6
  1e424d:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  1e4252:	c4 22 f9 b9 04 f7    	vfmadd231sd (%rdi,%r14,8),%xmm0,%xmm8
  1e4258:	44 08 e6             	or     %r12b,%sil
  1e425b:	c4 41 7b 11 14 c0    	vmovsd %xmm10,(%r8,%rax,8)
  1e4261:	41 83 fd 01          	cmp    $0x1,%r13d
  1e4265:	0f 84 25 01 00 00    	je     1e4390 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4220>
  1e426b:	4c 89 4c 24 08       	mov    %r9,0x8(%rsp)
  1e4270:	c4 c1 7b 10 44 c1 08 	vmovsd 0x8(%r9,%rax,8),%xmm0
  1e4277:	c4 41 7b 10 57 08    	vmovsd 0x8(%r15),%xmm10
  1e427d:	c4 62 d1 a9 d4       	vfmadd213sd %xmm4,%xmm5,%xmm10
  1e4282:	c4 42 f9 a9 54 c3 08 	vfmadd213sd 0x8(%r11,%rax,8),%xmm0,%xmm10
  1e4289:	c4 41 f9 7e d7       	vmovq  %xmm10,%r15
  1e428e:	41 b1 3f             	mov    $0x3f,%r9b
  1e4291:	c4 42 b0 f5 ff       	bzhi   %r9,%r15,%r15
  1e4296:	49 b9 00 00 00 00 00 	movabs $0xfff0000000000000,%r9
  1e429d:	00 f0 ff 
  1e42a0:	4f 8d 24 0f          	lea    (%r15,%r9,1),%r12
  1e42a4:	49 c1 ec 35          	shr    $0x35,%r12
  1e42a8:	41 81 fc ff 03 00 00 	cmp    $0x3ff,%r12d
  1e42af:	44 0f b6 e6          	movzbl %sil,%r12d
  1e42b3:	be 00 00 00 00       	mov    $0x0,%esi
  1e42b8:	41 0f 42 f4          	cmovb  %r12d,%esi
  1e42bc:	49 b9 00 00 00 00 00 	movabs $0x7ff0000000000000,%r9
  1e42c3:	00 f0 7f 
  1e42c6:	4d 39 cf             	cmp    %r9,%r15
  1e42c9:	41 0f 44 f4          	cmove  %r12d,%esi
  1e42cd:	4d 85 ff             	test   %r15,%r15
  1e42d0:	41 0f 44 f4          	cmove  %r12d,%esi
  1e42d4:	c4 82 f9 b9 7c f2 08 	vfmadd231sd 0x8(%r10,%r14,8),%xmm0,%xmm7
  1e42db:	c4 22 f9 b9 4c f2 08 	vfmadd231sd 0x8(%rdx,%r14,8),%xmm0,%xmm9
  1e42e2:	c4 a2 f9 b9 74 f3 08 	vfmadd231sd 0x8(%rbx,%r14,8),%xmm0,%xmm6
  1e42e9:	c4 22 f9 b9 44 f7 08 	vfmadd231sd 0x8(%rdi,%r14,8),%xmm0,%xmm8
  1e42f0:	c4 41 7b 11 54 c0 08 	vmovsd %xmm10,0x8(%r8,%rax,8)
  1e42f7:	41 83 fd 02          	cmp    $0x2,%r13d
  1e42fb:	0f 84 8f 00 00 00    	je     1e4390 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4220>
  1e4301:	4c 8b bc 24 f8 01 00 	mov    0x1f8(%rsp),%r15
  1e4308:	00 
  1e4309:	c4 c2 d1 b9 67 10    	vfmadd231sd 0x10(%r15),%xmm5,%xmm4
  1e430f:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
  1e4314:	c4 c1 7b 10 44 c1 10 	vmovsd 0x10(%r9,%rax,8),%xmm0
  1e431b:	c4 c2 f9 a9 64 c3 10 	vfmadd213sd 0x10(%r11,%rax,8),%xmm0,%xmm4
  1e4322:	c4 c1 f9 7e e7       	vmovq  %xmm4,%r15
  1e4327:	41 b1 3f             	mov    $0x3f,%r9b
  1e432a:	c4 42 b0 f5 ff       	bzhi   %r9,%r15,%r15
  1e432f:	49 b9 00 00 00 00 00 	movabs $0xfff0000000000000,%r9
  1e4336:	00 f0 ff 
  1e4339:	4f 8d 24 0f          	lea    (%r15,%r9,1),%r12
  1e433d:	49 c1 ec 35          	shr    $0x35,%r12
  1e4341:	41 81 fc ff 03 00 00 	cmp    $0x3ff,%r12d
  1e4348:	44 0f b6 e6          	movzbl %sil,%r12d
  1e434c:	be 00 00 00 00       	mov    $0x0,%esi
  1e4351:	41 0f 42 f4          	cmovb  %r12d,%esi
  1e4355:	49 b9 00 00 00 00 00 	movabs $0x7ff0000000000000,%r9
  1e435c:	00 f0 7f 
  1e435f:	4d 39 cf             	cmp    %r9,%r15
  1e4362:	41 0f 44 f4          	cmove  %r12d,%esi
  1e4366:	4d 85 ff             	test   %r15,%r15
  1e4369:	41 0f 44 f4          	cmove  %r12d,%esi
  1e436d:	c4 82 f9 b9 7c f2 10 	vfmadd231sd 0x10(%r10,%r14,8),%xmm0,%xmm7
  1e4374:	c4 22 f9 b9 4c f2 10 	vfmadd231sd 0x10(%rdx,%r14,8),%xmm0,%xmm9
  1e437b:	c4 a2 f9 b9 74 f3 10 	vfmadd231sd 0x10(%rbx,%r14,8),%xmm0,%xmm6
  1e4382:	c4 22 f9 b9 44 f7 10 	vfmadd231sd 0x10(%rdi,%r14,8),%xmm0,%xmm8
  1e4389:	c4 c1 7b 11 64 c0 10 	vmovsd %xmm4,0x10(%r8,%rax,8)
  1e4390:	48 8b bc 24 e0 03 00 	mov    0x3e0(%rsp),%rdi
  1e4397:	00 
  1e4398:	0f b6 9c 24 50 01 00 	movzbl 0x150(%rsp),%ebx
  1e439f:	00 
  1e43a0:	eb 03                	jmp    1e43a5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4235>
  1e43a2:	40 b6 01             	mov    $0x1,%sil
  1e43a5:	48 3b 4c 24 28       	cmp    0x28(%rsp),%rcx
  1e43aa:	4c 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%r15
  1e43b1:	00 
  1e43b2:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
  1e43b9:	00 
  1e43ba:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
  1e43bf:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
  1e43c6:	00 
  1e43c7:	4c 8b 9c 24 00 02 00 	mov    0x200(%rsp),%r11
  1e43ce:	00 
  1e43cf:	0f 83 77 1f 00 00    	jae    1e634c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x61dc>
  1e43d5:	4c 8b a4 24 d0 00 00 	mov    0xd0(%rsp),%r12
  1e43dc:	00 
  1e43dd:	c4 c1 7b 11 3c 2c    	vmovsd %xmm7,(%r12,%rbp,1)
  1e43e3:	c4 41 7b 11 4c 2c 08 	vmovsd %xmm9,0x8(%r12,%rbp,1)
  1e43ea:	4c 39 bc 24 20 02 00 	cmp    %r15,0x220(%rsp)
  1e43f1:	00 
  1e43f2:	48 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%rbp
  1e43f9:	00 
  1e43fa:	0f 83 e8 f8 ff ff    	jae    1e3ce8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3b78>
  1e4400:	48 ff c1             	inc    %rcx
  1e4403:	48 3b 4c 24 28       	cmp    0x28(%rsp),%rcx
  1e4408:	0f 82 c1 f8 ff ff    	jb     1e3ccf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3b5f>
  1e440e:	48 8d 15 fb ae 0f 00 	lea    0xfaefb(%rip),%rdx        # 2df310 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1160>
  1e4415:	48 89 cf             	mov    %rcx,%rdi
  1e4418:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1e441d:	c5 f8 77             	vzeroupper
  1e4420:	ff 15 aa 5c 10 00    	call   *0x105caa(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e4426:	88 9c 24 50 01 00 00 	mov    %bl,0x150(%rsp)
  1e442d:	4c 89 e9             	mov    %r13,%rcx
  1e4430:	48 c1 e9 03          	shr    $0x3,%rcx
  1e4434:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1e443b:	00 
  1e443c:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  1e4443:	00 
  1e4444:	4c 8b 9c 24 e0 03 00 	mov    0x3e0(%rsp),%r11
  1e444b:	00 
  1e444c:	4c 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%r15
  1e4453:	00 
  1e4454:	4c 8b a4 24 e8 00 00 	mov    0xe8(%rsp),%r12
  1e445b:	00 
  1e445c:	48 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%rbp
  1e4463:	00 
  1e4464:	eb 29                	jmp    1e448f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x431f>
  1e4466:	88 9c 24 50 01 00 00 	mov    %bl,0x150(%rsp)
  1e446d:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
  1e4474:	00 
  1e4475:	48 39 c9             	cmp    %rcx,%rcx
  1e4478:	48 0f 42 c9          	cmovb  %rcx,%rcx
  1e447c:	c5 7d 28 f9          	vmovapd %ymm1,%ymm15
  1e4480:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
  1e4485:	49 b8 fe ff ff ff ff 	movabs $0x3fffffffffffffe,%r8
  1e448c:	ff ff 03 
  1e448f:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
  1e4494:	4d 21 c1             	and    %r8,%r9
  1e4497:	49 c1 e1 05          	shl    $0x5,%r9
  1e449b:	48 85 c9             	test   %rcx,%rcx
  1e449e:	48 8b 9c 24 98 00 00 	mov    0x98(%rsp),%rbx
  1e44a5:	00 
  1e44a6:	48 89 8c 24 90 01 00 	mov    %rcx,0x190(%rsp)
  1e44ad:	00 
  1e44ae:	74 33                	je     1e44e3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4373>
  1e44b0:	48 83 f9 01          	cmp    $0x1,%rcx
  1e44b4:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
  1e44b9:	75 53                	jne    1e450e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x439e>
  1e44bb:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1e44bf:	31 c0                	xor    %eax,%eax
  1e44c1:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1e44c5:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
  1e44c9:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1e44cd:	c5 d1 ef ed          	vpxor  %xmm5,%xmm5,%xmm5
  1e44d1:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e44d5:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e44d9:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1e44de:	e9 3c 01 00 00       	jmp    1e461f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x44af>
  1e44e3:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1e44e8:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e44ec:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e44f0:	c5 d1 ef ed          	vpxor  %xmm5,%xmm5,%xmm5
  1e44f4:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1e44f8:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
  1e44fc:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1e4500:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1e4504:	4c 8b 74 24 68       	mov    0x68(%rsp),%r14
  1e4509:	e9 7d 01 00 00       	jmp    1e468b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x451b>
  1e450e:	4c 89 9c 24 00 02 00 	mov    %r11,0x200(%rsp)
  1e4515:	00 
  1e4516:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  1e451a:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1e451e:	bf 60 00 00 00       	mov    $0x60,%edi
  1e4523:	31 c0                	xor    %eax,%eax
  1e4525:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  1e4529:	c5 e1 ef db          	vpxor  %xmm3,%xmm3,%xmm3
  1e452d:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1e4531:	c5 d1 ef ed          	vpxor  %xmm5,%xmm5,%xmm5
  1e4535:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e4539:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e453d:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1e4542:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  1e4547:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
  1e454c:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  1e4553:	00 
  1e4554:	4c 8b 5c 24 50       	mov    0x50(%rsp),%r11
  1e4559:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  1e455e:	c4 c1 7d 10 44 38 a0 	vmovupd -0x60(%r8,%rdi,1),%ymm0
  1e4565:	c4 41 7d 10 4c 38 c0 	vmovupd -0x40(%r8,%rdi,1),%ymm9
  1e456c:	c4 41 7d 10 54 38 e0 	vmovupd -0x20(%r8,%rdi,1),%ymm10
  1e4573:	c4 c2 fd b8 7c 3a a0 	vfmadd231pd -0x60(%r10,%rdi,1),%ymm0,%ymm7
  1e457a:	c4 e2 fd b8 74 3a a0 	vfmadd231pd -0x60(%rdx,%rdi,1),%ymm0,%ymm6
  1e4581:	c4 c2 fd b8 6c 3b a0 	vfmadd231pd -0x60(%r11,%rdi,1),%ymm0,%ymm5
  1e4588:	c4 e2 fd b8 64 3e a0 	vfmadd231pd -0x60(%rsi,%rdi,1),%ymm0,%ymm4
  1e458f:	c4 c2 b5 b8 5c 3a c0 	vfmadd231pd -0x40(%r10,%rdi,1),%ymm9,%ymm3
  1e4596:	c4 e2 b5 b8 54 3a c0 	vfmadd231pd -0x40(%rdx,%rdi,1),%ymm9,%ymm2
  1e459d:	c4 c2 b5 b8 4c 3b c0 	vfmadd231pd -0x40(%r11,%rdi,1),%ymm9,%ymm1
  1e45a4:	c4 62 b5 b8 44 3e c0 	vfmadd231pd -0x40(%rsi,%rdi,1),%ymm9,%ymm8
  1e45ab:	c4 c1 7d 10 04 38    	vmovupd (%r8,%rdi,1),%ymm0
  1e45b1:	48 83 c0 02          	add    $0x2,%rax
  1e45b5:	c4 c2 ad b8 7c 3a e0 	vfmadd231pd -0x20(%r10,%rdi,1),%ymm10,%ymm7
  1e45bc:	c4 e2 ad b8 74 3a e0 	vfmadd231pd -0x20(%rdx,%rdi,1),%ymm10,%ymm6
  1e45c3:	c4 c2 ad b8 6c 3b e0 	vfmadd231pd -0x20(%r11,%rdi,1),%ymm10,%ymm5
  1e45ca:	c4 e2 ad b8 64 3e e0 	vfmadd231pd -0x20(%rsi,%rdi,1),%ymm10,%ymm4
  1e45d1:	c4 c2 fd b8 1c 3a    	vfmadd231pd (%r10,%rdi,1),%ymm0,%ymm3
  1e45d7:	c4 e2 fd b8 14 3a    	vfmadd231pd (%rdx,%rdi,1),%ymm0,%ymm2
  1e45dd:	c4 c2 fd b8 0c 3b    	vfmadd231pd (%r11,%rdi,1),%ymm0,%ymm1
  1e45e3:	c4 62 fd b8 04 3e    	vfmadd231pd (%rsi,%rdi,1),%ymm0,%ymm8
  1e45e9:	48 83 ef 80          	sub    $0xffffffffffffff80,%rdi
  1e45ed:	48 39 c1             	cmp    %rax,%rcx
  1e45f0:	0f 85 68 ff ff ff    	jne    1e455e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x43ee>
  1e45f6:	f6 84 24 90 01 00 00 	testb  $0x1,0x190(%rsp)
  1e45fd:	01 
  1e45fe:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
  1e4605:	00 
  1e4606:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
  1e460b:	4c 8b 9c 24 00 02 00 	mov    0x200(%rsp),%r11
  1e4612:	00 
  1e4613:	49 b8 fe ff ff ff ff 	movabs $0x3fffffffffffffe,%r8
  1e461a:	ff ff 03 
  1e461d:	74 6c                	je     1e468b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x451b>
  1e461f:	48 c1 e0 06          	shl    $0x6,%rax
  1e4623:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  1e4628:	c5 fd 10 04 01       	vmovupd (%rcx,%rax,1),%ymm0
  1e462d:	c5 7d 10 4c 01 20    	vmovupd 0x20(%rcx,%rax,1),%ymm9
  1e4633:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  1e4638:	c4 e2 fd b8 3c 01    	vfmadd231pd (%rcx,%rax,1),%ymm0,%ymm7
  1e463e:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  1e4645:	00 
  1e4646:	c4 e2 fd b8 34 02    	vfmadd231pd (%rdx,%rax,1),%ymm0,%ymm6
  1e464c:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  1e4651:	c4 e2 fd b8 2c 07    	vfmadd231pd (%rdi,%rax,1),%ymm0,%ymm5
  1e4657:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  1e465c:	c4 e2 fd b8 24 06    	vfmadd231pd (%rsi,%rax,1),%ymm0,%ymm4
  1e4662:	c4 e2 b5 b8 5c 01 20 	vfmadd231pd 0x20(%rcx,%rax,1),%ymm9,%ymm3
  1e4669:	c4 e2 b5 b8 54 02 20 	vfmadd231pd 0x20(%rdx,%rax,1),%ymm9,%ymm2
  1e4670:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
  1e4677:	00 
  1e4678:	c4 e2 b5 b8 4c 07 20 	vfmadd231pd 0x20(%rdi,%rax,1),%ymm9,%ymm1
  1e467f:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
  1e4684:	c4 62 b5 b8 44 06 20 	vfmadd231pd 0x20(%rsi,%rax,1),%ymm9,%ymm8
  1e468b:	4c 03 4c 24 08       	add    0x8(%rsp),%r9
  1e4690:	41 f6 c5 04          	test   $0x4,%r13b
  1e4694:	75 05                	jne    1e469b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x452b>
  1e4696:	4d 89 ca             	mov    %r9,%r10
  1e4699:	eb 61                	jmp    1e46fc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x458c>
  1e469b:	4c 21 c2             	and    %r8,%rdx
  1e469e:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  1e46a5:	00 
  1e46a6:	4c 21 c0             	and    %r8,%rax
  1e46a9:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  1e46ae:	4c 21 c1             	and    %r8,%rcx
  1e46b1:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  1e46b6:	4c 21 c6             	and    %r8,%rsi
  1e46b9:	48 c1 e2 05          	shl    $0x5,%rdx
  1e46bd:	48 c1 e0 05          	shl    $0x5,%rax
  1e46c1:	48 c1 e1 05          	shl    $0x5,%rcx
  1e46c5:	48 c1 e6 05          	shl    $0x5,%rsi
  1e46c9:	48 03 54 24 40       	add    0x40(%rsp),%rdx
  1e46ce:	48 03 84 24 80 00 00 	add    0x80(%rsp),%rax
  1e46d5:	00 
  1e46d6:	48 03 4c 24 50       	add    0x50(%rsp),%rcx
  1e46db:	48 03 74 24 48       	add    0x48(%rsp),%rsi
  1e46e0:	4d 89 ca             	mov    %r9,%r10
  1e46e3:	c4 c1 7d 10 01       	vmovupd (%r9),%ymm0
  1e46e8:	c4 e2 fd b8 3a       	vfmadd231pd (%rdx),%ymm0,%ymm7
  1e46ed:	c4 e2 fd b8 30       	vfmadd231pd (%rax),%ymm0,%ymm6
  1e46f2:	c4 e2 fd b8 29       	vfmadd231pd (%rcx),%ymm0,%ymm5
  1e46f7:	c4 e2 fd b8 26       	vfmadd231pd (%rsi),%ymm0,%ymm4
  1e46fc:	c5 bd 58 c4          	vaddpd %ymm4,%ymm8,%ymm0
  1e4700:	c5 f5 58 e5          	vaddpd %ymm5,%ymm1,%ymm4
  1e4704:	c5 ed 58 d6          	vaddpd %ymm6,%ymm2,%ymm2
  1e4708:	c5 e5 58 cf          	vaddpd %ymm7,%ymm3,%ymm1
  1e470c:	c4 e3 7d 19 cb 01    	vextractf128 $0x1,%ymm1,%xmm3
  1e4712:	c5 f1 58 cb          	vaddpd %xmm3,%xmm1,%xmm1
  1e4716:	c5 f1 c6 d9 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm3
  1e471b:	c5 f3 58 cb          	vaddsd %xmm3,%xmm1,%xmm1
  1e471f:	c4 e3 7d 19 d3 01    	vextractf128 $0x1,%ymm2,%xmm3
  1e4725:	c5 e9 58 d3          	vaddpd %xmm3,%xmm2,%xmm2
  1e4729:	c5 e9 c6 da 01       	vshufpd $0x1,%xmm2,%xmm2,%xmm3
  1e472e:	c5 eb 58 d3          	vaddsd %xmm3,%xmm2,%xmm2
  1e4732:	c4 e3 7d 19 e3 01    	vextractf128 $0x1,%ymm4,%xmm3
  1e4738:	c5 d9 58 db          	vaddpd %xmm3,%xmm4,%xmm3
  1e473c:	c5 e1 c6 e3 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm4
  1e4741:	c5 e3 58 dc          	vaddsd %xmm4,%xmm3,%xmm3
  1e4745:	c4 e3 7d 19 c4 01    	vextractf128 $0x1,%ymm0,%xmm4
  1e474b:	c5 f9 58 c4          	vaddpd %xmm4,%xmm0,%xmm0
  1e474f:	c5 f9 c6 e0 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm4
  1e4754:	c5 fb 58 e4          	vaddsd %xmm4,%xmm0,%xmm4
  1e4758:	4d 85 db             	test   %r11,%r11
  1e475b:	4c 8b 8c 24 e8 01 00 	mov    0x1e8(%rsp),%r9
  1e4762:	00 
  1e4763:	0f 84 d6 00 00 00    	je     1e483f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x46cf>
  1e4769:	41 8d 43 ff          	lea    -0x1(%r11),%eax
  1e476d:	39 84 24 e0 03 00 00 	cmp    %eax,0x3e0(%rsp)
  1e4774:	0f 86 51 1d 00 00    	jbe    1e64cb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x635b>
  1e477a:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  1e4781:	00 
  1e4782:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  1e4787:	c5 fb 10 04 c1       	vmovsd (%rcx,%rax,8),%xmm0
  1e478c:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  1e4791:	4c 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%r9
  1e4798:	00 
  1e4799:	c4 a2 f9 b9 0c cf    	vfmadd231sd (%rdi,%r9,8),%xmm0,%xmm1
  1e479f:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  1e47a6:	00 
  1e47a7:	c4 a2 f9 b9 14 ca    	vfmadd231sd (%rdx,%r9,8),%xmm0,%xmm2
  1e47ad:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  1e47b2:	c4 82 f9 b9 1c c8    	vfmadd231sd (%r8,%r9,8),%xmm0,%xmm3
  1e47b8:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  1e47bd:	c4 a2 f9 b9 24 ce    	vfmadd231sd (%rsi,%r9,8),%xmm0,%xmm4
  1e47c3:	41 83 fb 01          	cmp    $0x1,%r11d
  1e47c7:	74 5f                	je     1e4828 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x46b8>
  1e47c9:	c5 fb 10 44 c1 08    	vmovsd 0x8(%rcx,%rax,8),%xmm0
  1e47cf:	c4 a2 f9 b9 4c cf 08 	vfmadd231sd 0x8(%rdi,%r9,8),%xmm0,%xmm1
  1e47d6:	c4 a2 f9 b9 54 ca 08 	vfmadd231sd 0x8(%rdx,%r9,8),%xmm0,%xmm2
  1e47dd:	c4 82 f9 b9 5c c8 08 	vfmadd231sd 0x8(%r8,%r9,8),%xmm0,%xmm3
  1e47e4:	c4 a2 f9 b9 64 ce 08 	vfmadd231sd 0x8(%rsi,%r9,8),%xmm0,%xmm4
  1e47eb:	41 83 fb 02          	cmp    $0x2,%r11d
  1e47ef:	74 37                	je     1e4828 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x46b8>
  1e47f1:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  1e47f8:	00 
  1e47f9:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  1e47fe:	c5 fb 10 44 c1 10    	vmovsd 0x10(%rcx,%rax,8),%xmm0
  1e4804:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1e480b:	00 
  1e480c:	c4 e2 f9 b9 4c c7 10 	vfmadd231sd 0x10(%rdi,%rax,8),%xmm0,%xmm1
  1e4813:	c4 e2 f9 b9 54 c2 10 	vfmadd231sd 0x10(%rdx,%rax,8),%xmm0,%xmm2
  1e481a:	c4 c2 f9 b9 5c c0 10 	vfmadd231sd 0x10(%r8,%rax,8),%xmm0,%xmm3
  1e4821:	c4 e2 f9 b9 64 c6 10 	vfmadd231sd 0x10(%rsi,%rax,8),%xmm0,%xmm4
  1e4828:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
  1e482d:	49 b8 fe ff ff ff ff 	movabs $0x3fffffffffffffe,%r8
  1e4834:	ff ff 03 
  1e4837:	4c 8b 8c 24 e8 01 00 	mov    0x1e8(%rsp),%r9
  1e483e:	00 
  1e483f:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
  1e4846:	00 
  1e4847:	48 85 c9             	test   %rcx,%rcx
  1e484a:	74 32                	je     1e487e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x470e>
  1e484c:	48 83 f9 01          	cmp    $0x1,%rcx
  1e4850:	75 56                	jne    1e48a8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4738>
  1e4852:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1e4856:	31 c0                	xor    %eax,%eax
  1e4858:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e485c:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e4860:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1e4865:	c4 41 31 ef c9       	vpxor  %xmm9,%xmm9,%xmm9
  1e486a:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1e486f:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1e4874:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1e4879:	e9 1c 01 00 00       	jmp    1e499a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x482a>
  1e487e:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1e4883:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1e4888:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1e488d:	c4 41 31 ef c9       	vpxor  %xmm9,%xmm9,%xmm9
  1e4892:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1e4897:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e489b:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e489f:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1e48a3:	e9 40 01 00 00       	jmp    1e49e8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4878>
  1e48a8:	48 89 ca             	mov    %rcx,%rdx
  1e48ab:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  1e48af:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1e48b3:	bf 60 00 00 00       	mov    $0x60,%edi
  1e48b8:	31 c0                	xor    %eax,%eax
  1e48ba:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e48be:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e48c2:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1e48c7:	c4 41 31 ef c9       	vpxor  %xmm9,%xmm9,%xmm9
  1e48cc:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1e48d1:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1e48d6:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1e48db:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
  1e48e0:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
  1e48e5:	c4 c1 7d 10 44 39 a0 	vmovupd -0x60(%r9,%rdi,1),%ymm0
  1e48ec:	c4 41 7d 10 6c 39 c0 	vmovupd -0x40(%r9,%rdi,1),%ymm13
  1e48f3:	c4 41 7d 10 74 39 e0 	vmovupd -0x20(%r9,%rdi,1),%ymm14
  1e48fa:	c4 62 fd b8 5c 3d a0 	vfmadd231pd -0x60(%rbp,%rdi,1),%ymm0,%ymm11
  1e4901:	c4 62 fd b8 54 3b a0 	vfmadd231pd -0x60(%rbx,%rdi,1),%ymm0,%ymm10
  1e4908:	c4 42 fd b8 4c 3e a0 	vfmadd231pd -0x60(%r14,%rdi,1),%ymm0,%ymm9
  1e490f:	c4 42 fd b8 44 38 a0 	vfmadd231pd -0x60(%r8,%rdi,1),%ymm0,%ymm8
  1e4916:	c4 e2 95 b8 7c 3d c0 	vfmadd231pd -0x40(%rbp,%rdi,1),%ymm13,%ymm7
  1e491d:	c4 e2 95 b8 74 3b c0 	vfmadd231pd -0x40(%rbx,%rdi,1),%ymm13,%ymm6
  1e4924:	c4 c2 95 b8 6c 3e c0 	vfmadd231pd -0x40(%r14,%rdi,1),%ymm13,%ymm5
  1e492b:	c4 42 95 b8 64 38 c0 	vfmadd231pd -0x40(%r8,%rdi,1),%ymm13,%ymm12
  1e4932:	c4 c1 7d 10 04 39    	vmovupd (%r9,%rdi,1),%ymm0
  1e4938:	48 83 c0 02          	add    $0x2,%rax
  1e493c:	c4 62 8d b8 5c 3d e0 	vfmadd231pd -0x20(%rbp,%rdi,1),%ymm14,%ymm11
  1e4943:	c4 62 8d b8 54 3b e0 	vfmadd231pd -0x20(%rbx,%rdi,1),%ymm14,%ymm10
  1e494a:	c4 42 8d b8 4c 3e e0 	vfmadd231pd -0x20(%r14,%rdi,1),%ymm14,%ymm9
  1e4951:	c4 42 8d b8 44 38 e0 	vfmadd231pd -0x20(%r8,%rdi,1),%ymm14,%ymm8
  1e4958:	c4 e2 fd b8 7c 3d 00 	vfmadd231pd 0x0(%rbp,%rdi,1),%ymm0,%ymm7
  1e495f:	c4 e2 fd b8 34 3b    	vfmadd231pd (%rbx,%rdi,1),%ymm0,%ymm6
  1e4965:	c4 c2 fd b8 2c 3e    	vfmadd231pd (%r14,%rdi,1),%ymm0,%ymm5
  1e496b:	c4 42 fd b8 24 38    	vfmadd231pd (%r8,%rdi,1),%ymm0,%ymm12
  1e4971:	48 83 ef 80          	sub    $0xffffffffffffff80,%rdi
  1e4975:	48 39 c1             	cmp    %rax,%rcx
  1e4978:	0f 85 67 ff ff ff    	jne    1e48e5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4775>
  1e497e:	f6 c2 01             	test   $0x1,%dl
  1e4981:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
  1e4986:	49 b8 fe ff ff ff ff 	movabs $0x3fffffffffffffe,%r8
  1e498d:	ff ff 03 
  1e4990:	4c 8b 8c 24 e8 01 00 	mov    0x1e8(%rsp),%r9
  1e4997:	00 
  1e4998:	74 4e                	je     1e49e8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4878>
  1e499a:	48 c1 e0 06          	shl    $0x6,%rax
  1e499e:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  1e49a3:	c5 fd 10 04 01       	vmovupd (%rcx,%rax,1),%ymm0
  1e49a8:	c5 7d 10 6c 01 20    	vmovupd 0x20(%rcx,%rax,1),%ymm13
  1e49ae:	c4 62 fd b8 5c 05 00 	vfmadd231pd 0x0(%rbp,%rax,1),%ymm0,%ymm11
  1e49b5:	c4 62 fd b8 14 03    	vfmadd231pd (%rbx,%rax,1),%ymm0,%ymm10
  1e49bb:	c4 42 fd b8 0c 06    	vfmadd231pd (%r14,%rax,1),%ymm0,%ymm9
  1e49c1:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  1e49c6:	c4 62 fd b8 04 01    	vfmadd231pd (%rcx,%rax,1),%ymm0,%ymm8
  1e49cc:	c4 e2 95 b8 7c 05 20 	vfmadd231pd 0x20(%rbp,%rax,1),%ymm13,%ymm7
  1e49d3:	c4 e2 95 b8 74 03 20 	vfmadd231pd 0x20(%rbx,%rax,1),%ymm13,%ymm6
  1e49da:	c4 c2 95 b8 6c 06 20 	vfmadd231pd 0x20(%r14,%rax,1),%ymm13,%ymm5
  1e49e1:	c4 62 95 b8 64 01 20 	vfmadd231pd 0x20(%rcx,%rax,1),%ymm13,%ymm12
  1e49e8:	41 f6 c5 04          	test   $0x4,%r13b
  1e49ec:	74 66                	je     1e4a54 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x48e4>
  1e49ee:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  1e49f5:	00 
  1e49f6:	4c 21 c0             	and    %r8,%rax
  1e49f9:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
  1e4a00:	00 
  1e4a01:	4c 21 c1             	and    %r8,%rcx
  1e4a04:	48 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%rdi
  1e4a0b:	00 
  1e4a0c:	4c 21 c7             	and    %r8,%rdi
  1e4a0f:	4c 89 c2             	mov    %r8,%rdx
  1e4a12:	4c 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%r8
  1e4a19:	00 
  1e4a1a:	49 21 d0             	and    %rdx,%r8
  1e4a1d:	48 c1 e0 05          	shl    $0x5,%rax
  1e4a21:	48 c1 e1 05          	shl    $0x5,%rcx
  1e4a25:	48 c1 e7 05          	shl    $0x5,%rdi
  1e4a29:	49 c1 e0 05          	shl    $0x5,%r8
  1e4a2d:	48 01 e8             	add    %rbp,%rax
  1e4a30:	48 01 d9             	add    %rbx,%rcx
  1e4a33:	4c 01 f7             	add    %r14,%rdi
  1e4a36:	4c 03 44 24 38       	add    0x38(%rsp),%r8
  1e4a3b:	c4 c1 7d 10 02       	vmovupd (%r10),%ymm0
  1e4a40:	c4 62 fd b8 18       	vfmadd231pd (%rax),%ymm0,%ymm11
  1e4a45:	c4 62 fd b8 11       	vfmadd231pd (%rcx),%ymm0,%ymm10
  1e4a4a:	c4 62 fd b8 0f       	vfmadd231pd (%rdi),%ymm0,%ymm9
  1e4a4f:	c4 42 fd b8 00       	vfmadd231pd (%r8),%ymm0,%ymm8
  1e4a54:	c4 c1 1d 58 c0       	vaddpd %ymm8,%ymm12,%ymm0
  1e4a59:	c5 b5 58 ed          	vaddpd %ymm5,%ymm9,%ymm5
  1e4a5d:	c5 ad 58 f6          	vaddpd %ymm6,%ymm10,%ymm6
  1e4a61:	c5 a5 58 ff          	vaddpd %ymm7,%ymm11,%ymm7
  1e4a65:	c4 c3 7d 19 f8 01    	vextractf128 $0x1,%ymm7,%xmm8
  1e4a6b:	c5 b9 58 ff          	vaddpd %xmm7,%xmm8,%xmm7
  1e4a6f:	c5 41 c6 c7 01       	vshufpd $0x1,%xmm7,%xmm7,%xmm8
  1e4a74:	c5 bb 58 ff          	vaddsd %xmm7,%xmm8,%xmm7
  1e4a78:	c4 c3 7d 19 f0 01    	vextractf128 $0x1,%ymm6,%xmm8
  1e4a7e:	c5 b9 58 f6          	vaddpd %xmm6,%xmm8,%xmm6
  1e4a82:	c5 49 c6 c6 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm8
  1e4a87:	c5 3b 58 c6          	vaddsd %xmm6,%xmm8,%xmm8
  1e4a8b:	c4 e3 7d 19 ee 01    	vextractf128 $0x1,%ymm5,%xmm6
  1e4a91:	c5 d1 58 ee          	vaddpd %xmm6,%xmm5,%xmm5
  1e4a95:	c5 d1 c6 f5 01       	vshufpd $0x1,%xmm5,%xmm5,%xmm6
  1e4a9a:	c5 d3 58 ee          	vaddsd %xmm6,%xmm5,%xmm5
  1e4a9e:	c4 e3 7d 19 c6 01    	vextractf128 $0x1,%ymm0,%xmm6
  1e4aa4:	c5 f9 58 c6          	vaddpd %xmm6,%xmm0,%xmm0
  1e4aa8:	c5 f9 c6 f0 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm6
  1e4aad:	c5 fb 58 f6          	vaddsd %xmm6,%xmm0,%xmm6
  1e4ab1:	4d 85 db             	test   %r11,%r11
  1e4ab4:	0f 84 9c 00 00 00    	je     1e4b56 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x49e6>
  1e4aba:	41 8d 43 ff          	lea    -0x1(%r11),%eax
  1e4abe:	48 8b bc 24 e0 03 00 	mov    0x3e0(%rsp),%rdi
  1e4ac5:	00 
  1e4ac6:	39 c7                	cmp    %eax,%edi
  1e4ac8:	0f 86 96 18 00 00    	jbe    1e6364 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x61f4>
  1e4ace:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  1e4ad5:	00 
  1e4ad6:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  1e4adb:	c5 fb 10 04 c7       	vmovsd (%rdi,%rax,8),%xmm0
  1e4ae0:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
  1e4ae7:	00 
  1e4ae8:	c4 e2 f9 b9 7c d5 00 	vfmadd231sd 0x0(%rbp,%rdx,8),%xmm0,%xmm7
  1e4aef:	c4 62 f9 b9 04 d3    	vfmadd231sd (%rbx,%rdx,8),%xmm0,%xmm8
  1e4af5:	c4 c2 f9 b9 2c d6    	vfmadd231sd (%r14,%rdx,8),%xmm0,%xmm5
  1e4afb:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  1e4b00:	c4 e2 f9 b9 34 d1    	vfmadd231sd (%rcx,%rdx,8),%xmm0,%xmm6
  1e4b06:	41 83 fb 01          	cmp    $0x1,%r11d
  1e4b0a:	74 4a                	je     1e4b56 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x49e6>
  1e4b0c:	c5 fb 10 44 c7 08    	vmovsd 0x8(%rdi,%rax,8),%xmm0
  1e4b12:	c4 e2 f9 b9 7c d5 08 	vfmadd231sd 0x8(%rbp,%rdx,8),%xmm0,%xmm7
  1e4b19:	c4 62 f9 b9 44 d3 08 	vfmadd231sd 0x8(%rbx,%rdx,8),%xmm0,%xmm8
  1e4b20:	c4 c2 f9 b9 6c d6 08 	vfmadd231sd 0x8(%r14,%rdx,8),%xmm0,%xmm5
  1e4b27:	c4 e2 f9 b9 74 d1 08 	vfmadd231sd 0x8(%rcx,%rdx,8),%xmm0,%xmm6
  1e4b2e:	41 83 fb 02          	cmp    $0x2,%r11d
  1e4b32:	74 22                	je     1e4b56 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x49e6>
  1e4b34:	c5 fb 10 44 c7 10    	vmovsd 0x10(%rdi,%rax,8),%xmm0
  1e4b3a:	c4 e2 f9 b9 7c d5 10 	vfmadd231sd 0x10(%rbp,%rdx,8),%xmm0,%xmm7
  1e4b41:	c4 62 f9 b9 44 d3 10 	vfmadd231sd 0x10(%rbx,%rdx,8),%xmm0,%xmm8
  1e4b48:	c4 c2 f9 b9 6c d6 10 	vfmadd231sd 0x10(%r14,%rdx,8),%xmm0,%xmm5
  1e4b4f:	c4 e2 f9 b9 74 d1 10 	vfmadd231sd 0x10(%rcx,%rdx,8),%xmm0,%xmm6
  1e4b56:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1e4b5b:	49 8d 79 fe          	lea    -0x2(%r9),%rdi
  1e4b5f:	48 39 f7             	cmp    %rsi,%rdi
  1e4b62:	0f b6 94 24 50 01 00 	movzbl 0x150(%rsp),%edx
  1e4b69:	00 
  1e4b6a:	0f 83 9b 18 00 00    	jae    1e640b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x629b>
  1e4b70:	48 89 f8             	mov    %rdi,%rax
  1e4b73:	48 c1 e0 04          	shl    $0x4,%rax
  1e4b77:	c4 c1 7b 11 3c 04    	vmovsd %xmm7,(%r12,%rax,1)
  1e4b7d:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
  1e4b84:	00 
  1e4b85:	4c 01 c9             	add    %r9,%rcx
  1e4b88:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  1e4b8c:	c4 41 7b 11 44 04 08 	vmovsd %xmm8,0x8(%r12,%rax,1)
  1e4b93:	4c 39 f9             	cmp    %r15,%rcx
  1e4b96:	73 57                	jae    1e4bef <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4a7f>
  1e4b98:	49 ff c9             	dec    %r9
  1e4b9b:	49 39 f1             	cmp    %rsi,%r9
  1e4b9e:	0f 83 d1 18 00 00    	jae    1e6475 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6305>
  1e4ba4:	4c 89 c9             	mov    %r9,%rcx
  1e4ba7:	48 c1 e1 04          	shl    $0x4,%rcx
  1e4bab:	c4 c1 7b 11 2c 0c    	vmovsd %xmm5,(%r12,%rcx,1)
  1e4bb1:	c4 c1 7b 11 74 0c 08 	vmovsd %xmm6,0x8(%r12,%rcx,1)
  1e4bb8:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1e4bbd:	48 39 f7             	cmp    %rsi,%rdi
  1e4bc0:	0f 83 45 18 00 00    	jae    1e640b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x629b>
  1e4bc6:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  1e4bcd:	00 
  1e4bce:	c5 fb 11 0c 01       	vmovsd %xmm1,(%rcx,%rax,1)
  1e4bd3:	c5 fb 11 54 01 08    	vmovsd %xmm2,0x8(%rcx,%rax,1)
  1e4bd9:	49 39 f1             	cmp    %rsi,%r9
  1e4bdc:	0f 83 93 18 00 00    	jae    1e6475 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6305>
  1e4be2:	4c 89 cf             	mov    %r9,%rdi
  1e4be5:	c5 f9 28 cb          	vmovapd %xmm3,%xmm1
  1e4be9:	c5 f9 28 d4          	vmovapd %xmm4,%xmm2
  1e4bed:	eb 16                	jmp    1e4c05 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4a95>
  1e4bef:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1e4bf4:	48 39 f7             	cmp    %rsi,%rdi
  1e4bf7:	0f 83 0e 18 00 00    	jae    1e640b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x629b>
  1e4bfd:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  1e4c04:	00 
  1e4c05:	48 c1 e7 04          	shl    $0x4,%rdi
  1e4c09:	c5 fb 11 0c 39       	vmovsd %xmm1,(%rcx,%rdi,1)
  1e4c0e:	c5 fb 11 54 39 08    	vmovsd %xmm2,0x8(%rcx,%rdi,1)
  1e4c14:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  1e4c18:	c4 c2 7d 37 c7       	vpcmpgtq %ymm15,%ymm0,%ymm0
  1e4c1d:	c4 e2 7d 59 0d 82 15 	vpbroadcastq -0x1bea7e(%rip),%ymm1        # 261a8 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x4d8>
  1e4c24:	e4 ff 
  1e4c26:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
  1e4c2a:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
  1e4c30:	c5 f9 5d c1          	vminpd %xmm1,%xmm0,%xmm0
  1e4c34:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e4c39:	c5 fb 5d c1          	vminsd %xmm1,%xmm0,%xmm0
  1e4c3d:	31 c9                	xor    %ecx,%ecx
  1e4c3f:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1e4c43:	c5 f9 2e c1          	vucomisd %xmm1,%xmm0
  1e4c47:	0f b6 c2             	movzbl %dl,%eax
  1e4c4a:	0f 46 c1             	cmovbe %ecx,%eax
  1e4c4d:	e9 5b ee ff ff       	jmp    1e3aad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393d>
  1e4c52:	48 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%rcx
  1e4c59:	00 
  1e4c5a:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1e4c61:	00 
  1e4c62:	48 8d 14 c1          	lea    (%rcx,%rax,8),%rdx
  1e4c66:	48 89 94 24 80 04 00 	mov    %rdx,0x480(%rsp)
  1e4c6d:	00 
  1e4c6e:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
  1e4c75:	00 
  1e4c76:	48 8d 34 c2          	lea    (%rdx,%rax,8),%rsi
  1e4c7a:	48 89 b4 24 70 05 00 	mov    %rsi,0x570(%rsp)
  1e4c81:	00 
  1e4c82:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  1e4c87:	48 8d 3c c6          	lea    (%rsi,%rax,8),%rdi
  1e4c8b:	48 89 bc 24 60 04 00 	mov    %rdi,0x460(%rsp)
  1e4c92:	00 
  1e4c93:	49 8d 7a ff          	lea    -0x1(%r10),%rdi
  1e4c97:	4c 39 d7             	cmp    %r10,%rdi
  1e4c9a:	48 89 bc 24 10 05 00 	mov    %rdi,0x510(%rsp)
  1e4ca1:	00 
  1e4ca2:	4c 0f 42 d7          	cmovb  %rdi,%r10
  1e4ca6:	4c 89 94 24 c0 02 00 	mov    %r10,0x2c0(%rsp)
  1e4cad:	00 
  1e4cae:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  1e4cb3:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
  1e4cb7:	48 89 84 24 30 05 00 	mov    %rax,0x530(%rsp)
  1e4cbe:	00 
  1e4cbf:	4c 89 c8             	mov    %r9,%rax
  1e4cc2:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
  1e4cc6:	48 89 84 24 00 04 00 	mov    %rax,0x400(%rsp)
  1e4ccd:	00 
  1e4cce:	4c 89 bc 24 c0 00 00 	mov    %r15,0xc0(%rsp)
  1e4cd5:	00 
  1e4cd6:	49 83 e7 fe          	and    $0xfffffffffffffffe,%r15
  1e4cda:	4c 89 bc 24 40 04 00 	mov    %r15,0x440(%rsp)
  1e4ce1:	00 
  1e4ce2:	48 8b 84 24 88 02 00 	mov    0x288(%rsp),%rax
  1e4ce9:	00 
  1e4cea:	83 e0 02             	and    $0x2,%eax
  1e4ced:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
  1e4cf4:	00 
  1e4cf5:	b0 3a                	mov    $0x3a,%al
  1e4cf7:	c4 c2 f8 f5 c0       	bzhi   %rax,%r8,%rax
  1e4cfc:	48 c1 e0 05          	shl    $0x5,%rax
  1e4d00:	4c 8d 40 08          	lea    0x8(%rax),%r8
  1e4d04:	4c 89 84 24 50 05 00 	mov    %r8,0x550(%rsp)
  1e4d0b:	00 
  1e4d0c:	48 01 c1             	add    %rax,%rcx
  1e4d0f:	48 83 c1 08          	add    $0x8,%rcx
  1e4d13:	48 89 8c 24 00 03 00 	mov    %rcx,0x300(%rsp)
  1e4d1a:	00 
  1e4d1b:	48 8d 6c 02 08       	lea    0x8(%rdx,%rax,1),%rbp
  1e4d20:	4c 8d 64 06 08       	lea    0x8(%rsi,%rax,1),%r12
  1e4d25:	4c 8d 54 07 08       	lea    0x8(%rdi,%rax,1),%r10
  1e4d2a:	b3 01                	mov    $0x1,%bl
  1e4d2c:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
  1e4d33:	00 
  1e4d34:	4c 89 ca             	mov    %r9,%rdx
  1e4d37:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1e4d3c:	c5 7d 11 bc 24 e0 02 	vmovupd %ymm15,0x2e0(%rsp)
  1e4d43:	00 00 
  1e4d45:	eb 3f                	jmp    1e4d86 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4c16>
  1e4d47:	48 c1 e0 04          	shl    $0x4,%rax
  1e4d4b:	48 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%rcx
  1e4d52:	00 
  1e4d53:	c5 fb 11 1c 01       	vmovsd %xmm3,(%rcx,%rax,1)
  1e4d58:	c5 fb 11 6c 01 08    	vmovsd %xmm5,0x8(%rcx,%rax,1)
  1e4d5e:	22 9c 24 c0 01 00 00 	and    0x1c0(%rsp),%bl
  1e4d65:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1e4d6a:	48 83 c6 02          	add    $0x2,%rsi
  1e4d6e:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
  1e4d73:	4c 89 5c 24 58       	mov    %r11,0x58(%rsp)
  1e4d78:	48 3b b4 24 40 03 00 	cmp    0x340(%rsp),%rsi
  1e4d7f:	00 
  1e4d80:	0f 83 83 ed ff ff    	jae    1e3b09 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x3999>
  1e4d86:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  1e4d8b:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
  1e4d90:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  1e4d97:	00 
  1e4d98:	48 39 c6             	cmp    %rax,%rsi
  1e4d9b:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
  1e4da0:	0f 83 fd 15 00 00    	jae    1e63a3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6233>
  1e4da6:	48 3b b4 24 90 00 00 	cmp    0x90(%rsp),%rsi
  1e4dad:	00 
  1e4dae:	4c 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%r9
  1e4db5:	00 
  1e4db6:	4c 8b 84 24 a0 02 00 	mov    0x2a0(%rsp),%r8
  1e4dbd:	00 
  1e4dbe:	0f 83 fc 15 00 00    	jae    1e63c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6250>
  1e4dc4:	48 8d 7e 01          	lea    0x1(%rsi),%rdi
  1e4dc8:	48 39 c7             	cmp    %rax,%rdi
  1e4dcb:	0f 83 0a 16 00 00    	jae    1e63db <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x626b>
  1e4dd1:	48 3b bc 24 90 00 00 	cmp    0x90(%rsp),%rdi
  1e4dd8:	00 
  1e4dd9:	0f 83 14 16 00 00    	jae    1e63f3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6283>
  1e4ddf:	48 39 54 24 30       	cmp    %rdx,0x30(%rsp)
  1e4de4:	0f 85 c1 ec ff ff    	jne    1e3aab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393b>
  1e4dea:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  1e4def:	48 8b 84 24 c0 04 00 	mov    0x4c0(%rsp),%rax
  1e4df6:	00 
  1e4df7:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  1e4dfc:	c5 fb 10 04 d0       	vmovsd (%rax,%rdx,8),%xmm0
  1e4e01:	48 8b 8c 24 b8 04 00 	mov    0x4b8(%rsp),%rcx
  1e4e08:	00 
  1e4e09:	c5 fb 10 14 d1       	vmovsd (%rcx,%rdx,8),%xmm2
  1e4e0e:	c5 fb 10 4c d0 08    	vmovsd 0x8(%rax,%rdx,8),%xmm1
  1e4e14:	c5 fb 10 5c d1 08    	vmovsd 0x8(%rcx,%rdx,8),%xmm3
  1e4e1a:	4d 85 c0             	test   %r8,%r8
  1e4e1d:	c5 f9 29 84 24 20 03 	vmovapd %xmm0,0x320(%rsp)
  1e4e24:	00 00 
  1e4e26:	c5 f9 29 8c 24 50 01 	vmovapd %xmm1,0x150(%rsp)
  1e4e2d:	00 00 
  1e4e2f:	c5 f9 29 9c 24 b0 01 	vmovapd %xmm3,0x1b0(%rsp)
  1e4e36:	00 00 
  1e4e38:	c5 f9 29 94 24 40 02 	vmovapd %xmm2,0x240(%rsp)
  1e4e3f:	00 00 
  1e4e41:	0f 84 dc 00 00 00    	je     1e4f23 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4db3>
  1e4e47:	c4 62 7d 19 f8       	vbroadcastsd %xmm0,%ymm15
  1e4e4c:	c4 e2 7d 19 d2       	vbroadcastsd %xmm2,%ymm2
  1e4e51:	c4 e2 7d 19 c1       	vbroadcastsd %xmm1,%ymm0
  1e4e56:	c4 62 7d 19 eb       	vbroadcastsd %xmm3,%ymm13
  1e4e5b:	c5 d1 ef ed          	vpxor  %xmm5,%xmm5,%xmm5
  1e4e5f:	4c 89 c0             	mov    %r8,%rax
  1e4e62:	31 c9                	xor    %ecx,%ecx
  1e4e64:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1e4e68:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e4e6c:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1e4e70:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1e4e75:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e4e79:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1e4e7e:	c4 41 31 ef c9       	vpxor  %xmm9,%xmm9,%xmm9
  1e4e83:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  1e4e88:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  1e4e8d:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  1e4e92:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
  1e4e97:	4c 8b 9c 24 b0 04 00 	mov    0x4b0(%rsp),%r11
  1e4e9e:	00 
  1e4e9f:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
  1e4ea4:	4c 8b 6c 24 10       	mov    0x10(%rsp),%r13
  1e4ea9:	c4 41 7d 10 74 0d 00 	vmovupd 0x0(%r13,%rcx,1),%ymm14
  1e4eb0:	c5 7d 10 24 0f       	vmovupd (%rdi,%rcx,1),%ymm12
  1e4eb5:	c4 42 9d b8 ce       	vfmadd231pd %ymm14,%ymm12,%ymm9
  1e4eba:	c4 c1 7d 10 0c 0b    	vmovupd (%r11,%rcx,1),%ymm1
  1e4ec0:	c5 7d 28 d9          	vmovapd %ymm1,%ymm11
  1e4ec4:	c4 62 85 a8 da       	vfmadd213pd %ymm2,%ymm15,%ymm11
  1e4ec9:	c4 62 8d a8 1c 0e    	vfmadd213pd (%rsi,%rcx,1),%ymm14,%ymm11
  1e4ecf:	c4 c2 a5 b8 e4       	vfmadd231pd %ymm12,%ymm11,%ymm4
  1e4ed4:	c4 41 7d 10 24 0f    	vmovupd (%r15,%rcx,1),%ymm12
  1e4eda:	c4 42 9d b8 d6       	vfmadd231pd %ymm14,%ymm12,%ymm10
  1e4edf:	c4 c2 a5 b8 f4       	vfmadd231pd %ymm12,%ymm11,%ymm6
  1e4ee4:	c5 7d 10 24 0a       	vmovupd (%rdx,%rcx,1),%ymm12
  1e4ee9:	c4 c2 9d b8 fe       	vfmadd231pd %ymm14,%ymm12,%ymm7
  1e4eee:	c4 c2 a5 b8 dc       	vfmadd231pd %ymm12,%ymm11,%ymm3
  1e4ef3:	c4 41 7d 10 24 08    	vmovupd (%r8,%rcx,1),%ymm12
  1e4ef9:	c4 42 9d b8 c6       	vfmadd231pd %ymm14,%ymm12,%ymm8
  1e4efe:	c4 c2 a5 b8 ec       	vfmadd231pd %ymm12,%ymm11,%ymm5
  1e4f03:	c4 c2 fd a8 cd       	vfmadd213pd %ymm13,%ymm0,%ymm1
  1e4f08:	c4 c2 a5 a8 ce       	vfmadd213pd %ymm14,%ymm11,%ymm1
  1e4f0d:	c4 41 7d 11 1c 0e    	vmovupd %ymm11,(%r14,%rcx,1)
  1e4f13:	c5 fd 11 0c 0e       	vmovupd %ymm1,(%rsi,%rcx,1)
  1e4f18:	48 83 c1 20          	add    $0x20,%rcx
  1e4f1c:	48 ff c8             	dec    %rax
  1e4f1f:	75 88                	jne    1e4ea9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4d39>
  1e4f21:	eb 32                	jmp    1e4f55 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4de5>
  1e4f23:	c4 41 31 ef c9       	vpxor  %xmm9,%xmm9,%xmm9
  1e4f28:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  1e4f2d:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e4f31:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1e4f36:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1e4f3a:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e4f3e:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1e4f42:	c5 d1 ef ed          	vpxor  %xmm5,%xmm5,%xmm5
  1e4f46:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  1e4f4b:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
  1e4f50:	4c 8b 6c 24 10       	mov    0x10(%rsp),%r13
  1e4f55:	4a 8d 04 ce          	lea    (%rsi,%r9,8),%rax
  1e4f59:	4a 8d 0c cd 00 00 00 	lea    0x0(,%r9,8),%rcx
  1e4f60:	00 
  1e4f61:	4c 01 e9             	add    %r13,%rcx
  1e4f64:	48 89 8c 24 00 02 00 	mov    %rcx,0x200(%rsp)
  1e4f6b:	00 
  1e4f6c:	4b 8d 0c ce          	lea    (%r14,%r9,8),%rcx
  1e4f70:	48 89 8c 24 20 02 00 	mov    %rcx,0x220(%rsp)
  1e4f77:	00 
  1e4f78:	c4 63 7d 19 c8 01    	vextractf128 $0x1,%ymm9,%xmm0
  1e4f7e:	c5 b1 58 c0          	vaddpd %xmm0,%xmm9,%xmm0
  1e4f82:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e4f87:	c5 7b 58 c9          	vaddsd %xmm1,%xmm0,%xmm9
  1e4f8b:	c4 63 7d 19 d0 01    	vextractf128 $0x1,%ymm10,%xmm0
  1e4f91:	c5 a9 58 c0          	vaddpd %xmm0,%xmm10,%xmm0
  1e4f95:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e4f9a:	c5 7b 58 d1          	vaddsd %xmm1,%xmm0,%xmm10
  1e4f9e:	c4 e3 7d 19 f8 01    	vextractf128 $0x1,%ymm7,%xmm0
  1e4fa4:	c5 c1 58 c0          	vaddpd %xmm0,%xmm7,%xmm0
  1e4fa8:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e4fad:	c5 fb 58 f9          	vaddsd %xmm1,%xmm0,%xmm7
  1e4fb1:	c4 63 7d 19 c0 01    	vextractf128 $0x1,%ymm8,%xmm0
  1e4fb7:	c5 b9 58 c0          	vaddpd %xmm0,%xmm8,%xmm0
  1e4fbb:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e4fc0:	c5 7b 58 c1          	vaddsd %xmm1,%xmm0,%xmm8
  1e4fc4:	c4 e3 7d 19 e0 01    	vextractf128 $0x1,%ymm4,%xmm0
  1e4fca:	c5 d9 58 c0          	vaddpd %xmm0,%xmm4,%xmm0
  1e4fce:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e4fd3:	c5 fb 58 e1          	vaddsd %xmm1,%xmm0,%xmm4
  1e4fd7:	c4 e3 7d 19 f0 01    	vextractf128 $0x1,%ymm6,%xmm0
  1e4fdd:	c5 c9 58 c0          	vaddpd %xmm0,%xmm6,%xmm0
  1e4fe1:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e4fe6:	c5 fb 58 f1          	vaddsd %xmm1,%xmm0,%xmm6
  1e4fea:	c4 e3 7d 19 d8 01    	vextractf128 $0x1,%ymm3,%xmm0
  1e4ff0:	c5 e1 58 c0          	vaddpd %xmm0,%xmm3,%xmm0
  1e4ff4:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e4ff9:	c5 fb 58 d9          	vaddsd %xmm1,%xmm0,%xmm3
  1e4ffd:	c4 e3 7d 19 e8 01    	vextractf128 $0x1,%ymm5,%xmm0
  1e5003:	c5 d1 58 c0          	vaddpd %xmm0,%xmm5,%xmm0
  1e5007:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e500c:	c5 fb 58 e9          	vaddsd %xmm1,%xmm0,%xmm5
  1e5010:	48 83 bc 24 90 01 00 	cmpq   $0x0,0x190(%rsp)
  1e5017:	00 00 
  1e5019:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
  1e5020:	00 
  1e5021:	0f 84 b9 02 00 00    	je     1e52e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5170>
  1e5027:	48 83 bc 24 88 00 00 	cmpq   $0x0,0x88(%rsp)
  1e502e:	00 00 
  1e5030:	c5 7d 10 b4 24 20 04 	vmovupd 0x420(%rsp),%ymm14
  1e5037:	00 00 
  1e5039:	c5 7d 10 bc 24 e0 02 	vmovupd 0x2e0(%rsp),%ymm15
  1e5040:	00 00 
  1e5042:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
  1e5049:	00 
  1e504a:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1e504f:	41 b5 3f             	mov    $0x3f,%r13b
  1e5052:	0f 84 53 ea ff ff    	je     1e3aab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393b>
  1e5058:	48 8b 8c 24 f8 01 00 	mov    0x1f8(%rsp),%rcx
  1e505f:	00 
  1e5060:	c5 fb 10 01          	vmovsd (%rcx),%xmm0
  1e5064:	c5 f9 28 d0          	vmovapd %xmm0,%xmm2
  1e5068:	c5 79 28 9c 24 20 03 	vmovapd 0x320(%rsp),%xmm11
  1e506f:	00 00 
  1e5071:	c4 e2 a1 a9 94 24 40 	vfmadd213sd 0x240(%rsp),%xmm11,%xmm2
  1e5078:	02 00 00 
  1e507b:	48 8b 8c 24 00 02 00 	mov    0x200(%rsp),%rcx
  1e5082:	00 
  1e5083:	c5 7b 10 29          	vmovsd (%rcx),%xmm13
  1e5087:	c4 e2 91 a9 10       	vfmadd213sd (%rax),%xmm13,%xmm2
  1e508c:	c5 f9 28 8c 24 b0 01 	vmovapd 0x1b0(%rsp),%xmm1
  1e5093:	00 00 
  1e5095:	c4 e2 f1 99 84 24 50 	vfmadd132sd 0x150(%rsp),%xmm1,%xmm0
  1e509c:	01 00 00 
  1e509f:	c4 c2 e9 a9 c5       	vfmadd213sd %xmm13,%xmm2,%xmm0
  1e50a4:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  1e50a9:	c4 a1 7b 10 0c c9    	vmovsd (%rcx,%r9,8),%xmm1
  1e50af:	c4 e2 f1 b9 ea       	vfmadd231sd %xmm2,%xmm1,%xmm5
  1e50b4:	c4 62 91 b9 c1       	vfmadd231sd %xmm1,%xmm13,%xmm8
  1e50b9:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  1e50be:	c4 a1 7b 10 0c c9    	vmovsd (%rcx,%r9,8),%xmm1
  1e50c4:	c4 e2 f1 b9 da       	vfmadd231sd %xmm2,%xmm1,%xmm3
  1e50c9:	c4 e2 91 b9 f9       	vfmadd231sd %xmm1,%xmm13,%xmm7
  1e50ce:	c4 81 7b 10 0c cf    	vmovsd (%r15,%r9,8),%xmm1
  1e50d4:	c4 e2 f1 b9 f2       	vfmadd231sd %xmm2,%xmm1,%xmm6
  1e50d9:	c4 62 91 b9 d1       	vfmadd231sd %xmm1,%xmm13,%xmm10
  1e50de:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  1e50e3:	c4 a1 7b 10 0c c9    	vmovsd (%rcx,%r9,8),%xmm1
  1e50e9:	c4 42 f1 b9 cd       	vfmadd231sd %xmm13,%xmm1,%xmm9
  1e50ee:	c4 e2 f1 b9 e2       	vfmadd231sd %xmm2,%xmm1,%xmm4
  1e50f3:	48 8b 8c 24 20 02 00 	mov    0x220(%rsp),%rcx
  1e50fa:	00 
  1e50fb:	c5 fb 11 11          	vmovsd %xmm2,(%rcx)
  1e50ff:	c4 e1 f9 7e d1       	vmovq  %xmm2,%rcx
  1e5104:	c4 e1 f9 7e c6       	vmovq  %xmm0,%rsi
  1e5109:	c5 fb 11 00          	vmovsd %xmm0,(%rax)
  1e510d:	c4 e2 90 f5 c9       	bzhi   %r13,%rcx,%rcx
  1e5112:	49 bb 00 00 00 00 00 	movabs $0x7ff0000000000000,%r11
  1e5119:	00 f0 7f 
  1e511c:	4c 39 d9             	cmp    %r11,%rcx
  1e511f:	40 0f 94 c7          	sete   %dil
  1e5123:	48 85 c9             	test   %rcx,%rcx
  1e5126:	41 0f 94 c0          	sete   %r8b
  1e512a:	41 08 f8             	or     %dil,%r8b
  1e512d:	48 bf 00 00 00 00 00 	movabs $0xfff0000000000000,%rdi
  1e5134:	00 f0 ff 
  1e5137:	48 01 f9             	add    %rdi,%rcx
  1e513a:	48 c1 e9 35          	shr    $0x35,%rcx
  1e513e:	81 f9 ff 03 00 00    	cmp    $0x3ff,%ecx
  1e5144:	0f 92 c1             	setb   %cl
  1e5147:	44 08 c1             	or     %r8b,%cl
  1e514a:	c4 e2 90 f5 f6       	bzhi   %r13,%rsi,%rsi
  1e514f:	4c 39 de             	cmp    %r11,%rsi
  1e5152:	49 89 fb             	mov    %rdi,%r11
  1e5155:	40 0f 94 c7          	sete   %dil
  1e5159:	48 85 f6             	test   %rsi,%rsi
  1e515c:	41 0f 94 c0          	sete   %r8b
  1e5160:	41 08 f8             	or     %dil,%r8b
  1e5163:	4c 01 de             	add    %r11,%rsi
  1e5166:	48 c1 ee 35          	shr    $0x35,%rsi
  1e516a:	81 fe ff 03 00 00    	cmp    $0x3ff,%esi
  1e5170:	40 0f 92 c6          	setb   %sil
  1e5174:	44 08 c6             	or     %r8b,%sil
  1e5177:	40 20 ce             	and    %cl,%sil
  1e517a:	40 88 b4 24 c0 01 00 	mov    %sil,0x1c0(%rsp)
  1e5181:	00 
  1e5182:	83 bc 24 90 01 00 00 	cmpl   $0x1,0x190(%rsp)
  1e5189:	01 
  1e518a:	0f 84 42 01 00 00    	je     1e52d2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5162>
  1e5190:	83 bc 24 88 00 00 00 	cmpl   $0x1,0x88(%rsp)
  1e5197:	01 
  1e5198:	0f 84 0d e9 ff ff    	je     1e3aab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393b>
  1e519e:	48 8b 8c 24 f8 01 00 	mov    0x1f8(%rsp),%rcx
  1e51a5:	00 
  1e51a6:	c5 fb 10 41 08       	vmovsd 0x8(%rcx),%xmm0
  1e51ab:	c5 f9 28 d0          	vmovapd %xmm0,%xmm2
  1e51af:	c4 e2 a1 a9 94 24 40 	vfmadd213sd 0x240(%rsp),%xmm11,%xmm2
  1e51b6:	02 00 00 
  1e51b9:	48 8b 8c 24 00 02 00 	mov    0x200(%rsp),%rcx
  1e51c0:	00 
  1e51c1:	c5 7b 10 69 08       	vmovsd 0x8(%rcx),%xmm13
  1e51c6:	c4 e2 91 a9 50 08    	vfmadd213sd 0x8(%rax),%xmm13,%xmm2
  1e51cc:	c5 f9 28 8c 24 b0 01 	vmovapd 0x1b0(%rsp),%xmm1
  1e51d3:	00 00 
  1e51d5:	c4 e2 f1 99 84 24 50 	vfmadd132sd 0x150(%rsp),%xmm1,%xmm0
  1e51dc:	01 00 00 
  1e51df:	c4 c2 e9 a9 c5       	vfmadd213sd %xmm13,%xmm2,%xmm0
  1e51e4:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  1e51e9:	c4 a1 7b 10 4c c9 08 	vmovsd 0x8(%rcx,%r9,8),%xmm1
  1e51f0:	c4 e2 f1 b9 ea       	vfmadd231sd %xmm2,%xmm1,%xmm5
  1e51f5:	c4 62 91 b9 c1       	vfmadd231sd %xmm1,%xmm13,%xmm8
  1e51fa:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  1e51ff:	c4 a1 7b 10 4c c9 08 	vmovsd 0x8(%rcx,%r9,8),%xmm1
  1e5206:	c4 e2 f1 b9 da       	vfmadd231sd %xmm2,%xmm1,%xmm3
  1e520b:	c4 e2 91 b9 f9       	vfmadd231sd %xmm1,%xmm13,%xmm7
  1e5210:	c4 81 7b 10 4c cf 08 	vmovsd 0x8(%r15,%r9,8),%xmm1
  1e5217:	c4 e2 f1 b9 f2       	vfmadd231sd %xmm2,%xmm1,%xmm6
  1e521c:	c4 62 91 b9 d1       	vfmadd231sd %xmm1,%xmm13,%xmm10
  1e5221:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  1e5226:	c4 a1 7b 10 4c c9 08 	vmovsd 0x8(%rcx,%r9,8),%xmm1
  1e522d:	c4 42 f1 b9 cd       	vfmadd231sd %xmm13,%xmm1,%xmm9
  1e5232:	c4 e2 f1 b9 e2       	vfmadd231sd %xmm2,%xmm1,%xmm4
  1e5237:	c4 e1 f9 7e d1       	vmovq  %xmm2,%rcx
  1e523c:	48 8b b4 24 20 02 00 	mov    0x220(%rsp),%rsi
  1e5243:	00 
  1e5244:	c5 fb 11 56 08       	vmovsd %xmm2,0x8(%rsi)
  1e5249:	c4 e1 f9 7e c6       	vmovq  %xmm0,%rsi
  1e524e:	c5 fb 11 40 08       	vmovsd %xmm0,0x8(%rax)
  1e5253:	c4 e2 90 f5 c9       	bzhi   %r13,%rcx,%rcx
  1e5258:	49 bb 00 00 00 00 00 	movabs $0x7ff0000000000000,%r11
  1e525f:	00 f0 7f 
  1e5262:	4c 39 d9             	cmp    %r11,%rcx
  1e5265:	40 0f 94 c7          	sete   %dil
  1e5269:	48 85 c9             	test   %rcx,%rcx
  1e526c:	41 0f 94 c0          	sete   %r8b
  1e5270:	41 08 f8             	or     %dil,%r8b
  1e5273:	48 bf 00 00 00 00 00 	movabs $0xfff0000000000000,%rdi
  1e527a:	00 f0 ff 
  1e527d:	48 01 f9             	add    %rdi,%rcx
  1e5280:	48 c1 e9 35          	shr    $0x35,%rcx
  1e5284:	81 f9 ff 03 00 00    	cmp    $0x3ff,%ecx
  1e528a:	0f 92 c1             	setb   %cl
  1e528d:	44 08 c1             	or     %r8b,%cl
  1e5290:	c4 e2 90 f5 f6       	bzhi   %r13,%rsi,%rsi
  1e5295:	4c 39 de             	cmp    %r11,%rsi
  1e5298:	49 89 fb             	mov    %rdi,%r11
  1e529b:	40 0f 94 c7          	sete   %dil
  1e529f:	48 85 f6             	test   %rsi,%rsi
  1e52a2:	41 0f 94 c0          	sete   %r8b
  1e52a6:	41 08 f8             	or     %dil,%r8b
  1e52a9:	4c 01 de             	add    %r11,%rsi
  1e52ac:	48 c1 ee 35          	shr    $0x35,%rsi
  1e52b0:	81 fe ff 03 00 00    	cmp    $0x3ff,%esi
  1e52b6:	40 0f 92 c6          	setb   %sil
  1e52ba:	44 08 c6             	or     %r8b,%sil
  1e52bd:	40 20 ce             	and    %cl,%sil
  1e52c0:	40 20 b4 24 c0 01 00 	and    %sil,0x1c0(%rsp)
  1e52c7:	00 
  1e52c8:	83 bc 24 90 01 00 00 	cmpl   $0x2,0x190(%rsp)
  1e52cf:	02 
  1e52d0:	75 58                	jne    1e532a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x51ba>
  1e52d2:	c4 62 7d 19 2d 9d 0d 	vbroadcastsd -0x1bf263(%rip),%ymm13        # 26078 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x3a8>
  1e52d9:	e4 ff 
  1e52db:	e9 a5 01 00 00       	jmp    1e5485 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5315>
  1e52e0:	c6 84 24 c0 01 00 00 	movb   $0x1,0x1c0(%rsp)
  1e52e7:	01 
  1e52e8:	c4 62 7d 19 2d 87 0d 	vbroadcastsd -0x1bf279(%rip),%ymm13        # 26078 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x3a8>
  1e52ef:	e4 ff 
  1e52f1:	c5 7d 10 b4 24 20 04 	vmovupd 0x420(%rsp),%ymm14
  1e52f8:	00 00 
  1e52fa:	c5 7d 10 bc 24 e0 02 	vmovupd 0x2e0(%rsp),%ymm15
  1e5301:	00 00 
  1e5303:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
  1e530a:	00 
  1e530b:	4c 8b 8c 24 00 04 00 	mov    0x400(%rsp),%r9
  1e5312:	00 
  1e5313:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1e5318:	41 b5 3f             	mov    $0x3f,%r13b
  1e531b:	49 bb 00 00 00 00 00 	movabs $0xfff0000000000000,%r11
  1e5322:	00 f0 ff 
  1e5325:	e9 63 01 00 00       	jmp    1e548d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x531d>
  1e532a:	83 bc 24 88 00 00 00 	cmpl   $0x2,0x88(%rsp)
  1e5331:	02 
  1e5332:	0f 84 73 e7 ff ff    	je     1e3aab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393b>
  1e5338:	c5 79 28 ff          	vmovapd %xmm7,%xmm15
  1e533c:	c5 79 28 e3          	vmovapd %xmm3,%xmm12
  1e5340:	48 8b 8c 24 f8 01 00 	mov    0x1f8(%rsp),%rcx
  1e5347:	00 
  1e5348:	c5 fb 10 49 10       	vmovsd 0x10(%rcx),%xmm1
  1e534d:	c4 62 f1 a9 9c 24 40 	vfmadd213sd 0x240(%rsp),%xmm1,%xmm11
  1e5354:	02 00 00 
  1e5357:	48 8b 8c 24 00 02 00 	mov    0x200(%rsp),%rcx
  1e535e:	00 
  1e535f:	c5 fb 10 41 10       	vmovsd 0x10(%rcx),%xmm0
  1e5364:	c4 62 f9 a9 58 10    	vfmadd213sd 0x10(%rax),%xmm0,%xmm11
  1e536a:	c4 61 f9 7e d9       	vmovq  %xmm11,%rcx
  1e536f:	c4 e2 90 f5 c9       	bzhi   %r13,%rcx,%rcx
  1e5374:	49 b8 00 00 00 00 00 	movabs $0x7ff0000000000000,%r8
  1e537b:	00 f0 7f 
  1e537e:	4c 39 c1             	cmp    %r8,%rcx
  1e5381:	40 0f 94 c6          	sete   %sil
  1e5385:	48 85 c9             	test   %rcx,%rcx
  1e5388:	40 0f 94 c7          	sete   %dil
  1e538c:	40 08 f7             	or     %sil,%dil
  1e538f:	4c 01 d9             	add    %r11,%rcx
  1e5392:	48 c1 e9 35          	shr    $0x35,%rcx
  1e5396:	81 f9 ff 03 00 00    	cmp    $0x3ff,%ecx
  1e539c:	0f 92 c1             	setb   %cl
  1e539f:	40 08 f9             	or     %dil,%cl
  1e53a2:	c5 f9 28 9c 24 50 01 	vmovapd 0x150(%rsp),%xmm3
  1e53a9:	00 00 
  1e53ab:	c4 e2 f1 a9 9c 24 b0 	vfmadd213sd 0x1b0(%rsp),%xmm1,%xmm3
  1e53b2:	01 00 00 
  1e53b5:	c4 e2 a1 a9 d8       	vfmadd213sd %xmm0,%xmm11,%xmm3
  1e53ba:	c4 e1 f9 7e de       	vmovq  %xmm3,%rsi
  1e53bf:	c4 e2 90 f5 f6       	bzhi   %r13,%rsi,%rsi
  1e53c4:	4c 39 c6             	cmp    %r8,%rsi
  1e53c7:	40 0f 94 c7          	sete   %dil
  1e53cb:	48 85 f6             	test   %rsi,%rsi
  1e53ce:	41 0f 94 c0          	sete   %r8b
  1e53d2:	41 08 f8             	or     %dil,%r8b
  1e53d5:	4c 01 de             	add    %r11,%rsi
  1e53d8:	48 c1 ee 35          	shr    $0x35,%rsi
  1e53dc:	81 fe ff 03 00 00    	cmp    $0x3ff,%esi
  1e53e2:	40 0f 92 c6          	setb   %sil
  1e53e6:	44 08 c6             	or     %r8b,%sil
  1e53e9:	40 20 ce             	and    %cl,%sil
  1e53ec:	40 20 b4 24 c0 01 00 	and    %sil,0x1c0(%rsp)
  1e53f3:	00 
  1e53f4:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  1e53f9:	c4 a1 7b 10 4c c9 10 	vmovsd 0x10(%rcx,%r9,8),%xmm1
  1e5400:	c4 c2 f1 b9 eb       	vfmadd231sd %xmm11,%xmm1,%xmm5
  1e5405:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  1e540a:	c4 a1 7b 10 54 c9 10 	vmovsd 0x10(%rcx,%r9,8),%xmm2
  1e5411:	c4 42 e9 b9 e3       	vfmadd231sd %xmm11,%xmm2,%xmm12
  1e5416:	c4 41 79 28 eb       	vmovapd %xmm11,%xmm13
  1e541b:	c4 01 7b 10 5c cf 10 	vmovsd 0x10(%r15,%r9,8),%xmm11
  1e5422:	c4 c2 a1 b9 f5       	vfmadd231sd %xmm13,%xmm11,%xmm6
  1e5427:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  1e542c:	c5 f9 28 fd          	vmovapd %xmm5,%xmm7
  1e5430:	c4 a1 7b 10 6c c9 10 	vmovsd 0x10(%rcx,%r9,8),%xmm5
  1e5437:	c4 c2 d1 b9 e5       	vfmadd231sd %xmm13,%xmm5,%xmm4
  1e543c:	c4 62 f9 b9 c1       	vfmadd231sd %xmm1,%xmm0,%xmm8
  1e5441:	c4 62 f9 b9 fa       	vfmadd231sd %xmm2,%xmm0,%xmm15
  1e5446:	c4 42 f9 b9 d3       	vfmadd231sd %xmm11,%xmm0,%xmm10
  1e544b:	c4 62 d1 b9 c8       	vfmadd231sd %xmm0,%xmm5,%xmm9
  1e5450:	c5 f9 28 ef          	vmovapd %xmm7,%xmm5
  1e5454:	c5 79 29 ff          	vmovapd %xmm15,%xmm7
  1e5458:	48 8b 8c 24 20 02 00 	mov    0x220(%rsp),%rcx
  1e545f:	00 
  1e5460:	c5 7b 11 69 10       	vmovsd %xmm13,0x10(%rcx)
  1e5465:	c5 fb 11 58 10       	vmovsd %xmm3,0x10(%rax)
  1e546a:	c5 79 29 e3          	vmovapd %xmm12,%xmm3
  1e546e:	c4 62 7d 19 2d 01 0c 	vbroadcastsd -0x1bf3ff(%rip),%ymm13        # 26078 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x3a8>
  1e5475:	e4 ff 
  1e5477:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1e547c:	c5 7d 10 bc 24 e0 02 	vmovupd 0x2e0(%rsp),%ymm15
  1e5483:	00 00 
  1e5485:	4c 8b 8c 24 00 04 00 	mov    0x400(%rsp),%r9
  1e548c:	00 
  1e548d:	c5 7d 29 f8          	vmovapd %ymm15,%ymm0
  1e5491:	48 85 d2             	test   %rdx,%rdx
  1e5494:	0f 84 ea 00 00 00    	je     1e5584 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5414>
  1e549a:	48 83 fa 01          	cmp    $0x1,%rdx
  1e549e:	75 0b                	jne    1e54ab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x533b>
  1e54a0:	31 c9                	xor    %ecx,%ecx
  1e54a2:	c5 7d 29 f8          	vmovapd %ymm15,%ymm0
  1e54a6:	e9 9b 00 00 00       	jmp    1e5546 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x53d6>
  1e54ab:	be 20 00 00 00       	mov    $0x20,%esi
  1e54b0:	31 c9                	xor    %ecx,%ecx
  1e54b2:	c5 7d 29 f8          	vmovapd %ymm15,%ymm0
  1e54b6:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  1e54bb:	4c 8b 44 24 58       	mov    0x58(%rsp),%r8
  1e54c0:	c4 c1 0d 54 4c 30 e0 	vandpd -0x20(%r8,%rsi,1),%ymm14,%ymm1
  1e54c7:	c5 8d 54 54 37 e0    	vandpd -0x20(%rdi,%rsi,1),%ymm14,%ymm2
  1e54cd:	c5 1d c2 d9 00       	vcmpeqpd %ymm1,%ymm12,%ymm11
  1e54d2:	c4 c1 75 c2 cd 1d    	vcmpge_oqpd %ymm13,%ymm1,%ymm1
  1e54d8:	c5 a5 56 c9          	vorpd  %ymm1,%ymm11,%ymm1
  1e54dc:	c5 f5 54 c0          	vandpd %ymm0,%ymm1,%ymm0
  1e54e0:	c5 9d c2 ca 00       	vcmpeqpd %ymm2,%ymm12,%ymm1
  1e54e5:	c4 c1 6d c2 d5 1d    	vcmpge_oqpd %ymm13,%ymm2,%ymm2
  1e54eb:	c5 ed 56 c9          	vorpd  %ymm1,%ymm2,%ymm1
  1e54ef:	c4 c1 0d 54 14 30    	vandpd (%r8,%rsi,1),%ymm14,%ymm2
  1e54f5:	c5 0d 54 1c 37       	vandpd (%rdi,%rsi,1),%ymm14,%ymm11
  1e54fa:	48 83 c1 02          	add    $0x2,%rcx
  1e54fe:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1e5503:	c5 1d c2 e2 00       	vcmpeqpd %ymm2,%ymm12,%ymm12
  1e5508:	c4 c1 6d c2 d5 1d    	vcmpge_oqpd %ymm13,%ymm2,%ymm2
  1e550e:	c5 9d 56 d2          	vorpd  %ymm2,%ymm12,%ymm2
  1e5512:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  1e5517:	c5 ed 54 c9          	vandpd %ymm1,%ymm2,%ymm1
  1e551b:	c5 f5 54 c0          	vandpd %ymm0,%ymm1,%ymm0
  1e551f:	c4 c1 25 c2 cc 00    	vcmpeqpd %ymm12,%ymm11,%ymm1
  1e5525:	c4 c1 25 c2 d5 1d    	vcmpge_oqpd %ymm13,%ymm11,%ymm2
  1e552b:	c5 ed 56 c9          	vorpd  %ymm1,%ymm2,%ymm1
  1e552f:	c5 fd 54 c1          	vandpd %ymm1,%ymm0,%ymm0
  1e5533:	48 83 c6 40          	add    $0x40,%rsi
  1e5537:	49 39 c9             	cmp    %rcx,%r9
  1e553a:	75 84                	jne    1e54c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5350>
  1e553c:	f6 84 24 98 02 00 00 	testb  $0x4,0x298(%rsp)
  1e5543:	04 
  1e5544:	74 3e                	je     1e5584 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5414>
  1e5546:	48 c1 e1 05          	shl    $0x5,%rcx
  1e554a:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  1e554f:	c5 8d 54 0c 0e       	vandpd (%rsi,%rcx,1),%ymm14,%ymm1
  1e5554:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  1e5559:	c5 8d 54 14 0e       	vandpd (%rsi,%rcx,1),%ymm14,%ymm2
  1e555e:	c5 1d c2 d9 00       	vcmpeqpd %ymm1,%ymm12,%ymm11
  1e5563:	c4 c1 75 c2 cd 1d    	vcmpge_oqpd %ymm13,%ymm1,%ymm1
  1e5569:	c5 a5 56 c9          	vorpd  %ymm1,%ymm11,%ymm1
  1e556d:	c5 1d c2 da 00       	vcmpeqpd %ymm2,%ymm12,%ymm11
  1e5572:	c4 c1 6d c2 d5 1d    	vcmpge_oqpd %ymm13,%ymm2,%ymm2
  1e5578:	c5 a5 56 d2          	vorpd  %ymm2,%ymm11,%ymm2
  1e557c:	c5 f5 54 ca          	vandpd %ymm2,%ymm1,%ymm1
  1e5580:	c5 f5 54 c0          	vandpd %ymm0,%ymm1,%ymm0
  1e5584:	c4 e2 1d 37 c0       	vpcmpgtq %ymm0,%ymm12,%ymm0
  1e5589:	c4 e2 7d 59 0d 16 0c 	vpbroadcastq -0x1bf3ea(%rip),%ymm1        # 261a8 <anon.f3f2874240c9e52c98c7f84b8cf58816.124.llvm.10730297419414128210+0x4d8>
  1e5590:	e4 ff 
  1e5592:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
  1e5596:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
  1e559c:	c5 f9 5d c1          	vminpd %xmm1,%xmm0,%xmm0
  1e55a0:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e55a5:	c5 fb 5d c1          	vminsd %xmm1,%xmm0,%xmm0
  1e55a9:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  1e55ad:	c5 f9 2e c1          	vucomisd %xmm1,%xmm0
  1e55b1:	0f 86 f4 e4 ff ff    	jbe    1e3aab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393b>
  1e55b7:	48 83 bc 24 e0 03 00 	cmpq   $0x0,0x3e0(%rsp)
  1e55be:	00 00 
  1e55c0:	49 b9 00 00 00 00 00 	movabs $0x7ff0000000000000,%r9
  1e55c7:	00 f0 7f 
  1e55ca:	0f 84 84 00 00 00    	je     1e5654 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x54e4>
  1e55d0:	31 c9                	xor    %ecx,%ecx
  1e55d2:	48 8b b4 24 20 02 00 	mov    0x220(%rsp),%rsi
  1e55d9:	00 
  1e55da:	c4 e2 90 f5 34 ce    	bzhi   %r13,(%rsi,%rcx,8),%rsi
  1e55e0:	4c 39 ce             	cmp    %r9,%rsi
  1e55e3:	40 0f 95 c7          	setne  %dil
  1e55e7:	48 85 f6             	test   %rsi,%rsi
  1e55ea:	41 0f 95 c0          	setne  %r8b
  1e55ee:	41 20 f8             	and    %dil,%r8b
  1e55f1:	4c 01 de             	add    %r11,%rsi
  1e55f4:	48 c1 ee 35          	shr    $0x35,%rsi
  1e55f8:	81 fe ff 03 00 00    	cmp    $0x3ff,%esi
  1e55fe:	40 0f 93 c6          	setae  %sil
  1e5602:	41 84 f0             	test   %sil,%r8b
  1e5605:	75 3f                	jne    1e5646 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x54d6>
  1e5607:	c4 e2 90 f5 34 c8    	bzhi   %r13,(%rax,%rcx,8),%rsi
  1e560d:	48 bf 01 00 00 00 00 	movabs $0x7ff0000000000001,%rdi
  1e5614:	00 f0 7f 
  1e5617:	48 39 fe             	cmp    %rdi,%rsi
  1e561a:	40 0f 9c c7          	setl   %dil
  1e561e:	48 ff ce             	dec    %rsi
  1e5621:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffe,%r8
  1e5628:	ff 0f 00 
  1e562b:	4c 39 c6             	cmp    %r8,%rsi
  1e562e:	40 0f 97 c6          	seta   %sil
  1e5632:	40 84 fe             	test   %dil,%sil
  1e5635:	74 0f                	je     1e5646 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x54d6>
  1e5637:	48 ff c1             	inc    %rcx
  1e563a:	48 39 8c 24 88 00 00 	cmp    %rcx,0x88(%rsp)
  1e5641:	00 
  1e5642:	75 8e                	jne    1e55d2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5462>
  1e5644:	eb 0e                	jmp    1e5654 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x54e4>
  1e5646:	48 3b 8c 24 88 00 00 	cmp    0x88(%rsp),%rcx
  1e564d:	00 
  1e564e:	0f 82 57 e4 ff ff    	jb     1e3aab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x393b>
  1e5654:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  1e5659:	48 8d 3c 36          	lea    (%rsi,%rsi,1),%rdi
  1e565d:	48 3b 7c 24 28       	cmp    0x28(%rsp),%rdi
  1e5662:	0f 83 f8 0d 00 00    	jae    1e6460 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x62f0>
  1e5668:	49 89 f9             	mov    %rdi,%r9
  1e566b:	49 c1 e1 04          	shl    $0x4,%r9
  1e566f:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  1e5676:	00 
  1e5677:	c4 21 7b 11 0c 09    	vmovsd %xmm9,(%rcx,%r9,1)
  1e567d:	48 8b 84 24 78 01 00 	mov    0x178(%rsp),%rax
  1e5684:	00 
  1e5685:	48 8d 34 70          	lea    (%rax,%rsi,2),%rsi
  1e5689:	c4 21 7b 11 54 09 08 	vmovsd %xmm10,0x8(%rcx,%r9,1)
  1e5690:	48 3b b4 24 f0 00 00 	cmp    0xf0(%rsp),%rsi
  1e5697:	00 
  1e5698:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
  1e569d:	73 26                	jae    1e56c5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5555>
  1e569f:	48 8d 47 01          	lea    0x1(%rdi),%rax
  1e56a3:	48 3b 44 24 28       	cmp    0x28(%rsp),%rax
  1e56a8:	0f 83 f0 0d 00 00    	jae    1e649e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x632e>
  1e56ae:	48 c1 e0 04          	shl    $0x4,%rax
  1e56b2:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  1e56b9:	00 
  1e56ba:	c5 fb 11 3c 01       	vmovsd %xmm7,(%rcx,%rax,1)
  1e56bf:	c5 7b 11 44 01 08    	vmovsd %xmm8,0x8(%rcx,%rax,1)
  1e56c5:	4c 8d 6e 02          	lea    0x2(%rsi),%r13
  1e56c9:	4c 89 e8             	mov    %r13,%rax
  1e56cc:	48 2b 84 24 78 01 00 	sub    0x178(%rsp),%rax
  1e56d3:	00 
  1e56d4:	48 3b 44 24 28       	cmp    0x28(%rsp),%rax
  1e56d9:	0f 83 3c 0d 00 00    	jae    1e641b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x62ab>
  1e56df:	49 89 c0             	mov    %rax,%r8
  1e56e2:	49 c1 e0 04          	shl    $0x4,%r8
  1e56e6:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  1e56ed:	00 
  1e56ee:	c4 a1 7b 11 24 01    	vmovsd %xmm4,(%rcx,%r8,1)
  1e56f4:	4c 89 84 24 20 03 00 	mov    %r8,0x320(%rsp)
  1e56fb:	00 
  1e56fc:	c4 a1 7b 11 74 01 08 	vmovsd %xmm6,0x8(%rcx,%r8,1)
  1e5703:	4c 3b ac 24 f0 00 00 	cmp    0xf0(%rsp),%r13
  1e570a:	00 
  1e570b:	73 28                	jae    1e5735 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x55c5>
  1e570d:	48 8d 48 01          	lea    0x1(%rax),%rcx
  1e5711:	48 3b 4c 24 28       	cmp    0x28(%rsp),%rcx
  1e5716:	0f 83 f2 ec ff ff    	jae    1e440e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x429e>
  1e571c:	48 c1 e1 04          	shl    $0x4,%rcx
  1e5720:	4c 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%r8
  1e5727:	00 
  1e5728:	c4 c1 7b 11 1c 08    	vmovsd %xmm3,(%r8,%rcx,1)
  1e572e:	c4 c1 7b 11 6c 08 08 	vmovsd %xmm5,0x8(%r8,%rcx,1)
  1e5735:	48 89 b4 24 b0 01 00 	mov    %rsi,0x1b0(%rsp)
  1e573c:	00 
  1e573d:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  1e5741:	4d 85 f6             	test   %r14,%r14
  1e5744:	4c 89 8c 24 40 02 00 	mov    %r9,0x240(%rsp)
  1e574b:	00 
  1e574c:	74 2c                	je     1e577a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x560a>
  1e574e:	49 83 fe 01          	cmp    $0x1,%r14
  1e5752:	75 4a                	jne    1e579e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x562e>
  1e5754:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1e5758:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1e575d:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e5761:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1e5765:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1e576a:	31 c9                	xor    %ecx,%ecx
  1e576c:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e5770:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1e5775:	e9 55 01 00 00       	jmp    1e58cf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x575f>
  1e577a:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1e577e:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1e5783:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e5787:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1e578b:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1e5790:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1e5795:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e5799:	e9 9d 01 00 00       	jmp    1e593b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x57cb>
  1e579e:	88 9c 24 50 01 00 00 	mov    %bl,0x150(%rsp)
  1e57a5:	4d 89 dd             	mov    %r11,%r13
  1e57a8:	41 bb 20 00 00 00    	mov    $0x20,%r11d
  1e57ae:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  1e57b2:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  1e57b7:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  1e57bb:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  1e57bf:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  1e57c4:	31 c9                	xor    %ecx,%ecx
  1e57c6:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  1e57ca:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  1e57cf:	4c 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%r8
  1e57d6:	00 
  1e57d7:	4c 8b bc 24 98 00 00 	mov    0x98(%rsp),%r15
  1e57de:	00 
  1e57df:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  1e57e4:	4c 8b 74 24 38       	mov    0x38(%rsp),%r14
  1e57e9:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
  1e57ee:	4c 8b 8c 24 40 04 00 	mov    0x440(%rsp),%r9
  1e57f5:	00 
  1e57f6:	c4 81 7d 10 44 18 e0 	vmovupd -0x20(%r8,%r11,1),%ymm0
  1e57fd:	c4 81 7d 10 4c 1d e0 	vmovupd -0x20(%r13,%r11,1),%ymm1
  1e5804:	c4 e2 fd b8 f9       	vfmadd231pd %ymm1,%ymm0,%ymm7
  1e5809:	c4 81 7d 10 54 1f e0 	vmovupd -0x20(%r15,%r11,1),%ymm2
  1e5810:	c4 62 ed b8 c1       	vfmadd231pd %ymm1,%ymm2,%ymm8
  1e5815:	c4 21 7d 10 54 1e e0 	vmovupd -0x20(%rsi,%r11,1),%ymm10
  1e581c:	c4 e2 ad b8 e1       	vfmadd231pd %ymm1,%ymm10,%ymm4
  1e5821:	c4 01 7d 10 64 1e e0 	vmovupd -0x20(%r14,%r11,1),%ymm12
  1e5828:	c4 e2 9d b8 f1       	vfmadd231pd %ymm1,%ymm12,%ymm6
  1e582d:	c4 a1 7d 10 4c 1b e0 	vmovupd -0x20(%rbx,%r11,1),%ymm1
  1e5834:	c4 62 f5 b8 d8       	vfmadd231pd %ymm0,%ymm1,%ymm11
  1e5839:	c4 81 7d 10 04 18    	vmovupd (%r8,%r11,1),%ymm0
  1e583f:	c4 62 f5 b8 ca       	vfmadd231pd %ymm2,%ymm1,%ymm9
  1e5844:	c4 81 7d 10 54 1d 00 	vmovupd 0x0(%r13,%r11,1),%ymm2
  1e584b:	c4 c2 f5 b8 da       	vfmadd231pd %ymm10,%ymm1,%ymm3
  1e5850:	c4 01 7d 10 14 1f    	vmovupd (%r15,%r11,1),%ymm10
  1e5856:	c4 e2 9d b8 e9       	vfmadd231pd %ymm1,%ymm12,%ymm5
  1e585b:	c4 a1 7d 10 0c 1e    	vmovupd (%rsi,%r11,1),%ymm1
  1e5861:	c4 01 7d 10 24 1e    	vmovupd (%r14,%r11,1),%ymm12
  1e5867:	c4 e2 fd b8 fa       	vfmadd231pd %ymm2,%ymm0,%ymm7
  1e586c:	c4 62 ad b8 c2       	vfmadd231pd %ymm2,%ymm10,%ymm8
  1e5871:	c4 e2 f5 b8 e2       	vfmadd231pd %ymm2,%ymm1,%ymm4
  1e5876:	c4 e2 9d b8 f2       	vfmadd231pd %ymm2,%ymm12,%ymm6
  1e587b:	c4 a1 7d 10 14 1b    	vmovupd (%rbx,%r11,1),%ymm2
  1e5881:	c4 62 ed b8 d8       	vfmadd231pd %ymm0,%ymm2,%ymm11
  1e5886:	c4 42 ed b8 ca       	vfmadd231pd %ymm10,%ymm2,%ymm9
  1e588b:	c4 e2 ed b8 d9       	vfmadd231pd %ymm1,%ymm2,%ymm3
  1e5890:	c4 e2 9d b8 ea       	vfmadd231pd %ymm2,%ymm12,%ymm5
  1e5895:	48 83 c1 02          	add    $0x2,%rcx
  1e5899:	49 83 c3 40          	add    $0x40,%r11
  1e589d:	49 39 c9             	cmp    %rcx,%r9
  1e58a0:	0f 85 50 ff ff ff    	jne    1e57f6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5686>
  1e58a6:	f6 84 24 c0 00 00 00 	testb  $0x1,0xc0(%rsp)
  1e58ad:	01 
  1e58ae:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
  1e58b5:	00 
  1e58b6:	0f b6 9c 24 50 01 00 	movzbl 0x150(%rsp),%ebx
  1e58bd:	00 
  1e58be:	4d 89 eb             	mov    %r13,%r11
  1e58c1:	48 8b b4 24 b0 01 00 	mov    0x1b0(%rsp),%rsi
  1e58c8:	00 
  1e58c9:	4c 8d 6e 02          	lea    0x2(%rsi),%r13
  1e58cd:	74 6c                	je     1e593b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x57cb>
  1e58cf:	48 c1 e1 05          	shl    $0x5,%rcx
  1e58d3:	4c 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%r8
  1e58da:	00 
  1e58db:	c4 c1 7d 10 04 08    	vmovupd (%r8,%rcx,1),%ymm0
  1e58e1:	c4 c1 7d 10 0c 0b    	vmovupd (%r11,%rcx,1),%ymm1
  1e58e7:	c4 e2 fd b8 f9       	vfmadd231pd %ymm1,%ymm0,%ymm7
  1e58ec:	4c 8b 84 24 98 00 00 	mov    0x98(%rsp),%r8
  1e58f3:	00 
  1e58f4:	c4 c1 7d 10 14 08    	vmovupd (%r8,%rcx,1),%ymm2
  1e58fa:	c4 62 ed b8 c1       	vfmadd231pd %ymm1,%ymm2,%ymm8
  1e58ff:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  1e5904:	c5 7d 10 14 0e       	vmovupd (%rsi,%rcx,1),%ymm10
  1e5909:	c4 e2 ad b8 e1       	vfmadd231pd %ymm1,%ymm10,%ymm4
  1e590e:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  1e5913:	c5 7d 10 24 0e       	vmovupd (%rsi,%rcx,1),%ymm12
  1e5918:	c4 e2 9d b8 f1       	vfmadd231pd %ymm1,%ymm12,%ymm6
  1e591d:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  1e5922:	c5 fd 10 0c 0e       	vmovupd (%rsi,%rcx,1),%ymm1
  1e5927:	c4 62 f5 b8 d8       	vfmadd231pd %ymm0,%ymm1,%ymm11
  1e592c:	c4 62 f5 b8 ca       	vfmadd231pd %ymm2,%ymm1,%ymm9
  1e5931:	c4 c2 f5 b8 da       	vfmadd231pd %ymm10,%ymm1,%ymm3
  1e5936:	c4 e2 9d b8 e9       	vfmadd231pd %ymm1,%ymm12,%ymm5
  1e593b:	c4 e3 7d 19 f8 01    	vextractf128 $0x1,%ymm7,%xmm0
  1e5941:	c5 c1 58 c0          	vaddpd %xmm0,%xmm7,%xmm0
  1e5945:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e594a:	c5 fb 58 f9          	vaddsd %xmm1,%xmm0,%xmm7
  1e594e:	c4 63 7d 19 c0 01    	vextractf128 $0x1,%ymm8,%xmm0
  1e5954:	c5 b9 58 c0          	vaddpd %xmm0,%xmm8,%xmm0
  1e5958:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e595d:	c5 7b 58 d1          	vaddsd %xmm1,%xmm0,%xmm10
  1e5961:	c4 e3 7d 19 e0 01    	vextractf128 $0x1,%ymm4,%xmm0
  1e5967:	c5 d9 58 c0          	vaddpd %xmm0,%xmm4,%xmm0
  1e596b:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e5970:	c5 fb 58 e1          	vaddsd %xmm1,%xmm0,%xmm4
  1e5974:	c4 e3 7d 19 f0 01    	vextractf128 $0x1,%ymm6,%xmm0
  1e597a:	c5 c9 58 c0          	vaddpd %xmm0,%xmm6,%xmm0
  1e597e:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e5983:	c5 7b 58 c1          	vaddsd %xmm1,%xmm0,%xmm8
  1e5987:	c4 63 7d 19 d8 01    	vextractf128 $0x1,%ymm11,%xmm0
  1e598d:	c5 a1 58 c0          	vaddpd %xmm0,%xmm11,%xmm0
  1e5991:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e5996:	c5 fb 58 f1          	vaddsd %xmm1,%xmm0,%xmm6
  1e599a:	c4 63 7d 19 c8 01    	vextractf128 $0x1,%ymm9,%xmm0
  1e59a0:	c5 b1 58 c0          	vaddpd %xmm0,%xmm9,%xmm0
  1e59a4:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e59a9:	c5 7b 58 c9          	vaddsd %xmm1,%xmm0,%xmm9
  1e59ad:	c4 e3 7d 19 d8 01    	vextractf128 $0x1,%ymm3,%xmm0
  1e59b3:	c5 e1 58 c0          	vaddpd %xmm0,%xmm3,%xmm0
  1e59b7:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e59bc:	c5 fb 58 d9          	vaddsd %xmm1,%xmm0,%xmm3
  1e59c0:	c4 e3 7d 19 e8 01    	vextractf128 $0x1,%ymm5,%xmm0
  1e59c6:	c5 d1 58 c0          	vaddpd %xmm0,%xmm5,%xmm0
  1e59ca:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  1e59cf:	c5 fb 58 e9          	vaddsd %xmm1,%xmm0,%xmm5
  1e59d3:	48 83 bc 24 e0 03 00 	cmpq   $0x0,0x3e0(%rsp)
  1e59da:	00 00 
  1e59dc:	48 8b b4 24 60 02 00 	mov    0x260(%rsp),%rsi
  1e59e3:	00 
  1e59e4:	4c 8b 8c 24 00 03 00 	mov    0x300(%rsp),%r9
  1e59eb:	00 
  1e59ec:	0f 84 6c 01 00 00    	je     1e5b5e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x59ee>
  1e59f2:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  1e59f9:	00 
  1e59fa:	3b 8c 24 c0 02 00 00 	cmp    0x2c0(%rsp),%ecx
  1e5a01:	0f 84 81 0a 00 00    	je     1e6488 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6318>
  1e5a07:	48 83 bc 24 10 05 00 	cmpq   $0x0,0x510(%rsp)
  1e5a0e:	00 00 
  1e5a10:	0f 84 d0 00 00 00    	je     1e5ae6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5976>
  1e5a16:	4c 8b 84 24 50 05 00 	mov    0x550(%rsp),%r8
  1e5a1d:	00 
  1e5a1e:	4d 01 c3             	add    %r8,%r11
  1e5a21:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  1e5a26:	49 01 c8             	add    %rcx,%r8
  1e5a29:	31 c9                	xor    %ecx,%ecx
  1e5a2b:	c4 c1 7b 10 44 c9 f8 	vmovsd -0x8(%r9,%rcx,8),%xmm0
  1e5a32:	c4 c1 7b 10 4c cb f8 	vmovsd -0x8(%r11,%rcx,8),%xmm1
  1e5a39:	c4 e2 f9 b9 f9       	vfmadd231sd %xmm1,%xmm0,%xmm7
  1e5a3e:	c5 fb 10 54 cd f8    	vmovsd -0x8(%rbp,%rcx,8),%xmm2
  1e5a44:	c4 62 e9 b9 d1       	vfmadd231sd %xmm1,%xmm2,%xmm10
  1e5a49:	c4 41 7b 10 5c cc f8 	vmovsd -0x8(%r12,%rcx,8),%xmm11
  1e5a50:	c4 e2 a1 b9 e1       	vfmadd231sd %xmm1,%xmm11,%xmm4
  1e5a55:	c4 41 7b 10 64 ca f8 	vmovsd -0x8(%r10,%rcx,8),%xmm12
  1e5a5c:	c4 62 99 b9 c1       	vfmadd231sd %xmm1,%xmm12,%xmm8
  1e5a61:	c4 c1 7b 10 4c c8 f8 	vmovsd -0x8(%r8,%rcx,8),%xmm1
  1e5a68:	c4 e2 f1 b9 f0       	vfmadd231sd %xmm0,%xmm1,%xmm6
  1e5a6d:	c4 c1 7b 10 04 c9    	vmovsd (%r9,%rcx,8),%xmm0
  1e5a73:	c4 62 f1 b9 ca       	vfmadd231sd %xmm2,%xmm1,%xmm9
  1e5a78:	c4 c1 7b 10 14 cb    	vmovsd (%r11,%rcx,8),%xmm2
  1e5a7e:	c4 c2 f1 b9 db       	vfmadd231sd %xmm11,%xmm1,%xmm3
  1e5a83:	c5 7b 10 5c cd 00    	vmovsd 0x0(%rbp,%rcx,8),%xmm11
  1e5a89:	c4 e2 99 b9 e9       	vfmadd231sd %xmm1,%xmm12,%xmm5
  1e5a8e:	c4 c1 7b 10 0c cc    	vmovsd (%r12,%rcx,8),%xmm1
  1e5a94:	c4 41 7b 10 24 ca    	vmovsd (%r10,%rcx,8),%xmm12
  1e5a9a:	c4 e2 f9 b9 fa       	vfmadd231sd %xmm2,%xmm0,%xmm7
  1e5a9f:	c4 62 a1 b9 d2       	vfmadd231sd %xmm2,%xmm11,%xmm10
  1e5aa4:	c4 e2 f1 b9 e2       	vfmadd231sd %xmm2,%xmm1,%xmm4
  1e5aa9:	c4 62 99 b9 c2       	vfmadd231sd %xmm2,%xmm12,%xmm8
  1e5aae:	c4 c1 7b 10 14 c8    	vmovsd (%r8,%rcx,8),%xmm2
  1e5ab4:	c4 e2 e9 b9 f0       	vfmadd231sd %xmm0,%xmm2,%xmm6
  1e5ab9:	c4 42 e9 b9 cb       	vfmadd231sd %xmm11,%xmm2,%xmm9
  1e5abe:	c4 e2 e9 b9 d9       	vfmadd231sd %xmm1,%xmm2,%xmm3
  1e5ac3:	c4 e2 99 b9 ea       	vfmadd231sd %xmm2,%xmm12,%xmm5
  1e5ac8:	48 83 c1 02          	add    $0x2,%rcx
  1e5acc:	48 39 ce             	cmp    %rcx,%rsi
  1e5acf:	0f 85 56 ff ff ff    	jne    1e5a2b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x58bb>
  1e5ad5:	f6 84 24 88 02 00 00 	testb  $0x1,0x288(%rsp)
  1e5adc:	01 
  1e5add:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
  1e5ae2:	75 04                	jne    1e5ae8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5978>
  1e5ae4:	eb 78                	jmp    1e5b5e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x59ee>
  1e5ae6:	31 c9                	xor    %ecx,%ecx
  1e5ae8:	48 8b b4 24 80 04 00 	mov    0x480(%rsp),%rsi
  1e5aef:	00 
  1e5af0:	c5 fb 10 04 ce       	vmovsd (%rsi,%rcx,8),%xmm0
  1e5af5:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
  1e5afc:	00 
  1e5afd:	c5 fb 10 0c ce       	vmovsd (%rsi,%rcx,8),%xmm1
  1e5b02:	c4 e2 f9 b9 f9       	vfmadd231sd %xmm1,%xmm0,%xmm7
  1e5b07:	48 8b b4 24 70 05 00 	mov    0x570(%rsp),%rsi
  1e5b0e:	00 
  1e5b0f:	c5 fb 10 14 ce       	vmovsd (%rsi,%rcx,8),%xmm2
  1e5b14:	c4 62 e9 b9 d1       	vfmadd231sd %xmm1,%xmm2,%xmm10
  1e5b19:	48 8b b4 24 60 04 00 	mov    0x460(%rsp),%rsi
  1e5b20:	00 
  1e5b21:	c5 7b 10 1c ce       	vmovsd (%rsi,%rcx,8),%xmm11
  1e5b26:	c4 e2 a1 b9 e1       	vfmadd231sd %xmm1,%xmm11,%xmm4
  1e5b2b:	48 8b b4 24 30 05 00 	mov    0x530(%rsp),%rsi
  1e5b32:	00 
  1e5b33:	c5 7b 10 24 ce       	vmovsd (%rsi,%rcx,8),%xmm12
  1e5b38:	c4 62 99 b9 c1       	vfmadd231sd %xmm1,%xmm12,%xmm8
  1e5b3d:	48 8b b4 24 20 02 00 	mov    0x220(%rsp),%rsi
  1e5b44:	00 
  1e5b45:	c5 fb 10 0c ce       	vmovsd (%rsi,%rcx,8),%xmm1
  1e5b4a:	c4 e2 f1 b9 f0       	vfmadd231sd %xmm0,%xmm1,%xmm6
  1e5b4f:	c4 62 f1 b9 ca       	vfmadd231sd %xmm2,%xmm1,%xmm9
  1e5b54:	c4 c2 f1 b9 db       	vfmadd231sd %xmm11,%xmm1,%xmm3
  1e5b59:	c4 e2 99 b9 e9       	vfmadd231sd %xmm1,%xmm12,%xmm5
  1e5b5e:	48 3b 7c 24 18       	cmp    0x18(%rsp),%rdi
  1e5b63:	48 8b b4 24 40 02 00 	mov    0x240(%rsp),%rsi
  1e5b6a:	00 
  1e5b6b:	0f 83 c2 08 00 00    	jae    1e6433 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x62c3>
  1e5b71:	48 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%rcx
  1e5b78:	00 
  1e5b79:	c5 fb 11 3c 31       	vmovsd %xmm7,(%rcx,%rsi,1)
  1e5b7e:	c5 7b 11 54 31 08    	vmovsd %xmm10,0x8(%rcx,%rsi,1)
  1e5b84:	48 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%rcx
  1e5b8b:	00 
  1e5b8c:	48 3b 8c 24 f0 00 00 	cmp    0xf0(%rsp),%rcx
  1e5b93:	00 
  1e5b94:	73 25                	jae    1e5bbb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x5a4b>
  1e5b96:	48 ff c7             	inc    %rdi
  1e5b99:	48 3b 7c 24 18       	cmp    0x18(%rsp),%rdi
  1e5b9e:	0f 83 12 09 00 00    	jae    1e64b6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x6346>
  1e5ba4:	48 c1 e7 04          	shl    $0x4,%rdi
  1e5ba8:	48 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%rcx
  1e5baf:	00 
  1e5bb0:	c5 fb 11 24 39       	vmovsd %xmm4,(%rcx,%rdi,1)
  1e5bb5:	c5 7b 11 44 39 08    	vmovsd %xmm8,0x8(%rcx,%rdi,1)
  1e5bbb:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  1e5bc0:	0f 83 82 08 00 00    	jae    1e6448 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x62d8>
  1e5bc6:	48 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%rcx
  1e5bcd:	00 
  1e5bce:	48 8b b4 24 20 03 00 	mov    0x320(%rsp),%rsi
  1e5bd5:	00 
  1e5bd6:	c5 fb 11 34 31       	vmovsd %xmm6,(%rcx,%rsi,1)
  1e5bdb:	c5 7b 11 4c 31 08    	vmovsd %xmm9,0x8(%rcx,%rsi,1)
  1e5be1:	4c 3b ac 24 f0 00 00 	cmp    0xf0(%rsp),%r13
  1e5be8:	00 
  1e5be9:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
  1e5bee:	0f 83 6a f1 ff ff    	jae    1e4d5e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4bee>
  1e5bf4:	48 ff c0             	inc    %rax
  1e5bf7:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  1e5bfc:	0f 82 45 f1 ff ff    	jb     1e4d47 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedCheckedScaledAnalysisPairChannels<true>>>+0x4bd7>
  1e5c02:	48 8d 15 07 97 0f 00 	lea    0xf9707(%rip),%rdx        # 2df310 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1160>
  1e5c09:	48 89 c7             	mov    %rax,%rdi
  1e5c0c:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1e5c11:	c5 f8 77             	vzeroupper
  1e5c14:	ff 15 b6 44 10 00    	call   *0x1044b6(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5c1a:	48 8d 15 17 93 0f 00 	lea    0xf9317(%rip),%rdx        # 2def38 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xd88>
  1e5c21:	48 89 cf             	mov    %rcx,%rdi
  1e5c24:	48 89 ce             	mov    %rcx,%rsi
  1e5c27:	c5 f8 77             	vzeroupper
  1e5c2a:	ff 15 a0 44 10 00    	call   *0x1044a0(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5c30:	48 8d 15 01 93 0f 00 	lea    0xf9301(%rip),%rdx        # 2def38 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xd88>
  1e5c37:	48 89 f7             	mov    %rsi,%rdi
  1e5c3a:	c5 f8 77             	vzeroupper
  1e5c3d:	ff 15 8d 44 10 00    	call   *0x10448d(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5c43:	48 8b 84 24 10 05 00 	mov    0x510(%rsp),%rax
  1e5c4a:	00 
  1e5c4b:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
  1e5c52:	00 
  1e5c53:	48 8d 15 56 93 0f 00 	lea    0xf9356(%rip),%rdx        # 2defb0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe00>
  1e5c5a:	4c 89 ef             	mov    %r13,%rdi
  1e5c5d:	48 8b b4 24 60 02 00 	mov    0x260(%rsp),%rsi
  1e5c64:	00 
  1e5c65:	c5 f8 77             	vzeroupper
  1e5c68:	ff 15 62 44 10 00    	call   *0x104462(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5c6e:	48 8b 84 24 80 04 00 	mov    0x480(%rsp),%rax
  1e5c75:	00 
  1e5c76:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  1e5c7d:	00 
  1e5c7e:	48 8d 15 43 93 0f 00 	lea    0xf9343(%rip),%rdx        # 2defc8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe18>
  1e5c85:	4c 89 ef             	mov    %r13,%rdi
  1e5c88:	48 8b b4 24 00 03 00 	mov    0x300(%rsp),%rsi
  1e5c8f:	00 
  1e5c90:	c5 f8 77             	vzeroupper
  1e5c93:	ff 15 37 44 10 00    	call   *0x104437(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5c99:	48 8b 84 24 60 04 00 	mov    0x460(%rsp),%rax
  1e5ca0:	00 
  1e5ca1:	48 89 84 24 e0 02 00 	mov    %rax,0x2e0(%rsp)
  1e5ca8:	00 
  1e5ca9:	48 8d 15 30 93 0f 00 	lea    0xf9330(%rip),%rdx        # 2defe0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe30>
  1e5cb0:	4c 89 ef             	mov    %r13,%rdi
  1e5cb3:	48 8b b4 24 e0 02 00 	mov    0x2e0(%rsp),%rsi
  1e5cba:	00 
  1e5cbb:	ff 15 0f 44 10 00    	call   *0x10440f(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5cc1:	48 8b 84 24 40 04 00 	mov    0x440(%rsp),%rax
  1e5cc8:	00 
  1e5cc9:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  1e5cd0:	00 
  1e5cd1:	48 8d 15 20 93 0f 00 	lea    0xf9320(%rip),%rdx        # 2deff8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe48>
  1e5cd8:	4c 89 ef             	mov    %r13,%rdi
  1e5cdb:	48 8b b4 24 c0 02 00 	mov    0x2c0(%rsp),%rsi
  1e5ce2:	00 
  1e5ce3:	ff 15 e7 43 10 00    	call   *0x1043e7(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5ce9:	48 8b 84 24 40 04 00 	mov    0x440(%rsp),%rax
  1e5cf0:	00 
  1e5cf1:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
  1e5cf8:	00 
  1e5cf9:	48 8d 15 f8 92 0f 00 	lea    0xf92f8(%rip),%rdx        # 2deff8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe48>
  1e5d00:	4c 89 ef             	mov    %r13,%rdi
  1e5d03:	48 8b b4 24 60 02 00 	mov    0x260(%rsp),%rsi
  1e5d0a:	00 
  1e5d0b:	ff 15 bf 43 10 00    	call   *0x1043bf(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5d11:	48 8b 84 24 60 04 00 	mov    0x460(%rsp),%rax
  1e5d18:	00 
  1e5d19:	48 89 84 24 00 04 00 	mov    %rax,0x400(%rsp)
  1e5d20:	00 
  1e5d21:	48 8d 15 b8 92 0f 00 	lea    0xf92b8(%rip),%rdx        # 2defe0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe30>
  1e5d28:	4c 89 ef             	mov    %r13,%rdi
  1e5d2b:	48 8b b4 24 00 04 00 	mov    0x400(%rsp),%rsi
  1e5d32:	00 
  1e5d33:	ff 15 97 43 10 00    	call   *0x104397(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5d39:	48 8b 84 24 80 04 00 	mov    0x480(%rsp),%rax
  1e5d40:	00 
  1e5d41:	48 89 84 24 20 04 00 	mov    %rax,0x420(%rsp)
  1e5d48:	00 
  1e5d49:	48 8d 15 78 92 0f 00 	lea    0xf9278(%rip),%rdx        # 2defc8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe18>
  1e5d50:	4c 89 ef             	mov    %r13,%rdi
  1e5d53:	48 8b b4 24 20 04 00 	mov    0x420(%rsp),%rsi
  1e5d5a:	00 
  1e5d5b:	c5 f8 77             	vzeroupper
  1e5d5e:	ff 15 6c 43 10 00    	call   *0x10436c(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5d64:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
  1e5d6b:	00 
  1e5d6c:	48 89 84 24 a0 02 00 	mov    %rax,0x2a0(%rsp)
  1e5d73:	00 
  1e5d74:	48 8d 15 35 92 0f 00 	lea    0xf9235(%rip),%rdx        # 2defb0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe00>
  1e5d7b:	4c 89 ef             	mov    %r13,%rdi
  1e5d7e:	48 8b b4 24 a0 02 00 	mov    0x2a0(%rsp),%rsi
  1e5d85:	00 
  1e5d86:	c5 f8 77             	vzeroupper
  1e5d89:	ff 15 41 43 10 00    	call   *0x104341(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5d8f:	48 8d 15 0a 93 0f 00 	lea    0xf930a(%rip),%rdx        # 2df0a0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xef0>
  1e5d96:	4c 89 ef             	mov    %r13,%rdi
  1e5d99:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  1e5d9e:	c5 f8 77             	vzeroupper
  1e5da1:	ff 15 29 43 10 00    	call   *0x104329(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5da7:	48 8d 15 62 92 0f 00 	lea    0xf9262(%rip),%rdx        # 2df010 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe60>
  1e5dae:	4c 89 ef             	mov    %r13,%rdi
  1e5db1:	c5 f8 77             	vzeroupper
  1e5db4:	ff 15 16 43 10 00    	call   *0x104316(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5dba:	48 8d 15 67 92 0f 00 	lea    0xf9267(%rip),%rdx        # 2df028 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe78>
  1e5dc1:	4c 89 ef             	mov    %r13,%rdi
  1e5dc4:	48 8b b4 24 b8 00 00 	mov    0xb8(%rsp),%rsi
  1e5dcb:	00 
  1e5dcc:	c5 f8 77             	vzeroupper
  1e5dcf:	ff 15 fb 42 10 00    	call   *0x1042fb(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5dd5:	48 8d 15 94 92 0f 00 	lea    0xf9294(%rip),%rdx        # 2df070 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xec0>
  1e5ddc:	4c 89 ef             	mov    %r13,%rdi
  1e5ddf:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
  1e5de4:	c5 f8 77             	vzeroupper
  1e5de7:	ff 15 e3 42 10 00    	call   *0x1042e3(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5ded:	48 8d 15 94 92 0f 00 	lea    0xf9294(%rip),%rdx        # 2df088 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xed8>
  1e5df4:	4c 89 ef             	mov    %r13,%rdi
  1e5df7:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
  1e5dfe:	00 
  1e5dff:	c5 f8 77             	vzeroupper
  1e5e02:	ff 15 c8 42 10 00    	call   *0x1042c8(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5e08:	48 8d 15 31 92 0f 00 	lea    0xf9231(%rip),%rdx        # 2df040 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe90>
  1e5e0f:	4c 89 ef             	mov    %r13,%rdi
  1e5e12:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  1e5e19:	00 
  1e5e1a:	c5 f8 77             	vzeroupper
  1e5e1d:	ff 15 ad 42 10 00    	call   *0x1042ad(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5e23:	48 8d 15 2e 92 0f 00 	lea    0xf922e(%rip),%rdx        # 2df058 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xea8>
  1e5e2a:	4c 89 ef             	mov    %r13,%rdi
  1e5e2d:	48 8b b4 24 b0 00 00 	mov    0xb0(%rsp),%rsi
  1e5e34:	00 
  1e5e35:	c5 f8 77             	vzeroupper
  1e5e38:	ff 15 92 42 10 00    	call   *0x104292(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5e3e:	48 8d 15 73 92 0f 00 	lea    0xf9273(%rip),%rdx        # 2df0b8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf08>
  1e5e45:	4c 89 ef             	mov    %r13,%rdi
  1e5e48:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
  1e5e4f:	00 
  1e5e50:	c5 f8 77             	vzeroupper
  1e5e53:	ff 15 77 42 10 00    	call   *0x104277(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5e59:	48 8d 15 70 92 0f 00 	lea    0xf9270(%rip),%rdx        # 2df0d0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf20>
  1e5e60:	4c 89 ef             	mov    %r13,%rdi
  1e5e63:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  1e5e68:	c5 f8 77             	vzeroupper
  1e5e6b:	ff 15 5f 42 10 00    	call   *0x10425f(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5e71:	48 8b 84 24 40 04 00 	mov    0x440(%rsp),%rax
  1e5e78:	00 
  1e5e79:	48 89 84 24 c0 02 00 	mov    %rax,0x2c0(%rsp)
  1e5e80:	00 
  1e5e81:	48 8d 15 10 91 0f 00 	lea    0xf9110(%rip),%rdx        # 2def98 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xde8>
  1e5e88:	48 8b b4 24 c0 02 00 	mov    0x2c0(%rsp),%rsi
  1e5e8f:	00 
  1e5e90:	c5 f8 77             	vzeroupper
  1e5e93:	ff 15 37 42 10 00    	call   *0x104237(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5e99:	48 8b 84 24 10 05 00 	mov    0x510(%rsp),%rax
  1e5ea0:	00 
  1e5ea1:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
  1e5ea8:	00 
  1e5ea9:	48 8d 15 a0 90 0f 00 	lea    0xf90a0(%rip),%rdx        # 2def50 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xda0>
  1e5eb0:	48 8b b4 24 60 02 00 	mov    0x260(%rsp),%rsi
  1e5eb7:	00 
  1e5eb8:	c5 f8 77             	vzeroupper
  1e5ebb:	ff 15 0f 42 10 00    	call   *0x10420f(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5ec1:	48 8b 84 24 80 04 00 	mov    0x480(%rsp),%rax
  1e5ec8:	00 
  1e5ec9:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  1e5ed0:	00 
  1e5ed1:	48 8d 15 90 90 0f 00 	lea    0xf9090(%rip),%rdx        # 2def68 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xdb8>
  1e5ed8:	48 8b b4 24 00 03 00 	mov    0x300(%rsp),%rsi
  1e5edf:	00 
  1e5ee0:	c5 f8 77             	vzeroupper
  1e5ee3:	ff 15 e7 41 10 00    	call   *0x1041e7(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5ee9:	48 8b 84 24 60 04 00 	mov    0x460(%rsp),%rax
  1e5ef0:	00 
  1e5ef1:	48 89 84 24 e0 02 00 	mov    %rax,0x2e0(%rsp)
  1e5ef8:	00 
  1e5ef9:	48 8d 15 80 90 0f 00 	lea    0xf9080(%rip),%rdx        # 2def80 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xdd0>
  1e5f00:	48 8b b4 24 e0 02 00 	mov    0x2e0(%rsp),%rsi
  1e5f07:	00 
  1e5f08:	c5 f8 77             	vzeroupper
  1e5f0b:	ff 15 bf 41 10 00    	call   *0x1041bf(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5f11:	48 8d 15 58 91 0f 00 	lea    0xf9158(%rip),%rdx        # 2df070 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xec0>
  1e5f18:	4c 89 f7             	mov    %r14,%rdi
  1e5f1b:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
  1e5f20:	c5 f8 77             	vzeroupper
  1e5f23:	ff 15 a7 41 10 00    	call   *0x1041a7(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5f29:	48 8d 15 e0 90 0f 00 	lea    0xf90e0(%rip),%rdx        # 2df010 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe60>
  1e5f30:	4c 89 f7             	mov    %r14,%rdi
  1e5f33:	c5 f8 77             	vzeroupper
  1e5f36:	ff 15 94 41 10 00    	call   *0x104194(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5f3c:	48 8d 15 45 91 0f 00 	lea    0xf9145(%rip),%rdx        # 2df088 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xed8>
  1e5f43:	4c 89 f7             	mov    %r14,%rdi
  1e5f46:	48 8b b4 24 a8 00 00 	mov    0xa8(%rsp),%rsi
  1e5f4d:	00 
  1e5f4e:	c5 f8 77             	vzeroupper
  1e5f51:	ff 15 79 41 10 00    	call   *0x104179(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5f57:	48 8d 15 ca 90 0f 00 	lea    0xf90ca(%rip),%rdx        # 2df028 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe78>
  1e5f5e:	4c 89 f7             	mov    %r14,%rdi
  1e5f61:	48 8b b4 24 b8 00 00 	mov    0xb8(%rsp),%rsi
  1e5f68:	00 
  1e5f69:	c5 f8 77             	vzeroupper
  1e5f6c:	ff 15 5e 41 10 00    	call   *0x10415e(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5f72:	48 8d 15 27 91 0f 00 	lea    0xf9127(%rip),%rdx        # 2df0a0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xef0>
  1e5f79:	4c 89 f7             	mov    %r14,%rdi
  1e5f7c:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  1e5f81:	c5 f8 77             	vzeroupper
  1e5f84:	ff 15 46 41 10 00    	call   *0x104146(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5f8a:	48 8d 15 af 90 0f 00 	lea    0xf90af(%rip),%rdx        # 2df040 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xe90>
  1e5f91:	4c 89 f7             	mov    %r14,%rdi
  1e5f94:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  1e5f9b:	00 
  1e5f9c:	c5 f8 77             	vzeroupper
  1e5f9f:	ff 15 2b 41 10 00    	call   *0x10412b(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5fa5:	48 8d 15 0c 91 0f 00 	lea    0xf910c(%rip),%rdx        # 2df0b8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf08>
  1e5fac:	4c 89 f7             	mov    %r14,%rdi
  1e5faf:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
  1e5fb6:	00 
  1e5fb7:	c5 f8 77             	vzeroupper
  1e5fba:	ff 15 10 41 10 00    	call   *0x104110(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5fc0:	48 8d 15 91 90 0f 00 	lea    0xf9091(%rip),%rdx        # 2df058 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xea8>
  1e5fc7:	4c 89 f7             	mov    %r14,%rdi
  1e5fca:	48 8b b4 24 b0 00 00 	mov    0xb0(%rsp),%rsi
  1e5fd1:	00 
  1e5fd2:	c5 f8 77             	vzeroupper
  1e5fd5:	ff 15 f5 40 10 00    	call   *0x1040f5(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5fdb:	48 8d 15 ee 90 0f 00 	lea    0xf90ee(%rip),%rdx        # 2df0d0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf20>
  1e5fe2:	4c 89 f7             	mov    %r14,%rdi
  1e5fe5:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  1e5fea:	c5 f8 77             	vzeroupper
  1e5fed:	ff 15 dd 40 10 00    	call   *0x1040dd(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e5ff3:	48 8b 84 24 60 04 00 	mov    0x460(%rsp),%rax
  1e5ffa:	00 
  1e5ffb:	48 89 84 24 00 04 00 	mov    %rax,0x400(%rsp)
  1e6002:	00 
  1e6003:	48 8d 15 76 8f 0f 00 	lea    0xf8f76(%rip),%rdx        # 2def80 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xdd0>
  1e600a:	48 8b b4 24 00 04 00 	mov    0x400(%rsp),%rsi
  1e6011:	00 
  1e6012:	c5 f8 77             	vzeroupper
  1e6015:	ff 15 b5 40 10 00    	call   *0x1040b5(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e601b:	48 8b 84 24 c0 02 00 	mov    0x2c0(%rsp),%rax
  1e6022:	00 
  1e6023:	48 89 84 24 a0 02 00 	mov    %rax,0x2a0(%rsp)
  1e602a:	00 
  1e602b:	48 8d 15 1e 8f 0f 00 	lea    0xf8f1e(%rip),%rdx        # 2def50 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xda0>
  1e6032:	48 8b b4 24 a0 02 00 	mov    0x2a0(%rsp),%rsi
  1e6039:	00 
  1e603a:	c5 f8 77             	vzeroupper
  1e603d:	ff 15 8d 40 10 00    	call   *0x10408d(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6043:	48 8b 84 24 40 04 00 	mov    0x440(%rsp),%rax
  1e604a:	00 
  1e604b:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
  1e6052:	00 
  1e6053:	48 8d 15 3e 8f 0f 00 	lea    0xf8f3e(%rip),%rdx        # 2def98 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xde8>
  1e605a:	48 8b b4 24 60 02 00 	mov    0x260(%rsp),%rsi
  1e6061:	00 
  1e6062:	c5 f8 77             	vzeroupper
  1e6065:	ff 15 65 40 10 00    	call   *0x104065(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e606b:	48 8b 84 24 80 04 00 	mov    0x480(%rsp),%rax
  1e6072:	00 
  1e6073:	48 89 84 24 20 04 00 	mov    %rax,0x420(%rsp)
  1e607a:	00 
  1e607b:	48 8d 15 e6 8e 0f 00 	lea    0xf8ee6(%rip),%rdx        # 2def68 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xdb8>
  1e6082:	48 8b b4 24 20 04 00 	mov    0x420(%rsp),%rsi
  1e6089:	00 
  1e608a:	c5 f8 77             	vzeroupper
  1e608d:	ff 15 3d 40 10 00    	call   *0x10403d(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6093:	48 8d 15 8e 86 0f 00 	lea    0xf868e(%rip),%rdx        # 2de728 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x578>
  1e609a:	48 8b bc 24 88 00 00 	mov    0x88(%rsp),%rdi
  1e60a1:	00 
  1e60a2:	48 89 fe             	mov    %rdi,%rsi
  1e60a5:	c5 f8 77             	vzeroupper
  1e60a8:	ff 15 22 40 10 00    	call   *0x104022(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e60ae:	48 8d 15 8b 86 0f 00 	lea    0xf868b(%rip),%rdx        # 2de740 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x590>
  1e60b5:	48 8b bc 24 e0 03 00 	mov    0x3e0(%rsp),%rdi
  1e60bc:	00 
  1e60bd:	48 89 fe             	mov    %rdi,%rsi
  1e60c0:	c5 f8 77             	vzeroupper
  1e60c3:	ff 15 07 40 10 00    	call   *0x104007(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e60c9:	48 8d 15 d0 86 0f 00 	lea    0xf86d0(%rip),%rdx        # 2de7a0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x5f0>
  1e60d0:	4c 89 df             	mov    %r11,%rdi
  1e60d3:	4c 89 de             	mov    %r11,%rsi
  1e60d6:	c5 f8 77             	vzeroupper
  1e60d9:	ff 15 f1 3f 10 00    	call   *0x103ff1(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e60df:	48 8d 15 a2 86 0f 00 	lea    0xf86a2(%rip),%rdx        # 2de788 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x5d8>
  1e60e6:	48 89 fe             	mov    %rdi,%rsi
  1e60e9:	c5 f8 77             	vzeroupper
  1e60ec:	ff 15 de 3f 10 00    	call   *0x103fde(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e60f2:	48 8d 15 77 86 0f 00 	lea    0xf8677(%rip),%rdx        # 2de770 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x5c0>
  1e60f9:	4c 89 cf             	mov    %r9,%rdi
  1e60fc:	4c 89 ce             	mov    %r9,%rsi
  1e60ff:	c5 f8 77             	vzeroupper
  1e6102:	ff 15 c8 3f 10 00    	call   *0x103fc8(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6108:	48 8d 15 c9 90 0f 00 	lea    0xf90c9(%rip),%rdx        # 2df1d8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1028>
  1e610f:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
  1e6116:	00 
  1e6117:	48 89 fe             	mov    %rdi,%rsi
  1e611a:	c5 f8 77             	vzeroupper
  1e611d:	ff 15 ad 3f 10 00    	call   *0x103fad(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6123:	48 8d 15 96 90 0f 00 	lea    0xf9096(%rip),%rdx        # 2df1c0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1010>
  1e612a:	48 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%rdi
  1e6131:	00 
  1e6132:	48 89 fe             	mov    %rdi,%rsi
  1e6135:	c5 f8 77             	vzeroupper
  1e6138:	ff 15 92 3f 10 00    	call   *0x103f92(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e613e:	48 8d 15 63 90 0f 00 	lea    0xf9063(%rip),%rdx        # 2df1a8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xff8>
  1e6145:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
  1e614c:	00 
  1e614d:	48 89 fe             	mov    %rdi,%rsi
  1e6150:	c5 f8 77             	vzeroupper
  1e6153:	ff 15 77 3f 10 00    	call   *0x103f77(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6159:	48 8d 15 30 90 0f 00 	lea    0xf9030(%rip),%rdx        # 2df190 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xfe0>
  1e6160:	48 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%rdi
  1e6167:	00 
  1e6168:	48 89 fe             	mov    %rdi,%rsi
  1e616b:	c5 f8 77             	vzeroupper
  1e616e:	ff 15 5c 3f 10 00    	call   *0x103f5c(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6174:	48 8d 15 fd 8f 0f 00 	lea    0xf8ffd(%rip),%rdx        # 2df178 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xfc8>
  1e617b:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  1e6180:	48 89 fe             	mov    %rdi,%rsi
  1e6183:	c5 f8 77             	vzeroupper
  1e6186:	ff 15 44 3f 10 00    	call   *0x103f44(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e618c:	48 8d 15 cd 8f 0f 00 	lea    0xf8fcd(%rip),%rdx        # 2df160 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xfb0>
  1e6193:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  1e6198:	48 89 fe             	mov    %rdi,%rsi
  1e619b:	c5 f8 77             	vzeroupper
  1e619e:	ff 15 2c 3f 10 00    	call   *0x103f2c(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e61a4:	48 8d 15 55 8f 0f 00 	lea    0xf8f55(%rip),%rdx        # 2df100 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf50>
  1e61ab:	48 89 f7             	mov    %rsi,%rdi
  1e61ae:	c5 f8 77             	vzeroupper
  1e61b1:	ff 15 19 3f 10 00    	call   *0x103f19(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e61b7:	48 8d 15 92 84 0f 00 	lea    0xf8492(%rip),%rdx        # 2de650 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x4a0>
  1e61be:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  1e61c5:	00 
  1e61c6:	48 89 fe             	mov    %rdi,%rsi
  1e61c9:	c5 f8 77             	vzeroupper
  1e61cc:	ff 15 fe 3e 10 00    	call   *0x103efe(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e61d2:	48 8d 15 5f 84 0f 00 	lea    0xf845f(%rip),%rdx        # 2de638 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x488>
  1e61d9:	4c 89 cf             	mov    %r9,%rdi
  1e61dc:	4c 89 ce             	mov    %r9,%rsi
  1e61df:	c5 f8 77             	vzeroupper
  1e61e2:	ff 15 e8 3e 10 00    	call   *0x103ee8(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e61e8:	48 8d 15 d9 84 0f 00 	lea    0xf84d9(%rip),%rdx        # 2de6c8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x518>
  1e61ef:	c5 f8 77             	vzeroupper
  1e61f2:	ff 15 d8 3e 10 00    	call   *0x103ed8(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e61f8:	48 8d 15 e1 84 0f 00 	lea    0xf84e1(%rip),%rdx        # 2de6e0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x530>
  1e61ff:	4c 89 c6             	mov    %r8,%rsi
  1e6202:	c5 f8 77             	vzeroupper
  1e6205:	ff 15 c5 3e 10 00    	call   *0x103ec5(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e620b:	48 89 cf             	mov    %rcx,%rdi
  1e620e:	48 8d 15 33 8f 0f 00 	lea    0xf8f33(%rip),%rdx        # 2df148 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf98>
  1e6215:	48 89 ce             	mov    %rcx,%rsi
  1e6218:	c5 f8 77             	vzeroupper
  1e621b:	ff 15 af 3e 10 00    	call   *0x103eaf(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6221:	48 89 c7             	mov    %rax,%rdi
  1e6224:	48 8d 15 05 8f 0f 00 	lea    0xf8f05(%rip),%rdx        # 2df130 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf80>
  1e622b:	48 89 c6             	mov    %rax,%rsi
  1e622e:	c5 f8 77             	vzeroupper
  1e6231:	ff 15 99 3e 10 00    	call   *0x103e99(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6237:	48 8d 15 da 8e 0f 00 	lea    0xf8eda(%rip),%rdx        # 2df118 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf68>
  1e623e:	48 89 fe             	mov    %rdi,%rsi
  1e6241:	c5 f8 77             	vzeroupper
  1e6244:	ff 15 86 3e 10 00    	call   *0x103e86(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e624a:	48 8d 15 c7 8e 0f 00 	lea    0xf8ec7(%rip),%rdx        # 2df118 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf68>
  1e6251:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  1e6256:	48 89 fe             	mov    %rdi,%rsi
  1e6259:	c5 f8 77             	vzeroupper
  1e625c:	ff 15 6e 3e 10 00    	call   *0x103e6e(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6262:	48 8d 15 c7 8e 0f 00 	lea    0xf8ec7(%rip),%rdx        # 2df130 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf80>
  1e6269:	48 89 fe             	mov    %rdi,%rsi
  1e626c:	c5 f8 77             	vzeroupper
  1e626f:	ff 15 5b 3e 10 00    	call   *0x103e5b(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6275:	48 89 d7             	mov    %rdx,%rdi
  1e6278:	48 8d 15 c9 8e 0f 00 	lea    0xf8ec9(%rip),%rdx        # 2df148 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xf98>
  1e627f:	48 89 fe             	mov    %rdi,%rsi
  1e6282:	c5 f8 77             	vzeroupper
  1e6285:	ff 15 45 3e 10 00    	call   *0x103e45(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e628b:	48 8d 15 66 84 0f 00 	lea    0xf8466(%rip),%rdx        # 2de6f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x548>
  1e6292:	c5 f8 77             	vzeroupper
  1e6295:	ff 15 35 3e 10 00    	call   *0x103e35(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e629b:	48 8d 15 6e 84 0f 00 	lea    0xf846e(%rip),%rdx        # 2de710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x560>
  1e62a2:	4c 89 c6             	mov    %r8,%rsi
  1e62a5:	c5 f8 77             	vzeroupper
  1e62a8:	ff 15 22 3e 10 00    	call   *0x103e22(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e62ae:	48 8d 15 b3 83 0f 00 	lea    0xf83b3(%rip),%rdx        # 2de668 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x4b8>
  1e62b5:	c5 f8 77             	vzeroupper
  1e62b8:	ff 15 12 3e 10 00    	call   *0x103e12(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e62be:	48 8d 15 bb 83 0f 00 	lea    0xf83bb(%rip),%rdx        # 2de680 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x4d0>
  1e62c5:	4c 89 d6             	mov    %r10,%rsi
  1e62c8:	c5 f8 77             	vzeroupper
  1e62cb:	ff 15 ff 3d 10 00    	call   *0x103dff(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e62d1:	48 8d 15 c0 83 0f 00 	lea    0xf83c0(%rip),%rdx        # 2de698 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x4e8>
  1e62d8:	c5 f8 77             	vzeroupper
  1e62db:	ff 15 ef 3d 10 00    	call   *0x103def(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e62e1:	48 8d 15 c8 83 0f 00 	lea    0xf83c8(%rip),%rdx        # 2de6b0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x500>
  1e62e8:	4c 89 d6             	mov    %r10,%rsi
  1e62eb:	c5 f8 77             	vzeroupper
  1e62ee:	ff 15 dc 3d 10 00    	call   *0x103ddc(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e62f4:	48 8d 15 bd 84 0f 00 	lea    0xf84bd(%rip),%rdx        # 2de7b8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x608>
  1e62fb:	48 8b bc 24 c0 01 00 	mov    0x1c0(%rsp),%rdi
  1e6302:	00 
  1e6303:	48 8b b4 24 08 01 00 	mov    0x108(%rsp),%rsi
  1e630a:	00 
  1e630b:	c5 f8 77             	vzeroupper
  1e630e:	ff 15 bc 3d 10 00    	call   *0x103dbc(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6314:	48 8d 15 b5 84 0f 00 	lea    0xf84b5(%rip),%rdx        # 2de7d0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x620>
  1e631b:	48 8b bc 24 b0 01 00 	mov    0x1b0(%rsp),%rdi
  1e6322:	00 
  1e6323:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  1e632a:	00 
  1e632b:	c5 f8 77             	vzeroupper
  1e632e:	ff 15 9c 3d 10 00    	call   *0x103d9c(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6334:	48 8d 15 bd 8f 0f 00 	lea    0xf8fbd(%rip),%rdx        # 2df2f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1148>
  1e633b:	48 89 cf             	mov    %rcx,%rdi
  1e633e:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1e6343:	c5 f8 77             	vzeroupper
  1e6346:	ff 15 84 3d 10 00    	call   *0x103d84(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e634c:	48 8d 15 a5 8f 0f 00 	lea    0xf8fa5(%rip),%rdx        # 2df2f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1148>
  1e6353:	48 89 cf             	mov    %rcx,%rdi
  1e6356:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1e635b:	c5 f8 77             	vzeroupper
  1e635e:	ff 15 6c 3d 10 00    	call   *0x103d6c(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6364:	48 8d 15 25 88 0f 00 	lea    0xf8825(%rip),%rdx        # 2deb90 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9e0>
  1e636b:	48 89 fe             	mov    %rdi,%rsi
  1e636e:	c5 f8 77             	vzeroupper
  1e6371:	ff 15 59 3d 10 00    	call   *0x103d59(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6377:	48 8d 15 92 8f 0f 00 	lea    0xf8f92(%rip),%rdx        # 2df310 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1160>
  1e637e:	48 89 f7             	mov    %rsi,%rdi
  1e6381:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1e6386:	c5 f8 77             	vzeroupper
  1e6389:	ff 15 41 3d 10 00    	call   *0x103d41(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e638f:	48 8d 15 82 87 0f 00 	lea    0xf8782(%rip),%rdx        # 2deb18 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x968>
  1e6396:	31 ff                	xor    %edi,%edi
  1e6398:	31 f6                	xor    %esi,%esi
  1e639a:	c5 f8 77             	vzeroupper
  1e639d:	ff 15 2d 3d 10 00    	call   *0x103d2d(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e63a3:	48 8d 15 3e 84 0f 00 	lea    0xf843e(%rip),%rdx        # 2de7e8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x638>
  1e63aa:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  1e63af:	48 8b b4 24 08 01 00 	mov    0x108(%rsp),%rsi
  1e63b6:	00 
  1e63b7:	c5 f8 77             	vzeroupper
  1e63ba:	ff 15 10 3d 10 00    	call   *0x103d10(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e63c0:	48 89 f7             	mov    %rsi,%rdi
  1e63c3:	48 8d 15 36 84 0f 00 	lea    0xf8436(%rip),%rdx        # 2de800 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x650>
  1e63ca:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  1e63d1:	00 
  1e63d2:	c5 f8 77             	vzeroupper
  1e63d5:	ff 15 f5 3c 10 00    	call   *0x103cf5(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e63db:	48 8d 15 36 84 0f 00 	lea    0xf8436(%rip),%rdx        # 2de818 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x668>
  1e63e2:	48 8b b4 24 08 01 00 	mov    0x108(%rsp),%rsi
  1e63e9:	00 
  1e63ea:	c5 f8 77             	vzeroupper
  1e63ed:	ff 15 dd 3c 10 00    	call   *0x103cdd(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e63f3:	48 8d 15 36 84 0f 00 	lea    0xf8436(%rip),%rdx        # 2de830 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x680>
  1e63fa:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  1e6401:	00 
  1e6402:	c5 f8 77             	vzeroupper
  1e6405:	ff 15 c5 3c 10 00    	call   *0x103cc5(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e640b:	48 8d 15 e6 8e 0f 00 	lea    0xf8ee6(%rip),%rdx        # 2df2f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1148>
  1e6412:	c5 f8 77             	vzeroupper
  1e6415:	ff 15 b5 3c 10 00    	call   *0x103cb5(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e641b:	48 8d 15 d6 8e 0f 00 	lea    0xf8ed6(%rip),%rdx        # 2df2f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1148>
  1e6422:	48 89 c7             	mov    %rax,%rdi
  1e6425:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1e642a:	c5 f8 77             	vzeroupper
  1e642d:	ff 15 9d 3c 10 00    	call   *0x103c9d(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6433:	48 8d 15 be 8e 0f 00 	lea    0xf8ebe(%rip),%rdx        # 2df2f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1148>
  1e643a:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1e643f:	c5 f8 77             	vzeroupper
  1e6442:	ff 15 88 3c 10 00    	call   *0x103c88(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6448:	48 8d 15 a9 8e 0f 00 	lea    0xf8ea9(%rip),%rdx        # 2df2f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1148>
  1e644f:	48 89 c7             	mov    %rax,%rdi
  1e6452:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1e6457:	c5 f8 77             	vzeroupper
  1e645a:	ff 15 70 3c 10 00    	call   *0x103c70(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6460:	48 8d 15 91 8e 0f 00 	lea    0xf8e91(%rip),%rdx        # 2df2f8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1148>
  1e6467:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1e646c:	c5 f8 77             	vzeroupper
  1e646f:	ff 15 5b 3c 10 00    	call   *0x103c5b(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6475:	48 8d 15 94 8e 0f 00 	lea    0xf8e94(%rip),%rdx        # 2df310 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1160>
  1e647c:	4c 89 cf             	mov    %r9,%rdi
  1e647f:	c5 f8 77             	vzeroupper
  1e6482:	ff 15 48 3c 10 00    	call   *0x103c48(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e6488:	48 8d 15 f9 85 0f 00 	lea    0xf85f9(%rip),%rdx        # 2dea88 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x8d8>
  1e648f:	48 89 cf             	mov    %rcx,%rdi
  1e6492:	48 89 ce             	mov    %rcx,%rsi
  1e6495:	c5 f8 77             	vzeroupper
  1e6498:	ff 15 32 3c 10 00    	call   *0x103c32(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e649e:	48 8d 15 6b 8e 0f 00 	lea    0xf8e6b(%rip),%rdx        # 2df310 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1160>
  1e64a5:	48 89 c7             	mov    %rax,%rdi
  1e64a8:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  1e64ad:	c5 f8 77             	vzeroupper
  1e64b0:	ff 15 1a 3c 10 00    	call   *0x103c1a(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e64b6:	48 8d 15 53 8e 0f 00 	lea    0xf8e53(%rip),%rdx        # 2df310 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x1160>
  1e64bd:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  1e64c2:	c5 f8 77             	vzeroupper
  1e64c5:	ff 15 05 3c 10 00    	call   *0x103c05(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
  1e64cb:	48 8d 15 be 86 0f 00 	lea    0xf86be(%rip),%rdx        # 2deb90 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9e0>
  1e64d2:	48 8b bc 24 e0 03 00 	mov    0x3e0(%rsp),%rdi
  1e64d9:	00 
  1e64da:	48 89 fe             	mov    %rdi,%rsi
  1e64dd:	c5 f8 77             	vzeroupper
  1e64e0:	ff 15 ea 3b 10 00    	call   *0x103bea(%rip)        # 2ea0d0 <_DYNAMIC+0x2b8>
