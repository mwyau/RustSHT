
rustsht-diagnostic-test-binary:     file format elf64-x86-64


Disassembly of section .text:

00000000006a9380 <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>>:
  6a9380:	55                   	push   %rbp
  6a9381:	41 57                	push   %r15
  6a9383:	41 56                	push   %r14
  6a9385:	41 55                	push   %r13
  6a9387:	41 54                	push   %r12
  6a9389:	53                   	push   %rbx
  6a938a:	48 83 ec 78          	sub    $0x78,%rsp
  6a938e:	48 8b 0f             	mov    (%rdi),%rcx
  6a9391:	48 8b 57 08          	mov    0x8(%rdi),%rdx
  6a9395:	48 89 d0             	mov    %rdx,%rax
  6a9398:	48 c1 e8 02          	shr    $0x2,%rax
  6a939c:	4c 8b 4f 10          	mov    0x10(%rdi),%r9
  6a93a0:	4c 8b 57 18          	mov    0x18(%rdi),%r10
  6a93a4:	4d 89 d4             	mov    %r10,%r12
  6a93a7:	49 c1 ec 02          	shr    $0x2,%r12
  6a93ab:	4c 8b 5f 20          	mov    0x20(%rdi),%r11
  6a93af:	4c 8b 77 28          	mov    0x28(%rdi),%r14
  6a93b3:	48 8b 77 30          	mov    0x30(%rdi),%rsi
  6a93b7:	4c 8b 7f 38          	mov    0x38(%rdi),%r15
  6a93bb:	4c 8b 47 40          	mov    0x40(%rdi),%r8
  6a93bf:	48 8b 5f 48          	mov    0x48(%rdi),%rbx
  6a93c3:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  6a93c8:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
  6a93cd:	4c 39 e0             	cmp    %r12,%rax
  6a93d0:	0f 85 45 02 00 00    	jne    6a961b <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x29b>
  6a93d6:	4d 89 f4             	mov    %r14,%r12
  6a93d9:	49 c1 ec 02          	shr    $0x2,%r12
  6a93dd:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6a93e2:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
  6a93e7:	4c 39 e0             	cmp    %r12,%rax
  6a93ea:	0f 85 46 02 00 00    	jne    6a9636 <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x2b6>
  6a93f0:	4d 89 fc             	mov    %r15,%r12
  6a93f3:	49 c1 ec 02          	shr    $0x2,%r12
  6a93f7:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6a93fc:	4c 89 64 24 40       	mov    %r12,0x40(%rsp)
  6a9401:	4c 39 e0             	cmp    %r12,%rax
  6a9404:	0f 85 47 02 00 00    	jne    6a9651 <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x2d1>
  6a940a:	49 89 dc             	mov    %rbx,%r12
  6a940d:	49 c1 ec 02          	shr    $0x2,%r12
  6a9411:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6a9416:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
  6a941b:	4c 39 e0             	cmp    %r12,%rax
  6a941e:	0f 85 48 02 00 00    	jne    6a966c <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x2ec>
  6a9424:	41 89 d4             	mov    %edx,%r12d
  6a9427:	41 83 e4 03          	and    $0x3,%r12d
  6a942b:	45 89 d5             	mov    %r10d,%r13d
  6a942e:	41 83 e5 03          	and    $0x3,%r13d
  6a9432:	4c 89 64 24 50       	mov    %r12,0x50(%rsp)
  6a9437:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
  6a943c:	4d 39 ec             	cmp    %r13,%r12
  6a943f:	0f 85 42 02 00 00    	jne    6a9687 <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x307>
  6a9445:	45 89 f5             	mov    %r14d,%r13d
  6a9448:	41 83 e5 03          	and    $0x3,%r13d
  6a944c:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
  6a9451:	4c 89 6c 24 60       	mov    %r13,0x60(%rsp)
  6a9456:	4d 39 ec             	cmp    %r13,%r12
  6a9459:	0f 85 43 02 00 00    	jne    6a96a2 <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x322>
  6a945f:	45 89 fd             	mov    %r15d,%r13d
  6a9462:	41 83 e5 03          	and    $0x3,%r13d
  6a9466:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
  6a946b:	4c 89 6c 24 68       	mov    %r13,0x68(%rsp)
  6a9470:	4d 39 ec             	cmp    %r13,%r12
  6a9473:	0f 85 44 02 00 00    	jne    6a96bd <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x33d>
  6a9479:	41 89 dd             	mov    %ebx,%r13d
  6a947c:	41 83 e5 03          	and    $0x3,%r13d
  6a9480:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
  6a9485:	4c 89 6c 24 70       	mov    %r13,0x70(%rsp)
  6a948a:	4d 39 ec             	cmp    %r13,%r12
  6a948d:	0f 85 45 02 00 00    	jne    6a96d8 <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x358>
  6a9493:	c4 e2 7d 19 4f 50    	vbroadcastsd 0x50(%rdi),%ymm1
  6a9499:	c4 e2 7d 19 47 58    	vbroadcastsd 0x58(%rdi),%ymm0
  6a949f:	48 85 c0             	test   %rax,%rax
  6a94a2:	0f 84 ac 00 00 00    	je     6a9554 <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x1d4>
  6a94a8:	48 83 f8 01          	cmp    $0x1,%rax
  6a94ac:	75 04                	jne    6a94b2 <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x132>
  6a94ae:	31 ff                	xor    %edi,%edi
  6a94b0:	eb 76                	jmp    6a9528 <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x1a8>
  6a94b2:	49 89 c5             	mov    %rax,%r13
  6a94b5:	49 83 e5 fe          	and    $0xfffffffffffffffe,%r13
  6a94b9:	bd 20 00 00 00       	mov    $0x20,%ebp
  6a94be:	31 ff                	xor    %edi,%edi
  6a94c0:	c4 c1 7d 10 54 2b e0 	vmovupd -0x20(%r11,%rbp,1),%ymm2
  6a94c7:	c4 c1 7c 10 5c 29 e0 	vmovups -0x20(%r9,%rbp,1),%ymm3
  6a94ce:	c5 fc 11 5c 2e e0    	vmovups %ymm3,-0x20(%rsi,%rbp,1)
  6a94d4:	c4 e2 f5 a8 d0       	vfmadd213pd %ymm0,%ymm1,%ymm2
  6a94d9:	c4 c1 7d 10 5c 29 e0 	vmovupd -0x20(%r9,%rbp,1),%ymm3
  6a94e0:	c4 e2 ed a8 5c 29 e0 	vfmadd213pd -0x20(%rcx,%rbp,1),%ymm2,%ymm3
  6a94e7:	c4 c1 7d 11 5c 28 e0 	vmovupd %ymm3,-0x20(%r8,%rbp,1)
  6a94ee:	48 83 c7 02          	add    $0x2,%rdi
  6a94f2:	c4 c1 7d 10 14 2b    	vmovupd (%r11,%rbp,1),%ymm2
  6a94f8:	c4 c1 7c 10 1c 29    	vmovups (%r9,%rbp,1),%ymm3
  6a94fe:	c5 fc 11 1c 2e       	vmovups %ymm3,(%rsi,%rbp,1)
  6a9503:	c4 e2 f5 a8 d0       	vfmadd213pd %ymm0,%ymm1,%ymm2
  6a9508:	c4 c1 7d 10 1c 29    	vmovupd (%r9,%rbp,1),%ymm3
  6a950e:	c4 e2 ed a8 1c 29    	vfmadd213pd (%rcx,%rbp,1),%ymm2,%ymm3
  6a9514:	c4 c1 7d 11 1c 28    	vmovupd %ymm3,(%r8,%rbp,1)
  6a951a:	48 83 c5 40          	add    $0x40,%rbp
  6a951e:	49 39 fd             	cmp    %rdi,%r13
  6a9521:	75 9d                	jne    6a94c0 <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x140>
  6a9523:	f6 c2 04             	test   $0x4,%dl
  6a9526:	74 2c                	je     6a9554 <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x1d4>
  6a9528:	48 c1 e7 05          	shl    $0x5,%rdi
  6a952c:	c4 c1 7d 10 14 3b    	vmovupd (%r11,%rdi,1),%ymm2
  6a9532:	c4 e2 f5 a8 d0       	vfmadd213pd %ymm0,%ymm1,%ymm2
  6a9537:	c4 c1 7c 10 1c 39    	vmovups (%r9,%rdi,1),%ymm3
  6a953d:	c5 fc 11 1c 3e       	vmovups %ymm3,(%rsi,%rdi,1)
  6a9542:	c4 c1 7d 10 1c 39    	vmovupd (%r9,%rdi,1),%ymm3
  6a9548:	c4 e2 ed a8 1c 39    	vfmadd213pd (%rcx,%rdi,1),%ymm2,%ymm3
  6a954e:	c4 c1 7d 11 1c 38    	vmovupd %ymm3,(%r8,%rdi,1)
  6a9554:	4d 85 e4             	test   %r12,%r12
  6a9557:	0f 84 93 00 00 00    	je     6a95f0 <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x270>
  6a955d:	48 bf fc ff ff ff ff 	movabs $0xffffffffffffffc,%rdi
  6a9564:	ff ff 0f 
  6a9567:	48 21 fa             	and    %rdi,%rdx
  6a956a:	49 21 fa             	and    %rdi,%r10
  6a956d:	49 21 fe             	and    %rdi,%r14
  6a9570:	49 21 ff             	and    %rdi,%r15
  6a9573:	c4 81 7b 10 14 f3    	vmovsd (%r11,%r14,8),%xmm2
  6a9579:	c4 e2 f1 a9 d0       	vfmadd213sd %xmm0,%xmm1,%xmm2
  6a957e:	c4 81 7b 10 1c d1    	vmovsd (%r9,%r10,8),%xmm3
  6a9584:	c4 a1 7b 11 1c fe    	vmovsd %xmm3,(%rsi,%r15,8)
  6a958a:	c4 e2 e1 a9 14 d1    	vfmadd213sd (%rcx,%rdx,8),%xmm3,%xmm2
  6a9590:	48 21 fb             	and    %rdi,%rbx
  6a9593:	c4 c1 7b 11 14 d8    	vmovsd %xmm2,(%r8,%rbx,8)
  6a9599:	41 83 fc 01          	cmp    $0x1,%r12d
  6a959d:	74 51                	je     6a95f0 <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x270>
  6a959f:	c4 81 7b 10 54 f3 08 	vmovsd 0x8(%r11,%r14,8),%xmm2
  6a95a6:	c4 e2 f1 a9 d0       	vfmadd213sd %xmm0,%xmm1,%xmm2
  6a95ab:	c4 81 7b 10 5c d1 08 	vmovsd 0x8(%r9,%r10,8),%xmm3
  6a95b2:	c4 a1 7b 11 5c fe 08 	vmovsd %xmm3,0x8(%rsi,%r15,8)
  6a95b9:	c4 e2 e1 a9 54 d1 08 	vfmadd213sd 0x8(%rcx,%rdx,8),%xmm3,%xmm2
  6a95c0:	c4 c1 7b 11 54 d8 08 	vmovsd %xmm2,0x8(%r8,%rbx,8)
  6a95c7:	41 83 fc 02          	cmp    $0x2,%r12d
  6a95cb:	74 23                	je     6a95f0 <<rustsht::legendre::scalar_paired::analysis::tests::B3RecurrenceReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x270>
  6a95cd:	c4 82 f1 b9 44 f3 10 	vfmadd231sd 0x10(%r11,%r14,8),%xmm1,%xmm0
  6a95d4:	c4 81 7b 10 4c d1 10 	vmovsd 0x10(%r9,%r10,8),%xmm1
  6a95db:	c4 a1 7b 11 4c fe 10 	vmovsd %xmm1,0x10(%rsi,%r15,8)
  6a95e2:	c4 e2 f1 a9 44 d1 10 	vfmadd213sd 0x10(%rcx,%rdx,8),%xmm1,%xmm0
  6a95e9:	c4 c1 7b 11 44 d8 10 	vmovsd %xmm0,0x10(%r8,%rbx,8)
  6a95f0:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  6a95f5:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6a95fa:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  6a95ff:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6a9604:	48 8d 44 24 08       	lea    0x8(%rsp),%rax
  6a9609:	48 83 c4 78          	add    $0x78,%rsp
  6a960d:	5b                   	pop    %rbx
  6a960e:	41 5c                	pop    %r12
  6a9610:	41 5d                	pop    %r13
  6a9612:	41 5e                	pop    %r14
  6a9614:	41 5f                	pop    %r15
  6a9616:	5d                   	pop    %rbp
  6a9617:	c5 f8 77             	vzeroupper
  6a961a:	c3                   	ret
  6a961b:	4c 8d 0d fe 22 25 00 	lea    0x2522fe(%rip),%r9        # 8fb920 <anon.3c471167dc082c98c49baec13787986d.8.llvm.17085315686757230396+0x228>
  6a9622:	48 8d 74 24 28       	lea    0x28(%rsp),%rsi
  6a9627:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
  6a962c:	31 ff                	xor    %edi,%edi
  6a962e:	31 c9                	xor    %ecx,%ecx
  6a9630:	ff 15 5a b2 27 00    	call   *0x27b25a(%rip)        # 924890 <_DYNAMIC+0x2b0>
  6a9636:	4c 8d 0d fb 22 25 00 	lea    0x2522fb(%rip),%r9        # 8fb938 <anon.3c471167dc082c98c49baec13787986d.8.llvm.17085315686757230396+0x240>
  6a963d:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
  6a9642:	48 8d 54 24 38       	lea    0x38(%rsp),%rdx
  6a9647:	31 ff                	xor    %edi,%edi
  6a9649:	31 c9                	xor    %ecx,%ecx
  6a964b:	ff 15 3f b2 27 00    	call   *0x27b23f(%rip)        # 924890 <_DYNAMIC+0x2b0>
  6a9651:	4c 8d 0d f8 22 25 00 	lea    0x2522f8(%rip),%r9        # 8fb950 <anon.3c471167dc082c98c49baec13787986d.8.llvm.17085315686757230396+0x258>
  6a9658:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
  6a965d:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
  6a9662:	31 ff                	xor    %edi,%edi
  6a9664:	31 c9                	xor    %ecx,%ecx
  6a9666:	ff 15 24 b2 27 00    	call   *0x27b224(%rip)        # 924890 <_DYNAMIC+0x2b0>
  6a966c:	4c 8d 0d f5 22 25 00 	lea    0x2522f5(%rip),%r9        # 8fb968 <anon.3c471167dc082c98c49baec13787986d.8.llvm.17085315686757230396+0x270>
  6a9673:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
  6a9678:	48 8d 54 24 48       	lea    0x48(%rsp),%rdx
  6a967d:	31 ff                	xor    %edi,%edi
  6a967f:	31 c9                	xor    %ecx,%ecx
  6a9681:	ff 15 09 b2 27 00    	call   *0x27b209(%rip)        # 924890 <_DYNAMIC+0x2b0>
  6a9687:	4c 8d 0d f2 22 25 00 	lea    0x2522f2(%rip),%r9        # 8fb980 <anon.3c471167dc082c98c49baec13787986d.8.llvm.17085315686757230396+0x288>
  6a968e:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
  6a9693:	48 8d 54 24 58       	lea    0x58(%rsp),%rdx
  6a9698:	31 ff                	xor    %edi,%edi
  6a969a:	31 c9                	xor    %ecx,%ecx
  6a969c:	ff 15 ee b1 27 00    	call   *0x27b1ee(%rip)        # 924890 <_DYNAMIC+0x2b0>
  6a96a2:	4c 8d 0d ef 22 25 00 	lea    0x2522ef(%rip),%r9        # 8fb998 <anon.3c471167dc082c98c49baec13787986d.8.llvm.17085315686757230396+0x2a0>
  6a96a9:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
  6a96ae:	48 8d 54 24 60       	lea    0x60(%rsp),%rdx
  6a96b3:	31 ff                	xor    %edi,%edi
  6a96b5:	31 c9                	xor    %ecx,%ecx
  6a96b7:	ff 15 d3 b1 27 00    	call   *0x27b1d3(%rip)        # 924890 <_DYNAMIC+0x2b0>
  6a96bd:	4c 8d 0d ec 22 25 00 	lea    0x2522ec(%rip),%r9        # 8fb9b0 <anon.3c471167dc082c98c49baec13787986d.8.llvm.17085315686757230396+0x2b8>
  6a96c4:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
  6a96c9:	48 8d 54 24 68       	lea    0x68(%rsp),%rdx
  6a96ce:	31 ff                	xor    %edi,%edi
  6a96d0:	31 c9                	xor    %ecx,%ecx
  6a96d2:	ff 15 b8 b1 27 00    	call   *0x27b1b8(%rip)        # 924890 <_DYNAMIC+0x2b0>
  6a96d8:	4c 8d 0d e9 22 25 00 	lea    0x2522e9(%rip),%r9        # 8fb9c8 <anon.3c471167dc082c98c49baec13787986d.8.llvm.17085315686757230396+0x2d0>
  6a96df:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
  6a96e4:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
  6a96e9:	31 ff                	xor    %edi,%edi
  6a96eb:	31 c9                	xor    %ecx,%ecx
  6a96ed:	ff 15 9d b1 27 00    	call   *0x27b19d(%rip)        # 924890 <_DYNAMIC+0x2b0>

rustsht-diagnostic-test-binary:     file format elf64-x86-64


Disassembly of section .text:

00000000006a9fa0 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>>:
  6a9fa0:	55                   	push   %rbp
  6a9fa1:	41 57                	push   %r15
  6a9fa3:	41 56                	push   %r14
  6a9fa5:	41 55                	push   %r13
  6a9fa7:	41 54                	push   %r12
  6a9fa9:	53                   	push   %rbx
  6a9faa:	48 83 ec 68          	sub    $0x68,%rsp
  6a9fae:	48 8b 07             	mov    (%rdi),%rax
  6a9fb1:	48 8b 57 08          	mov    0x8(%rdi),%rdx
  6a9fb5:	49 89 d1             	mov    %rdx,%r9
  6a9fb8:	49 c1 e9 02          	shr    $0x2,%r9
  6a9fbc:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
  6a9fc0:	4c 8b 47 18          	mov    0x18(%rdi),%r8
  6a9fc4:	4d 89 c2             	mov    %r8,%r10
  6a9fc7:	49 c1 ea 02          	shr    $0x2,%r10
  6a9fcb:	48 8b 77 20          	mov    0x20(%rdi),%rsi
  6a9fcf:	48 8b 7f 28          	mov    0x28(%rdi),%rdi
  6a9fd3:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
  6a9fd8:	4c 89 54 24 18       	mov    %r10,0x18(%rsp)
  6a9fdd:	4d 39 d1             	cmp    %r10,%r9
  6a9fe0:	0f 85 a5 04 00 00    	jne    6aa48b <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x4eb>
  6a9fe6:	49 89 fa             	mov    %rdi,%r10
  6a9fe9:	49 c1 ea 02          	shr    $0x2,%r10
  6a9fed:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
  6a9ff2:	4c 89 54 24 20       	mov    %r10,0x20(%rsp)
  6a9ff7:	4d 39 d1             	cmp    %r10,%r9
  6a9ffa:	0f 85 a6 04 00 00    	jne    6aa4a6 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x506>
  6aa000:	89 d5                	mov    %edx,%ebp
  6aa002:	83 e5 03             	and    $0x3,%ebp
  6aa005:	45 89 c2             	mov    %r8d,%r10d
  6aa008:	41 83 e2 03          	and    $0x3,%r10d
  6aa00c:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
  6aa011:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
  6aa016:	4c 39 d5             	cmp    %r10,%rbp
  6aa019:	0f 85 a2 04 00 00    	jne    6aa4c1 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x521>
  6aa01f:	41 89 fa             	mov    %edi,%r10d
  6aa022:	41 83 e2 03          	and    $0x3,%r10d
  6aa026:	48 89 6c 24 40       	mov    %rbp,0x40(%rsp)
  6aa02b:	4c 89 54 24 38       	mov    %r10,0x38(%rsp)
  6aa030:	4c 39 d5             	cmp    %r10,%rbp
  6aa033:	0f 85 a3 04 00 00    	jne    6aa4dc <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x53c>
  6aa039:	b3 01                	mov    $0x1,%bl
  6aa03b:	4d 85 c9             	test   %r9,%r9
  6aa03e:	0f 84 b4 03 00 00    	je     6aa3f8 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x458>
  6aa044:	45 31 d2             	xor    %r10d,%r10d
  6aa047:	c4 e2 7d 19 05 f0 d3 	vbroadcastsd -0x622c10(%rip),%ymm0        # 87440 <anon.0b99e93e68bce6aba665244ab6c960f8.603.llvm.1632719894550172145+0x5b0>
  6aa04e:	9d ff 
  6aa050:	c5 e9 ef d2          	vpxor  %xmm2,%xmm2,%xmm2
  6aa054:	c4 e2 7d 59 1d eb d3 	vpbroadcastq -0x622c15(%rip),%ymm3        # 87448 <anon.0b99e93e68bce6aba665244ab6c960f8.603.llvm.1632719894550172145+0x5b8>
  6aa05b:	9d ff 
  6aa05d:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  6aa061:	c4 e2 7d 19 2d 6e d5 	vbroadcastsd -0x622a92(%rip),%ymm5        # 875d8 <anon.0b99e93e68bce6aba665244ab6c960f8.603.llvm.1632719894550172145+0x748>
  6aa068:	9d ff 
  6aa06a:	c4 e2 7d 19 3d 85 e5 	vbroadcastsd -0x621a7b(%rip),%ymm7        # 885f8 <anon.0b99e93e68bce6aba665244ab6c960f8.392.llvm.1632719894550172145+0xfc0>
  6aa071:	9d ff 
  6aa073:	c4 62 7d 19 05 3c ec 	vbroadcastsd -0x6213c4(%rip),%ymm8        # 88cb8 <anon.9294b98e9307444ffe4df6d6f1e31641.52.llvm.9753170170489185970+0x1b0>
  6aa07a:	9d ff 
  6aa07c:	4d 89 d3             	mov    %r10,%r11
  6aa07f:	49 c1 e3 05          	shl    $0x5,%r11
  6aa083:	c4 21 7d 10 0c 18    	vmovupd (%rax,%r11,1),%ymm9
  6aa089:	c4 21 7d 10 14 19    	vmovupd (%rcx,%r11,1),%ymm10
  6aa08f:	c5 35 54 e0          	vandpd %ymm0,%ymm9,%ymm12
  6aa093:	c5 2d 54 e8          	vandpd %ymm0,%ymm10,%ymm13
  6aa097:	c4 e2 7d 19 0d 70 c7 	vbroadcastsd -0x623890(%rip),%ymm1        # 86810 <GCC_except_table0+0x8f4>
  6aa09e:	9d ff 
  6aa0a0:	c5 1d c2 d9 12       	vcmple_oqpd %ymm1,%ymm12,%ymm11
  6aa0a5:	c5 15 c2 f1 12       	vcmple_oqpd %ymm1,%ymm13,%ymm14
  6aa0aa:	c4 41 0d 54 db       	vandpd %ymm11,%ymm14,%ymm11
  6aa0af:	c4 42 6d 37 db       	vpcmpgtq %ymm11,%ymm2,%ymm11
  6aa0b4:	c5 25 db db          	vpand  %ymm3,%ymm11,%ymm11
  6aa0b8:	c4 43 7d 39 de 01    	vextracti128 $0x1,%ymm11,%xmm14
  6aa0be:	c4 41 21 5d de       	vminpd %xmm14,%xmm11,%xmm11
  6aa0c3:	c4 41 21 c6 f3 01    	vshufpd $0x1,%xmm11,%xmm11,%xmm14
  6aa0c9:	c4 41 23 5d de       	vminsd %xmm14,%xmm11,%xmm11
  6aa0ce:	c5 79 2e dc          	vucomisd %xmm4,%xmm11
  6aa0d2:	0f 86 9d 03 00 00    	jbe    6aa475 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x4d5>
  6aa0d8:	c4 21 7e 6f 1c 1e    	vmovdqu (%rsi,%r11,1),%ymm11
  6aa0de:	c4 41 1d 5f e5       	vmaxpd %ymm13,%ymm12,%ymm12
  6aa0e3:	c5 1d c2 f5 12       	vcmple_oqpd %ymm5,%ymm12,%ymm14
  6aa0e8:	c5 1d c2 ea 00       	vcmpeqpd %ymm2,%ymm12,%ymm13
  6aa0ed:	c4 e2 7d 19 0d 9a d6 	vbroadcastsd -0x622966(%rip),%ymm1        # 87790 <anon.0b99e93e68bce6aba665244ab6c960f8.392.llvm.1632719894550172145+0x158>
  6aa0f4:	9d ff 
  6aa0f6:	c5 1d c2 f9 1d       	vcmpge_oqpd %ymm1,%ymm12,%ymm15
  6aa0fb:	c4 41 05 56 fd       	vorpd  %ymm13,%ymm15,%ymm15
  6aa100:	c4 41 05 54 f6       	vandpd %ymm14,%ymm15,%ymm14
  6aa105:	c4 42 6d 37 f6       	vpcmpgtq %ymm14,%ymm2,%ymm14
  6aa10a:	c5 0d db f3          	vpand  %ymm3,%ymm14,%ymm14
  6aa10e:	c4 43 7d 39 f7 01    	vextracti128 $0x1,%ymm14,%xmm15
  6aa114:	c4 41 09 5d f7       	vminpd %xmm15,%xmm14,%xmm14
  6aa119:	c4 41 09 c6 fe 01    	vshufpd $0x1,%xmm14,%xmm14,%xmm15
  6aa11f:	c4 41 0b 5d f7       	vminsd %xmm15,%xmm14,%xmm14
  6aa124:	c5 79 2e f4          	vucomisd %xmm4,%xmm14
  6aa128:	76 36                	jbe    6aa160 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x1c0>
  6aa12a:	c4 e2 25 29 ca       	vpcmpeqq %ymm2,%ymm11,%ymm1
  6aa12f:	c5 f5 db cb          	vpand  %ymm3,%ymm1,%ymm1
  6aa133:	c4 e3 7d 39 ce 01    	vextracti128 $0x1,%ymm1,%xmm6
  6aa139:	c5 f1 5d ce          	vminpd %xmm6,%xmm1,%xmm1
  6aa13d:	c5 f1 c6 f1 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm6
  6aa142:	c5 f3 5d ce          	vminsd %xmm6,%xmm1,%xmm1
  6aa146:	c5 f9 2e cc          	vucomisd %xmm4,%xmm1
  6aa14a:	0f 86 80 02 00 00    	jbe    6aa3d0 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x430>
  6aa150:	e9 7d 02 00 00       	jmp    6aa3d2 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x432>
  6aa155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6aa15c:	00 00 00 00 
  6aa160:	c5 1d c2 f5 1e       	vcmpgt_oqpd %ymm5,%ymm12,%ymm14
  6aa165:	c4 42 6d 37 fe       	vpcmpgtq %ymm14,%ymm2,%ymm15
  6aa16a:	c5 85 db cb          	vpand  %ymm3,%ymm15,%ymm1
  6aa16e:	c4 e3 7d 39 ce 01    	vextracti128 $0x1,%ymm1,%xmm6
  6aa174:	c5 f1 5f ce          	vmaxpd %xmm6,%xmm1,%xmm1
  6aa178:	c5 f1 c6 f1 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm6
  6aa17d:	c5 f3 5f ce          	vmaxsd %xmm6,%xmm1,%xmm1
  6aa181:	c5 f9 2e cc          	vucomisd %xmm4,%xmm1
  6aa185:	0f 86 c8 00 00 00    	jbe    6aa253 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x2b3>
  6aa18b:	c4 63 7d 39 f9 01    	vextracti128 $0x1,%ymm15,%xmm1
  6aa191:	c5 01 6b e9          	vpackssdw %xmm1,%xmm15,%xmm13
  6aa195:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6aa19c:	00 00 00 00 
  6aa1a0:	c4 e2 7d 59 0d 07 eb 	vpbroadcastq -0x6214f9(%rip),%ymm1        # 88cb0 <anon.9294b98e9307444ffe4df6d6f1e31641.52.llvm.9753170170489185970+0x1a8>
  6aa1a7:	9d ff 
  6aa1a9:	c4 e2 25 37 c9       	vpcmpgtq %ymm1,%ymm11,%ymm1
  6aa1ae:	c4 c2 6d 37 f6       	vpcmpgtq %ymm14,%ymm2,%ymm6
  6aa1b3:	c5 cd db f3          	vpand  %ymm3,%ymm6,%ymm6
  6aa1b7:	c5 f5 db ce          	vpand  %ymm6,%ymm1,%ymm1
  6aa1bb:	c4 e3 7d 39 ce 01    	vextracti128 $0x1,%ymm1,%xmm6
  6aa1c1:	c5 f1 5f ce          	vmaxpd %xmm6,%xmm1,%xmm1
  6aa1c5:	c5 f1 c6 f1 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm6
  6aa1ca:	c5 f3 5f ce          	vmaxsd %xmm6,%xmm1,%xmm1
  6aa1ce:	c5 f9 2e cc          	vucomisd %xmm4,%xmm1
  6aa1d2:	0f 87 9d 02 00 00    	ja     6aa475 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x4d5>
  6aa1d8:	c5 b5 59 cf          	vmulpd %ymm7,%ymm9,%ymm1
  6aa1dc:	c4 c1 49 72 f5 1f    	vpslld $0x1f,%xmm13,%xmm6
  6aa1e2:	c5 c9 72 e6 1f       	vpsrad $0x1f,%xmm6,%xmm6
  6aa1e7:	c4 e2 7d 25 f6       	vpmovsxdq %xmm6,%ymm6
  6aa1ec:	c4 63 35 4b c9 60    	vblendvpd %ymm6,%ymm1,%ymm9,%ymm9
  6aa1f2:	c5 ad 59 cf          	vmulpd %ymm7,%ymm10,%ymm1
  6aa1f6:	c4 63 2d 4b d1 60    	vblendvpd %ymm6,%ymm1,%ymm10,%ymm10
  6aa1fc:	c4 e2 7d 59 0d db ca 	vpbroadcastq -0x623525(%rip),%ymm1        # 86ce0 <anon.aa4097ceb990e370c9cbe0d570081e8a.295.llvm.5932341495059967333+0x130>
  6aa203:	9d ff 
  6aa205:	c5 cd db c9          	vpand  %ymm1,%ymm6,%ymm1
  6aa209:	c5 25 d4 d9          	vpaddq %ymm1,%ymm11,%ymm11
  6aa20d:	c5 b5 54 c8          	vandpd %ymm0,%ymm9,%ymm1
  6aa211:	c5 ad 54 f0          	vandpd %ymm0,%ymm10,%ymm6
  6aa215:	c5 75 5f e6          	vmaxpd %ymm6,%ymm1,%ymm12
  6aa219:	c5 1d c2 f5 1e       	vcmpgt_oqpd %ymm5,%ymm12,%ymm14
  6aa21e:	c4 c2 6d 37 ce       	vpcmpgtq %ymm14,%ymm2,%ymm1
  6aa223:	c4 e3 7d 39 ce 01    	vextracti128 $0x1,%ymm1,%xmm6
  6aa229:	c5 71 6b ee          	vpackssdw %xmm6,%xmm1,%xmm13
  6aa22d:	c5 f5 db cb          	vpand  %ymm3,%ymm1,%ymm1
  6aa231:	c4 e3 7d 39 ce 01    	vextracti128 $0x1,%ymm1,%xmm6
  6aa237:	c5 f1 5f ce          	vmaxpd %xmm6,%xmm1,%xmm1
  6aa23b:	c5 f1 c6 f1 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm6
  6aa240:	c5 f3 5f ce          	vmaxsd %xmm6,%xmm1,%xmm1
  6aa244:	c5 f9 2e cc          	vucomisd %xmm4,%xmm1
  6aa248:	0f 87 52 ff ff ff    	ja     6aa1a0 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x200>
  6aa24e:	c5 1d c2 ea 00       	vcmpeqpd %ymm2,%ymm12,%ymm13
  6aa253:	c4 e2 7d 19 0d 34 d5 	vbroadcastsd -0x622acc(%rip),%ymm1        # 87790 <anon.0b99e93e68bce6aba665244ab6c960f8.392.llvm.1632719894550172145+0x158>
  6aa25a:	9d ff 
  6aa25c:	c5 9d c2 c9 11       	vcmplt_oqpd %ymm1,%ymm12,%ymm1
  6aa261:	c5 15 55 f1          	vandnpd %ymm1,%ymm13,%ymm14
  6aa265:	c4 42 6d 37 fe       	vpcmpgtq %ymm14,%ymm2,%ymm15
  6aa26a:	c5 85 db cb          	vpand  %ymm3,%ymm15,%ymm1
  6aa26e:	c4 e3 7d 39 ce 01    	vextracti128 $0x1,%ymm1,%xmm6
  6aa274:	c5 f1 5f ce          	vmaxpd %xmm6,%xmm1,%xmm1
  6aa278:	c5 f1 c6 f1 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm6
  6aa27d:	c5 f3 5f ce          	vmaxsd %xmm6,%xmm1,%xmm1
  6aa281:	c5 f9 2e cc          	vucomisd %xmm4,%xmm1
  6aa285:	0f 86 d8 00 00 00    	jbe    6aa363 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x3c3>
  6aa28b:	c4 63 7d 39 f9 01    	vextracti128 $0x1,%ymm15,%xmm1
  6aa291:	c5 01 6b f9          	vpackssdw %xmm1,%xmm15,%xmm15
  6aa295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6aa29c:	00 00 00 00 
  6aa2a0:	c4 e2 7d 59 0d cf e8 	vpbroadcastq -0x621731(%rip),%ymm1        # 88b78 <anon.9294b98e9307444ffe4df6d6f1e31641.52.llvm.9753170170489185970+0x70>
  6aa2a7:	9d ff 
  6aa2a9:	c4 e2 25 37 c9       	vpcmpgtq %ymm1,%ymm11,%ymm1
  6aa2ae:	c4 c2 6d 37 f6       	vpcmpgtq %ymm14,%ymm2,%ymm6
  6aa2b3:	c5 f5 df ce          	vpandn %ymm6,%ymm1,%ymm1
  6aa2b7:	c5 f5 db cb          	vpand  %ymm3,%ymm1,%ymm1
  6aa2bb:	c4 e3 7d 39 ce 01    	vextracti128 $0x1,%ymm1,%xmm6
  6aa2c1:	c5 f1 5f ce          	vmaxpd %xmm6,%xmm1,%xmm1
  6aa2c5:	c5 f1 c6 f1 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm6
  6aa2ca:	c5 f3 5f ce          	vmaxsd %xmm6,%xmm1,%xmm1
  6aa2ce:	c5 f9 2e cc          	vucomisd %xmm4,%xmm1
  6aa2d2:	0f 87 9d 01 00 00    	ja     6aa475 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x4d5>
  6aa2d8:	c4 e2 7d 59 0d d7 eb 	vpbroadcastq -0x621429(%rip),%ymm1        # 88eb8 <anon.9294b98e9307444ffe4df6d6f1e31641.52.llvm.9753170170489185970+0x3b0>
  6aa2df:	9d ff 
  6aa2e1:	c4 c1 35 59 f0       	vmulpd %ymm8,%ymm9,%ymm6
  6aa2e6:	c4 c1 19 72 f7 1f    	vpslld $0x1f,%xmm15,%xmm12
  6aa2ec:	c4 c1 19 72 e4 1f    	vpsrad $0x1f,%xmm12,%xmm12
  6aa2f2:	c4 42 7d 25 e4       	vpmovsxdq %xmm12,%ymm12
  6aa2f7:	c4 63 35 4b ce c0    	vblendvpd %ymm12,%ymm6,%ymm9,%ymm9
  6aa2fd:	c4 c1 2d 59 f0       	vmulpd %ymm8,%ymm10,%ymm6
  6aa302:	c4 63 2d 4b d6 c0    	vblendvpd %ymm12,%ymm6,%ymm10,%ymm10
  6aa308:	c5 9d db c9          	vpand  %ymm1,%ymm12,%ymm1
  6aa30c:	c5 25 d4 d9          	vpaddq %ymm1,%ymm11,%ymm11
  6aa310:	c5 b5 54 c8          	vandpd %ymm0,%ymm9,%ymm1
  6aa314:	c5 ad 54 f0          	vandpd %ymm0,%ymm10,%ymm6
  6aa318:	c5 75 5f e6          	vmaxpd %ymm6,%ymm1,%ymm12
  6aa31c:	c5 1d c2 ea 00       	vcmpeqpd %ymm2,%ymm12,%ymm13
  6aa321:	c4 e2 7d 19 0d 66 d4 	vbroadcastsd -0x622b9a(%rip),%ymm1        # 87790 <anon.0b99e93e68bce6aba665244ab6c960f8.392.llvm.1632719894550172145+0x158>
  6aa328:	9d ff 
  6aa32a:	c5 9d c2 c9 11       	vcmplt_oqpd %ymm1,%ymm12,%ymm1
  6aa32f:	c5 15 55 f1          	vandnpd %ymm1,%ymm13,%ymm14
  6aa333:	c4 c2 6d 37 ce       	vpcmpgtq %ymm14,%ymm2,%ymm1
  6aa338:	c4 e3 7d 39 ce 01    	vextracti128 $0x1,%ymm1,%xmm6
  6aa33e:	c5 71 6b fe          	vpackssdw %xmm6,%xmm1,%xmm15
  6aa342:	c5 f5 db cb          	vpand  %ymm3,%ymm1,%ymm1
  6aa346:	c4 e3 7d 39 ce 01    	vextracti128 $0x1,%ymm1,%xmm6
  6aa34c:	c5 f1 5f ce          	vmaxpd %xmm6,%xmm1,%xmm1
  6aa350:	c5 f1 c6 f1 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm6
  6aa355:	c5 f3 5f ce          	vmaxsd %xmm6,%xmm1,%xmm1
  6aa359:	c5 f9 2e cc          	vucomisd %xmm4,%xmm1
  6aa35d:	0f 87 3d ff ff ff    	ja     6aa2a0 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x300>
  6aa363:	c4 e2 25 29 ca       	vpcmpeqq %ymm2,%ymm11,%ymm1
  6aa368:	c5 f5 db cb          	vpand  %ymm3,%ymm1,%ymm1
  6aa36c:	c4 e3 7d 39 ce 01    	vextracti128 $0x1,%ymm1,%xmm6
  6aa372:	c5 f1 5d ce          	vminpd %xmm6,%xmm1,%xmm1
  6aa376:	c5 f1 c6 f1 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm6
  6aa37b:	c5 f3 5d ce          	vminsd %xmm6,%xmm1,%xmm1
  6aa37f:	c5 f9 2e cc          	vucomisd %xmm4,%xmm1
  6aa383:	76 4b                	jbe    6aa3d0 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x430>
  6aa385:	c4 e2 7d 19 0d 02 d4 	vbroadcastsd -0x622bfe(%rip),%ymm1        # 87790 <anon.0b99e93e68bce6aba665244ab6c960f8.392.llvm.1632719894550172145+0x158>
  6aa38c:	9d ff 
  6aa38e:	c5 9d c2 c9 1d       	vcmpge_oqpd %ymm1,%ymm12,%ymm1
  6aa393:	c5 95 56 c9          	vorpd  %ymm1,%ymm13,%ymm1
  6aa397:	c5 9d c2 f5 12       	vcmple_oqpd %ymm5,%ymm12,%ymm6
  6aa39c:	c5 f5 54 ce          	vandpd %ymm6,%ymm1,%ymm1
  6aa3a0:	c4 e2 6d 37 c9       	vpcmpgtq %ymm1,%ymm2,%ymm1
  6aa3a5:	c5 f5 db cb          	vpand  %ymm3,%ymm1,%ymm1
  6aa3a9:	c4 e3 7d 39 ce 01    	vextracti128 $0x1,%ymm1,%xmm6
  6aa3af:	c5 f1 5d ce          	vminpd %xmm6,%xmm1,%xmm1
  6aa3b3:	c5 f1 c6 f1 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm6
  6aa3b8:	c5 f3 5d f6          	vminsd %xmm6,%xmm1,%xmm6
  6aa3bc:	c4 e3 71 0d ce 01    	vblendpd $0x1,%xmm6,%xmm1,%xmm1
  6aa3c2:	c5 f9 2e cc          	vucomisd %xmm4,%xmm1
  6aa3c6:	77 0a                	ja     6aa3d2 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x432>
  6aa3c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6aa3cf:	00 
  6aa3d0:	31 db                	xor    %ebx,%ebx
  6aa3d2:	49 ff c2             	inc    %r10
  6aa3d5:	4e 8d 34 18          	lea    (%rax,%r11,1),%r14
  6aa3d9:	4e 8d 3c 19          	lea    (%rcx,%r11,1),%r15
  6aa3dd:	c4 41 7d 11 0e       	vmovupd %ymm9,(%r14)
  6aa3e2:	c4 41 7d 11 17       	vmovupd %ymm10,(%r15)
  6aa3e7:	49 01 f3             	add    %rsi,%r11
  6aa3ea:	c4 41 7e 7f 1b       	vmovdqu %ymm11,(%r11)
  6aa3ef:	4d 39 ca             	cmp    %r9,%r10
  6aa3f2:	0f 85 84 fc ff ff    	jne    6aa07c <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0xdc>
  6aa3f8:	48 85 ed             	test   %rbp,%rbp
  6aa3fb:	74 7a                	je     6aa477 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x4d7>
  6aa3fd:	49 b9 fc ff ff ff ff 	movabs $0xffffffffffffffc,%r9
  6aa404:	ff ff 0f 
  6aa407:	4c 21 ca             	and    %r9,%rdx
  6aa40a:	4c 8d 34 d0          	lea    (%rax,%rdx,8),%r14
  6aa40e:	4d 21 c8             	and    %r9,%r8
  6aa411:	4e 8d 3c c1          	lea    (%rcx,%r8,8),%r15
  6aa415:	4c 21 cf             	and    %r9,%rdi
  6aa418:	4c 8d 24 fe          	lea    (%rsi,%rdi,8),%r12
  6aa41c:	4c 8d 6c 24 40       	lea    0x40(%rsp),%r13
  6aa421:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6aa428:	0f 1f 84 00 00 00 00 
  6aa42f:	00 
  6aa430:	48 c7 04 24 01 00 00 	movq   $0x1,(%rsp)
  6aa437:	00 
  6aa438:	ba 01 00 00 00       	mov    $0x1,%edx
  6aa43d:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  6aa443:	4c 89 ef             	mov    %r13,%rdi
  6aa446:	4c 89 f6             	mov    %r14,%rsi
  6aa449:	4c 89 f9             	mov    %r15,%rcx
  6aa44c:	4d 89 e1             	mov    %r12,%r9
  6aa44f:	c5 f8 77             	vzeroupper
  6aa452:	e8 c9 d8 de ff       	call   497d20 <rustsht::legendre::scalar::normalize_pair_lanes>
  6aa457:	83 7c 24 40 ff       	cmpl   $0xffffffff,0x40(%rsp)
  6aa45c:	75 17                	jne    6aa475 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x4d5>
  6aa45e:	22 5c 24 48          	and    0x48(%rsp),%bl
  6aa462:	49 83 c4 08          	add    $0x8,%r12
  6aa466:	49 83 c7 08          	add    $0x8,%r15
  6aa46a:	49 83 c6 08          	add    $0x8,%r14
  6aa46e:	48 ff cd             	dec    %rbp
  6aa471:	75 bd                	jne    6aa430 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x490>
  6aa473:	eb 02                	jmp    6aa477 <<rustsht::legendre::scalar_paired::analysis::tests::B3NormalizeReplay as pulp::WithSimd>::with_simd::<pulp::x86::v3::V3>+0x4d7>
  6aa475:	b3 02                	mov    $0x2,%bl
  6aa477:	89 d8                	mov    %ebx,%eax
  6aa479:	48 83 c4 68          	add    $0x68,%rsp
  6aa47d:	5b                   	pop    %rbx
  6aa47e:	41 5c                	pop    %r12
  6aa480:	41 5d                	pop    %r13
  6aa482:	41 5e                	pop    %r14
  6aa484:	41 5f                	pop    %r15
  6aa486:	5d                   	pop    %rbp
  6aa487:	c5 f8 77             	vzeroupper
  6aa48a:	c3                   	ret
  6aa48b:	4c 8d 0d 4e 15 25 00 	lea    0x25154e(%rip),%r9        # 8fb9e0 <anon.3c471167dc082c98c49baec13787986d.8.llvm.17085315686757230396+0x2e8>
  6aa492:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  6aa497:	48 8d 54 24 18       	lea    0x18(%rsp),%rdx
  6aa49c:	31 ff                	xor    %edi,%edi
  6aa49e:	31 c9                	xor    %ecx,%ecx
  6aa4a0:	ff 15 ea a3 27 00    	call   *0x27a3ea(%rip)        # 924890 <_DYNAMIC+0x2b0>
  6aa4a6:	4c 8d 0d 4b 15 25 00 	lea    0x25154b(%rip),%r9        # 8fb9f8 <anon.3c471167dc082c98c49baec13787986d.8.llvm.17085315686757230396+0x300>
  6aa4ad:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  6aa4b2:	48 8d 54 24 20       	lea    0x20(%rsp),%rdx
  6aa4b7:	31 ff                	xor    %edi,%edi
  6aa4b9:	31 c9                	xor    %ecx,%ecx
  6aa4bb:	ff 15 cf a3 27 00    	call   *0x27a3cf(%rip)        # 924890 <_DYNAMIC+0x2b0>
  6aa4c1:	4c 8d 0d 48 15 25 00 	lea    0x251548(%rip),%r9        # 8fba10 <anon.3c471167dc082c98c49baec13787986d.8.llvm.17085315686757230396+0x318>
  6aa4c8:	48 8d 74 24 28       	lea    0x28(%rsp),%rsi
  6aa4cd:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
  6aa4d2:	31 ff                	xor    %edi,%edi
  6aa4d4:	31 c9                	xor    %ecx,%ecx
  6aa4d6:	ff 15 b4 a3 27 00    	call   *0x27a3b4(%rip)        # 924890 <_DYNAMIC+0x2b0>
  6aa4dc:	4c 8d 0d 45 15 25 00 	lea    0x251545(%rip),%r9        # 8fba28 <anon.3c471167dc082c98c49baec13787986d.8.llvm.17085315686757230396+0x330>
  6aa4e3:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  6aa4e8:	48 8d 54 24 38       	lea    0x38(%rsp),%rdx
  6aa4ed:	31 ff                	xor    %edi,%edi
  6aa4ef:	31 c9                	xor    %ecx,%ecx
  6aa4f1:	ff 15 99 a3 27 00    	call   *0x27a399(%rip)        # 924890 <_DYNAMIC+0x2b0>
