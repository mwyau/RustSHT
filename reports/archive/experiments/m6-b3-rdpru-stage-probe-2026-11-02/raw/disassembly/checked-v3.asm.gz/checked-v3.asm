
target-plain/release/examples/m6_b3_rdpru_probe:     file format elf64-x86-64


Disassembly of section .text:

000000000019d160 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>>:
  19d160:	55                   	push   rbp
  19d161:	41 57                	push   r15
  19d163:	41 56                	push   r14
  19d165:	41 55                	push   r13
  19d167:	41 54                	push   r12
  19d169:	53                   	push   rbx
  19d16a:	48 81 ec 78 02 00 00 	sub    rsp,0x278
  19d171:	48 8b 87 a0 00 00 00 	mov    rax,QWORD PTR [rdi+0xa0]
  19d178:	48 3b 87 b0 00 00 00 	cmp    rax,QWORD PTR [rdi+0xb0]
  19d17f:	0f 85 2c 2c 00 00    	jne    19fdb1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c51>
  19d185:	4c 8b 7f 10          	mov    r15,QWORD PTR [rdi+0x10]
  19d189:	4c 8b 67 20          	mov    r12,QWORD PTR [rdi+0x20]
  19d18d:	4c 8b 6f 50          	mov    r13,QWORD PTR [rdi+0x50]
  19d191:	4c 8b 4f 60          	mov    r9,QWORD PTR [rdi+0x60]
  19d195:	4c 8b 57 70          	mov    r10,QWORD PTR [rdi+0x70]
  19d199:	4c 8b 9f 80 00 00 00 	mov    r11,QWORD PTR [rdi+0x80]
  19d1a0:	48 8b 9f e0 00 00 00 	mov    rbx,QWORD PTR [rdi+0xe0]
  19d1a7:	4c 8b 87 e8 00 00 00 	mov    r8,QWORD PTR [rdi+0xe8]
  19d1ae:	48 8b 8f c0 00 00 00 	mov    rcx,QWORD PTR [rdi+0xc0]
  19d1b5:	48 31 c1             	xor    rcx,rax
  19d1b8:	4c 89 fa             	mov    rdx,r15
  19d1bb:	48 31 c2             	xor    rdx,rax
  19d1be:	48 09 ca             	or     rdx,rcx
  19d1c1:	4c 89 e1             	mov    rcx,r12
  19d1c4:	48 31 c1             	xor    rcx,rax
  19d1c7:	4c 89 ee             	mov    rsi,r13
  19d1ca:	48 31 c6             	xor    rsi,rax
  19d1cd:	48 09 ce             	or     rsi,rcx
  19d1d0:	48 09 d6             	or     rsi,rdx
  19d1d3:	4c 89 c9             	mov    rcx,r9
  19d1d6:	48 31 c1             	xor    rcx,rax
  19d1d9:	4c 89 d2             	mov    rdx,r10
  19d1dc:	48 31 c2             	xor    rdx,rax
  19d1df:	48 09 ca             	or     rdx,rcx
  19d1e2:	4c 89 d9             	mov    rcx,r11
  19d1e5:	48 31 c1             	xor    rcx,rax
  19d1e8:	48 09 d1             	or     rcx,rdx
  19d1eb:	48 09 f1             	or     rcx,rsi
  19d1ee:	48 85 db             	test   rbx,rbx
  19d1f1:	0f 95 c2             	setne  dl
  19d1f4:	4c 31 c0             	xor    rax,r8
  19d1f7:	48 09 c8             	or     rax,rcx
  19d1fa:	0f 94 c0             	sete   al
  19d1fd:	84 d0                	test   al,dl
  19d1ff:	0f 84 ac 2b 00 00    	je     19fdb1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c51>
  19d205:	4c 39 87 f8 00 00 00 	cmp    QWORD PTR [rdi+0xf8],r8
  19d20c:	0f 85 9f 2b 00 00    	jne    19fdb1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c51>
  19d212:	4c 39 87 08 01 00 00 	cmp    QWORD PTR [rdi+0x108],r8
  19d219:	0f 85 92 2b 00 00    	jne    19fdb1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c51>
  19d21f:	4c 39 87 18 01 00 00 	cmp    QWORD PTR [rdi+0x118],r8
  19d226:	0f 85 85 2b 00 00    	jne    19fdb1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c51>
  19d22c:	4c 89 84 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],r8
  19d233:	00 
  19d234:	4c 8b 87 c8 00 00 00 	mov    r8,QWORD PTR [rdi+0xc8]
  19d23b:	48 8b 8f d0 00 00 00 	mov    rcx,QWORD PTR [rdi+0xd0]
  19d242:	48 8b b7 28 01 00 00 	mov    rsi,QWORD PTR [rdi+0x128]
  19d249:	49 89 ce             	mov    r14,rcx
  19d24c:	4c 89 84 24 58 01 00 	mov    QWORD PTR [rsp+0x158],r8
  19d253:	00 
  19d254:	4d 29 c6             	sub    r14,r8
  19d257:	49 8d 46 01          	lea    rax,[r14+0x1]
  19d25b:	48 39 c6             	cmp    rsi,rax
  19d25e:	0f 82 4d 2b 00 00    	jb     19fdb1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c51>
  19d264:	48 89 fa             	mov    rdx,rdi
  19d267:	4c 89 a4 24 18 01 00 	mov    QWORD PTR [rsp+0x118],r12
  19d26e:	00 
  19d26f:	4c 89 bc 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],r15
  19d276:	00 
  19d277:	48 89 74 24 68       	mov    QWORD PTR [rsp+0x68],rsi
  19d27c:	4c 89 9c 24 80 00 00 	mov    QWORD PTR [rsp+0x80],r11
  19d283:	00 
  19d284:	4c 89 94 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r10
  19d28b:	00 
  19d28c:	4c 89 4c 24 58       	mov    QWORD PTR [rsp+0x58],r9
  19d291:	48 89 4c 24 60       	mov    QWORD PTR [rsp+0x60],rcx
  19d296:	48 8b 82 d8 00 00 00 	mov    rax,QWORD PTR [rdx+0xd8]
  19d29d:	4c 8b 62 18          	mov    r12,QWORD PTR [rdx+0x18]
  19d2a1:	48 8b 4a 28          	mov    rcx,QWORD PTR [rdx+0x28]
  19d2a5:	48 89 8c 24 00 02 00 	mov    QWORD PTR [rsp+0x200],rcx
  19d2ac:	00 
  19d2ad:	48 8b 4a 30          	mov    rcx,QWORD PTR [rdx+0x30]
  19d2b1:	48 89 8c 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rcx
  19d2b8:	00 
  19d2b9:	48 8b 4a 38          	mov    rcx,QWORD PTR [rdx+0x38]
  19d2bd:	48 89 8c 24 f8 01 00 	mov    QWORD PTR [rsp+0x1f8],rcx
  19d2c4:	00 
  19d2c5:	48 8b 4a 40          	mov    rcx,QWORD PTR [rdx+0x40]
  19d2c9:	48 89 8c 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],rcx
  19d2d0:	00 
  19d2d1:	48 8b 4a 48          	mov    rcx,QWORD PTR [rdx+0x48]
  19d2d5:	48 89 4c 24 38       	mov    QWORD PTR [rsp+0x38],rcx
  19d2da:	48 8b 4a 58          	mov    rcx,QWORD PTR [rdx+0x58]
  19d2de:	48 89 4c 24 20       	mov    QWORD PTR [rsp+0x20],rcx
  19d2e3:	4c 8b 4a 68          	mov    r9,QWORD PTR [rdx+0x68]
  19d2e7:	48 8b 4a 78          	mov    rcx,QWORD PTR [rdx+0x78]
  19d2eb:	48 89 4c 24 48       	mov    QWORD PTR [rsp+0x48],rcx
  19d2f0:	4c 8b 9a 88 00 00 00 	mov    r11,QWORD PTR [rdx+0x88]
  19d2f7:	49 83 c6 02          	add    r14,0x2
  19d2fb:	4d 89 f7             	mov    r15,r14
  19d2fe:	49 d1 ef             	shr    r15,1
  19d301:	31 c9                	xor    ecx,ecx
  19d303:	4c 89 ff             	mov    rdi,r15
  19d306:	48 83 ef 01          	sub    rdi,0x1
  19d30a:	48 0f 42 f9          	cmovb  rdi,rcx
  19d30e:	48 89 bc 24 f0 01 00 	mov    QWORD PTR [rsp+0x1f0],rdi
  19d315:	00 
  19d316:	48 8b ba 90 00 00 00 	mov    rdi,QWORD PTR [rdx+0x90]
  19d31d:	48 89 7c 24 30       	mov    QWORD PTR [rsp+0x30],rdi
  19d322:	49 83 ef 02          	sub    r15,0x2
  19d326:	4c 0f 42 f9          	cmovb  r15,rcx
  19d32a:	48 8b 8a f0 00 00 00 	mov    rcx,QWORD PTR [rdx+0xf0]
  19d331:	48 89 8c 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rcx
  19d338:	00 
  19d339:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  19d33d:	c5 7d c2 f8 00       	vcmpeqpd ymm15,ymm0,ymm0
  19d342:	48 8b 8a 00 01 00 00 	mov    rcx,QWORD PTR [rdx+0x100]
  19d349:	48 8b aa 10 01 00 00 	mov    rbp,QWORD PTR [rdx+0x110]
  19d350:	48 8b ba 20 01 00 00 	mov    rdi,QWORD PTR [rdx+0x120]
  19d357:	48 89 bc 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],rdi
  19d35e:	00 
  19d35f:	48 8b ba 98 00 00 00 	mov    rdi,QWORD PTR [rdx+0x98]
  19d366:	4c 8b 92 a8 00 00 00 	mov    r10,QWORD PTR [rdx+0xa8]
  19d36d:	48 8b b2 b8 00 00 00 	mov    rsi,QWORD PTR [rdx+0xb8]
  19d374:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
  19d379:	4c 89 bc 24 98 01 00 	mov    QWORD PTR [rsp+0x198],r15
  19d380:	00 
  19d381:	4c 39 f8             	cmp    rax,r15
  19d384:	4c 89 9c 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],r11
  19d38b:	00 
  19d38c:	4c 89 ac 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],r13
  19d393:	00 
  19d394:	4c 89 4c 24 28       	mov    QWORD PTR [rsp+0x28],r9
  19d399:	48 89 8c 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rcx
  19d3a0:	00 
  19d3a1:	4c 89 a4 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],r12
  19d3a8:	00 
  19d3a9:	0f 83 97 00 00 00    	jae    19d446 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2e6>
  19d3af:	48 8b 12             	mov    rdx,QWORD PTR [rdx]
  19d3b2:	c6 02 01             	mov    BYTE PTR [rdx],0x1
  19d3b5:	4c 89 e9             	mov    rcx,r13
  19d3b8:	48 c1 e9 02          	shr    rcx,0x2
  19d3bc:	48 8b 54 24 58       	mov    rdx,QWORD PTR [rsp+0x58]
  19d3c1:	48 c1 ea 02          	shr    rdx,0x2
  19d3c5:	4c 8b 8c 24 88 00 00 	mov    r9,QWORD PTR [rsp+0x88]
  19d3cc:	00 
  19d3cd:	49 c1 e9 02          	shr    r9,0x2
  19d3d1:	4c 8b 9c 24 80 00 00 	mov    r11,QWORD PTR [rsp+0x80]
  19d3d8:	00 
  19d3d9:	49 c1 eb 02          	shr    r11,0x2
  19d3dd:	48 8b b4 24 f8 00 00 	mov    rsi,QWORD PTR [rsp+0xf8]
  19d3e4:	00 
  19d3e5:	49 89 f0             	mov    r8,rsi
  19d3e8:	49 c1 e8 02          	shr    r8,0x2
  19d3ec:	49 89 cf             	mov    r15,rcx
  19d3ef:	49 31 d7             	xor    r15,rdx
  19d3f2:	49 31 d1             	xor    r9,rdx
  19d3f5:	4d 09 f9             	or     r9,r15
  19d3f8:	49 31 d3             	xor    r11,rdx
  19d3fb:	4c 39 c1             	cmp    rcx,r8
  19d3fe:	4c 0f 42 c1          	cmovb  r8,rcx
  19d402:	4c 89 84 24 98 00 00 	mov    QWORD PTR [rsp+0x98],r8
  19d409:	00 
  19d40a:	4d 09 cb             	or     r11,r9
  19d40d:	0f 84 f8 0d 00 00    	je     19e20b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x10ab>
  19d413:	48 8b 8c 24 c8 00 00 	mov    rcx,QWORD PTR [rsp+0xc8]
  19d41a:	00 
  19d41b:	48 39 c8             	cmp    rax,rcx
  19d41e:	0f 83 72 2b 00 00    	jae    19ff96 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2e36>
  19d424:	48 8b b4 24 f0 00 00 	mov    rsi,QWORD PTR [rsp+0xf0]
  19d42b:	00 
  19d42c:	48 39 f0             	cmp    rax,rsi
  19d42f:	0f 83 83 2b 00 00    	jae    19ffb8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2e58>
  19d435:	48 ff c0             	inc    rax
  19d438:	48 39 c8             	cmp    rax,rcx
  19d43b:	0f 82 67 29 00 00    	jb     19fda8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c48>
  19d441:	e9 6f 2a 00 00       	jmp    19feb5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d55>
  19d446:	c6 44 24 07 01       	mov    BYTE PTR [rsp+0x7],0x1
  19d44b:	4c 89 b4 24 d8 01 00 	mov    QWORD PTR [rsp+0x1d8],r14
  19d452:	00 
  19d453:	4c 8b 8c 24 a8 00 00 	mov    r9,QWORD PTR [rsp+0xa8]
  19d45a:	00 
  19d45b:	48 8b 94 24 f8 00 00 	mov    rdx,QWORD PTR [rsp+0xf8]
  19d462:	00 
  19d463:	48 89 54 24 08       	mov    QWORD PTR [rsp+0x8],rdx
  19d468:	49 89 fd             	mov    r13,rdi
  19d46b:	48 89 c6             	mov    rsi,rax
  19d46e:	4c 8b 74 24 30       	mov    r14,QWORD PTR [rsp+0x30]
  19d473:	48 ba fe ff ff ff ff 	movabs rdx,0x3fffffffffffffe
  19d47a:	ff ff 03 
  19d47d:	48 3b b4 24 f0 01 00 	cmp    rsi,QWORD PTR [rsp+0x1f0]
  19d484:	00 
  19d485:	48 89 6c 24 70       	mov    QWORD PTR [rsp+0x70],rbp
  19d48a:	4c 8b 64 24 10       	mov    r12,QWORD PTR [rsp+0x10]
  19d48f:	0f 83 98 0b 00 00    	jae    19e02d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0xecd>
  19d495:	48 8b 84 24 f8 00 00 	mov    rax,QWORD PTR [rsp+0xf8]
  19d49c:	00 
  19d49d:	49 89 c7             	mov    r15,rax
  19d4a0:	49 c1 ef 02          	shr    r15,0x2
  19d4a4:	89 c7                	mov    edi,eax
  19d4a6:	83 e7 03             	and    edi,0x3
  19d4a9:	48 89 bc 24 e8 01 00 	mov    QWORD PTR [rsp+0x1e8],rdi
  19d4b0:	00 
  19d4b1:	48 89 c7             	mov    rdi,rax
  19d4b4:	4c 89 4c 24 50       	mov    QWORD PTR [rsp+0x50],r9
  19d4b9:	49 89 d1             	mov    r9,rdx
  19d4bc:	48 ba fc ff ff ff ff 	movabs rdx,0xffffffffffffffc
  19d4c3:	ff ff 0f 
  19d4c6:	48 21 d7             	and    rdi,rdx
  19d4c9:	48 89 bc 24 48 02 00 	mov    QWORD PTR [rsp+0x248],rdi
  19d4d0:	00 
  19d4d1:	48 8b bc 24 a8 00 00 	mov    rdi,QWORD PTR [rsp+0xa8]
  19d4d8:	00 
  19d4d9:	49 89 fe             	mov    r14,rdi
  19d4dc:	49 c1 ee 02          	shr    r14,0x2
  19d4e0:	4c 89 b4 24 a0 01 00 	mov    QWORD PTR [rsp+0x1a0],r14
  19d4e7:	00 
  19d4e8:	4d 21 cf             	and    r15,r9
  19d4eb:	49 c1 e7 05          	shl    r15,0x5
  19d4ef:	4a 8d 14 3b          	lea    rdx,[rbx+r15*1]
  19d4f3:	48 89 94 24 18 02 00 	mov    QWORD PTR [rsp+0x218],rdx
  19d4fa:	00 
  19d4fb:	48 c1 e8 03          	shr    rax,0x3
  19d4ff:	48 89 84 24 10 01 00 	mov    QWORD PTR [rsp+0x110],rax
  19d506:	00 
  19d507:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
  19d50e:	00 
  19d50f:	4c 01 f8             	add    rax,r15
  19d512:	48 89 84 24 10 02 00 	mov    QWORD PTR [rsp+0x210],rax
  19d519:	00 
  19d51a:	4a 8d 04 39          	lea    rax,[rcx+r15*1]
  19d51e:	48 89 84 24 08 02 00 	mov    QWORD PTR [rsp+0x208],rax
  19d525:	00 
  19d526:	49 01 ef             	add    r15,rbp
  19d529:	4c 89 bc 24 20 02 00 	mov    QWORD PTR [rsp+0x220],r15
  19d530:	00 
  19d531:	48 89 f8             	mov    rax,rdi
  19d534:	48 c1 e8 03          	shr    rax,0x3
  19d538:	48 89 44 24 40       	mov    QWORD PTR [rsp+0x40],rax
  19d53d:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
  19d544:	00 
  19d545:	48 89 c2             	mov    rdx,rax
  19d548:	48 c1 ea 02          	shr    rdx,0x2
  19d54c:	48 89 94 24 78 01 00 	mov    QWORD PTR [rsp+0x178],rdx
  19d553:	00 
  19d554:	89 c2                	mov    edx,eax
  19d556:	83 e2 03             	and    edx,0x3
  19d559:	48 89 94 24 48 01 00 	mov    QWORD PTR [rsp+0x148],rdx
  19d560:	00 
  19d561:	49 be fc ff ff ff ff 	movabs r14,0xffffffffffffffc
  19d568:	ff ff 0f 
  19d56b:	4c 21 f0             	and    rax,r14
  19d56e:	48 89 84 24 40 02 00 	mov    QWORD PTR [rsp+0x240],rax
  19d575:	00 
  19d576:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
  19d57b:	49 89 c1             	mov    r9,rax
  19d57e:	49 c1 e9 02          	shr    r9,0x2
  19d582:	89 c7                	mov    edi,eax
  19d584:	83 e7 03             	and    edi,0x3
  19d587:	48 89 bc 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rdi
  19d58e:	00 
  19d58f:	4c 21 f0             	and    rax,r14
  19d592:	48 89 84 24 38 02 00 	mov    QWORD PTR [rsp+0x238],rax
  19d599:	00 
  19d59a:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
  19d5a1:	00 
  19d5a2:	49 89 c3             	mov    r11,rax
  19d5a5:	49 c1 eb 02          	shr    r11,0x2
  19d5a9:	41 89 c7             	mov    r15d,eax
  19d5ac:	41 83 e7 03          	and    r15d,0x3
  19d5b0:	4c 21 f0             	and    rax,r14
  19d5b3:	48 89 84 24 30 02 00 	mov    QWORD PTR [rsp+0x230],rax
  19d5ba:	00 
  19d5bb:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
  19d5c2:	00 
  19d5c3:	48 89 c2             	mov    rdx,rax
  19d5c6:	48 c1 ea 02          	shr    rdx,0x2
  19d5ca:	89 c7                	mov    edi,eax
  19d5cc:	83 e7 03             	and    edi,0x3
  19d5cf:	4c 21 f0             	and    rax,r14
  19d5d2:	48 89 84 24 28 02 00 	mov    QWORD PTR [rsp+0x228],rax
  19d5d9:	00 
  19d5da:	4c 8b b4 24 18 01 00 	mov    r14,QWORD PTR [rsp+0x118]
  19d5e1:	00 
  19d5e2:	4c 89 f0             	mov    rax,r14
  19d5e5:	49 b8 fc ff ff ff ff 	movabs r8,0xffffffffffffffc
  19d5ec:	ff ff 0f 
  19d5ef:	4c 21 c0             	and    rax,r8
  19d5f2:	48 89 44 24 78       	mov    QWORD PTR [rsp+0x78],rax
  19d5f7:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
  19d5fe:	00 
  19d5ff:	48 39 c6             	cmp    rsi,rax
  19d602:	48 0f 47 c6          	cmova  rax,rsi
  19d606:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
  19d60d:	00 
  19d60e:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
  19d615:	00 
  19d616:	48 39 c6             	cmp    rsi,rax
  19d619:	48 0f 47 c6          	cmova  rax,rsi
  19d61d:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
  19d624:	00 
  19d625:	48 8b 84 24 78 01 00 	mov    rax,QWORD PTR [rsp+0x178]
  19d62c:	00 
  19d62d:	49 39 c1             	cmp    r9,rax
  19d630:	4c 8b 44 24 60       	mov    r8,QWORD PTR [rsp+0x60]
  19d635:	4c 89 8c 24 c0 01 00 	mov    QWORD PTR [rsp+0x1c0],r9
  19d63c:	00 
  19d63d:	49 0f 42 c1          	cmovb  rax,r9
  19d641:	4c 8b 4c 24 50       	mov    r9,QWORD PTR [rsp+0x50]
  19d646:	49 39 c3             	cmp    r11,rax
  19d649:	4c 89 9c 24 b8 01 00 	mov    QWORD PTR [rsp+0x1b8],r11
  19d650:	00 
  19d651:	49 0f 42 c3          	cmovb  rax,r11
  19d655:	48 39 c2             	cmp    rdx,rax
  19d658:	48 89 94 24 b0 01 00 	mov    QWORD PTR [rsp+0x1b0],rdx
  19d65f:	00 
  19d660:	48 0f 42 c2          	cmovb  rax,rdx
  19d664:	48 89 84 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rax
  19d66b:	00 
  19d66c:	4c 89 f0             	mov    rax,r14
  19d66f:	48 c1 e8 02          	shr    rax,0x2
  19d673:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
  19d67a:	00 
  19d67b:	48 8b 84 24 48 01 00 	mov    rax,QWORD PTR [rsp+0x148]
  19d682:	00 
  19d683:	48 8b 94 24 80 01 00 	mov    rdx,QWORD PTR [rsp+0x180]
  19d68a:	00 
  19d68b:	48 39 c2             	cmp    rdx,rax
  19d68e:	48 0f 42 c2          	cmovb  rax,rdx
  19d692:	49 39 c7             	cmp    r15,rax
  19d695:	4c 89 bc 24 d0 01 00 	mov    QWORD PTR [rsp+0x1d0],r15
  19d69c:	00 
  19d69d:	49 0f 42 c7          	cmovb  rax,r15
  19d6a1:	48 39 c7             	cmp    rdi,rax
  19d6a4:	48 89 bc 24 c8 01 00 	mov    QWORD PTR [rsp+0x1c8],rdi
  19d6ab:	00 
  19d6ac:	48 0f 42 c7          	cmovb  rax,rdi
  19d6b0:	48 89 84 24 50 01 00 	mov    QWORD PTR [rsp+0x150],rax
  19d6b7:	00 
  19d6b8:	48 8b 84 24 a8 00 00 	mov    rax,QWORD PTR [rsp+0xa8]
  19d6bf:	00 
  19d6c0:	83 e0 03             	and    eax,0x3
  19d6c3:	48 89 84 24 88 01 00 	mov    QWORD PTR [rsp+0x188],rax
  19d6ca:	00 
  19d6cb:	41 83 e6 03          	and    r14d,0x3
  19d6cf:	4c 89 b4 24 18 01 00 	mov    QWORD PTR [rsp+0x118],r14
  19d6d6:	00 
  19d6d7:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
  19d6db:	c4 e2 7d 19 1d 14 39 	vbroadcastsd ymm3,QWORD PTR [rip+0xffffffffffe83914]        # 20ff8 <anon.18cb9c1b3fe794d0b89f358a70182f4e.25.llvm.5582884991536083740+0x388>
  19d6e2:	e8 ff 
  19d6e4:	c5 7d 29 f9          	vmovapd ymm1,ymm15
  19d6e8:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
  19d6ed:	49 89 c7             	mov    r15,rax
  19d6f0:	48 89 9c 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rbx
  19d6f7:	00 
  19d6f8:	eb 1e                	jmp    19d718 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x5b8>
  19d6fa:	c5 dd 54 c9          	vandpd ymm1,ymm4,ymm1
  19d6fe:	48 ff c6             	inc    rsi
  19d701:	4d 89 d5             	mov    r13,r10
  19d704:	49 89 d2             	mov    r10,rdx
  19d707:	49 89 ff             	mov    r15,rdi
  19d70a:	48 3b b4 24 f0 01 00 	cmp    rsi,QWORD PTR [rsp+0x1f0]
  19d711:	00 
  19d712:	0f 83 f4 09 00 00    	jae    19e10c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0xfac>
  19d718:	4c 89 4c 24 08       	mov    QWORD PTR [rsp+0x8],r9
  19d71d:	4c 89 e2             	mov    rdx,r12
  19d720:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
  19d725:	4c 89 ff             	mov    rdi,r15
  19d728:	48 c1 ef 03          	shr    rdi,0x3
  19d72c:	48 8b 84 24 10 01 00 	mov    rax,QWORD PTR [rsp+0x110]
  19d733:	00 
  19d734:	48 39 c7             	cmp    rdi,rax
  19d737:	48 0f 43 f8          	cmovae rdi,rax
  19d73b:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
  19d740:	48 39 f8             	cmp    rax,rdi
  19d743:	48 0f 42 f8          	cmovb  rdi,rax
  19d747:	c4 41 21 57 db       	vxorpd xmm11,xmm11,xmm11
  19d74c:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  19d750:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  19d755:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  19d75a:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  19d75f:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  19d763:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  19d767:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  19d76b:	48 85 ff             	test   rdi,rdi
  19d76e:	4c 8b b4 24 90 00 00 	mov    r14,QWORD PTR [rsp+0x90]
  19d775:	00 
  19d776:	0f 84 1c 01 00 00    	je     19d898 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x738>
  19d77c:	48 83 ff 01          	cmp    rdi,0x1
  19d780:	75 07                	jne    19d789 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x629>
  19d782:	31 c0                	xor    eax,eax
  19d784:	e9 c9 00 00 00       	jmp    19d852 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x6f2>
  19d789:	4d 89 fc             	mov    r12,r15
  19d78c:	49 89 f9             	mov    r9,rdi
  19d78f:	48 b8 fe ff ff ff ff 	movabs rax,0x1ffffffffffffffe
  19d796:	ff ff 1f 
  19d799:	49 21 c1             	and    r9,rax
  19d79c:	41 bf 60 00 00 00    	mov    r15d,0x60
  19d7a2:	31 c0                	xor    eax,eax
  19d7a4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  19d7ab:	00 00 00 00 00 
  19d7b0:	c4 81 7d 10 44 3a a0 	vmovupd ymm0,YMMWORD PTR [r10+r15*1-0x60]
  19d7b7:	c4 01 7d 10 64 3a c0 	vmovupd ymm12,YMMWORD PTR [r10+r15*1-0x40]
  19d7be:	c4 01 7d 10 6c 3a e0 	vmovupd ymm13,YMMWORD PTR [r10+r15*1-0x20]
  19d7c5:	c4 a2 fd b8 7c 3b a0 	vfmadd231pd ymm7,ymm0,YMMWORD PTR [rbx+r15*1-0x60]
  19d7cc:	c4 02 fd b8 44 3e a0 	vfmadd231pd ymm8,ymm0,YMMWORD PTR [r14+r15*1-0x60]
  19d7d3:	c4 22 fd b8 4c 39 a0 	vfmadd231pd ymm9,ymm0,YMMWORD PTR [rcx+r15*1-0x60]
  19d7da:	c4 22 fd b8 54 3d a0 	vfmadd231pd ymm10,ymm0,YMMWORD PTR [rbp+r15*1-0x60]
  19d7e1:	c4 a2 9d b8 6c 3b c0 	vfmadd231pd ymm5,ymm12,YMMWORD PTR [rbx+r15*1-0x40]
  19d7e8:	c4 82 9d b8 74 3e c0 	vfmadd231pd ymm6,ymm12,YMMWORD PTR [r14+r15*1-0x40]
  19d7ef:	c4 a2 9d b8 64 39 c0 	vfmadd231pd ymm4,ymm12,YMMWORD PTR [rcx+r15*1-0x40]
  19d7f6:	c4 22 9d b8 5c 3d c0 	vfmadd231pd ymm11,ymm12,YMMWORD PTR [rbp+r15*1-0x40]
  19d7fd:	c4 81 7d 10 04 3a    	vmovupd ymm0,YMMWORD PTR [r10+r15*1]
  19d803:	48 83 c0 02          	add    rax,0x2
  19d807:	c4 a2 95 b8 7c 3b e0 	vfmadd231pd ymm7,ymm13,YMMWORD PTR [rbx+r15*1-0x20]
  19d80e:	c4 02 95 b8 44 3e e0 	vfmadd231pd ymm8,ymm13,YMMWORD PTR [r14+r15*1-0x20]
  19d815:	c4 22 95 b8 4c 39 e0 	vfmadd231pd ymm9,ymm13,YMMWORD PTR [rcx+r15*1-0x20]
  19d81c:	c4 22 95 b8 54 3d e0 	vfmadd231pd ymm10,ymm13,YMMWORD PTR [rbp+r15*1-0x20]
  19d823:	c4 a2 fd b8 2c 3b    	vfmadd231pd ymm5,ymm0,YMMWORD PTR [rbx+r15*1]
  19d829:	c4 82 fd b8 34 3e    	vfmadd231pd ymm6,ymm0,YMMWORD PTR [r14+r15*1]
  19d82f:	c4 a2 fd b8 24 39    	vfmadd231pd ymm4,ymm0,YMMWORD PTR [rcx+r15*1]
  19d835:	c4 22 fd b8 5c 3d 00 	vfmadd231pd ymm11,ymm0,YMMWORD PTR [rbp+r15*1+0x0]
  19d83c:	49 83 ef 80          	sub    r15,0xffffffffffffff80
  19d840:	49 39 c1             	cmp    r9,rax
  19d843:	0f 85 67 ff ff ff    	jne    19d7b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x650>
  19d849:	40 f6 c7 01          	test   dil,0x1
  19d84d:	4d 89 e7             	mov    r15,r12
  19d850:	74 46                	je     19d898 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x738>
  19d852:	48 c1 e0 06          	shl    rax,0x6
  19d856:	c4 c1 7d 10 04 02    	vmovupd ymm0,YMMWORD PTR [r10+rax*1]
  19d85c:	c4 41 7d 10 64 02 20 	vmovupd ymm12,YMMWORD PTR [r10+rax*1+0x20]
  19d863:	c4 e2 fd b8 3c 03    	vfmadd231pd ymm7,ymm0,YMMWORD PTR [rbx+rax*1]
  19d869:	c4 42 fd b8 04 06    	vfmadd231pd ymm8,ymm0,YMMWORD PTR [r14+rax*1]
  19d86f:	c4 62 fd b8 0c 01    	vfmadd231pd ymm9,ymm0,YMMWORD PTR [rcx+rax*1]
  19d875:	c4 62 fd b8 54 05 00 	vfmadd231pd ymm10,ymm0,YMMWORD PTR [rbp+rax*1+0x0]
  19d87c:	c4 e2 9d b8 6c 03 20 	vfmadd231pd ymm5,ymm12,YMMWORD PTR [rbx+rax*1+0x20]
  19d883:	c4 c2 9d b8 74 06 20 	vfmadd231pd ymm6,ymm12,YMMWORD PTR [r14+rax*1+0x20]
  19d88a:	c4 e2 9d b8 64 01 20 	vfmadd231pd ymm4,ymm12,YMMWORD PTR [rcx+rax*1+0x20]
  19d891:	c4 62 9d b8 5c 05 20 	vfmadd231pd ymm11,ymm12,YMMWORD PTR [rbp+rax*1+0x20]
  19d898:	4d 89 f9             	mov    r9,r15
  19d89b:	49 c1 e9 02          	shr    r9,0x2
  19d89f:	41 f6 c7 04          	test   r15b,0x4
  19d8a3:	4c 89 6c 24 10       	mov    QWORD PTR [rsp+0x10],r13
  19d8a8:	75 07                	jne    19d8b1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x751>
  19d8aa:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
  19d8af:	eb 76                	jmp    19d927 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x7c7>
  19d8b1:	f6 84 24 a8 00 00 00 	test   BYTE PTR [rsp+0xa8],0x4
  19d8b8:	04 
  19d8b9:	48 8b 7c 24 20       	mov    rdi,QWORD PTR [rsp+0x20]
  19d8be:	0f 84 9d 25 00 00    	je     19fe61 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d01>
  19d8c4:	f6 84 24 f8 00 00 00 	test   BYTE PTR [rsp+0xf8],0x4
  19d8cb:	04 
  19d8cc:	0f 84 a3 25 00 00    	je     19fe75 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d15>
  19d8d2:	4d 89 fc             	mov    r12,r15
  19d8d5:	4c 89 c8             	mov    rax,r9
  19d8d8:	49 bf fe ff ff ff ff 	movabs r15,0x3fffffffffffffe
  19d8df:	ff ff 03 
  19d8e2:	4c 21 f8             	and    rax,r15
  19d8e5:	48 c1 e0 05          	shl    rax,0x5
  19d8e9:	4c 01 d0             	add    rax,r10
  19d8ec:	c5 fd 10 00          	vmovupd ymm0,YMMWORD PTR [rax]
  19d8f0:	48 8b 84 24 18 02 00 	mov    rax,QWORD PTR [rsp+0x218]
  19d8f7:	00 
  19d8f8:	c4 e2 fd b8 38       	vfmadd231pd ymm7,ymm0,YMMWORD PTR [rax]
  19d8fd:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
  19d904:	00 
  19d905:	c4 62 fd b8 00       	vfmadd231pd ymm8,ymm0,YMMWORD PTR [rax]
  19d90a:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
  19d911:	00 
  19d912:	c4 62 fd b8 08       	vfmadd231pd ymm9,ymm0,YMMWORD PTR [rax]
  19d917:	48 8b 84 24 20 02 00 	mov    rax,QWORD PTR [rsp+0x220]
  19d91e:	00 
  19d91f:	c4 62 fd b8 10       	vfmadd231pd ymm10,ymm0,YMMWORD PTR [rax]
  19d924:	4d 89 e7             	mov    r15,r12
  19d927:	c4 c1 25 58 c2       	vaddpd ymm0,ymm11,ymm10
  19d92c:	c5 b5 58 e4          	vaddpd ymm4,ymm9,ymm4
  19d930:	c5 bd 58 f6          	vaddpd ymm6,ymm8,ymm6
  19d934:	c5 d5 58 ef          	vaddpd ymm5,ymm5,ymm7
  19d938:	45 89 fc             	mov    r12d,r15d
  19d93b:	41 83 e4 03          	and    r12d,0x3
  19d93f:	4d 89 fd             	mov    r13,r15
  19d942:	48 b8 fc ff ff ff ff 	movabs rax,0xffffffffffffffc
  19d949:	ff ff 0f 
  19d94c:	49 21 c5             	and    r13,rax
  19d94f:	c4 e3 7d 19 ef 01    	vextractf128 xmm7,ymm5,0x1
  19d955:	c5 d1 58 ef          	vaddpd xmm5,xmm5,xmm7
  19d959:	c5 d1 c6 fd 01       	vshufpd xmm7,xmm5,xmm5,0x1
  19d95e:	c5 d3 58 ef          	vaddsd xmm5,xmm5,xmm7
  19d962:	c4 e3 7d 19 f7 01    	vextractf128 xmm7,ymm6,0x1
  19d968:	c5 c9 58 f7          	vaddpd xmm6,xmm6,xmm7
  19d96c:	c5 c9 c6 fe 01       	vshufpd xmm7,xmm6,xmm6,0x1
  19d971:	c5 cb 58 ff          	vaddsd xmm7,xmm6,xmm7
  19d975:	c4 e3 7d 19 e6 01    	vextractf128 xmm6,ymm4,0x1
  19d97b:	c5 d9 58 e6          	vaddpd xmm4,xmm4,xmm6
  19d97f:	c5 d9 c6 f4 01       	vshufpd xmm6,xmm4,xmm4,0x1
  19d984:	c5 db 58 e6          	vaddsd xmm4,xmm4,xmm6
  19d988:	c4 e3 7d 19 c6 01    	vextractf128 xmm6,ymm0,0x1
  19d98e:	c5 f9 58 c6          	vaddpd xmm0,xmm0,xmm6
  19d992:	c5 f9 c6 f0 01       	vshufpd xmm6,xmm0,xmm0,0x1
  19d997:	c5 fb 58 f6          	vaddsd xmm6,xmm0,xmm6
  19d99b:	4d 85 e4             	test   r12,r12
  19d99e:	4c 89 ac 24 20 01 00 	mov    QWORD PTR [rsp+0x120],r13
  19d9a5:	00 
  19d9a6:	0f 84 8b 00 00 00    	je     19da37 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x8d7>
  19d9ac:	41 8d 44 24 ff       	lea    eax,[r12-0x1]
  19d9b1:	39 84 24 e8 01 00 00 	cmp    DWORD PTR [rsp+0x1e8],eax
  19d9b8:	0f 86 88 24 00 00    	jbe    19fe46 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2ce6>
  19d9be:	c4 81 7b 10 04 ea    	vmovsd xmm0,QWORD PTR [r10+r13*8]
  19d9c4:	48 8b 84 24 48 02 00 	mov    rax,QWORD PTR [rsp+0x248]
  19d9cb:	00 
  19d9cc:	c4 e2 f9 b9 2c c3    	vfmadd231sd xmm5,xmm0,QWORD PTR [rbx+rax*8]
  19d9d2:	c4 c2 f9 b9 3c c6    	vfmadd231sd xmm7,xmm0,QWORD PTR [r14+rax*8]
  19d9d8:	c4 e2 f9 b9 24 c1    	vfmadd231sd xmm4,xmm0,QWORD PTR [rcx+rax*8]
  19d9de:	c4 e2 f9 b9 74 c5 00 	vfmadd231sd xmm6,xmm0,QWORD PTR [rbp+rax*8+0x0]
  19d9e5:	41 83 fc 01          	cmp    r12d,0x1
  19d9e9:	74 4c                	je     19da37 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x8d7>
  19d9eb:	c4 81 7b 10 44 ea 08 	vmovsd xmm0,QWORD PTR [r10+r13*8+0x8]
  19d9f2:	c4 e2 f9 b9 6c c3 08 	vfmadd231sd xmm5,xmm0,QWORD PTR [rbx+rax*8+0x8]
  19d9f9:	c4 c2 f9 b9 7c c6 08 	vfmadd231sd xmm7,xmm0,QWORD PTR [r14+rax*8+0x8]
  19da00:	c4 e2 f9 b9 64 c1 08 	vfmadd231sd xmm4,xmm0,QWORD PTR [rcx+rax*8+0x8]
  19da07:	c4 e2 f9 b9 74 c5 08 	vfmadd231sd xmm6,xmm0,QWORD PTR [rbp+rax*8+0x8]
  19da0e:	41 83 fc 02          	cmp    r12d,0x2
  19da12:	74 23                	je     19da37 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x8d7>
  19da14:	c4 81 7b 10 44 ea 10 	vmovsd xmm0,QWORD PTR [r10+r13*8+0x10]
  19da1b:	c4 e2 f9 b9 6c c3 10 	vfmadd231sd xmm5,xmm0,QWORD PTR [rbx+rax*8+0x10]
  19da22:	c4 c2 f9 b9 7c c6 10 	vfmadd231sd xmm7,xmm0,QWORD PTR [r14+rax*8+0x10]
  19da29:	c4 e2 f9 b9 64 c1 10 	vfmadd231sd xmm4,xmm0,QWORD PTR [rcx+rax*8+0x10]
  19da30:	c4 e2 f9 b9 74 c5 10 	vfmadd231sd xmm6,xmm0,QWORD PTR [rbp+rax*8+0x10]
  19da37:	4c 89 bc 24 98 01 00 	mov    QWORD PTR [rsp+0x198],r15
  19da3e:	00 
  19da3f:	4c 8d 2c 36          	lea    r13,[rsi+rsi*1]
  19da43:	48 8b 6c 24 68       	mov    rbp,QWORD PTR [rsp+0x68]
  19da48:	49 39 ed             	cmp    r13,rbp
  19da4b:	48 8b 4c 24 48       	mov    rcx,QWORD PTR [rsp+0x48]
  19da50:	48 8b 5c 24 78       	mov    rbx,QWORD PTR [rsp+0x78]
  19da55:	0f 83 d5 23 00 00    	jae    19fe30 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2cd0>
  19da5b:	4d 89 ef             	mov    r15,r13
  19da5e:	49 c1 e7 04          	shl    r15,0x4
  19da62:	4c 8b b4 24 c0 00 00 	mov    r14,QWORD PTR [rsp+0xc0]
  19da69:	00 
  19da6a:	c4 81 7b 11 2c 3e    	vmovsd QWORD PTR [r14+r15*1],xmm5
  19da70:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
  19da77:	00 
  19da78:	48 8d 04 70          	lea    rax,[rax+rsi*2]
  19da7c:	c4 81 7b 11 7c 3e 08 	vmovsd QWORD PTR [r14+r15*1+0x8],xmm7
  19da83:	48 89 84 24 60 01 00 	mov    QWORD PTR [rsp+0x160],rax
  19da8a:	00 
  19da8b:	4c 39 c0             	cmp    rax,r8
  19da8e:	4c 8b 74 24 38       	mov    r14,QWORD PTR [rsp+0x38]
  19da93:	73 26                	jae    19dabb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x95b>
  19da95:	49 8d 45 01          	lea    rax,[r13+0x1]
  19da99:	48 39 e8             	cmp    rax,rbp
  19da9c:	0f 83 fd 23 00 00    	jae    19fe9f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d3f>
  19daa2:	48 c1 e0 04          	shl    rax,0x4
  19daa6:	4c 8b 84 24 c0 00 00 	mov    r8,QWORD PTR [rsp+0xc0]
  19daad:	00 
  19daae:	c4 c1 7b 11 24 00    	vmovsd QWORD PTR [r8+rax*1],xmm4
  19dab4:	c4 c1 7b 11 74 00 08 	vmovsd QWORD PTR [r8+rax*1+0x8],xmm6
  19dabb:	48 3b b4 24 e0 00 00 	cmp    rsi,QWORD PTR [rsp+0xe0]
  19dac2:	00 
  19dac3:	0f 84 11 23 00 00    	je     19fdda <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c7a>
  19dac9:	48 3b b4 24 d8 00 00 	cmp    rsi,QWORD PTR [rsp+0xd8]
  19dad0:	00 
  19dad1:	48 8b ac 24 18 01 00 	mov    rbp,QWORD PTR [rsp+0x118]
  19dad8:	00 
  19dad9:	0f 84 1b 23 00 00    	je     19fdfa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c9a>
  19dadf:	4c 8b 5c 24 08       	mov    r11,QWORD PTR [rsp+0x8]
  19dae4:	49 c1 eb 02          	shr    r11,0x2
  19dae8:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
  19daed:	48 c1 e8 02          	shr    rax,0x2
  19daf1:	4c 8b 84 24 08 01 00 	mov    r8,QWORD PTR [rsp+0x108]
  19daf8:	00 
  19daf9:	4c 39 c0             	cmp    rax,r8
  19dafc:	49 0f 43 c0          	cmovae rax,r8
  19db00:	49 39 c1             	cmp    r9,rax
  19db03:	49 0f 42 c1          	cmovb  rax,r9
  19db07:	4c 8b 8c 24 00 02 00 	mov    r9,QWORD PTR [rsp+0x200]
  19db0e:	00 
  19db0f:	c4 c2 7d 19 34 f1    	vbroadcastsd ymm6,QWORD PTR [r9+rsi*8]
  19db15:	4c 8b 84 24 a0 01 00 	mov    r8,QWORD PTR [rsp+0x1a0]
  19db1c:	00 
  19db1d:	49 39 c0             	cmp    r8,rax
  19db20:	49 0f 42 c0          	cmovb  rax,r8
  19db24:	4c 8b 8c 24 f8 01 00 	mov    r9,QWORD PTR [rsp+0x1f8]
  19db2b:	00 
  19db2c:	48 89 74 24 18       	mov    QWORD PTR [rsp+0x18],rsi
  19db31:	c4 c2 7d 19 2c f1    	vbroadcastsd ymm5,QWORD PTR [r9+rsi*8]
  19db37:	48 8b b4 24 90 01 00 	mov    rsi,QWORD PTR [rsp+0x190]
  19db3e:	00 
  19db3f:	48 39 c6             	cmp    rsi,rax
  19db42:	48 0f 42 c6          	cmovb  rax,rsi
  19db46:	49 39 c3             	cmp    r11,rax
  19db49:	4c 89 9c 24 30 01 00 	mov    QWORD PTR [rsp+0x130],r11
  19db50:	00 
  19db51:	49 0f 42 c3          	cmovb  rax,r11
  19db55:	48 85 c0             	test   rax,rax
  19db58:	0f 84 93 00 00 00    	je     19dbf1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0xa91>
  19db5e:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  19db63:	45 31 c9             	xor    r9d,r9d
  19db66:	c5 7d 29 fc          	vmovapd ymm4,ymm15
  19db6a:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  19db6e:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  19db72:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  19db77:	4c 8b 9c 24 a0 00 00 	mov    r11,QWORD PTR [rsp+0xa0]
  19db7e:	00 
  19db7f:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
  19db84:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
  19db89:	0f 1f 80 00 00 00 00 	nop    DWORD PTR [rax+0x0]
  19db90:	c4 01 7d 10 0c 0a    	vmovupd ymm9,YMMWORD PTR [r10+r9*1]
  19db96:	c4 02 b5 b8 04 0e    	vfmadd231pd ymm8,ymm9,YMMWORD PTR [r14+r9*1]
  19db9c:	c4 a2 b5 b8 3c 0f    	vfmadd231pd ymm7,ymm9,YMMWORD PTR [rdi+r9*1]
  19dba2:	c4 a2 b5 b8 04 0e    	vfmadd231pd ymm0,ymm9,YMMWORD PTR [rsi+r9*1]
  19dba8:	c4 22 b5 b8 14 09    	vfmadd231pd ymm10,ymm9,YMMWORD PTR [rcx+r9*1]
  19dbae:	c4 01 7d 10 1c 0b    	vmovupd ymm11,YMMWORD PTR [r11+r9*1]
  19dbb4:	c4 62 cd a8 dd       	vfmadd213pd ymm11,ymm6,ymm5
  19dbb9:	c4 02 b5 a8 1c 08    	vfmadd213pd ymm11,ymm9,YMMWORD PTR [r8+r9*1]
  19dbbf:	c4 21 7d 11 1c 0a    	vmovupd YMMWORD PTR [rdx+r9*1],ymm11
  19dbc5:	c4 62 7d 19 0d 42 35 	vbroadcastsd ymm9,QWORD PTR [rip+0xffffffffffe83542]        # 21110 <anon.18cb9c1b3fe794d0b89f358a70182f4e.25.llvm.5582884991536083740+0x4a0>
  19dbcc:	e8 ff 
  19dbce:	c4 41 25 54 c9       	vandpd ymm9,ymm11,ymm9
  19dbd3:	c5 35 c2 da 00       	vcmpeqpd ymm11,ymm9,ymm2
  19dbd8:	c5 35 c2 cb 1d       	vcmpge_oqpd ymm9,ymm9,ymm3
  19dbdd:	c4 41 35 56 cb       	vorpd  ymm9,ymm9,ymm11
  19dbe2:	c5 b5 54 e4          	vandpd ymm4,ymm9,ymm4
  19dbe6:	49 83 c1 20          	add    r9,0x20
  19dbea:	48 ff c8             	dec    rax
  19dbed:	75 a1                	jne    19db90 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0xa30>
  19dbef:	eb 1b                	jmp    19dc0c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0xaac>
  19dbf1:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  19dbf6:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  19dbfa:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  19dbfe:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  19dc03:	c5 7d 29 fc          	vmovapd ymm4,ymm15
  19dc07:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
  19dc0c:	4c 8b 5c 24 08       	mov    r11,QWORD PTR [rsp+0x8]
  19dc11:	44 89 d9             	mov    ecx,r11d
  19dc14:	83 e1 03             	and    ecx,0x3
  19dc17:	49 be fc ff ff ff ff 	movabs r14,0xffffffffffffffc
  19dc1e:	ff ff 0f 
  19dc21:	4d 21 f3             	and    r11,r14
  19dc24:	c4 43 7d 19 c1 01    	vextractf128 xmm9,ymm8,0x1
  19dc2a:	c4 41 39 58 c1       	vaddpd xmm8,xmm8,xmm9
  19dc2f:	c4 41 39 c6 c8 01    	vshufpd xmm9,xmm8,xmm8,0x1
  19dc35:	c4 41 3b 58 c1       	vaddsd xmm8,xmm8,xmm9
  19dc3a:	c4 c3 7d 19 f9 01    	vextractf128 xmm9,ymm7,0x1
  19dc40:	c5 b1 58 ff          	vaddpd xmm7,xmm9,xmm7
  19dc44:	c5 41 c6 cf 01       	vshufpd xmm9,xmm7,xmm7,0x1
  19dc49:	c5 33 58 cf          	vaddsd xmm9,xmm9,xmm7
  19dc4d:	c4 e3 7d 19 c7 01    	vextractf128 xmm7,ymm0,0x1
  19dc53:	c5 f9 58 c7          	vaddpd xmm0,xmm0,xmm7
  19dc57:	c5 f9 c6 f8 01       	vshufpd xmm7,xmm0,xmm0,0x1
  19dc5c:	c5 fb 58 ff          	vaddsd xmm7,xmm0,xmm7
  19dc60:	c4 63 7d 19 d0 01    	vextractf128 xmm0,ymm10,0x1
  19dc66:	4c 8b 4c 24 50       	mov    r9,QWORD PTR [rsp+0x50]
  19dc6b:	44 89 c8             	mov    eax,r9d
  19dc6e:	83 e0 03             	and    eax,0x3
  19dc71:	4c 8b 84 24 50 01 00 	mov    r8,QWORD PTR [rsp+0x150]
  19dc78:	00 
  19dc79:	4c 39 c0             	cmp    rax,r8
  19dc7c:	49 0f 43 c0          	cmovae rax,r8
  19dc80:	c5 a9 58 c0          	vaddpd xmm0,xmm10,xmm0
  19dc84:	49 39 c4             	cmp    r12,rax
  19dc87:	49 0f 42 c4          	cmovb  rax,r12
  19dc8b:	c5 79 c6 d0 01       	vshufpd xmm10,xmm0,xmm0,0x1
  19dc90:	4c 8b 84 24 88 01 00 	mov    r8,QWORD PTR [rsp+0x188]
  19dc97:	00 
  19dc98:	49 39 c0             	cmp    r8,rax
  19dc9b:	49 0f 42 c0          	cmovb  rax,r8
  19dc9f:	c5 2b 58 d0          	vaddsd xmm10,xmm10,xmm0
  19dca3:	48 39 c5             	cmp    rbp,rax
  19dca6:	48 0f 42 c5          	cmovb  rax,rbp
  19dcaa:	48 39 c1             	cmp    rcx,rax
  19dcad:	48 89 8c 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rcx
  19dcb4:	00 
  19dcb5:	48 0f 42 c1          	cmovb  rax,rcx
  19dcb9:	48 85 c0             	test   rax,rax
  19dcbc:	4c 89 9c 24 98 00 00 	mov    QWORD PTR [rsp+0x98],r11
  19dcc3:	00 
  19dcc4:	0f 84 fb 00 00 00    	je     19ddc5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0xc65>
  19dcca:	4d 89 cc             	mov    r12,r9
  19dccd:	4d 21 f4             	and    r12,r14
  19dcd0:	48 8b 8c 24 20 01 00 	mov    rcx,QWORD PTR [rsp+0x120]
  19dcd7:	00 
  19dcd8:	c4 c1 7b 10 04 ca    	vmovsd xmm0,QWORD PTR [r10+rcx*8]
  19dcde:	48 8b 8c 24 a0 00 00 	mov    rcx,QWORD PTR [rsp+0xa0]
  19dce5:	00 
  19dce6:	c5 7b 10 1c d9       	vmovsd xmm11,QWORD PTR [rcx+rbx*8]
  19dceb:	c4 62 c9 a9 dd       	vfmadd213sd xmm11,xmm6,xmm5
  19dcf0:	48 8b 4c 24 10       	mov    rcx,QWORD PTR [rsp+0x10]
  19dcf5:	c4 22 f9 a9 1c e1    	vfmadd213sd xmm11,xmm0,QWORD PTR [rcx+r12*8]
  19dcfb:	c4 41 f9 7e d9       	vmovq  r9,xmm11
  19dd00:	b1 3f                	mov    cl,0x3f
  19dd02:	c4 42 f0 f5 c9       	bzhi   r9,r9,rcx
  19dd07:	48 b9 00 00 00 00 00 	movabs rcx,0x7ff0000000000000
  19dd0e:	00 f0 7f 
  19dd11:	49 39 c9             	cmp    r9,rcx
  19dd14:	41 0f 94 c6          	sete   r14b
  19dd18:	4d 85 c9             	test   r9,r9
  19dd1b:	41 0f 94 c0          	sete   r8b
  19dd1f:	45 08 f0             	or     r8b,r14b
  19dd22:	49 89 f6             	mov    r14,rsi
  19dd25:	48 89 fe             	mov    rsi,rdi
  19dd28:	48 8b 7c 24 38       	mov    rdi,QWORD PTR [rsp+0x38]
  19dd2d:	48 8b 9c 24 40 02 00 	mov    rbx,QWORD PTR [rsp+0x240]
  19dd34:	00 
  19dd35:	c4 62 f9 b9 04 df    	vfmadd231sd xmm8,xmm0,QWORD PTR [rdi+rbx*8]
  19dd3b:	48 8b 8c 24 38 02 00 	mov    rcx,QWORD PTR [rsp+0x238]
  19dd42:	00 
  19dd43:	c4 62 f9 b9 0c ce    	vfmadd231sd xmm9,xmm0,QWORD PTR [rsi+rcx*8]
  19dd49:	48 8b b4 24 30 02 00 	mov    rsi,QWORD PTR [rsp+0x230]
  19dd50:	00 
  19dd51:	c4 c2 f9 b9 3c f6    	vfmadd231sd xmm7,xmm0,QWORD PTR [r14+rsi*8]
  19dd57:	49 be 00 00 00 00 00 	movabs r14,0xfff0000000000000
  19dd5e:	00 f0 ff 
  19dd61:	4d 01 f1             	add    r9,r14
  19dd64:	49 c1 e9 35          	shr    r9,0x35
  19dd68:	41 81 f9 ff 03 00 00 	cmp    r9d,0x3ff
  19dd6f:	4c 8b 74 24 48       	mov    r14,QWORD PTR [rsp+0x48]
  19dd74:	48 8b ac 24 28 02 00 	mov    rbp,QWORD PTR [rsp+0x228]
  19dd7b:	00 
  19dd7c:	c4 42 f9 b9 14 ee    	vfmadd231sd xmm10,xmm0,QWORD PTR [r14+rbp*8]
  19dd82:	41 0f 92 c1          	setb   r9b
  19dd86:	45 08 c1             	or     r9b,r8b
  19dd89:	c4 21 7b 11 1c da    	vmovsd QWORD PTR [rdx+r11*8],xmm11
  19dd8f:	83 f8 01             	cmp    eax,0x1
  19dd92:	4c 8b 9c 24 e8 00 00 	mov    r11,QWORD PTR [rsp+0xe8]
  19dd99:	00 
  19dd9a:	75 5f                	jne    19ddfb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0xc9b>
  19dd9c:	4c 8b 74 24 30       	mov    r14,QWORD PTR [rsp+0x30]
  19dda1:	4c 8b 44 24 60       	mov    r8,QWORD PTR [rsp+0x60]
  19dda6:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
  19ddad:	00 
  19ddae:	48 8b 6c 24 70       	mov    rbp,QWORD PTR [rsp+0x70]
  19ddb3:	4c 8b 64 24 10       	mov    r12,QWORD PTR [rsp+0x10]
  19ddb8:	48 8b 9c 24 00 01 00 	mov    rbx,QWORD PTR [rsp+0x100]
  19ddbf:	00 
  19ddc0:	e9 06 02 00 00       	jmp    19dfcb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0xe6b>
  19ddc5:	4c 8b 74 24 30       	mov    r14,QWORD PTR [rsp+0x30]
  19ddca:	4c 8b 44 24 60       	mov    r8,QWORD PTR [rsp+0x60]
  19ddcf:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
  19ddd6:	00 
  19ddd7:	48 8b 6c 24 70       	mov    rbp,QWORD PTR [rsp+0x70]
  19dddc:	4c 8b 9c 24 e8 00 00 	mov    r11,QWORD PTR [rsp+0xe8]
  19dde3:	00 
  19dde4:	4c 8b 64 24 10       	mov    r12,QWORD PTR [rsp+0x10]
  19dde9:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  19ddee:	48 8b 9c 24 00 01 00 	mov    rbx,QWORD PTR [rsp+0x100]
  19ddf5:	00 
  19ddf6:	e9 df 01 00 00       	jmp    19dfda <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0xe7a>
  19ddfb:	4c 89 bc 24 e0 01 00 	mov    QWORD PTR [rsp+0x1e0],r15
  19de02:	00 
  19de03:	4c 8b 9c 24 20 01 00 	mov    r11,QWORD PTR [rsp+0x120]
  19de0a:	00 
  19de0b:	c4 81 7b 10 44 da 08 	vmovsd xmm0,QWORD PTR [r10+r11*8+0x8]
  19de12:	4c 8b 84 24 a0 00 00 	mov    r8,QWORD PTR [rsp+0xa0]
  19de19:	00 
  19de1a:	4c 8b 5c 24 78       	mov    r11,QWORD PTR [rsp+0x78]
  19de1f:	c4 01 7b 10 5c d8 08 	vmovsd xmm11,QWORD PTR [r8+r11*8+0x8]
  19de26:	c4 62 c9 a9 dd       	vfmadd213sd xmm11,xmm6,xmm5
  19de2b:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
  19de30:	c4 02 f9 a9 5c e0 08 	vfmadd213sd xmm11,xmm0,QWORD PTR [r8+r12*8+0x8]
  19de37:	c4 41 f9 7e d8       	vmovq  r8,xmm11
  19de3c:	41 b3 3f             	mov    r11b,0x3f
  19de3f:	c4 42 a0 f5 c0       	bzhi   r8,r8,r11
  19de44:	49 bb 00 00 00 00 00 	movabs r11,0x7ff0000000000000
  19de4b:	00 f0 7f 
  19de4e:	4d 39 d8             	cmp    r8,r11
  19de51:	4d 89 f7             	mov    r15,r14
  19de54:	41 0f 94 c6          	sete   r14b
  19de58:	4d 85 c0             	test   r8,r8
  19de5b:	41 0f 94 c3          	sete   r11b
  19de5f:	45 08 f3             	or     r11b,r14b
  19de62:	4d 89 fe             	mov    r14,r15
  19de65:	49 bf 00 00 00 00 00 	movabs r15,0xfff0000000000000
  19de6c:	00 f0 ff 
  19de6f:	4d 01 f8             	add    r8,r15
  19de72:	49 c1 e8 35          	shr    r8,0x35
  19de76:	41 81 f8 ff 03 00 00 	cmp    r8d,0x3ff
  19de7d:	41 0f 92 c0          	setb   r8b
  19de81:	45 08 d8             	or     r8b,r11b
  19de84:	c4 62 f9 b9 44 df 08 	vfmadd231sd xmm8,xmm0,QWORD PTR [rdi+rbx*8+0x8]
  19de8b:	4c 8b 5c 24 20       	mov    r11,QWORD PTR [rsp+0x20]
  19de90:	c4 42 f9 b9 4c cb 08 	vfmadd231sd xmm9,xmm0,QWORD PTR [r11+rcx*8+0x8]
  19de97:	4c 8b 5c 24 28       	mov    r11,QWORD PTR [rsp+0x28]
  19de9c:	c4 c2 f9 b9 7c f3 08 	vfmadd231sd xmm7,xmm0,QWORD PTR [r11+rsi*8+0x8]
  19dea3:	c4 42 f9 b9 54 ee 08 	vfmadd231sd xmm10,xmm0,QWORD PTR [r14+rbp*8+0x8]
  19deaa:	45 20 c1             	and    r9b,r8b
  19dead:	4c 8b 84 24 98 00 00 	mov    r8,QWORD PTR [rsp+0x98]
  19deb4:	00 
  19deb5:	c4 21 7b 11 5c c2 08 	vmovsd QWORD PTR [rdx+r8*8+0x8],xmm11
  19debc:	83 f8 02             	cmp    eax,0x2
  19debf:	75 29                	jne    19deea <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0xd8a>
  19dec1:	4c 8b 9c 24 e8 00 00 	mov    r11,QWORD PTR [rsp+0xe8]
  19dec8:	00 
  19dec9:	4c 8b 74 24 30       	mov    r14,QWORD PTR [rsp+0x30]
  19dece:	4c 8b 44 24 60       	mov    r8,QWORD PTR [rsp+0x60]
  19ded3:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
  19deda:	00 
  19dedb:	48 8b 6c 24 70       	mov    rbp,QWORD PTR [rsp+0x70]
  19dee0:	4c 8b 64 24 10       	mov    r12,QWORD PTR [rsp+0x10]
  19dee5:	e9 d1 00 00 00       	jmp    19dfbb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0xe5b>
  19deea:	49 89 fb             	mov    r11,rdi
  19deed:	48 8b 84 24 20 01 00 	mov    rax,QWORD PTR [rsp+0x120]
  19def4:	00 
  19def5:	c4 c1 7b 10 44 c2 10 	vmovsd xmm0,QWORD PTR [r10+rax*8+0x10]
  19defc:	48 8b 84 24 a0 00 00 	mov    rax,QWORD PTR [rsp+0xa0]
  19df03:	00 
  19df04:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
  19df09:	c4 e2 c9 b9 6c f8 10 	vfmadd231sd xmm5,xmm6,QWORD PTR [rax+rdi*8+0x10]
  19df10:	4d 89 f7             	mov    r15,r14
  19df13:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
  19df18:	c4 82 f9 a9 6c e6 10 	vfmadd213sd xmm5,xmm0,QWORD PTR [r14+r12*8+0x10]
  19df1f:	c4 e1 f9 7e e8       	vmovq  rax,xmm5
  19df24:	40 b7 3f             	mov    dil,0x3f
  19df27:	c4 e2 c0 f5 c0       	bzhi   rax,rax,rdi
  19df2c:	48 bf 00 00 00 00 00 	movabs rdi,0x7ff0000000000000
  19df33:	00 f0 7f 
  19df36:	48 39 f8             	cmp    rax,rdi
  19df39:	40 0f 94 c7          	sete   dil
  19df3d:	48 85 c0             	test   rax,rax
  19df40:	4d 89 c4             	mov    r12,r8
  19df43:	41 0f 94 c0          	sete   r8b
  19df47:	41 08 f8             	or     r8b,dil
  19df4a:	48 bf 00 00 00 00 00 	movabs rdi,0xfff0000000000000
  19df51:	00 f0 ff 
  19df54:	48 01 f8             	add    rax,rdi
  19df57:	48 c1 e8 35          	shr    rax,0x35
  19df5b:	3d ff 03 00 00       	cmp    eax,0x3ff
  19df60:	0f 92 c0             	setb   al
  19df63:	44 08 c0             	or     al,r8b
  19df66:	41 20 c1             	and    r9b,al
  19df69:	c4 42 f9 b9 44 db 10 	vfmadd231sd xmm8,xmm0,QWORD PTR [r11+rbx*8+0x10]
  19df70:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
  19df75:	c4 62 f9 b9 4c c8 10 	vfmadd231sd xmm9,xmm0,QWORD PTR [rax+rcx*8+0x10]
  19df7c:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
  19df81:	c4 e2 f9 b9 7c f0 10 	vfmadd231sd xmm7,xmm0,QWORD PTR [rax+rsi*8+0x10]
  19df88:	c4 42 f9 b9 54 ef 10 	vfmadd231sd xmm10,xmm0,QWORD PTR [r15+rbp*8+0x10]
  19df8f:	c4 a1 7b 11 6c e2 10 	vmovsd QWORD PTR [rdx+r12*8+0x10],xmm5
  19df96:	4c 8b 9c 24 e8 00 00 	mov    r11,QWORD PTR [rsp+0xe8]
  19df9d:	00 
  19df9e:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
  19dfa3:	4c 8b 44 24 60       	mov    r8,QWORD PTR [rsp+0x60]
  19dfa8:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
  19dfaf:	00 
  19dfb0:	48 8b 6c 24 70       	mov    rbp,QWORD PTR [rsp+0x70]
  19dfb5:	4d 89 f4             	mov    r12,r14
  19dfb8:	49 89 c6             	mov    r14,rax
  19dfbb:	48 8b 9c 24 00 01 00 	mov    rbx,QWORD PTR [rsp+0x100]
  19dfc2:	00 
  19dfc3:	4c 8b bc 24 e0 01 00 	mov    r15,QWORD PTR [rsp+0x1e0]
  19dfca:	00 
  19dfcb:	44 20 4c 24 07       	and    BYTE PTR [rsp+0x7],r9b
  19dfd0:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  19dfd5:	4c 8b 4c 24 50       	mov    r9,QWORD PTR [rsp+0x50]
  19dfda:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
  19dfdf:	4d 39 f5             	cmp    r13,r14
  19dfe2:	0f 83 32 1e 00 00    	jae    19fe1a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2cba>
  19dfe8:	c4 01 7b 11 04 3b    	vmovsd QWORD PTR [r11+r15*1],xmm8
  19dfee:	c4 01 7b 11 4c 3b 08 	vmovsd QWORD PTR [r11+r15*1+0x8],xmm9
  19dff5:	4c 39 84 24 60 01 00 	cmp    QWORD PTR [rsp+0x160],r8
  19dffc:	00 
  19dffd:	48 8b 84 24 98 01 00 	mov    rax,QWORD PTR [rsp+0x198]
  19e004:	00 
  19e005:	0f 83 ef f6 ff ff    	jae    19d6fa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x59a>
  19e00b:	49 ff c5             	inc    r13
  19e00e:	4d 39 f5             	cmp    r13,r14
  19e011:	0f 83 72 1e 00 00    	jae    19fe89 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d29>
  19e017:	49 c1 e5 04          	shl    r13,0x4
  19e01b:	c4 81 7b 11 3c 2b    	vmovsd QWORD PTR [r11+r13*1],xmm7
  19e021:	c4 01 7b 11 54 2b 08 	vmovsd QWORD PTR [r11+r13*1+0x8],xmm10
  19e028:	e9 cd f6 ff ff       	jmp    19d6fa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x59a>
  19e02d:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
  19e034:	00 
  19e035:	48 89 f8             	mov    rax,rdi
  19e038:	48 c1 e8 02          	shr    rax,0x2
  19e03c:	48 89 84 24 78 01 00 	mov    QWORD PTR [rsp+0x178],rax
  19e043:	00 
  19e044:	41 89 fc             	mov    r12d,edi
  19e047:	41 83 e4 03          	and    r12d,0x3
  19e04b:	4c 8b 44 24 58       	mov    r8,QWORD PTR [rsp+0x58]
  19e050:	4c 89 c0             	mov    rax,r8
  19e053:	48 c1 e8 02          	shr    rax,0x2
  19e057:	48 89 84 24 c0 01 00 	mov    QWORD PTR [rsp+0x1c0],rax
  19e05e:	00 
  19e05f:	44 89 c0             	mov    eax,r8d
  19e062:	83 e0 03             	and    eax,0x3
  19e065:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
  19e06c:	00 
  19e06d:	4c 8b 8c 24 88 00 00 	mov    r9,QWORD PTR [rsp+0x88]
  19e074:	00 
  19e075:	4c 89 c8             	mov    rax,r9
  19e078:	48 c1 e8 02          	shr    rax,0x2
  19e07c:	48 89 84 24 b8 01 00 	mov    QWORD PTR [rsp+0x1b8],rax
  19e083:	00 
  19e084:	44 89 c8             	mov    eax,r9d
  19e087:	83 e0 03             	and    eax,0x3
  19e08a:	48 89 84 24 d0 01 00 	mov    QWORD PTR [rsp+0x1d0],rax
  19e091:	00 
  19e092:	4c 8b bc 24 80 00 00 	mov    r15,QWORD PTR [rsp+0x80]
  19e099:	00 
  19e09a:	4c 89 f8             	mov    rax,r15
  19e09d:	48 c1 e8 02          	shr    rax,0x2
  19e0a1:	48 89 84 24 b0 01 00 	mov    QWORD PTR [rsp+0x1b0],rax
  19e0a8:	00 
  19e0a9:	44 89 f8             	mov    eax,r15d
  19e0ac:	83 e0 03             	and    eax,0x3
  19e0af:	48 89 84 24 c8 01 00 	mov    QWORD PTR [rsp+0x1c8],rax
  19e0b6:	00 
  19e0b7:	4c 8b 6c 24 08       	mov    r13,QWORD PTR [rsp+0x8]
  19e0bc:	4c 89 ee             	mov    rsi,r13
  19e0bf:	48 c1 ee 02          	shr    rsi,0x2
  19e0c3:	44 89 e8             	mov    eax,r13d
  19e0c6:	83 e0 03             	and    eax,0x3
  19e0c9:	48 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rax
  19e0d0:	00 
  19e0d1:	4c 89 e9             	mov    rcx,r13
  19e0d4:	48 b8 fc ff ff ff ff 	movabs rax,0xffffffffffffffc
  19e0db:	ff ff 0f 
  19e0de:	48 21 c1             	and    rcx,rax
  19e0e1:	48 89 8c 24 98 00 00 	mov    QWORD PTR [rsp+0x98],rcx
  19e0e8:	00 
  19e0e9:	48 8b 84 24 a8 00 00 	mov    rax,QWORD PTR [rsp+0xa8]
  19e0f0:	00 
  19e0f1:	48 89 c1             	mov    rcx,rax
  19e0f4:	48 c1 e9 02          	shr    rcx,0x2
  19e0f8:	48 89 8c 24 a0 01 00 	mov    QWORD PTR [rsp+0x1a0],rcx
  19e0ff:	00 
  19e100:	48 c1 e8 03          	shr    rax,0x3
  19e104:	48 89 c5             	mov    rbp,rax
  19e107:	4c 89 e8             	mov    rax,r13
  19e10a:	eb 46                	jmp    19e152 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0xff2>
  19e10c:	c5 7d 28 f9          	vmovapd ymm15,ymm1
  19e110:	48 89 f8             	mov    rax,rdi
  19e113:	49 89 d2             	mov    r10,rdx
  19e116:	48 8b bc 24 d0 00 00 	mov    rdi,QWORD PTR [rsp+0xd0]
  19e11d:	00 
  19e11e:	4c 8b 44 24 58       	mov    r8,QWORD PTR [rsp+0x58]
  19e123:	4c 8b 8c 24 88 00 00 	mov    r9,QWORD PTR [rsp+0x88]
  19e12a:	00 
  19e12b:	4c 8b bc 24 80 00 00 	mov    r15,QWORD PTR [rsp+0x80]
  19e132:	00 
  19e133:	48 ba fe ff ff ff ff 	movabs rdx,0x3fffffffffffffe
  19e13a:	ff ff 03 
  19e13d:	48 8b 6c 24 40       	mov    rbp,QWORD PTR [rsp+0x40]
  19e142:	4c 8b a4 24 48 01 00 	mov    r12,QWORD PTR [rsp+0x148]
  19e149:	00 
  19e14a:	48 8b b4 24 30 01 00 	mov    rsi,QWORD PTR [rsp+0x130]
  19e151:	00 
  19e152:	48 21 d6             	and    rsi,rdx
  19e155:	48 c1 e6 05          	shl    rsi,0x5
  19e159:	48 89 b4 24 30 01 00 	mov    QWORD PTR [rsp+0x130],rsi
  19e160:	00 
  19e161:	48 89 44 24 08       	mov    QWORD PTR [rsp+0x8],rax
  19e166:	48 89 c2             	mov    rdx,rax
  19e169:	48 c1 ea 03          	shr    rdx,0x3
  19e16d:	48 89 f8             	mov    rax,rdi
  19e170:	48 c1 e8 03          	shr    rax,0x3
  19e174:	4c 89 c7             	mov    rdi,r8
  19e177:	48 c1 ef 03          	shr    rdi,0x3
  19e17b:	48 39 c7             	cmp    rdi,rax
  19e17e:	48 0f 43 f8          	cmovae rdi,rax
  19e182:	4d 89 c8             	mov    r8,r9
  19e185:	49 c1 e8 03          	shr    r8,0x3
  19e189:	49 39 f8             	cmp    r8,rdi
  19e18c:	4c 0f 43 c7          	cmovae r8,rdi
  19e190:	4c 89 f8             	mov    rax,r15
  19e193:	48 c1 e8 03          	shr    rax,0x3
  19e197:	4c 39 c0             	cmp    rax,r8
  19e19a:	49 0f 43 c0          	cmovae rax,r8
  19e19e:	48 39 c2             	cmp    rdx,rax
  19e1a1:	48 0f 42 c2          	cmovb  rax,rdx
  19e1a5:	48 39 c5             	cmp    rbp,rax
  19e1a8:	48 0f 42 c5          	cmovb  rax,rbp
  19e1ac:	48 85 c0             	test   rax,rax
  19e1af:	4c 8b ac 24 d8 01 00 	mov    r13,QWORD PTR [rsp+0x1d8]
  19e1b6:	00 
  19e1b7:	48 8b 4c 24 48       	mov    rcx,QWORD PTR [rsp+0x48]
  19e1bc:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
  19e1c1:	48 bf fe ff ff ff ff 	movabs rdi,0x1ffffffffffffffe
  19e1c8:	ff ff 1f 
  19e1cb:	0f 84 69 12 00 00    	je     19f43a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x22da>
  19e1d1:	48 83 f8 01          	cmp    rax,0x1
  19e1d5:	0f 85 8d 12 00 00    	jne    19f468 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2308>
  19e1db:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
  19e1df:	31 ff                	xor    edi,edi
  19e1e1:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
  19e1e5:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
  19e1e9:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  19e1ed:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  19e1f1:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  19e1f5:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  19e1f9:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  19e1fe:	4c 8b bc 24 b0 00 00 	mov    r15,QWORD PTR [rsp+0xb0]
  19e205:	00 
  19e206:	e9 56 13 00 00       	jmp    19f561 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2401>
  19e20b:	49 89 cf             	mov    r15,rcx
  19e20e:	45 89 e8             	mov    r8d,r13d
  19e211:	41 83 e0 03          	and    r8d,0x3
  19e215:	48 8b 8c 24 a8 00 00 	mov    rcx,QWORD PTR [rsp+0xa8]
  19e21c:	00 
  19e21d:	89 ca                	mov    edx,ecx
  19e21f:	83 e2 03             	and    edx,0x3
  19e222:	44 39 c2             	cmp    edx,r8d
  19e225:	4c 8b 5c 24 58       	mov    r11,QWORD PTR [rsp+0x58]
  19e22a:	0f 85 4a 1b 00 00    	jne    19fd7a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c1a>
  19e230:	48 8b 8c 24 18 01 00 	mov    rcx,QWORD PTR [rsp+0x118]
  19e237:	00 
  19e238:	83 e1 03             	and    ecx,0x3
  19e23b:	48 89 8c 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rcx
  19e242:	00 
  19e243:	44 39 c1             	cmp    ecx,r8d
  19e246:	0f 85 2e 1b 00 00    	jne    19fd7a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c1a>
  19e24c:	48 8b 94 24 a8 00 00 	mov    rdx,QWORD PTR [rsp+0xa8]
  19e253:	00 
  19e254:	48 c1 ea 02          	shr    rdx,0x2
  19e258:	4c 39 fa             	cmp    rdx,r15
  19e25b:	0f 85 19 1b 00 00    	jne    19fd7a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c1a>
  19e261:	48 8b 94 24 18 01 00 	mov    rdx,QWORD PTR [rsp+0x118]
  19e268:	00 
  19e269:	48 c1 ea 02          	shr    rdx,0x2
  19e26d:	4c 39 fa             	cmp    rdx,r15
  19e270:	0f 85 04 1b 00 00    	jne    19fd7a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c1a>
  19e276:	44 89 da             	mov    edx,r11d
  19e279:	83 e2 03             	and    edx,0x3
  19e27c:	41 39 d0             	cmp    r8d,edx
  19e27f:	0f 85 f5 1a 00 00    	jne    19fd7a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c1a>
  19e285:	4c 89 44 24 08       	mov    QWORD PTR [rsp+0x8],r8
  19e28a:	4c 8b 8c 24 88 00 00 	mov    r9,QWORD PTR [rsp+0x88]
  19e291:	00 
  19e292:	41 83 e1 03          	and    r9d,0x3
  19e296:	41 39 d1             	cmp    r9d,edx
  19e299:	0f 85 db 1a 00 00    	jne    19fd7a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c1a>
  19e29f:	4c 8b 8c 24 80 00 00 	mov    r9,QWORD PTR [rsp+0x80]
  19e2a6:	00 
  19e2a7:	41 83 e1 03          	and    r9d,0x3
  19e2ab:	41 39 d1             	cmp    r9d,edx
  19e2ae:	0f 85 c6 1a 00 00    	jne    19fd7a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c1a>
  19e2b4:	4c 89 b4 24 d8 01 00 	mov    QWORD PTR [rsp+0x1d8],r14
  19e2bb:	00 
  19e2bc:	49 b8 fc ff ff ff ff 	movabs r8,0xffffffffffffffc
  19e2c3:	ff ff 0f 
  19e2c6:	4d 21 c5             	and    r13,r8
  19e2c9:	4c 89 ac 24 10 01 00 	mov    QWORD PTR [rsp+0x110],r13
  19e2d0:	00 
  19e2d1:	4d 21 c3             	and    r11,r8
  19e2d4:	4c 89 5c 24 78       	mov    QWORD PTR [rsp+0x78],r11
  19e2d9:	48 8b 94 24 88 00 00 	mov    rdx,QWORD PTR [rsp+0x88]
  19e2e0:	00 
  19e2e1:	4c 21 c2             	and    rdx,r8
  19e2e4:	48 8b 8c 24 80 00 00 	mov    rcx,QWORD PTR [rsp+0x80]
  19e2eb:	00 
  19e2ec:	4c 21 c1             	and    rcx,r8
  19e2ef:	48 89 8c 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rcx
  19e2f6:	00 
  19e2f7:	48 8b 8c 24 18 01 00 	mov    rcx,QWORD PTR [rsp+0x118]
  19e2fe:	00 
  19e2ff:	4c 21 c1             	and    rcx,r8
  19e302:	48 89 8c 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rcx
  19e309:	00 
  19e30a:	89 f1                	mov    ecx,esi
  19e30c:	83 e1 03             	and    ecx,0x3
  19e30f:	4c 21 c6             	and    rsi,r8
  19e312:	48 89 b4 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rsi
  19e319:	00 
  19e31a:	48 8d 71 ff          	lea    rsi,[rcx-0x1]
  19e31e:	48 39 ce             	cmp    rsi,rcx
  19e321:	48 89 8c 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],rcx
  19e328:	00 
  19e329:	48 0f 43 f1          	cmovae rsi,rcx
  19e32d:	48 89 b4 24 88 01 00 	mov    QWORD PTR [rsp+0x188],rsi
  19e334:	00 
  19e335:	4c 89 f9             	mov    rcx,r15
  19e338:	48 83 e1 fe          	and    rcx,0xfffffffffffffffe
  19e33c:	48 89 8c 24 50 01 00 	mov    QWORD PTR [rsp+0x150],rcx
  19e343:	00 
  19e344:	4c 8b 8c 24 98 00 00 	mov    r9,QWORD PTR [rsp+0x98]
  19e34b:	00 
  19e34c:	49 83 e1 fe          	and    r9,0xfffffffffffffffe
  19e350:	c6 44 24 07 01       	mov    BYTE PTR [rsp+0x7],0x1
  19e355:	48 89 c6             	mov    rsi,rax
  19e358:	48 8b 84 24 a8 00 00 	mov    rax,QWORD PTR [rsp+0xa8]
  19e35f:	00 
  19e360:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
  19e365:	4c 8b 9c 24 e8 00 00 	mov    r11,QWORD PTR [rsp+0xe8]
  19e36c:	00 
  19e36d:	4c 8b 74 24 30       	mov    r14,QWORD PTR [rsp+0x30]
  19e372:	4c 89 7c 24 70       	mov    QWORD PTR [rsp+0x70],r15
  19e377:	c5 7d 11 bc 24 50 02 	vmovupd YMMWORD PTR [rsp+0x250],ymm15
  19e37e:	00 00 
  19e380:	48 89 94 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rdx
  19e387:	00 
  19e388:	4c 89 4c 24 40       	mov    QWORD PTR [rsp+0x40],r9
  19e38d:	eb 1f                	jmp    19e3ae <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x124e>
  19e38f:	48 83 c6 02          	add    rsi,0x2
  19e393:	4c 89 ef             	mov    rdi,r13
  19e396:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
  19e39b:	48 89 44 24 50       	mov    QWORD PTR [rsp+0x50],rax
  19e3a0:	48 3b b4 24 98 01 00 	cmp    rsi,QWORD PTR [rsp+0x198]
  19e3a7:	00 
  19e3a8:	0f 83 1a 1a 00 00    	jae    19fdc8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c68>
  19e3ae:	4c 8b 6c 24 10       	mov    r13,QWORD PTR [rsp+0x10]
  19e3b3:	4c 89 54 24 10       	mov    QWORD PTR [rsp+0x10],r10
  19e3b8:	48 8b 8c 24 c8 00 00 	mov    rcx,QWORD PTR [rsp+0xc8]
  19e3bf:	00 
  19e3c0:	48 39 ce             	cmp    rsi,rcx
  19e3c3:	48 89 74 24 18       	mov    QWORD PTR [rsp+0x18],rsi
  19e3c8:	0f 83 cd 1b 00 00    	jae    19ff9b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2e3b>
  19e3ce:	48 89 f0             	mov    rax,rsi
  19e3d1:	48 8b b4 24 f0 00 00 	mov    rsi,QWORD PTR [rsp+0xf0]
  19e3d8:	00 
  19e3d9:	48 39 f0             	cmp    rax,rsi
  19e3dc:	0f 83 db 1b 00 00    	jae    19ffbd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2e5d>
  19e3e2:	48 ff c0             	inc    rax
  19e3e5:	48 39 c8             	cmp    rax,rcx
  19e3e8:	0f 83 c7 1a 00 00    	jae    19feb5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d55>
  19e3ee:	48 39 f0             	cmp    rax,rsi
  19e3f1:	0f 83 d9 1a 00 00    	jae    19fed0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d70>
  19e3f7:	49 89 fa             	mov    r10,rdi
  19e3fa:	48 8b 4c 24 50       	mov    rcx,QWORD PTR [rsp+0x50]
  19e3ff:	48 89 cf             	mov    rdi,rcx
  19e402:	48 c1 ef 02          	shr    rdi,0x2
  19e406:	31 c0                	xor    eax,eax
  19e408:	4c 39 ff             	cmp    rdi,r15
  19e40b:	0f 85 a2 19 00 00    	jne    19fdb3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c53>
  19e411:	89 cf                	mov    edi,ecx
  19e413:	83 e7 03             	and    edi,0x3
  19e416:	3b 7c 24 08          	cmp    edi,DWORD PTR [rsp+0x8]
  19e41a:	0f 85 93 19 00 00    	jne    19fdb3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c53>
  19e420:	48 8b 84 24 00 02 00 	mov    rax,QWORD PTR [rsp+0x200]
  19e427:	00 
  19e428:	48 8b 54 24 18       	mov    rdx,QWORD PTR [rsp+0x18]
  19e42d:	c5 fb 10 04 d0       	vmovsd xmm0,QWORD PTR [rax+rdx*8]
  19e432:	48 8b 8c 24 f8 01 00 	mov    rcx,QWORD PTR [rsp+0x1f8]
  19e439:	00 
  19e43a:	c5 fb 10 24 d1       	vmovsd xmm4,QWORD PTR [rcx+rdx*8]
  19e43f:	c5 fb 10 4c d0 08    	vmovsd xmm1,QWORD PTR [rax+rdx*8+0x8]
  19e445:	c5 fb 10 5c d1 08    	vmovsd xmm3,QWORD PTR [rcx+rdx*8+0x8]
  19e44b:	4d 85 ff             	test   r15,r15
  19e44e:	c5 f9 29 8c 24 20 01 	vmovapd XMMWORD PTR [rsp+0x120],xmm1
  19e455:	00 00 
  19e457:	c5 f9 29 84 24 60 01 	vmovapd XMMWORD PTR [rsp+0x160],xmm0
  19e45e:	00 00 
  19e460:	c5 f9 29 9c 24 a0 01 	vmovapd XMMWORD PTR [rsp+0x1a0],xmm3
  19e467:	00 00 
  19e469:	c5 f9 29 a4 24 30 01 	vmovapd XMMWORD PTR [rsp+0x130],xmm4
  19e470:	00 00 
  19e472:	0f 84 d2 00 00 00    	je     19e54a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x13ea>
  19e478:	c4 e2 7d 19 d0       	vbroadcastsd ymm2,xmm0
  19e47d:	c4 e2 7d 19 c4       	vbroadcastsd ymm0,xmm4
  19e482:	c4 62 7d 19 f1       	vbroadcastsd ymm14,xmm1
  19e487:	c4 62 7d 19 e3       	vbroadcastsd ymm12,xmm3
  19e48c:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  19e490:	4c 89 f8             	mov    rax,r15
  19e493:	31 ff                	xor    edi,edi
  19e495:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  19e499:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  19e49e:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  19e4a2:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  19e4a7:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  19e4ab:	c4 41 21 57 db       	vxorpd xmm11,xmm11,xmm11
  19e4b0:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  19e4b5:	4c 8b 4c 24 38       	mov    r9,QWORD PTR [rsp+0x38]
  19e4ba:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
  19e4bf:	48 8b 4c 24 28       	mov    rcx,QWORD PTR [rsp+0x28]
  19e4c4:	4c 8b 7c 24 48       	mov    r15,QWORD PTR [rsp+0x48]
  19e4c9:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
  19e4ce:	66 90                	xchg   ax,ax
  19e4d0:	c5 7d 10 3c 3a       	vmovupd ymm15,YMMWORD PTR [rdx+rdi*1]
  19e4d5:	c4 41 7d 10 2c 39    	vmovupd ymm13,YMMWORD PTR [r9+rdi*1]
  19e4db:	c4 42 95 b8 d7       	vfmadd231pd ymm10,ymm13,ymm15
  19e4e0:	c4 c1 7d 10 0c 3c    	vmovupd ymm1,YMMWORD PTR [r12+rdi*1]
  19e4e6:	c5 fd 28 d9          	vmovapd ymm3,ymm1
  19e4ea:	c4 e2 ed a8 d8       	vfmadd213pd ymm3,ymm2,ymm0
  19e4ef:	c4 c2 85 a8 1c 3a    	vfmadd213pd ymm3,ymm15,YMMWORD PTR [r10+rdi*1]
  19e4f5:	c4 c2 e5 b8 ed       	vfmadd231pd ymm5,ymm3,ymm13
  19e4fa:	c5 7d 10 2c 3e       	vmovupd ymm13,YMMWORD PTR [rsi+rdi*1]
  19e4ff:	c4 42 95 b8 df       	vfmadd231pd ymm11,ymm13,ymm15
  19e504:	c4 42 e5 b8 c5       	vfmadd231pd ymm8,ymm3,ymm13
  19e509:	c5 7d 10 2c 39       	vmovupd ymm13,YMMWORD PTR [rcx+rdi*1]
  19e50e:	c4 c2 95 b8 ff       	vfmadd231pd ymm7,ymm13,ymm15
  19e513:	c4 c2 e5 b8 e5       	vfmadd231pd ymm4,ymm3,ymm13
  19e518:	c4 41 7d 10 2c 3f    	vmovupd ymm13,YMMWORD PTR [r15+rdi*1]
  19e51e:	c4 42 95 b8 cf       	vfmadd231pd ymm9,ymm13,ymm15
  19e523:	c4 c2 e5 b8 f5       	vfmadd231pd ymm6,ymm3,ymm13
  19e528:	c4 c2 8d a8 cc       	vfmadd213pd ymm1,ymm14,ymm12
  19e52d:	c4 c2 e5 a8 cf       	vfmadd213pd ymm1,ymm3,ymm15
  19e532:	c4 c1 7d 11 5c 3d 00 	vmovupd YMMWORD PTR [r13+rdi*1+0x0],ymm3
  19e539:	c4 c1 7d 11 0c 3a    	vmovupd YMMWORD PTR [r10+rdi*1],ymm1
  19e53f:	48 83 c7 20          	add    rdi,0x20
  19e543:	48 ff c8             	dec    rax
  19e546:	75 88                	jne    19e4d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1370>
  19e548:	eb 24                	jmp    19e56e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x140e>
  19e54a:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  19e54f:	c4 41 21 57 db       	vxorpd xmm11,xmm11,xmm11
  19e554:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  19e558:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  19e55d:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  19e561:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  19e566:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  19e56a:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  19e56e:	c4 63 7d 19 d0 01    	vextractf128 xmm0,ymm10,0x1
  19e574:	c5 a9 58 c0          	vaddpd xmm0,xmm10,xmm0
  19e578:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19e57d:	c5 7b 58 f9          	vaddsd xmm15,xmm0,xmm1
  19e581:	c4 63 7d 19 d8 01    	vextractf128 xmm0,ymm11,0x1
  19e587:	c5 a1 58 c0          	vaddpd xmm0,xmm11,xmm0
  19e58b:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19e590:	c5 7b 58 d9          	vaddsd xmm11,xmm0,xmm1
  19e594:	c4 e3 7d 19 f8 01    	vextractf128 xmm0,ymm7,0x1
  19e59a:	c5 c1 58 c0          	vaddpd xmm0,xmm7,xmm0
  19e59e:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19e5a3:	c5 7b 58 e1          	vaddsd xmm12,xmm0,xmm1
  19e5a7:	c4 63 7d 19 c8 01    	vextractf128 xmm0,ymm9,0x1
  19e5ad:	c5 b1 58 c0          	vaddpd xmm0,xmm9,xmm0
  19e5b1:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19e5b6:	c5 7b 58 c9          	vaddsd xmm9,xmm0,xmm1
  19e5ba:	c4 e3 7d 19 e8 01    	vextractf128 xmm0,ymm5,0x1
  19e5c0:	c5 d1 58 c0          	vaddpd xmm0,xmm5,xmm0
  19e5c4:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19e5c9:	c5 fb 58 e9          	vaddsd xmm5,xmm0,xmm1
  19e5cd:	c4 63 7d 19 c0 01    	vextractf128 xmm0,ymm8,0x1
  19e5d3:	c5 b9 58 c0          	vaddpd xmm0,xmm8,xmm0
  19e5d7:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19e5dc:	c5 7b 58 d1          	vaddsd xmm10,xmm0,xmm1
  19e5e0:	c4 e3 7d 19 e0 01    	vextractf128 xmm0,ymm4,0x1
  19e5e6:	c5 d9 58 c0          	vaddpd xmm0,xmm4,xmm0
  19e5ea:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19e5ef:	c5 fb 58 e1          	vaddsd xmm4,xmm0,xmm1
  19e5f3:	c4 e3 7d 19 f0 01    	vextractf128 xmm0,ymm6,0x1
  19e5f9:	c5 c9 58 c0          	vaddpd xmm0,xmm6,xmm0
  19e5fd:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19e602:	c5 fb 58 f9          	vaddsd xmm7,xmm0,xmm1
  19e606:	48 83 bc 24 90 01 00 	cmp    QWORD PTR [rsp+0x190],0x0
  19e60d:	00 00 
  19e60f:	0f 84 a2 01 00 00    	je     19e7b7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1657>
  19e615:	48 83 7c 24 08 00    	cmp    QWORD PTR [rsp+0x8],0x0
  19e61b:	4c 8b 7c 24 20       	mov    r15,QWORD PTR [rsp+0x20]
  19e620:	4c 8b 64 24 28       	mov    r12,QWORD PTR [rsp+0x28]
  19e625:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
  19e62c:	00 
  19e62d:	48 8b 94 24 10 01 00 	mov    rdx,QWORD PTR [rsp+0x110]
  19e634:	00 
  19e635:	48 8b 74 24 78       	mov    rsi,QWORD PTR [rsp+0x78]
  19e63a:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
  19e641:	00 
  19e642:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
  19e649:	00 
  19e64a:	c4 41 11 57 ed       	vxorpd xmm13,xmm13,xmm13
  19e64f:	c4 62 7d 19 35 a0 29 	vbroadcastsd ymm14,QWORD PTR [rip+0xffffffffffe829a0]        # 20ff8 <anon.18cb9c1b3fe794d0b89f358a70182f4e.25.llvm.5582884991536083740+0x388>
  19e656:	e8 ff 
  19e658:	0f 84 53 17 00 00    	je     19fdb1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c51>
  19e65e:	4c 8b 84 24 a0 00 00 	mov    r8,QWORD PTR [rsp+0xa0]
  19e665:	00 
  19e666:	c4 c1 7b 10 04 f8    	vmovsd xmm0,QWORD PTR [r8+rdi*8]
  19e66c:	c5 f9 28 d0          	vmovapd xmm2,xmm0
  19e670:	c5 f9 28 f4          	vmovapd xmm6,xmm4
  19e674:	c5 f9 28 8c 24 30 01 	vmovapd xmm1,XMMWORD PTR [rsp+0x130]
  19e67b:	00 00 
  19e67d:	c4 e2 f1 99 94 24 60 	vfmadd132sd xmm2,xmm1,QWORD PTR [rsp+0x160]
  19e684:	01 00 00 
  19e687:	c5 79 28 c5          	vmovapd xmm8,xmm5
  19e68b:	c5 79 29 cd          	vmovapd xmm5,xmm9
  19e68f:	c4 41 79 28 cc       	vmovapd xmm9,xmm12
  19e694:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
  19e699:	c4 41 7b 10 24 f0    	vmovsd xmm12,QWORD PTR [r8+rsi*8]
  19e69f:	c4 c2 99 a9 14 f2    	vfmadd213sd xmm2,xmm12,QWORD PTR [r10+rsi*8]
  19e6a5:	c5 f9 28 a4 24 a0 01 	vmovapd xmm4,XMMWORD PTR [rsp+0x1a0]
  19e6ac:	00 00 
  19e6ae:	c4 e2 d9 99 84 24 20 	vfmadd132sd xmm0,xmm4,QWORD PTR [rsp+0x120]
  19e6b5:	01 00 00 
  19e6b8:	c4 c2 e9 a9 c4       	vfmadd213sd xmm0,xmm2,xmm12
  19e6bd:	4c 8b 44 24 48       	mov    r8,QWORD PTR [rsp+0x48]
  19e6c2:	c4 c1 7b 10 0c c0    	vmovsd xmm1,QWORD PTR [r8+rax*8]
  19e6c8:	c4 e2 f1 b9 fa       	vfmadd231sd xmm7,xmm1,xmm2
  19e6cd:	c4 e2 99 b9 e9       	vfmadd231sd xmm5,xmm12,xmm1
  19e6d2:	4c 8b 84 24 08 01 00 	mov    r8,QWORD PTR [rsp+0x108]
  19e6d9:	00 
  19e6da:	c4 81 7b 10 0c c4    	vmovsd xmm1,QWORD PTR [r12+r8*8]
  19e6e0:	c4 e2 f1 b9 f2       	vfmadd231sd xmm6,xmm1,xmm2
  19e6e5:	c4 62 99 b9 c9       	vfmadd231sd xmm9,xmm12,xmm1
  19e6ea:	c4 c1 7b 10 0c f7    	vmovsd xmm1,QWORD PTR [r15+rsi*8]
  19e6f0:	c4 62 f1 b9 d2       	vfmadd231sd xmm10,xmm1,xmm2
  19e6f5:	c5 79 29 db          	vmovapd xmm3,xmm11
  19e6f9:	c4 e2 99 b9 d9       	vfmadd231sd xmm3,xmm12,xmm1
  19e6fe:	4c 8b 44 24 38       	mov    r8,QWORD PTR [rsp+0x38]
  19e703:	c4 c1 7b 10 0c d0    	vmovsd xmm1,QWORD PTR [r8+rdx*8]
  19e709:	c4 42 f1 b9 fc       	vfmadd231sd xmm15,xmm1,xmm12
  19e70e:	c4 62 f1 b9 c2       	vfmadd231sd xmm8,xmm1,xmm2
  19e713:	48 8b 7c 24 50       	mov    rdi,QWORD PTR [rsp+0x50]
  19e718:	48 b8 fc ff ff ff ff 	movabs rax,0xffffffffffffffc
  19e71f:	ff ff 0f 
  19e722:	48 21 c7             	and    rdi,rax
  19e725:	c4 c1 7b 11 54 fd 00 	vmovsd QWORD PTR [r13+rdi*8+0x0],xmm2
  19e72c:	c4 e1 f9 7e d0       	vmovq  rax,xmm2
  19e731:	c4 c1 f9 7e c0       	vmovq  r8,xmm0
  19e736:	c4 c1 7b 11 04 f2    	vmovsd QWORD PTR [r10+rsi*8],xmm0
  19e73c:	41 b4 3f             	mov    r12b,0x3f
  19e73f:	c4 e2 98 f5 c0       	bzhi   rax,rax,r12
  19e744:	49 bf 00 00 00 00 00 	movabs r15,0x7ff0000000000000
  19e74b:	00 f0 7f 
  19e74e:	4c 39 f8             	cmp    rax,r15
  19e751:	41 0f 94 c1          	sete   r9b
  19e755:	48 85 c0             	test   rax,rax
  19e758:	41 0f 94 c3          	sete   r11b
  19e75c:	45 08 cb             	or     r11b,r9b
  19e75f:	48 ba 00 00 00 00 00 	movabs rdx,0xfff0000000000000
  19e766:	00 f0 ff 
  19e769:	48 01 d0             	add    rax,rdx
  19e76c:	48 c1 e8 35          	shr    rax,0x35
  19e770:	3d ff 03 00 00       	cmp    eax,0x3ff
  19e775:	41 0f 92 c1          	setb   r9b
  19e779:	45 08 d9             	or     r9b,r11b
  19e77c:	c4 c2 98 f5 c0       	bzhi   rax,r8,r12
  19e781:	4c 39 f8             	cmp    rax,r15
  19e784:	41 0f 94 c0          	sete   r8b
  19e788:	48 85 c0             	test   rax,rax
  19e78b:	41 0f 94 c3          	sete   r11b
  19e78f:	45 08 c3             	or     r11b,r8b
  19e792:	48 01 d0             	add    rax,rdx
  19e795:	48 c1 e8 35          	shr    rax,0x35
  19e799:	3d ff 03 00 00       	cmp    eax,0x3ff
  19e79e:	0f 92 c0             	setb   al
  19e7a1:	44 08 d8             	or     al,r11b
  19e7a4:	44 20 c8             	and    al,r9b
  19e7a7:	83 7c 24 08 01       	cmp    DWORD PTR [rsp+0x8],0x1
  19e7ac:	75 47                	jne    19e7f5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1695>
  19e7ae:	c5 79 28 db          	vmovapd xmm11,xmm3
  19e7b2:	e9 0a 04 00 00       	jmp    19ebc1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1a61>
  19e7b7:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
  19e7be:	00 
  19e7bf:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  19e7c4:	4c 8b 44 24 70       	mov    r8,QWORD PTR [rsp+0x70]
  19e7c9:	48 8b bc 24 50 01 00 	mov    rdi,QWORD PTR [rsp+0x150]
  19e7d0:	00 
  19e7d1:	4c 8b 4c 24 40       	mov    r9,QWORD PTR [rsp+0x40]
  19e7d6:	c4 41 11 57 ed       	vxorpd xmm13,xmm13,xmm13
  19e7db:	b2 3f                	mov    dl,0x3f
  19e7dd:	49 bf 00 00 00 00 00 	movabs r15,0x7ff0000000000000
  19e7e4:	00 f0 7f 
  19e7e7:	c4 62 7d 19 35 08 28 	vbroadcastsd ymm14,QWORD PTR [rip+0xffffffffffe82808]        # 20ff8 <anon.18cb9c1b3fe794d0b89f358a70182f4e.25.llvm.5582884991536083740+0x388>
  19e7ee:	e8 ff 
  19e7f0:	e9 02 04 00 00       	jmp    19ebf7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1a97>
  19e7f5:	4c 8b 84 24 a0 00 00 	mov    r8,QWORD PTR [rsp+0xa0]
  19e7fc:	00 
  19e7fd:	4c 8b 8c 24 d8 00 00 	mov    r9,QWORD PTR [rsp+0xd8]
  19e804:	00 
  19e805:	c4 81 7b 10 44 c8 08 	vmovsd xmm0,QWORD PTR [r8+r9*8+0x8]
  19e80c:	c5 f9 28 d0          	vmovapd xmm2,xmm0
  19e810:	c5 79 28 9c 24 30 01 	vmovapd xmm11,XMMWORD PTR [rsp+0x130]
  19e817:	00 00 
  19e819:	c4 e2 a1 99 94 24 60 	vfmadd132sd xmm2,xmm11,QWORD PTR [rsp+0x160]
  19e820:	01 00 00 
  19e823:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
  19e828:	c4 41 7b 10 64 f0 08 	vmovsd xmm12,QWORD PTR [r8+rsi*8+0x8]
  19e82f:	c4 c2 99 a9 54 f2 08 	vfmadd213sd xmm2,xmm12,QWORD PTR [r10+rsi*8+0x8]
  19e836:	c4 e2 d9 99 84 24 20 	vfmadd132sd xmm0,xmm4,QWORD PTR [rsp+0x120]
  19e83d:	01 00 00 
  19e840:	c4 c2 e9 a9 c4       	vfmadd213sd xmm0,xmm2,xmm12
  19e845:	4c 8b 44 24 48       	mov    r8,QWORD PTR [rsp+0x48]
  19e84a:	4c 8b 8c 24 e0 00 00 	mov    r9,QWORD PTR [rsp+0xe0]
  19e851:	00 
  19e852:	c4 81 7b 10 4c c8 08 	vmovsd xmm1,QWORD PTR [r8+r9*8+0x8]
  19e859:	c4 e2 f1 b9 fa       	vfmadd231sd xmm7,xmm1,xmm2
  19e85e:	c4 e2 99 b9 e9       	vfmadd231sd xmm5,xmm12,xmm1
  19e863:	4c 8b 84 24 08 01 00 	mov    r8,QWORD PTR [rsp+0x108]
  19e86a:	00 
  19e86b:	4c 8b 4c 24 28       	mov    r9,QWORD PTR [rsp+0x28]
  19e870:	c4 81 7b 10 4c c1 08 	vmovsd xmm1,QWORD PTR [r9+r8*8+0x8]
  19e877:	c4 e2 f1 b9 f2       	vfmadd231sd xmm6,xmm1,xmm2
  19e87c:	c4 62 99 b9 c9       	vfmadd231sd xmm9,xmm12,xmm1
  19e881:	4c 8b 44 24 20       	mov    r8,QWORD PTR [rsp+0x20]
  19e886:	c4 c1 7b 10 4c f0 08 	vmovsd xmm1,QWORD PTR [r8+rsi*8+0x8]
  19e88d:	c4 62 f1 b9 d2       	vfmadd231sd xmm10,xmm1,xmm2
  19e892:	c4 e2 99 b9 d9       	vfmadd231sd xmm3,xmm12,xmm1
  19e897:	4c 8b 84 24 10 01 00 	mov    r8,QWORD PTR [rsp+0x110]
  19e89e:	00 
  19e89f:	4c 8b 4c 24 38       	mov    r9,QWORD PTR [rsp+0x38]
  19e8a4:	c4 81 7b 10 4c c1 08 	vmovsd xmm1,QWORD PTR [r9+r8*8+0x8]
  19e8ab:	c4 42 f1 b9 fc       	vfmadd231sd xmm15,xmm1,xmm12
  19e8b0:	c4 62 f1 b9 c2       	vfmadd231sd xmm8,xmm1,xmm2
  19e8b5:	c4 c1 f9 7e d0       	vmovq  r8,xmm2
  19e8ba:	c4 c1 7b 11 54 fd 08 	vmovsd QWORD PTR [r13+rdi*8+0x8],xmm2
  19e8c1:	c4 c1 f9 7e c1       	vmovq  r9,xmm0
  19e8c6:	c4 c1 7b 11 44 f2 08 	vmovsd QWORD PTR [r10+rsi*8+0x8],xmm0
  19e8cd:	41 b4 3f             	mov    r12b,0x3f
  19e8d0:	c4 42 98 f5 c0       	bzhi   r8,r8,r12
  19e8d5:	4d 39 f8             	cmp    r8,r15
  19e8d8:	41 0f 94 c3          	sete   r11b
  19e8dc:	4d 85 c0             	test   r8,r8
  19e8df:	41 0f 94 c6          	sete   r14b
  19e8e3:	45 08 de             	or     r14b,r11b
  19e8e6:	49 01 d0             	add    r8,rdx
  19e8e9:	49 c1 e8 35          	shr    r8,0x35
  19e8ed:	41 81 f8 ff 03 00 00 	cmp    r8d,0x3ff
  19e8f4:	41 0f 92 c0          	setb   r8b
  19e8f8:	45 08 f0             	or     r8b,r14b
  19e8fb:	c4 42 98 f5 c9       	bzhi   r9,r9,r12
  19e900:	4d 39 f9             	cmp    r9,r15
  19e903:	41 0f 94 c3          	sete   r11b
  19e907:	4d 85 c9             	test   r9,r9
  19e90a:	41 0f 94 c6          	sete   r14b
  19e90e:	45 08 de             	or     r14b,r11b
  19e911:	49 01 d1             	add    r9,rdx
  19e914:	49 c1 e9 35          	shr    r9,0x35
  19e918:	41 81 f9 ff 03 00 00 	cmp    r9d,0x3ff
  19e91f:	41 0f 92 c1          	setb   r9b
  19e923:	45 08 f1             	or     r9b,r14b
  19e926:	45 20 c1             	and    r9b,r8b
  19e929:	44 20 c8             	and    al,r9b
  19e92c:	83 7c 24 08 02       	cmp    DWORD PTR [rsp+0x8],0x2
  19e931:	0f 84 35 01 00 00    	je     19ea6c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x190c>
  19e937:	4c 8b 84 24 a0 00 00 	mov    r8,QWORD PTR [rsp+0xa0]
  19e93e:	00 
  19e93f:	4c 8b 8c 24 d8 00 00 	mov    r9,QWORD PTR [rsp+0xd8]
  19e946:	00 
  19e947:	c4 81 7b 10 44 c8 10 	vmovsd xmm0,QWORD PTR [r8+r9*8+0x10]
  19e94e:	c5 f9 28 d0          	vmovapd xmm2,xmm0
  19e952:	c4 e2 a1 99 94 24 60 	vfmadd132sd xmm2,xmm11,QWORD PTR [rsp+0x160]
  19e959:	01 00 00 
  19e95c:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
  19e961:	c4 41 7b 10 64 f0 10 	vmovsd xmm12,QWORD PTR [r8+rsi*8+0x10]
  19e968:	c4 c2 99 a9 54 f2 10 	vfmadd213sd xmm2,xmm12,QWORD PTR [r10+rsi*8+0x10]
  19e96f:	c4 e2 d9 99 84 24 20 	vfmadd132sd xmm0,xmm4,QWORD PTR [rsp+0x120]
  19e976:	01 00 00 
  19e979:	c4 c2 e9 a9 c4       	vfmadd213sd xmm0,xmm2,xmm12
  19e97e:	4c 8b 44 24 48       	mov    r8,QWORD PTR [rsp+0x48]
  19e983:	4c 8b 8c 24 e0 00 00 	mov    r9,QWORD PTR [rsp+0xe0]
  19e98a:	00 
  19e98b:	c4 81 7b 10 4c c8 10 	vmovsd xmm1,QWORD PTR [r8+r9*8+0x10]
  19e992:	c4 e2 f1 b9 fa       	vfmadd231sd xmm7,xmm1,xmm2
  19e997:	c4 e2 99 b9 e9       	vfmadd231sd xmm5,xmm12,xmm1
  19e99c:	4c 8b 84 24 08 01 00 	mov    r8,QWORD PTR [rsp+0x108]
  19e9a3:	00 
  19e9a4:	4c 8b 4c 24 28       	mov    r9,QWORD PTR [rsp+0x28]
  19e9a9:	c4 81 7b 10 4c c1 10 	vmovsd xmm1,QWORD PTR [r9+r8*8+0x10]
  19e9b0:	c4 e2 f1 b9 f2       	vfmadd231sd xmm6,xmm1,xmm2
  19e9b5:	c4 62 99 b9 c9       	vfmadd231sd xmm9,xmm12,xmm1
  19e9ba:	4c 8b 44 24 20       	mov    r8,QWORD PTR [rsp+0x20]
  19e9bf:	c4 c1 7b 10 4c f0 10 	vmovsd xmm1,QWORD PTR [r8+rsi*8+0x10]
  19e9c6:	c4 62 f1 b9 d2       	vfmadd231sd xmm10,xmm1,xmm2
  19e9cb:	c4 e2 99 b9 d9       	vfmadd231sd xmm3,xmm12,xmm1
  19e9d0:	4c 8b 84 24 10 01 00 	mov    r8,QWORD PTR [rsp+0x110]
  19e9d7:	00 
  19e9d8:	4c 8b 4c 24 38       	mov    r9,QWORD PTR [rsp+0x38]
  19e9dd:	c4 81 7b 10 4c c1 10 	vmovsd xmm1,QWORD PTR [r9+r8*8+0x10]
  19e9e4:	c4 42 f1 b9 fc       	vfmadd231sd xmm15,xmm1,xmm12
  19e9e9:	c4 62 f1 b9 c2       	vfmadd231sd xmm8,xmm1,xmm2
  19e9ee:	c4 c1 f9 7e d0       	vmovq  r8,xmm2
  19e9f3:	c4 c1 7b 11 54 fd 10 	vmovsd QWORD PTR [r13+rdi*8+0x10],xmm2
  19e9fa:	c4 c1 f9 7e c1       	vmovq  r9,xmm0
  19e9ff:	c4 c1 7b 11 44 f2 10 	vmovsd QWORD PTR [r10+rsi*8+0x10],xmm0
  19ea06:	41 b4 3f             	mov    r12b,0x3f
  19ea09:	c4 42 98 f5 c0       	bzhi   r8,r8,r12
  19ea0e:	4d 39 f8             	cmp    r8,r15
  19ea11:	41 0f 94 c3          	sete   r11b
  19ea15:	4d 85 c0             	test   r8,r8
  19ea18:	41 0f 94 c6          	sete   r14b
  19ea1c:	45 08 de             	or     r14b,r11b
  19ea1f:	49 01 d0             	add    r8,rdx
  19ea22:	49 c1 e8 35          	shr    r8,0x35
  19ea26:	41 81 f8 ff 03 00 00 	cmp    r8d,0x3ff
  19ea2d:	41 0f 92 c0          	setb   r8b
  19ea31:	45 08 f0             	or     r8b,r14b
  19ea34:	c4 42 98 f5 c9       	bzhi   r9,r9,r12
  19ea39:	4d 39 f9             	cmp    r9,r15
  19ea3c:	41 0f 94 c3          	sete   r11b
  19ea40:	4d 85 c9             	test   r9,r9
  19ea43:	41 0f 94 c6          	sete   r14b
  19ea47:	45 08 de             	or     r14b,r11b
  19ea4a:	49 01 d1             	add    r9,rdx
  19ea4d:	49 c1 e9 35          	shr    r9,0x35
  19ea51:	41 81 f9 ff 03 00 00 	cmp    r9d,0x3ff
  19ea58:	41 0f 92 c1          	setb   r9b
  19ea5c:	45 08 f1             	or     r9b,r14b
  19ea5f:	45 20 c1             	and    r9b,r8b
  19ea62:	44 20 c8             	and    al,r9b
  19ea65:	83 7c 24 08 03       	cmp    DWORD PTR [rsp+0x8],0x3
  19ea6a:	75 09                	jne    19ea75 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1915>
  19ea6c:	c5 79 28 db          	vmovapd xmm11,xmm3
  19ea70:	e9 47 01 00 00       	jmp    19ebbc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1a5c>
  19ea75:	4c 8b 84 24 a0 00 00 	mov    r8,QWORD PTR [rsp+0xa0]
  19ea7c:	00 
  19ea7d:	4c 8b 8c 24 d8 00 00 	mov    r9,QWORD PTR [rsp+0xd8]
  19ea84:	00 
  19ea85:	c4 81 7b 10 4c c8 18 	vmovsd xmm1,QWORD PTR [r8+r9*8+0x18]
  19ea8c:	c5 f9 28 94 24 60 01 	vmovapd xmm2,XMMWORD PTR [rsp+0x160]
  19ea93:	00 00 
  19ea95:	c4 c2 f1 a9 d3       	vfmadd213sd xmm2,xmm1,xmm11
  19ea9a:	4c 8b 44 24 10       	mov    r8,QWORD PTR [rsp+0x10]
  19ea9f:	c4 c1 7b 10 44 f0 18 	vmovsd xmm0,QWORD PTR [r8+rsi*8+0x18]
  19eaa6:	c4 c2 f9 a9 54 f2 18 	vfmadd213sd xmm2,xmm0,QWORD PTR [r10+rsi*8+0x18]
  19eaad:	c4 c1 f9 7e d0       	vmovq  r8,xmm2
  19eab2:	41 b6 3f             	mov    r14b,0x3f
  19eab5:	c4 42 88 f5 c0       	bzhi   r8,r8,r14
  19eaba:	4d 39 f8             	cmp    r8,r15
  19eabd:	41 0f 94 c1          	sete   r9b
  19eac1:	4d 85 c0             	test   r8,r8
  19eac4:	41 0f 94 c3          	sete   r11b
  19eac8:	45 08 cb             	or     r11b,r9b
  19eacb:	49 01 d0             	add    r8,rdx
  19eace:	49 c1 e8 35          	shr    r8,0x35
  19ead2:	41 81 f8 ff 03 00 00 	cmp    r8d,0x3ff
  19ead9:	41 0f 92 c1          	setb   r9b
  19eadd:	45 08 d9             	or     r9b,r11b
  19eae0:	c5 79 28 9c 24 20 01 	vmovapd xmm11,XMMWORD PTR [rsp+0x120]
  19eae7:	00 00 
  19eae9:	c4 62 f1 a9 dc       	vfmadd213sd xmm11,xmm1,xmm4
  19eaee:	c4 62 e9 a9 d8       	vfmadd213sd xmm11,xmm2,xmm0
  19eaf3:	c5 79 29 9c 24 20 01 	vmovapd XMMWORD PTR [rsp+0x120],xmm11
  19eafa:	00 00 
  19eafc:	c4 41 f9 7e d8       	vmovq  r8,xmm11
  19eb01:	c4 42 88 f5 c0       	bzhi   r8,r8,r14
  19eb06:	4d 39 f8             	cmp    r8,r15
  19eb09:	41 0f 94 c6          	sete   r14b
  19eb0d:	4d 85 c0             	test   r8,r8
  19eb10:	41 0f 94 c3          	sete   r11b
  19eb14:	45 08 f3             	or     r11b,r14b
  19eb17:	49 01 d0             	add    r8,rdx
  19eb1a:	49 c1 e8 35          	shr    r8,0x35
  19eb1e:	41 81 f8 ff 03 00 00 	cmp    r8d,0x3ff
  19eb25:	48 8b 54 24 48       	mov    rdx,QWORD PTR [rsp+0x48]
  19eb2a:	4c 8b 84 24 e0 00 00 	mov    r8,QWORD PTR [rsp+0xe0]
  19eb31:	00 
  19eb32:	c4 a1 7b 10 4c c2 18 	vmovsd xmm1,QWORD PTR [rdx+r8*8+0x18]
  19eb39:	48 8b 94 24 08 01 00 	mov    rdx,QWORD PTR [rsp+0x108]
  19eb40:	00 
  19eb41:	4c 8b 44 24 28       	mov    r8,QWORD PTR [rsp+0x28]
  19eb46:	c4 c1 7b 10 64 d0 18 	vmovsd xmm4,QWORD PTR [r8+rdx*8+0x18]
  19eb4d:	48 8b 54 24 20       	mov    rdx,QWORD PTR [rsp+0x20]
  19eb52:	c5 7b 10 5c f2 18    	vmovsd xmm11,QWORD PTR [rdx+rsi*8+0x18]
  19eb58:	48 8b 94 24 10 01 00 	mov    rdx,QWORD PTR [rsp+0x110]
  19eb5f:	00 
  19eb60:	4c 8b 44 24 38       	mov    r8,QWORD PTR [rsp+0x38]
  19eb65:	c4 41 7b 10 64 d0 18 	vmovsd xmm12,QWORD PTR [r8+rdx*8+0x18]
  19eb6c:	c4 c1 7b 11 54 fd 18 	vmovsd QWORD PTR [r13+rdi*8+0x18],xmm2
  19eb73:	40 0f 92 c7          	setb   dil
  19eb77:	44 08 df             	or     dil,r11b
  19eb7a:	44 20 cf             	and    dil,r9b
  19eb7d:	40 20 f8             	and    al,dil
  19eb80:	c4 e2 f1 b9 fa       	vfmadd231sd xmm7,xmm1,xmm2
  19eb85:	c4 e2 d9 b9 f2       	vfmadd231sd xmm6,xmm4,xmm2
  19eb8a:	c4 62 a1 b9 d2       	vfmadd231sd xmm10,xmm11,xmm2
  19eb8f:	c4 62 99 b9 c2       	vfmadd231sd xmm8,xmm12,xmm2
  19eb94:	c4 e2 f9 b9 e9       	vfmadd231sd xmm5,xmm0,xmm1
  19eb99:	c4 62 f9 b9 cc       	vfmadd231sd xmm9,xmm0,xmm4
  19eb9e:	c4 c2 f9 b9 db       	vfmadd231sd xmm3,xmm0,xmm11
  19eba3:	c5 79 28 db          	vmovapd xmm11,xmm3
  19eba7:	c4 62 99 b9 f8       	vfmadd231sd xmm15,xmm12,xmm0
  19ebac:	c5 f9 28 84 24 20 01 	vmovapd xmm0,XMMWORD PTR [rsp+0x120]
  19ebb3:	00 00 
  19ebb5:	c4 c1 7b 11 44 f2 18 	vmovsd QWORD PTR [r10+rsi*8+0x18],xmm0
  19ebbc:	4c 8b 74 24 30       	mov    r14,QWORD PTR [rsp+0x30]
  19ebc1:	20 44 24 07          	and    BYTE PTR [rsp+0x7],al
  19ebc5:	4c 8b 9c 24 e8 00 00 	mov    r11,QWORD PTR [rsp+0xe8]
  19ebcc:	00 
  19ebcd:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  19ebd2:	4c 8b 44 24 70       	mov    r8,QWORD PTR [rsp+0x70]
  19ebd7:	48 8b bc 24 50 01 00 	mov    rdi,QWORD PTR [rsp+0x150]
  19ebde:	00 
  19ebdf:	4c 8b 4c 24 40       	mov    r9,QWORD PTR [rsp+0x40]
  19ebe4:	b2 3f                	mov    dl,0x3f
  19ebe6:	c5 f9 28 e6          	vmovapd xmm4,xmm6
  19ebea:	c4 41 79 28 e1       	vmovapd xmm12,xmm9
  19ebef:	c5 79 28 cd          	vmovapd xmm9,xmm5
  19ebf3:	c5 79 29 c5          	vmovapd xmm5,xmm8
  19ebf7:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
  19ebfc:	48 3b 44 24 58       	cmp    rax,QWORD PTR [rsp+0x58]
  19ec01:	0f 85 aa 11 00 00    	jne    19fdb1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c51>
  19ec07:	c5 fd 10 84 24 50 02 	vmovupd ymm0,YMMWORD PTR [rsp+0x250]
  19ec0e:	00 00 
  19ec10:	4d 85 c0             	test   r8,r8
  19ec13:	0f 84 f7 00 00 00    	je     19ed10 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1bb0>
  19ec19:	49 83 f8 01          	cmp    r8,0x1
  19ec1d:	75 10                	jne    19ec2f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1acf>
  19ec1f:	c5 fd 10 84 24 50 02 	vmovupd ymm0,YMMWORD PTR [rsp+0x250]
  19ec26:	00 00 
  19ec28:	31 c0                	xor    eax,eax
  19ec2a:	e9 a1 00 00 00       	jmp    19ecd0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1b70>
  19ec2f:	c5 79 29 e6          	vmovapd xmm6,xmm12
  19ec33:	ba 20 00 00 00       	mov    edx,0x20
  19ec38:	c5 fd 10 84 24 50 02 	vmovupd ymm0,YMMWORD PTR [rsp+0x250]
  19ec3f:	00 00 
  19ec41:	31 c0                	xor    eax,eax
  19ec43:	c4 e2 7d 19 0d c4 24 	vbroadcastsd ymm1,QWORD PTR [rip+0xffffffffffe824c4]        # 21110 <anon.18cb9c1b3fe794d0b89f358a70182f4e.25.llvm.5582884991536083740+0x4a0>
  19ec4a:	e8 ff 
  19ec4c:	c4 c1 75 54 54 15 e0 	vandpd ymm2,ymm1,YMMWORD PTR [r13+rdx*1-0x20]
  19ec53:	c4 c1 75 54 5c 12 e0 	vandpd ymm3,ymm1,YMMWORD PTR [r10+rdx*1-0x20]
  19ec5a:	c5 15 c2 e2 00       	vcmpeqpd ymm12,ymm13,ymm2
  19ec5f:	c4 c1 6d c2 d6 1d    	vcmpge_oqpd ymm2,ymm2,ymm14
  19ec65:	c5 9d 56 d2          	vorpd  ymm2,ymm12,ymm2
  19ec69:	c5 ed 54 c0          	vandpd ymm0,ymm2,ymm0
  19ec6d:	c5 95 c2 d3 00       	vcmpeqpd ymm2,ymm13,ymm3
  19ec72:	c4 c1 65 c2 de 1d    	vcmpge_oqpd ymm3,ymm3,ymm14
  19ec78:	c5 e5 56 d2          	vorpd  ymm2,ymm3,ymm2
  19ec7c:	c4 c1 75 54 5c 15 00 	vandpd ymm3,ymm1,YMMWORD PTR [r13+rdx*1+0x0]
  19ec83:	c4 c1 75 54 0c 12    	vandpd ymm1,ymm1,YMMWORD PTR [r10+rdx*1]
  19ec89:	48 83 c0 02          	add    rax,0x2
  19ec8d:	c5 15 c2 e3 00       	vcmpeqpd ymm12,ymm13,ymm3
  19ec92:	c4 c1 65 c2 de 1d    	vcmpge_oqpd ymm3,ymm3,ymm14
  19ec98:	c5 9d 56 db          	vorpd  ymm3,ymm12,ymm3
  19ec9c:	c5 e5 54 d2          	vandpd ymm2,ymm3,ymm2
  19eca0:	c5 ed 54 c0          	vandpd ymm0,ymm2,ymm0
  19eca4:	c5 95 c2 d1 00       	vcmpeqpd ymm2,ymm13,ymm1
  19eca9:	c4 c1 75 c2 ce 1d    	vcmpge_oqpd ymm1,ymm1,ymm14
  19ecaf:	c5 f5 56 ca          	vorpd  ymm1,ymm1,ymm2
  19ecb3:	c5 fd 54 c1          	vandpd ymm0,ymm0,ymm1
  19ecb7:	48 83 c2 40          	add    rdx,0x40
  19ecbb:	48 39 c7             	cmp    rdi,rax
  19ecbe:	75 83                	jne    19ec43 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1ae3>
  19ecc0:	f6 84 24 d0 00 00 00 	test   BYTE PTR [rsp+0xd0],0x4
  19ecc7:	04 
  19ecc8:	b2 3f                	mov    dl,0x3f
  19ecca:	c5 79 28 e6          	vmovapd xmm12,xmm6
  19ecce:	74 40                	je     19ed10 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1bb0>
  19ecd0:	48 c1 e0 05          	shl    rax,0x5
  19ecd4:	c4 e2 7d 19 0d 33 24 	vbroadcastsd ymm1,QWORD PTR [rip+0xffffffffffe82433]        # 21110 <anon.18cb9c1b3fe794d0b89f358a70182f4e.25.llvm.5582884991536083740+0x4a0>
  19ecdb:	e8 ff 
  19ecdd:	c4 c1 75 54 54 05 00 	vandpd ymm2,ymm1,YMMWORD PTR [r13+rax*1+0x0]
  19ece4:	c4 c1 75 54 0c 02    	vandpd ymm1,ymm1,YMMWORD PTR [r10+rax*1]
  19ecea:	c5 95 c2 da 00       	vcmpeqpd ymm3,ymm13,ymm2
  19ecef:	c4 c1 6d c2 d6 1d    	vcmpge_oqpd ymm2,ymm2,ymm14
  19ecf5:	c5 ed 56 d3          	vorpd  ymm2,ymm2,ymm3
  19ecf9:	c5 95 c2 d9 00       	vcmpeqpd ymm3,ymm13,ymm1
  19ecfe:	c4 c1 75 c2 ce 1d    	vcmpge_oqpd ymm1,ymm1,ymm14
  19ed04:	c5 f5 56 cb          	vorpd  ymm1,ymm1,ymm3
  19ed08:	c5 ed 54 c9          	vandpd ymm1,ymm2,ymm1
  19ed0c:	c5 f5 54 c0          	vandpd ymm0,ymm1,ymm0
  19ed10:	c4 e2 15 37 c0       	vpcmpgtq ymm0,ymm13,ymm0
  19ed15:	c4 e2 7d 59 0d ea 23 	vpbroadcastq ymm1,QWORD PTR [rip+0xffffffffffe823ea]        # 21108 <anon.18cb9c1b3fe794d0b89f358a70182f4e.25.llvm.5582884991536083740+0x498>
  19ed1c:	e8 ff 
  19ed1e:	c5 fd db c1          	vpand  ymm0,ymm0,ymm1
  19ed22:	c4 e3 7d 39 c1 01    	vextracti128 xmm1,ymm0,0x1
  19ed28:	c5 f9 5d c1          	vminpd xmm0,xmm0,xmm1
  19ed2c:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19ed31:	c5 fb 5d c1          	vminsd xmm0,xmm0,xmm1
  19ed35:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
  19ed39:	c5 f9 2e c1          	vucomisd xmm0,xmm1
  19ed3d:	0f 86 6e 10 00 00    	jbe    19fdb1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c51>
  19ed43:	48 83 7c 24 08 00    	cmp    QWORD PTR [rsp+0x8],0x0
  19ed49:	74 7f                	je     19edca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1c6a>
  19ed4b:	4c 8b 4c 24 78       	mov    r9,QWORD PTR [rsp+0x78]
  19ed50:	c4 82 e8 f5 44 cd 00 	bzhi   rax,QWORD PTR [r13+r9*8+0x0],rdx
  19ed57:	4c 39 f8             	cmp    rax,r15
  19ed5a:	41 b7 3f             	mov    r15b,0x3f
  19ed5d:	0f 95 c2             	setne  dl
  19ed60:	48 85 c0             	test   rax,rax
  19ed63:	40 0f 95 c7          	setne  dil
  19ed67:	40 20 d7             	and    dil,dl
  19ed6a:	48 ba 00 00 00 00 00 	movabs rdx,0xfff0000000000000
  19ed71:	00 f0 ff 
  19ed74:	48 01 d0             	add    rax,rdx
  19ed77:	48 c1 e8 35          	shr    rax,0x35
  19ed7b:	3d ff 03 00 00       	cmp    eax,0x3ff
  19ed80:	0f 93 c0             	setae  al
  19ed83:	40 84 c7             	test   dil,al
  19ed86:	75 31                	jne    19edb9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1c59>
  19ed88:	c4 82 80 f5 04 ca    	bzhi   rax,QWORD PTR [r10+r9*8],r15
  19ed8e:	48 ba 01 00 00 00 00 	movabs rdx,0x7ff0000000000001
  19ed95:	00 f0 7f 
  19ed98:	48 39 d0             	cmp    rax,rdx
  19ed9b:	0f 9c c2             	setl   dl
  19ed9e:	48 ff c8             	dec    rax
  19eda1:	48 bf fe ff ff ff ff 	movabs rdi,0xffffffffffffe
  19eda8:	ff 0f 00 
  19edab:	48 39 f8             	cmp    rax,rdi
  19edae:	0f 97 c0             	seta   al
  19edb1:	84 d0                	test   al,dl
  19edb3:	0f 85 6a 05 00 00    	jne    19f323 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x21c3>
  19edb9:	31 c0                	xor    eax,eax
  19edbb:	4c 8b 4c 24 40       	mov    r9,QWORD PTR [rsp+0x40]
  19edc0:	3b 44 24 08          	cmp    eax,DWORD PTR [rsp+0x8]
  19edc4:	0f 82 e7 0f 00 00    	jb     19fdb1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c51>
  19edca:	48 8d 3c 36          	lea    rdi,[rsi+rsi*1]
  19edce:	4c 39 f7             	cmp    rdi,r14
  19edd1:	0f 83 0c 11 00 00    	jae    19fee3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d83>
  19edd7:	48 89 fa             	mov    rdx,rdi
  19edda:	48 c1 e2 04          	shl    rdx,0x4
  19edde:	c4 41 7b 11 3c 13    	vmovsd QWORD PTR [r11+rdx*1],xmm15
  19ede4:	48 8b 84 24 58 01 00 	mov    rax,QWORD PTR [rsp+0x158]
  19edeb:	00 
  19edec:	48 8d 04 70          	lea    rax,[rax+rsi*2]
  19edf0:	c4 41 7b 11 5c 13 08 	vmovsd QWORD PTR [r11+rdx*1+0x8],xmm11
  19edf7:	48 3b 44 24 60       	cmp    rax,QWORD PTR [rsp+0x60]
  19edfc:	4d 89 c7             	mov    r15,r8
  19edff:	c5 7d 10 bc 24 50 02 	vmovupd ymm15,YMMWORD PTR [rsp+0x250]
  19ee06:	00 00 
  19ee08:	73 24                	jae    19ee2e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1cce>
  19ee0a:	49 89 c0             	mov    r8,rax
  19ee0d:	48 8d 47 01          	lea    rax,[rdi+0x1]
  19ee11:	4c 39 f0             	cmp    rax,r14
  19ee14:	0f 83 25 11 00 00    	jae    19ff3f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2ddf>
  19ee1a:	48 c1 e0 04          	shl    rax,0x4
  19ee1e:	c4 41 7b 11 24 03    	vmovsd QWORD PTR [r11+rax*1],xmm12
  19ee24:	c4 41 7b 11 4c 03 08 	vmovsd QWORD PTR [r11+rax*1+0x8],xmm9
  19ee2b:	4c 89 c0             	mov    rax,r8
  19ee2e:	48 89 54 24 50       	mov    QWORD PTR [rsp+0x50],rdx
  19ee33:	48 89 84 24 20 01 00 	mov    QWORD PTR [rsp+0x120],rax
  19ee3a:	00 
  19ee3b:	48 83 c0 02          	add    rax,0x2
  19ee3f:	48 89 c2             	mov    rdx,rax
  19ee42:	48 2b 94 24 58 01 00 	sub    rdx,QWORD PTR [rsp+0x158]
  19ee49:	00 
  19ee4a:	4c 39 f2             	cmp    rdx,r14
  19ee4d:	0f 83 be 10 00 00    	jae    19ff11 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2db1>
  19ee53:	49 89 d0             	mov    r8,rdx
  19ee56:	49 c1 e0 04          	shl    r8,0x4
  19ee5a:	c4 81 7b 11 2c 03    	vmovsd QWORD PTR [r11+r8*1],xmm5
  19ee60:	4c 89 84 24 30 01 00 	mov    QWORD PTR [rsp+0x130],r8
  19ee67:	00 
  19ee68:	c4 01 7b 11 54 03 08 	vmovsd QWORD PTR [r11+r8*1+0x8],xmm10
  19ee6f:	4c 8b 44 24 60       	mov    r8,QWORD PTR [rsp+0x60]
  19ee74:	48 89 84 24 60 01 00 	mov    QWORD PTR [rsp+0x160],rax
  19ee7b:	00 
  19ee7c:	4c 39 c0             	cmp    rax,r8
  19ee7f:	73 1e                	jae    19ee9f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1d3f>
  19ee81:	48 8d 42 01          	lea    rax,[rdx+0x1]
  19ee85:	4c 39 f0             	cmp    rax,r14
  19ee88:	0f 83 b1 10 00 00    	jae    19ff3f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2ddf>
  19ee8e:	48 c1 e0 04          	shl    rax,0x4
  19ee92:	c4 c1 7b 11 24 03    	vmovsd QWORD PTR [r11+rax*1],xmm4
  19ee98:	c4 c1 7b 11 7c 03 08 	vmovsd QWORD PTR [r11+rax*1+0x8],xmm7
  19ee9f:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  19eea3:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
  19eeaa:	00 
  19eeab:	48 85 c0             	test   rax,rax
  19eeae:	74 2d                	je     19eedd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1d7d>
  19eeb0:	48 83 f8 01          	cmp    rax,0x1
  19eeb4:	75 4c                	jne    19ef02 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1da2>
  19eeb6:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  19eeba:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  19eebe:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  19eec2:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  19eec7:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  19eecc:	31 c0                	xor    eax,eax
  19eece:	c4 41 21 57 db       	vxorpd xmm11,xmm11,xmm11
  19eed3:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  19eed8:	e9 26 01 00 00       	jmp    19f003 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1ea3>
  19eedd:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  19eee1:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  19eee5:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  19eee9:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  19eeee:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  19eef3:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  19eef8:	c4 41 21 57 db       	vxorpd xmm11,xmm11,xmm11
  19eefd:	e9 61 01 00 00       	jmp    19f063 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1f03>
  19ef02:	4d 89 ce             	mov    r14,r9
  19ef05:	41 b9 20 00 00 00    	mov    r9d,0x20
  19ef0b:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  19ef0f:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  19ef13:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  19ef17:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  19ef1c:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  19ef21:	31 c0                	xor    eax,eax
  19ef23:	c4 41 21 57 db       	vxorpd xmm11,xmm11,xmm11
  19ef28:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  19ef2d:	4c 8b bc 24 90 00 00 	mov    r15,QWORD PTR [rsp+0x90]
  19ef34:	00 
  19ef35:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
  19ef3a:	c4 a1 7d 10 44 0b e0 	vmovupd ymm0,YMMWORD PTR [rbx+r9*1-0x20]
  19ef41:	c4 a1 7d 10 4c 0f e0 	vmovupd ymm1,YMMWORD PTR [rdi+r9*1-0x20]
  19ef48:	c4 62 fd b8 d9       	vfmadd231pd ymm11,ymm0,ymm1
  19ef4d:	c4 81 7d 10 54 0f e0 	vmovupd ymm2,YMMWORD PTR [r15+r9*1-0x20]
  19ef54:	c4 62 ed b8 d1       	vfmadd231pd ymm10,ymm2,ymm1
  19ef59:	c4 a1 7d 10 5c 09 e0 	vmovupd ymm3,YMMWORD PTR [rcx+r9*1-0x20]
  19ef60:	c4 62 e5 b8 c1       	vfmadd231pd ymm8,ymm3,ymm1
  19ef65:	c4 21 7d 10 64 0d e0 	vmovupd ymm12,YMMWORD PTR [rbp+r9*1-0x20]
  19ef6c:	c4 e2 9d b8 f9       	vfmadd231pd ymm7,ymm12,ymm1
  19ef71:	c4 81 7d 10 4c 0d e0 	vmovupd ymm1,YMMWORD PTR [r13+r9*1-0x20]
  19ef78:	c4 62 f5 b8 c8       	vfmadd231pd ymm9,ymm1,ymm0
  19ef7d:	c4 a1 7d 10 04 0b    	vmovupd ymm0,YMMWORD PTR [rbx+r9*1]
  19ef83:	c4 e2 f5 b8 f2       	vfmadd231pd ymm6,ymm1,ymm2
  19ef88:	c4 a1 7d 10 14 0f    	vmovupd ymm2,YMMWORD PTR [rdi+r9*1]
  19ef8e:	c4 e2 f5 b8 eb       	vfmadd231pd ymm5,ymm1,ymm3
  19ef93:	c4 81 7d 10 1c 0f    	vmovupd ymm3,YMMWORD PTR [r15+r9*1]
  19ef99:	c4 e2 9d b8 e1       	vfmadd231pd ymm4,ymm12,ymm1
  19ef9e:	c4 a1 7d 10 0c 09    	vmovupd ymm1,YMMWORD PTR [rcx+r9*1]
  19efa4:	c4 21 7d 10 64 0d 00 	vmovupd ymm12,YMMWORD PTR [rbp+r9*1+0x0]
  19efab:	c4 62 fd b8 da       	vfmadd231pd ymm11,ymm0,ymm2
  19efb0:	c4 62 e5 b8 d2       	vfmadd231pd ymm10,ymm3,ymm2
  19efb5:	c4 62 f5 b8 c2       	vfmadd231pd ymm8,ymm1,ymm2
  19efba:	c4 e2 9d b8 fa       	vfmadd231pd ymm7,ymm12,ymm2
  19efbf:	c4 81 7d 10 54 0d 00 	vmovupd ymm2,YMMWORD PTR [r13+r9*1+0x0]
  19efc6:	c4 62 ed b8 c8       	vfmadd231pd ymm9,ymm2,ymm0
  19efcb:	c4 e2 ed b8 f3       	vfmadd231pd ymm6,ymm2,ymm3
  19efd0:	c4 e2 ed b8 e9       	vfmadd231pd ymm5,ymm2,ymm1
  19efd5:	c4 e2 9d b8 e2       	vfmadd231pd ymm4,ymm12,ymm2
  19efda:	48 83 c0 02          	add    rax,0x2
  19efde:	49 83 c1 40          	add    r9,0x40
  19efe2:	49 39 c6             	cmp    r14,rax
  19efe5:	0f 85 4f ff ff ff    	jne    19ef3a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1dda>
  19efeb:	f6 84 24 98 00 00 00 	test   BYTE PTR [rsp+0x98],0x1
  19eff2:	01 
  19eff3:	4c 8b 7c 24 70       	mov    r15,QWORD PTR [rsp+0x70]
  19eff8:	4c 8b 74 24 30       	mov    r14,QWORD PTR [rsp+0x30]
  19effd:	48 8d 3c 36          	lea    rdi,[rsi+rsi*1]
  19f001:	74 60                	je     19f063 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1f03>
  19f003:	48 c1 e0 05          	shl    rax,0x5
  19f007:	c5 fd 10 04 03       	vmovupd ymm0,YMMWORD PTR [rbx+rax*1]
  19f00c:	48 8b 74 24 10       	mov    rsi,QWORD PTR [rsp+0x10]
  19f011:	c5 fd 10 0c 06       	vmovupd ymm1,YMMWORD PTR [rsi+rax*1]
  19f016:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  19f01b:	c4 62 fd b8 d9       	vfmadd231pd ymm11,ymm0,ymm1
  19f020:	4c 8b 8c 24 90 00 00 	mov    r9,QWORD PTR [rsp+0x90]
  19f027:	00 
  19f028:	c4 c1 7d 10 14 01    	vmovupd ymm2,YMMWORD PTR [r9+rax*1]
  19f02e:	c4 62 ed b8 d1       	vfmadd231pd ymm10,ymm2,ymm1
  19f033:	c5 fd 10 1c 01       	vmovupd ymm3,YMMWORD PTR [rcx+rax*1]
  19f038:	c4 62 e5 b8 c1       	vfmadd231pd ymm8,ymm3,ymm1
  19f03d:	c5 7d 10 64 05 00    	vmovupd ymm12,YMMWORD PTR [rbp+rax*1+0x0]
  19f043:	c4 e2 9d b8 f9       	vfmadd231pd ymm7,ymm12,ymm1
  19f048:	c4 c1 7d 10 4c 05 00 	vmovupd ymm1,YMMWORD PTR [r13+rax*1+0x0]
  19f04f:	c4 62 f5 b8 c8       	vfmadd231pd ymm9,ymm1,ymm0
  19f054:	c4 e2 f5 b8 f2       	vfmadd231pd ymm6,ymm1,ymm2
  19f059:	c4 e2 f5 b8 eb       	vfmadd231pd ymm5,ymm1,ymm3
  19f05e:	c4 e2 9d b8 e1       	vfmadd231pd ymm4,ymm12,ymm1
  19f063:	c4 63 7d 19 d8 01    	vextractf128 xmm0,ymm11,0x1
  19f069:	c5 a1 58 c0          	vaddpd xmm0,xmm11,xmm0
  19f06d:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19f072:	c5 7b 58 d9          	vaddsd xmm11,xmm0,xmm1
  19f076:	c4 63 7d 19 d0 01    	vextractf128 xmm0,ymm10,0x1
  19f07c:	c5 a9 58 c0          	vaddpd xmm0,xmm10,xmm0
  19f080:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19f085:	c5 7b 58 e1          	vaddsd xmm12,xmm0,xmm1
  19f089:	c4 63 7d 19 c0 01    	vextractf128 xmm0,ymm8,0x1
  19f08f:	c5 b9 58 c0          	vaddpd xmm0,xmm8,xmm0
  19f093:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19f098:	c5 7b 58 c1          	vaddsd xmm8,xmm0,xmm1
  19f09c:	c4 e3 7d 19 f8 01    	vextractf128 xmm0,ymm7,0x1
  19f0a2:	c5 c1 58 c0          	vaddpd xmm0,xmm7,xmm0
  19f0a6:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19f0ab:	c5 7b 58 d1          	vaddsd xmm10,xmm0,xmm1
  19f0af:	c4 63 7d 19 c8 01    	vextractf128 xmm0,ymm9,0x1
  19f0b5:	c5 b1 58 c0          	vaddpd xmm0,xmm9,xmm0
  19f0b9:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19f0be:	c5 fb 58 f9          	vaddsd xmm7,xmm0,xmm1
  19f0c2:	c4 e3 7d 19 f0 01    	vextractf128 xmm0,ymm6,0x1
  19f0c8:	c5 c9 58 c0          	vaddpd xmm0,xmm6,xmm0
  19f0cc:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19f0d1:	c5 fb 58 f1          	vaddsd xmm6,xmm0,xmm1
  19f0d5:	c4 e3 7d 19 e8 01    	vextractf128 xmm0,ymm5,0x1
  19f0db:	c5 d1 58 c0          	vaddpd xmm0,xmm5,xmm0
  19f0df:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19f0e4:	c5 fb 58 e9          	vaddsd xmm5,xmm0,xmm1
  19f0e8:	c4 e3 7d 19 e0 01    	vextractf128 xmm0,ymm4,0x1
  19f0ee:	c5 d9 58 c0          	vaddpd xmm0,xmm4,xmm0
  19f0f2:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19f0f7:	c5 fb 58 e1          	vaddsd xmm4,xmm0,xmm1
  19f0fb:	48 83 bc 24 b0 00 00 	cmp    QWORD PTR [rsp+0xb0],0x0
  19f102:	00 00 
  19f104:	0f 84 53 01 00 00    	je     19f25d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x20fd>
  19f10a:	48 89 7c 24 18       	mov    QWORD PTR [rsp+0x18],rdi
  19f10f:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
  19f114:	48 3b 84 24 88 01 00 	cmp    rax,QWORD PTR [rsp+0x188]
  19f11b:	00 
  19f11c:	0f 86 5c 0e 00 00    	jbe    19ff7e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2e1e>
  19f122:	4d 89 f8             	mov    r8,r15
  19f125:	4c 8b bc 24 00 01 00 	mov    r15,QWORD PTR [rsp+0x100]
  19f12c:	00 
  19f12d:	c4 a1 7b 10 04 fb    	vmovsd xmm0,QWORD PTR [rbx+r15*8]
  19f133:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
  19f138:	4c 8b 4c 24 78       	mov    r9,QWORD PTR [rsp+0x78]
  19f13d:	c4 a1 7b 10 0c cf    	vmovsd xmm1,QWORD PTR [rdi+r9*8]
  19f143:	c4 62 f9 b9 d9       	vfmadd231sd xmm11,xmm0,xmm1
  19f148:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
  19f14f:	00 
  19f150:	c4 a1 7b 10 14 f8    	vmovsd xmm2,QWORD PTR [rax+r15*8]
  19f156:	c4 62 e9 b9 e1       	vfmadd231sd xmm12,xmm2,xmm1
  19f15b:	c4 a1 7b 10 1c f9    	vmovsd xmm3,QWORD PTR [rcx+r15*8]
  19f161:	c4 62 e1 b9 c1       	vfmadd231sd xmm8,xmm3,xmm1
  19f166:	c4 21 7b 10 4c fd 00 	vmovsd xmm9,QWORD PTR [rbp+r15*8+0x0]
  19f16d:	c4 62 b1 b9 d1       	vfmadd231sd xmm10,xmm9,xmm1
  19f172:	c4 81 7b 10 4c cd 00 	vmovsd xmm1,QWORD PTR [r13+r9*8+0x0]
  19f179:	c4 e2 f1 b9 f8       	vfmadd231sd xmm7,xmm1,xmm0
  19f17e:	c4 e2 f1 b9 f2       	vfmadd231sd xmm6,xmm1,xmm2
  19f183:	c4 e2 f1 b9 eb       	vfmadd231sd xmm5,xmm1,xmm3
  19f188:	c4 e2 b1 b9 e1       	vfmadd231sd xmm4,xmm9,xmm1
  19f18d:	4c 8b b4 24 b0 00 00 	mov    r14,QWORD PTR [rsp+0xb0]
  19f194:	00 
  19f195:	41 83 fe 01          	cmp    r14d,0x1
  19f199:	0f 84 aa 00 00 00    	je     19f249 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x20e9>
  19f19f:	c4 a1 7b 10 44 fb 08 	vmovsd xmm0,QWORD PTR [rbx+r15*8+0x8]
  19f1a6:	c4 a1 7b 10 4c cf 08 	vmovsd xmm1,QWORD PTR [rdi+r9*8+0x8]
  19f1ad:	c4 62 f9 b9 d9       	vfmadd231sd xmm11,xmm0,xmm1
  19f1b2:	c4 a1 7b 10 54 f8 08 	vmovsd xmm2,QWORD PTR [rax+r15*8+0x8]
  19f1b9:	c4 62 e9 b9 e1       	vfmadd231sd xmm12,xmm2,xmm1
  19f1be:	c4 a1 7b 10 5c f9 08 	vmovsd xmm3,QWORD PTR [rcx+r15*8+0x8]
  19f1c5:	c4 62 e1 b9 c1       	vfmadd231sd xmm8,xmm3,xmm1
  19f1ca:	c4 21 7b 10 4c fd 08 	vmovsd xmm9,QWORD PTR [rbp+r15*8+0x8]
  19f1d1:	c4 62 b1 b9 d1       	vfmadd231sd xmm10,xmm9,xmm1
  19f1d6:	c4 81 7b 10 4c cd 08 	vmovsd xmm1,QWORD PTR [r13+r9*8+0x8]
  19f1dd:	c4 e2 f1 b9 f8       	vfmadd231sd xmm7,xmm1,xmm0
  19f1e2:	c4 e2 f1 b9 f2       	vfmadd231sd xmm6,xmm1,xmm2
  19f1e7:	c4 e2 f1 b9 eb       	vfmadd231sd xmm5,xmm1,xmm3
  19f1ec:	c4 e2 b1 b9 e1       	vfmadd231sd xmm4,xmm9,xmm1
  19f1f1:	41 83 fe 02          	cmp    r14d,0x2
  19f1f5:	74 52                	je     19f249 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x20e9>
  19f1f7:	c4 a1 7b 10 44 fb 10 	vmovsd xmm0,QWORD PTR [rbx+r15*8+0x10]
  19f1fe:	c4 a1 7b 10 4c cf 10 	vmovsd xmm1,QWORD PTR [rdi+r9*8+0x10]
  19f205:	c4 62 f9 b9 d9       	vfmadd231sd xmm11,xmm0,xmm1
  19f20a:	c4 a1 7b 10 54 f8 10 	vmovsd xmm2,QWORD PTR [rax+r15*8+0x10]
  19f211:	c4 62 e9 b9 e1       	vfmadd231sd xmm12,xmm2,xmm1
  19f216:	c4 a1 7b 10 5c f9 10 	vmovsd xmm3,QWORD PTR [rcx+r15*8+0x10]
  19f21d:	c4 62 e1 b9 c1       	vfmadd231sd xmm8,xmm3,xmm1
  19f222:	c4 21 7b 10 4c fd 10 	vmovsd xmm9,QWORD PTR [rbp+r15*8+0x10]
  19f229:	c4 62 b1 b9 d1       	vfmadd231sd xmm10,xmm9,xmm1
  19f22e:	c4 81 7b 10 4c cd 10 	vmovsd xmm1,QWORD PTR [r13+r9*8+0x10]
  19f235:	c4 e2 f1 b9 f8       	vfmadd231sd xmm7,xmm1,xmm0
  19f23a:	c4 e2 f1 b9 f2       	vfmadd231sd xmm6,xmm1,xmm2
  19f23f:	c4 e2 f1 b9 eb       	vfmadd231sd xmm5,xmm1,xmm3
  19f244:	c4 e2 b1 b9 e1       	vfmadd231sd xmm4,xmm9,xmm1
  19f249:	4c 8b 64 24 30       	mov    r12,QWORD PTR [rsp+0x30]
  19f24e:	4d 89 c7             	mov    r15,r8
  19f251:	4c 8b 44 24 60       	mov    r8,QWORD PTR [rsp+0x60]
  19f256:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
  19f25b:	eb 03                	jmp    19f260 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2100>
  19f25d:	4d 89 f4             	mov    r12,r14
  19f260:	48 3b 7c 24 68       	cmp    rdi,QWORD PTR [rsp+0x68]
  19f265:	0f 83 bf 0c 00 00    	jae    19ff2a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2dca>
  19f26b:	4d 89 c1             	mov    r9,r8
  19f26e:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
  19f275:	00 
  19f276:	4c 8b 44 24 50       	mov    r8,QWORD PTR [rsp+0x50]
  19f27b:	c4 21 7b 11 1c 00    	vmovsd QWORD PTR [rax+r8*1],xmm11
  19f281:	c4 21 7b 11 64 00 08 	vmovsd QWORD PTR [rax+r8*1+0x8],xmm12
  19f288:	4d 89 c8             	mov    r8,r9
  19f28b:	4c 39 8c 24 20 01 00 	cmp    QWORD PTR [rsp+0x120],r9
  19f292:	00 
  19f293:	4d 89 e6             	mov    r14,r12
  19f296:	4c 8b a4 24 a0 00 00 	mov    r12,QWORD PTR [rsp+0xa0]
  19f29d:	00 
  19f29e:	73 25                	jae    19f2c5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2165>
  19f2a0:	48 ff c7             	inc    rdi
  19f2a3:	48 3b 7c 24 68       	cmp    rdi,QWORD PTR [rsp+0x68]
  19f2a8:	0f 83 2c 0d 00 00    	jae    19ffda <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2e7a>
  19f2ae:	48 c1 e7 04          	shl    rdi,0x4
  19f2b2:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
  19f2b9:	00 
  19f2ba:	c5 7b 11 04 38       	vmovsd QWORD PTR [rax+rdi*1],xmm8
  19f2bf:	c5 7b 11 54 38 08    	vmovsd QWORD PTR [rax+rdi*1+0x8],xmm10
  19f2c5:	48 3b 54 24 68       	cmp    rdx,QWORD PTR [rsp+0x68]
  19f2ca:	0f 83 26 0c 00 00    	jae    19fef6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d96>
  19f2d0:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
  19f2d7:	00 
  19f2d8:	48 8b bc 24 30 01 00 	mov    rdi,QWORD PTR [rsp+0x130]
  19f2df:	00 
  19f2e0:	c5 fb 11 3c 38       	vmovsd QWORD PTR [rax+rdi*1],xmm7
  19f2e5:	c5 fb 11 74 38 08    	vmovsd QWORD PTR [rax+rdi*1+0x8],xmm6
  19f2eb:	4c 39 84 24 60 01 00 	cmp    QWORD PTR [rsp+0x160],r8
  19f2f2:	00 
  19f2f3:	0f 83 96 f0 ff ff    	jae    19e38f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x122f>
  19f2f9:	48 ff c2             	inc    rdx
  19f2fc:	48 3b 54 24 68       	cmp    rdx,QWORD PTR [rsp+0x68]
  19f301:	0f 83 e8 0c 00 00    	jae    19ffef <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2e8f>
  19f307:	48 c1 e2 04          	shl    rdx,0x4
  19f30b:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
  19f312:	00 
  19f313:	c5 fb 11 2c 10       	vmovsd QWORD PTR [rax+rdx*1],xmm5
  19f318:	c5 fb 11 64 10 08    	vmovsd QWORD PTR [rax+rdx*1+0x8],xmm4
  19f31e:	e9 6c f0 ff ff       	jmp    19e38f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x122f>
  19f323:	83 7c 24 08 01       	cmp    DWORD PTR [rsp+0x8],0x1
  19f328:	4c 8b 4c 24 40       	mov    r9,QWORD PTR [rsp+0x40]
  19f32d:	b0 3f                	mov    al,0x3f
  19f32f:	49 bf 00 00 00 00 00 	movabs r15,0x7ff0000000000000
  19f336:	00 f0 7f 
  19f339:	0f 84 8b fa ff ff    	je     19edca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1c6a>
  19f33f:	4c 8b 4c 24 78       	mov    r9,QWORD PTR [rsp+0x78]
  19f344:	c4 82 f8 f5 44 cd 08 	bzhi   rax,QWORD PTR [r13+r9*8+0x8],rax
  19f34b:	4c 39 f8             	cmp    rax,r15
  19f34e:	0f 95 c2             	setne  dl
  19f351:	48 85 c0             	test   rax,rax
  19f354:	40 0f 95 c7          	setne  dil
  19f358:	40 20 d7             	and    dil,dl
  19f35b:	48 ba 00 00 00 00 00 	movabs rdx,0xfff0000000000000
  19f362:	00 f0 ff 
  19f365:	48 01 d0             	add    rax,rdx
  19f368:	48 c1 e8 35          	shr    rax,0x35
  19f36c:	3d ff 03 00 00       	cmp    eax,0x3ff
  19f371:	0f 93 c2             	setae  dl
  19f374:	b8 01 00 00 00       	mov    eax,0x1
  19f379:	40 84 d7             	test   dil,dl
  19f37c:	0f 85 39 fa ff ff    	jne    19edbb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1c5b>
  19f382:	b2 3f                	mov    dl,0x3f
  19f384:	c4 82 e8 f5 54 ca 08 	bzhi   rdx,QWORD PTR [r10+r9*8+0x8],rdx
  19f38b:	4c 39 fa             	cmp    rdx,r15
  19f38e:	40 0f 9f c7          	setg   dil
  19f392:	48 ff ca             	dec    rdx
  19f395:	49 b9 ff ff ff ff ff 	movabs r9,0xfffffffffffff
  19f39c:	ff 0f 00 
  19f39f:	4c 39 ca             	cmp    rdx,r9
  19f3a2:	0f 92 c2             	setb   dl
  19f3a5:	40 08 fa             	or     dl,dil
  19f3a8:	4c 8b 4c 24 40       	mov    r9,QWORD PTR [rsp+0x40]
  19f3ad:	b2 3f                	mov    dl,0x3f
  19f3af:	0f 85 0b fa ff ff    	jne    19edc0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1c60>
  19f3b5:	83 7c 24 08 02       	cmp    DWORD PTR [rsp+0x8],0x2
  19f3ba:	0f 84 0a fa ff ff    	je     19edca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1c6a>
  19f3c0:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
  19f3c5:	c4 c2 e8 f5 44 c5 10 	bzhi   rax,QWORD PTR [r13+rax*8+0x10],rdx
  19f3cc:	4c 39 f8             	cmp    rax,r15
  19f3cf:	0f 95 c2             	setne  dl
  19f3d2:	48 85 c0             	test   rax,rax
  19f3d5:	40 0f 95 c7          	setne  dil
  19f3d9:	40 20 d7             	and    dil,dl
  19f3dc:	48 ba 00 00 00 00 00 	movabs rdx,0xfff0000000000000
  19f3e3:	00 f0 ff 
  19f3e6:	48 01 d0             	add    rax,rdx
  19f3e9:	48 c1 e8 35          	shr    rax,0x35
  19f3ed:	3d ff 03 00 00       	cmp    eax,0x3ff
  19f3f2:	0f 93 c2             	setae  dl
  19f3f5:	b8 02 00 00 00       	mov    eax,0x2
  19f3fa:	40 84 d7             	test   dil,dl
  19f3fd:	0f 85 bd f9 ff ff    	jne    19edc0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1c60>
  19f403:	48 8b 54 24 78       	mov    rdx,QWORD PTR [rsp+0x78]
  19f408:	40 b7 3f             	mov    dil,0x3f
  19f40b:	c4 c2 c0 f5 54 d2 10 	bzhi   rdx,QWORD PTR [r10+rdx*8+0x10],rdi
  19f412:	4c 39 fa             	cmp    rdx,r15
  19f415:	40 0f 9f c7          	setg   dil
  19f419:	48 ff ca             	dec    rdx
  19f41c:	49 bf ff ff ff ff ff 	movabs r15,0xfffffffffffff
  19f423:	ff 0f 00 
  19f426:	4c 39 fa             	cmp    rdx,r15
  19f429:	0f 92 c2             	setb   dl
  19f42c:	40 08 fa             	or     dl,dil
  19f42f:	0f 85 8b f9 ff ff    	jne    19edc0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1c60>
  19f435:	e9 90 f9 ff ff       	jmp    19edca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x1c6a>
  19f43a:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  19f43f:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  19f443:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  19f447:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  19f44b:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  19f44f:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
  19f453:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
  19f457:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
  19f45b:	4c 8b bc 24 b0 00 00 	mov    r15,QWORD PTR [rsp+0xb0]
  19f462:	00 
  19f463:	e9 57 01 00 00       	jmp    19f5bf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x245f>
  19f468:	4c 89 a4 24 48 01 00 	mov    QWORD PTR [rsp+0x148],r12
  19f46f:	00 
  19f470:	49 89 c0             	mov    r8,rax
  19f473:	49 21 f8             	and    r8,rdi
  19f476:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
  19f47a:	41 b9 60 00 00 00    	mov    r9d,0x60
  19f480:	31 ff                	xor    edi,edi
  19f482:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
  19f486:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
  19f48a:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  19f48e:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  19f492:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  19f496:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  19f49a:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  19f49f:	4c 8b 7c 24 38       	mov    r15,QWORD PTR [rsp+0x38]
  19f4a4:	49 89 cc             	mov    r12,rcx
  19f4a7:	48 89 f1             	mov    rcx,rsi
  19f4aa:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
  19f4af:	c4 81 7d 10 44 0a a0 	vmovupd ymm0,YMMWORD PTR [r10+r9*1-0x60]
  19f4b6:	c4 01 7d 10 4c 0a c0 	vmovupd ymm9,YMMWORD PTR [r10+r9*1-0x40]
  19f4bd:	c4 01 7d 10 54 0a e0 	vmovupd ymm10,YMMWORD PTR [r10+r9*1-0x20]
  19f4c4:	c4 82 fd b8 64 0f a0 	vfmadd231pd ymm4,ymm0,YMMWORD PTR [r15+r9*1-0x60]
  19f4cb:	c4 a2 fd b8 6c 0e a0 	vfmadd231pd ymm5,ymm0,YMMWORD PTR [rsi+r9*1-0x60]
  19f4d2:	c4 a2 fd b8 74 09 a0 	vfmadd231pd ymm6,ymm0,YMMWORD PTR [rcx+r9*1-0x60]
  19f4d9:	c4 82 fd b8 7c 0c a0 	vfmadd231pd ymm7,ymm0,YMMWORD PTR [r12+r9*1-0x60]
  19f4e0:	c4 82 b5 b8 54 0f c0 	vfmadd231pd ymm2,ymm9,YMMWORD PTR [r15+r9*1-0x40]
  19f4e7:	c4 a2 b5 b8 5c 0e c0 	vfmadd231pd ymm3,ymm9,YMMWORD PTR [rsi+r9*1-0x40]
  19f4ee:	c4 a2 b5 b8 4c 09 c0 	vfmadd231pd ymm1,ymm9,YMMWORD PTR [rcx+r9*1-0x40]
  19f4f5:	c4 02 b5 b8 44 0c c0 	vfmadd231pd ymm8,ymm9,YMMWORD PTR [r12+r9*1-0x40]
  19f4fc:	c4 81 7d 10 04 0a    	vmovupd ymm0,YMMWORD PTR [r10+r9*1]
  19f502:	48 83 c7 02          	add    rdi,0x2
  19f506:	c4 82 ad b8 64 0f e0 	vfmadd231pd ymm4,ymm10,YMMWORD PTR [r15+r9*1-0x20]
  19f50d:	c4 a2 ad b8 6c 0e e0 	vfmadd231pd ymm5,ymm10,YMMWORD PTR [rsi+r9*1-0x20]
  19f514:	c4 a2 ad b8 74 09 e0 	vfmadd231pd ymm6,ymm10,YMMWORD PTR [rcx+r9*1-0x20]
  19f51b:	c4 82 ad b8 7c 0c e0 	vfmadd231pd ymm7,ymm10,YMMWORD PTR [r12+r9*1-0x20]
  19f522:	c4 82 fd b8 14 0f    	vfmadd231pd ymm2,ymm0,YMMWORD PTR [r15+r9*1]
  19f528:	c4 a2 fd b8 1c 0e    	vfmadd231pd ymm3,ymm0,YMMWORD PTR [rsi+r9*1]
  19f52e:	c4 a2 fd b8 0c 09    	vfmadd231pd ymm1,ymm0,YMMWORD PTR [rcx+r9*1]
  19f534:	c4 02 fd b8 04 0c    	vfmadd231pd ymm8,ymm0,YMMWORD PTR [r12+r9*1]
  19f53a:	49 83 e9 80          	sub    r9,0xffffffffffffff80
  19f53e:	49 39 f8             	cmp    r8,rdi
  19f541:	0f 85 68 ff ff ff    	jne    19f4af <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x234f>
  19f547:	a8 01                	test   al,0x1
  19f549:	48 89 ce             	mov    rsi,rcx
  19f54c:	4c 89 e1             	mov    rcx,r12
  19f54f:	4c 8b a4 24 48 01 00 	mov    r12,QWORD PTR [rsp+0x148]
  19f556:	00 
  19f557:	4c 8b bc 24 b0 00 00 	mov    r15,QWORD PTR [rsp+0xb0]
  19f55e:	00 
  19f55f:	74 5e                	je     19f5bf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x245f>
  19f561:	48 c1 e7 06          	shl    rdi,0x6
  19f565:	c4 c1 7d 10 04 3a    	vmovupd ymm0,YMMWORD PTR [r10+rdi*1]
  19f56b:	c4 41 7d 10 4c 3a 20 	vmovupd ymm9,YMMWORD PTR [r10+rdi*1+0x20]
  19f572:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
  19f577:	c4 e2 fd b8 24 38    	vfmadd231pd ymm4,ymm0,YMMWORD PTR [rax+rdi*1]
  19f57d:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
  19f582:	c4 e2 fd b8 2c 3e    	vfmadd231pd ymm5,ymm0,YMMWORD PTR [rsi+rdi*1]
  19f588:	48 8b 4c 24 28       	mov    rcx,QWORD PTR [rsp+0x28]
  19f58d:	c4 e2 fd b8 34 39    	vfmadd231pd ymm6,ymm0,YMMWORD PTR [rcx+rdi*1]
  19f593:	48 8b 4c 24 48       	mov    rcx,QWORD PTR [rsp+0x48]
  19f598:	c4 e2 fd b8 3c 39    	vfmadd231pd ymm7,ymm0,YMMWORD PTR [rcx+rdi*1]
  19f59e:	c4 e2 b5 b8 54 38 20 	vfmadd231pd ymm2,ymm9,YMMWORD PTR [rax+rdi*1+0x20]
  19f5a5:	c4 e2 b5 b8 5c 3e 20 	vfmadd231pd ymm3,ymm9,YMMWORD PTR [rsi+rdi*1+0x20]
  19f5ac:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
  19f5b1:	c4 e2 b5 b8 4c 3e 20 	vfmadd231pd ymm1,ymm9,YMMWORD PTR [rsi+rdi*1+0x20]
  19f5b8:	c4 62 b5 b8 44 39 20 	vfmadd231pd ymm8,ymm9,YMMWORD PTR [rcx+rdi*1+0x20]
  19f5bf:	4c 01 94 24 30 01 00 	add    QWORD PTR [rsp+0x130],r10
  19f5c6:	00 
  19f5c7:	f6 44 24 08 04       	test   BYTE PTR [rsp+0x8],0x4
  19f5cc:	48 89 6c 24 40       	mov    QWORD PTR [rsp+0x40],rbp
  19f5d1:	0f 84 d3 00 00 00    	je     19f6aa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x254a>
  19f5d7:	f6 84 24 a0 01 00 00 	test   BYTE PTR [rsp+0x1a0],0x1
  19f5de:	01 
  19f5df:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
  19f5e4:	0f 84 77 08 00 00    	je     19fe61 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d01>
  19f5ea:	f6 84 24 d0 00 00 00 	test   BYTE PTR [rsp+0xd0],0x4
  19f5f1:	04 
  19f5f2:	0f 84 7d 08 00 00    	je     19fe75 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d15>
  19f5f8:	48 89 54 24 10       	mov    QWORD PTR [rsp+0x10],rdx
  19f5fd:	f6 44 24 58 04       	test   BYTE PTR [rsp+0x58],0x4
  19f602:	0f 84 67 0a 00 00    	je     1a006f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2f0f>
  19f608:	f6 84 24 88 00 00 00 	test   BYTE PTR [rsp+0x88],0x4
  19f60f:	04 
  19f610:	0f 84 6d 0a 00 00    	je     1a0083 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2f23>
  19f616:	f6 84 24 80 00 00 00 	test   BYTE PTR [rsp+0x80],0x4
  19f61d:	04 
  19f61e:	0f 84 73 0a 00 00    	je     1a0097 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2f37>
  19f624:	4c 89 ea             	mov    rdx,r13
  19f627:	4d 89 dd             	mov    r13,r11
  19f62a:	48 bf fe ff ff ff ff 	movabs rdi,0x3fffffffffffffe
  19f631:	ff ff 03 
  19f634:	4c 8b 84 24 78 01 00 	mov    r8,QWORD PTR [rsp+0x178]
  19f63b:	00 
  19f63c:	49 21 f8             	and    r8,rdi
  19f63f:	4c 8b 8c 24 c0 01 00 	mov    r9,QWORD PTR [rsp+0x1c0]
  19f646:	00 
  19f647:	49 21 f9             	and    r9,rdi
  19f64a:	4c 8b 9c 24 b8 01 00 	mov    r11,QWORD PTR [rsp+0x1b8]
  19f651:	00 
  19f652:	49 21 fb             	and    r11,rdi
  19f655:	48 8b ac 24 b0 01 00 	mov    rbp,QWORD PTR [rsp+0x1b0]
  19f65c:	00 
  19f65d:	48 21 fd             	and    rbp,rdi
  19f660:	49 c1 e0 05          	shl    r8,0x5
  19f664:	49 c1 e1 05          	shl    r9,0x5
  19f668:	49 c1 e3 05          	shl    r11,0x5
  19f66c:	48 c1 e5 05          	shl    rbp,0x5
  19f670:	4c 03 44 24 38       	add    r8,QWORD PTR [rsp+0x38]
  19f675:	49 01 c1             	add    r9,rax
  19f678:	49 01 f3             	add    r11,rsi
  19f67b:	48 01 cd             	add    rbp,rcx
  19f67e:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
  19f685:	00 
  19f686:	c5 fd 10 00          	vmovupd ymm0,YMMWORD PTR [rax]
  19f68a:	c4 c2 fd b8 20       	vfmadd231pd ymm4,ymm0,YMMWORD PTR [r8]
  19f68f:	c4 c2 fd b8 29       	vfmadd231pd ymm5,ymm0,YMMWORD PTR [r9]
  19f694:	c4 c2 fd b8 33       	vfmadd231pd ymm6,ymm0,YMMWORD PTR [r11]
  19f699:	c4 e2 fd b8 7d 00    	vfmadd231pd ymm7,ymm0,YMMWORD PTR [rbp+0x0]
  19f69f:	4d 89 eb             	mov    r11,r13
  19f6a2:	49 89 d5             	mov    r13,rdx
  19f6a5:	48 8b 54 24 10       	mov    rdx,QWORD PTR [rsp+0x10]
  19f6aa:	c5 bd 58 c7          	vaddpd ymm0,ymm8,ymm7
  19f6ae:	c5 f5 58 f6          	vaddpd ymm6,ymm1,ymm6
  19f6b2:	c5 e5 58 dd          	vaddpd ymm3,ymm3,ymm5
  19f6b6:	c5 ed 58 cc          	vaddpd ymm1,ymm2,ymm4
  19f6ba:	c4 e3 7d 19 ca 01    	vextractf128 xmm2,ymm1,0x1
  19f6c0:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
  19f6c4:	c5 f1 c6 d1 01       	vshufpd xmm2,xmm1,xmm1,0x1
  19f6c9:	c5 f3 58 ca          	vaddsd xmm1,xmm1,xmm2
  19f6cd:	c4 e3 7d 19 da 01    	vextractf128 xmm2,ymm3,0x1
  19f6d3:	c5 e1 58 d2          	vaddpd xmm2,xmm3,xmm2
  19f6d7:	c5 e9 c6 da 01       	vshufpd xmm3,xmm2,xmm2,0x1
  19f6dc:	c5 eb 58 d3          	vaddsd xmm2,xmm2,xmm3
  19f6e0:	c4 e3 7d 19 f3 01    	vextractf128 xmm3,ymm6,0x1
  19f6e6:	c5 c9 58 db          	vaddpd xmm3,xmm6,xmm3
  19f6ea:	c5 e1 c6 e3 01       	vshufpd xmm4,xmm3,xmm3,0x1
  19f6ef:	c5 e3 58 dc          	vaddsd xmm3,xmm3,xmm4
  19f6f3:	c4 e3 7d 19 c4 01    	vextractf128 xmm4,ymm0,0x1
  19f6f9:	c5 f9 58 c4          	vaddpd xmm0,xmm0,xmm4
  19f6fd:	c5 f9 c6 e0 01       	vshufpd xmm4,xmm0,xmm0,0x1
  19f702:	c5 fb 58 e4          	vaddsd xmm4,xmm0,xmm4
  19f706:	4d 85 ff             	test   r15,r15
  19f709:	48 8b b4 24 80 01 00 	mov    rsi,QWORD PTR [rsp+0x180]
  19f710:	00 
  19f711:	48 8b bc 24 d0 01 00 	mov    rdi,QWORD PTR [rsp+0x1d0]
  19f718:	00 
  19f719:	4c 8b 84 24 c8 01 00 	mov    r8,QWORD PTR [rsp+0x1c8]
  19f720:	00 
  19f721:	0f 84 46 02 00 00    	je     19f96d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x280d>
  19f727:	4c 39 e6             	cmp    rsi,r12
  19f72a:	4c 89 e0             	mov    rax,r12
  19f72d:	48 0f 42 c6          	cmovb  rax,rsi
  19f731:	48 39 f8             	cmp    rax,rdi
  19f734:	48 0f 43 c7          	cmovae rax,rdi
  19f738:	49 8d 4f ff          	lea    rcx,[r15-0x1]
  19f73c:	4c 39 c0             	cmp    rax,r8
  19f73f:	49 0f 43 c0          	cmovae rax,r8
  19f743:	48 39 c1             	cmp    rcx,rax
  19f746:	48 0f 42 c1          	cmovb  rax,rcx
  19f74a:	49 39 c4             	cmp    r12,rax
  19f74d:	0f 84 b7 08 00 00    	je     1a000a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2eaa>
  19f753:	48 39 c6             	cmp    rsi,rax
  19f756:	0f 84 c4 08 00 00    	je     1a0020 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2ec0>
  19f75c:	48 39 c7             	cmp    rdi,rax
  19f75f:	0f 84 ce 08 00 00    	je     1a0033 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2ed3>
  19f765:	49 39 c0             	cmp    r8,rax
  19f768:	0f 84 d8 08 00 00    	je     1a0046 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2ee6>
  19f76e:	44 89 ff             	mov    edi,r15d
  19f771:	83 e7 03             	and    edi,0x3
  19f774:	49 83 ff 04          	cmp    r15,0x4
  19f778:	73 1c                	jae    19f796 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2636>
  19f77a:	45 31 ff             	xor    r15d,r15d
  19f77d:	4c 8b 64 24 38       	mov    r12,QWORD PTR [rsp+0x38]
  19f782:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
  19f787:	48 8b 4c 24 28       	mov    rcx,QWORD PTR [rsp+0x28]
  19f78c:	48 8b 6c 24 48       	mov    rbp,QWORD PTR [rsp+0x48]
  19f791:	e9 3f 01 00 00       	jmp    19f8d5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2775>
  19f796:	4c 89 f8             	mov    rax,r15
  19f799:	48 83 e0 fc          	and    rax,0xfffffffffffffffc
  19f79d:	4c 8b 84 24 d0 00 00 	mov    r8,QWORD PTR [rsp+0xd0]
  19f7a4:	00 
  19f7a5:	49 bc fc ff ff ff ff 	movabs r12,0xffffffffffffffc
  19f7ac:	ff ff 0f 
  19f7af:	4d 21 e0             	and    r8,r12
  19f7b2:	4c 8b 4c 24 38       	mov    r9,QWORD PTR [rsp+0x38]
  19f7b7:	4f 8d 04 c1          	lea    r8,[r9+r8*8]
  19f7bb:	49 83 c0 18          	add    r8,0x18
  19f7bf:	48 8b 8c 24 98 00 00 	mov    rcx,QWORD PTR [rsp+0x98]
  19f7c6:	00 
  19f7c7:	4d 8d 0c ca          	lea    r9,[r10+rcx*8]
  19f7cb:	49 83 c1 18          	add    r9,0x18
  19f7cf:	4c 8b 5c 24 58       	mov    r11,QWORD PTR [rsp+0x58]
  19f7d4:	4d 21 e3             	and    r11,r12
  19f7d7:	4c 8b 74 24 20       	mov    r14,QWORD PTR [rsp+0x20]
  19f7dc:	4f 8d 1c de          	lea    r11,[r14+r11*8]
  19f7e0:	49 83 c3 18          	add    r11,0x18
  19f7e4:	4c 8b b4 24 88 00 00 	mov    r14,QWORD PTR [rsp+0x88]
  19f7eb:	00 
  19f7ec:	4d 21 e6             	and    r14,r12
  19f7ef:	48 8b 4c 24 28       	mov    rcx,QWORD PTR [rsp+0x28]
  19f7f4:	4e 8d 34 f1          	lea    r14,[rcx+r14*8]
  19f7f8:	49 83 c6 18          	add    r14,0x18
  19f7fc:	4c 8b bc 24 80 00 00 	mov    r15,QWORD PTR [rsp+0x80]
  19f803:	00 
  19f804:	4d 21 e7             	and    r15,r12
  19f807:	48 8b 4c 24 48       	mov    rcx,QWORD PTR [rsp+0x48]
  19f80c:	4e 8d 24 f9          	lea    r12,[rcx+r15*8]
  19f810:	49 83 c4 18          	add    r12,0x18
  19f814:	45 31 ff             	xor    r15d,r15d
  19f817:	c4 81 7b 10 44 f9 e8 	vmovsd xmm0,QWORD PTR [r9+r15*8-0x18]
  19f81e:	c4 81 7b 10 6c f9 f0 	vmovsd xmm5,QWORD PTR [r9+r15*8-0x10]
  19f825:	c4 82 f9 b9 4c f8 e8 	vfmadd231sd xmm1,xmm0,QWORD PTR [r8+r15*8-0x18]
  19f82c:	c4 82 f9 b9 54 fb e8 	vfmadd231sd xmm2,xmm0,QWORD PTR [r11+r15*8-0x18]
  19f833:	c4 82 f9 b9 5c fe e8 	vfmadd231sd xmm3,xmm0,QWORD PTR [r14+r15*8-0x18]
  19f83a:	c4 82 f9 b9 64 fc e8 	vfmadd231sd xmm4,xmm0,QWORD PTR [r12+r15*8-0x18]
  19f841:	c4 82 d1 b9 4c f8 f0 	vfmadd231sd xmm1,xmm5,QWORD PTR [r8+r15*8-0x10]
  19f848:	c4 82 d1 b9 54 fb f0 	vfmadd231sd xmm2,xmm5,QWORD PTR [r11+r15*8-0x10]
  19f84f:	c4 82 d1 b9 5c fe f0 	vfmadd231sd xmm3,xmm5,QWORD PTR [r14+r15*8-0x10]
  19f856:	c4 82 d1 b9 64 fc f0 	vfmadd231sd xmm4,xmm5,QWORD PTR [r12+r15*8-0x10]
  19f85d:	c4 81 7b 10 44 f9 f8 	vmovsd xmm0,QWORD PTR [r9+r15*8-0x8]
  19f864:	c4 82 f9 b9 4c f8 f8 	vfmadd231sd xmm1,xmm0,QWORD PTR [r8+r15*8-0x8]
  19f86b:	c4 82 f9 b9 54 fb f8 	vfmadd231sd xmm2,xmm0,QWORD PTR [r11+r15*8-0x8]
  19f872:	c4 82 f9 b9 5c fe f8 	vfmadd231sd xmm3,xmm0,QWORD PTR [r14+r15*8-0x8]
  19f879:	c4 82 f9 b9 64 fc f8 	vfmadd231sd xmm4,xmm0,QWORD PTR [r12+r15*8-0x8]
  19f880:	c4 81 7b 10 04 f9    	vmovsd xmm0,QWORD PTR [r9+r15*8]
  19f886:	c4 82 f9 b9 0c f8    	vfmadd231sd xmm1,xmm0,QWORD PTR [r8+r15*8]
  19f88c:	c4 82 f9 b9 14 fb    	vfmadd231sd xmm2,xmm0,QWORD PTR [r11+r15*8]
  19f892:	c4 82 f9 b9 1c fe    	vfmadd231sd xmm3,xmm0,QWORD PTR [r14+r15*8]
  19f898:	c4 82 f9 b9 24 fc    	vfmadd231sd xmm4,xmm0,QWORD PTR [r12+r15*8]
  19f89e:	49 83 c7 04          	add    r15,0x4
  19f8a2:	4c 39 f8             	cmp    rax,r15
  19f8a5:	0f 85 6c ff ff ff    	jne    19f817 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x26b7>
  19f8ab:	48 85 ff             	test   rdi,rdi
  19f8ae:	4c 8b 9c 24 e8 00 00 	mov    r11,QWORD PTR [rsp+0xe8]
  19f8b5:	00 
  19f8b6:	4c 8b 74 24 30       	mov    r14,QWORD PTR [rsp+0x30]
  19f8bb:	4c 8b 64 24 38       	mov    r12,QWORD PTR [rsp+0x38]
  19f8c0:	48 8b 74 24 20       	mov    rsi,QWORD PTR [rsp+0x20]
  19f8c5:	48 8b 4c 24 28       	mov    rcx,QWORD PTR [rsp+0x28]
  19f8ca:	48 8b 6c 24 48       	mov    rbp,QWORD PTR [rsp+0x48]
  19f8cf:	0f 84 98 00 00 00    	je     19f96d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x280d>
  19f8d5:	49 b9 fc ff ff ff ff 	movabs r9,0xffffffffffffffc
  19f8dc:	ff ff 0f 
  19f8df:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
  19f8e6:	00 
  19f8e7:	4c 21 c8             	and    rax,r9
  19f8ea:	4e 8d 04 fd 00 00 00 	lea    r8,[r15*8+0x0]
  19f8f1:	00 
  19f8f2:	49 8d 04 c0          	lea    rax,[r8+rax*8]
  19f8f6:	48 01 c5             	add    rbp,rax
  19f8f9:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
  19f900:	00 
  19f901:	4c 21 c8             	and    rax,r9
  19f904:	49 8d 04 c0          	lea    rax,[r8+rax*8]
  19f908:	48 01 c1             	add    rcx,rax
  19f90b:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
  19f910:	4c 21 c8             	and    rax,r9
  19f913:	49 8d 04 c0          	lea    rax,[r8+rax*8]
  19f917:	48 01 c6             	add    rsi,rax
  19f91a:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
  19f921:	00 
  19f922:	48 8d 04 c5 00 00 00 	lea    rax,[rax*8+0x0]
  19f929:	00 
  19f92a:	4a 8d 04 f8          	lea    rax,[rax+r15*8]
  19f92e:	4c 01 d0             	add    rax,r10
  19f931:	4c 8b bc 24 d0 00 00 	mov    r15,QWORD PTR [rsp+0xd0]
  19f938:	00 
  19f939:	4d 21 cf             	and    r15,r9
  19f93c:	4f 8d 04 f8          	lea    r8,[r8+r15*8]
  19f940:	4d 01 c4             	add    r12,r8
  19f943:	45 31 c0             	xor    r8d,r8d
  19f946:	c4 a1 7b 10 04 c0    	vmovsd xmm0,QWORD PTR [rax+r8*8]
  19f94c:	c4 82 f9 b9 0c c4    	vfmadd231sd xmm1,xmm0,QWORD PTR [r12+r8*8]
  19f952:	c4 a2 f9 b9 14 c6    	vfmadd231sd xmm2,xmm0,QWORD PTR [rsi+r8*8]
  19f958:	c4 a2 f9 b9 1c c1    	vfmadd231sd xmm3,xmm0,QWORD PTR [rcx+r8*8]
  19f95e:	c4 a2 f9 b9 64 c5 00 	vfmadd231sd xmm4,xmm0,QWORD PTR [rbp+r8*8+0x0]
  19f965:	49 ff c0             	inc    r8
  19f968:	4c 39 c7             	cmp    rdi,r8
  19f96b:	75 d9                	jne    19f946 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x27e6>
  19f96d:	4c 8b 84 24 f8 00 00 	mov    r8,QWORD PTR [rsp+0xf8]
  19f974:	00 
  19f975:	4c 89 c0             	mov    rax,r8
  19f978:	48 c1 e8 03          	shr    rax,0x3
  19f97c:	48 39 c2             	cmp    rdx,rax
  19f97f:	48 0f 42 c2          	cmovb  rax,rdx
  19f983:	48 8b 4c 24 40       	mov    rcx,QWORD PTR [rsp+0x40]
  19f988:	48 39 c1             	cmp    rcx,rax
  19f98b:	48 0f 42 c1          	cmovb  rax,rcx
  19f98f:	48 85 c0             	test   rax,rax
  19f992:	74 44                	je     19f9d8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2878>
  19f994:	48 83 f8 01          	cmp    rax,0x1
  19f998:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
  19f99f:	00 
  19f9a0:	4c 8b 7c 24 70       	mov    r15,QWORD PTR [rsp+0x70]
  19f9a5:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
  19f9aa:	75 68                	jne    19fa14 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x28b4>
  19f9ac:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  19f9b0:	31 d2                	xor    edx,edx
  19f9b2:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  19f9b6:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  19f9ba:	c4 41 21 57 db       	vxorpd xmm11,xmm11,xmm11
  19f9bf:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  19f9c4:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  19f9c9:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  19f9ce:	c4 41 19 57 e4       	vxorpd xmm12,xmm12,xmm12
  19f9d3:	e9 19 01 00 00       	jmp    19faf1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2991>
  19f9d8:	c4 41 19 57 e4       	vxorpd xmm12,xmm12,xmm12
  19f9dd:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  19f9e2:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  19f9e7:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  19f9ec:	c4 41 21 57 db       	vxorpd xmm11,xmm11,xmm11
  19f9f1:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  19f9f5:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  19f9f9:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  19f9fd:	48 8b 8c 24 b8 00 00 	mov    rcx,QWORD PTR [rsp+0xb8]
  19fa04:	00 
  19fa05:	4c 8b 7c 24 70       	mov    r15,QWORD PTR [rsp+0x70]
  19fa0a:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
  19fa0f:	e9 2a 01 00 00       	jmp    19fb3e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x29de>
  19fa14:	49 bc fe ff ff ff ff 	movabs r12,0x1ffffffffffffffe
  19fa1b:	ff ff 1f 
  19fa1e:	49 21 c4             	and    r12,rax
  19fa21:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  19fa25:	bf 60 00 00 00       	mov    edi,0x60
  19fa2a:	31 d2                	xor    edx,edx
  19fa2c:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  19fa30:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  19fa34:	c4 41 21 57 db       	vxorpd xmm11,xmm11,xmm11
  19fa39:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  19fa3e:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  19fa43:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  19fa48:	c4 41 19 57 e4       	vxorpd xmm12,xmm12,xmm12
  19fa4d:	4c 8b 8c 24 90 00 00 	mov    r9,QWORD PTR [rsp+0x90]
  19fa54:	00 
  19fa55:	c4 c1 7d 10 44 3a a0 	vmovupd ymm0,YMMWORD PTR [r10+rdi*1-0x60]
  19fa5c:	c4 41 7d 10 6c 3a c0 	vmovupd ymm13,YMMWORD PTR [r10+rdi*1-0x40]
  19fa63:	c4 41 7d 10 74 3a e0 	vmovupd ymm14,YMMWORD PTR [r10+rdi*1-0x20]
  19fa6a:	c4 62 fd b8 44 3b a0 	vfmadd231pd ymm8,ymm0,YMMWORD PTR [rbx+rdi*1-0x60]
  19fa71:	c4 42 fd b8 4c 39 a0 	vfmadd231pd ymm9,ymm0,YMMWORD PTR [r9+rdi*1-0x60]
  19fa78:	c4 62 fd b8 54 39 a0 	vfmadd231pd ymm10,ymm0,YMMWORD PTR [rcx+rdi*1-0x60]
  19fa7f:	c4 42 fd b8 5c 3f a0 	vfmadd231pd ymm11,ymm0,YMMWORD PTR [r15+rdi*1-0x60]
  19fa86:	c4 e2 95 b8 74 3b c0 	vfmadd231pd ymm6,ymm13,YMMWORD PTR [rbx+rdi*1-0x40]
  19fa8d:	c4 c2 95 b8 7c 39 c0 	vfmadd231pd ymm7,ymm13,YMMWORD PTR [r9+rdi*1-0x40]
  19fa94:	c4 e2 95 b8 6c 39 c0 	vfmadd231pd ymm5,ymm13,YMMWORD PTR [rcx+rdi*1-0x40]
  19fa9b:	c4 42 95 b8 64 3f c0 	vfmadd231pd ymm12,ymm13,YMMWORD PTR [r15+rdi*1-0x40]
  19faa2:	c4 c1 7d 10 04 3a    	vmovupd ymm0,YMMWORD PTR [r10+rdi*1]
  19faa8:	48 83 c2 02          	add    rdx,0x2
  19faac:	c4 62 8d b8 44 3b e0 	vfmadd231pd ymm8,ymm14,YMMWORD PTR [rbx+rdi*1-0x20]
  19fab3:	c4 42 8d b8 4c 39 e0 	vfmadd231pd ymm9,ymm14,YMMWORD PTR [r9+rdi*1-0x20]
  19faba:	c4 62 8d b8 54 39 e0 	vfmadd231pd ymm10,ymm14,YMMWORD PTR [rcx+rdi*1-0x20]
  19fac1:	c4 42 8d b8 5c 3f e0 	vfmadd231pd ymm11,ymm14,YMMWORD PTR [r15+rdi*1-0x20]
  19fac8:	c4 e2 fd b8 34 3b    	vfmadd231pd ymm6,ymm0,YMMWORD PTR [rbx+rdi*1]
  19face:	c4 c2 fd b8 3c 39    	vfmadd231pd ymm7,ymm0,YMMWORD PTR [r9+rdi*1]
  19fad4:	c4 e2 fd b8 2c 39    	vfmadd231pd ymm5,ymm0,YMMWORD PTR [rcx+rdi*1]
  19fada:	c4 42 fd b8 24 3f    	vfmadd231pd ymm12,ymm0,YMMWORD PTR [r15+rdi*1]
  19fae0:	48 83 ef 80          	sub    rdi,0xffffffffffffff80
  19fae4:	49 39 d4             	cmp    r12,rdx
  19fae7:	0f 85 68 ff ff ff    	jne    19fa55 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x28f5>
  19faed:	a8 01                	test   al,0x1
  19faef:	74 4d                	je     19fb3e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x29de>
  19faf1:	48 c1 e2 06          	shl    rdx,0x6
  19faf5:	c4 c1 7d 10 04 12    	vmovupd ymm0,YMMWORD PTR [r10+rdx*1]
  19fafb:	c4 41 7d 10 6c 12 20 	vmovupd ymm13,YMMWORD PTR [r10+rdx*1+0x20]
  19fb02:	c4 62 fd b8 04 13    	vfmadd231pd ymm8,ymm0,YMMWORD PTR [rbx+rdx*1]
  19fb08:	48 8b 84 24 90 00 00 	mov    rax,QWORD PTR [rsp+0x90]
  19fb0f:	00 
  19fb10:	c4 62 fd b8 0c 10    	vfmadd231pd ymm9,ymm0,YMMWORD PTR [rax+rdx*1]
  19fb16:	c4 62 fd b8 14 11    	vfmadd231pd ymm10,ymm0,YMMWORD PTR [rcx+rdx*1]
  19fb1c:	c4 42 fd b8 1c 17    	vfmadd231pd ymm11,ymm0,YMMWORD PTR [r15+rdx*1]
  19fb22:	c4 e2 95 b8 74 13 20 	vfmadd231pd ymm6,ymm13,YMMWORD PTR [rbx+rdx*1+0x20]
  19fb29:	c4 e2 95 b8 7c 10 20 	vfmadd231pd ymm7,ymm13,YMMWORD PTR [rax+rdx*1+0x20]
  19fb30:	c4 e2 95 b8 6c 11 20 	vfmadd231pd ymm5,ymm13,YMMWORD PTR [rcx+rdx*1+0x20]
  19fb37:	c4 42 95 b8 64 17 20 	vfmadd231pd ymm12,ymm13,YMMWORD PTR [r15+rdx*1+0x20]
  19fb3e:	f6 44 24 08 04       	test   BYTE PTR [rsp+0x8],0x4
  19fb43:	74 6f                	je     19fbb4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2a54>
  19fb45:	f6 84 24 a0 01 00 00 	test   BYTE PTR [rsp+0x1a0],0x1
  19fb4c:	01 
  19fb4d:	0f 84 0e 03 00 00    	je     19fe61 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d01>
  19fb53:	41 f6 c0 04          	test   r8b,0x4
  19fb57:	48 ba fe ff ff ff ff 	movabs rdx,0x3fffffffffffffe
  19fb5e:	ff ff 03 
  19fb61:	0f 84 0e 03 00 00    	je     19fe75 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d15>
  19fb67:	4c 89 c0             	mov    rax,r8
  19fb6a:	48 c1 e8 02          	shr    rax,0x2
  19fb6e:	48 21 d0             	and    rax,rdx
  19fb71:	48 c1 e0 05          	shl    rax,0x5
  19fb75:	48 8d 14 03          	lea    rdx,[rbx+rax*1]
  19fb79:	48 8b bc 24 90 00 00 	mov    rdi,QWORD PTR [rsp+0x90]
  19fb80:	00 
  19fb81:	48 01 c7             	add    rdi,rax
  19fb84:	4c 8d 04 01          	lea    r8,[rcx+rax*1]
  19fb88:	4c 01 f8             	add    rax,r15
  19fb8b:	4c 8b 8c 24 30 01 00 	mov    r9,QWORD PTR [rsp+0x130]
  19fb92:	00 
  19fb93:	c4 c1 7d 10 01       	vmovupd ymm0,YMMWORD PTR [r9]
  19fb98:	c4 62 fd b8 02       	vfmadd231pd ymm8,ymm0,YMMWORD PTR [rdx]
  19fb9d:	c4 62 fd b8 0f       	vfmadd231pd ymm9,ymm0,YMMWORD PTR [rdi]
  19fba2:	c4 42 fd b8 10       	vfmadd231pd ymm10,ymm0,YMMWORD PTR [r8]
  19fba7:	4c 8b 84 24 f8 00 00 	mov    r8,QWORD PTR [rsp+0xf8]
  19fbae:	00 
  19fbaf:	c4 62 fd b8 18       	vfmadd231pd ymm11,ymm0,YMMWORD PTR [rax]
  19fbb4:	c4 c1 1d 58 c3       	vaddpd ymm0,ymm12,ymm11
  19fbb9:	c5 ad 58 ed          	vaddpd ymm5,ymm10,ymm5
  19fbbd:	c5 35 58 cf          	vaddpd ymm9,ymm9,ymm7
  19fbc1:	c5 bd 58 f6          	vaddpd ymm6,ymm8,ymm6
  19fbc5:	c4 e3 7d 19 f7 01    	vextractf128 xmm7,ymm6,0x1
  19fbcb:	c5 c9 58 f7          	vaddpd xmm6,xmm6,xmm7
  19fbcf:	c5 c9 c6 fe 01       	vshufpd xmm7,xmm6,xmm6,0x1
  19fbd4:	c5 cb 58 ff          	vaddsd xmm7,xmm6,xmm7
  19fbd8:	c4 63 7d 19 ce 01    	vextractf128 xmm6,ymm9,0x1
  19fbde:	c5 b1 58 f6          	vaddpd xmm6,xmm9,xmm6
  19fbe2:	c5 49 c6 c6 01       	vshufpd xmm8,xmm6,xmm6,0x1
  19fbe7:	c5 3b 58 c6          	vaddsd xmm8,xmm8,xmm6
  19fbeb:	c4 e3 7d 19 ee 01    	vextractf128 xmm6,ymm5,0x1
  19fbf1:	c5 d1 58 ee          	vaddpd xmm5,xmm5,xmm6
  19fbf5:	c5 d1 c6 f5 01       	vshufpd xmm6,xmm5,xmm5,0x1
  19fbfa:	c5 d3 58 ee          	vaddsd xmm5,xmm5,xmm6
  19fbfe:	c4 e3 7d 19 c6 01    	vextractf128 xmm6,ymm0,0x1
  19fc04:	c5 f9 58 c6          	vaddpd xmm0,xmm0,xmm6
  19fc08:	c5 f9 c6 f0 01       	vshufpd xmm6,xmm0,xmm0,0x1
  19fc0d:	c5 fb 58 f6          	vaddsd xmm6,xmm0,xmm6
  19fc11:	4c 8b a4 24 b0 00 00 	mov    r12,QWORD PTR [rsp+0xb0]
  19fc18:	00 
  19fc19:	4d 85 e4             	test   r12,r12
  19fc1c:	74 75                	je     19fc93 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2b33>
  19fc1e:	44 89 c7             	mov    edi,r8d
  19fc21:	83 e7 03             	and    edi,0x3
  19fc24:	49 8d 44 24 ff       	lea    rax,[r12-0x1]
  19fc29:	48 39 c7             	cmp    rdi,rax
  19fc2c:	0f 86 2a 04 00 00    	jbe    1a005c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2efc>
  19fc32:	48 b8 fc ff ff ff ff 	movabs rax,0xffffffffffffffc
  19fc39:	ff ff 0f 
  19fc3c:	49 21 c0             	and    r8,rax
  19fc3f:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
  19fc46:	00 
  19fc47:	49 8d 04 c2          	lea    rax,[r10+rax*8]
  19fc4b:	4a 8d 14 c3          	lea    rdx,[rbx+r8*8]
  19fc4f:	48 8b bc 24 90 00 00 	mov    rdi,QWORD PTR [rsp+0x90]
  19fc56:	00 
  19fc57:	4a 8d 3c c7          	lea    rdi,[rdi+r8*8]
  19fc5b:	4a 8d 0c c1          	lea    rcx,[rcx+r8*8]
  19fc5f:	4f 8d 0c c7          	lea    r9,[r15+r8*8]
  19fc63:	41 83 e4 03          	and    r12d,0x3
  19fc67:	45 31 c0             	xor    r8d,r8d
  19fc6a:	4d 89 e2             	mov    r10,r12
  19fc6d:	c4 a1 7b 10 04 c0    	vmovsd xmm0,QWORD PTR [rax+r8*8]
  19fc73:	c4 a2 f9 b9 3c c2    	vfmadd231sd xmm7,xmm0,QWORD PTR [rdx+r8*8]
  19fc79:	c4 22 f9 b9 04 c7    	vfmadd231sd xmm8,xmm0,QWORD PTR [rdi+r8*8]
  19fc7f:	c4 a2 f9 b9 2c c1    	vfmadd231sd xmm5,xmm0,QWORD PTR [rcx+r8*8]
  19fc85:	c4 82 f9 b9 34 c1    	vfmadd231sd xmm6,xmm0,QWORD PTR [r9+r8*8]
  19fc8b:	49 ff c0             	inc    r8
  19fc8e:	4d 39 c2             	cmp    r10,r8
  19fc91:	75 da                	jne    19fc6d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2b0d>
  19fc93:	49 83 e5 fe          	and    r13,0xfffffffffffffffe
  19fc97:	49 8d 45 fe          	lea    rax,[r13-0x2]
  19fc9b:	48 39 f0             	cmp    rax,rsi
  19fc9e:	0f 83 b1 02 00 00    	jae    19ff55 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2df5>
  19fca4:	48 89 c1             	mov    rcx,rax
  19fca7:	48 c1 e1 04          	shl    rcx,0x4
  19fcab:	48 8b bc 24 c0 00 00 	mov    rdi,QWORD PTR [rsp+0xc0]
  19fcb2:	00 
  19fcb3:	c5 fb 11 3c 0f       	vmovsd QWORD PTR [rdi+rcx*1],xmm7
  19fcb8:	48 8b 94 24 58 01 00 	mov    rdx,QWORD PTR [rsp+0x158]
  19fcbf:	00 
  19fcc0:	4c 01 ea             	add    rdx,r13
  19fcc3:	48 83 c2 fe          	add    rdx,0xfffffffffffffffe
  19fcc7:	c5 7b 11 44 0f 08    	vmovsd QWORD PTR [rdi+rcx*1+0x8],xmm8
  19fccd:	48 3b 54 24 60       	cmp    rdx,QWORD PTR [rsp+0x60]
  19fcd2:	73 52                	jae    19fd26 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2bc6>
  19fcd4:	49 ff cd             	dec    r13
  19fcd7:	49 39 f5             	cmp    r13,rsi
  19fcda:	0f 83 cb 03 00 00    	jae    1a00ab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2f4b>
  19fce0:	4c 89 ea             	mov    rdx,r13
  19fce3:	48 c1 e2 04          	shl    rdx,0x4
  19fce7:	48 8b b4 24 c0 00 00 	mov    rsi,QWORD PTR [rsp+0xc0]
  19fcee:	00 
  19fcef:	c5 fb 11 2c 16       	vmovsd QWORD PTR [rsi+rdx*1],xmm5
  19fcf4:	c5 fb 11 74 16 08    	vmovsd QWORD PTR [rsi+rdx*1+0x8],xmm6
  19fcfa:	4c 39 f0             	cmp    rax,r14
  19fcfd:	0f 83 65 02 00 00    	jae    19ff68 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2e08>
  19fd03:	c4 c1 7b 11 0c 0b    	vmovsd QWORD PTR [r11+rcx*1],xmm1
  19fd09:	c4 c1 7b 11 54 0b 08 	vmovsd QWORD PTR [r11+rcx*1+0x8],xmm2
  19fd10:	4d 39 f5             	cmp    r13,r14
  19fd13:	0f 83 70 01 00 00    	jae    19fe89 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d29>
  19fd19:	4c 89 e8             	mov    rax,r13
  19fd1c:	c5 f9 28 cb          	vmovapd xmm1,xmm3
  19fd20:	c5 f9 28 d4          	vmovapd xmm2,xmm4
  19fd24:	eb 09                	jmp    19fd2f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2bcf>
  19fd26:	4c 39 f0             	cmp    rax,r14
  19fd29:	0f 83 39 02 00 00    	jae    19ff68 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2e08>
  19fd2f:	48 c1 e0 04          	shl    rax,0x4
  19fd33:	c4 c1 7b 11 0c 03    	vmovsd QWORD PTR [r11+rax*1],xmm1
  19fd39:	c4 c1 7b 11 54 03 08 	vmovsd QWORD PTR [r11+rax*1+0x8],xmm2
  19fd40:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  19fd44:	c4 c2 7d 37 c7       	vpcmpgtq ymm0,ymm0,ymm15
  19fd49:	c4 e2 7d 59 0d b6 13 	vpbroadcastq ymm1,QWORD PTR [rip+0xffffffffffe813b6]        # 21108 <anon.18cb9c1b3fe794d0b89f358a70182f4e.25.llvm.5582884991536083740+0x498>
  19fd50:	e8 ff 
  19fd52:	c5 fd db c1          	vpand  ymm0,ymm0,ymm1
  19fd56:	c4 e3 7d 39 c1 01    	vextracti128 xmm1,ymm0,0x1
  19fd5c:	c5 f9 5d c1          	vminpd xmm0,xmm0,xmm1
  19fd60:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  19fd65:	c5 fb 5d c1          	vminsd xmm0,xmm0,xmm1
  19fd69:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
  19fd6d:	c5 f9 2e c1          	vucomisd xmm0,xmm1
  19fd71:	0f 97 c0             	seta   al
  19fd74:	22 44 24 07          	and    al,BYTE PTR [rsp+0x7]
  19fd78:	eb 39                	jmp    19fdb3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2c53>
  19fd7a:	48 8b 8c 24 c8 00 00 	mov    rcx,QWORD PTR [rsp+0xc8]
  19fd81:	00 
  19fd82:	48 39 c8             	cmp    rax,rcx
  19fd85:	0f 83 0b 02 00 00    	jae    19ff96 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2e36>
  19fd8b:	48 8b b4 24 f0 00 00 	mov    rsi,QWORD PTR [rsp+0xf0]
  19fd92:	00 
  19fd93:	48 39 f0             	cmp    rax,rsi
  19fd96:	0f 83 1c 02 00 00    	jae    19ffb8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2e58>
  19fd9c:	48 ff c0             	inc    rax
  19fd9f:	48 39 c8             	cmp    rax,rcx
  19fda2:	0f 83 0d 01 00 00    	jae    19feb5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d55>
  19fda8:	48 39 f0             	cmp    rax,rsi
  19fdab:	0f 83 1f 01 00 00    	jae    19fed0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x2d70>
  19fdb1:	31 c0                	xor    eax,eax
  19fdb3:	48 81 c4 78 02 00 00 	add    rsp,0x278
  19fdba:	5b                   	pop    rbx
  19fdbb:	41 5c                	pop    r12
  19fdbd:	41 5d                	pop    r13
  19fdbf:	41 5e                	pop    r14
  19fdc1:	41 5f                	pop    r15
  19fdc3:	5d                   	pop    rbp
  19fdc4:	c5 f8 77             	vzeroupper
  19fdc7:	c3                   	ret
  19fdc8:	48 8b 44 24 58       	mov    rax,QWORD PTR [rsp+0x58]
  19fdcd:	49 89 c1             	mov    r9,rax
  19fdd0:	48 89 44 24 08       	mov    QWORD PTR [rsp+0x8],rax
  19fdd5:	e9 99 d6 ff ff       	jmp    19d473 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, true, true, true>>>+0x313>
  19fdda:	48 8d 15 8f 6d 0d 00 	lea    rdx,[rip+0xd6d8f]        # 276b70 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x608>
  19fde1:	48 8b bc 24 e0 00 00 	mov    rdi,QWORD PTR [rsp+0xe0]
  19fde8:	00 
  19fde9:	48 8b b4 24 c8 00 00 	mov    rsi,QWORD PTR [rsp+0xc8]
  19fdf0:	00 
  19fdf1:	c5 f8 77             	vzeroupper
  19fdf4:	ff 15 96 08 0e 00    	call   QWORD PTR [rip+0xe0896]        # 280690 <_DYNAMIC+0x2b8>
  19fdfa:	48 8d 15 87 6d 0d 00 	lea    rdx,[rip+0xd6d87]        # 276b88 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x620>
  19fe01:	48 8b bc 24 d8 00 00 	mov    rdi,QWORD PTR [rsp+0xd8]
  19fe08:	00 
  19fe09:	48 8b b4 24 f0 00 00 	mov    rsi,QWORD PTR [rsp+0xf0]
  19fe10:	00 
  19fe11:	c5 f8 77             	vzeroupper
  19fe14:	ff 15 76 08 0e 00    	call   QWORD PTR [rip+0xe0876]        # 280690 <_DYNAMIC+0x2b8>
  19fe1a:	48 8d 15 ef 78 0d 00 	lea    rdx,[rip+0xd78ef]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  19fe21:	4c 89 ef             	mov    rdi,r13
  19fe24:	4c 89 f6             	mov    rsi,r14
  19fe27:	c5 f8 77             	vzeroupper
  19fe2a:	ff 15 60 08 0e 00    	call   QWORD PTR [rip+0xe0860]        # 280690 <_DYNAMIC+0x2b8>
  19fe30:	48 8d 15 d9 78 0d 00 	lea    rdx,[rip+0xd78d9]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  19fe37:	4c 89 ef             	mov    rdi,r13
  19fe3a:	48 89 ee             	mov    rsi,rbp
  19fe3d:	c5 f8 77             	vzeroupper
  19fe40:	ff 15 4a 08 0e 00    	call   QWORD PTR [rip+0xe084a]        # 280690 <_DYNAMIC+0x2b8>
  19fe46:	48 8d 15 5b 71 0d 00 	lea    rdx,[rip+0xd715b]        # 276fa8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa40>
  19fe4d:	48 8b bc 24 e8 01 00 	mov    rdi,QWORD PTR [rsp+0x1e8]
  19fe54:	00 
  19fe55:	48 89 fe             	mov    rsi,rdi
  19fe58:	c5 f8 77             	vzeroupper
  19fe5b:	ff 15 2f 08 0e 00    	call   QWORD PTR [rip+0xe082f]        # 280690 <_DYNAMIC+0x2b8>
  19fe61:	48 8d 15 c8 70 0d 00 	lea    rdx,[rip+0xd70c8]        # 276f30 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9c8>
  19fe68:	31 ff                	xor    edi,edi
  19fe6a:	31 f6                	xor    esi,esi
  19fe6c:	c5 f8 77             	vzeroupper
  19fe6f:	ff 15 1b 08 0e 00    	call   QWORD PTR [rip+0xe081b]        # 280690 <_DYNAMIC+0x2b8>
  19fe75:	48 8d 15 cc 70 0d 00 	lea    rdx,[rip+0xd70cc]        # 276f48 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9e0>
  19fe7c:	31 ff                	xor    edi,edi
  19fe7e:	31 f6                	xor    esi,esi
  19fe80:	c5 f8 77             	vzeroupper
  19fe83:	ff 15 07 08 0e 00    	call   QWORD PTR [rip+0xe0807]        # 280690 <_DYNAMIC+0x2b8>
  19fe89:	48 8d 15 98 78 0d 00 	lea    rdx,[rip+0xd7898]        # 277728 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  19fe90:	4c 89 ef             	mov    rdi,r13
  19fe93:	4c 89 f6             	mov    rsi,r14
  19fe96:	c5 f8 77             	vzeroupper
  19fe99:	ff 15 f1 07 0e 00    	call   QWORD PTR [rip+0xe07f1]        # 280690 <_DYNAMIC+0x2b8>
  19fe9f:	48 8d 15 82 78 0d 00 	lea    rdx,[rip+0xd7882]        # 277728 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  19fea6:	48 89 c7             	mov    rdi,rax
  19fea9:	48 89 ee             	mov    rsi,rbp
  19feac:	c5 f8 77             	vzeroupper
  19feaf:	ff 15 db 07 0e 00    	call   QWORD PTR [rip+0xe07db]        # 280690 <_DYNAMIC+0x2b8>
  19feb5:	48 8d 15 14 6d 0d 00 	lea    rdx,[rip+0xd6d14]        # 276bd0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x668>
  19febc:	48 89 c7             	mov    rdi,rax
  19febf:	48 8b b4 24 c8 00 00 	mov    rsi,QWORD PTR [rsp+0xc8]
  19fec6:	00 
  19fec7:	c5 f8 77             	vzeroupper
  19feca:	ff 15 c0 07 0e 00    	call   QWORD PTR [rip+0xe07c0]        # 280690 <_DYNAMIC+0x2b8>
  19fed0:	48 8d 15 11 6d 0d 00 	lea    rdx,[rip+0xd6d11]        # 276be8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x680>
  19fed7:	48 89 c7             	mov    rdi,rax
  19feda:	c5 f8 77             	vzeroupper
  19fedd:	ff 15 ad 07 0e 00    	call   QWORD PTR [rip+0xe07ad]        # 280690 <_DYNAMIC+0x2b8>
  19fee3:	48 8d 15 26 78 0d 00 	lea    rdx,[rip+0xd7826]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  19feea:	4c 89 f6             	mov    rsi,r14
  19feed:	c5 f8 77             	vzeroupper
  19fef0:	ff 15 9a 07 0e 00    	call   QWORD PTR [rip+0xe079a]        # 280690 <_DYNAMIC+0x2b8>
  19fef6:	48 8d 05 13 78 0d 00 	lea    rax,[rip+0xd7813]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  19fefd:	48 89 d7             	mov    rdi,rdx
  19ff00:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
  19ff05:	48 89 c2             	mov    rdx,rax
  19ff08:	c5 f8 77             	vzeroupper
  19ff0b:	ff 15 7f 07 0e 00    	call   QWORD PTR [rip+0xe077f]        # 280690 <_DYNAMIC+0x2b8>
  19ff11:	48 8d 05 f8 77 0d 00 	lea    rax,[rip+0xd77f8]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  19ff18:	48 89 d7             	mov    rdi,rdx
  19ff1b:	4c 89 f6             	mov    rsi,r14
  19ff1e:	48 89 c2             	mov    rdx,rax
  19ff21:	c5 f8 77             	vzeroupper
  19ff24:	ff 15 66 07 0e 00    	call   QWORD PTR [rip+0xe0766]        # 280690 <_DYNAMIC+0x2b8>
  19ff2a:	48 8d 15 df 77 0d 00 	lea    rdx,[rip+0xd77df]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  19ff31:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
  19ff36:	c5 f8 77             	vzeroupper
  19ff39:	ff 15 51 07 0e 00    	call   QWORD PTR [rip+0xe0751]        # 280690 <_DYNAMIC+0x2b8>
  19ff3f:	48 8d 15 e2 77 0d 00 	lea    rdx,[rip+0xd77e2]        # 277728 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  19ff46:	48 89 c7             	mov    rdi,rax
  19ff49:	4c 89 f6             	mov    rsi,r14
  19ff4c:	c5 f8 77             	vzeroupper
  19ff4f:	ff 15 3b 07 0e 00    	call   QWORD PTR [rip+0xe073b]        # 280690 <_DYNAMIC+0x2b8>
  19ff55:	48 8d 15 b4 77 0d 00 	lea    rdx,[rip+0xd77b4]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  19ff5c:	48 89 c7             	mov    rdi,rax
  19ff5f:	c5 f8 77             	vzeroupper
  19ff62:	ff 15 28 07 0e 00    	call   QWORD PTR [rip+0xe0728]        # 280690 <_DYNAMIC+0x2b8>
  19ff68:	48 8d 15 a1 77 0d 00 	lea    rdx,[rip+0xd77a1]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  19ff6f:	48 89 c7             	mov    rdi,rax
  19ff72:	4c 89 f6             	mov    rsi,r14
  19ff75:	c5 f8 77             	vzeroupper
  19ff78:	ff 15 12 07 0e 00    	call   QWORD PTR [rip+0xe0712]        # 280690 <_DYNAMIC+0x2b8>
  19ff7e:	48 8d 15 bb 6e 0d 00 	lea    rdx,[rip+0xd6ebb]        # 276e40 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x8d8>
  19ff85:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
  19ff8a:	48 89 fe             	mov    rsi,rdi
  19ff8d:	c5 f8 77             	vzeroupper
  19ff90:	ff 15 fa 06 0e 00    	call   QWORD PTR [rip+0xe06fa]        # 280690 <_DYNAMIC+0x2b8>
  19ff96:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
  19ff9b:	48 8d 15 fe 6b 0d 00 	lea    rdx,[rip+0xd6bfe]        # 276ba0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x638>
  19ffa2:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
  19ffa7:	48 8b b4 24 c8 00 00 	mov    rsi,QWORD PTR [rsp+0xc8]
  19ffae:	00 
  19ffaf:	c5 f8 77             	vzeroupper
  19ffb2:	ff 15 d8 06 0e 00    	call   QWORD PTR [rip+0xe06d8]        # 280690 <_DYNAMIC+0x2b8>
  19ffb8:	48 89 44 24 18       	mov    QWORD PTR [rsp+0x18],rax
  19ffbd:	48 8d 15 f4 6b 0d 00 	lea    rdx,[rip+0xd6bf4]        # 276bb8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x650>
  19ffc4:	48 8b 7c 24 18       	mov    rdi,QWORD PTR [rsp+0x18]
  19ffc9:	48 8b b4 24 f0 00 00 	mov    rsi,QWORD PTR [rsp+0xf0]
  19ffd0:	00 
  19ffd1:	c5 f8 77             	vzeroupper
  19ffd4:	ff 15 b6 06 0e 00    	call   QWORD PTR [rip+0xe06b6]        # 280690 <_DYNAMIC+0x2b8>
  19ffda:	48 8d 15 47 77 0d 00 	lea    rdx,[rip+0xd7747]        # 277728 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  19ffe1:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
  19ffe6:	c5 f8 77             	vzeroupper
  19ffe9:	ff 15 a1 06 0e 00    	call   QWORD PTR [rip+0xe06a1]        # 280690 <_DYNAMIC+0x2b8>
  19ffef:	48 8d 05 32 77 0d 00 	lea    rax,[rip+0xd7732]        # 277728 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  19fff6:	48 89 d7             	mov    rdi,rdx
  19fff9:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
  19fffe:	48 89 c2             	mov    rdx,rax
  1a0001:	c5 f8 77             	vzeroupper
  1a0004:	ff 15 86 06 0e 00    	call   QWORD PTR [rip+0xe0686]        # 280690 <_DYNAMIC+0x2b8>
  1a000a:	48 8d 15 97 6f 0d 00 	lea    rdx,[rip+0xd6f97]        # 276fa8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa40>
  1a0011:	4c 89 e7             	mov    rdi,r12
  1a0014:	4c 89 e6             	mov    rsi,r12
  1a0017:	c5 f8 77             	vzeroupper
  1a001a:	ff 15 70 06 0e 00    	call   QWORD PTR [rip+0xe0670]        # 280690 <_DYNAMIC+0x2b8>
  1a0020:	48 8d 15 99 6f 0d 00 	lea    rdx,[rip+0xd6f99]        # 276fc0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa58>
  1a0027:	48 89 f7             	mov    rdi,rsi
  1a002a:	c5 f8 77             	vzeroupper
  1a002d:	ff 15 5d 06 0e 00    	call   QWORD PTR [rip+0xe065d]        # 280690 <_DYNAMIC+0x2b8>
  1a0033:	48 8d 15 9e 6f 0d 00 	lea    rdx,[rip+0xd6f9e]        # 276fd8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa70>
  1a003a:	48 89 fe             	mov    rsi,rdi
  1a003d:	c5 f8 77             	vzeroupper
  1a0040:	ff 15 4a 06 0e 00    	call   QWORD PTR [rip+0xe064a]        # 280690 <_DYNAMIC+0x2b8>
  1a0046:	48 8d 15 a3 6f 0d 00 	lea    rdx,[rip+0xd6fa3]        # 276ff0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa88>
  1a004d:	4c 89 c7             	mov    rdi,r8
  1a0050:	4c 89 c6             	mov    rsi,r8
  1a0053:	c5 f8 77             	vzeroupper
  1a0056:	ff 15 34 06 0e 00    	call   QWORD PTR [rip+0xe0634]        # 280690 <_DYNAMIC+0x2b8>
  1a005c:	48 8d 15 45 6f 0d 00 	lea    rdx,[rip+0xd6f45]        # 276fa8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa40>
  1a0063:	48 89 fe             	mov    rsi,rdi
  1a0066:	c5 f8 77             	vzeroupper
  1a0069:	ff 15 21 06 0e 00    	call   QWORD PTR [rip+0xe0621]        # 280690 <_DYNAMIC+0x2b8>
  1a006f:	48 8d 15 ea 6e 0d 00 	lea    rdx,[rip+0xd6eea]        # 276f60 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9f8>
  1a0076:	31 ff                	xor    edi,edi
  1a0078:	31 f6                	xor    esi,esi
  1a007a:	c5 f8 77             	vzeroupper
  1a007d:	ff 15 0d 06 0e 00    	call   QWORD PTR [rip+0xe060d]        # 280690 <_DYNAMIC+0x2b8>
  1a0083:	48 8d 15 ee 6e 0d 00 	lea    rdx,[rip+0xd6eee]        # 276f78 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa10>
  1a008a:	31 ff                	xor    edi,edi
  1a008c:	31 f6                	xor    esi,esi
  1a008e:	c5 f8 77             	vzeroupper
  1a0091:	ff 15 f9 05 0e 00    	call   QWORD PTR [rip+0xe05f9]        # 280690 <_DYNAMIC+0x2b8>
  1a0097:	48 8d 15 f2 6e 0d 00 	lea    rdx,[rip+0xd6ef2]        # 276f90 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa28>
  1a009e:	31 ff                	xor    edi,edi
  1a00a0:	31 f6                	xor    esi,esi
  1a00a2:	c5 f8 77             	vzeroupper
  1a00a5:	ff 15 e5 05 0e 00    	call   QWORD PTR [rip+0xe05e5]        # 280690 <_DYNAMIC+0x2b8>
  1a00ab:	48 8d 15 76 76 0d 00 	lea    rdx,[rip+0xd7676]        # 277728 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1a00b2:	4c 89 ef             	mov    rdi,r13
  1a00b5:	c5 f8 77             	vzeroupper
  1a00b8:	ff 15 d2 05 0e 00    	call   QWORD PTR [rip+0xe05d2]        # 280690 <_DYNAMIC+0x2b8>
