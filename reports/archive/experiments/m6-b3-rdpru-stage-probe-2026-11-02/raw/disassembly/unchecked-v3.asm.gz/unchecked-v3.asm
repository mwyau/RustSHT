
target-plain/release/examples/m6_b3_rdpru_probe:     file format elf64-x86-64


Disassembly of section .text:

00000000001a18c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>>:
  1a18c0:	55                   	push   rbp
  1a18c1:	41 57                	push   r15
  1a18c3:	41 56                	push   r14
  1a18c5:	41 55                	push   r13
  1a18c7:	41 54                	push   r12
  1a18c9:	53                   	push   rbx
  1a18ca:	48 81 ec 38 02 00 00 	sub    rsp,0x238
  1a18d1:	48 8b 87 a0 00 00 00 	mov    rax,QWORD PTR [rdi+0xa0]
  1a18d8:	48 3b 87 b0 00 00 00 	cmp    rax,QWORD PTR [rdi+0xb0]
  1a18df:	0f 85 69 28 00 00    	jne    1a414e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x288e>
  1a18e5:	4c 8b 67 10          	mov    r12,QWORD PTR [rdi+0x10]
  1a18e9:	48 8b 6f 20          	mov    rbp,QWORD PTR [rdi+0x20]
  1a18ed:	4c 8b 6f 50          	mov    r13,QWORD PTR [rdi+0x50]
  1a18f1:	4c 8b 57 60          	mov    r10,QWORD PTR [rdi+0x60]
  1a18f5:	4c 8b 5f 70          	mov    r11,QWORD PTR [rdi+0x70]
  1a18f9:	4c 8b bf 80 00 00 00 	mov    r15,QWORD PTR [rdi+0x80]
  1a1900:	48 8b 8f e0 00 00 00 	mov    rcx,QWORD PTR [rdi+0xe0]
  1a1907:	48 8b 9f e8 00 00 00 	mov    rbx,QWORD PTR [rdi+0xe8]
  1a190e:	48 8b 97 c0 00 00 00 	mov    rdx,QWORD PTR [rdi+0xc0]
  1a1915:	48 31 c2             	xor    rdx,rax
  1a1918:	4c 89 e6             	mov    rsi,r12
  1a191b:	48 31 c6             	xor    rsi,rax
  1a191e:	48 09 d6             	or     rsi,rdx
  1a1921:	48 89 ea             	mov    rdx,rbp
  1a1924:	48 31 c2             	xor    rdx,rax
  1a1927:	4d 89 e8             	mov    r8,r13
  1a192a:	49 31 c0             	xor    r8,rax
  1a192d:	49 09 d0             	or     r8,rdx
  1a1930:	49 09 f0             	or     r8,rsi
  1a1933:	4c 89 d2             	mov    rdx,r10
  1a1936:	48 31 c2             	xor    rdx,rax
  1a1939:	4c 89 de             	mov    rsi,r11
  1a193c:	48 31 c6             	xor    rsi,rax
  1a193f:	48 09 d6             	or     rsi,rdx
  1a1942:	4c 89 fa             	mov    rdx,r15
  1a1945:	48 31 c2             	xor    rdx,rax
  1a1948:	48 09 f2             	or     rdx,rsi
  1a194b:	4c 09 c2             	or     rdx,r8
  1a194e:	48 85 c9             	test   rcx,rcx
  1a1951:	40 0f 95 c6          	setne  sil
  1a1955:	48 31 d8             	xor    rax,rbx
  1a1958:	48 09 d0             	or     rax,rdx
  1a195b:	0f 94 c0             	sete   al
  1a195e:	40 84 f0             	test   al,sil
  1a1961:	0f 84 e7 27 00 00    	je     1a414e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x288e>
  1a1967:	48 39 9f f8 00 00 00 	cmp    QWORD PTR [rdi+0xf8],rbx
  1a196e:	0f 85 da 27 00 00    	jne    1a414e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x288e>
  1a1974:	48 39 9f 08 01 00 00 	cmp    QWORD PTR [rdi+0x108],rbx
  1a197b:	0f 85 cd 27 00 00    	jne    1a414e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x288e>
  1a1981:	48 39 9f 18 01 00 00 	cmp    QWORD PTR [rdi+0x118],rbx
  1a1988:	0f 85 c0 27 00 00    	jne    1a414e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x288e>
  1a198e:	48 8b 97 c8 00 00 00 	mov    rdx,QWORD PTR [rdi+0xc8]
  1a1995:	48 8b b7 d0 00 00 00 	mov    rsi,QWORD PTR [rdi+0xd0]
  1a199c:	49 89 f9             	mov    r9,rdi
  1a199f:	48 8b bf 28 01 00 00 	mov    rdi,QWORD PTR [rdi+0x128]
  1a19a6:	49 89 f6             	mov    r14,rsi
  1a19a9:	48 89 94 24 30 01 00 	mov    QWORD PTR [rsp+0x130],rdx
  1a19b0:	00 
  1a19b1:	49 29 d6             	sub    r14,rdx
  1a19b4:	49 8d 46 01          	lea    rax,[r14+0x1]
  1a19b8:	48 89 7c 24 18       	mov    QWORD PTR [rsp+0x18],rdi
  1a19bd:	48 39 c7             	cmp    rdi,rax
  1a19c0:	0f 82 88 27 00 00    	jb     1a414e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x288e>
  1a19c6:	48 89 74 24 68       	mov    QWORD PTR [rsp+0x68],rsi
  1a19cb:	48 89 ac 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rbp
  1a19d2:	00 
  1a19d3:	4c 89 a4 24 98 00 00 	mov    QWORD PTR [rsp+0x98],r12
  1a19da:	00 
  1a19db:	4c 89 7c 24 70       	mov    QWORD PTR [rsp+0x70],r15
  1a19e0:	4c 89 5c 24 78       	mov    QWORD PTR [rsp+0x78],r11
  1a19e5:	4c 89 54 24 50       	mov    QWORD PTR [rsp+0x50],r10
  1a19ea:	49 8b b9 d8 00 00 00 	mov    rdi,QWORD PTR [r9+0xd8]
  1a19f1:	49 8b 41 18          	mov    rax,QWORD PTR [r9+0x18]
  1a19f5:	48 89 84 24 d0 00 00 	mov    QWORD PTR [rsp+0xd0],rax
  1a19fc:	00 
  1a19fd:	49 8b 41 28          	mov    rax,QWORD PTR [r9+0x28]
  1a1a01:	48 89 84 24 e8 01 00 	mov    QWORD PTR [rsp+0x1e8],rax
  1a1a08:	00 
  1a1a09:	49 8b 41 30          	mov    rax,QWORD PTR [r9+0x30]
  1a1a0d:	48 89 84 24 d8 00 00 	mov    QWORD PTR [rsp+0xd8],rax
  1a1a14:	00 
  1a1a15:	49 8b 41 38          	mov    rax,QWORD PTR [r9+0x38]
  1a1a19:	48 89 84 24 e0 01 00 	mov    QWORD PTR [rsp+0x1e0],rax
  1a1a20:	00 
  1a1a21:	49 8b 41 40          	mov    rax,QWORD PTR [r9+0x40]
  1a1a25:	48 89 44 24 58       	mov    QWORD PTR [rsp+0x58],rax
  1a1a2a:	4d 8b 51 48          	mov    r10,QWORD PTR [r9+0x48]
  1a1a2e:	49 8b 41 58          	mov    rax,QWORD PTR [r9+0x58]
  1a1a32:	48 89 44 24 30       	mov    QWORD PTR [rsp+0x30],rax
  1a1a37:	4d 8b 79 68          	mov    r15,QWORD PTR [r9+0x68]
  1a1a3b:	49 83 c6 02          	add    r14,0x2
  1a1a3f:	4d 89 f0             	mov    r8,r14
  1a1a42:	49 d1 e8             	shr    r8,1
  1a1a45:	31 c0                	xor    eax,eax
  1a1a47:	4c 89 c2             	mov    rdx,r8
  1a1a4a:	48 83 ea 01          	sub    rdx,0x1
  1a1a4e:	48 0f 42 d0          	cmovb  rdx,rax
  1a1a52:	48 89 94 24 d8 01 00 	mov    QWORD PTR [rsp+0x1d8],rdx
  1a1a59:	00 
  1a1a5a:	49 8b 51 78          	mov    rdx,QWORD PTR [r9+0x78]
  1a1a5e:	48 89 54 24 20       	mov    QWORD PTR [rsp+0x20],rdx
  1a1a63:	49 83 e8 02          	sub    r8,0x2
  1a1a67:	4c 0f 42 c0          	cmovb  r8,rax
  1a1a6b:	49 8b 81 88 00 00 00 	mov    rax,QWORD PTR [r9+0x88]
  1a1a72:	48 89 84 24 c8 00 00 	mov    QWORD PTR [rsp+0xc8],rax
  1a1a79:	00 
  1a1a7a:	49 8b 81 90 00 00 00 	mov    rax,QWORD PTR [r9+0x90]
  1a1a81:	48 89 44 24 08       	mov    QWORD PTR [rsp+0x8],rax
  1a1a86:	49 8b 91 f0 00 00 00 	mov    rdx,QWORD PTR [r9+0xf0]
  1a1a8d:	49 8b a9 00 01 00 00 	mov    rbp,QWORD PTR [r9+0x100]
  1a1a94:	4d 8b a1 10 01 00 00 	mov    r12,QWORD PTR [r9+0x110]
  1a1a9b:	49 8b 81 20 01 00 00 	mov    rax,QWORD PTR [r9+0x120]
  1a1aa2:	48 89 84 24 00 01 00 	mov    QWORD PTR [rsp+0x100],rax
  1a1aa9:	00 
  1a1aaa:	49 8b 81 98 00 00 00 	mov    rax,QWORD PTR [r9+0x98]
  1a1ab1:	4d 8b 99 a8 00 00 00 	mov    r11,QWORD PTR [r9+0xa8]
  1a1ab8:	4d 8b 89 b8 00 00 00 	mov    r9,QWORD PTR [r9+0xb8]
  1a1abf:	4c 89 8c 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r9
  1a1ac6:	00 
  1a1ac7:	4c 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],r8
  1a1ace:	00 
  1a1acf:	4c 39 c7             	cmp    rdi,r8
  1a1ad2:	4c 89 a4 24 c0 00 00 	mov    QWORD PTR [rsp+0xc0],r12
  1a1ad9:	00 
  1a1ada:	4c 89 54 24 38       	mov    QWORD PTR [rsp+0x38],r10
  1a1adf:	4c 89 7c 24 60       	mov    QWORD PTR [rsp+0x60],r15
  1a1ae4:	4c 89 b4 24 00 02 00 	mov    QWORD PTR [rsp+0x200],r14
  1a1aeb:	00 
  1a1aec:	48 89 9c 24 08 01 00 	mov    QWORD PTR [rsp+0x108],rbx
  1a1af3:	00 
  1a1af4:	73 7d                	jae    1a1b73 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2b3>
  1a1af6:	4d 89 e8             	mov    r8,r13
  1a1af9:	49 c1 e8 02          	shr    r8,0x2
  1a1afd:	4c 8b 4c 24 50       	mov    r9,QWORD PTR [rsp+0x50]
  1a1b02:	49 c1 e9 02          	shr    r9,0x2
  1a1b06:	49 89 dc             	mov    r12,rbx
  1a1b09:	48 8b 5c 24 78       	mov    rbx,QWORD PTR [rsp+0x78]
  1a1b0e:	48 c1 eb 02          	shr    rbx,0x2
  1a1b12:	4c 8b 7c 24 70       	mov    r15,QWORD PTR [rsp+0x70]
  1a1b17:	49 c1 ef 02          	shr    r15,0x2
  1a1b1b:	49 c1 ec 02          	shr    r12,0x2
  1a1b1f:	4c 89 c6             	mov    rsi,r8
  1a1b22:	4c 31 ce             	xor    rsi,r9
  1a1b25:	4c 31 cb             	xor    rbx,r9
  1a1b28:	48 09 f3             	or     rbx,rsi
  1a1b2b:	4d 31 cf             	xor    r15,r9
  1a1b2e:	4d 39 e0             	cmp    r8,r12
  1a1b31:	4d 0f 42 e0          	cmovb  r12,r8
  1a1b35:	4c 89 a4 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],r12
  1a1b3c:	00 
  1a1b3d:	49 09 df             	or     r15,rbx
  1a1b40:	0f 84 ad 0d 00 00    	je     1a28f3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1033>
  1a1b46:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
  1a1b4d:	00 
  1a1b4e:	48 39 c7             	cmp    rdi,rax
  1a1b51:	0f 83 34 27 00 00    	jae    1a428b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x29cb>
  1a1b57:	48 3b 7c 24 58       	cmp    rdi,QWORD PTR [rsp+0x58]
  1a1b5c:	0f 83 44 27 00 00    	jae    1a42a6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x29e6>
  1a1b62:	48 ff c7             	inc    rdi
  1a1b65:	48 39 c7             	cmp    rdi,rax
  1a1b68:	0f 82 d5 25 00 00    	jb     1a4143 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2883>
  1a1b6e:	e9 fd 26 00 00       	jmp    1a4270 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x29b0>
  1a1b73:	4c 89 ac 24 28 01 00 	mov    QWORD PTR [rsp+0x128],r13
  1a1b7a:	00 
  1a1b7b:	c6 44 24 07 01       	mov    BYTE PTR [rsp+0x7],0x1
  1a1b80:	48 8b b4 24 98 00 00 	mov    rsi,QWORD PTR [rsp+0x98]
  1a1b87:	00 
  1a1b88:	48 89 74 24 10       	mov    QWORD PTR [rsp+0x10],rsi
  1a1b8d:	48 89 5c 24 28       	mov    QWORD PTR [rsp+0x28],rbx
  1a1b92:	48 89 5c 24 48       	mov    QWORD PTR [rsp+0x48],rbx
  1a1b97:	49 89 c5             	mov    r13,rax
  1a1b9a:	49 89 f8             	mov    r8,rdi
  1a1b9d:	4c 8b 94 24 90 00 00 	mov    r10,QWORD PTR [rsp+0x90]
  1a1ba4:	00 
  1a1ba5:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1a1ba9:	c5 fd c2 c0 00       	vcmpeqpd ymm0,ymm0,ymm0
  1a1bae:	48 bf fe ff ff ff ff 	movabs rdi,0x3fffffffffffffe
  1a1bb5:	ff ff 03 
  1a1bb8:	4c 3b 84 24 d8 01 00 	cmp    r8,QWORD PTR [rsp+0x1d8]
  1a1bbf:	00 
  1a1bc0:	0f 83 76 0b 00 00    	jae    1a273c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0xe7c>
  1a1bc6:	49 89 df             	mov    r15,rbx
  1a1bc9:	49 c1 ef 02          	shr    r15,0x2
  1a1bcd:	89 d8                	mov    eax,ebx
  1a1bcf:	83 e0 03             	and    eax,0x3
  1a1bd2:	48 89 84 24 c8 01 00 	mov    QWORD PTR [rsp+0x1c8],rax
  1a1bd9:	00 
  1a1bda:	48 89 de             	mov    rsi,rbx
  1a1bdd:	49 be fc ff ff ff ff 	movabs r14,0xffffffffffffffc
  1a1be4:	ff ff 0f 
  1a1be7:	4c 21 f6             	and    rsi,r14
  1a1bea:	48 89 b4 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],rsi
  1a1bf1:	00 
  1a1bf2:	48 8b b4 24 98 00 00 	mov    rsi,QWORD PTR [rsp+0x98]
  1a1bf9:	00 
  1a1bfa:	49 89 f1             	mov    r9,rsi
  1a1bfd:	49 c1 e9 02          	shr    r9,0x2
  1a1c01:	4c 89 8c 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],r9
  1a1c08:	00 
  1a1c09:	49 21 ff             	and    r15,rdi
  1a1c0c:	49 c1 e7 05          	shl    r15,0x5
  1a1c10:	4a 8d 04 39          	lea    rax,[rcx+r15*1]
  1a1c14:	48 89 84 24 18 02 00 	mov    QWORD PTR [rsp+0x218],rax
  1a1c1b:	00 
  1a1c1c:	48 c1 eb 03          	shr    rbx,0x3
  1a1c20:	48 89 9c 24 f0 01 00 	mov    QWORD PTR [rsp+0x1f0],rbx
  1a1c27:	00 
  1a1c28:	4a 8d 04 3a          	lea    rax,[rdx+r15*1]
  1a1c2c:	48 89 84 24 10 02 00 	mov    QWORD PTR [rsp+0x210],rax
  1a1c33:	00 
  1a1c34:	49 8d 04 2f          	lea    rax,[r15+rbp*1]
  1a1c38:	48 89 84 24 08 02 00 	mov    QWORD PTR [rsp+0x208],rax
  1a1c3f:	00 
  1a1c40:	4d 01 e7             	add    r15,r12
  1a1c43:	4c 89 bc 24 20 02 00 	mov    QWORD PTR [rsp+0x220],r15
  1a1c4a:	00 
  1a1c4b:	48 89 f7             	mov    rdi,rsi
  1a1c4e:	48 c1 ef 03          	shr    rdi,0x3
  1a1c52:	48 89 bc 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rdi
  1a1c59:	00 
  1a1c5a:	4c 8b bc 24 28 01 00 	mov    r15,QWORD PTR [rsp+0x128]
  1a1c61:	00 
  1a1c62:	4c 89 f8             	mov    rax,r15
  1a1c65:	48 c1 e8 02          	shr    rax,0x2
  1a1c69:	48 89 84 24 78 01 00 	mov    QWORD PTR [rsp+0x178],rax
  1a1c70:	00 
  1a1c71:	44 89 f8             	mov    eax,r15d
  1a1c74:	83 e0 03             	and    eax,0x3
  1a1c77:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
  1a1c7e:	00 
  1a1c7f:	4d 21 f7             	and    r15,r14
  1a1c82:	4c 89 bc 24 50 01 00 	mov    QWORD PTR [rsp+0x150],r15
  1a1c89:	00 
  1a1c8a:	48 8b 7c 24 50       	mov    rdi,QWORD PTR [rsp+0x50]
  1a1c8f:	48 89 fb             	mov    rbx,rdi
  1a1c92:	48 c1 eb 02          	shr    rbx,0x2
  1a1c96:	89 f8                	mov    eax,edi
  1a1c98:	83 e0 03             	and    eax,0x3
  1a1c9b:	48 89 84 24 88 01 00 	mov    QWORD PTR [rsp+0x188],rax
  1a1ca2:	00 
  1a1ca3:	4c 21 f7             	and    rdi,r14
  1a1ca6:	48 89 bc 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rdi
  1a1cad:	00 
  1a1cae:	48 8b 7c 24 78       	mov    rdi,QWORD PTR [rsp+0x78]
  1a1cb3:	48 89 fe             	mov    rsi,rdi
  1a1cb6:	48 c1 ee 02          	shr    rsi,0x2
  1a1cba:	89 f8                	mov    eax,edi
  1a1cbc:	83 e0 03             	and    eax,0x3
  1a1cbf:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
  1a1cc6:	00 
  1a1cc7:	4c 21 f7             	and    rdi,r14
  1a1cca:	48 89 bc 24 80 00 00 	mov    QWORD PTR [rsp+0x80],rdi
  1a1cd1:	00 
  1a1cd2:	48 8b 7c 24 70       	mov    rdi,QWORD PTR [rsp+0x70]
  1a1cd7:	48 89 f8             	mov    rax,rdi
  1a1cda:	48 c1 e8 02          	shr    rax,0x2
  1a1cde:	41 89 f9             	mov    r9d,edi
  1a1ce1:	41 83 e1 03          	and    r9d,0x3
  1a1ce5:	4c 21 f7             	and    rdi,r14
  1a1ce8:	48 89 bc 24 30 02 00 	mov    QWORD PTR [rsp+0x230],rdi
  1a1cef:	00 
  1a1cf0:	48 8b bc 24 18 01 00 	mov    rdi,QWORD PTR [rsp+0x118]
  1a1cf7:	00 
  1a1cf8:	49 89 fe             	mov    r14,rdi
  1a1cfb:	49 bf fc ff ff ff ff 	movabs r15,0xffffffffffffffc
  1a1d02:	ff ff 0f 
  1a1d05:	4d 21 fe             	and    r14,r15
  1a1d08:	4c 89 b4 24 28 02 00 	mov    QWORD PTR [rsp+0x228],r14
  1a1d0f:	00 
  1a1d10:	4c 8b b4 24 d8 00 00 	mov    r14,QWORD PTR [rsp+0xd8]
  1a1d17:	00 
  1a1d18:	4d 39 f0             	cmp    r8,r14
  1a1d1b:	4d 0f 47 f0          	cmova  r14,r8
  1a1d1f:	4c 89 b4 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],r14
  1a1d26:	00 
  1a1d27:	4c 8b 74 24 58       	mov    r14,QWORD PTR [rsp+0x58]
  1a1d2c:	4d 39 f0             	cmp    r8,r14
  1a1d2f:	4d 0f 47 f0          	cmova  r14,r8
  1a1d33:	4c 89 b4 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],r14
  1a1d3a:	00 
  1a1d3b:	4c 8b b4 24 78 01 00 	mov    r14,QWORD PTR [rsp+0x178]
  1a1d42:	00 
  1a1d43:	4c 39 f3             	cmp    rbx,r14
  1a1d46:	48 89 9c 24 b8 01 00 	mov    QWORD PTR [rsp+0x1b8],rbx
  1a1d4d:	00 
  1a1d4e:	4c 0f 42 f3          	cmovb  r14,rbx
  1a1d52:	4c 39 f6             	cmp    rsi,r14
  1a1d55:	48 89 b4 24 b0 01 00 	mov    QWORD PTR [rsp+0x1b0],rsi
  1a1d5c:	00 
  1a1d5d:	4c 0f 42 f6          	cmovb  r14,rsi
  1a1d61:	4c 39 f0             	cmp    rax,r14
  1a1d64:	48 89 84 24 a8 01 00 	mov    QWORD PTR [rsp+0x1a8],rax
  1a1d6b:	00 
  1a1d6c:	4c 0f 42 f0          	cmovb  r14,rax
  1a1d70:	4c 89 b4 24 a0 01 00 	mov    QWORD PTR [rsp+0x1a0],r14
  1a1d77:	00 
  1a1d78:	48 89 f8             	mov    rax,rdi
  1a1d7b:	48 c1 e8 02          	shr    rax,0x2
  1a1d7f:	48 89 84 24 20 01 00 	mov    QWORD PTR [rsp+0x120],rax
  1a1d86:	00 
  1a1d87:	48 8b 84 24 90 01 00 	mov    rax,QWORD PTR [rsp+0x190]
  1a1d8e:	00 
  1a1d8f:	48 8b b4 24 88 01 00 	mov    rsi,QWORD PTR [rsp+0x188]
  1a1d96:	00 
  1a1d97:	48 39 c6             	cmp    rsi,rax
  1a1d9a:	48 0f 42 c6          	cmovb  rax,rsi
  1a1d9e:	48 8b b4 24 80 01 00 	mov    rsi,QWORD PTR [rsp+0x180]
  1a1da5:	00 
  1a1da6:	48 39 c6             	cmp    rsi,rax
  1a1da9:	48 0f 42 c6          	cmovb  rax,rsi
  1a1dad:	49 39 c1             	cmp    r9,rax
  1a1db0:	4c 89 8c 24 c0 01 00 	mov    QWORD PTR [rsp+0x1c0],r9
  1a1db7:	00 
  1a1db8:	49 0f 42 c1          	cmovb  rax,r9
  1a1dbc:	48 89 84 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rax
  1a1dc3:	00 
  1a1dc4:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
  1a1dcb:	00 
  1a1dcc:	83 e0 03             	and    eax,0x3
  1a1dcf:	48 89 84 24 98 01 00 	mov    QWORD PTR [rsp+0x198],rax
  1a1dd6:	00 
  1a1dd7:	83 e7 03             	and    edi,0x3
  1a1dda:	48 89 bc 24 18 01 00 	mov    QWORD PTR [rsp+0x118],rdi
  1a1de1:	00 
  1a1de2:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
  1a1de6:	c4 e2 7d 19 1d 09 f2 	vbroadcastsd ymm3,QWORD PTR [rip+0xffffffffffe7f209]        # 20ff8 <anon.18cb9c1b3fe794d0b89f358a70182f4e.25.llvm.5582884991536083740+0x388>
  1a1ded:	e7 ff 
  1a1def:	c5 fd 28 c8          	vmovapd ymm1,ymm0
  1a1df3:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
  1a1df8:	48 89 ac 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],rbp
  1a1dff:	00 
  1a1e00:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
  1a1e05:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
  1a1e0a:	48 89 8c 24 10 01 00 	mov    QWORD PTR [rsp+0x110],rcx
  1a1e11:	00 
  1a1e12:	48 89 94 24 d0 01 00 	mov    QWORD PTR [rsp+0x1d0],rdx
  1a1e19:	00 
  1a1e1a:	eb 26                	jmp    1a1e42 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x582>
  1a1e1c:	c5 dd 54 c9          	vandpd ymm1,ymm4,ymm1
  1a1e20:	49 ff c0             	inc    r8
  1a1e23:	4d 89 dd             	mov    r13,r11
  1a1e26:	48 89 f0             	mov    rax,rsi
  1a1e29:	49 89 db             	mov    r11,rbx
  1a1e2c:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
  1a1e31:	48 89 fe             	mov    rsi,rdi
  1a1e34:	4c 3b 84 24 d8 01 00 	cmp    r8,QWORD PTR [rsp+0x1d8]
  1a1e3b:	00 
  1a1e3c:	0f 83 d5 09 00 00    	jae    1a2817 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0xf57>
  1a1e42:	4c 89 74 24 48       	mov    QWORD PTR [rsp+0x48],r14
  1a1e47:	4c 89 d3             	mov    rbx,r10
  1a1e4a:	49 89 c2             	mov    r10,rax
  1a1e4d:	48 89 f7             	mov    rdi,rsi
  1a1e50:	48 c1 ef 03          	shr    rdi,0x3
  1a1e54:	48 8b 84 24 f0 01 00 	mov    rax,QWORD PTR [rsp+0x1f0]
  1a1e5b:	00 
  1a1e5c:	48 39 c7             	cmp    rdi,rax
  1a1e5f:	48 0f 43 f8          	cmovae rdi,rax
  1a1e63:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
  1a1e6a:	00 
  1a1e6b:	48 39 f8             	cmp    rax,rdi
  1a1e6e:	48 0f 42 f8          	cmovb  rdi,rax
  1a1e72:	c4 41 21 57 db       	vxorpd xmm11,xmm11,xmm11
  1a1e77:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  1a1e7b:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  1a1e80:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  1a1e85:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  1a1e8a:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  1a1e8e:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  1a1e92:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  1a1e96:	48 85 ff             	test   rdi,rdi
  1a1e99:	0f 84 16 01 00 00    	je     1a1fb5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x6f5>
  1a1e9f:	48 83 ff 01          	cmp    rdi,0x1
  1a1ea3:	75 07                	jne    1a1eac <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x5ec>
  1a1ea5:	31 c0                	xor    eax,eax
  1a1ea7:	e9 c3 00 00 00       	jmp    1a1f6f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x6af>
  1a1eac:	49 89 f9             	mov    r9,rdi
  1a1eaf:	48 b8 fe ff ff ff ff 	movabs rax,0x1ffffffffffffffe
  1a1eb6:	ff ff 1f 
  1a1eb9:	49 21 c1             	and    r9,rax
  1a1ebc:	41 bf 60 00 00 00    	mov    r15d,0x60
  1a1ec2:	31 c0                	xor    eax,eax
  1a1ec4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
  1a1ecb:	00 00 00 00 00 
  1a1ed0:	c4 01 7d 10 64 3b a0 	vmovupd ymm12,YMMWORD PTR [r11+r15*1-0x60]
  1a1ed7:	c4 01 7d 10 6c 3b c0 	vmovupd ymm13,YMMWORD PTR [r11+r15*1-0x40]
  1a1ede:	c4 01 7d 10 74 3b e0 	vmovupd ymm14,YMMWORD PTR [r11+r15*1-0x20]
  1a1ee5:	c4 a2 9d b8 7c 39 a0 	vfmadd231pd ymm7,ymm12,YMMWORD PTR [rcx+r15*1-0x60]
  1a1eec:	c4 22 9d b8 44 3a a0 	vfmadd231pd ymm8,ymm12,YMMWORD PTR [rdx+r15*1-0x60]
  1a1ef3:	c4 22 9d b8 4c 3d a0 	vfmadd231pd ymm9,ymm12,YMMWORD PTR [rbp+r15*1-0x60]
  1a1efa:	c4 02 9d b8 54 3c a0 	vfmadd231pd ymm10,ymm12,YMMWORD PTR [r12+r15*1-0x60]
  1a1f01:	c4 a2 95 b8 6c 39 c0 	vfmadd231pd ymm5,ymm13,YMMWORD PTR [rcx+r15*1-0x40]
  1a1f08:	c4 a2 95 b8 74 3a c0 	vfmadd231pd ymm6,ymm13,YMMWORD PTR [rdx+r15*1-0x40]
  1a1f0f:	c4 a2 95 b8 64 3d c0 	vfmadd231pd ymm4,ymm13,YMMWORD PTR [rbp+r15*1-0x40]
  1a1f16:	c4 02 95 b8 5c 3c c0 	vfmadd231pd ymm11,ymm13,YMMWORD PTR [r12+r15*1-0x40]
  1a1f1d:	c4 01 7d 10 24 3b    	vmovupd ymm12,YMMWORD PTR [r11+r15*1]
  1a1f23:	48 83 c0 02          	add    rax,0x2
  1a1f27:	c4 a2 8d b8 7c 39 e0 	vfmadd231pd ymm7,ymm14,YMMWORD PTR [rcx+r15*1-0x20]
  1a1f2e:	c4 22 8d b8 44 3a e0 	vfmadd231pd ymm8,ymm14,YMMWORD PTR [rdx+r15*1-0x20]
  1a1f35:	c4 22 8d b8 4c 3d e0 	vfmadd231pd ymm9,ymm14,YMMWORD PTR [rbp+r15*1-0x20]
  1a1f3c:	c4 02 8d b8 54 3c e0 	vfmadd231pd ymm10,ymm14,YMMWORD PTR [r12+r15*1-0x20]
  1a1f43:	c4 a2 9d b8 2c 39    	vfmadd231pd ymm5,ymm12,YMMWORD PTR [rcx+r15*1]
  1a1f49:	c4 a2 9d b8 34 3a    	vfmadd231pd ymm6,ymm12,YMMWORD PTR [rdx+r15*1]
  1a1f4f:	c4 a2 9d b8 64 3d 00 	vfmadd231pd ymm4,ymm12,YMMWORD PTR [rbp+r15*1+0x0]
  1a1f56:	c4 02 9d b8 1c 3c    	vfmadd231pd ymm11,ymm12,YMMWORD PTR [r12+r15*1]
  1a1f5c:	49 83 ef 80          	sub    r15,0xffffffffffffff80
  1a1f60:	49 39 c1             	cmp    r9,rax
  1a1f63:	0f 85 67 ff ff ff    	jne    1a1ed0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x610>
  1a1f69:	40 f6 c7 01          	test   dil,0x1
  1a1f6d:	74 46                	je     1a1fb5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x6f5>
  1a1f6f:	48 c1 e0 06          	shl    rax,0x6
  1a1f73:	c4 41 7d 10 24 03    	vmovupd ymm12,YMMWORD PTR [r11+rax*1]
  1a1f79:	c4 41 7d 10 6c 03 20 	vmovupd ymm13,YMMWORD PTR [r11+rax*1+0x20]
  1a1f80:	c4 e2 9d b8 3c 01    	vfmadd231pd ymm7,ymm12,YMMWORD PTR [rcx+rax*1]
  1a1f86:	c4 62 9d b8 04 02    	vfmadd231pd ymm8,ymm12,YMMWORD PTR [rdx+rax*1]
  1a1f8c:	c4 62 9d b8 4c 05 00 	vfmadd231pd ymm9,ymm12,YMMWORD PTR [rbp+rax*1+0x0]
  1a1f93:	c4 42 9d b8 14 04    	vfmadd231pd ymm10,ymm12,YMMWORD PTR [r12+rax*1]
  1a1f99:	c4 e2 95 b8 6c 01 20 	vfmadd231pd ymm5,ymm13,YMMWORD PTR [rcx+rax*1+0x20]
  1a1fa0:	c4 e2 95 b8 74 02 20 	vfmadd231pd ymm6,ymm13,YMMWORD PTR [rdx+rax*1+0x20]
  1a1fa7:	c4 e2 95 b8 64 05 20 	vfmadd231pd ymm4,ymm13,YMMWORD PTR [rbp+rax*1+0x20]
  1a1fae:	c4 42 95 b8 5c 04 20 	vfmadd231pd ymm11,ymm13,YMMWORD PTR [r12+rax*1+0x20]
  1a1fb5:	49 89 f4             	mov    r12,rsi
  1a1fb8:	49 c1 ec 02          	shr    r12,0x2
  1a1fbc:	40 f6 c6 04          	test   sil,0x4
  1a1fc0:	74 6b                	je     1a202d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x76d>
  1a1fc2:	f6 84 24 98 00 00 00 	test   BYTE PTR [rsp+0x98],0x4
  1a1fc9:	04 
  1a1fca:	0f 84 35 22 00 00    	je     1a4205 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2945>
  1a1fd0:	f6 84 24 08 01 00 00 	test   BYTE PTR [rsp+0x108],0x4
  1a1fd7:	04 
  1a1fd8:	0f 84 3b 22 00 00    	je     1a4219 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2959>
  1a1fde:	4c 89 e0             	mov    rax,r12
  1a1fe1:	48 bf fe ff ff ff ff 	movabs rdi,0x3fffffffffffffe
  1a1fe8:	ff ff 03 
  1a1feb:	48 21 f8             	and    rax,rdi
  1a1fee:	48 c1 e0 05          	shl    rax,0x5
  1a1ff2:	4c 01 d8             	add    rax,r11
  1a1ff5:	c5 7d 10 20          	vmovupd ymm12,YMMWORD PTR [rax]
  1a1ff9:	48 8b 84 24 18 02 00 	mov    rax,QWORD PTR [rsp+0x218]
  1a2000:	00 
  1a2001:	c4 e2 9d b8 38       	vfmadd231pd ymm7,ymm12,YMMWORD PTR [rax]
  1a2006:	48 8b 84 24 10 02 00 	mov    rax,QWORD PTR [rsp+0x210]
  1a200d:	00 
  1a200e:	c4 62 9d b8 00       	vfmadd231pd ymm8,ymm12,YMMWORD PTR [rax]
  1a2013:	48 8b 84 24 08 02 00 	mov    rax,QWORD PTR [rsp+0x208]
  1a201a:	00 
  1a201b:	c4 62 9d b8 08       	vfmadd231pd ymm9,ymm12,YMMWORD PTR [rax]
  1a2020:	48 8b 84 24 20 02 00 	mov    rax,QWORD PTR [rsp+0x220]
  1a2027:	00 
  1a2028:	c4 62 9d b8 10       	vfmadd231pd ymm10,ymm12,YMMWORD PTR [rax]
  1a202d:	48 8b bc 24 f8 00 00 	mov    rdi,QWORD PTR [rsp+0xf8]
  1a2034:	00 
  1a2035:	c4 41 25 58 d2       	vaddpd ymm10,ymm11,ymm10
  1a203a:	c5 b5 58 e4          	vaddpd ymm4,ymm9,ymm4
  1a203e:	c5 bd 58 f6          	vaddpd ymm6,ymm8,ymm6
  1a2042:	c5 d5 58 ef          	vaddpd ymm5,ymm5,ymm7
  1a2046:	41 89 f1             	mov    r9d,esi
  1a2049:	41 83 e1 03          	and    r9d,0x3
  1a204d:	49 89 f6             	mov    r14,rsi
  1a2050:	48 b8 fc ff ff ff ff 	movabs rax,0xffffffffffffffc
  1a2057:	ff ff 0f 
  1a205a:	49 21 c6             	and    r14,rax
  1a205d:	c4 e3 7d 19 ef 01    	vextractf128 xmm7,ymm5,0x1
  1a2063:	c5 d1 58 ef          	vaddpd xmm5,xmm5,xmm7
  1a2067:	c5 d1 c6 fd 01       	vshufpd xmm7,xmm5,xmm5,0x1
  1a206c:	c5 d3 58 ef          	vaddsd xmm5,xmm5,xmm7
  1a2070:	c4 e3 7d 19 f7 01    	vextractf128 xmm7,ymm6,0x1
  1a2076:	c5 c9 58 f7          	vaddpd xmm6,xmm6,xmm7
  1a207a:	c5 c9 c6 fe 01       	vshufpd xmm7,xmm6,xmm6,0x1
  1a207f:	c5 cb 58 ff          	vaddsd xmm7,xmm6,xmm7
  1a2083:	c4 e3 7d 19 e6 01    	vextractf128 xmm6,ymm4,0x1
  1a2089:	c5 d9 58 e6          	vaddpd xmm4,xmm4,xmm6
  1a208d:	c5 d9 c6 f4 01       	vshufpd xmm6,xmm4,xmm4,0x1
  1a2092:	c5 db 58 e6          	vaddsd xmm4,xmm4,xmm6
  1a2096:	c4 63 7d 19 d6 01    	vextractf128 xmm6,ymm10,0x1
  1a209c:	c5 a9 58 f6          	vaddpd xmm6,xmm10,xmm6
  1a20a0:	c5 49 c6 c6 01       	vshufpd xmm8,xmm6,xmm6,0x1
  1a20a5:	c5 bb 58 f6          	vaddsd xmm6,xmm8,xmm6
  1a20a9:	4d 85 c9             	test   r9,r9
  1a20ac:	0f 84 8a 00 00 00    	je     1a213c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x87c>
  1a20b2:	41 8d 41 ff          	lea    eax,[r9-0x1]
  1a20b6:	39 84 24 c8 01 00 00 	cmp    DWORD PTR [rsp+0x1c8],eax
  1a20bd:	0f 86 27 21 00 00    	jbe    1a41ea <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x292a>
  1a20c3:	c4 01 7b 10 04 f3    	vmovsd xmm8,QWORD PTR [r11+r14*8]
  1a20c9:	c4 e2 b9 b9 2c f9    	vfmadd231sd xmm5,xmm8,QWORD PTR [rcx+rdi*8]
  1a20cf:	c4 e2 b9 b9 3c fa    	vfmadd231sd xmm7,xmm8,QWORD PTR [rdx+rdi*8]
  1a20d5:	c4 e2 b9 b9 64 fd 00 	vfmadd231sd xmm4,xmm8,QWORD PTR [rbp+rdi*8+0x0]
  1a20dc:	48 8b 84 24 c0 00 00 	mov    rax,QWORD PTR [rsp+0xc0]
  1a20e3:	00 
  1a20e4:	c4 e2 b9 b9 34 f8    	vfmadd231sd xmm6,xmm8,QWORD PTR [rax+rdi*8]
  1a20ea:	41 83 f9 01          	cmp    r9d,0x1
  1a20ee:	74 4c                	je     1a213c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x87c>
  1a20f0:	c4 01 7b 10 44 f3 08 	vmovsd xmm8,QWORD PTR [r11+r14*8+0x8]
  1a20f7:	c4 e2 b9 b9 6c f9 08 	vfmadd231sd xmm5,xmm8,QWORD PTR [rcx+rdi*8+0x8]
  1a20fe:	c4 e2 b9 b9 7c fa 08 	vfmadd231sd xmm7,xmm8,QWORD PTR [rdx+rdi*8+0x8]
  1a2105:	c4 e2 b9 b9 64 fd 08 	vfmadd231sd xmm4,xmm8,QWORD PTR [rbp+rdi*8+0x8]
  1a210c:	c4 e2 b9 b9 74 f8 08 	vfmadd231sd xmm6,xmm8,QWORD PTR [rax+rdi*8+0x8]
  1a2113:	41 83 f9 02          	cmp    r9d,0x2
  1a2117:	74 23                	je     1a213c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x87c>
  1a2119:	c4 01 7b 10 44 f3 10 	vmovsd xmm8,QWORD PTR [r11+r14*8+0x10]
  1a2120:	c4 e2 b9 b9 6c f9 10 	vfmadd231sd xmm5,xmm8,QWORD PTR [rcx+rdi*8+0x10]
  1a2127:	c4 e2 b9 b9 7c fa 10 	vfmadd231sd xmm7,xmm8,QWORD PTR [rdx+rdi*8+0x10]
  1a212e:	c4 e2 b9 b9 64 fd 10 	vfmadd231sd xmm4,xmm8,QWORD PTR [rbp+rdi*8+0x10]
  1a2135:	c4 e2 b9 b9 74 f8 10 	vfmadd231sd xmm6,xmm8,QWORD PTR [rax+rdi*8+0x10]
  1a213c:	4c 89 ed             	mov    rbp,r13
  1a213f:	48 89 74 24 28       	mov    QWORD PTR [rsp+0x28],rsi
  1a2144:	4f 8d 2c 00          	lea    r13,[r8+r8*1]
  1a2148:	4c 3b 6c 24 18       	cmp    r13,QWORD PTR [rsp+0x18]
  1a214d:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
  1a2152:	0f 83 7a 20 00 00    	jae    1a41d2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2912>
  1a2158:	4c 89 f1             	mov    rcx,r14
  1a215b:	4d 89 ef             	mov    r15,r13
  1a215e:	49 c1 e7 04          	shl    r15,0x4
  1a2162:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
  1a2169:	00 
  1a216a:	c4 a1 7b 11 2c 3e    	vmovsd QWORD PTR [rsi+r15*1],xmm5
  1a2170:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
  1a2177:	00 
  1a2178:	4a 8d 04 40          	lea    rax,[rax+r8*2]
  1a217c:	c4 a1 7b 11 7c 3e 08 	vmovsd QWORD PTR [rsi+r15*1+0x8],xmm7
  1a2183:	48 89 84 24 38 01 00 	mov    QWORD PTR [rsp+0x138],rax
  1a218a:	00 
  1a218b:	48 3b 44 24 68       	cmp    rax,QWORD PTR [rsp+0x68]
  1a2190:	73 26                	jae    1a21b8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x8f8>
  1a2192:	49 8d 45 01          	lea    rax,[r13+0x1]
  1a2196:	48 3b 44 24 18       	cmp    rax,QWORD PTR [rsp+0x18]
  1a219b:	0f 83 a2 20 00 00    	jae    1a4243 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2983>
  1a21a1:	48 c1 e0 04          	shl    rax,0x4
  1a21a5:	48 8b b4 24 00 01 00 	mov    rsi,QWORD PTR [rsp+0x100]
  1a21ac:	00 
  1a21ad:	c5 fb 11 24 06       	vmovsd QWORD PTR [rsi+rax*1],xmm4
  1a21b2:	c5 fb 11 74 06 08    	vmovsd QWORD PTR [rsi+rax*1+0x8],xmm6
  1a21b8:	4c 3b 84 24 f0 00 00 	cmp    r8,QWORD PTR [rsp+0xf0]
  1a21bf:	00 
  1a21c0:	0f 84 b9 1f 00 00    	je     1a417f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x28bf>
  1a21c6:	4c 3b 84 24 e8 00 00 	cmp    r8,QWORD PTR [rsp+0xe8]
  1a21cd:	00 
  1a21ce:	0f 84 cb 1f 00 00    	je     1a419f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x28df>
  1a21d4:	48 c1 ef 02          	shr    rdi,0x2
  1a21d8:	4c 89 54 24 10       	mov    QWORD PTR [rsp+0x10],r10
  1a21dd:	4c 89 d0             	mov    rax,r10
  1a21e0:	48 c1 e8 02          	shr    rax,0x2
  1a21e4:	48 8b 94 24 a0 01 00 	mov    rdx,QWORD PTR [rsp+0x1a0]
  1a21eb:	00 
  1a21ec:	48 39 d0             	cmp    rax,rdx
  1a21ef:	48 0f 43 c2          	cmovae rax,rdx
  1a21f3:	49 39 c4             	cmp    r12,rax
  1a21f6:	49 0f 42 c4          	cmovb  rax,r12
  1a21fa:	48 8b b4 24 e8 01 00 	mov    rsi,QWORD PTR [rsp+0x1e8]
  1a2201:	00 
  1a2202:	c4 a2 7d 19 34 c6    	vbroadcastsd ymm6,QWORD PTR [rsi+r8*8]
  1a2208:	48 8b 94 24 b0 00 00 	mov    rdx,QWORD PTR [rsp+0xb0]
  1a220f:	00 
  1a2210:	48 39 c2             	cmp    rdx,rax
  1a2213:	48 0f 42 c2          	cmovb  rax,rdx
  1a2217:	48 8b b4 24 e0 01 00 	mov    rsi,QWORD PTR [rsp+0x1e0]
  1a221e:	00 
  1a221f:	4c 89 44 24 40       	mov    QWORD PTR [rsp+0x40],r8
  1a2224:	c4 a2 7d 19 2c c6    	vbroadcastsd ymm5,QWORD PTR [rsi+r8*8]
  1a222a:	48 8b 94 24 20 01 00 	mov    rdx,QWORD PTR [rsp+0x120]
  1a2231:	00 
  1a2232:	48 39 c2             	cmp    rdx,rax
  1a2235:	48 0f 42 c2          	cmovb  rax,rdx
  1a2239:	48 39 c7             	cmp    rdi,rax
  1a223c:	48 89 bc 24 60 01 00 	mov    QWORD PTR [rsp+0x160],rdi
  1a2243:	00 
  1a2244:	48 0f 42 c7          	cmovb  rax,rdi
  1a2248:	48 85 c0             	test   rax,rax
  1a224b:	0f 84 a0 00 00 00    	je     1a22f1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0xa31>
  1a2251:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  1a2256:	45 31 e4             	xor    r12d,r12d
  1a2259:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  1a225e:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  1a2262:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  1a2267:	c5 fd 28 e0          	vmovapd ymm4,ymm0
  1a226b:	48 8b 7c 24 38       	mov    rdi,QWORD PTR [rsp+0x38]
  1a2270:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
  1a2275:	4c 8b 54 24 60       	mov    r10,QWORD PTR [rsp+0x60]
  1a227a:	4c 8b 44 24 20       	mov    r8,QWORD PTR [rsp+0x20]
  1a227f:	4c 8b b4 24 d0 00 00 	mov    r14,QWORD PTR [rsp+0xd0]
  1a2286:	00 
  1a2287:	48 89 ea             	mov    rdx,rbp
  1a228a:	66 0f 1f 44 00 00    	nop    WORD PTR [rax+rax*1+0x0]
  1a2290:	c4 01 7d 10 1c 23    	vmovupd ymm11,YMMWORD PTR [r11+r12*1]
  1a2296:	c4 22 a5 b8 04 27    	vfmadd231pd ymm8,ymm11,YMMWORD PTR [rdi+r12*1]
  1a229c:	c4 22 a5 b8 0c 26    	vfmadd231pd ymm9,ymm11,YMMWORD PTR [rsi+r12*1]
  1a22a2:	c4 82 a5 b8 3c 22    	vfmadd231pd ymm7,ymm11,YMMWORD PTR [r10+r12*1]
  1a22a8:	c4 02 a5 b8 14 20    	vfmadd231pd ymm10,ymm11,YMMWORD PTR [r8+r12*1]
  1a22ae:	c4 01 7d 10 24 26    	vmovupd ymm12,YMMWORD PTR [r14+r12*1]
  1a22b4:	c4 62 cd a8 e5       	vfmadd213pd ymm12,ymm6,ymm5
  1a22b9:	c4 22 a5 a8 24 22    	vfmadd213pd ymm12,ymm11,YMMWORD PTR [rdx+r12*1]
  1a22bf:	c4 21 7d 11 24 23    	vmovupd YMMWORD PTR [rbx+r12*1],ymm12
  1a22c5:	c4 62 7d 19 1d 42 ee 	vbroadcastsd ymm11,QWORD PTR [rip+0xffffffffffe7ee42]        # 21110 <anon.18cb9c1b3fe794d0b89f358a70182f4e.25.llvm.5582884991536083740+0x4a0>
  1a22cc:	e7 ff 
  1a22ce:	c4 41 1d 54 db       	vandpd ymm11,ymm12,ymm11
  1a22d3:	c5 25 c2 e2 00       	vcmpeqpd ymm12,ymm11,ymm2
  1a22d8:	c5 25 c2 db 1d       	vcmpge_oqpd ymm11,ymm11,ymm3
  1a22dd:	c4 41 25 56 dc       	vorpd  ymm11,ymm11,ymm12
  1a22e2:	c5 a5 54 e4          	vandpd ymm4,ymm11,ymm4
  1a22e6:	49 83 c4 20          	add    r12,0x20
  1a22ea:	48 ff c8             	dec    rax
  1a22ed:	75 a1                	jne    1a2290 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x9d0>
  1a22ef:	eb 17                	jmp    1a2308 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0xa48>
  1a22f1:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  1a22f6:	c5 fd 28 e0          	vmovapd ymm4,ymm0
  1a22fa:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  1a22fe:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  1a2303:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  1a2308:	4c 8b 54 24 48       	mov    r10,QWORD PTR [rsp+0x48]
  1a230d:	44 89 d2             	mov    edx,r10d
  1a2310:	83 e2 03             	and    edx,0x3
  1a2313:	48 be fc ff ff ff ff 	movabs rsi,0xffffffffffffffc
  1a231a:	ff ff 0f 
  1a231d:	49 21 f2             	and    r10,rsi
  1a2320:	c4 43 7d 19 c3 01    	vextractf128 xmm11,ymm8,0x1
  1a2326:	c4 41 39 58 c3       	vaddpd xmm8,xmm8,xmm11
  1a232b:	c4 41 39 c6 d8 01    	vshufpd xmm11,xmm8,xmm8,0x1
  1a2331:	c4 41 3b 58 c3       	vaddsd xmm8,xmm8,xmm11
  1a2336:	c4 43 7d 19 cb 01    	vextractf128 xmm11,ymm9,0x1
  1a233c:	c4 41 31 58 cb       	vaddpd xmm9,xmm9,xmm11
  1a2341:	c4 41 31 c6 d9 01    	vshufpd xmm11,xmm9,xmm9,0x1
  1a2347:	c4 41 33 58 cb       	vaddsd xmm9,xmm9,xmm11
  1a234c:	c4 c3 7d 19 fb 01    	vextractf128 xmm11,ymm7,0x1
  1a2352:	c5 a1 58 ff          	vaddpd xmm7,xmm11,xmm7
  1a2356:	c5 41 c6 df 01       	vshufpd xmm11,xmm7,xmm7,0x1
  1a235b:	c5 a3 58 ff          	vaddsd xmm7,xmm11,xmm7
  1a235f:	c4 43 7d 19 d3 01    	vextractf128 xmm11,ymm10,0x1
  1a2365:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
  1a236a:	45 89 f4             	mov    r12d,r14d
  1a236d:	41 83 e4 03          	and    r12d,0x3
  1a2371:	48 8b 84 24 e0 00 00 	mov    rax,QWORD PTR [rsp+0xe0]
  1a2378:	00 
  1a2379:	49 39 c4             	cmp    r12,rax
  1a237c:	4c 0f 43 e0          	cmovae r12,rax
  1a2380:	c4 41 29 58 d3       	vaddpd xmm10,xmm10,xmm11
  1a2385:	4d 39 e1             	cmp    r9,r12
  1a2388:	4d 0f 42 e1          	cmovb  r12,r9
  1a238c:	c4 41 29 c6 da 01    	vshufpd xmm11,xmm10,xmm10,0x1
  1a2392:	48 8b 84 24 98 01 00 	mov    rax,QWORD PTR [rsp+0x198]
  1a2399:	00 
  1a239a:	4c 39 e0             	cmp    rax,r12
  1a239d:	4c 0f 42 e0          	cmovb  r12,rax
  1a23a1:	c4 41 2b 58 d3       	vaddsd xmm10,xmm10,xmm11
  1a23a6:	48 8b 84 24 18 01 00 	mov    rax,QWORD PTR [rsp+0x118]
  1a23ad:	00 
  1a23ae:	4c 39 e0             	cmp    rax,r12
  1a23b1:	4c 0f 42 e0          	cmovb  r12,rax
  1a23b5:	4c 39 e2             	cmp    rdx,r12
  1a23b8:	48 89 94 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rdx
  1a23bf:	00 
  1a23c0:	4c 0f 42 e2          	cmovb  r12,rdx
  1a23c4:	4d 85 e4             	test   r12,r12
  1a23c7:	4c 89 94 24 40 01 00 	mov    QWORD PTR [rsp+0x140],r10
  1a23ce:	00 
  1a23cf:	0f 84 ff 00 00 00    	je     1a24d4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0xc14>
  1a23d5:	4c 89 f0             	mov    rax,r14
  1a23d8:	48 21 f0             	and    rax,rsi
  1a23db:	c4 41 7b 10 1c cb    	vmovsd xmm11,QWORD PTR [r11+rcx*8]
  1a23e1:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
  1a23e8:	00 
  1a23e9:	48 8b bc 24 28 02 00 	mov    rdi,QWORD PTR [rsp+0x228]
  1a23f0:	00 
  1a23f1:	c5 7b 10 24 fe       	vmovsd xmm12,QWORD PTR [rsi+rdi*8]
  1a23f6:	c4 62 c9 a9 e5       	vfmadd213sd xmm12,xmm6,xmm5
  1a23fb:	48 89 ac 24 90 00 00 	mov    QWORD PTR [rsp+0x90],rbp
  1a2402:	00 
  1a2403:	c4 62 a1 a9 64 c5 00 	vfmadd213sd xmm12,xmm11,QWORD PTR [rbp+rax*8+0x0]
  1a240a:	c4 41 f9 7e e1       	vmovq  r9,xmm12
  1a240f:	b2 3f                	mov    dl,0x3f
  1a2411:	c4 42 e8 f5 c9       	bzhi   r9,r9,rdx
  1a2416:	48 ba 00 00 00 00 00 	movabs rdx,0x7ff0000000000000
  1a241d:	00 f0 7f 
  1a2420:	49 39 d1             	cmp    r9,rdx
  1a2423:	41 0f 94 c0          	sete   r8b
  1a2427:	4d 85 c9             	test   r9,r9
  1a242a:	41 0f 94 c6          	sete   r14b
  1a242e:	45 08 c6             	or     r14b,r8b
  1a2431:	48 8b 54 24 38       	mov    rdx,QWORD PTR [rsp+0x38]
  1a2436:	4c 8b 84 24 50 01 00 	mov    r8,QWORD PTR [rsp+0x150]
  1a243d:	00 
  1a243e:	c4 22 a1 b9 04 c2    	vfmadd231sd xmm8,xmm11,QWORD PTR [rdx+r8*8]
  1a2444:	48 8b 54 24 30       	mov    rdx,QWORD PTR [rsp+0x30]
  1a2449:	4c 8b 84 24 a8 00 00 	mov    r8,QWORD PTR [rsp+0xa8]
  1a2450:	00 
  1a2451:	c4 22 a1 b9 0c c2    	vfmadd231sd xmm9,xmm11,QWORD PTR [rdx+r8*8]
  1a2457:	48 8b 54 24 60       	mov    rdx,QWORD PTR [rsp+0x60]
  1a245c:	4c 8b 84 24 80 00 00 	mov    r8,QWORD PTR [rsp+0x80]
  1a2463:	00 
  1a2464:	c4 a2 a1 b9 3c c2    	vfmadd231sd xmm7,xmm11,QWORD PTR [rdx+r8*8]
  1a246a:	48 ba 00 00 00 00 00 	movabs rdx,0xfff0000000000000
  1a2471:	00 f0 ff 
  1a2474:	49 01 d1             	add    r9,rdx
  1a2477:	49 c1 e9 35          	shr    r9,0x35
  1a247b:	41 81 f9 ff 03 00 00 	cmp    r9d,0x3ff
  1a2482:	48 8b 94 24 30 02 00 	mov    rdx,QWORD PTR [rsp+0x230]
  1a2489:	00 
  1a248a:	4c 8b 44 24 20       	mov    r8,QWORD PTR [rsp+0x20]
  1a248f:	c4 42 a1 b9 14 d0    	vfmadd231sd xmm10,xmm11,QWORD PTR [r8+rdx*8]
  1a2495:	41 0f 92 c1          	setb   r9b
  1a2499:	45 08 f1             	or     r9b,r14b
  1a249c:	c4 21 7b 11 24 d3    	vmovsd QWORD PTR [rbx+r10*8],xmm12
  1a24a2:	41 83 fc 01          	cmp    r12d,0x1
  1a24a6:	75 63                	jne    1a250b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0xc4b>
  1a24a8:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
  1a24ad:	4c 8b a4 24 c0 00 00 	mov    r12,QWORD PTR [rsp+0xc0]
  1a24b4:	00 
  1a24b5:	4c 8b 94 24 90 00 00 	mov    r10,QWORD PTR [rsp+0x90]
  1a24bc:	00 
  1a24bd:	48 8b ac 24 a0 00 00 	mov    rbp,QWORD PTR [rsp+0xa0]
  1a24c4:	00 
  1a24c5:	4c 8b 44 24 40       	mov    r8,QWORD PTR [rsp+0x40]
  1a24ca:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
  1a24cf:	e9 f3 01 00 00       	jmp    1a26c7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0xe07>
  1a24d4:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
  1a24d9:	4c 8b a4 24 c0 00 00 	mov    r12,QWORD PTR [rsp+0xc0]
  1a24e0:	00 
  1a24e1:	49 89 ea             	mov    r10,rbp
  1a24e4:	48 8b 94 24 d0 01 00 	mov    rdx,QWORD PTR [rsp+0x1d0]
  1a24eb:	00 
  1a24ec:	48 8b ac 24 a0 00 00 	mov    rbp,QWORD PTR [rsp+0xa0]
  1a24f3:	00 
  1a24f4:	4c 8b 44 24 40       	mov    r8,QWORD PTR [rsp+0x40]
  1a24f9:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
  1a24fe:	48 8b 8c 24 10 01 00 	mov    rcx,QWORD PTR [rsp+0x110]
  1a2505:	00 
  1a2506:	e9 d6 01 00 00       	jmp    1a26e1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0xe21>
  1a250b:	4c 89 d5             	mov    rbp,r10
  1a250e:	c4 41 7b 10 5c cb 08 	vmovsd xmm11,QWORD PTR [r11+rcx*8+0x8]
  1a2515:	c5 7b 10 64 fe 08    	vmovsd xmm12,QWORD PTR [rsi+rdi*8+0x8]
  1a251b:	c4 62 c9 a9 e5       	vfmadd213sd xmm12,xmm6,xmm5
  1a2520:	4c 8b 84 24 90 00 00 	mov    r8,QWORD PTR [rsp+0x90]
  1a2527:	00 
  1a2528:	c4 42 a1 a9 64 c0 08 	vfmadd213sd xmm12,xmm11,QWORD PTR [r8+rax*8+0x8]
  1a252f:	c4 41 f9 7e e0       	vmovq  r8,xmm12
  1a2534:	41 b2 3f             	mov    r10b,0x3f
  1a2537:	c4 42 a8 f5 c0       	bzhi   r8,r8,r10
  1a253c:	49 ba 00 00 00 00 00 	movabs r10,0x7ff0000000000000
  1a2543:	00 f0 7f 
  1a2546:	4d 39 d0             	cmp    r8,r10
  1a2549:	41 0f 94 c6          	sete   r14b
  1a254d:	4d 85 c0             	test   r8,r8
  1a2550:	41 0f 94 c2          	sete   r10b
  1a2554:	45 08 f2             	or     r10b,r14b
  1a2557:	48 be 00 00 00 00 00 	movabs rsi,0xfff0000000000000
  1a255e:	00 f0 ff 
  1a2561:	49 01 f0             	add    r8,rsi
  1a2564:	49 c1 e8 35          	shr    r8,0x35
  1a2568:	41 81 f8 ff 03 00 00 	cmp    r8d,0x3ff
  1a256f:	41 0f 92 c0          	setb   r8b
  1a2573:	45 08 d0             	or     r8b,r10b
  1a2576:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
  1a257b:	4c 8b 94 24 50 01 00 	mov    r10,QWORD PTR [rsp+0x150]
  1a2582:	00 
  1a2583:	c4 22 a1 b9 44 d6 08 	vfmadd231sd xmm8,xmm11,QWORD PTR [rsi+r10*8+0x8]
  1a258a:	48 8b 74 24 30       	mov    rsi,QWORD PTR [rsp+0x30]
  1a258f:	4c 8b 94 24 a8 00 00 	mov    r10,QWORD PTR [rsp+0xa8]
  1a2596:	00 
  1a2597:	c4 22 a1 b9 4c d6 08 	vfmadd231sd xmm9,xmm11,QWORD PTR [rsi+r10*8+0x8]
  1a259e:	4c 8b 54 24 60       	mov    r10,QWORD PTR [rsp+0x60]
  1a25a3:	4c 8b b4 24 80 00 00 	mov    r14,QWORD PTR [rsp+0x80]
  1a25aa:	00 
  1a25ab:	c4 82 a1 b9 7c f2 08 	vfmadd231sd xmm7,xmm11,QWORD PTR [r10+r14*8+0x8]
  1a25b2:	4c 8b 54 24 20       	mov    r10,QWORD PTR [rsp+0x20]
  1a25b7:	c4 42 a1 b9 54 d2 08 	vfmadd231sd xmm10,xmm11,QWORD PTR [r10+rdx*8+0x8]
  1a25be:	45 20 c1             	and    r9b,r8b
  1a25c1:	c5 7b 11 64 eb 08    	vmovsd QWORD PTR [rbx+rbp*8+0x8],xmm12
  1a25c7:	41 83 fc 02          	cmp    r12d,0x2
  1a25cb:	49 89 ee             	mov    r14,rbp
  1a25ce:	48 8b ac 24 a0 00 00 	mov    rbp,QWORD PTR [rsp+0xa0]
  1a25d5:	00 
  1a25d6:	75 1f                	jne    1a25f7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0xd37>
  1a25d8:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
  1a25dd:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
  1a25e2:	4c 8b a4 24 c0 00 00 	mov    r12,QWORD PTR [rsp+0xc0]
  1a25e9:	00 
  1a25ea:	4c 8b 94 24 90 00 00 	mov    r10,QWORD PTR [rsp+0x90]
  1a25f1:	00 
  1a25f2:	e9 cb 00 00 00       	jmp    1a26c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0xe02>
  1a25f7:	c4 41 7b 10 5c cb 10 	vmovsd xmm11,QWORD PTR [r11+rcx*8+0x10]
  1a25fe:	48 8b 8c 24 d0 00 00 	mov    rcx,QWORD PTR [rsp+0xd0]
  1a2605:	00 
  1a2606:	c4 e2 c9 b9 6c f9 10 	vfmadd231sd xmm5,xmm6,QWORD PTR [rcx+rdi*8+0x10]
  1a260d:	48 8b 8c 24 90 00 00 	mov    rcx,QWORD PTR [rsp+0x90]
  1a2614:	00 
  1a2615:	c4 e2 a1 a9 6c c1 10 	vfmadd213sd xmm5,xmm11,QWORD PTR [rcx+rax*8+0x10]
  1a261c:	c4 e1 f9 7e e8       	vmovq  rax,xmm5
  1a2621:	40 b7 3f             	mov    dil,0x3f
  1a2624:	c4 e2 c0 f5 c0       	bzhi   rax,rax,rdi
  1a2629:	48 bf 00 00 00 00 00 	movabs rdi,0x7ff0000000000000
  1a2630:	00 f0 7f 
  1a2633:	48 39 f8             	cmp    rax,rdi
  1a2636:	41 0f 94 c2          	sete   r10b
  1a263a:	48 85 c0             	test   rax,rax
  1a263d:	41 0f 94 c0          	sete   r8b
  1a2641:	45 08 d0             	or     r8b,r10b
  1a2644:	48 bf 00 00 00 00 00 	movabs rdi,0xfff0000000000000
  1a264b:	00 f0 ff 
  1a264e:	48 01 f8             	add    rax,rdi
  1a2651:	48 c1 e8 35          	shr    rax,0x35
  1a2655:	3d ff 03 00 00       	cmp    eax,0x3ff
  1a265a:	0f 92 c0             	setb   al
  1a265d:	44 08 c0             	or     al,r8b
  1a2660:	41 20 c1             	and    r9b,al
  1a2663:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
  1a2668:	48 8b bc 24 50 01 00 	mov    rdi,QWORD PTR [rsp+0x150]
  1a266f:	00 
  1a2670:	c4 62 a1 b9 44 f8 10 	vfmadd231sd xmm8,xmm11,QWORD PTR [rax+rdi*8+0x10]
  1a2677:	48 8b 84 24 a8 00 00 	mov    rax,QWORD PTR [rsp+0xa8]
  1a267e:	00 
  1a267f:	c4 62 a1 b9 4c c6 10 	vfmadd231sd xmm9,xmm11,QWORD PTR [rsi+rax*8+0x10]
  1a2686:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
  1a268b:	48 8b b4 24 80 00 00 	mov    rsi,QWORD PTR [rsp+0x80]
  1a2692:	00 
  1a2693:	c4 e2 a1 b9 7c f0 10 	vfmadd231sd xmm7,xmm11,QWORD PTR [rax+rsi*8+0x10]
  1a269a:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
  1a269f:	c4 62 a1 b9 54 d0 10 	vfmadd231sd xmm10,xmm11,QWORD PTR [rax+rdx*8+0x10]
  1a26a6:	c4 a1 7b 11 6c f3 10 	vmovsd QWORD PTR [rbx+r14*8+0x10],xmm5
  1a26ad:	48 8b 7c 24 08       	mov    rdi,QWORD PTR [rsp+0x8]
  1a26b2:	48 8b 74 24 68       	mov    rsi,QWORD PTR [rsp+0x68]
  1a26b7:	4c 8b a4 24 c0 00 00 	mov    r12,QWORD PTR [rsp+0xc0]
  1a26be:	00 
  1a26bf:	49 89 ca             	mov    r10,rcx
  1a26c2:	4c 8b 44 24 40       	mov    r8,QWORD PTR [rsp+0x40]
  1a26c7:	4c 8b 74 24 10       	mov    r14,QWORD PTR [rsp+0x10]
  1a26cc:	48 8b 8c 24 10 01 00 	mov    rcx,QWORD PTR [rsp+0x110]
  1a26d3:	00 
  1a26d4:	44 20 4c 24 07       	and    BYTE PTR [rsp+0x7],r9b
  1a26d9:	48 8b 94 24 d0 01 00 	mov    rdx,QWORD PTR [rsp+0x1d0]
  1a26e0:	00 
  1a26e1:	49 39 fd             	cmp    r13,rdi
  1a26e4:	0f 83 d2 1a 00 00    	jae    1a41bc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x28fc>
  1a26ea:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
  1a26f1:	00 
  1a26f2:	c4 21 7b 11 04 38    	vmovsd QWORD PTR [rax+r15*1],xmm8
  1a26f8:	c4 21 7b 11 4c 38 08 	vmovsd QWORD PTR [rax+r15*1+0x8],xmm9
  1a26ff:	48 39 b4 24 38 01 00 	cmp    QWORD PTR [rsp+0x138],rsi
  1a2706:	00 
  1a2707:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
  1a270c:	0f 83 0a f7 ff ff    	jae    1a1e1c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x55c>
  1a2712:	49 ff c5             	inc    r13
  1a2715:	49 39 fd             	cmp    r13,rdi
  1a2718:	0f 83 0f 1b 00 00    	jae    1a422d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x296d>
  1a271e:	49 c1 e5 04          	shl    r13,0x4
  1a2722:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
  1a2729:	00 
  1a272a:	c4 a1 7b 11 3c 28    	vmovsd QWORD PTR [rax+r13*1],xmm7
  1a2730:	c4 21 7b 11 54 28 08 	vmovsd QWORD PTR [rax+r13*1+0x8],xmm10
  1a2737:	e9 e0 f6 ff ff       	jmp    1a1e1c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x55c>
  1a273c:	4c 8b ac 24 28 01 00 	mov    r13,QWORD PTR [rsp+0x128]
  1a2743:	00 
  1a2744:	4c 89 e8             	mov    rax,r13
  1a2747:	48 c1 e8 02          	shr    rax,0x2
  1a274b:	48 89 84 24 78 01 00 	mov    QWORD PTR [rsp+0x178],rax
  1a2752:	00 
  1a2753:	44 89 e8             	mov    eax,r13d
  1a2756:	83 e0 03             	and    eax,0x3
  1a2759:	48 89 84 24 90 01 00 	mov    QWORD PTR [rsp+0x190],rax
  1a2760:	00 
  1a2761:	4c 8b 4c 24 50       	mov    r9,QWORD PTR [rsp+0x50]
  1a2766:	4c 89 c8             	mov    rax,r9
  1a2769:	48 c1 e8 02          	shr    rax,0x2
  1a276d:	48 89 84 24 b8 01 00 	mov    QWORD PTR [rsp+0x1b8],rax
  1a2774:	00 
  1a2775:	44 89 c8             	mov    eax,r9d
  1a2778:	83 e0 03             	and    eax,0x3
  1a277b:	48 89 84 24 88 01 00 	mov    QWORD PTR [rsp+0x188],rax
  1a2782:	00 
  1a2783:	48 8b 74 24 78       	mov    rsi,QWORD PTR [rsp+0x78]
  1a2788:	48 89 f0             	mov    rax,rsi
  1a278b:	48 c1 e8 02          	shr    rax,0x2
  1a278f:	48 89 84 24 b0 01 00 	mov    QWORD PTR [rsp+0x1b0],rax
  1a2796:	00 
  1a2797:	89 f0                	mov    eax,esi
  1a2799:	83 e0 03             	and    eax,0x3
  1a279c:	48 89 84 24 80 01 00 	mov    QWORD PTR [rsp+0x180],rax
  1a27a3:	00 
  1a27a4:	4c 8b 54 24 70       	mov    r10,QWORD PTR [rsp+0x70]
  1a27a9:	4c 89 d0             	mov    rax,r10
  1a27ac:	48 c1 e8 02          	shr    rax,0x2
  1a27b0:	48 89 84 24 a8 01 00 	mov    QWORD PTR [rsp+0x1a8],rax
  1a27b7:	00 
  1a27b8:	44 89 d0             	mov    eax,r10d
  1a27bb:	83 e0 03             	and    eax,0x3
  1a27be:	48 89 84 24 c0 01 00 	mov    QWORD PTR [rsp+0x1c0],rax
  1a27c5:	00 
  1a27c6:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
  1a27cb:	49 89 fc             	mov    r12,rdi
  1a27ce:	49 c1 ec 02          	shr    r12,0x2
  1a27d2:	89 f8                	mov    eax,edi
  1a27d4:	83 e0 03             	and    eax,0x3
  1a27d7:	48 89 84 24 b8 00 00 	mov    QWORD PTR [rsp+0xb8],rax
  1a27de:	00 
  1a27df:	49 89 f8             	mov    r8,rdi
  1a27e2:	48 b8 fc ff ff ff ff 	movabs rax,0xffffffffffffffc
  1a27e9:	ff ff 0f 
  1a27ec:	49 21 c0             	and    r8,rax
  1a27ef:	4c 89 84 24 40 01 00 	mov    QWORD PTR [rsp+0x140],r8
  1a27f6:	00 
  1a27f7:	48 8b 84 24 98 00 00 	mov    rax,QWORD PTR [rsp+0x98]
  1a27fe:	00 
  1a27ff:	49 89 c0             	mov    r8,rax
  1a2802:	49 c1 e8 02          	shr    r8,0x2
  1a2806:	4c 89 84 24 b0 00 00 	mov    QWORD PTR [rsp+0xb0],r8
  1a280d:	00 
  1a280e:	48 c1 e8 03          	shr    rax,0x3
  1a2812:	49 89 c6             	mov    r14,rax
  1a2815:	eb 3b                	jmp    1a2852 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0xf92>
  1a2817:	c5 fd 28 c1          	vmovapd ymm0,ymm1
  1a281b:	49 89 db             	mov    r11,rbx
  1a281e:	48 8b 9c 24 08 01 00 	mov    rbx,QWORD PTR [rsp+0x108]
  1a2825:	00 
  1a2826:	4c 8b ac 24 28 01 00 	mov    r13,QWORD PTR [rsp+0x128]
  1a282d:	00 
  1a282e:	4c 8b 4c 24 50       	mov    r9,QWORD PTR [rsp+0x50]
  1a2833:	48 8b 74 24 78       	mov    rsi,QWORD PTR [rsp+0x78]
  1a2838:	4c 8b 54 24 70       	mov    r10,QWORD PTR [rsp+0x70]
  1a283d:	4c 8b 7c 24 60       	mov    r15,QWORD PTR [rsp+0x60]
  1a2842:	4c 8b b4 24 88 00 00 	mov    r14,QWORD PTR [rsp+0x88]
  1a2849:	00 
  1a284a:	4c 8b a4 24 60 01 00 	mov    r12,QWORD PTR [rsp+0x160]
  1a2851:	00 
  1a2852:	48 b8 fe ff ff ff ff 	movabs rax,0x3fffffffffffffe
  1a2859:	ff ff 03 
  1a285c:	49 21 c4             	and    r12,rax
  1a285f:	49 c1 e4 05          	shl    r12,0x5
  1a2863:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
  1a2868:	48 c1 ef 03          	shr    rdi,0x3
  1a286c:	4c 89 e8             	mov    rax,r13
  1a286f:	48 c1 e8 03          	shr    rax,0x3
  1a2873:	49 c1 e9 03          	shr    r9,0x3
  1a2877:	49 39 c1             	cmp    r9,rax
  1a287a:	4c 0f 43 c8          	cmovae r9,rax
  1a287e:	48 89 f0             	mov    rax,rsi
  1a2881:	48 c1 e8 03          	shr    rax,0x3
  1a2885:	4c 39 c8             	cmp    rax,r9
  1a2888:	49 0f 43 c1          	cmovae rax,r9
  1a288c:	49 c1 ea 03          	shr    r10,0x3
  1a2890:	49 39 c2             	cmp    r10,rax
  1a2893:	4c 0f 43 d0          	cmovae r10,rax
  1a2897:	4c 39 d7             	cmp    rdi,r10
  1a289a:	48 89 7c 24 48       	mov    QWORD PTR [rsp+0x48],rdi
  1a289f:	4c 0f 42 d7          	cmovb  r10,rdi
  1a28a3:	4d 39 d6             	cmp    r14,r10
  1a28a6:	4d 0f 42 d6          	cmovb  r10,r14
  1a28aa:	4d 85 d2             	test   r10,r10
  1a28ad:	4c 89 b4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],r14
  1a28b4:	00 
  1a28b5:	0f 84 6a 0f 00 00    	je     1a3825 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1f65>
  1a28bb:	49 83 fa 01          	cmp    r10,0x1
  1a28bf:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
  1a28c4:	0f 85 86 0f 00 00    	jne    1a3850 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1f90>
  1a28ca:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
  1a28ce:	45 31 c9             	xor    r9d,r9d
  1a28d1:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
  1a28d5:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
  1a28d9:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  1a28dd:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  1a28e1:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  1a28e5:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  1a28e9:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  1a28ee:	e9 4c 10 00 00       	jmp    1a393f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x207f>
  1a28f3:	4c 8b 8c 24 98 00 00 	mov    r9,QWORD PTR [rsp+0x98]
  1a28fa:	00 
  1a28fb:	49 c1 e9 02          	shr    r9,0x2
  1a28ff:	4d 39 c1             	cmp    r9,r8
  1a2902:	4c 8b 64 24 50       	mov    r12,QWORD PTR [rsp+0x50]
  1a2907:	0f 85 0e 18 00 00    	jne    1a411b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x285b>
  1a290d:	4c 8b 8c 24 18 01 00 	mov    r9,QWORD PTR [rsp+0x118]
  1a2914:	00 
  1a2915:	49 c1 e9 02          	shr    r9,0x2
  1a2919:	4d 39 c1             	cmp    r9,r8
  1a291c:	0f 85 f9 17 00 00    	jne    1a411b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x285b>
  1a2922:	45 89 ef             	mov    r15d,r13d
  1a2925:	41 83 e7 03          	and    r15d,0x3
  1a2929:	45 89 e1             	mov    r9d,r12d
  1a292c:	41 83 e1 03          	and    r9d,0x3
  1a2930:	45 39 cf             	cmp    r15d,r9d
  1a2933:	0f 85 e2 17 00 00    	jne    1a411b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x285b>
  1a2939:	48 8b 5c 24 78       	mov    rbx,QWORD PTR [rsp+0x78]
  1a293e:	83 e3 03             	and    ebx,0x3
  1a2941:	44 39 cb             	cmp    ebx,r9d
  1a2944:	0f 85 d1 17 00 00    	jne    1a411b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x285b>
  1a294a:	48 8b 5c 24 70       	mov    rbx,QWORD PTR [rsp+0x70]
  1a294f:	83 e3 03             	and    ebx,0x3
  1a2952:	44 39 cb             	cmp    ebx,r9d
  1a2955:	0f 85 c0 17 00 00    	jne    1a411b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x285b>
  1a295b:	4c 8b 8c 24 98 00 00 	mov    r9,QWORD PTR [rsp+0x98]
  1a2962:	00 
  1a2963:	41 83 e1 03          	and    r9d,0x3
  1a2967:	45 39 f9             	cmp    r9d,r15d
  1a296a:	0f 85 ab 17 00 00    	jne    1a411b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x285b>
  1a2970:	4c 8b 8c 24 18 01 00 	mov    r9,QWORD PTR [rsp+0x118]
  1a2977:	00 
  1a2978:	41 83 e1 03          	and    r9d,0x3
  1a297c:	4c 89 8c 24 a0 01 00 	mov    QWORD PTR [rsp+0x1a0],r9
  1a2983:	00 
  1a2984:	45 39 f9             	cmp    r9d,r15d
  1a2987:	0f 85 8e 17 00 00    	jne    1a411b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x285b>
  1a298d:	4c 89 7c 24 10       	mov    QWORD PTR [rsp+0x10],r15
  1a2992:	4c 89 84 24 38 01 00 	mov    QWORD PTR [rsp+0x138],r8
  1a2999:	00 
  1a299a:	4c 89 ac 24 28 01 00 	mov    QWORD PTR [rsp+0x128],r13
  1a29a1:	00 
  1a29a2:	49 b8 fc ff ff ff ff 	movabs r8,0xffffffffffffffc
  1a29a9:	ff ff 0f 
  1a29ac:	4d 21 c5             	and    r13,r8
  1a29af:	4c 89 ac 24 f8 00 00 	mov    QWORD PTR [rsp+0xf8],r13
  1a29b6:	00 
  1a29b7:	4d 21 c4             	and    r12,r8
  1a29ba:	4c 89 a4 24 80 00 00 	mov    QWORD PTR [rsp+0x80],r12
  1a29c1:	00 
  1a29c2:	4c 8b 4c 24 78       	mov    r9,QWORD PTR [rsp+0x78]
  1a29c7:	4d 21 c1             	and    r9,r8
  1a29ca:	4c 89 8c 24 f0 00 00 	mov    QWORD PTR [rsp+0xf0],r9
  1a29d1:	00 
  1a29d2:	4c 8b 4c 24 70       	mov    r9,QWORD PTR [rsp+0x70]
  1a29d7:	4d 21 c1             	and    r9,r8
  1a29da:	4c 89 8c 24 e8 00 00 	mov    QWORD PTR [rsp+0xe8],r9
  1a29e1:	00 
  1a29e2:	4c 8b 8c 24 18 01 00 	mov    r9,QWORD PTR [rsp+0x118]
  1a29e9:	00 
  1a29ea:	4d 21 c1             	and    r9,r8
  1a29ed:	4c 89 8c 24 a0 00 00 	mov    QWORD PTR [rsp+0xa0],r9
  1a29f4:	00 
  1a29f5:	4c 8b 8c 24 08 01 00 	mov    r9,QWORD PTR [rsp+0x108]
  1a29fc:	00 
  1a29fd:	44 89 cb             	mov    ebx,r9d
  1a2a00:	83 e3 03             	and    ebx,0x3
  1a2a03:	4d 89 ce             	mov    r14,r9
  1a2a06:	4d 21 c6             	and    r14,r8
  1a2a09:	4c 89 b4 24 10 01 00 	mov    QWORD PTR [rsp+0x110],r14
  1a2a10:	00 
  1a2a11:	48 8d 73 ff          	lea    rsi,[rbx-0x1]
  1a2a15:	48 39 de             	cmp    rsi,rbx
  1a2a18:	48 89 9c 24 a8 00 00 	mov    QWORD PTR [rsp+0xa8],rbx
  1a2a1f:	00 
  1a2a20:	48 0f 43 f3          	cmovae rsi,rbx
  1a2a24:	48 89 b4 24 98 01 00 	mov    QWORD PTR [rsp+0x198],rsi
  1a2a2b:	00 
  1a2a2c:	48 8b b4 24 b0 00 00 	mov    rsi,QWORD PTR [rsp+0xb0]
  1a2a33:	00 
  1a2a34:	48 83 e6 fe          	and    rsi,0xfffffffffffffffe
  1a2a38:	c6 44 24 07 01       	mov    BYTE PTR [rsp+0x7],0x1
  1a2a3d:	49 89 f8             	mov    r8,rdi
  1a2a40:	4c 89 cf             	mov    rdi,r9
  1a2a43:	48 8b 9c 24 98 00 00 	mov    rbx,QWORD PTR [rsp+0x98]
  1a2a4a:	00 
  1a2a4b:	4c 8b a4 24 c0 00 00 	mov    r12,QWORD PTR [rsp+0xc0]
  1a2a52:	00 
  1a2a53:	4c 8b 7c 24 60       	mov    r15,QWORD PTR [rsp+0x60]
  1a2a58:	4c 8b b4 24 90 00 00 	mov    r14,QWORD PTR [rsp+0x90]
  1a2a5f:	00 
  1a2a60:	48 89 b4 24 e0 00 00 	mov    QWORD PTR [rsp+0xe0],rsi
  1a2a67:	00 
  1a2a68:	eb 29                	jmp    1a2a93 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x11d3>
  1a2a6a:	49 83 c0 02          	add    r8,0x2
  1a2a6e:	4c 89 e8             	mov    rax,r13
  1a2a71:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
  1a2a76:	4c 8b 4c 24 28       	mov    r9,QWORD PTR [rsp+0x28]
  1a2a7b:	48 8b 5c 24 50       	mov    rbx,QWORD PTR [rsp+0x50]
  1a2a80:	4c 3b 84 24 b8 00 00 	cmp    r8,QWORD PTR [rsp+0xb8]
  1a2a87:	00 
  1a2a88:	4c 8b 7c 24 60       	mov    r15,QWORD PTR [rsp+0x60]
  1a2a8d:	0f 83 d2 16 00 00    	jae    1a4165 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x28a5>
  1a2a93:	48 89 5c 24 48       	mov    QWORD PTR [rsp+0x48],rbx
  1a2a98:	4d 89 f5             	mov    r13,r14
  1a2a9b:	4d 89 de             	mov    r14,r11
  1a2a9e:	48 89 7c 24 28       	mov    QWORD PTR [rsp+0x28],rdi
  1a2aa3:	49 89 c3             	mov    r11,rax
  1a2aa6:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
  1a2aad:	00 
  1a2aae:	49 39 c0             	cmp    r8,rax
  1a2ab1:	0f 83 d1 17 00 00    	jae    1a4288 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x29c8>
  1a2ab7:	4c 3b 44 24 58       	cmp    r8,QWORD PTR [rsp+0x58]
  1a2abc:	48 8b 5c 24 30       	mov    rbx,QWORD PTR [rsp+0x30]
  1a2ac1:	0f 83 dc 17 00 00    	jae    1a42a3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x29e3>
  1a2ac7:	49 8d 78 01          	lea    rdi,[r8+0x1]
  1a2acb:	48 39 c7             	cmp    rdi,rax
  1a2ace:	0f 83 9c 17 00 00    	jae    1a4270 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x29b0>
  1a2ad4:	48 3b 7c 24 58       	cmp    rdi,QWORD PTR [rsp+0x58]
  1a2ad9:	0f 83 7c 17 00 00    	jae    1a425b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x299b>
  1a2adf:	31 c0                	xor    eax,eax
  1a2ae1:	4c 39 4c 24 28       	cmp    QWORD PTR [rsp+0x28],r9
  1a2ae6:	0f 85 64 16 00 00    	jne    1a4150 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2890>
  1a2aec:	4c 39 4c 24 50       	cmp    QWORD PTR [rsp+0x50],r9
  1a2af1:	4c 8b 4c 24 20       	mov    r9,QWORD PTR [rsp+0x20]
  1a2af6:	48 8b bc 24 38 01 00 	mov    rdi,QWORD PTR [rsp+0x138]
  1a2afd:	00 
  1a2afe:	0f 85 4c 16 00 00    	jne    1a4150 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2890>
  1a2b04:	48 8b 44 24 28       	mov    rax,QWORD PTR [rsp+0x28]
  1a2b09:	48 c1 e8 02          	shr    rax,0x2
  1a2b0d:	48 39 f8             	cmp    rax,rdi
  1a2b10:	0f 85 38 16 00 00    	jne    1a414e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x288e>
  1a2b16:	4c 89 fe             	mov    rsi,r15
  1a2b19:	48 8b 44 24 48       	mov    rax,QWORD PTR [rsp+0x48]
  1a2b1e:	89 c7                	mov    edi,eax
  1a2b20:	83 e7 03             	and    edi,0x3
  1a2b23:	31 c0                	xor    eax,eax
  1a2b25:	4c 8b 7c 24 10       	mov    r15,QWORD PTR [rsp+0x10]
  1a2b2a:	44 39 ff             	cmp    edi,r15d
  1a2b2d:	0f 85 1d 16 00 00    	jne    1a4150 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2890>
  1a2b33:	48 8b 7c 24 28       	mov    rdi,QWORD PTR [rsp+0x28]
  1a2b38:	83 e7 03             	and    edi,0x3
  1a2b3b:	44 39 ff             	cmp    edi,r15d
  1a2b3e:	0f 85 0c 16 00 00    	jne    1a4150 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2890>
  1a2b44:	48 8b 7c 24 48       	mov    rdi,QWORD PTR [rsp+0x48]
  1a2b49:	48 c1 ef 02          	shr    rdi,0x2
  1a2b4d:	4c 8b bc 24 38 01 00 	mov    r15,QWORD PTR [rsp+0x138]
  1a2b54:	00 
  1a2b55:	4c 39 ff             	cmp    rdi,r15
  1a2b58:	0f 85 f2 15 00 00    	jne    1a4150 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2890>
  1a2b5e:	48 8b 84 24 e8 01 00 	mov    rax,QWORD PTR [rsp+0x1e8]
  1a2b65:	00 
  1a2b66:	c4 a1 7b 10 04 c0    	vmovsd xmm0,QWORD PTR [rax+r8*8]
  1a2b6c:	48 8b bc 24 e0 01 00 	mov    rdi,QWORD PTR [rsp+0x1e0]
  1a2b73:	00 
  1a2b74:	c4 a1 7b 10 1c c7    	vmovsd xmm3,QWORD PTR [rdi+r8*8]
  1a2b7a:	c4 a1 7b 10 4c c0 08 	vmovsd xmm1,QWORD PTR [rax+r8*8+0x8]
  1a2b81:	c4 a1 7b 10 54 c7 08 	vmovsd xmm2,QWORD PTR [rdi+r8*8+0x8]
  1a2b88:	4d 85 ff             	test   r15,r15
  1a2b8b:	c5 f9 29 84 24 60 01 	vmovapd XMMWORD PTR [rsp+0x160],xmm0
  1a2b92:	00 00 
  1a2b94:	c5 f9 29 8c 24 50 01 	vmovapd XMMWORD PTR [rsp+0x150],xmm1
  1a2b9b:	00 00 
  1a2b9d:	c5 f9 29 94 24 40 01 	vmovapd XMMWORD PTR [rsp+0x140],xmm2
  1a2ba4:	00 00 
  1a2ba6:	c5 f9 29 9c 24 f0 01 	vmovapd XMMWORD PTR [rsp+0x1f0],xmm3
  1a2bad:	00 00 
  1a2baf:	0f 84 d2 00 00 00    	je     1a2c87 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x13c7>
  1a2bb5:	c4 62 7d 19 e0       	vbroadcastsd ymm12,xmm0
  1a2bba:	c4 62 7d 19 eb       	vbroadcastsd ymm13,xmm3
  1a2bbf:	c4 62 7d 19 f1       	vbroadcastsd ymm14,xmm1
  1a2bc4:	c4 62 7d 19 fa       	vbroadcastsd ymm15,xmm2
  1a2bc9:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  1a2bcd:	4c 89 f8             	mov    rax,r15
  1a2bd0:	31 ff                	xor    edi,edi
  1a2bd2:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
  1a2bd6:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  1a2bda:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
  1a2bde:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  1a2be2:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  1a2be6:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  1a2beb:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  1a2bf0:	49 89 f7             	mov    r15,rsi
  1a2bf3:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
  1a2bf8:	0f 1f 84 00 00 00 00 	nop    DWORD PTR [rax+rax*1+0x0]
  1a2bff:	00 
  1a2c00:	c4 41 7d 10 14 3e    	vmovupd ymm10,YMMWORD PTR [r14+rdi*1]
  1a2c06:	c5 7d 10 1c 3e       	vmovupd ymm11,YMMWORD PTR [rsi+rdi*1]
  1a2c0b:	c4 42 a5 b8 c2       	vfmadd231pd ymm8,ymm11,ymm10
  1a2c10:	4c 8b 94 24 d0 00 00 	mov    r10,QWORD PTR [rsp+0xd0]
  1a2c17:	00 
  1a2c18:	c4 c1 7d 10 04 3a    	vmovupd ymm0,YMMWORD PTR [r10+rdi*1]
  1a2c1e:	c5 fd 28 c8          	vmovapd ymm1,ymm0
  1a2c22:	c4 c2 9d a8 cd       	vfmadd213pd ymm1,ymm12,ymm13
  1a2c27:	c4 c2 ad a8 0c 3b    	vfmadd213pd ymm1,ymm10,YMMWORD PTR [r11+rdi*1]
  1a2c2d:	c4 c2 f5 b8 db       	vfmadd231pd ymm3,ymm1,ymm11
  1a2c32:	c5 7d 10 1c 3b       	vmovupd ymm11,YMMWORD PTR [rbx+rdi*1]
  1a2c37:	c4 42 a5 b8 ca       	vfmadd231pd ymm9,ymm11,ymm10
  1a2c3c:	c4 c2 f5 b8 eb       	vfmadd231pd ymm5,ymm1,ymm11
  1a2c41:	c4 41 7d 10 1c 3f    	vmovupd ymm11,YMMWORD PTR [r15+rdi*1]
  1a2c47:	c4 c2 a5 b8 f2       	vfmadd231pd ymm6,ymm11,ymm10
  1a2c4c:	c4 c2 f5 b8 d3       	vfmadd231pd ymm2,ymm1,ymm11
  1a2c51:	c4 41 7d 10 1c 39    	vmovupd ymm11,YMMWORD PTR [r9+rdi*1]
  1a2c57:	c4 c2 a5 b8 fa       	vfmadd231pd ymm7,ymm11,ymm10
  1a2c5c:	c4 c2 f5 b8 e3       	vfmadd231pd ymm4,ymm1,ymm11
  1a2c61:	c4 c2 8d a8 c7       	vfmadd213pd ymm0,ymm14,ymm15
  1a2c66:	c4 c2 f5 a8 c2       	vfmadd213pd ymm0,ymm1,ymm10
  1a2c6b:	c4 c1 7d 11 4c 3d 00 	vmovupd YMMWORD PTR [r13+rdi*1+0x0],ymm1
  1a2c72:	c4 c1 7d 11 04 3b    	vmovupd YMMWORD PTR [r11+rdi*1],ymm0
  1a2c78:	48 83 c7 20          	add    rdi,0x20
  1a2c7c:	48 ff c8             	dec    rax
  1a2c7f:	0f 85 7b ff ff ff    	jne    1a2c00 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1340>
  1a2c85:	eb 25                	jmp    1a2cac <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x13ec>
  1a2c87:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  1a2c8c:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  1a2c91:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  1a2c95:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  1a2c99:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
  1a2c9d:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  1a2ca1:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
  1a2ca5:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  1a2ca9:	49 89 f7             	mov    r15,rsi
  1a2cac:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
  1a2cb1:	48 b8 fc ff ff ff ff 	movabs rax,0xffffffffffffffc
  1a2cb8:	ff ff 0f 
  1a2cbb:	48 21 c6             	and    rsi,rax
  1a2cbe:	c4 63 7d 19 c0 01    	vextractf128 xmm0,ymm8,0x1
  1a2cc4:	c5 b9 58 c0          	vaddpd xmm0,xmm8,xmm0
  1a2cc8:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  1a2ccd:	c5 7b 58 c1          	vaddsd xmm8,xmm0,xmm1
  1a2cd1:	c4 63 7d 19 c8 01    	vextractf128 xmm0,ymm9,0x1
  1a2cd7:	c5 b1 58 c0          	vaddpd xmm0,xmm9,xmm0
  1a2cdb:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  1a2ce0:	c5 7b 58 c9          	vaddsd xmm9,xmm0,xmm1
  1a2ce4:	c4 e3 7d 19 f0 01    	vextractf128 xmm0,ymm6,0x1
  1a2cea:	c5 c9 58 c0          	vaddpd xmm0,xmm6,xmm0
  1a2cee:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  1a2cf3:	c5 fb 58 f1          	vaddsd xmm6,xmm0,xmm1
  1a2cf7:	c4 e3 7d 19 f8 01    	vextractf128 xmm0,ymm7,0x1
  1a2cfd:	c5 c1 58 c0          	vaddpd xmm0,xmm7,xmm0
  1a2d01:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  1a2d06:	c5 fb 58 f9          	vaddsd xmm7,xmm0,xmm1
  1a2d0a:	c4 e3 7d 19 d8 01    	vextractf128 xmm0,ymm3,0x1
  1a2d10:	c5 e1 58 c0          	vaddpd xmm0,xmm3,xmm0
  1a2d14:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  1a2d19:	c5 fb 58 d9          	vaddsd xmm3,xmm0,xmm1
  1a2d1d:	c4 e3 7d 19 e8 01    	vextractf128 xmm0,ymm5,0x1
  1a2d23:	c5 d1 58 c0          	vaddpd xmm0,xmm5,xmm0
  1a2d27:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  1a2d2c:	c5 fb 58 e9          	vaddsd xmm5,xmm0,xmm1
  1a2d30:	c4 e3 7d 19 d0 01    	vextractf128 xmm0,ymm2,0x1
  1a2d36:	c5 e9 58 c0          	vaddpd xmm0,xmm2,xmm0
  1a2d3a:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  1a2d3f:	c5 fb 58 d1          	vaddsd xmm2,xmm0,xmm1
  1a2d43:	c4 e3 7d 19 e0 01    	vextractf128 xmm0,ymm4,0x1
  1a2d49:	c5 d9 58 c0          	vaddpd xmm0,xmm4,xmm0
  1a2d4d:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  1a2d52:	c5 fb 58 e1          	vaddsd xmm4,xmm0,xmm1
  1a2d56:	48 83 bc 24 a0 01 00 	cmp    QWORD PTR [rsp+0x1a0],0x0
  1a2d5d:	00 00 
  1a2d5f:	48 89 b4 24 88 00 00 	mov    QWORD PTR [rsp+0x88],rsi
  1a2d66:	00 
  1a2d67:	4c 89 b4 24 90 00 00 	mov    QWORD PTR [rsp+0x90],r14
  1a2d6e:	00 
  1a2d6f:	0f 84 67 05 00 00    	je     1a32dc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1a1c>
  1a2d75:	48 83 7c 24 10 00    	cmp    QWORD PTR [rsp+0x10],0x0
  1a2d7b:	0f 84 cd 13 00 00    	je     1a414e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x288e>
  1a2d81:	48 89 f0             	mov    rax,rsi
  1a2d84:	4c 89 44 24 40       	mov    QWORD PTR [rsp+0x40],r8
  1a2d89:	48 8b 74 24 28       	mov    rsi,QWORD PTR [rsp+0x28]
  1a2d8e:	48 bf fc ff ff ff ff 	movabs rdi,0xffffffffffffffc
  1a2d95:	ff ff 0f 
  1a2d98:	48 21 fe             	and    rsi,rdi
  1a2d9b:	48 8b bc 24 a0 00 00 	mov    rdi,QWORD PTR [rsp+0xa0]
  1a2da2:	00 
  1a2da3:	4c 8b 84 24 d0 00 00 	mov    r8,QWORD PTR [rsp+0xd0]
  1a2daa:	00 
  1a2dab:	c4 41 7b 10 24 f8    	vmovsd xmm12,QWORD PTR [r8+rdi*8]
  1a2db1:	c4 41 79 28 ec       	vmovapd xmm13,xmm12
  1a2db6:	c5 79 28 bc 24 60 01 	vmovapd xmm15,XMMWORD PTR [rsp+0x160]
  1a2dbd:	00 00 
  1a2dbf:	c5 79 28 9c 24 f0 01 	vmovapd xmm11,XMMWORD PTR [rsp+0x1f0]
  1a2dc6:	00 00 
  1a2dc8:	c4 42 81 a9 eb       	vfmadd213sd xmm13,xmm15,xmm11
  1a2dcd:	48 8b bc 24 80 00 00 	mov    rdi,QWORD PTR [rsp+0x80]
  1a2dd4:	00 
  1a2dd5:	c4 41 7b 10 34 fe    	vmovsd xmm14,QWORD PTR [r14+rdi*8]
  1a2ddb:	c4 42 89 a9 2c f3    	vfmadd213sd xmm13,xmm14,QWORD PTR [r11+rsi*8]
  1a2de1:	c5 f9 28 8c 24 50 01 	vmovapd xmm1,XMMWORD PTR [rsp+0x150]
  1a2de8:	00 00 
  1a2dea:	c5 79 28 94 24 40 01 	vmovapd xmm10,XMMWORD PTR [rsp+0x140]
  1a2df1:	00 00 
  1a2df3:	c4 42 f1 a9 e2       	vfmadd213sd xmm12,xmm1,xmm10
  1a2df8:	c4 42 91 a9 e6       	vfmadd213sd xmm12,xmm13,xmm14
  1a2dfd:	4c 8b 84 24 e8 00 00 	mov    r8,QWORD PTR [rsp+0xe8]
  1a2e04:	00 
  1a2e05:	c4 81 7b 10 04 c1    	vmovsd xmm0,QWORD PTR [r9+r8*8]
  1a2e0b:	c4 c2 f9 b9 e5       	vfmadd231sd xmm4,xmm0,xmm13
  1a2e10:	c4 e2 89 b9 f8       	vfmadd231sd xmm7,xmm14,xmm0
  1a2e15:	4c 8b 84 24 f0 00 00 	mov    r8,QWORD PTR [rsp+0xf0]
  1a2e1c:	00 
  1a2e1d:	c4 81 7b 10 04 c7    	vmovsd xmm0,QWORD PTR [r15+r8*8]
  1a2e23:	c4 c2 f9 b9 d5       	vfmadd231sd xmm2,xmm0,xmm13
  1a2e28:	c4 e2 89 b9 f0       	vfmadd231sd xmm6,xmm14,xmm0
  1a2e2d:	c5 fb 10 04 fb       	vmovsd xmm0,QWORD PTR [rbx+rdi*8]
  1a2e32:	c4 c2 f9 b9 ed       	vfmadd231sd xmm5,xmm0,xmm13
  1a2e37:	c4 62 89 b9 c8       	vfmadd231sd xmm9,xmm14,xmm0
  1a2e3c:	48 8b 7c 24 38       	mov    rdi,QWORD PTR [rsp+0x38]
  1a2e41:	4c 8b 84 24 f8 00 00 	mov    r8,QWORD PTR [rsp+0xf8]
  1a2e48:	00 
  1a2e49:	c4 a1 7b 10 04 c7    	vmovsd xmm0,QWORD PTR [rdi+r8*8]
  1a2e4f:	c4 42 f9 b9 c6       	vfmadd231sd xmm8,xmm0,xmm14
  1a2e54:	c4 c2 f9 b9 dd       	vfmadd231sd xmm3,xmm0,xmm13
  1a2e59:	c4 41 7b 11 6c c5 00 	vmovsd QWORD PTR [r13+rax*8+0x0],xmm13
  1a2e60:	c4 61 f9 7e ef       	vmovq  rdi,xmm13
  1a2e65:	c4 41 f9 7e e0       	vmovq  r8,xmm12
  1a2e6a:	48 89 b4 24 20 01 00 	mov    QWORD PTR [rsp+0x120],rsi
  1a2e71:	00 
  1a2e72:	c4 41 7b 11 24 f3    	vmovsd QWORD PTR [r11+rsi*8],xmm12
  1a2e78:	40 b6 3f             	mov    sil,0x3f
  1a2e7b:	c4 e2 c8 f5 ff       	bzhi   rdi,rdi,rsi
  1a2e80:	48 be 00 00 00 00 00 	movabs rsi,0x7ff0000000000000
  1a2e87:	00 f0 7f 
  1a2e8a:	48 39 f7             	cmp    rdi,rsi
  1a2e8d:	41 0f 94 c1          	sete   r9b
  1a2e91:	48 85 ff             	test   rdi,rdi
  1a2e94:	41 0f 94 c2          	sete   r10b
  1a2e98:	45 08 ca             	or     r10b,r9b
  1a2e9b:	48 b8 00 00 00 00 00 	movabs rax,0xfff0000000000000
  1a2ea2:	00 f0 ff 
  1a2ea5:	48 01 c7             	add    rdi,rax
  1a2ea8:	48 c1 ef 35          	shr    rdi,0x35
  1a2eac:	81 ff ff 03 00 00    	cmp    edi,0x3ff
  1a2eb2:	41 0f 92 c1          	setb   r9b
  1a2eb6:	45 08 d1             	or     r9b,r10b
  1a2eb9:	40 b7 3f             	mov    dil,0x3f
  1a2ebc:	c4 c2 c0 f5 f8       	bzhi   rdi,r8,rdi
  1a2ec1:	48 39 f7             	cmp    rdi,rsi
  1a2ec4:	41 0f 94 c0          	sete   r8b
  1a2ec8:	48 85 ff             	test   rdi,rdi
  1a2ecb:	41 0f 94 c2          	sete   r10b
  1a2ecf:	45 08 c2             	or     r10b,r8b
  1a2ed2:	48 01 c7             	add    rdi,rax
  1a2ed5:	48 c1 ef 35          	shr    rdi,0x35
  1a2ed9:	81 ff ff 03 00 00    	cmp    edi,0x3ff
  1a2edf:	40 0f 92 c7          	setb   dil
  1a2ee3:	44 08 d7             	or     dil,r10b
  1a2ee6:	44 20 cf             	and    dil,r9b
  1a2ee9:	83 7c 24 10 01       	cmp    DWORD PTR [rsp+0x10],0x1
  1a2eee:	0f 84 c7 03 00 00    	je     1a32bb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x19fb>
  1a2ef4:	4c 8b 84 24 a0 00 00 	mov    r8,QWORD PTR [rsp+0xa0]
  1a2efb:	00 
  1a2efc:	48 8b 84 24 d0 00 00 	mov    rax,QWORD PTR [rsp+0xd0]
  1a2f03:	00 
  1a2f04:	c4 21 7b 10 64 c0 08 	vmovsd xmm12,QWORD PTR [rax+r8*8+0x8]
  1a2f0b:	c4 41 79 28 ec       	vmovapd xmm13,xmm12
  1a2f10:	c4 42 81 a9 eb       	vfmadd213sd xmm13,xmm15,xmm11
  1a2f15:	4c 8b 84 24 80 00 00 	mov    r8,QWORD PTR [rsp+0x80]
  1a2f1c:	00 
  1a2f1d:	c4 01 7b 10 74 c6 08 	vmovsd xmm14,QWORD PTR [r14+r8*8+0x8]
  1a2f24:	48 8b b4 24 20 01 00 	mov    rsi,QWORD PTR [rsp+0x120]
  1a2f2b:	00 
  1a2f2c:	c4 42 89 a9 6c f3 08 	vfmadd213sd xmm13,xmm14,QWORD PTR [r11+rsi*8+0x8]
  1a2f33:	c4 42 f1 a9 e2       	vfmadd213sd xmm12,xmm1,xmm10
  1a2f38:	c4 42 91 a9 e6       	vfmadd213sd xmm12,xmm13,xmm14
  1a2f3d:	4c 8b 8c 24 e8 00 00 	mov    r9,QWORD PTR [rsp+0xe8]
  1a2f44:	00 
  1a2f45:	4c 8b 54 24 20       	mov    r10,QWORD PTR [rsp+0x20]
  1a2f4a:	c4 81 7b 10 44 ca 08 	vmovsd xmm0,QWORD PTR [r10+r9*8+0x8]
  1a2f51:	c4 c2 f9 b9 e5       	vfmadd231sd xmm4,xmm0,xmm13
  1a2f56:	c4 e2 89 b9 f8       	vfmadd231sd xmm7,xmm14,xmm0
  1a2f5b:	4c 8b 8c 24 f0 00 00 	mov    r9,QWORD PTR [rsp+0xf0]
  1a2f62:	00 
  1a2f63:	c4 81 7b 10 44 cf 08 	vmovsd xmm0,QWORD PTR [r15+r9*8+0x8]
  1a2f6a:	c4 c2 f9 b9 d5       	vfmadd231sd xmm2,xmm0,xmm13
  1a2f6f:	c4 e2 89 b9 f0       	vfmadd231sd xmm6,xmm14,xmm0
  1a2f74:	c4 a1 7b 10 44 c3 08 	vmovsd xmm0,QWORD PTR [rbx+r8*8+0x8]
  1a2f7b:	c4 c2 f9 b9 ed       	vfmadd231sd xmm5,xmm0,xmm13
  1a2f80:	c4 62 89 b9 c8       	vfmadd231sd xmm9,xmm14,xmm0
  1a2f85:	4c 8b 44 24 38       	mov    r8,QWORD PTR [rsp+0x38]
  1a2f8a:	4c 8b 8c 24 f8 00 00 	mov    r9,QWORD PTR [rsp+0xf8]
  1a2f91:	00 
  1a2f92:	c4 81 7b 10 44 c8 08 	vmovsd xmm0,QWORD PTR [r8+r9*8+0x8]
  1a2f99:	c4 42 f9 b9 c6       	vfmadd231sd xmm8,xmm0,xmm14
  1a2f9e:	c4 c2 f9 b9 dd       	vfmadd231sd xmm3,xmm0,xmm13
  1a2fa3:	c4 41 f9 7e e8       	vmovq  r8,xmm13
  1a2fa8:	4c 8b 8c 24 88 00 00 	mov    r9,QWORD PTR [rsp+0x88]
  1a2faf:	00 
  1a2fb0:	c4 01 7b 11 6c cd 08 	vmovsd QWORD PTR [r13+r9*8+0x8],xmm13
  1a2fb7:	c4 41 f9 7e e1       	vmovq  r9,xmm12
  1a2fbc:	c4 41 7b 11 64 f3 08 	vmovsd QWORD PTR [r11+rsi*8+0x8],xmm12
  1a2fc3:	40 b6 3f             	mov    sil,0x3f
  1a2fc6:	c4 42 c8 f5 c0       	bzhi   r8,r8,rsi
  1a2fcb:	48 b8 00 00 00 00 00 	movabs rax,0x7ff0000000000000
  1a2fd2:	00 f0 7f 
  1a2fd5:	49 39 c0             	cmp    r8,rax
  1a2fd8:	41 0f 94 c2          	sete   r10b
  1a2fdc:	4d 85 c0             	test   r8,r8
  1a2fdf:	0f 94 c3             	sete   bl
  1a2fe2:	44 08 d3             	or     bl,r10b
  1a2fe5:	49 bf 00 00 00 00 00 	movabs r15,0xfff0000000000000
  1a2fec:	00 f0 ff 
  1a2fef:	4d 01 f8             	add    r8,r15
  1a2ff2:	49 c1 e8 35          	shr    r8,0x35
  1a2ff6:	41 81 f8 ff 03 00 00 	cmp    r8d,0x3ff
  1a2ffd:	41 0f 92 c0          	setb   r8b
  1a3001:	41 08 d8             	or     r8b,bl
  1a3004:	c4 42 c8 f5 c9       	bzhi   r9,r9,rsi
  1a3009:	49 39 c1             	cmp    r9,rax
  1a300c:	41 0f 94 c2          	sete   r10b
  1a3010:	4d 85 c9             	test   r9,r9
  1a3013:	0f 94 c3             	sete   bl
  1a3016:	44 08 d3             	or     bl,r10b
  1a3019:	4d 01 f9             	add    r9,r15
  1a301c:	49 c1 e9 35          	shr    r9,0x35
  1a3020:	41 81 f9 ff 03 00 00 	cmp    r9d,0x3ff
  1a3027:	41 0f 92 c1          	setb   r9b
  1a302b:	41 08 d9             	or     r9b,bl
  1a302e:	45 20 c1             	and    r9b,r8b
  1a3031:	44 20 cf             	and    dil,r9b
  1a3034:	83 7c 24 10 02       	cmp    DWORD PTR [rsp+0x10],0x2
  1a3039:	0f 84 7c 02 00 00    	je     1a32bb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x19fb>
  1a303f:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
  1a3046:	00 
  1a3047:	4c 8b 84 24 a0 00 00 	mov    r8,QWORD PTR [rsp+0xa0]
  1a304e:	00 
  1a304f:	c4 21 7b 10 64 c6 10 	vmovsd xmm12,QWORD PTR [rsi+r8*8+0x10]
  1a3056:	c4 41 79 28 ec       	vmovapd xmm13,xmm12
  1a305b:	c4 42 81 a9 eb       	vfmadd213sd xmm13,xmm15,xmm11
  1a3060:	4c 8b 84 24 80 00 00 	mov    r8,QWORD PTR [rsp+0x80]
  1a3067:	00 
  1a3068:	c4 01 7b 10 74 c6 10 	vmovsd xmm14,QWORD PTR [r14+r8*8+0x10]
  1a306f:	48 8b b4 24 20 01 00 	mov    rsi,QWORD PTR [rsp+0x120]
  1a3076:	00 
  1a3077:	c4 42 89 a9 6c f3 10 	vfmadd213sd xmm13,xmm14,QWORD PTR [r11+rsi*8+0x10]
  1a307e:	c4 42 f1 a9 e2       	vfmadd213sd xmm12,xmm1,xmm10
  1a3083:	c4 42 91 a9 e6       	vfmadd213sd xmm12,xmm13,xmm14
  1a3088:	4c 8b 8c 24 e8 00 00 	mov    r9,QWORD PTR [rsp+0xe8]
  1a308f:	00 
  1a3090:	4c 8b 54 24 20       	mov    r10,QWORD PTR [rsp+0x20]
  1a3095:	c4 81 7b 10 44 ca 10 	vmovsd xmm0,QWORD PTR [r10+r9*8+0x10]
  1a309c:	c4 c2 f9 b9 e5       	vfmadd231sd xmm4,xmm0,xmm13
  1a30a1:	c4 e2 89 b9 f8       	vfmadd231sd xmm7,xmm14,xmm0
  1a30a6:	4c 8b 8c 24 f0 00 00 	mov    r9,QWORD PTR [rsp+0xf0]
  1a30ad:	00 
  1a30ae:	48 8b 44 24 60       	mov    rax,QWORD PTR [rsp+0x60]
  1a30b3:	c4 a1 7b 10 44 c8 10 	vmovsd xmm0,QWORD PTR [rax+r9*8+0x10]
  1a30ba:	c4 c2 f9 b9 d5       	vfmadd231sd xmm2,xmm0,xmm13
  1a30bf:	c4 e2 89 b9 f0       	vfmadd231sd xmm6,xmm14,xmm0
  1a30c4:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
  1a30c9:	c4 a1 7b 10 44 c0 10 	vmovsd xmm0,QWORD PTR [rax+r8*8+0x10]
  1a30d0:	c4 c2 f9 b9 ed       	vfmadd231sd xmm5,xmm0,xmm13
  1a30d5:	c4 62 89 b9 c8       	vfmadd231sd xmm9,xmm14,xmm0
  1a30da:	4c 8b 44 24 38       	mov    r8,QWORD PTR [rsp+0x38]
  1a30df:	4c 8b 8c 24 f8 00 00 	mov    r9,QWORD PTR [rsp+0xf8]
  1a30e6:	00 
  1a30e7:	c4 81 7b 10 44 c8 10 	vmovsd xmm0,QWORD PTR [r8+r9*8+0x10]
  1a30ee:	c4 42 f9 b9 c6       	vfmadd231sd xmm8,xmm0,xmm14
  1a30f3:	c4 c2 f9 b9 dd       	vfmadd231sd xmm3,xmm0,xmm13
  1a30f8:	c4 41 f9 7e e8       	vmovq  r8,xmm13
  1a30fd:	4c 8b 8c 24 88 00 00 	mov    r9,QWORD PTR [rsp+0x88]
  1a3104:	00 
  1a3105:	c4 01 7b 11 6c cd 10 	vmovsd QWORD PTR [r13+r9*8+0x10],xmm13
  1a310c:	c4 41 f9 7e e1       	vmovq  r9,xmm12
  1a3111:	c4 41 7b 11 64 f3 10 	vmovsd QWORD PTR [r11+rsi*8+0x10],xmm12
  1a3118:	40 b6 3f             	mov    sil,0x3f
  1a311b:	c4 42 c8 f5 c0       	bzhi   r8,r8,rsi
  1a3120:	48 b8 00 00 00 00 00 	movabs rax,0x7ff0000000000000
  1a3127:	00 f0 7f 
  1a312a:	49 39 c0             	cmp    r8,rax
  1a312d:	41 0f 94 c2          	sete   r10b
  1a3131:	4d 85 c0             	test   r8,r8
  1a3134:	0f 94 c3             	sete   bl
  1a3137:	44 08 d3             	or     bl,r10b
  1a313a:	4d 01 f8             	add    r8,r15
  1a313d:	49 c1 e8 35          	shr    r8,0x35
  1a3141:	41 81 f8 ff 03 00 00 	cmp    r8d,0x3ff
  1a3148:	41 0f 92 c0          	setb   r8b
  1a314c:	41 08 d8             	or     r8b,bl
  1a314f:	c4 42 c8 f5 c9       	bzhi   r9,r9,rsi
  1a3154:	49 39 c1             	cmp    r9,rax
  1a3157:	41 0f 94 c2          	sete   r10b
  1a315b:	4d 85 c9             	test   r9,r9
  1a315e:	0f 94 c3             	sete   bl
  1a3161:	44 08 d3             	or     bl,r10b
  1a3164:	4d 01 f9             	add    r9,r15
  1a3167:	49 c1 e9 35          	shr    r9,0x35
  1a316b:	41 81 f9 ff 03 00 00 	cmp    r9d,0x3ff
  1a3172:	41 0f 92 c1          	setb   r9b
  1a3176:	41 08 d9             	or     r9b,bl
  1a3179:	45 20 c1             	and    r9b,r8b
  1a317c:	44 20 cf             	and    dil,r9b
  1a317f:	83 7c 24 10 03       	cmp    DWORD PTR [rsp+0x10],0x3
  1a3184:	0f 84 31 01 00 00    	je     1a32bb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x19fb>
  1a318a:	48 8b b4 24 d0 00 00 	mov    rsi,QWORD PTR [rsp+0xd0]
  1a3191:	00 
  1a3192:	4c 8b 84 24 a0 00 00 	mov    r8,QWORD PTR [rsp+0xa0]
  1a3199:	00 
  1a319a:	c4 a1 7b 10 44 c6 18 	vmovsd xmm0,QWORD PTR [rsi+r8*8+0x18]
  1a31a1:	c4 42 f9 a9 fb       	vfmadd213sd xmm15,xmm0,xmm11
  1a31a6:	48 8b b4 24 80 00 00 	mov    rsi,QWORD PTR [rsp+0x80]
  1a31ad:	00 
  1a31ae:	c4 41 7b 10 5c f6 18 	vmovsd xmm11,QWORD PTR [r14+rsi*8+0x18]
  1a31b5:	4c 8b b4 24 20 01 00 	mov    r14,QWORD PTR [rsp+0x120]
  1a31bc:	00 
  1a31bd:	c4 02 a1 a9 7c f3 18 	vfmadd213sd xmm15,xmm11,QWORD PTR [r11+r14*8+0x18]
  1a31c4:	c4 41 f9 7e f8       	vmovq  r8,xmm15
  1a31c9:	b3 3f                	mov    bl,0x3f
  1a31cb:	c4 42 e0 f5 c0       	bzhi   r8,r8,rbx
  1a31d0:	49 39 c0             	cmp    r8,rax
  1a31d3:	41 0f 94 c1          	sete   r9b
  1a31d7:	4d 85 c0             	test   r8,r8
  1a31da:	41 0f 94 c2          	sete   r10b
  1a31de:	45 08 ca             	or     r10b,r9b
  1a31e1:	4d 01 f8             	add    r8,r15
  1a31e4:	49 c1 e8 35          	shr    r8,0x35
  1a31e8:	41 81 f8 ff 03 00 00 	cmp    r8d,0x3ff
  1a31ef:	41 0f 92 c1          	setb   r9b
  1a31f3:	45 08 d1             	or     r9b,r10b
  1a31f6:	c4 c2 f9 a9 ca       	vfmadd213sd xmm1,xmm0,xmm10
  1a31fb:	c4 c2 81 a9 cb       	vfmadd213sd xmm1,xmm15,xmm11
  1a3200:	c4 c1 f9 7e c8       	vmovq  r8,xmm1
  1a3205:	c4 42 e0 f5 c0       	bzhi   r8,r8,rbx
  1a320a:	49 39 c0             	cmp    r8,rax
  1a320d:	41 0f 94 c2          	sete   r10b
  1a3211:	4d 85 c0             	test   r8,r8
  1a3214:	0f 94 c3             	sete   bl
  1a3217:	44 08 d3             	or     bl,r10b
  1a321a:	4d 01 f8             	add    r8,r15
  1a321d:	49 c1 e8 35          	shr    r8,0x35
  1a3221:	41 81 f8 ff 03 00 00 	cmp    r8d,0x3ff
  1a3228:	48 8b 84 24 e8 00 00 	mov    rax,QWORD PTR [rsp+0xe8]
  1a322f:	00 
  1a3230:	4c 8b 44 24 20       	mov    r8,QWORD PTR [rsp+0x20]
  1a3235:	c4 c1 7b 10 44 c0 18 	vmovsd xmm0,QWORD PTR [r8+rax*8+0x18]
  1a323c:	c5 79 28 e9          	vmovapd xmm13,xmm1
  1a3240:	48 8b 84 24 f0 00 00 	mov    rax,QWORD PTR [rsp+0xf0]
  1a3247:	00 
  1a3248:	4c 8b 7c 24 60       	mov    r15,QWORD PTR [rsp+0x60]
  1a324d:	c4 c1 7b 10 4c c7 18 	vmovsd xmm1,QWORD PTR [r15+rax*8+0x18]
  1a3254:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
  1a3259:	c5 7b 10 54 f0 18    	vmovsd xmm10,QWORD PTR [rax+rsi*8+0x18]
  1a325f:	48 8b 44 24 38       	mov    rax,QWORD PTR [rsp+0x38]
  1a3264:	48 8b b4 24 f8 00 00 	mov    rsi,QWORD PTR [rsp+0xf8]
  1a326b:	00 
  1a326c:	c5 7b 10 64 f0 18    	vmovsd xmm12,QWORD PTR [rax+rsi*8+0x18]
  1a3272:	48 8b 84 24 88 00 00 	mov    rax,QWORD PTR [rsp+0x88]
  1a3279:	00 
  1a327a:	c4 41 7b 11 7c c5 18 	vmovsd QWORD PTR [r13+rax*8+0x18],xmm15
  1a3281:	c4 01 7b 11 6c f3 18 	vmovsd QWORD PTR [r11+r14*8+0x18],xmm13
  1a3288:	0f 92 c0             	setb   al
  1a328b:	08 d8                	or     al,bl
  1a328d:	44 20 c8             	and    al,r9b
  1a3290:	40 20 c7             	and    dil,al
  1a3293:	c4 c2 f9 b9 e7       	vfmadd231sd xmm4,xmm0,xmm15
  1a3298:	c4 c2 f1 b9 d7       	vfmadd231sd xmm2,xmm1,xmm15
  1a329d:	c4 c2 a9 b9 ef       	vfmadd231sd xmm5,xmm10,xmm15
  1a32a2:	c4 c2 99 b9 df       	vfmadd231sd xmm3,xmm12,xmm15
  1a32a7:	c4 e2 a1 b9 f8       	vfmadd231sd xmm7,xmm11,xmm0
  1a32ac:	c4 e2 a1 b9 f1       	vfmadd231sd xmm6,xmm11,xmm1
  1a32b1:	c4 42 a1 b9 ca       	vfmadd231sd xmm9,xmm11,xmm10
  1a32b6:	c4 42 99 b9 c3       	vfmadd231sd xmm8,xmm12,xmm11
  1a32bb:	4c 8b b4 24 e0 00 00 	mov    r14,QWORD PTR [rsp+0xe0]
  1a32c2:	00 
  1a32c3:	40 20 7c 24 07       	and    BYTE PTR [rsp+0x7],dil
  1a32c8:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
  1a32cd:	4c 8b 44 24 40       	mov    r8,QWORD PTR [rsp+0x40]
  1a32d2:	4c 8b 94 24 a8 00 00 	mov    r10,QWORD PTR [rsp+0xa8]
  1a32d9:	00 
  1a32da:	eb 15                	jmp    1a32f1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1a31>
  1a32dc:	48 8b 44 24 08       	mov    rax,QWORD PTR [rsp+0x8]
  1a32e1:	4c 8b 94 24 a8 00 00 	mov    r10,QWORD PTR [rsp+0xa8]
  1a32e8:	00 
  1a32e9:	4c 8b b4 24 e0 00 00 	mov    r14,QWORD PTR [rsp+0xe0]
  1a32f0:	00 
  1a32f1:	4f 8d 0c 00          	lea    r9,[r8+r8*1]
  1a32f5:	49 39 c1             	cmp    r9,rax
  1a32f8:	0f 83 d5 0f 00 00    	jae    1a42d3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2a13>
  1a32fe:	4c 89 cb             	mov    rbx,r9
  1a3301:	48 c1 e3 04          	shl    rbx,0x4
  1a3305:	48 8b bc 24 c8 00 00 	mov    rdi,QWORD PTR [rsp+0xc8]
  1a330c:	00 
  1a330d:	c5 7b 11 04 1f       	vmovsd QWORD PTR [rdi+rbx*1],xmm8
  1a3312:	48 8b 84 24 30 01 00 	mov    rax,QWORD PTR [rsp+0x130]
  1a3319:	00 
  1a331a:	4a 8d 34 40          	lea    rsi,[rax+r8*2]
  1a331e:	c5 7b 11 4c 1f 08    	vmovsd QWORD PTR [rdi+rbx*1+0x8],xmm9
  1a3324:	48 3b 74 24 68       	cmp    rsi,QWORD PTR [rsp+0x68]
  1a3329:	73 26                	jae    1a3351 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1a91>
  1a332b:	49 8d 41 01          	lea    rax,[r9+0x1]
  1a332f:	48 3b 44 24 08       	cmp    rax,QWORD PTR [rsp+0x8]
  1a3334:	0f 83 e1 0f 00 00    	jae    1a431b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2a5b>
  1a333a:	48 c1 e0 04          	shl    rax,0x4
  1a333e:	48 8b bc 24 c8 00 00 	mov    rdi,QWORD PTR [rsp+0xc8]
  1a3345:	00 
  1a3346:	c5 fb 11 34 07       	vmovsd QWORD PTR [rdi+rax*1],xmm6
  1a334b:	c5 fb 11 7c 07 08    	vmovsd QWORD PTR [rdi+rax*1+0x8],xmm7
  1a3351:	48 89 9c 24 60 01 00 	mov    QWORD PTR [rsp+0x160],rbx
  1a3358:	00 
  1a3359:	48 89 74 24 40       	mov    QWORD PTR [rsp+0x40],rsi
  1a335e:	48 8d 7e 02          	lea    rdi,[rsi+0x2]
  1a3362:	49 89 ff             	mov    r15,rdi
  1a3365:	4c 2b bc 24 30 01 00 	sub    r15,QWORD PTR [rsp+0x130]
  1a336c:	00 
  1a336d:	4c 3b 7c 24 08       	cmp    r15,QWORD PTR [rsp+0x8]
  1a3372:	0f 83 8b 0f 00 00    	jae    1a4303 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2a43>
  1a3378:	4c 89 fb             	mov    rbx,r15
  1a337b:	48 c1 e3 04          	shl    rbx,0x4
  1a337f:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
  1a3386:	00 
  1a3387:	c5 fb 11 1c 18       	vmovsd QWORD PTR [rax+rbx*1],xmm3
  1a338c:	48 89 9c 24 50 01 00 	mov    QWORD PTR [rsp+0x150],rbx
  1a3393:	00 
  1a3394:	c5 fb 11 6c 18 08    	vmovsd QWORD PTR [rax+rbx*1+0x8],xmm5
  1a339a:	48 3b 7c 24 68       	cmp    rdi,QWORD PTR [rsp+0x68]
  1a339f:	4c 89 f6             	mov    rsi,r14
  1a33a2:	4c 8b b4 24 90 00 00 	mov    r14,QWORD PTR [rsp+0x90]
  1a33a9:	00 
  1a33aa:	73 45                	jae    1a33f1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1b31>
  1a33ac:	49 8d 47 01          	lea    rax,[r15+0x1]
  1a33b0:	48 3b 44 24 08       	cmp    rax,QWORD PTR [rsp+0x8]
  1a33b5:	0f 83 60 0f 00 00    	jae    1a431b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2a5b>
  1a33bb:	4c 89 cb             	mov    rbx,r9
  1a33be:	4d 89 c1             	mov    r9,r8
  1a33c1:	48 c1 e0 04          	shl    rax,0x4
  1a33c5:	4c 8b 84 24 c8 00 00 	mov    r8,QWORD PTR [rsp+0xc8]
  1a33cc:	00 
  1a33cd:	c4 c1 7b 11 14 00    	vmovsd QWORD PTR [r8+rax*1],xmm2
  1a33d3:	c4 c1 7b 11 64 00 08 	vmovsd QWORD PTR [r8+rax*1+0x8],xmm4
  1a33da:	4d 89 c8             	mov    r8,r9
  1a33dd:	4c 8b 94 24 a8 00 00 	mov    r10,QWORD PTR [rsp+0xa8]
  1a33e4:	00 
  1a33e5:	49 89 d9             	mov    r9,rbx
  1a33e8:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
  1a33ed:	48 8d 78 02          	lea    rdi,[rax+0x2]
  1a33f1:	c5 f9 57 c0          	vxorpd xmm0,xmm0,xmm0
  1a33f5:	48 8b 84 24 b0 00 00 	mov    rax,QWORD PTR [rsp+0xb0]
  1a33fc:	00 
  1a33fd:	48 85 c0             	test   rax,rax
  1a3400:	74 29                	je     1a342b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1b6b>
  1a3402:	48 83 f8 01          	cmp    rax,0x1
  1a3406:	75 44                	jne    1a344c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1b8c>
  1a3408:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
  1a340c:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
  1a3410:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
  1a3414:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  1a3418:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  1a341c:	31 c0                	xor    eax,eax
  1a341e:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  1a3422:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  1a3426:	e9 18 01 00 00       	jmp    1a3543 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1c83>
  1a342b:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
  1a342f:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
  1a3433:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
  1a3437:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  1a343b:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  1a343f:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  1a3443:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  1a3447:	e9 46 01 00 00       	jmp    1a3592 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1cd2>
  1a344c:	4c 89 8c 24 40 01 00 	mov    QWORD PTR [rsp+0x140],r9
  1a3453:	00 
  1a3454:	41 b9 20 00 00 00    	mov    r9d,0x20
  1a345a:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
  1a345e:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
  1a3462:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
  1a3466:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  1a346a:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  1a346e:	31 c0                	xor    eax,eax
  1a3470:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  1a3474:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  1a3478:	c4 21 7d 10 44 09 e0 	vmovupd ymm8,YMMWORD PTR [rcx+r9*1-0x20]
  1a347f:	c4 01 7d 10 4c 0e e0 	vmovupd ymm9,YMMWORD PTR [r14+r9*1-0x20]
  1a3486:	c4 c2 bd b8 f9       	vfmadd231pd ymm7,ymm8,ymm9
  1a348b:	c4 21 7d 10 54 0a e0 	vmovupd ymm10,YMMWORD PTR [rdx+r9*1-0x20]
  1a3492:	c4 c2 ad b8 f1       	vfmadd231pd ymm6,ymm10,ymm9
  1a3497:	c4 21 7d 10 5c 0d e0 	vmovupd ymm11,YMMWORD PTR [rbp+r9*1-0x20]
  1a349e:	c4 c2 a5 b8 e1       	vfmadd231pd ymm4,ymm11,ymm9
  1a34a3:	c4 01 7d 10 64 0c e0 	vmovupd ymm12,YMMWORD PTR [r12+r9*1-0x20]
  1a34aa:	c4 c2 9d b8 d9       	vfmadd231pd ymm3,ymm12,ymm9
  1a34af:	c4 01 7d 10 4c 0d e0 	vmovupd ymm9,YMMWORD PTR [r13+r9*1-0x20]
  1a34b6:	c4 c2 b5 b8 e8       	vfmadd231pd ymm5,ymm9,ymm8
  1a34bb:	c4 21 7d 10 04 09    	vmovupd ymm8,YMMWORD PTR [rcx+r9*1]
  1a34c1:	c4 c2 b5 b8 d2       	vfmadd231pd ymm2,ymm9,ymm10
  1a34c6:	c4 01 7d 10 14 0e    	vmovupd ymm10,YMMWORD PTR [r14+r9*1]
  1a34cc:	c4 c2 b5 b8 cb       	vfmadd231pd ymm1,ymm9,ymm11
  1a34d1:	c4 21 7d 10 1c 0a    	vmovupd ymm11,YMMWORD PTR [rdx+r9*1]
  1a34d7:	c4 c2 9d b8 c1       	vfmadd231pd ymm0,ymm12,ymm9
  1a34dc:	c4 21 7d 10 4c 0d 00 	vmovupd ymm9,YMMWORD PTR [rbp+r9*1+0x0]
  1a34e3:	c4 01 7d 10 24 0c    	vmovupd ymm12,YMMWORD PTR [r12+r9*1]
  1a34e9:	c4 c2 bd b8 fa       	vfmadd231pd ymm7,ymm8,ymm10
  1a34ee:	c4 c2 a5 b8 f2       	vfmadd231pd ymm6,ymm11,ymm10
  1a34f3:	c4 c2 b5 b8 e2       	vfmadd231pd ymm4,ymm9,ymm10
  1a34f8:	c4 c2 9d b8 da       	vfmadd231pd ymm3,ymm12,ymm10
  1a34fd:	c4 01 7d 10 54 0d 00 	vmovupd ymm10,YMMWORD PTR [r13+r9*1+0x0]
  1a3504:	c4 c2 ad b8 e8       	vfmadd231pd ymm5,ymm10,ymm8
  1a3509:	c4 c2 ad b8 d3       	vfmadd231pd ymm2,ymm10,ymm11
  1a350e:	c4 c2 ad b8 c9       	vfmadd231pd ymm1,ymm10,ymm9
  1a3513:	c4 c2 9d b8 c2       	vfmadd231pd ymm0,ymm12,ymm10
  1a3518:	48 83 c0 02          	add    rax,0x2
  1a351c:	49 83 c1 40          	add    r9,0x40
  1a3520:	48 39 c6             	cmp    rsi,rax
  1a3523:	0f 85 4f ff ff ff    	jne    1a3478 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1bb8>
  1a3529:	f6 84 24 b0 00 00 00 	test   BYTE PTR [rsp+0xb0],0x1
  1a3530:	01 
  1a3531:	4c 8b 94 24 a8 00 00 	mov    r10,QWORD PTR [rsp+0xa8]
  1a3538:	00 
  1a3539:	4c 8b 8c 24 40 01 00 	mov    r9,QWORD PTR [rsp+0x140]
  1a3540:	00 
  1a3541:	74 4f                	je     1a3592 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1cd2>
  1a3543:	48 c1 e0 05          	shl    rax,0x5
  1a3547:	c5 7d 10 04 01       	vmovupd ymm8,YMMWORD PTR [rcx+rax*1]
  1a354c:	c4 41 7d 10 0c 06    	vmovupd ymm9,YMMWORD PTR [r14+rax*1]
  1a3552:	c4 c2 bd b8 f9       	vfmadd231pd ymm7,ymm8,ymm9
  1a3557:	c5 7d 10 14 02       	vmovupd ymm10,YMMWORD PTR [rdx+rax*1]
  1a355c:	c4 c2 ad b8 f1       	vfmadd231pd ymm6,ymm10,ymm9
  1a3561:	c5 7d 10 5c 05 00    	vmovupd ymm11,YMMWORD PTR [rbp+rax*1+0x0]
  1a3567:	c4 c2 a5 b8 e1       	vfmadd231pd ymm4,ymm11,ymm9
  1a356c:	c4 41 7d 10 24 04    	vmovupd ymm12,YMMWORD PTR [r12+rax*1]
  1a3572:	c4 c2 9d b8 d9       	vfmadd231pd ymm3,ymm12,ymm9
  1a3577:	c4 41 7d 10 4c 05 00 	vmovupd ymm9,YMMWORD PTR [r13+rax*1+0x0]
  1a357e:	c4 c2 b5 b8 e8       	vfmadd231pd ymm5,ymm9,ymm8
  1a3583:	c4 c2 b5 b8 d2       	vfmadd231pd ymm2,ymm9,ymm10
  1a3588:	c4 c2 b5 b8 cb       	vfmadd231pd ymm1,ymm9,ymm11
  1a358d:	c4 c2 9d b8 c1       	vfmadd231pd ymm0,ymm12,ymm9
  1a3592:	c4 c3 7d 19 f8 01    	vextractf128 xmm8,ymm7,0x1
  1a3598:	c5 b9 58 ff          	vaddpd xmm7,xmm8,xmm7
  1a359c:	c5 41 c6 c7 01       	vshufpd xmm8,xmm7,xmm7,0x1
  1a35a1:	c5 bb 58 ff          	vaddsd xmm7,xmm8,xmm7
  1a35a5:	c4 c3 7d 19 f0 01    	vextractf128 xmm8,ymm6,0x1
  1a35ab:	c5 b9 58 f6          	vaddpd xmm6,xmm8,xmm6
  1a35af:	c5 49 c6 c6 01       	vshufpd xmm8,xmm6,xmm6,0x1
  1a35b4:	c5 3b 58 c6          	vaddsd xmm8,xmm8,xmm6
  1a35b8:	c4 e3 7d 19 e6 01    	vextractf128 xmm6,ymm4,0x1
  1a35be:	c5 d9 58 e6          	vaddpd xmm4,xmm4,xmm6
  1a35c2:	c5 d9 c6 f4 01       	vshufpd xmm6,xmm4,xmm4,0x1
  1a35c7:	c5 db 58 e6          	vaddsd xmm4,xmm4,xmm6
  1a35cb:	c4 e3 7d 19 de 01    	vextractf128 xmm6,ymm3,0x1
  1a35d1:	c5 e1 58 de          	vaddpd xmm3,xmm3,xmm6
  1a35d5:	c5 e1 c6 f3 01       	vshufpd xmm6,xmm3,xmm3,0x1
  1a35da:	c5 e3 58 f6          	vaddsd xmm6,xmm3,xmm6
  1a35de:	c4 e3 7d 19 eb 01    	vextractf128 xmm3,ymm5,0x1
  1a35e4:	c5 d1 58 db          	vaddpd xmm3,xmm5,xmm3
  1a35e8:	c5 e1 c6 eb 01       	vshufpd xmm5,xmm3,xmm3,0x1
  1a35ed:	c5 e3 58 dd          	vaddsd xmm3,xmm3,xmm5
  1a35f1:	c4 e3 7d 19 d5 01    	vextractf128 xmm5,ymm2,0x1
  1a35f7:	c5 e9 58 d5          	vaddpd xmm2,xmm2,xmm5
  1a35fb:	c5 e9 c6 ea 01       	vshufpd xmm5,xmm2,xmm2,0x1
  1a3600:	c5 eb 58 d5          	vaddsd xmm2,xmm2,xmm5
  1a3604:	c4 e3 7d 19 cd 01    	vextractf128 xmm5,ymm1,0x1
  1a360a:	c5 f1 58 cd          	vaddpd xmm1,xmm1,xmm5
  1a360e:	c5 f1 c6 e9 01       	vshufpd xmm5,xmm1,xmm1,0x1
  1a3613:	c5 f3 58 cd          	vaddsd xmm1,xmm1,xmm5
  1a3617:	c4 e3 7d 19 c5 01    	vextractf128 xmm5,ymm0,0x1
  1a361d:	c5 f9 58 c5          	vaddpd xmm0,xmm0,xmm5
  1a3621:	c5 f9 c6 e8 01       	vshufpd xmm5,xmm0,xmm0,0x1
  1a3626:	c5 fb 58 c5          	vaddsd xmm0,xmm0,xmm5
  1a362a:	4d 85 d2             	test   r10,r10
  1a362d:	0f 84 35 01 00 00    	je     1a3768 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1ea8>
  1a3633:	48 8b 84 24 98 01 00 	mov    rax,QWORD PTR [rsp+0x198]
  1a363a:	00 
  1a363b:	48 39 44 24 10       	cmp    QWORD PTR [rsp+0x10],rax
  1a3640:	48 8b 84 24 80 00 00 	mov    rax,QWORD PTR [rsp+0x80]
  1a3647:	00 
  1a3648:	0f 86 21 0d 00 00    	jbe    1a436f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2aaf>
  1a364e:	4c 89 cb             	mov    rbx,r9
  1a3651:	48 8b b4 24 10 01 00 	mov    rsi,QWORD PTR [rsp+0x110]
  1a3658:	00 
  1a3659:	c5 fb 10 2c f1       	vmovsd xmm5,QWORD PTR [rcx+rsi*8]
  1a365e:	c4 41 7b 10 0c c6    	vmovsd xmm9,QWORD PTR [r14+rax*8]
  1a3664:	c4 c2 d1 b9 f9       	vfmadd231sd xmm7,xmm5,xmm9
  1a3669:	c5 7b 10 14 f2       	vmovsd xmm10,QWORD PTR [rdx+rsi*8]
  1a366e:	c4 42 a9 b9 c1       	vfmadd231sd xmm8,xmm10,xmm9
  1a3673:	c5 7b 10 5c f5 00    	vmovsd xmm11,QWORD PTR [rbp+rsi*8+0x0]
  1a3679:	c4 c2 a1 b9 e1       	vfmadd231sd xmm4,xmm11,xmm9
  1a367e:	c4 41 7b 10 24 f4    	vmovsd xmm12,QWORD PTR [r12+rsi*8]
  1a3684:	c4 c2 99 b9 f1       	vfmadd231sd xmm6,xmm12,xmm9
  1a3689:	4c 8b 8c 24 88 00 00 	mov    r9,QWORD PTR [rsp+0x88]
  1a3690:	00 
  1a3691:	c4 01 7b 10 4c cd 00 	vmovsd xmm9,QWORD PTR [r13+r9*8+0x0]
  1a3698:	c4 e2 b1 b9 dd       	vfmadd231sd xmm3,xmm9,xmm5
  1a369d:	c4 c2 b1 b9 d2       	vfmadd231sd xmm2,xmm9,xmm10
  1a36a2:	c4 c2 b1 b9 cb       	vfmadd231sd xmm1,xmm9,xmm11
  1a36a7:	c4 c2 99 b9 c1       	vfmadd231sd xmm0,xmm12,xmm9
  1a36ac:	41 83 fa 01          	cmp    r10d,0x1
  1a36b0:	0f 84 a4 00 00 00    	je     1a375a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1e9a>
  1a36b6:	c5 fb 10 6c f1 08    	vmovsd xmm5,QWORD PTR [rcx+rsi*8+0x8]
  1a36bc:	c4 41 7b 10 4c c6 08 	vmovsd xmm9,QWORD PTR [r14+rax*8+0x8]
  1a36c3:	c4 c2 d1 b9 f9       	vfmadd231sd xmm7,xmm5,xmm9
  1a36c8:	c5 7b 10 54 f2 08    	vmovsd xmm10,QWORD PTR [rdx+rsi*8+0x8]
  1a36ce:	c4 42 a9 b9 c1       	vfmadd231sd xmm8,xmm10,xmm9
  1a36d3:	c5 7b 10 5c f5 08    	vmovsd xmm11,QWORD PTR [rbp+rsi*8+0x8]
  1a36d9:	c4 c2 a1 b9 e1       	vfmadd231sd xmm4,xmm11,xmm9
  1a36de:	c4 41 7b 10 64 f4 08 	vmovsd xmm12,QWORD PTR [r12+rsi*8+0x8]
  1a36e5:	c4 c2 99 b9 f1       	vfmadd231sd xmm6,xmm12,xmm9
  1a36ea:	c4 01 7b 10 4c cd 08 	vmovsd xmm9,QWORD PTR [r13+r9*8+0x8]
  1a36f1:	c4 e2 b1 b9 dd       	vfmadd231sd xmm3,xmm9,xmm5
  1a36f6:	c4 c2 b1 b9 d2       	vfmadd231sd xmm2,xmm9,xmm10
  1a36fb:	c4 c2 b1 b9 cb       	vfmadd231sd xmm1,xmm9,xmm11
  1a3700:	c4 c2 99 b9 c1       	vfmadd231sd xmm0,xmm12,xmm9
  1a3705:	41 83 fa 02          	cmp    r10d,0x2
  1a3709:	74 4f                	je     1a375a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1e9a>
  1a370b:	c5 fb 10 6c f1 10    	vmovsd xmm5,QWORD PTR [rcx+rsi*8+0x10]
  1a3711:	c4 41 7b 10 4c c6 10 	vmovsd xmm9,QWORD PTR [r14+rax*8+0x10]
  1a3718:	c4 c2 d1 b9 f9       	vfmadd231sd xmm7,xmm5,xmm9
  1a371d:	c5 7b 10 54 f2 10    	vmovsd xmm10,QWORD PTR [rdx+rsi*8+0x10]
  1a3723:	c4 42 a9 b9 c1       	vfmadd231sd xmm8,xmm10,xmm9
  1a3728:	c5 7b 10 5c f5 10    	vmovsd xmm11,QWORD PTR [rbp+rsi*8+0x10]
  1a372e:	c4 c2 a1 b9 e1       	vfmadd231sd xmm4,xmm11,xmm9
  1a3733:	c4 41 7b 10 64 f4 10 	vmovsd xmm12,QWORD PTR [r12+rsi*8+0x10]
  1a373a:	c4 c2 99 b9 f1       	vfmadd231sd xmm6,xmm12,xmm9
  1a373f:	c4 01 7b 10 4c cd 10 	vmovsd xmm9,QWORD PTR [r13+r9*8+0x10]
  1a3746:	c4 e2 b1 b9 dd       	vfmadd231sd xmm3,xmm9,xmm5
  1a374b:	c4 c2 b1 b9 d2       	vfmadd231sd xmm2,xmm9,xmm10
  1a3750:	c4 c2 b1 b9 cb       	vfmadd231sd xmm1,xmm9,xmm11
  1a3755:	c4 c2 99 b9 c1       	vfmadd231sd xmm0,xmm12,xmm9
  1a375a:	49 89 d9             	mov    r9,rbx
  1a375d:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
  1a3762:	48 8d 78 02          	lea    rdi,[rax+0x2]
  1a3766:	eb 05                	jmp    1a376d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1ead>
  1a3768:	48 8b 44 24 40       	mov    rax,QWORD PTR [rsp+0x40]
  1a376d:	4c 3b 4c 24 18       	cmp    r9,QWORD PTR [rsp+0x18]
  1a3772:	0f 83 43 0b 00 00    	jae    1a42bb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x29fb>
  1a3778:	48 89 c3             	mov    rbx,rax
  1a377b:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
  1a3782:	00 
  1a3783:	4c 8b 94 24 60 01 00 	mov    r10,QWORD PTR [rsp+0x160]
  1a378a:	00 
  1a378b:	c4 a1 7b 11 3c 10    	vmovsd QWORD PTR [rax+r10*1],xmm7
  1a3791:	c4 21 7b 11 44 10 08 	vmovsd QWORD PTR [rax+r10*1+0x8],xmm8
  1a3798:	48 3b 5c 24 68       	cmp    rbx,QWORD PTR [rsp+0x68]
  1a379d:	73 27                	jae    1a37c6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1f06>
  1a379f:	49 ff c1             	inc    r9
  1a37a2:	4c 3b 4c 24 18       	cmp    r9,QWORD PTR [rsp+0x18]
  1a37a7:	0f 83 da 0b 00 00    	jae    1a4387 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2ac7>
  1a37ad:	49 c1 e1 04          	shl    r9,0x4
  1a37b1:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
  1a37b8:	00 
  1a37b9:	c4 a1 7b 11 24 08    	vmovsd QWORD PTR [rax+r9*1],xmm4
  1a37bf:	c4 a1 7b 11 74 08 08 	vmovsd QWORD PTR [rax+r9*1+0x8],xmm6
  1a37c6:	4c 3b 7c 24 18       	cmp    r15,QWORD PTR [rsp+0x18]
  1a37cb:	0f 83 1a 0b 00 00    	jae    1a42eb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2a2b>
  1a37d1:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
  1a37d8:	00 
  1a37d9:	4c 8b 8c 24 50 01 00 	mov    r9,QWORD PTR [rsp+0x150]
  1a37e0:	00 
  1a37e1:	c4 a1 7b 11 1c 08    	vmovsd QWORD PTR [rax+r9*1],xmm3
  1a37e7:	c4 a1 7b 11 54 08 08 	vmovsd QWORD PTR [rax+r9*1+0x8],xmm2
  1a37ee:	48 3b 7c 24 68       	cmp    rdi,QWORD PTR [rsp+0x68]
  1a37f3:	0f 83 71 f2 ff ff    	jae    1a2a6a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x11aa>
  1a37f9:	49 ff c7             	inc    r15
  1a37fc:	4c 3b 7c 24 18       	cmp    r15,QWORD PTR [rsp+0x18]
  1a3801:	0f 83 98 0b 00 00    	jae    1a439f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2adf>
  1a3807:	49 c1 e7 04          	shl    r15,0x4
  1a380b:	48 8b 84 24 00 01 00 	mov    rax,QWORD PTR [rsp+0x100]
  1a3812:	00 
  1a3813:	c4 a1 7b 11 0c 38    	vmovsd QWORD PTR [rax+r15*1],xmm1
  1a3819:	c4 a1 7b 11 44 38 08 	vmovsd QWORD PTR [rax+r15*1+0x8],xmm0
  1a3820:	e9 45 f2 ff ff       	jmp    1a2a6a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x11aa>
  1a3825:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  1a382a:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  1a382e:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  1a3832:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  1a3836:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  1a383a:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
  1a383e:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
  1a3842:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
  1a3846:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
  1a384b:	e9 3e 01 00 00       	jmp    1a398e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x20ce>
  1a3850:	4c 89 d0             	mov    rax,r10
  1a3853:	49 b8 fe ff ff ff ff 	movabs r8,0x1ffffffffffffffe
  1a385a:	ff ff 1f 
  1a385d:	4c 21 c0             	and    rax,r8
  1a3860:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
  1a3864:	bb 60 00 00 00       	mov    ebx,0x60
  1a3869:	45 31 c9             	xor    r9d,r9d
  1a386c:	c5 e1 57 db          	vxorpd xmm3,xmm3,xmm3
  1a3870:	c5 e9 57 d2          	vxorpd xmm2,xmm2,xmm2
  1a3874:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  1a3878:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  1a387c:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  1a3880:	c5 d9 57 e4          	vxorpd xmm4,xmm4,xmm4
  1a3884:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  1a3889:	4d 89 f8             	mov    r8,r15
  1a388c:	4c 8b 7c 24 30       	mov    r15,QWORD PTR [rsp+0x30]
  1a3891:	4c 8b 74 24 20       	mov    r14,QWORD PTR [rsp+0x20]
  1a3896:	c4 41 7d 10 4c 1b a0 	vmovupd ymm9,YMMWORD PTR [r11+rbx*1-0x60]
  1a389d:	c4 41 7d 10 54 1b c0 	vmovupd ymm10,YMMWORD PTR [r11+rbx*1-0x40]
  1a38a4:	c4 41 7d 10 5c 1b e0 	vmovupd ymm11,YMMWORD PTR [r11+rbx*1-0x20]
  1a38ab:	c4 e2 b5 b8 64 1e a0 	vfmadd231pd ymm4,ymm9,YMMWORD PTR [rsi+rbx*1-0x60]
  1a38b2:	c4 c2 b5 b8 6c 1f a0 	vfmadd231pd ymm5,ymm9,YMMWORD PTR [r15+rbx*1-0x60]
  1a38b9:	c4 c2 b5 b8 74 18 a0 	vfmadd231pd ymm6,ymm9,YMMWORD PTR [r8+rbx*1-0x60]
  1a38c0:	c4 c2 b5 b8 7c 1e a0 	vfmadd231pd ymm7,ymm9,YMMWORD PTR [r14+rbx*1-0x60]
  1a38c7:	c4 e2 ad b8 54 1e c0 	vfmadd231pd ymm2,ymm10,YMMWORD PTR [rsi+rbx*1-0x40]
  1a38ce:	c4 c2 ad b8 5c 1f c0 	vfmadd231pd ymm3,ymm10,YMMWORD PTR [r15+rbx*1-0x40]
  1a38d5:	c4 c2 ad b8 4c 18 c0 	vfmadd231pd ymm1,ymm10,YMMWORD PTR [r8+rbx*1-0x40]
  1a38dc:	c4 42 ad b8 44 1e c0 	vfmadd231pd ymm8,ymm10,YMMWORD PTR [r14+rbx*1-0x40]
  1a38e3:	c4 41 7d 10 0c 1b    	vmovupd ymm9,YMMWORD PTR [r11+rbx*1]
  1a38e9:	49 83 c1 02          	add    r9,0x2
  1a38ed:	c4 e2 a5 b8 64 1e e0 	vfmadd231pd ymm4,ymm11,YMMWORD PTR [rsi+rbx*1-0x20]
  1a38f4:	c4 c2 a5 b8 6c 1f e0 	vfmadd231pd ymm5,ymm11,YMMWORD PTR [r15+rbx*1-0x20]
  1a38fb:	c4 c2 a5 b8 74 18 e0 	vfmadd231pd ymm6,ymm11,YMMWORD PTR [r8+rbx*1-0x20]
  1a3902:	c4 c2 a5 b8 7c 1e e0 	vfmadd231pd ymm7,ymm11,YMMWORD PTR [r14+rbx*1-0x20]
  1a3909:	c4 e2 b5 b8 14 1e    	vfmadd231pd ymm2,ymm9,YMMWORD PTR [rsi+rbx*1]
  1a390f:	c4 c2 b5 b8 1c 1f    	vfmadd231pd ymm3,ymm9,YMMWORD PTR [r15+rbx*1]
  1a3915:	c4 c2 b5 b8 0c 18    	vfmadd231pd ymm1,ymm9,YMMWORD PTR [r8+rbx*1]
  1a391b:	c4 42 b5 b8 04 1e    	vfmadd231pd ymm8,ymm9,YMMWORD PTR [r14+rbx*1]
  1a3921:	48 83 eb 80          	sub    rbx,0xffffffffffffff80
  1a3925:	4c 39 c8             	cmp    rax,r9
  1a3928:	0f 85 68 ff ff ff    	jne    1a3896 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x1fd6>
  1a392e:	41 f6 c2 01          	test   r10b,0x1
  1a3932:	48 8b 9c 24 08 01 00 	mov    rbx,QWORD PTR [rsp+0x108]
  1a3939:	00 
  1a393a:	4d 89 c7             	mov    r15,r8
  1a393d:	74 4f                	je     1a398e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x20ce>
  1a393f:	49 c1 e1 06          	shl    r9,0x6
  1a3943:	c4 01 7d 10 0c 0b    	vmovupd ymm9,YMMWORD PTR [r11+r9*1]
  1a3949:	c4 01 7d 10 54 0b 20 	vmovupd ymm10,YMMWORD PTR [r11+r9*1+0x20]
  1a3950:	c4 a2 b5 b8 24 0e    	vfmadd231pd ymm4,ymm9,YMMWORD PTR [rsi+r9*1]
  1a3956:	48 8b 44 24 30       	mov    rax,QWORD PTR [rsp+0x30]
  1a395b:	c4 a2 b5 b8 2c 08    	vfmadd231pd ymm5,ymm9,YMMWORD PTR [rax+r9*1]
  1a3961:	c4 82 b5 b8 34 0f    	vfmadd231pd ymm6,ymm9,YMMWORD PTR [r15+r9*1]
  1a3967:	4c 8b 44 24 20       	mov    r8,QWORD PTR [rsp+0x20]
  1a396c:	c4 82 b5 b8 3c 08    	vfmadd231pd ymm7,ymm9,YMMWORD PTR [r8+r9*1]
  1a3972:	c4 a2 ad b8 54 0e 20 	vfmadd231pd ymm2,ymm10,YMMWORD PTR [rsi+r9*1+0x20]
  1a3979:	c4 a2 ad b8 5c 08 20 	vfmadd231pd ymm3,ymm10,YMMWORD PTR [rax+r9*1+0x20]
  1a3980:	c4 82 ad b8 4c 0f 20 	vfmadd231pd ymm1,ymm10,YMMWORD PTR [r15+r9*1+0x20]
  1a3987:	c4 02 ad b8 44 08 20 	vfmadd231pd ymm8,ymm10,YMMWORD PTR [r8+r9*1+0x20]
  1a398e:	4d 01 dc             	add    r12,r11
  1a3991:	f6 44 24 28 04       	test   BYTE PTR [rsp+0x28],0x4
  1a3996:	4c 89 a4 24 60 01 00 	mov    QWORD PTR [rsp+0x160],r12
  1a399d:	00 
  1a399e:	0f 84 b0 00 00 00    	je     1a3a54 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2194>
  1a39a4:	f6 84 24 b0 00 00 00 	test   BYTE PTR [rsp+0xb0],0x1
  1a39ab:	01 
  1a39ac:	48 8b 44 24 20       	mov    rax,QWORD PTR [rsp+0x20]
  1a39b1:	0f 84 4e 08 00 00    	je     1a4205 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2945>
  1a39b7:	41 f6 c5 04          	test   r13b,0x4
  1a39bb:	48 8b 7c 24 50       	mov    rdi,QWORD PTR [rsp+0x50]
  1a39c0:	0f 84 53 08 00 00    	je     1a4219 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2959>
  1a39c6:	40 f6 c7 04          	test   dil,0x4
  1a39ca:	0f 84 29 0a 00 00    	je     1a43f9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2b39>
  1a39d0:	f6 44 24 78 04       	test   BYTE PTR [rsp+0x78],0x4
  1a39d5:	0f 84 32 0a 00 00    	je     1a440d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2b4d>
  1a39db:	f6 44 24 70 04       	test   BYTE PTR [rsp+0x70],0x4
  1a39e0:	0f 84 3b 0a 00 00    	je     1a4421 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2b61>
  1a39e6:	49 b8 fe ff ff ff ff 	movabs r8,0x3fffffffffffffe
  1a39ed:	ff ff 03 
  1a39f0:	48 8b bc 24 78 01 00 	mov    rdi,QWORD PTR [rsp+0x178]
  1a39f7:	00 
  1a39f8:	4c 21 c7             	and    rdi,r8
  1a39fb:	4c 8b 8c 24 b8 01 00 	mov    r9,QWORD PTR [rsp+0x1b8]
  1a3a02:	00 
  1a3a03:	4d 21 c1             	and    r9,r8
  1a3a06:	4c 8b 94 24 b0 01 00 	mov    r10,QWORD PTR [rsp+0x1b0]
  1a3a0d:	00 
  1a3a0e:	4d 21 c2             	and    r10,r8
  1a3a11:	4c 8b b4 24 a8 01 00 	mov    r14,QWORD PTR [rsp+0x1a8]
  1a3a18:	00 
  1a3a19:	4d 21 c6             	and    r14,r8
  1a3a1c:	48 c1 e7 05          	shl    rdi,0x5
  1a3a20:	49 c1 e1 05          	shl    r9,0x5
  1a3a24:	49 c1 e2 05          	shl    r10,0x5
  1a3a28:	49 c1 e6 05          	shl    r14,0x5
  1a3a2c:	48 01 f7             	add    rdi,rsi
  1a3a2f:	4c 03 4c 24 30       	add    r9,QWORD PTR [rsp+0x30]
  1a3a34:	4d 01 fa             	add    r10,r15
  1a3a37:	49 01 c6             	add    r14,rax
  1a3a3a:	c4 41 7d 10 0c 24    	vmovupd ymm9,YMMWORD PTR [r12]
  1a3a40:	c4 e2 b5 b8 27       	vfmadd231pd ymm4,ymm9,YMMWORD PTR [rdi]
  1a3a45:	c4 c2 b5 b8 29       	vfmadd231pd ymm5,ymm9,YMMWORD PTR [r9]
  1a3a4a:	c4 c2 b5 b8 32       	vfmadd231pd ymm6,ymm9,YMMWORD PTR [r10]
  1a3a4f:	c4 c2 b5 b8 3e       	vfmadd231pd ymm7,ymm9,YMMWORD PTR [r14]
  1a3a54:	c5 bd 58 ff          	vaddpd ymm7,ymm8,ymm7
  1a3a58:	c5 f5 58 f6          	vaddpd ymm6,ymm1,ymm6
  1a3a5c:	c5 e5 58 dd          	vaddpd ymm3,ymm3,ymm5
  1a3a60:	c5 ed 58 cc          	vaddpd ymm1,ymm2,ymm4
  1a3a64:	c4 e3 7d 19 ca 01    	vextractf128 xmm2,ymm1,0x1
  1a3a6a:	c5 f1 58 ca          	vaddpd xmm1,xmm1,xmm2
  1a3a6e:	c5 f1 c6 d1 01       	vshufpd xmm2,xmm1,xmm1,0x1
  1a3a73:	c5 f3 58 ca          	vaddsd xmm1,xmm1,xmm2
  1a3a77:	c4 e3 7d 19 da 01    	vextractf128 xmm2,ymm3,0x1
  1a3a7d:	c5 e1 58 d2          	vaddpd xmm2,xmm3,xmm2
  1a3a81:	c5 e9 c6 da 01       	vshufpd xmm3,xmm2,xmm2,0x1
  1a3a86:	c5 eb 58 d3          	vaddsd xmm2,xmm2,xmm3
  1a3a8a:	c4 e3 7d 19 f3 01    	vextractf128 xmm3,ymm6,0x1
  1a3a90:	c5 c9 58 db          	vaddpd xmm3,xmm6,xmm3
  1a3a94:	c5 e1 c6 e3 01       	vshufpd xmm4,xmm3,xmm3,0x1
  1a3a99:	c5 e3 58 dc          	vaddsd xmm3,xmm3,xmm4
  1a3a9d:	c4 e3 7d 19 fc 01    	vextractf128 xmm4,ymm7,0x1
  1a3aa3:	c5 c1 58 e4          	vaddpd xmm4,xmm7,xmm4
  1a3aa7:	c5 d9 c6 ec 01       	vshufpd xmm5,xmm4,xmm4,0x1
  1a3aac:	c5 db 58 e5          	vaddsd xmm4,xmm4,xmm5
  1a3ab0:	4c 8b 8c 24 b8 00 00 	mov    r9,QWORD PTR [rsp+0xb8]
  1a3ab7:	00 
  1a3ab8:	4d 85 c9             	test   r9,r9
  1a3abb:	48 8b bc 24 90 01 00 	mov    rdi,QWORD PTR [rsp+0x190]
  1a3ac2:	00 
  1a3ac3:	4c 8b 84 24 88 01 00 	mov    r8,QWORD PTR [rsp+0x188]
  1a3aca:	00 
  1a3acb:	4c 8b 94 24 80 01 00 	mov    r10,QWORD PTR [rsp+0x180]
  1a3ad2:	00 
  1a3ad3:	4c 8b b4 24 c0 01 00 	mov    r14,QWORD PTR [rsp+0x1c0]
  1a3ada:	00 
  1a3adb:	0f 84 22 02 00 00    	je     1a3d03 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2443>
  1a3ae1:	49 39 f8             	cmp    r8,rdi
  1a3ae4:	48 89 f8             	mov    rax,rdi
  1a3ae7:	49 0f 42 c0          	cmovb  rax,r8
  1a3aeb:	4c 39 d0             	cmp    rax,r10
  1a3aee:	49 0f 43 c2          	cmovae rax,r10
  1a3af2:	49 ff c9             	dec    r9
  1a3af5:	4c 39 f0             	cmp    rax,r14
  1a3af8:	49 0f 43 c6          	cmovae rax,r14
  1a3afc:	49 39 c1             	cmp    r9,rax
  1a3aff:	49 0f 42 c1          	cmovb  rax,r9
  1a3b03:	48 39 c7             	cmp    rdi,rax
  1a3b06:	0f 84 27 08 00 00    	je     1a4333 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2a73>
  1a3b0c:	49 39 c0             	cmp    r8,rax
  1a3b0f:	0f 84 a2 08 00 00    	je     1a43b7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2af7>
  1a3b15:	49 39 c2             	cmp    r10,rax
  1a3b18:	0f 84 af 08 00 00    	je     1a43cd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2b0d>
  1a3b1e:	49 39 c6             	cmp    r14,rax
  1a3b21:	0f 84 bc 08 00 00    	je     1a43e3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2b23>
  1a3b27:	48 8b 84 24 b8 00 00 	mov    rax,QWORD PTR [rsp+0xb8]
  1a3b2e:	00 
  1a3b2f:	41 89 c1             	mov    r9d,eax
  1a3b32:	41 83 e1 03          	and    r9d,0x3
  1a3b36:	48 83 f8 04          	cmp    rax,0x4
  1a3b3a:	73 12                	jae    1a3b4e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x228e>
  1a3b3c:	45 31 e4             	xor    r12d,r12d
  1a3b3f:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
  1a3b44:	4c 8b 74 24 20       	mov    r14,QWORD PTR [rsp+0x20]
  1a3b49:	e9 27 01 00 00       	jmp    1a3c75 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x23b5>
  1a3b4e:	48 83 e0 fc          	and    rax,0xfffffffffffffffc
  1a3b52:	49 89 f6             	mov    r14,rsi
  1a3b55:	4c 89 ee             	mov    rsi,r13
  1a3b58:	4d 89 ea             	mov    r10,r13
  1a3b5b:	49 bd fc ff ff ff ff 	movabs r13,0xffffffffffffffc
  1a3b62:	ff ff 0f 
  1a3b65:	4d 21 ea             	and    r10,r13
  1a3b68:	4f 8d 14 d6          	lea    r10,[r14+r10*8]
  1a3b6c:	49 83 c2 18          	add    r10,0x18
  1a3b70:	48 8b bc 24 40 01 00 	mov    rdi,QWORD PTR [rsp+0x140]
  1a3b77:	00 
  1a3b78:	49 8d 1c fb          	lea    rbx,[r11+rdi*8]
  1a3b7c:	48 83 c3 18          	add    rbx,0x18
  1a3b80:	4c 8b 74 24 50       	mov    r14,QWORD PTR [rsp+0x50]
  1a3b85:	4d 21 ee             	and    r14,r13
  1a3b88:	4d 89 fc             	mov    r12,r15
  1a3b8b:	4c 8b 7c 24 30       	mov    r15,QWORD PTR [rsp+0x30]
  1a3b90:	4f 8d 34 f7          	lea    r14,[r15+r14*8]
  1a3b94:	49 83 c6 18          	add    r14,0x18
  1a3b98:	4c 8b 7c 24 78       	mov    r15,QWORD PTR [rsp+0x78]
  1a3b9d:	4d 21 ef             	and    r15,r13
  1a3ba0:	4f 8d 3c fc          	lea    r15,[r12+r15*8]
  1a3ba4:	49 83 c7 18          	add    r15,0x18
  1a3ba8:	4c 8b 64 24 70       	mov    r12,QWORD PTR [rsp+0x70]
  1a3bad:	4d 21 ec             	and    r12,r13
  1a3bb0:	4c 8b 6c 24 20       	mov    r13,QWORD PTR [rsp+0x20]
  1a3bb5:	4f 8d 6c e5 18       	lea    r13,[r13+r12*8+0x18]
  1a3bba:	45 31 e4             	xor    r12d,r12d
  1a3bbd:	c4 a1 7b 10 6c e3 e8 	vmovsd xmm5,QWORD PTR [rbx+r12*8-0x18]
  1a3bc4:	c4 a1 7b 10 74 e3 f0 	vmovsd xmm6,QWORD PTR [rbx+r12*8-0x10]
  1a3bcb:	c4 82 d1 b9 4c e2 e8 	vfmadd231sd xmm1,xmm5,QWORD PTR [r10+r12*8-0x18]
  1a3bd2:	c4 82 d1 b9 54 e6 e8 	vfmadd231sd xmm2,xmm5,QWORD PTR [r14+r12*8-0x18]
  1a3bd9:	c4 82 d1 b9 5c e7 e8 	vfmadd231sd xmm3,xmm5,QWORD PTR [r15+r12*8-0x18]
  1a3be0:	c4 82 d1 b9 64 e5 e8 	vfmadd231sd xmm4,xmm5,QWORD PTR [r13+r12*8-0x18]
  1a3be7:	c4 82 c9 b9 4c e2 f0 	vfmadd231sd xmm1,xmm6,QWORD PTR [r10+r12*8-0x10]
  1a3bee:	c4 82 c9 b9 54 e6 f0 	vfmadd231sd xmm2,xmm6,QWORD PTR [r14+r12*8-0x10]
  1a3bf5:	c4 82 c9 b9 5c e7 f0 	vfmadd231sd xmm3,xmm6,QWORD PTR [r15+r12*8-0x10]
  1a3bfc:	c4 82 c9 b9 64 e5 f0 	vfmadd231sd xmm4,xmm6,QWORD PTR [r13+r12*8-0x10]
  1a3c03:	c4 a1 7b 10 6c e3 f8 	vmovsd xmm5,QWORD PTR [rbx+r12*8-0x8]
  1a3c0a:	c4 82 d1 b9 4c e2 f8 	vfmadd231sd xmm1,xmm5,QWORD PTR [r10+r12*8-0x8]
  1a3c11:	c4 82 d1 b9 54 e6 f8 	vfmadd231sd xmm2,xmm5,QWORD PTR [r14+r12*8-0x8]
  1a3c18:	c4 82 d1 b9 5c e7 f8 	vfmadd231sd xmm3,xmm5,QWORD PTR [r15+r12*8-0x8]
  1a3c1f:	c4 82 d1 b9 64 e5 f8 	vfmadd231sd xmm4,xmm5,QWORD PTR [r13+r12*8-0x8]
  1a3c26:	c4 a1 7b 10 2c e3    	vmovsd xmm5,QWORD PTR [rbx+r12*8]
  1a3c2c:	c4 82 d1 b9 0c e2    	vfmadd231sd xmm1,xmm5,QWORD PTR [r10+r12*8]
  1a3c32:	c4 82 d1 b9 14 e6    	vfmadd231sd xmm2,xmm5,QWORD PTR [r14+r12*8]
  1a3c38:	c4 82 d1 b9 1c e7    	vfmadd231sd xmm3,xmm5,QWORD PTR [r15+r12*8]
  1a3c3e:	c4 82 d1 b9 64 e5 00 	vfmadd231sd xmm4,xmm5,QWORD PTR [r13+r12*8+0x0]
  1a3c45:	49 83 c4 04          	add    r12,0x4
  1a3c49:	4c 39 e0             	cmp    rax,r12
  1a3c4c:	0f 85 6b ff ff ff    	jne    1a3bbd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x22fd>
  1a3c52:	4d 85 c9             	test   r9,r9
  1a3c55:	48 8b 9c 24 08 01 00 	mov    rbx,QWORD PTR [rsp+0x108]
  1a3c5c:	00 
  1a3c5d:	49 89 f5             	mov    r13,rsi
  1a3c60:	4c 8b 44 24 30       	mov    r8,QWORD PTR [rsp+0x30]
  1a3c65:	4c 8b 7c 24 60       	mov    r15,QWORD PTR [rsp+0x60]
  1a3c6a:	4c 8b 74 24 20       	mov    r14,QWORD PTR [rsp+0x20]
  1a3c6f:	0f 84 8e 00 00 00    	je     1a3d03 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2443>
  1a3c75:	48 be fc ff ff ff ff 	movabs rsi,0xffffffffffffffc
  1a3c7c:	ff ff 0f 
  1a3c7f:	48 8b 44 24 70       	mov    rax,QWORD PTR [rsp+0x70]
  1a3c84:	48 21 f0             	and    rax,rsi
  1a3c87:	4e 8d 14 e5 00 00 00 	lea    r10,[r12*8+0x0]
  1a3c8e:	00 
  1a3c8f:	49 8d 04 c2          	lea    rax,[r10+rax*8]
  1a3c93:	49 01 c6             	add    r14,rax
  1a3c96:	48 8b 44 24 78       	mov    rax,QWORD PTR [rsp+0x78]
  1a3c9b:	48 21 f0             	and    rax,rsi
  1a3c9e:	49 8d 04 c2          	lea    rax,[r10+rax*8]
  1a3ca2:	49 01 c7             	add    r15,rax
  1a3ca5:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
  1a3caa:	48 21 f0             	and    rax,rsi
  1a3cad:	49 8d 04 c2          	lea    rax,[r10+rax*8]
  1a3cb1:	49 01 c0             	add    r8,rax
  1a3cb4:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
  1a3cbb:	00 
  1a3cbc:	48 8d 04 c5 00 00 00 	lea    rax,[rax*8+0x0]
  1a3cc3:	00 
  1a3cc4:	4a 8d 04 e0          	lea    rax,[rax+r12*8]
  1a3cc8:	4c 01 d8             	add    rax,r11
  1a3ccb:	49 21 f5             	and    r13,rsi
  1a3cce:	48 8b 74 24 38       	mov    rsi,QWORD PTR [rsp+0x38]
  1a3cd3:	4f 8d 14 ea          	lea    r10,[r10+r13*8]
  1a3cd7:	4c 01 d6             	add    rsi,r10
  1a3cda:	45 31 d2             	xor    r10d,r10d
  1a3cdd:	c4 a1 7b 10 2c d0    	vmovsd xmm5,QWORD PTR [rax+r10*8]
  1a3ce3:	c4 a2 d1 b9 0c d6    	vfmadd231sd xmm1,xmm5,QWORD PTR [rsi+r10*8]
  1a3ce9:	c4 82 d1 b9 14 d0    	vfmadd231sd xmm2,xmm5,QWORD PTR [r8+r10*8]
  1a3cef:	c4 82 d1 b9 1c d7    	vfmadd231sd xmm3,xmm5,QWORD PTR [r15+r10*8]
  1a3cf5:	c4 82 d1 b9 24 d6    	vfmadd231sd xmm4,xmm5,QWORD PTR [r14+r10*8]
  1a3cfb:	49 ff c2             	inc    r10
  1a3cfe:	4d 39 d1             	cmp    r9,r10
  1a3d01:	75 da                	jne    1a3cdd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x241d>
  1a3d03:	48 89 d8             	mov    rax,rbx
  1a3d06:	48 c1 e8 03          	shr    rax,0x3
  1a3d0a:	48 8b 74 24 48       	mov    rsi,QWORD PTR [rsp+0x48]
  1a3d0f:	48 39 c6             	cmp    rsi,rax
  1a3d12:	48 0f 42 c6          	cmovb  rax,rsi
  1a3d16:	48 8b b4 24 88 00 00 	mov    rsi,QWORD PTR [rsp+0x88]
  1a3d1d:	00 
  1a3d1e:	48 39 c6             	cmp    rsi,rax
  1a3d21:	48 0f 42 c6          	cmovb  rax,rsi
  1a3d25:	48 85 c0             	test   rax,rax
  1a3d28:	74 5a                	je     1a3d84 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x24c4>
  1a3d2a:	48 83 f8 01          	cmp    rax,0x1
  1a3d2e:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  1a3d33:	4c 8b 54 24 08       	mov    r10,QWORD PTR [rsp+0x8]
  1a3d38:	4c 8b a4 24 c0 00 00 	mov    r12,QWORD PTR [rsp+0xc0]
  1a3d3f:	00 
  1a3d40:	49 b9 fe ff ff ff ff 	movabs r9,0x3fffffffffffffe
  1a3d47:	ff ff 03 
  1a3d4a:	0f 85 82 00 00 00    	jne    1a3dd2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2512>
  1a3d50:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  1a3d54:	31 ff                	xor    edi,edi
  1a3d56:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  1a3d5a:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  1a3d5e:	c4 41 21 57 db       	vxorpd xmm11,xmm11,xmm11
  1a3d63:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  1a3d68:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  1a3d6d:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  1a3d72:	c4 41 19 57 e4       	vxorpd xmm12,xmm12,xmm12
  1a3d77:	4c 8b b4 24 b8 00 00 	mov    r14,QWORD PTR [rsp+0xb8]
  1a3d7e:	00 
  1a3d7f:	e9 2d 01 00 00       	jmp    1a3eb1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x25f1>
  1a3d84:	c4 41 19 57 e4       	vxorpd xmm12,xmm12,xmm12
  1a3d89:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  1a3d8e:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  1a3d93:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  1a3d98:	c4 41 21 57 db       	vxorpd xmm11,xmm11,xmm11
  1a3d9d:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  1a3da1:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  1a3da5:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  1a3da9:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  1a3dae:	4c 8b 54 24 08       	mov    r10,QWORD PTR [rsp+0x8]
  1a3db3:	4c 8b a4 24 c0 00 00 	mov    r12,QWORD PTR [rsp+0xc0]
  1a3dba:	00 
  1a3dbb:	49 b9 fe ff ff ff ff 	movabs r9,0x3fffffffffffffe
  1a3dc2:	ff ff 03 
  1a3dc5:	4c 8b b4 24 b8 00 00 	mov    r14,QWORD PTR [rsp+0xb8]
  1a3dcc:	00 
  1a3dcd:	e9 25 01 00 00       	jmp    1a3ef7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2637>
  1a3dd2:	49 be fe ff ff ff ff 	movabs r14,0x1ffffffffffffffe
  1a3dd9:	ff ff 1f 
  1a3ddc:	49 21 c6             	and    r14,rax
  1a3ddf:	c5 d1 57 ed          	vxorpd xmm5,xmm5,xmm5
  1a3de3:	41 b8 60 00 00 00    	mov    r8d,0x60
  1a3de9:	31 ff                	xor    edi,edi
  1a3deb:	c5 c1 57 ff          	vxorpd xmm7,xmm7,xmm7
  1a3def:	c5 c9 57 f6          	vxorpd xmm6,xmm6,xmm6
  1a3df3:	c4 41 21 57 db       	vxorpd xmm11,xmm11,xmm11
  1a3df8:	c4 41 29 57 d2       	vxorpd xmm10,xmm10,xmm10
  1a3dfd:	c4 41 31 57 c9       	vxorpd xmm9,xmm9,xmm9
  1a3e02:	c4 41 39 57 c0       	vxorpd xmm8,xmm8,xmm8
  1a3e07:	c4 41 19 57 e4       	vxorpd xmm12,xmm12,xmm12
  1a3e0c:	c4 01 7d 10 6c 03 a0 	vmovupd ymm13,YMMWORD PTR [r11+r8*1-0x60]
  1a3e13:	c4 01 7d 10 74 03 c0 	vmovupd ymm14,YMMWORD PTR [r11+r8*1-0x40]
  1a3e1a:	c4 01 7d 10 7c 03 e0 	vmovupd ymm15,YMMWORD PTR [r11+r8*1-0x20]
  1a3e21:	c4 22 95 b8 44 01 a0 	vfmadd231pd ymm8,ymm13,YMMWORD PTR [rcx+r8*1-0x60]
  1a3e28:	c4 22 95 b8 4c 02 a0 	vfmadd231pd ymm9,ymm13,YMMWORD PTR [rdx+r8*1-0x60]
  1a3e2f:	c4 22 95 b8 54 05 a0 	vfmadd231pd ymm10,ymm13,YMMWORD PTR [rbp+r8*1-0x60]
  1a3e36:	c4 02 95 b8 5c 04 a0 	vfmadd231pd ymm11,ymm13,YMMWORD PTR [r12+r8*1-0x60]
  1a3e3d:	c4 a2 8d b8 74 01 c0 	vfmadd231pd ymm6,ymm14,YMMWORD PTR [rcx+r8*1-0x40]
  1a3e44:	c4 a2 8d b8 7c 02 c0 	vfmadd231pd ymm7,ymm14,YMMWORD PTR [rdx+r8*1-0x40]
  1a3e4b:	c4 a2 8d b8 6c 05 c0 	vfmadd231pd ymm5,ymm14,YMMWORD PTR [rbp+r8*1-0x40]
  1a3e52:	c4 02 8d b8 64 04 c0 	vfmadd231pd ymm12,ymm14,YMMWORD PTR [r12+r8*1-0x40]
  1a3e59:	c4 01 7d 10 2c 03    	vmovupd ymm13,YMMWORD PTR [r11+r8*1]
  1a3e5f:	48 83 c7 02          	add    rdi,0x2
  1a3e63:	c4 22 85 b8 44 01 e0 	vfmadd231pd ymm8,ymm15,YMMWORD PTR [rcx+r8*1-0x20]
  1a3e6a:	c4 22 85 b8 4c 02 e0 	vfmadd231pd ymm9,ymm15,YMMWORD PTR [rdx+r8*1-0x20]
  1a3e71:	c4 22 85 b8 54 05 e0 	vfmadd231pd ymm10,ymm15,YMMWORD PTR [rbp+r8*1-0x20]
  1a3e78:	c4 02 85 b8 5c 04 e0 	vfmadd231pd ymm11,ymm15,YMMWORD PTR [r12+r8*1-0x20]
  1a3e7f:	c4 a2 95 b8 34 01    	vfmadd231pd ymm6,ymm13,YMMWORD PTR [rcx+r8*1]
  1a3e85:	c4 a2 95 b8 3c 02    	vfmadd231pd ymm7,ymm13,YMMWORD PTR [rdx+r8*1]
  1a3e8b:	c4 a2 95 b8 6c 05 00 	vfmadd231pd ymm5,ymm13,YMMWORD PTR [rbp+r8*1+0x0]
  1a3e92:	c4 02 95 b8 24 04    	vfmadd231pd ymm12,ymm13,YMMWORD PTR [r12+r8*1]
  1a3e98:	49 83 e8 80          	sub    r8,0xffffffffffffff80
  1a3e9c:	49 39 fe             	cmp    r14,rdi
  1a3e9f:	0f 85 67 ff ff ff    	jne    1a3e0c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x254c>
  1a3ea5:	a8 01                	test   al,0x1
  1a3ea7:	4c 8b b4 24 b8 00 00 	mov    r14,QWORD PTR [rsp+0xb8]
  1a3eae:	00 
  1a3eaf:	74 46                	je     1a3ef7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2637>
  1a3eb1:	48 c1 e7 06          	shl    rdi,0x6
  1a3eb5:	c4 41 7d 10 2c 3b    	vmovupd ymm13,YMMWORD PTR [r11+rdi*1]
  1a3ebb:	c4 41 7d 10 74 3b 20 	vmovupd ymm14,YMMWORD PTR [r11+rdi*1+0x20]
  1a3ec2:	c4 62 95 b8 04 39    	vfmadd231pd ymm8,ymm13,YMMWORD PTR [rcx+rdi*1]
  1a3ec8:	c4 62 95 b8 0c 3a    	vfmadd231pd ymm9,ymm13,YMMWORD PTR [rdx+rdi*1]
  1a3ece:	c4 62 95 b8 54 3d 00 	vfmadd231pd ymm10,ymm13,YMMWORD PTR [rbp+rdi*1+0x0]
  1a3ed5:	c4 42 95 b8 1c 3c    	vfmadd231pd ymm11,ymm13,YMMWORD PTR [r12+rdi*1]
  1a3edb:	c4 e2 8d b8 74 39 20 	vfmadd231pd ymm6,ymm14,YMMWORD PTR [rcx+rdi*1+0x20]
  1a3ee2:	c4 e2 8d b8 7c 3a 20 	vfmadd231pd ymm7,ymm14,YMMWORD PTR [rdx+rdi*1+0x20]
  1a3ee9:	c4 e2 8d b8 6c 3d 20 	vfmadd231pd ymm5,ymm14,YMMWORD PTR [rbp+rdi*1+0x20]
  1a3ef0:	c4 42 8d b8 64 3c 20 	vfmadd231pd ymm12,ymm14,YMMWORD PTR [r12+rdi*1+0x20]
  1a3ef7:	f6 44 24 28 04       	test   BYTE PTR [rsp+0x28],0x4
  1a3efc:	74 55                	je     1a3f53 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2693>
  1a3efe:	f6 84 24 b0 00 00 00 	test   BYTE PTR [rsp+0xb0],0x1
  1a3f05:	01 
  1a3f06:	0f 84 f9 02 00 00    	je     1a4205 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2945>
  1a3f0c:	f6 c3 04             	test   bl,0x4
  1a3f0f:	0f 84 04 03 00 00    	je     1a4219 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2959>
  1a3f15:	48 89 d8             	mov    rax,rbx
  1a3f18:	48 c1 e8 02          	shr    rax,0x2
  1a3f1c:	4c 21 c8             	and    rax,r9
  1a3f1f:	48 c1 e0 05          	shl    rax,0x5
  1a3f23:	48 8d 3c 01          	lea    rdi,[rcx+rax*1]
  1a3f27:	4c 8d 04 02          	lea    r8,[rdx+rax*1]
  1a3f2b:	4c 8d 0c 28          	lea    r9,[rax+rbp*1]
  1a3f2f:	4c 01 e0             	add    rax,r12
  1a3f32:	4c 8b bc 24 60 01 00 	mov    r15,QWORD PTR [rsp+0x160]
  1a3f39:	00 
  1a3f3a:	c4 41 7d 10 2f       	vmovupd ymm13,YMMWORD PTR [r15]
  1a3f3f:	c4 62 95 b8 07       	vfmadd231pd ymm8,ymm13,YMMWORD PTR [rdi]
  1a3f44:	c4 42 95 b8 08       	vfmadd231pd ymm9,ymm13,YMMWORD PTR [r8]
  1a3f49:	c4 42 95 b8 11       	vfmadd231pd ymm10,ymm13,YMMWORD PTR [r9]
  1a3f4e:	c4 62 95 b8 18       	vfmadd231pd ymm11,ymm13,YMMWORD PTR [rax]
  1a3f53:	c4 41 1d 58 db       	vaddpd ymm11,ymm12,ymm11
  1a3f58:	c5 ad 58 ed          	vaddpd ymm5,ymm10,ymm5
  1a3f5c:	c5 35 58 cf          	vaddpd ymm9,ymm9,ymm7
  1a3f60:	c5 bd 58 f6          	vaddpd ymm6,ymm8,ymm6
  1a3f64:	c4 e3 7d 19 f7 01    	vextractf128 xmm7,ymm6,0x1
  1a3f6a:	c5 c9 58 f7          	vaddpd xmm6,xmm6,xmm7
  1a3f6e:	c5 c9 c6 fe 01       	vshufpd xmm7,xmm6,xmm6,0x1
  1a3f73:	c5 cb 58 ff          	vaddsd xmm7,xmm6,xmm7
  1a3f77:	c4 63 7d 19 ce 01    	vextractf128 xmm6,ymm9,0x1
  1a3f7d:	c5 b1 58 f6          	vaddpd xmm6,xmm9,xmm6
  1a3f81:	c5 49 c6 c6 01       	vshufpd xmm8,xmm6,xmm6,0x1
  1a3f86:	c5 3b 58 c6          	vaddsd xmm8,xmm8,xmm6
  1a3f8a:	c4 e3 7d 19 ee 01    	vextractf128 xmm6,ymm5,0x1
  1a3f90:	c5 d1 58 ee          	vaddpd xmm5,xmm5,xmm6
  1a3f94:	c5 d1 c6 f5 01       	vshufpd xmm6,xmm5,xmm5,0x1
  1a3f99:	c5 d3 58 ee          	vaddsd xmm5,xmm5,xmm6
  1a3f9d:	c4 63 7d 19 de 01    	vextractf128 xmm6,ymm11,0x1
  1a3fa3:	c5 a1 58 f6          	vaddpd xmm6,xmm11,xmm6
  1a3fa7:	c5 49 c6 ce 01       	vshufpd xmm9,xmm6,xmm6,0x1
  1a3fac:	c5 b3 58 f6          	vaddsd xmm6,xmm9,xmm6
  1a3fb0:	4d 85 f6             	test   r14,r14
  1a3fb3:	74 6f                	je     1a4024 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2764>
  1a3fb5:	89 df                	mov    edi,ebx
  1a3fb7:	83 e7 03             	and    edi,0x3
  1a3fba:	49 8d 46 ff          	lea    rax,[r14-0x1]
  1a3fbe:	48 39 c7             	cmp    rdi,rax
  1a3fc1:	0f 86 6c 03 00 00    	jbe    1a4333 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2a73>
  1a3fc7:	48 b8 fc ff ff ff ff 	movabs rax,0xffffffffffffffc
  1a3fce:	ff ff 0f 
  1a3fd1:	48 21 c3             	and    rbx,rax
  1a3fd4:	48 8b 84 24 40 01 00 	mov    rax,QWORD PTR [rsp+0x140]
  1a3fdb:	00 
  1a3fdc:	49 8d 04 c3          	lea    rax,[r11+rax*8]
  1a3fe0:	48 8d 0c d9          	lea    rcx,[rcx+rbx*8]
  1a3fe4:	48 8d 3c da          	lea    rdi,[rdx+rbx*8]
  1a3fe8:	48 8d 14 dd 00 00 00 	lea    rdx,[rbx*8+0x0]
  1a3fef:	00 
  1a3ff0:	48 01 ea             	add    rdx,rbp
  1a3ff3:	4d 8d 0c dc          	lea    r9,[r12+rbx*8]
  1a3ff7:	41 83 e6 03          	and    r14d,0x3
  1a3ffb:	45 31 c0             	xor    r8d,r8d
  1a3ffe:	c4 21 7b 10 0c c0    	vmovsd xmm9,QWORD PTR [rax+r8*8]
  1a4004:	c4 a2 b1 b9 3c c1    	vfmadd231sd xmm7,xmm9,QWORD PTR [rcx+r8*8]
  1a400a:	c4 22 b1 b9 04 c7    	vfmadd231sd xmm8,xmm9,QWORD PTR [rdi+r8*8]
  1a4010:	c4 a2 b1 b9 2c c2    	vfmadd231sd xmm5,xmm9,QWORD PTR [rdx+r8*8]
  1a4016:	c4 82 b1 b9 34 c1    	vfmadd231sd xmm6,xmm9,QWORD PTR [r9+r8*8]
  1a401c:	49 ff c0             	inc    r8
  1a401f:	4d 39 c6             	cmp    r14,r8
  1a4022:	75 da                	jne    1a3ffe <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x273e>
  1a4024:	48 8b bc 24 00 02 00 	mov    rdi,QWORD PTR [rsp+0x200]
  1a402b:	00 
  1a402c:	48 83 e7 fe          	and    rdi,0xfffffffffffffffe
  1a4030:	48 8d 47 fe          	lea    rax,[rdi-0x2]
  1a4034:	48 39 f0             	cmp    rax,rsi
  1a4037:	0f 83 09 03 00 00    	jae    1a4346 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2a86>
  1a403d:	48 89 c1             	mov    rcx,rax
  1a4040:	48 c1 e1 04          	shl    rcx,0x4
  1a4044:	4c 8b 84 24 00 01 00 	mov    r8,QWORD PTR [rsp+0x100]
  1a404b:	00 
  1a404c:	c4 c1 7b 11 3c 08    	vmovsd QWORD PTR [r8+rcx*1],xmm7
  1a4052:	48 8b 94 24 30 01 00 	mov    rdx,QWORD PTR [rsp+0x130]
  1a4059:	00 
  1a405a:	48 01 fa             	add    rdx,rdi
  1a405d:	48 83 c2 fe          	add    rdx,0xfffffffffffffffe
  1a4061:	c4 41 7b 11 44 08 08 	vmovsd QWORD PTR [r8+rcx*1+0x8],xmm8
  1a4068:	48 3b 54 24 68       	cmp    rdx,QWORD PTR [rsp+0x68]
  1a406d:	73 52                	jae    1a40c1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2801>
  1a406f:	48 ff cf             	dec    rdi
  1a4072:	48 39 f7             	cmp    rdi,rsi
  1a4075:	0f 83 ba 03 00 00    	jae    1a4435 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2b75>
  1a407b:	48 89 fa             	mov    rdx,rdi
  1a407e:	48 c1 e2 04          	shl    rdx,0x4
  1a4082:	c4 c1 7b 11 2c 10    	vmovsd QWORD PTR [r8+rdx*1],xmm5
  1a4088:	c4 c1 7b 11 74 10 08 	vmovsd QWORD PTR [r8+rdx*1+0x8],xmm6
  1a408f:	4c 39 d0             	cmp    rax,r10
  1a4092:	0f 83 c1 02 00 00    	jae    1a4359 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2a99>
  1a4098:	48 8b 84 24 c8 00 00 	mov    rax,QWORD PTR [rsp+0xc8]
  1a409f:	00 
  1a40a0:	c5 fb 11 0c 08       	vmovsd QWORD PTR [rax+rcx*1],xmm1
  1a40a5:	c5 fb 11 54 08 08    	vmovsd QWORD PTR [rax+rcx*1+0x8],xmm2
  1a40ab:	4c 39 d7             	cmp    rdi,r10
  1a40ae:	0f 83 91 03 00 00    	jae    1a4445 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2b85>
  1a40b4:	48 89 f8             	mov    rax,rdi
  1a40b7:	c5 f9 28 cb          	vmovapd xmm1,xmm3
  1a40bb:	c5 f9 28 d4          	vmovapd xmm2,xmm4
  1a40bf:	eb 09                	jmp    1a40ca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x280a>
  1a40c1:	4c 39 d0             	cmp    rax,r10
  1a40c4:	0f 83 8f 02 00 00    	jae    1a4359 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2a99>
  1a40ca:	48 c1 e0 04          	shl    rax,0x4
  1a40ce:	48 8b 8c 24 c8 00 00 	mov    rcx,QWORD PTR [rsp+0xc8]
  1a40d5:	00 
  1a40d6:	c5 fb 11 0c 01       	vmovsd QWORD PTR [rcx+rax*1],xmm1
  1a40db:	c5 fb 11 54 01 08    	vmovsd QWORD PTR [rcx+rax*1+0x8],xmm2
  1a40e1:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
  1a40e5:	c4 e2 75 37 c0       	vpcmpgtq ymm0,ymm1,ymm0
  1a40ea:	c4 e2 7d 59 0d 15 d0 	vpbroadcastq ymm1,QWORD PTR [rip+0xffffffffffe7d015]        # 21108 <anon.18cb9c1b3fe794d0b89f358a70182f4e.25.llvm.5582884991536083740+0x498>
  1a40f1:	e7 ff 
  1a40f3:	c5 fd db c1          	vpand  ymm0,ymm0,ymm1
  1a40f7:	c4 e3 7d 39 c1 01    	vextracti128 xmm1,ymm0,0x1
  1a40fd:	c5 f9 5d c1          	vminpd xmm0,xmm0,xmm1
  1a4101:	c5 f9 c6 c8 01       	vshufpd xmm1,xmm0,xmm0,0x1
  1a4106:	c5 fb 5d c1          	vminsd xmm0,xmm0,xmm1
  1a410a:	c5 f1 57 c9          	vxorpd xmm1,xmm1,xmm1
  1a410e:	c5 f9 2e c1          	vucomisd xmm0,xmm1
  1a4112:	0f 97 c0             	seta   al
  1a4115:	22 44 24 07          	and    al,BYTE PTR [rsp+0x7]
  1a4119:	eb 35                	jmp    1a4150 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2890>
  1a411b:	48 8b 84 24 d8 00 00 	mov    rax,QWORD PTR [rsp+0xd8]
  1a4122:	00 
  1a4123:	48 39 c7             	cmp    rdi,rax
  1a4126:	0f 83 5f 01 00 00    	jae    1a428b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x29cb>
  1a412c:	48 3b 7c 24 58       	cmp    rdi,QWORD PTR [rsp+0x58]
  1a4131:	0f 83 6f 01 00 00    	jae    1a42a6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x29e6>
  1a4137:	48 ff c7             	inc    rdi
  1a413a:	48 39 c7             	cmp    rdi,rax
  1a413d:	0f 83 2d 01 00 00    	jae    1a4270 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x29b0>
  1a4143:	48 3b 7c 24 58       	cmp    rdi,QWORD PTR [rsp+0x58]
  1a4148:	0f 83 0d 01 00 00    	jae    1a425b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x299b>
  1a414e:	31 c0                	xor    eax,eax
  1a4150:	48 81 c4 38 02 00 00 	add    rsp,0x238
  1a4157:	5b                   	pop    rbx
  1a4158:	41 5c                	pop    r12
  1a415a:	41 5d                	pop    r13
  1a415c:	41 5e                	pop    r14
  1a415e:	41 5f                	pop    r15
  1a4160:	5d                   	pop    rbp
  1a4161:	c5 f8 77             	vzeroupper
  1a4164:	c3                   	ret
  1a4165:	4d 89 f2             	mov    r10,r14
  1a4168:	48 8b 44 24 50       	mov    rax,QWORD PTR [rsp+0x50]
  1a416d:	48 89 44 24 10       	mov    QWORD PTR [rsp+0x10],rax
  1a4172:	48 8b 9c 24 08 01 00 	mov    rbx,QWORD PTR [rsp+0x108]
  1a4179:	00 
  1a417a:	e9 26 da ff ff       	jmp    1a1ba5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPair<true, false, true, true>>>+0x2e5>
  1a417f:	48 8d 15 ea 29 0d 00 	lea    rdx,[rip+0xd29ea]        # 276b70 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x608>
  1a4186:	48 8b bc 24 f0 00 00 	mov    rdi,QWORD PTR [rsp+0xf0]
  1a418d:	00 
  1a418e:	48 8b b4 24 d8 00 00 	mov    rsi,QWORD PTR [rsp+0xd8]
  1a4195:	00 
  1a4196:	c5 f8 77             	vzeroupper
  1a4199:	ff 15 f1 c4 0d 00    	call   QWORD PTR [rip+0xdc4f1]        # 280690 <_DYNAMIC+0x2b8>
  1a419f:	48 8d 15 e2 29 0d 00 	lea    rdx,[rip+0xd29e2]        # 276b88 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x620>
  1a41a6:	48 8b bc 24 e8 00 00 	mov    rdi,QWORD PTR [rsp+0xe8]
  1a41ad:	00 
  1a41ae:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
  1a41b3:	c5 f8 77             	vzeroupper
  1a41b6:	ff 15 d4 c4 0d 00    	call   QWORD PTR [rip+0xdc4d4]        # 280690 <_DYNAMIC+0x2b8>
  1a41bc:	48 8d 15 4d 35 0d 00 	lea    rdx,[rip+0xd354d]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a41c3:	48 89 fe             	mov    rsi,rdi
  1a41c6:	4c 89 ef             	mov    rdi,r13
  1a41c9:	c5 f8 77             	vzeroupper
  1a41cc:	ff 15 be c4 0d 00    	call   QWORD PTR [rip+0xdc4be]        # 280690 <_DYNAMIC+0x2b8>
  1a41d2:	48 8d 15 37 35 0d 00 	lea    rdx,[rip+0xd3537]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a41d9:	4c 89 ef             	mov    rdi,r13
  1a41dc:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  1a41e1:	c5 f8 77             	vzeroupper
  1a41e4:	ff 15 a6 c4 0d 00    	call   QWORD PTR [rip+0xdc4a6]        # 280690 <_DYNAMIC+0x2b8>
  1a41ea:	48 8d 15 b7 2d 0d 00 	lea    rdx,[rip+0xd2db7]        # 276fa8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa40>
  1a41f1:	48 8b bc 24 c8 01 00 	mov    rdi,QWORD PTR [rsp+0x1c8]
  1a41f8:	00 
  1a41f9:	48 89 fe             	mov    rsi,rdi
  1a41fc:	c5 f8 77             	vzeroupper
  1a41ff:	ff 15 8b c4 0d 00    	call   QWORD PTR [rip+0xdc48b]        # 280690 <_DYNAMIC+0x2b8>
  1a4205:	48 8d 15 24 2d 0d 00 	lea    rdx,[rip+0xd2d24]        # 276f30 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9c8>
  1a420c:	31 ff                	xor    edi,edi
  1a420e:	31 f6                	xor    esi,esi
  1a4210:	c5 f8 77             	vzeroupper
  1a4213:	ff 15 77 c4 0d 00    	call   QWORD PTR [rip+0xdc477]        # 280690 <_DYNAMIC+0x2b8>
  1a4219:	48 8d 15 28 2d 0d 00 	lea    rdx,[rip+0xd2d28]        # 276f48 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9e0>
  1a4220:	31 ff                	xor    edi,edi
  1a4222:	31 f6                	xor    esi,esi
  1a4224:	c5 f8 77             	vzeroupper
  1a4227:	ff 15 63 c4 0d 00    	call   QWORD PTR [rip+0xdc463]        # 280690 <_DYNAMIC+0x2b8>
  1a422d:	48 8d 15 f4 34 0d 00 	lea    rdx,[rip+0xd34f4]        # 277728 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1a4234:	48 89 fe             	mov    rsi,rdi
  1a4237:	4c 89 ef             	mov    rdi,r13
  1a423a:	c5 f8 77             	vzeroupper
  1a423d:	ff 15 4d c4 0d 00    	call   QWORD PTR [rip+0xdc44d]        # 280690 <_DYNAMIC+0x2b8>
  1a4243:	48 8d 15 de 34 0d 00 	lea    rdx,[rip+0xd34de]        # 277728 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1a424a:	48 89 c7             	mov    rdi,rax
  1a424d:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  1a4252:	c5 f8 77             	vzeroupper
  1a4255:	ff 15 35 c4 0d 00    	call   QWORD PTR [rip+0xdc435]        # 280690 <_DYNAMIC+0x2b8>
  1a425b:	48 8d 15 86 29 0d 00 	lea    rdx,[rip+0xd2986]        # 276be8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x680>
  1a4262:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
  1a4267:	c5 f8 77             	vzeroupper
  1a426a:	ff 15 20 c4 0d 00    	call   QWORD PTR [rip+0xdc420]        # 280690 <_DYNAMIC+0x2b8>
  1a4270:	48 8d 15 59 29 0d 00 	lea    rdx,[rip+0xd2959]        # 276bd0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x668>
  1a4277:	48 8b b4 24 d8 00 00 	mov    rsi,QWORD PTR [rsp+0xd8]
  1a427e:	00 
  1a427f:	c5 f8 77             	vzeroupper
  1a4282:	ff 15 08 c4 0d 00    	call   QWORD PTR [rip+0xdc408]        # 280690 <_DYNAMIC+0x2b8>
  1a4288:	4c 89 c7             	mov    rdi,r8
  1a428b:	48 8d 15 0e 29 0d 00 	lea    rdx,[rip+0xd290e]        # 276ba0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x638>
  1a4292:	48 8b b4 24 d8 00 00 	mov    rsi,QWORD PTR [rsp+0xd8]
  1a4299:	00 
  1a429a:	c5 f8 77             	vzeroupper
  1a429d:	ff 15 ed c3 0d 00    	call   QWORD PTR [rip+0xdc3ed]        # 280690 <_DYNAMIC+0x2b8>
  1a42a3:	4c 89 c7             	mov    rdi,r8
  1a42a6:	48 8d 15 0b 29 0d 00 	lea    rdx,[rip+0xd290b]        # 276bb8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x650>
  1a42ad:	48 8b 74 24 58       	mov    rsi,QWORD PTR [rsp+0x58]
  1a42b2:	c5 f8 77             	vzeroupper
  1a42b5:	ff 15 d5 c3 0d 00    	call   QWORD PTR [rip+0xdc3d5]        # 280690 <_DYNAMIC+0x2b8>
  1a42bb:	48 8d 15 4e 34 0d 00 	lea    rdx,[rip+0xd344e]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a42c2:	4c 89 cf             	mov    rdi,r9
  1a42c5:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  1a42ca:	c5 f8 77             	vzeroupper
  1a42cd:	ff 15 bd c3 0d 00    	call   QWORD PTR [rip+0xdc3bd]        # 280690 <_DYNAMIC+0x2b8>
  1a42d3:	48 8d 15 36 34 0d 00 	lea    rdx,[rip+0xd3436]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a42da:	4c 89 cf             	mov    rdi,r9
  1a42dd:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
  1a42e2:	c5 f8 77             	vzeroupper
  1a42e5:	ff 15 a5 c3 0d 00    	call   QWORD PTR [rip+0xdc3a5]        # 280690 <_DYNAMIC+0x2b8>
  1a42eb:	48 8d 15 1e 34 0d 00 	lea    rdx,[rip+0xd341e]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a42f2:	4c 89 ff             	mov    rdi,r15
  1a42f5:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  1a42fa:	c5 f8 77             	vzeroupper
  1a42fd:	ff 15 8d c3 0d 00    	call   QWORD PTR [rip+0xdc38d]        # 280690 <_DYNAMIC+0x2b8>
  1a4303:	48 8d 15 06 34 0d 00 	lea    rdx,[rip+0xd3406]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a430a:	4c 89 ff             	mov    rdi,r15
  1a430d:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
  1a4312:	c5 f8 77             	vzeroupper
  1a4315:	ff 15 75 c3 0d 00    	call   QWORD PTR [rip+0xdc375]        # 280690 <_DYNAMIC+0x2b8>
  1a431b:	48 8d 15 06 34 0d 00 	lea    rdx,[rip+0xd3406]        # 277728 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1a4322:	48 89 c7             	mov    rdi,rax
  1a4325:	48 8b 74 24 08       	mov    rsi,QWORD PTR [rsp+0x8]
  1a432a:	c5 f8 77             	vzeroupper
  1a432d:	ff 15 5d c3 0d 00    	call   QWORD PTR [rip+0xdc35d]        # 280690 <_DYNAMIC+0x2b8>
  1a4333:	48 8d 15 6e 2c 0d 00 	lea    rdx,[rip+0xd2c6e]        # 276fa8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa40>
  1a433a:	48 89 fe             	mov    rsi,rdi
  1a433d:	c5 f8 77             	vzeroupper
  1a4340:	ff 15 4a c3 0d 00    	call   QWORD PTR [rip+0xdc34a]        # 280690 <_DYNAMIC+0x2b8>
  1a4346:	48 8d 15 c3 33 0d 00 	lea    rdx,[rip+0xd33c3]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a434d:	48 89 c7             	mov    rdi,rax
  1a4350:	c5 f8 77             	vzeroupper
  1a4353:	ff 15 37 c3 0d 00    	call   QWORD PTR [rip+0xdc337]        # 280690 <_DYNAMIC+0x2b8>
  1a4359:	48 8d 15 b0 33 0d 00 	lea    rdx,[rip+0xd33b0]        # 277710 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11a8>
  1a4360:	48 89 c7             	mov    rdi,rax
  1a4363:	4c 89 d6             	mov    rsi,r10
  1a4366:	c5 f8 77             	vzeroupper
  1a4369:	ff 15 21 c3 0d 00    	call   QWORD PTR [rip+0xdc321]        # 280690 <_DYNAMIC+0x2b8>
  1a436f:	48 8d 15 ca 2a 0d 00 	lea    rdx,[rip+0xd2aca]        # 276e40 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x8d8>
  1a4376:	48 8b 7c 24 10       	mov    rdi,QWORD PTR [rsp+0x10]
  1a437b:	48 89 fe             	mov    rsi,rdi
  1a437e:	c5 f8 77             	vzeroupper
  1a4381:	ff 15 09 c3 0d 00    	call   QWORD PTR [rip+0xdc309]        # 280690 <_DYNAMIC+0x2b8>
  1a4387:	48 8d 15 9a 33 0d 00 	lea    rdx,[rip+0xd339a]        # 277728 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1a438e:	4c 89 cf             	mov    rdi,r9
  1a4391:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  1a4396:	c5 f8 77             	vzeroupper
  1a4399:	ff 15 f1 c2 0d 00    	call   QWORD PTR [rip+0xdc2f1]        # 280690 <_DYNAMIC+0x2b8>
  1a439f:	48 8d 15 82 33 0d 00 	lea    rdx,[rip+0xd3382]        # 277728 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1a43a6:	4c 89 ff             	mov    rdi,r15
  1a43a9:	48 8b 74 24 18       	mov    rsi,QWORD PTR [rsp+0x18]
  1a43ae:	c5 f8 77             	vzeroupper
  1a43b1:	ff 15 d9 c2 0d 00    	call   QWORD PTR [rip+0xdc2d9]        # 280690 <_DYNAMIC+0x2b8>
  1a43b7:	48 8d 15 02 2c 0d 00 	lea    rdx,[rip+0xd2c02]        # 276fc0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa58>
  1a43be:	4c 89 c7             	mov    rdi,r8
  1a43c1:	4c 89 c6             	mov    rsi,r8
  1a43c4:	c5 f8 77             	vzeroupper
  1a43c7:	ff 15 c3 c2 0d 00    	call   QWORD PTR [rip+0xdc2c3]        # 280690 <_DYNAMIC+0x2b8>
  1a43cd:	48 8d 15 04 2c 0d 00 	lea    rdx,[rip+0xd2c04]        # 276fd8 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa70>
  1a43d4:	4c 89 d7             	mov    rdi,r10
  1a43d7:	4c 89 d6             	mov    rsi,r10
  1a43da:	c5 f8 77             	vzeroupper
  1a43dd:	ff 15 ad c2 0d 00    	call   QWORD PTR [rip+0xdc2ad]        # 280690 <_DYNAMIC+0x2b8>
  1a43e3:	48 8d 15 06 2c 0d 00 	lea    rdx,[rip+0xd2c06]        # 276ff0 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa88>
  1a43ea:	4c 89 f7             	mov    rdi,r14
  1a43ed:	4c 89 f6             	mov    rsi,r14
  1a43f0:	c5 f8 77             	vzeroupper
  1a43f3:	ff 15 97 c2 0d 00    	call   QWORD PTR [rip+0xdc297]        # 280690 <_DYNAMIC+0x2b8>
  1a43f9:	48 8d 15 60 2b 0d 00 	lea    rdx,[rip+0xd2b60]        # 276f60 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x9f8>
  1a4400:	31 ff                	xor    edi,edi
  1a4402:	31 f6                	xor    esi,esi
  1a4404:	c5 f8 77             	vzeroupper
  1a4407:	ff 15 83 c2 0d 00    	call   QWORD PTR [rip+0xdc283]        # 280690 <_DYNAMIC+0x2b8>
  1a440d:	48 8d 15 64 2b 0d 00 	lea    rdx,[rip+0xd2b64]        # 276f78 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa10>
  1a4414:	31 ff                	xor    edi,edi
  1a4416:	31 f6                	xor    esi,esi
  1a4418:	c5 f8 77             	vzeroupper
  1a441b:	ff 15 6f c2 0d 00    	call   QWORD PTR [rip+0xdc26f]        # 280690 <_DYNAMIC+0x2b8>
  1a4421:	48 8d 15 68 2b 0d 00 	lea    rdx,[rip+0xd2b68]        # 276f90 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0xa28>
  1a4428:	31 ff                	xor    edi,edi
  1a442a:	31 f6                	xor    esi,esi
  1a442c:	c5 f8 77             	vzeroupper
  1a442f:	ff 15 5b c2 0d 00    	call   QWORD PTR [rip+0xdc25b]        # 280690 <_DYNAMIC+0x2b8>
  1a4435:	48 8d 15 ec 32 0d 00 	lea    rdx,[rip+0xd32ec]        # 277728 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1a443c:	c5 f8 77             	vzeroupper
  1a443f:	ff 15 4b c2 0d 00    	call   QWORD PTR [rip+0xdc24b]        # 280690 <_DYNAMIC+0x2b8>
  1a4445:	48 8d 15 dc 32 0d 00 	lea    rdx,[rip+0xd32dc]        # 277728 <anon.cc766c50d6f6989ff40805d0f8c3184f.50.llvm.8891494790698771628+0x11c0>
  1a444c:	4c 89 d6             	mov    rsi,r10
  1a444f:	c5 f8 77             	vzeroupper
  1a4452:	ff 15 38 c2 0d 00    	call   QWORD PTR [rip+0xdc238]        # 280690 <_DYNAMIC+0x2b8>
