
/tmp/rustsht-b1-f64-seed-normalizer-20261101/rust-parent:     file format elf64-x86-64


Disassembly of section .text:

00000000001c3e20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>>:
  1c3e20:	55                   	push   %rbp
  1c3e21:	41 57                	push   %r15
  1c3e23:	41 56                	push   %r14
  1c3e25:	41 55                	push   %r13
  1c3e27:	41 54                	push   %r12
  1c3e29:	53                   	push   %rbx
  1c3e2a:	48 81 ec 08 02 00 00 	sub    $0x208,%rsp
  1c3e31:	48 89 fb             	mov    %rdi,%rbx
  1c3e34:	48 8b 86 d8 00 00 00 	mov    0xd8(%rsi),%rax
  1c3e3b:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  1c3e40:	48 8b 86 e0 00 00 00 	mov    0xe0(%rsi),%rax
  1c3e47:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
  1c3e4e:	00 
  1c3e4f:	0f b6 86 e8 00 00 00 	movzbl 0xe8(%rsi),%eax
  1c3e56:	88 44 24 57          	mov    %al,0x57(%rsp)
  1c3e5a:	48 8b 06             	mov    (%rsi),%rax
  1c3e5d:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  1c3e64:	00 
  1c3e65:	48 8b 46 08          	mov    0x8(%rsi),%rax
  1c3e69:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  1c3e70:	00 
  1c3e71:	48 8b 46 10          	mov    0x10(%rsi),%rax
  1c3e75:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  1c3e7c:	00 
  1c3e7d:	48 8b 46 18          	mov    0x18(%rsi),%rax
  1c3e81:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
  1c3e88:	00 
  1c3e89:	48 8b 46 20          	mov    0x20(%rsi),%rax
  1c3e8d:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  1c3e94:	00 
  1c3e95:	48 8b 46 28          	mov    0x28(%rsi),%rax
  1c3e99:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  1c3ea0:	00 
  1c3ea1:	48 8b 46 30          	mov    0x30(%rsi),%rax
  1c3ea5:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  1c3eac:	00 
  1c3ead:	48 8b 46 38          	mov    0x38(%rsi),%rax
  1c3eb1:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  1c3eb8:	00 
  1c3eb9:	48 8b 46 40          	mov    0x40(%rsi),%rax
  1c3ebd:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
  1c3ec4:	00 
  1c3ec5:	48 8b 46 58          	mov    0x58(%rsi),%rax
  1c3ec9:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  1c3ed0:	00 
  1c3ed1:	48 8b 46 60          	mov    0x60(%rsi),%rax
  1c3ed5:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  1c3eda:	48 8b 46 68          	mov    0x68(%rsi),%rax
  1c3ede:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  1c3ee5:	00 
  1c3ee6:	48 8b 46 70          	mov    0x70(%rsi),%rax
  1c3eea:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
  1c3ef1:	00 
  1c3ef2:	48 8b 46 78          	mov    0x78(%rsi),%rax
  1c3ef6:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  1c3efd:	00 
  1c3efe:	48 8b 86 80 00 00 00 	mov    0x80(%rsi),%rax
  1c3f05:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  1c3f0c:	00 
  1c3f0d:	48 8b 86 88 00 00 00 	mov    0x88(%rsi),%rax
  1c3f14:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  1c3f1b:	00 
  1c3f1c:	48 8b 86 90 00 00 00 	mov    0x90(%rsi),%rax
  1c3f23:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  1c3f2a:	00 
  1c3f2b:	48 8b 86 98 00 00 00 	mov    0x98(%rsi),%rax
  1c3f32:	4c 8b be a0 00 00 00 	mov    0xa0(%rsi),%r15
  1c3f39:	4c 8b b6 a8 00 00 00 	mov    0xa8(%rsi),%r14
  1c3f40:	4c 8b ae b0 00 00 00 	mov    0xb0(%rsi),%r13
  1c3f47:	48 8b 8e b8 00 00 00 	mov    0xb8(%rsi),%rcx
  1c3f4e:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  1c3f53:	48 8b 8e c0 00 00 00 	mov    0xc0(%rsi),%rcx
  1c3f5a:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
  1c3f5f:	48 8b ae c8 00 00 00 	mov    0xc8(%rsi),%rbp
  1c3f66:	4c 8b a6 d0 00 00 00 	mov    0xd0(%rsi),%r12
  1c3f6d:	4c 89 24 24          	mov    %r12,(%rsp)
  1c3f71:	48 8d bc 24 b8 01 00 	lea    0x1b8(%rsp),%rdi
  1c3f78:	00 
  1c3f79:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  1c3f7e:	48 89 c6             	mov    %rax,%rsi
  1c3f81:	4c 89 fa             	mov    %r15,%rdx
  1c3f84:	4c 89 f1             	mov    %r14,%rcx
  1c3f87:	4d 89 e8             	mov    %r13,%r8
  1c3f8a:	49 89 e9             	mov    %rbp,%r9
  1c3f8d:	ff 15 f5 62 0e 00    	call   *0xe62f5(%rip)        # 2aa288 <_DYNAMIC+0x5d8>
  1c3f93:	48 8b 84 24 b8 01 00 	mov    0x1b8(%rsp),%rax
  1c3f9a:	00 
  1c3f9b:	0f b6 8c 24 c0 01 00 	movzbl 0x1c0(%rsp),%ecx
  1c3fa2:	00 
  1c3fa3:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  1c3fa7:	74 27                	je     1c3fd0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1b0>
  1c3fa9:	c5 f9 10 84 24 c1 01 	vmovupd 0x1c1(%rsp),%xmm0
  1c3fb0:	00 00 
  1c3fb2:	c5 f9 10 8c 24 d0 01 	vmovupd 0x1d0(%rsp),%xmm1
  1c3fb9:	00 00 
  1c3fbb:	c5 f9 11 4b 18       	vmovupd %xmm1,0x18(%rbx)
  1c3fc0:	c5 f9 11 43 09       	vmovupd %xmm0,0x9(%rbx)
  1c3fc5:	48 89 03             	mov    %rax,(%rbx)
  1c3fc8:	88 4b 08             	mov    %cl,0x8(%rbx)
  1c3fcb:	e9 f2 00 00 00       	jmp    1c40c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x2a2>
  1c3fd0:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
  1c3fd5:	4c 8b 94 24 28 01 00 	mov    0x128(%rsp),%r10
  1c3fdc:	00 
  1c3fdd:	48 89 9c 24 c8 00 00 	mov    %rbx,0xc8(%rsp)
  1c3fe4:	00 
  1c3fe5:	88 4c 24 17          	mov    %cl,0x17(%rsp)
  1c3fe9:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
  1c3fee:	4c 89 74 24 38       	mov    %r14,0x38(%rsp)
  1c3ff3:	48 89 ac 24 10 01 00 	mov    %rbp,0x110(%rsp)
  1c3ffa:	00 
  1c3ffb:	4c 89 a4 24 08 01 00 	mov    %r12,0x108(%rsp)
  1c4002:	00 
  1c4003:	4c 89 6c 24 58       	mov    %r13,0x58(%rsp)
  1c4008:	48 8b bc 24 98 01 00 	mov    0x198(%rsp),%rdi
  1c400f:	00 
  1c4010:	48 8b 9c 24 e8 00 00 	mov    0xe8(%rsp),%rbx
  1c4017:	00 
  1c4018:	49 89 d9             	mov    %rbx,%r9
  1c401b:	49 c1 e9 02          	shr    $0x2,%r9
  1c401f:	4c 8b b4 24 20 01 00 	mov    0x120(%rsp),%r14
  1c4026:	00 
  1c4027:	4c 89 f0             	mov    %r14,%rax
  1c402a:	48 c1 e8 02          	shr    $0x2,%rax
  1c402e:	4c 8b ac 24 40 01 00 	mov    0x140(%rsp),%r13
  1c4035:	00 
  1c4036:	4c 89 e9             	mov    %r13,%rcx
  1c4039:	48 c1 e9 02          	shr    $0x2,%rcx
  1c403d:	48 8b ac 24 18 01 00 	mov    0x118(%rsp),%rbp
  1c4044:	00 
  1c4045:	48 89 ea             	mov    %rbp,%rdx
  1c4048:	48 c1 ea 02          	shr    $0x2,%rdx
  1c404c:	4c 8b 5c 24 70       	mov    0x70(%rsp),%r11
  1c4051:	4c 89 de             	mov    %r11,%rsi
  1c4054:	48 c1 ee 02          	shr    $0x2,%rsi
  1c4058:	4c 31 c8             	xor    %r9,%rax
  1c405b:	4c 31 c9             	xor    %r9,%rcx
  1c405e:	48 09 c1             	or     %rax,%rcx
  1c4061:	4c 31 ca             	xor    %r9,%rdx
  1c4064:	48 09 ca             	or     %rcx,%rdx
  1c4067:	4c 89 4c 24 68       	mov    %r9,0x68(%rsp)
  1c406c:	4c 31 ce             	xor    %r9,%rsi
  1c406f:	48 09 d6             	or     %rdx,%rsi
  1c4072:	75 3b                	jne    1c40af <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x28f>
  1c4074:	4c 89 f6             	mov    %r14,%rsi
  1c4077:	4c 89 ea             	mov    %r13,%rdx
  1c407a:	48 89 e9             	mov    %rbp,%rcx
  1c407d:	4c 89 d8             	mov    %r11,%rax
  1c4080:	49 89 db             	mov    %rbx,%r11
  1c4083:	41 83 e3 03          	and    $0x3,%r11d
  1c4087:	83 e0 03             	and    $0x3,%eax
  1c408a:	83 e1 03             	and    $0x3,%ecx
  1c408d:	83 e2 03             	and    $0x3,%edx
  1c4090:	83 e6 03             	and    $0x3,%esi
  1c4093:	4c 31 de             	xor    %r11,%rsi
  1c4096:	4c 31 da             	xor    %r11,%rdx
  1c4099:	48 09 f2             	or     %rsi,%rdx
  1c409c:	4c 31 d9             	xor    %r11,%rcx
  1c409f:	48 09 d1             	or     %rdx,%rcx
  1c40a2:	4c 89 5c 24 60       	mov    %r11,0x60(%rsp)
  1c40a7:	4c 31 d8             	xor    %r11,%rax
  1c40aa:	48 09 c8             	or     %rcx,%rax
  1c40ad:	74 28                	je     1c40d7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x2b7>
  1c40af:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  1c40b6:	00 
  1c40b7:	c6 40 08 00          	movb   $0x0,0x8(%rax)
  1c40bb:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
  1c40c2:	48 81 c4 08 02 00 00 	add    $0x208,%rsp
  1c40c9:	5b                   	pop    %rbx
  1c40ca:	41 5c                	pop    %r12
  1c40cc:	41 5d                	pop    %r13
  1c40ce:	41 5e                	pop    %r14
