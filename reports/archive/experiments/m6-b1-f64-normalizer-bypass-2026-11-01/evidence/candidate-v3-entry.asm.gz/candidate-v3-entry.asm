
/tmp/rustsht-b1-f64-seed-normalizer-20261101/rust-candidate:     file format elf64-x86-64


Disassembly of section .text:

00000000001c3d10 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>>:
  1c3d10:	55                   	push   %rbp
  1c3d11:	41 57                	push   %r15
  1c3d13:	41 56                	push   %r14
  1c3d15:	41 55                	push   %r13
  1c3d17:	41 54                	push   %r12
  1c3d19:	53                   	push   %rbx
  1c3d1a:	48 81 ec f8 01 00 00 	sub    $0x1f8,%rsp
  1c3d21:	48 89 bc 24 80 00 00 	mov    %rdi,0x80(%rsp)
  1c3d28:	00 
  1c3d29:	48 8b 86 d8 00 00 00 	mov    0xd8(%rsi),%rax
  1c3d30:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  1c3d35:	48 8b be e0 00 00 00 	mov    0xe0(%rsi),%rdi
  1c3d3c:	0f b6 8e e8 00 00 00 	movzbl 0xe8(%rsi),%ecx
  1c3d43:	48 8b 06             	mov    (%rsi),%rax
  1c3d46:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  1c3d4d:	00 
  1c3d4e:	48 8b 46 08          	mov    0x8(%rsi),%rax
  1c3d52:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
  1c3d59:	00 
  1c3d5a:	4c 8b 6e 10          	mov    0x10(%rsi),%r13
  1c3d5e:	4c 8b 76 18          	mov    0x18(%rsi),%r14
  1c3d62:	4c 8b 46 20          	mov    0x20(%rsi),%r8
  1c3d66:	48 8b 6e 28          	mov    0x28(%rsi),%rbp
  1c3d6a:	4c 8b 7e 30          	mov    0x30(%rsi),%r15
  1c3d6e:	4c 8b 5e 38          	mov    0x38(%rsi),%r11
  1c3d72:	4c 8b 56 40          	mov    0x40(%rsi),%r10
  1c3d76:	48 8b 46 58          	mov    0x58(%rsi),%rax
  1c3d7a:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  1c3d81:	00 
  1c3d82:	48 8b 5e 60          	mov    0x60(%rsi),%rbx
  1c3d86:	48 8b 46 68          	mov    0x68(%rsi),%rax
  1c3d8a:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  1c3d91:	00 
  1c3d92:	48 8b 46 70          	mov    0x70(%rsi),%rax
  1c3d96:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  1c3d9d:	00 
  1c3d9e:	48 8b 46 78          	mov    0x78(%rsi),%rax
  1c3da2:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  1c3da9:	00 
  1c3daa:	48 8b 86 80 00 00 00 	mov    0x80(%rsi),%rax
  1c3db1:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  1c3db8:	00 
  1c3db9:	48 8b 96 88 00 00 00 	mov    0x88(%rsi),%rdx
  1c3dc0:	48 8b 86 90 00 00 00 	mov    0x90(%rsi),%rax
  1c3dc7:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  1c3dcc:	48 8b 86 98 00 00 00 	mov    0x98(%rsi),%rax
  1c3dd3:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  1c3dda:	00 
  1c3ddb:	48 8b 86 a0 00 00 00 	mov    0xa0(%rsi),%rax
  1c3de2:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  1c3de7:	4c 8b a6 a8 00 00 00 	mov    0xa8(%rsi),%r12
  1c3dee:	48 8b 86 b0 00 00 00 	mov    0xb0(%rsi),%rax
  1c3df5:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  1c3dfa:	48 8b 86 b8 00 00 00 	mov    0xb8(%rsi),%rax
  1c3e01:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  1c3e06:	48 8b 86 c0 00 00 00 	mov    0xc0(%rsi),%rax
  1c3e0d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  1c3e12:	4c 8b 8e c8 00 00 00 	mov    0xc8(%rsi),%r9
  1c3e19:	48 8b 86 d0 00 00 00 	mov    0xd0(%rsi),%rax
  1c3e20:	c6 44 24 0f 01       	movb   $0x1,0xf(%rsp)
  1c3e25:	48 89 bc 24 30 01 00 	mov    %rdi,0x130(%rsp)
  1c3e2c:	00 
  1c3e2d:	48 81 ff fe 01 00 00 	cmp    $0x1fe,%rdi
  1c3e34:	4c 89 9c 24 f0 00 00 	mov    %r11,0xf0(%rsp)
  1c3e3b:	00 
  1c3e3c:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  1c3e41:	0f 87 da 00 00 00    	ja     1c3f21 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x211>
  1c3e47:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
  1c3e4c:	48 89 ac 24 00 01 00 	mov    %rbp,0x100(%rsp)
  1c3e53:	00 
  1c3e54:	4c 89 94 24 d8 00 00 	mov    %r10,0xd8(%rsp)
  1c3e5b:	00 
  1c3e5c:	4c 89 b4 24 08 01 00 	mov    %r14,0x108(%rsp)
  1c3e63:	00 
  1c3e64:	4c 89 bc 24 e0 00 00 	mov    %r15,0xe0(%rsp)
  1c3e6b:	00 
  1c3e6c:	4c 89 c3             	mov    %r8,%rbx
  1c3e6f:	41 89 ce             	mov    %ecx,%r14d
  1c3e72:	48 89 04 24          	mov    %rax,(%rsp)
  1c3e76:	48 8d bc 24 a8 01 00 	lea    0x1a8(%rsp),%rdi
  1c3e7d:	00 
  1c3e7e:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  1c3e85:	00 
  1c3e86:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  1c3e8b:	4c 89 e1             	mov    %r12,%rcx
  1c3e8e:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  1c3e93:	4c 89 cd             	mov    %r9,%rbp
  1c3e96:	49 89 c7             	mov    %rax,%r15
  1c3e99:	ff 15 49 62 0e 00    	call   *0xe6249(%rip)        # 2aa0e8 <_DYNAMIC+0x5d8>
  1c3e9f:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
  1c3ea6:	00 
  1c3ea7:	0f b6 94 24 b0 01 00 	movzbl 0x1b0(%rsp),%edx
  1c3eae:	00 
  1c3eaf:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  1c3eb3:	74 2f                	je     1c3ee4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x1d4>
  1c3eb5:	c5 f9 10 84 24 b1 01 	vmovupd 0x1b1(%rsp),%xmm0
  1c3ebc:	00 00 
  1c3ebe:	c5 f9 10 8c 24 c0 01 	vmovupd 0x1c0(%rsp),%xmm1
  1c3ec5:	00 00 
  1c3ec7:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  1c3ece:	00 
  1c3ecf:	c5 f9 11 49 18       	vmovupd %xmm1,0x18(%rcx)
  1c3ed4:	c5 f9 11 41 09       	vmovupd %xmm0,0x9(%rcx)
  1c3ed9:	48 89 01             	mov    %rax,(%rcx)
  1c3edc:	88 51 08             	mov    %dl,0x8(%rcx)
  1c3edf:	e9 dc 00 00 00       	jmp    1c3fc0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x2b0>
  1c3ee4:	44 89 f1             	mov    %r14d,%ecx
  1c3ee7:	49 89 d8             	mov    %rbx,%r8
  1c3eea:	4c 89 f8             	mov    %r15,%rax
  1c3eed:	4c 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%r15
  1c3ef4:	00 
  1c3ef5:	4c 8b b4 24 08 01 00 	mov    0x108(%rsp),%r14
  1c3efc:	00 
  1c3efd:	4c 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%r10
  1c3f04:	00 
  1c3f05:	49 89 e9             	mov    %rbp,%r9
  1c3f08:	48 8b ac 24 00 01 00 	mov    0x100(%rsp),%rbp
  1c3f0f:	00 
  1c3f10:	4c 8b 9c 24 f0 00 00 	mov    0xf0(%rsp),%r11
  1c3f17:	00 
  1c3f18:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
  1c3f1d:	88 54 24 0f          	mov    %dl,0xf(%rsp)
  1c3f21:	4c 89 8c 24 18 01 00 	mov    %r9,0x118(%rsp)
  1c3f28:	00 
  1c3f29:	88 4c 24 2f          	mov    %cl,0x2f(%rsp)
  1c3f2d:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  1c3f34:	00 
  1c3f35:	4c 89 ef             	mov    %r13,%rdi
  1c3f38:	48 c1 ef 02          	shr    $0x2,%rdi
  1c3f3c:	4c 89 c0             	mov    %r8,%rax
  1c3f3f:	48 c1 e8 02          	shr    $0x2,%rax
  1c3f43:	4c 89 f9             	mov    %r15,%rcx
  1c3f46:	48 c1 e9 02          	shr    $0x2,%rcx
  1c3f4a:	4c 89 d2             	mov    %r10,%rdx
  1c3f4d:	48 c1 ea 02          	shr    $0x2,%rdx
  1c3f51:	48 89 de             	mov    %rbx,%rsi
  1c3f54:	48 c1 ee 02          	shr    $0x2,%rsi
  1c3f58:	48 31 f8             	xor    %rdi,%rax
  1c3f5b:	48 31 f9             	xor    %rdi,%rcx
  1c3f5e:	48 09 c1             	or     %rax,%rcx
  1c3f61:	48 31 fa             	xor    %rdi,%rdx
  1c3f64:	48 09 ca             	or     %rcx,%rdx
  1c3f67:	48 89 7c 24 58       	mov    %rdi,0x58(%rsp)
  1c3f6c:	48 31 fe             	xor    %rdi,%rsi
  1c3f6f:	48 09 d6             	or     %rdx,%rsi
  1c3f72:	75 39                	jne    1c3fad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x29d>
  1c3f74:	44 89 ef             	mov    %r13d,%edi
  1c3f77:	83 e7 03             	and    $0x3,%edi
  1c3f7a:	89 d8                	mov    %ebx,%eax
  1c3f7c:	83 e0 03             	and    $0x3,%eax
  1c3f7f:	44 89 d1             	mov    %r10d,%ecx
  1c3f82:	83 e1 03             	and    $0x3,%ecx
  1c3f85:	44 89 fa             	mov    %r15d,%edx
  1c3f88:	83 e2 03             	and    $0x3,%edx
  1c3f8b:	44 89 c6             	mov    %r8d,%esi
  1c3f8e:	83 e6 03             	and    $0x3,%esi
  1c3f91:	48 31 fe             	xor    %rdi,%rsi
  1c3f94:	48 31 fa             	xor    %rdi,%rdx
  1c3f97:	48 09 f2             	or     %rsi,%rdx
  1c3f9a:	48 31 f9             	xor    %rdi,%rcx
  1c3f9d:	48 09 d1             	or     %rdx,%rcx
  1c3fa0:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
  1c3fa5:	48 31 f8             	xor    %rdi,%rax
  1c3fa8:	48 09 c8             	or     %rcx,%rax
  1c3fab:	74 28                	je     1c3fd5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScalarAnalysisPairTyped<f64>>>+0x2c5>
  1c3fad:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  1c3fb4:	00 
  1c3fb5:	c6 40 08 00          	movb   $0x0,0x8(%rax)
  1c3fb9:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
