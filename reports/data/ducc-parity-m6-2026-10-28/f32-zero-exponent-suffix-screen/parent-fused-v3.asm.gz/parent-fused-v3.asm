
matched release binary: ELF64 x86-64


Disassembly of section .text:

0000000000141fd0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>>:
  141fd0:	push   %rbp
  141fd1:	push   %r15
  141fd3:	push   %r14
  141fd5:	push   %r13
  141fd7:	push   %r12
  141fd9:	push   %rbx
  141fda:	sub    $0xe8,%rsp
  141fe1:	mov    0x88(%rdi),%r13
  141fe8:	mov    (%rdi),%r10
  141feb:	mov    0x8(%rdi),%r12
  141fef:	mov    0x10(%rdi),%rax
  141ff3:	mov    %rax,0x60(%rsp)
  141ff8:	mov    0x18(%rdi),%rax
  141ffc:	mov    %rax,0x70(%rsp)
  142001:	mov    0x20(%rdi),%r15
  142005:	mov    0x28(%rdi),%rax
  142009:	mov    %rax,0x68(%rsp)
  14200e:	mov    0x30(%rdi),%rcx
  142012:	mov    0x38(%rdi),%r8
  142016:	mov    0x40(%rdi),%rdx
  14201a:	mov    0x48(%rdi),%r9
  14201e:	mov    0x50(%rdi),%r14
  142022:	mov    0x58(%rdi),%rbx
  142026:	sub    0x80(%rdi),%r13
  14202d:	mov    0x60(%rdi),%rax
  142031:	mov    %rax,0x18(%rsp)
  142036:	mov    0x68(%rdi),%rbp
  14203a:	mov    0x70(%rdi),%rax
  14203e:	mov    %rax,0x58(%rsp)
  142043:	mov    0x78(%rdi),%rax
  142047:	mov    %r12,%r11
  14204a:	shr    $0x3,%r11
  14204e:	mov    %r12,0x90(%rsp)
  142056:	and    $0x7,%r12d
  14205a:	mov    %r12,0x28(%rsp)
  14205f:	mov    %rbx,0x48(%rsp)
  142064:	mov    %ebx,%edi
  142066:	and    $0x7,%edi
  142069:	mov    %rdi,0x20(%rsp)
  14206e:	mov    %rbp,0x38(%rsp)
  142073:	and    $0x7,%ebp
  142076:	mov    %rbp,0x10(%rsp)
  14207b:	mov    %rax,0x40(%rsp)
  142080:	and    $0x7,%eax
  142083:	mov    %rax,0x8(%rsp)
  142088:	add    $0x2,%r13
  14208c:	shr    $1,%r13
  14208f:	mov    %r11,0x50(%rsp)
  142094:	test   %r11,%r11
  142097:	je     1422b5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x2e5>
  14209d:	mov    0x48(%rsp),%rbx
  1420a2:	shr    $0x3,%rbx
  1420a6:	mov    0x38(%rsp),%rsi
  1420ab:	shr    $0x3,%rsi
  1420af:	mov    0x40(%rsp),%rdi
  1420b4:	shr    $0x3,%rdi
  1420b8:	test   %r13,%r13
  1420bb:	mov    %rsi,0x30(%rsp)
  1420c0:	je     142359 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x389>
  1420c6:	xor    %r11d,%r11d
  1420c9:	vpbroadcastd -0x1244e2(%rip),%ymm0        # 1dbf0 <__abi_tag+0x1d8f4>
  1420d2:	vmovdqu %ymm0,0xa0(%rsp)
  1420db:	mov    %r10,0x88(%rsp)
  1420e3:	mov    %r14,0x80(%rsp)
  1420eb:	mov    %rdi,0x78(%rsp)
  1420f0:	mov    0x70(%rsp),%r12
  1420f5:	mov    0x60(%rsp),%rbp
  1420fa:	vbroadcastss -0x124733(%rip),%ymm3        # 1d9d0 <__abi_tag+0x1d6d4>
  142103:	vxorps %xmm8,%xmm8,%xmm8
  142108:	jmp    142149 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x179>
  14210a:	nopw   0x0(%rax,%rax,1)
  142110:	vmovups %ymm6,(%r10)
  142115:	mov    0x98(%rsp),%rax
  14211d:	vmovups %ymm7,(%rax)
  142121:	mov    %rdi,%r11
  142124:	cmp    0x50(%rsp),%rdi
  142129:	mov    0x88(%rsp),%r10
  142131:	mov    0x80(%rsp),%r14
  142139:	mov    0x78(%rsp),%rdi
  14213e:	mov    0x30(%rsp),%rsi
  142143:	je     1422b5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x2e5>
  142149:	cmp    %rbx,%r11
  14214c:	je     14265e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x68e>
  142152:	cmp    %rsi,%r11
  142155:	mov    0x68(%rsp),%rsi
  14215a:	je     142646 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x676>
  142160:	cmp    %rdi,%r11
  142163:	je     142633 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x663>
  142169:	lea    0x1(%r11),%rdi
  14216d:	shl    $0x5,%r11
  142171:	vmovups (%r10,%r11,1),%ymm5
  142177:	vmovups (%r14,%r11,1),%ymm9
  14217d:	mov    0x18(%rsp),%r10
  142182:	add    %r11,%r10
  142185:	vmovups (%r10),%ymm6
  14218a:	mov    0x58(%rsp),%r14
  14218f:	lea    (%r14,%r11,1),%rax
  142193:	mov    %rax,0x98(%rsp)
  14219b:	vmovups (%r14,%r11,1),%ymm7
  1421a1:	vmulps %ymm5,%ymm5,%ymm0
  1421a5:	vmovups %ymm0,0xc0(%rsp)
  1421ae:	vxorps %xmm10,%xmm10,%xmm10
  1421b3:	xor    %r14d,%r14d
  1421b6:	jmp    1421ea <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x21a>
  1421b8:	nopl   0x0(%rax,%rax,1)
  1421c0:	vmovaps %ymm9,%ymm15
  1421c5:	vfmadd213ps %ymm13,%ymm5,%ymm11
  1421ca:	vfmadd213ps %ymm14,%ymm5,%ymm12
  1421cf:	vfmadd231ps %ymm11,%ymm9,%ymm6
  1421d4:	vfmadd231ps %ymm12,%ymm9,%ymm7
  1421d9:	mov    %r11,%r14
  1421dc:	vmovaps %ymm15,%ymm9
  1421e1:	cmp    %r11,%r13
  1421e4:	je     142110 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x140>
  1421ea:	cmp    %r14,%r8
  1421ed:	je     14259f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5cf>
  1421f3:	cmp    %r14,%r9
  1421f6:	je     142589 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5b9>
  1421fc:	lea    0x1(%r14),%r11
  142200:	vbroadcastss (%rdx,%r14,8),%ymm11
  142206:	vbroadcastss (%rcx,%r14,8),%ymm13
  14220c:	vbroadcastss 0x4(%rdx,%r14,8),%ymm12
  142213:	vbroadcastss 0x4(%rcx,%r14,8),%ymm14
  14221a:	cmp    %r13,%r11
  14221d:	jae    1421c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1f0>
  14221f:	cmp    %r12,%r14
  142222:	jae    1425b5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5e5>
  142228:	cmp    %rsi,%r14
  14222b:	jae    1425cb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5fb>
  142231:	vbroadcastss 0x0(%rbp,%r14,4),%ymm4
  142238:	vbroadcastss (%r15,%r14,4),%ymm15
  14223e:	vfmadd231ps 0xc0(%rsp),%ymm4,%ymm15
  142248:	vfmadd213ps %ymm10,%ymm9,%ymm15
  14224d:	vmovups 0xa0(%rsp),%ymm0
  142256:	vandps %ymm0,%ymm9,%ymm4
  14225a:	vandps %ymm0,%ymm15,%ymm10
  14225e:	vcmple_oqps %ymm3,%ymm4,%ymm1
  142263:	vcmpeqps %ymm4,%ymm8,%ymm2
  142268:	vbroadcastss -0x1246c1(%rip),%ymm0        # 1dbb0 <__abi_tag+0x1d8b4>
  142271:	vcmpge_oqps %ymm0,%ymm4,%ymm4
  142276:	vorps  %ymm2,%ymm4,%ymm2
  14227a:	vandps %ymm1,%ymm2,%ymm1
  14227e:	vcmple_oqps %ymm3,%ymm10,%ymm2
  142283:	vandps %ymm2,%ymm1,%ymm1
  142287:	vcmpeqps %ymm8,%ymm10,%ymm2
  14228d:	vcmpge_oqps %ymm0,%ymm10,%ymm4
  142292:	vorps  %ymm2,%ymm4,%ymm2
  142296:	vandps %ymm2,%ymm1,%ymm1
  14229a:	vpcmpeqd %ymm0,%ymm0,%ymm0
  14229e:	vptest %ymm0,%ymm1
  1422a3:	vmovaps %ymm9,%ymm10
  1422a8:	jb     1421c5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1f5>
  1422ae:	xor    %eax,%eax
  1422b0:	jmp    142574 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a4>
  1422b5:	mov    0x28(%rsp),%rdi
  1422ba:	test   %rdi,%rdi
  1422bd:	je     142572 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a2>
  1422c3:	test   %r13,%r13
  1422c6:	je     14251d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x54d>
  1422cc:	movabs $0x1ffffffffffffff8,%rax
  1422d6:	mov    0x90(%rsp),%rdi
  1422de:	and    %rax,%rdi
  1422e1:	lea    (%r10,%rdi,4),%rsi
  1422e5:	mov    %rsi,0xc0(%rsp)
  1422ed:	mov    0x48(%rsp),%rdi
  1422f2:	and    %rax,%rdi
  1422f5:	lea    (%r14,%rdi,4),%rsi
  1422f9:	mov    %rsi,0xa0(%rsp)
  142301:	mov    0x38(%rsp),%r10
  142306:	and    %rax,%r10
  142309:	mov    0x18(%rsp),%rdi
  14230e:	lea    (%rdi,%r10,4),%r10
  142312:	mov    0x40(%rsp),%rdi
  142317:	and    %rax,%rdi
  14231a:	mov    0x58(%rsp),%rax
  14231f:	lea    (%rax,%rdi,4),%rdi
  142323:	xor    %r11d,%r11d
  142326:	vpxor  %xmm0,%xmm0,%xmm0
  14232a:	vbroadcastss -0x124743(%rip),%xmm1        # 1dbf0 <__abi_tag+0x1d8f4>
  142333:	vmovss -0x12478b(%rip),%xmm2        # 1dbb0 <__abi_tag+0x1d8b4>
  14233b:	vmovss -0x124973(%rip),%xmm3        # 1d9d0 <__abi_tag+0x1d6d4>
  142343:	mov    0x70(%rsp),%r12
  142348:	mov    0x68(%rsp),%rsi
  14234d:	mov    0x60(%rsp),%rbp
  142352:	mov    %r10,0x18(%rsp)
  142357:	jmp    1423c1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x3f1>
  142359:	cmp    %rbx,%rsi
  14235c:	mov    %rbx,%rcx
  14235f:	cmovb  %rsi,%rcx
  142363:	cmp    %rdi,%rcx
  142366:	cmovae %rdi,%rcx
  14236a:	mov    0x50(%rsp),%rdx
  14236f:	dec    %rdx
  142372:	cmp    %rdx,%rcx
  142375:	mov    %rdx,%rax
  142378:	cmovb  %rcx,%rdx
  14237c:	cmp    %rdx,%rbx
  14237f:	je     14265e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x68e>
  142385:	cmp    %rdx,%rsi
  142388:	je     142646 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x676>
  14238e:	cmp    %rdx,%rdi
  142391:	je     142633 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x663>
  142397:	cmp    %rcx,%rax
  14239a:	jbe    142513 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x543>
  1423a0:	jmp    1423a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x3d0>
  1423a2:	mov    0x18(%rsp),%r10
  1423a7:	vmovss %xmm7,(%r10,%r11,4)
  1423ad:	vmovss %xmm8,(%rdi,%r11,4)
  1423b3:	mov    %rbx,%r11
  1423b6:	cmp    0x28(%rsp),%rbx
  1423bb:	je     142572 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a2>
  1423c1:	cmp    0x20(%rsp),%r11
  1423c6:	je     1426a4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x6d4>
  1423cc:	cmp    0x10(%rsp),%r11
  1423d1:	je     14268c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x6bc>
  1423d7:	cmp    0x8(%rsp),%r11
  1423dc:	je     142674 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x6a4>
  1423e2:	lea    0x1(%r11),%rbx
  1423e6:	mov    0xc0(%rsp),%rax
  1423ee:	vmovss (%rax,%r11,4),%xmm4
  1423f4:	mov    0xa0(%rsp),%rax
  1423fc:	vmovss (%rax,%r11,4),%xmm6
  142402:	vmovss (%r10,%r11,4),%xmm7
  142408:	vmovss (%rdi,%r11,4),%xmm8
  14240e:	vmulss %xmm4,%xmm4,%xmm5
  142412:	vxorps %xmm11,%xmm11,%xmm11
  142417:	xor    %r10d,%r10d
  14241a:	jmp    14243e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x46e>
  14241c:	nopl   0x0(%rax)
  142420:	vmovaps %xmm6,%xmm12
  142424:	vfmadd213ss %xmm10,%xmm6,%xmm7
  142429:	vfmadd213ss %xmm9,%xmm6,%xmm8
  14242e:	mov    %r14,%r10
  142431:	vmovaps %xmm12,%xmm6
  142435:	cmp    %r14,%r13
  142438:	je     1423a2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x3d2>
  14243e:	cmp    %r10,%r8
  142441:	je     1425de <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x60e>
  142447:	cmp    %r10,%r9
  14244a:	je     1425f4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x624>
  142450:	vmovaps %xmm7,%xmm10
  142454:	vmovaps %xmm8,%xmm9
  142459:	lea    0x1(%r10),%r14
  14245d:	vmovss (%rdx,%r10,8),%xmm7
  142463:	vfmadd213ss (%rcx,%r10,8),%xmm4,%xmm7
  142469:	vmovss 0x4(%rdx,%r10,8),%xmm8
  142470:	vfmadd213ss 0x4(%rcx,%r10,8),%xmm4,%xmm8
  142477:	cmp    %r13,%r14
  14247a:	jae    142420 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x450>
  14247c:	cmp    %r12,%r10
  14247f:	jae    14261d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x64d>
  142485:	cmp    %rsi,%r10
  142488:	jae    14260a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x63a>
  14248e:	vmovss 0x0(%rbp,%r10,4),%xmm12
  142495:	vfmadd213ss (%r15,%r10,4),%xmm5,%xmm12
  14249b:	vucomiss %xmm0,%xmm6
  14249f:	jne    1424a3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x4d3>
  1424a1:	jnp    1424cf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x4ff>
  1424a3:	vmovd  %xmm6,%eax
  1424a7:	add    %eax,%eax
  1424a9:	cmp    $0xfeffffff,%eax
  1424ae:	ja     1422ae <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x2de>
  1424b4:	vandps %xmm1,%xmm6,%xmm13
  1424b8:	xor    %eax,%eax
  1424ba:	vucomiss %xmm2,%xmm13
  1424be:	jb     142574 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a4>
  1424c4:	vucomiss %xmm13,%xmm3
  1424c9:	jb     142574 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a4>
  1424cf:	vfmadd213ss %xmm11,%xmm6,%xmm12
  1424d4:	vucomiss %xmm0,%xmm12
  1424d8:	jne    1424e5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x515>
  1424da:	jp     1424e5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x515>
  1424dc:	vmovaps %xmm6,%xmm11
  1424e0:	jmp    142424 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x454>
  1424e5:	vmovd  %xmm12,%eax
  1424e9:	add    %eax,%eax
  1424eb:	cmp    $0xfeffffff,%eax
  1424f0:	ja     1422ae <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x2de>
  1424f6:	vandps %xmm1,%xmm12,%xmm11
  1424fa:	xor    %eax,%eax
  1424fc:	vucomiss %xmm2,%xmm11
  142500:	jb     142574 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a4>
  142502:	vucomiss %xmm11,%xmm3
  142507:	vmovaps %xmm6,%xmm11
  14250b:	jae    142424 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x454>
  142511:	jmp    142574 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a4>
  142513:	mov    0x28(%rsp),%rdi
  142518:	test   %rdi,%rdi
  14251b:	je     142572 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a2>
  14251d:	dec    %rdi
  142520:	mov    0x10(%rsp),%rax
  142525:	cmp    %rax,%rdi
  142528:	cmovb  %rdi,%rax
  14252c:	mov    0x20(%rsp),%rdx
  142531:	cmp    %rdx,%rax
  142534:	cmovae %rdx,%rax
  142538:	mov    0x8(%rsp),%rcx
  14253d:	cmp    %rcx,%rax
  142540:	cmovb  %rax,%rcx
  142544:	cmp    %rcx,%rdx
  142547:	je     1426a4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x6d4>
  14254d:	cmp    %ecx,0x10(%rsp)
  142551:	je     14268c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x6bc>
  142557:	cmp    %eax,0x8(%rsp)
  14255b:	jbe    142674 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x6a4>
  142561:	mov    $0x1,%al
  142563:	cmp    %ecx,%edi
  142565:	je     142574 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a4>
  142567:	nopw   0x0(%rax,%rax,1)
  142570:	jmp    142570 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a0>
  142572:	mov    $0x1,%al
  142574:	add    $0xe8,%rsp
  14257b:	pop    %rbx
  14257c:	pop    %r12
  14257e:	pop    %r13
  142580:	pop    %r14
  142582:	pop    %r15
  142584:	pop    %rbp
  142585:	vzeroupper
  142588:	ret
  142589:	lea    0xfb470(%rip),%rdx        # 23da00 <anon.d3955c148a5649dc08b679c338cd5e71.23.llvm.8214180122555259442+0x108>
  142590:	mov    %r9,%rdi
  142593:	mov    %r9,%rsi
  142596:	vzeroupper
  142599:	call   *0x104679(%rip)        # 246c18 <_DYNAMIC+0x260>
  14259f:	lea    0xfb442(%rip),%rdx        # 23d9e8 <anon.d3955c148a5649dc08b679c338cd5e71.23.llvm.8214180122555259442+0xf0>
  1425a6:	mov    %r8,%rdi
  1425a9:	mov    %r8,%rsi
  1425ac:	vzeroupper
  1425af:	call   *0x104663(%rip)        # 246c18 <_DYNAMIC+0x260>
  1425b5:	lea    0xfb45c(%rip),%rdx        # 23da18 <anon.d3955c148a5649dc08b679c338cd5e71.23.llvm.8214180122555259442+0x120>
  1425bc:	mov    %r14,%rdi
  1425bf:	mov    %r12,%rsi
  1425c2:	vzeroupper
  1425c5:	call   *0x10464d(%rip)        # 246c18 <_DYNAMIC+0x260>
  1425cb:	lea    0xfb45e(%rip),%rdx        # 23da30 <anon.d3955c148a5649dc08b679c338cd5e71.23.llvm.8214180122555259442+0x138>
  1425d2:	mov    %r14,%rdi
  1425d5:	vzeroupper
  1425d8:	call   *0x10463a(%rip)        # 246c18 <_DYNAMIC+0x260>
  1425de:	lea    0xfb38b(%rip),%rdx        # 23d970 <anon.d3955c148a5649dc08b679c338cd5e71.23.llvm.8214180122555259442+0x78>
  1425e5:	mov    %r8,%rdi
  1425e8:	mov    %r8,%rsi
  1425eb:	vzeroupper
  1425ee:	call   *0x104624(%rip)        # 246c18 <_DYNAMIC+0x260>
  1425f4:	lea    0xfb38d(%rip),%rdx        # 23d988 <anon.d3955c148a5649dc08b679c338cd5e71.23.llvm.8214180122555259442+0x90>
  1425fb:	mov    %r9,%rdi
  1425fe:	mov    %r9,%rsi
  142601:	vzeroupper
  142604:	call   *0x10460e(%rip)        # 246c18 <_DYNAMIC+0x260>
  14260a:	lea    0xfb3a7(%rip),%rdx        # 23d9b8 <anon.d3955c148a5649dc08b679c338cd5e71.23.llvm.8214180122555259442+0xc0>
  142611:	mov    %r10,%rdi
  142614:	vzeroupper
  142617:	call   *0x1045fb(%rip)        # 246c18 <_DYNAMIC+0x260>
  14261d:	lea    0xfb37c(%rip),%rdx        # 23d9a0 <anon.d3955c148a5649dc08b679c338cd5e71.23.llvm.8214180122555259442+0xa8>
  142624:	mov    %r10,%rdi
  142627:	mov    %r12,%rsi
  14262a:	vzeroupper
  14262d:	call   *0x1045e5(%rip)        # 246c18 <_DYNAMIC+0x260>
  142633:	lea    0xfb456(%rip),%rdx        # 23da90 <anon.d3955c148a5649dc08b679c338cd5e71.23.llvm.8214180122555259442+0x198>
  14263a:	mov    %rdi,%rsi
  14263d:	vzeroupper
  142640:	call   *0x1045d2(%rip)        # 246c18 <_DYNAMIC+0x260>
  142646:	lea    0xfb42b(%rip),%rdx        # 23da78 <anon.d3955c148a5649dc08b679c338cd5e71.23.llvm.8214180122555259442+0x180>
  14264d:	mov    0x30(%rsp),%rdi
  142652:	mov    %rdi,%rsi
  142655:	vzeroupper
  142658:	call   *0x1045ba(%rip)        # 246c18 <_DYNAMIC+0x260>
  14265e:	lea    0xfb36b(%rip),%rdx        # 23d9d0 <anon.d3955c148a5649dc08b679c338cd5e71.23.llvm.8214180122555259442+0xd8>
  142665:	mov    %rbx,%rdi
  142668:	mov    %rbx,%rsi
  14266b:	vzeroupper
  14266e:	call   *0x1045a4(%rip)        # 246c18 <_DYNAMIC+0x260>
  142674:	lea    0xfb3e5(%rip),%rdx        # 23da60 <anon.d3955c148a5649dc08b679c338cd5e71.23.llvm.8214180122555259442+0x168>
  14267b:	mov    0x8(%rsp),%rdi
  142680:	mov    %rdi,%rsi
  142683:	vzeroupper
  142686:	call   *0x10458c(%rip)        # 246c18 <_DYNAMIC+0x260>
  14268c:	lea    0xfb3b5(%rip),%rdx        # 23da48 <anon.d3955c148a5649dc08b679c338cd5e71.23.llvm.8214180122555259442+0x150>
  142693:	mov    0x10(%rsp),%rdi
  142698:	mov    %rdi,%rsi
  14269b:	vzeroupper
  14269e:	call   *0x104574(%rip)        # 246c18 <_DYNAMIC+0x260>
  1426a4:	lea    0xfb2ad(%rip),%rdx        # 23d958 <anon.d3955c148a5649dc08b679c338cd5e71.23.llvm.8214180122555259442+0x60>
  1426ab:	mov    0x20(%rsp),%rdi
  1426b0:	mov    %rdi,%rsi
  1426b3:	vzeroupper
  1426b6:	call   *0x10455c(%rip)        # 246c18 <_DYNAMIC+0x260>
