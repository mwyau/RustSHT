
matched release binary: ELF64 x86-64


Disassembly of section .text:

00000000001d7d10 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>>:
  1d7d10:	push   %rbp
  1d7d11:	push   %r15
  1d7d13:	push   %r14
  1d7d15:	push   %r13
  1d7d17:	push   %r12
  1d7d19:	push   %rbx
  1d7d1a:	sub    $0xd8,%rsp
  1d7d21:	mov    0x98(%rdi),%rdx
  1d7d28:	mov    0xa0(%rdi),%r15
  1d7d2f:	mov    (%rdi),%rax
  1d7d32:	mov    %rax,0x38(%rsp)
  1d7d37:	mov    0x8(%rdi),%rcx
  1d7d3b:	mov    0x10(%rdi),%r13
  1d7d3f:	mov    0x18(%rdi),%rax
  1d7d43:	mov    %rax,0x58(%rsp)
  1d7d48:	mov    0x20(%rdi),%r9
  1d7d4c:	mov    0x28(%rdi),%rsi
  1d7d50:	mov    0x30(%rdi),%r10
  1d7d54:	mov    0x38(%rdi),%rax
  1d7d58:	mov    %rax,0x48(%rsp)
  1d7d5d:	mov    0x40(%rdi),%rbp
  1d7d61:	mov    0x48(%rdi),%rax
  1d7d65:	mov    %rax,0x40(%rsp)
  1d7d6a:	mov    0x50(%rdi),%rax
  1d7d6e:	mov    %rax,0xc0(%rsp)
  1d7d76:	mov    0x58(%rdi),%rax
  1d7d7a:	mov    %rax,0xb0(%rsp)
  1d7d82:	sub    0x90(%rdi),%rdx
  1d7d89:	mov    0x60(%rdi),%rax
  1d7d8d:	mov    %rax,0x8(%rsp)
  1d7d92:	mov    0x68(%rdi),%rax
  1d7d96:	mov    %rax,0xa8(%rsp)
  1d7d9e:	mov    0x70(%rdi),%rax
  1d7da2:	mov    %rax,0x50(%rsp)
  1d7da7:	mov    0x78(%rdi),%r11
  1d7dab:	mov    0x80(%rdi),%rax
  1d7db2:	mov    %rax,0x30(%rsp)
  1d7db7:	mov    0x88(%rdi),%rax
  1d7dbe:	mov    %rax,0xb8(%rsp)
  1d7dc6:	mov    %rcx,0xd0(%rsp)
  1d7dce:	mov    %rcx,%rax
  1d7dd1:	mov    %r11,%rcx
  1d7dd4:	shr    $0x3,%rax
  1d7dd8:	add    $0x2,%rdx
  1d7ddc:	shr    $1,%rdx
  1d7ddf:	mov    %rax,0x18(%rsp)
  1d7de4:	test   %rax,%rax
  1d7de7:	mov    %r15,0xc8(%rsp)
  1d7def:	je     1d8099 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x389>
  1d7df5:	mov    0xb0(%rsp),%r8
  1d7dfd:	shr    $0x3,%r8
  1d7e01:	mov    0xa8(%rsp),%rax
  1d7e09:	shr    $0x3,%rax
  1d7e0d:	mov    %rax,0x28(%rsp)
  1d7e12:	mov    %rcx,%rax
  1d7e15:	shr    $0x3,%rax
  1d7e19:	mov    %rax,0x20(%rsp)
  1d7e1e:	mov    0xb8(%rsp),%rax
  1d7e26:	shr    $0x3,%rax
  1d7e2a:	mov    %rax,0x10(%rsp)
  1d7e2f:	mov    0x48(%rsp),%r11
  1d7e34:	cmp    %r11,%r15
  1d7e37:	cmova  %r15,%r11
  1d7e3b:	mov    0x40(%rsp),%rbx
  1d7e40:	cmp    %rbx,%r15
  1d7e43:	cmova  %r15,%rbx
  1d7e47:	xor    %edi,%edi
  1d7e49:	vpbroadcastd -0x1ba322(%rip),%ymm0        # 1db30 <__abi_tag+0x1d834>
  1d7e52:	vmovdqu %ymm0,0x80(%rsp)
  1d7e5b:	vbroadcastss -0x1ba534(%rip),%ymm3        # 1d930 <__abi_tag+0x1d634>
  1d7e64:	jmp    1d7e97 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x187>
  1d7e66:	cs nopw 0x0(%rax,%rax,1)
  1d7e70:	mov    %r12,%rcx
  1d7e73:	inc    %rdi
  1d7e76:	vmovups %ymm9,(%rax)
  1d7e7a:	add    0x30(%rsp),%r14
  1d7e7f:	vmovups %ymm8,(%r14)
  1d7e84:	cmp    0x18(%rsp),%rdi
  1d7e89:	mov    0xc8(%rsp),%r15
  1d7e91:	je     1d8099 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x389>
  1d7e97:	mov    %rdi,%r14
  1d7e9a:	shl    $0x5,%r14
  1d7e9e:	mov    0x38(%rsp),%rax
  1d7ea3:	vmovups (%rax,%r14,1),%ymm5
  1d7ea9:	vxorps %xmm6,%xmm6,%xmm6
  1d7ead:	test   %r8,%r8
  1d7eb0:	je     1d7ec9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1b9>
  1d7eb2:	cmp    %r8,%rdi
  1d7eb5:	jae    1d8fc1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12b1>
  1d7ebb:	mov    0xc0(%rsp),%rax
  1d7ec3:	vmovups (%rax,%r14,1),%ymm6
  1d7ec9:	cmp    0x28(%rsp),%rdi
  1d7ece:	je     1d8f4e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x123e>
  1d7ed4:	mov    0x8(%rsp),%rax
  1d7ed9:	vmovups (%rax,%r14,1),%ymm7
  1d7edf:	vmovups 0x80(%rsp),%ymm0
  1d7ee8:	vandps %ymm0,%ymm6,%ymm8
  1d7eec:	vandps %ymm0,%ymm7,%ymm9
  1d7ef0:	vbroadcastss -0x1ba5c9(%rip),%ymm1        # 1d930 <__abi_tag+0x1d634>
  1d7ef9:	vcmple_oqps %ymm1,%ymm8,%ymm10
  1d7efe:	vxorps %xmm2,%xmm2,%xmm2
  1d7f02:	vcmpeqps %ymm2,%ymm8,%ymm11
  1d7f07:	vbroadcastss -0x1ba418(%rip),%ymm0        # 1daf8 <__abi_tag+0x1d7fc>
  1d7f10:	vcmpge_oqps %ymm0,%ymm8,%ymm8
  1d7f15:	vorps  %ymm11,%ymm8,%ymm8
  1d7f1a:	vandps %ymm10,%ymm8,%ymm8
  1d7f1f:	vcmple_oqps %ymm1,%ymm9,%ymm10
  1d7f24:	vandps %ymm10,%ymm8,%ymm8
  1d7f29:	vcmpeqps %ymm2,%ymm9,%ymm10
  1d7f2e:	vcmpge_oqps %ymm0,%ymm9,%ymm9
  1d7f33:	vorps  %ymm10,%ymm9,%ymm9
  1d7f38:	vandps %ymm9,%ymm8,%ymm8
  1d7f3d:	vpcmpeqd %ymm0,%ymm0,%ymm0
  1d7f41:	vptest %ymm0,%ymm8
  1d7f46:	jae    1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d7f4c:	cmp    0x20(%rsp),%rdi
  1d7f51:	je     1d8f7e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x126e>
  1d7f57:	cmp    0x10(%rsp),%rdi
  1d7f5c:	je     1d8f66 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1256>
  1d7f62:	mov    %rcx,%r12
  1d7f65:	mov    0x50(%rsp),%rax
  1d7f6a:	add    %r14,%rax
  1d7f6d:	vmovups (%rax),%ymm9
  1d7f71:	mov    0x30(%rsp),%rcx
  1d7f76:	vmovups (%rcx,%r14,1),%ymm8
  1d7f7c:	cmp    %rdx,%r15
  1d7f7f:	jae    1d7e70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x160>
  1d7f85:	vmulps %ymm5,%ymm5,%ymm0
  1d7f89:	vmovups %ymm0,0x60(%rsp)
  1d7f8f:	jmp    1d7fcb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x2bb>
  1d7f91:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1d7fa0:	vmovaps %ymm7,%ymm15
  1d7fa4:	vfmadd213ps %ymm13,%ymm5,%ymm11
  1d7fa9:	vfmadd213ps %ymm14,%ymm5,%ymm12
  1d7fae:	vfmadd231ps %ymm11,%ymm7,%ymm9
  1d7fb3:	vfmadd231ps %ymm12,%ymm7,%ymm8
  1d7fb8:	mov    %rcx,%r15
  1d7fbb:	vmovaps %ymm15,%ymm7
  1d7fbf:	cmp    %rcx,%rdx
  1d7fc2:	mov    %r12,%rcx
  1d7fc5:	je     1d7e73 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x163>
  1d7fcb:	cmp    %r15,%r11
  1d7fce:	je     1d8e39 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1129>
  1d7fd4:	cmp    %r15,%rbx
  1d7fd7:	je     1d8e51 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1141>
  1d7fdd:	lea    0x1(%r15),%rcx
  1d7fe1:	vbroadcastss 0x0(%rbp,%r15,8),%ymm11
  1d7fe8:	vbroadcastss (%r10,%r15,8),%ymm13
  1d7fee:	vbroadcastss -0x4(%rbp,%rcx,8),%ymm12
  1d7ff5:	vbroadcastss -0x4(%r10,%rcx,8),%ymm14
  1d7ffc:	cmp    %rdx,%rcx
  1d7fff:	jae    1d7fa0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x290>
  1d8001:	cmp    0x58(%rsp),%r15
  1d8006:	jae    1d8ec1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x11b1>
  1d800c:	cmp    %rsi,%r15
  1d800f:	jae    1d8eae <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x119e>
  1d8015:	vbroadcastss 0x0(%r13,%r15,4),%ymm4
  1d801c:	vbroadcastss (%r9,%r15,4),%ymm15
  1d8022:	vfmadd231ps 0x60(%rsp),%ymm4,%ymm15
  1d8029:	vfmadd213ps %ymm6,%ymm7,%ymm15
  1d802e:	vmovups 0x80(%rsp),%ymm0
  1d8037:	vandps %ymm0,%ymm7,%ymm4
  1d803b:	vandps %ymm0,%ymm15,%ymm6
  1d803f:	vcmple_oqps %ymm3,%ymm4,%ymm1
  1d8044:	vxorps %xmm10,%xmm10,%xmm10
  1d8049:	vcmpeqps %ymm4,%ymm10,%ymm2
  1d804e:	vbroadcastss -0x1ba55f(%rip),%ymm0        # 1daf8 <__abi_tag+0x1d7fc>
  1d8057:	vcmpge_oqps %ymm0,%ymm4,%ymm4
  1d805c:	vorps  %ymm2,%ymm4,%ymm2
  1d8060:	vandps %ymm1,%ymm2,%ymm1
  1d8064:	vcmple_oqps %ymm3,%ymm6,%ymm2
  1d8069:	vandps %ymm2,%ymm1,%ymm1
  1d806d:	vcmpeqps %ymm6,%ymm10,%ymm2
  1d8072:	vcmpge_oqps %ymm0,%ymm6,%ymm4
  1d8077:	vorps  %ymm2,%ymm4,%ymm2
  1d807b:	vandps %ymm2,%ymm1,%ymm1
  1d807f:	vpcmpeqd %ymm0,%ymm0,%ymm0
  1d8083:	vptest %ymm0,%ymm1
  1d8088:	vmovaps %ymm7,%ymm6
  1d808c:	jb     1d7fa4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x294>
  1d8092:	xor    %eax,%eax
  1d8094:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8099:	mov    0xd0(%rsp),%rbx
  1d80a1:	mov    %ebx,%eax
  1d80a3:	and    $0x7,%eax
  1d80a6:	mov    %rax,0x80(%rsp)
  1d80ae:	je     1d88fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbeb>
  1d80b4:	movabs $0x1ffffffffffffff8,%r8
  1d80be:	mov    0xb0(%rsp),%r11
  1d80c6:	mov    %r11d,%edi
  1d80c9:	and    $0x7,%edi
  1d80cc:	and    %r8,%r11
  1d80cf:	mov    %rcx,%rax
  1d80d2:	mov    0xc0(%rsp),%rcx
  1d80da:	lea    (%rcx,%r11,4),%rcx
  1d80de:	mov    %rcx,0x20(%rsp)
  1d80e3:	mov    0xa8(%rsp),%r11
  1d80eb:	mov    %r11d,%r12d
  1d80ee:	and    $0x7,%r12d
  1d80f2:	and    %r8,%r11
  1d80f5:	mov    0x8(%rsp),%rcx
  1d80fa:	lea    (%rcx,%r11,4),%r11
  1d80fe:	mov    %eax,%ecx
  1d8100:	and    $0x7,%ecx
  1d8103:	mov    %rcx,0x60(%rsp)
  1d8108:	mov    0xb8(%rsp),%r14
  1d8110:	mov    %r14d,%ecx
  1d8113:	and    $0x7,%ecx
  1d8116:	mov    %rcx,0x8(%rsp)
  1d811b:	cmp    %rdx,%r15
  1d811e:	mov    %r12,0x10(%rsp)
  1d8123:	mov    %r11,0x18(%rsp)
  1d8128:	mov    %rdi,0x28(%rsp)
  1d812d:	jae    1d83cb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x6bb>
  1d8133:	and    %r8,%rbx
  1d8136:	mov    0x38(%rsp),%rcx
  1d813b:	lea    (%rcx,%rbx,4),%rdi
  1d813f:	and    %r8,%rax
  1d8142:	mov    0x50(%rsp),%rcx
  1d8147:	lea    (%rcx,%rax,4),%rax
  1d814b:	mov    %rax,0x38(%rsp)
  1d8150:	and    %r8,%r14
  1d8153:	mov    0x30(%rsp),%rax
  1d8158:	lea    (%rax,%r14,4),%rax
  1d815c:	mov    %rax,0x30(%rsp)
  1d8161:	mov    0x48(%rsp),%r14
  1d8166:	cmp    %r14,%r15
  1d8169:	cmova  %r15,%r14
  1d816d:	mov    0x40(%rsp),%rcx
  1d8172:	cmp    %rcx,%r15
  1d8175:	mov    %r15,%rax
  1d8178:	mov    %rcx,%r15
  1d817b:	cmova  %rax,%r15
  1d817f:	xor    %ebx,%ebx
  1d8181:	vpxor  %xmm0,%xmm0,%xmm0
  1d8185:	vbroadcastss -0x1ba65e(%rip),%xmm1        # 1db30 <__abi_tag+0x1d834>
  1d818e:	vmovss -0x1ba69e(%rip),%xmm2        # 1daf8 <__abi_tag+0x1d7fc>
  1d8196:	vmovss -0x1ba86e(%rip),%xmm3        # 1d930 <__abi_tag+0x1d634>
  1d819e:	mov    %rdi,0x50(%rsp)
  1d81a3:	jmp    1d81d9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x4c9>
  1d81a5:	mov    0x38(%rsp),%rax
  1d81aa:	vmovss %xmm8,(%rax,%rbx,4)
  1d81af:	mov    0x30(%rsp),%rax
  1d81b4:	vmovss %xmm9,(%rax,%rbx,4)
  1d81b9:	mov    %r11,%rbx
  1d81bc:	cmp    0x80(%rsp),%r11
  1d81c4:	mov    0x10(%rsp),%r12
  1d81c9:	mov    0x18(%rsp),%r11
  1d81ce:	mov    0x50(%rsp),%rdi
  1d81d3:	je     1d88fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbeb>
  1d81d9:	vmovss (%rdi,%rbx,4),%xmm4
  1d81de:	mov    0x28(%rsp),%rax
  1d81e3:	test   %rax,%rax
  1d81e6:	je     1d8247 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x537>
  1d81e8:	cmp    %rax,%rbx
  1d81eb:	jae    1d8fec <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12dc>
  1d81f1:	cmp    %r12,%rbx
  1d81f4:	jae    1d9009 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f9>
  1d81fa:	mov    0x20(%rsp),%rax
  1d81ff:	vmovss (%rax,%rbx,4),%xmm6
  1d8204:	vmovss (%r11,%rbx,4),%xmm5
  1d820a:	vucomiss %xmm0,%xmm6
  1d820e:	jne    1d8212 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x502>
  1d8210:	jnp    1d823d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x52d>
  1d8212:	vmovd  %xmm6,%eax
  1d8216:	add    %eax,%eax
  1d8218:	cmp    $0xfeffffff,%eax
  1d821d:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8223:	vandps %xmm1,%xmm6,%xmm7
  1d8227:	xor    %eax,%eax
  1d8229:	vucomiss %xmm2,%xmm7
  1d822d:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8233:	vucomiss %xmm7,%xmm3
  1d8237:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d823d:	vucomiss %xmm0,%xmm5
  1d8241:	jne    1d8262 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x552>
  1d8243:	jnp    1d828d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x57d>
  1d8245:	jmp    1d8262 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x552>
  1d8247:	cmp    %r12,%rbx
  1d824a:	jae    1d9004 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f4>
  1d8250:	vmovss (%r11,%rbx,4),%xmm5
  1d8256:	vxorps %xmm6,%xmm6,%xmm6
  1d825a:	vucomiss %xmm0,%xmm5
  1d825e:	jne    1d8262 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x552>
  1d8260:	jnp    1d828d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x57d>
  1d8262:	vmovd  %xmm5,%eax
  1d8266:	add    %eax,%eax
  1d8268:	cmp    $0xfeffffff,%eax
  1d826d:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8273:	vandps %xmm1,%xmm5,%xmm7
  1d8277:	xor    %eax,%eax
  1d8279:	vucomiss %xmm2,%xmm7
  1d827d:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8283:	vucomiss %xmm7,%xmm3
  1d8287:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d828d:	cmp    0x60(%rsp),%rbx
  1d8292:	je     1d8fd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12c4>
  1d8298:	cmp    0x8(%rsp),%rbx
  1d829d:	je     1d8d52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1042>
  1d82a3:	lea    0x1(%rbx),%r11
  1d82a7:	mov    0x38(%rsp),%rax
  1d82ac:	vmovss (%rax,%rbx,4),%xmm8
  1d82b1:	mov    0x30(%rsp),%rax
  1d82b6:	vmovss (%rax,%rbx,4),%xmm9
  1d82bb:	vmulss %xmm4,%xmm4,%xmm7
  1d82bf:	mov    0xc8(%rsp),%rcx
  1d82c7:	jmp    1d82eb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5db>
  1d82c9:	nopl   0x0(%rax)
  1d82d0:	vmovaps %xmm5,%xmm12
  1d82d4:	vfmadd213ss %xmm11,%xmm5,%xmm8
  1d82d9:	vfmadd213ss %xmm10,%xmm5,%xmm9
  1d82de:	vmovaps %xmm12,%xmm5
  1d82e2:	cmp    %rcx,%rdx
  1d82e5:	je     1d81a5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x495>
  1d82eb:	cmp    %rcx,%r14
  1d82ee:	je     1d8f36 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1226>
  1d82f4:	mov    %rcx,%rax
  1d82f7:	cmp    %rcx,%r15
  1d82fa:	je     1d8f1e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x120e>
  1d8300:	vmovaps %xmm8,%xmm11
  1d8305:	vmovaps %xmm9,%xmm10
  1d830a:	lea    0x1(%rax),%rcx
  1d830e:	vmovss 0x0(%rbp,%rax,8),%xmm8
  1d8314:	vfmadd213ss (%r10,%rax,8),%xmm4,%xmm8
  1d831a:	vmovss -0x4(%rbp,%rcx,8),%xmm9
  1d8320:	vfmadd213ss -0x4(%r10,%rcx,8),%xmm4,%xmm9
  1d8327:	cmp    %rdx,%rcx
  1d832a:	jae    1d82d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5c0>
  1d832c:	cmp    0x58(%rsp),%rax
  1d8331:	jae    1d8f96 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1286>
  1d8337:	cmp    %rsi,%rax
  1d833a:	jae    1d8fae <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x129e>
  1d8340:	vmovss 0x0(%r13,%rax,4),%xmm12
  1d8347:	vfmadd213ss (%r9,%rax,4),%xmm7,%xmm12
  1d834d:	vucomiss %xmm0,%xmm5
  1d8351:	jne    1d8355 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x645>
  1d8353:	jnp    1d8381 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x671>
  1d8355:	vmovd  %xmm5,%eax
  1d8359:	add    %eax,%eax
  1d835b:	cmp    $0xfeffffff,%eax
  1d8360:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8366:	vandps %xmm1,%xmm5,%xmm13
  1d836a:	xor    %eax,%eax
  1d836c:	vucomiss %xmm2,%xmm13
  1d8370:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8376:	vucomiss %xmm13,%xmm3
  1d837b:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8381:	vfmadd213ss %xmm6,%xmm5,%xmm12
  1d8386:	vucomiss %xmm0,%xmm12
  1d838a:	jne    1d8397 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x687>
  1d838c:	jp     1d8397 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x687>
  1d838e:	vmovaps %xmm5,%xmm6
  1d8392:	jmp    1d82d4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5c4>
  1d8397:	vmovd  %xmm12,%eax
  1d839b:	add    %eax,%eax
  1d839d:	cmp    $0xfeffffff,%eax
  1d83a2:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d83a8:	vandps %xmm1,%xmm12,%xmm6
  1d83ac:	xor    %eax,%eax
  1d83ae:	vucomiss %xmm2,%xmm6
  1d83b2:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d83b8:	vucomiss %xmm6,%xmm3
  1d83bc:	vmovaps %xmm5,%xmm6
  1d83c0:	jae    1d82d4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5c4>
  1d83c6:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d83cb:	mov    %r12,%rbx
  1d83ce:	test   %rdi,%rdi
  1d83d1:	je     1d8713 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xa03>
  1d83d7:	test   %r12,%r12
  1d83da:	je     1d9009 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f9>
  1d83e0:	mov    0x20(%rsp),%rax
  1d83e5:	vmovss (%rax),%xmm2
  1d83e9:	vmovss (%r11),%xmm0
  1d83ee:	vxorps %xmm1,%xmm1,%xmm1
  1d83f2:	vucomiss %xmm1,%xmm2
  1d83f6:	jne    1d8912 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xc02>
  1d83fc:	jp     1d8912 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xc02>
  1d8402:	vucomiss %xmm1,%xmm0
  1d8406:	jne    1d8950 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xc40>
  1d840c:	jp     1d8950 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xc40>
  1d8412:	cmpq   $0x0,0x60(%rsp)
  1d8418:	je     1d8fd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12c4>
  1d841e:	cmpq   $0x0,0x8(%rsp)
  1d8424:	je     1d8d52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1042>
  1d842a:	cmpl   $0x1,0x80(%rsp)
  1d8432:	je     1d88fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbeb>
  1d8438:	mov    0x28(%rsp),%rax
  1d843d:	mov    %rax,%rbx
  1d8440:	cmp    $0x1,%eax
  1d8443:	mov    0x10(%rsp),%r12
  1d8448:	mov    0x18(%rsp),%rax
  1d844d:	je     1d8fec <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12dc>
  1d8453:	mov    %r12,%rbx
  1d8456:	cmp    $0x1,%r12d
  1d845a:	je     1d9009 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f9>
  1d8460:	mov    0x20(%rsp),%rcx
  1d8465:	vmovss 0x4(%rcx),%xmm2
  1d846a:	vmovss 0x4(%rax),%xmm0
  1d846f:	vxorps %xmm1,%xmm1,%xmm1
  1d8473:	vucomiss %xmm1,%xmm2
  1d8477:	jne    1d89d6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xcc6>
  1d847d:	jp     1d89d6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xcc6>
  1d8483:	vucomiss %xmm1,%xmm0
  1d8487:	jne    1d8a60 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xd50>
  1d848d:	jp     1d8a60 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xd50>
  1d8493:	cmpl   $0x1,0x60(%rsp)
  1d8498:	je     1d8fd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12c4>
  1d849e:	cmpl   $0x1,0x8(%rsp)
  1d84a3:	je     1d8d52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1042>
  1d84a9:	cmpl   $0x2,0x80(%rsp)
  1d84b1:	je     1d88fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbeb>
  1d84b7:	mov    0x28(%rsp),%rax
  1d84bc:	mov    %rax,%rbx
  1d84bf:	cmp    $0x2,%eax
  1d84c2:	mov    0x10(%rsp),%r12
  1d84c7:	mov    0x18(%rsp),%rax
  1d84cc:	je     1d8fec <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12dc>
  1d84d2:	mov    %r12,%rbx
  1d84d5:	cmp    $0x2,%r12d
  1d84d9:	je     1d9009 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f9>
  1d84df:	mov    0x20(%rsp),%rcx
  1d84e4:	vmovss 0x8(%rcx),%xmm2
  1d84e9:	vmovss 0x8(%rax),%xmm0
  1d84ee:	vxorps %xmm1,%xmm1,%xmm1
  1d84f2:	vucomiss %xmm1,%xmm2
  1d84f6:	jne    1d8aea <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xdda>
  1d84fc:	jp     1d8aea <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xdda>
  1d8502:	vucomiss %xmm1,%xmm0
  1d8506:	jne    1d8b2f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xe1f>
  1d850c:	jp     1d8b2f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xe1f>
  1d8512:	cmpl   $0x2,0x60(%rsp)
  1d8517:	je     1d8fd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12c4>
  1d851d:	cmpl   $0x2,0x8(%rsp)
  1d8522:	je     1d8d52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1042>
  1d8528:	cmpl   $0x3,0x80(%rsp)
  1d8530:	je     1d88fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbeb>
  1d8536:	mov    0x28(%rsp),%rax
  1d853b:	mov    %rax,%rbx
  1d853e:	cmp    $0x3,%eax
  1d8541:	mov    0x10(%rsp),%r12
  1d8546:	mov    0x18(%rsp),%rax
  1d854b:	je     1d8fec <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12dc>
  1d8551:	mov    %r12,%rbx
  1d8554:	cmp    $0x3,%r12d
  1d8558:	je     1d9009 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f9>
  1d855e:	mov    0x20(%rsp),%rcx
  1d8563:	vmovss 0xc(%rcx),%xmm2
  1d8568:	vmovss 0xc(%rax),%xmm0
  1d856d:	vxorps %xmm1,%xmm1,%xmm1
  1d8571:	vucomiss %xmm1,%xmm2
  1d8575:	jne    1d8bb9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xea9>
  1d857b:	jp     1d8bb9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xea9>
  1d8581:	vucomiss %xmm1,%xmm0
  1d8585:	jne    1d8bfe <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xeee>
  1d858b:	jp     1d8bfe <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xeee>
  1d8591:	cmpl   $0x3,0x60(%rsp)
  1d8596:	je     1d8fd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12c4>
  1d859c:	cmpl   $0x3,0x8(%rsp)
  1d85a1:	je     1d8d52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1042>
  1d85a7:	cmpl   $0x4,0x80(%rsp)
  1d85af:	je     1d88fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbeb>
  1d85b5:	mov    0x28(%rsp),%rax
  1d85ba:	mov    %rax,%rbx
  1d85bd:	cmp    $0x4,%eax
  1d85c0:	mov    0x10(%rsp),%r12
  1d85c5:	mov    0x18(%rsp),%rax
  1d85ca:	je     1d8fec <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12dc>
  1d85d0:	mov    %r12,%rbx
  1d85d3:	cmp    $0x4,%r12d
  1d85d7:	je     1d9009 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f9>
  1d85dd:	mov    0x20(%rsp),%rcx
  1d85e2:	vmovss 0x10(%rcx),%xmm2
  1d85e7:	vmovss 0x10(%rax),%xmm0
  1d85ec:	vxorps %xmm1,%xmm1,%xmm1
  1d85f0:	vucomiss %xmm1,%xmm2
  1d85f4:	jne    1d8c88 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xf78>
  1d85fa:	jp     1d8c88 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xf78>
  1d8600:	vucomiss %xmm1,%xmm0
  1d8604:	jne    1d8d6a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x105a>
  1d860a:	jp     1d8d6a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x105a>
  1d8610:	cmpl   $0x4,0x60(%rsp)
  1d8615:	je     1d8fd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12c4>
  1d861b:	cmpl   $0x4,0x8(%rsp)
  1d8620:	je     1d8d52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1042>
  1d8626:	cmpl   $0x5,0x80(%rsp)
  1d862e:	je     1d88fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbeb>
  1d8634:	mov    0x28(%rsp),%rax
  1d8639:	mov    %rax,%rbx
  1d863c:	cmp    $0x5,%eax
  1d863f:	mov    0x10(%rsp),%r12
  1d8644:	mov    0x18(%rsp),%rax
  1d8649:	je     1d8fec <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12dc>
  1d864f:	mov    %r12,%rbx
  1d8652:	cmp    $0x5,%r12d
  1d8656:	je     1d9009 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f9>
  1d865c:	mov    0x20(%rsp),%rcx
  1d8661:	vmovss 0x14(%rcx),%xmm2
  1d8666:	vmovss 0x14(%rax),%xmm0
  1d866b:	vxorps %xmm1,%xmm1,%xmm1
  1d866f:	vucomiss %xmm1,%xmm2
  1d8673:	jne    1d8df4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x10e4>
  1d8679:	jp     1d8df4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x10e4>
  1d867f:	vucomiss %xmm1,%xmm0
  1d8683:	jne    1d8e69 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1159>
  1d8689:	jp     1d8e69 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1159>
  1d868f:	cmpl   $0x5,0x60(%rsp)
  1d8694:	je     1d8fd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12c4>
  1d869a:	cmpl   $0x5,0x8(%rsp)
  1d869f:	je     1d8d52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1042>
  1d86a5:	cmpl   $0x6,0x80(%rsp)
  1d86ad:	je     1d88fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbeb>
  1d86b3:	mov    0x28(%rsp),%rax
  1d86b8:	mov    %rax,%rbx
  1d86bb:	cmp    $0x6,%eax
  1d86be:	mov    0x10(%rsp),%r12
  1d86c3:	mov    0x18(%rsp),%rax
  1d86c8:	je     1d8fec <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12dc>
  1d86ce:	mov    %r12,%rbx
  1d86d1:	cmp    $0x6,%r12d
  1d86d5:	je     1d9009 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f9>
  1d86db:	mov    0x20(%rsp),%rcx
  1d86e0:	vmovss 0x18(%rcx),%xmm2
  1d86e5:	vmovss 0x18(%rax),%xmm0
  1d86ea:	vxorps %xmm1,%xmm1,%xmm1
  1d86ee:	vucomiss %xmm1,%xmm2
  1d86f2:	jne    1d8ed9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x11c9>
  1d86f8:	jp     1d8ed9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x11c9>
  1d86fe:	vucomiss %xmm1,%xmm0
  1d8702:	jne    1d8daf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x109f>
  1d8708:	jnp    1d8d3a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x102a>
  1d870e:	jmp    1d8daf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x109f>
  1d8713:	test   %r12,%r12
  1d8716:	je     1d9009 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f9>
  1d871c:	vmovss (%r11),%xmm0
  1d8721:	vxorps %xmm1,%xmm1,%xmm1
  1d8725:	vucomiss %xmm1,%xmm0
  1d8729:	jne    1d8991 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xc81>
  1d872f:	jp     1d8991 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xc81>
  1d8735:	cmpq   $0x0,0x60(%rsp)
  1d873b:	je     1d8fd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12c4>
  1d8741:	cmpq   $0x0,0x8(%rsp)
  1d8747:	je     1d8d52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1042>
  1d874d:	cmpl   $0x1,0x80(%rsp)
  1d8755:	je     1d88fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbeb>
  1d875b:	mov    0x10(%rsp),%r12
  1d8760:	mov    %r12,%rbx
  1d8763:	cmp    $0x1,%r12d
  1d8767:	mov    0x18(%rsp),%rax
  1d876c:	je     1d9009 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f9>
  1d8772:	vmovss 0x4(%rax),%xmm0
  1d8777:	vxorps %xmm1,%xmm1,%xmm1
  1d877b:	vucomiss %xmm1,%xmm0
  1d877f:	jne    1d8a1b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xd0b>
  1d8785:	jp     1d8a1b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xd0b>
  1d878b:	cmpl   $0x1,0x60(%rsp)
  1d8790:	je     1d8fd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12c4>
  1d8796:	cmpl   $0x1,0x8(%rsp)
  1d879b:	je     1d8d52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1042>
  1d87a1:	cmpl   $0x2,0x80(%rsp)
  1d87a9:	je     1d88fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbeb>
  1d87af:	mov    0x10(%rsp),%r12
  1d87b4:	mov    %r12,%rbx
  1d87b7:	cmp    $0x2,%r12d
  1d87bb:	mov    0x18(%rsp),%rax
  1d87c0:	je     1d9009 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f9>
  1d87c6:	vmovss 0x8(%rax),%xmm0
  1d87cb:	vxorps %xmm1,%xmm1,%xmm1
  1d87cf:	vucomiss %xmm1,%xmm0
  1d87d3:	jne    1d8aa5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xd95>
  1d87d9:	jp     1d8aa5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xd95>
  1d87df:	cmpl   $0x2,0x60(%rsp)
  1d87e4:	je     1d8fd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12c4>
  1d87ea:	cmpl   $0x2,0x8(%rsp)
  1d87ef:	je     1d8d52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1042>
  1d87f5:	cmpl   $0x3,0x80(%rsp)
  1d87fd:	je     1d88fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbeb>
  1d8803:	mov    0x10(%rsp),%r12
  1d8808:	mov    %r12,%rbx
  1d880b:	cmp    $0x3,%r12d
  1d880f:	mov    0x18(%rsp),%rax
  1d8814:	je     1d9009 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f9>
  1d881a:	vmovss 0xc(%rax),%xmm0
  1d881f:	vxorps %xmm1,%xmm1,%xmm1
  1d8823:	vucomiss %xmm1,%xmm0
  1d8827:	jne    1d8b74 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xe64>
  1d882d:	jp     1d8b74 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xe64>
  1d8833:	cmpl   $0x3,0x60(%rsp)
  1d8838:	je     1d8fd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12c4>
  1d883e:	cmpl   $0x3,0x8(%rsp)
  1d8843:	je     1d8d52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1042>
  1d8849:	cmpl   $0x4,0x80(%rsp)
  1d8851:	je     1d88fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbeb>
  1d8857:	mov    0x10(%rsp),%r12
  1d885c:	mov    %r12,%rbx
  1d885f:	cmp    $0x4,%r12d
  1d8863:	mov    0x18(%rsp),%rax
  1d8868:	je     1d9009 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f9>
  1d886e:	vmovss 0x10(%rax),%xmm0
  1d8873:	vxorps %xmm1,%xmm1,%xmm1
  1d8877:	vucomiss %xmm1,%xmm0
  1d887b:	jne    1d8c43 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xf33>
  1d8881:	jp     1d8c43 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xf33>
  1d8887:	cmpl   $0x4,0x60(%rsp)
  1d888c:	je     1d8fd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12c4>
  1d8892:	cmpl   $0x4,0x8(%rsp)
  1d8897:	je     1d8d52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1042>
  1d889d:	cmpl   $0x5,0x80(%rsp)
  1d88a5:	je     1d88fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbeb>
  1d88a7:	mov    0x10(%rsp),%r12
  1d88ac:	mov    %r12,%rbx
  1d88af:	cmp    $0x5,%r12d
  1d88b3:	mov    0x18(%rsp),%rax
  1d88b8:	je     1d9009 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f9>
  1d88be:	vmovss 0x14(%rax),%xmm0
  1d88c3:	vxorps %xmm1,%xmm1,%xmm1
  1d88c7:	vucomiss %xmm1,%xmm0
  1d88cb:	jne    1d8ccd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xfbd>
  1d88d1:	jp     1d8ccd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xfbd>
  1d88d7:	cmpl   $0x5,0x60(%rsp)
  1d88dc:	je     1d8fd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12c4>
  1d88e2:	cmpl   $0x5,0x8(%rsp)
  1d88e7:	je     1d8d52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1042>
  1d88ed:	cmpl   $0x6,0x80(%rsp)
  1d88f5:	jne    1d8d12 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1002>
  1d88fb:	mov    $0x1,%al
  1d88fd:	add    $0xd8,%rsp
  1d8904:	pop    %rbx
  1d8905:	pop    %r12
  1d8907:	pop    %r13
  1d8909:	pop    %r14
  1d890b:	pop    %r15
  1d890d:	pop    %rbp
  1d890e:	vzeroupper
  1d8911:	ret
  1d8912:	vmovd  %xmm2,%eax
  1d8916:	add    %eax,%eax
  1d8918:	cmp    $0xfeffffff,%eax
  1d891d:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8923:	vbroadcastss -0x1badfc(%rip),%xmm3        # 1db30 <__abi_tag+0x1d834>
  1d892c:	vandps %xmm3,%xmm2,%xmm2
  1d8930:	xor    %eax,%eax
  1d8932:	vucomiss -0x1bae42(%rip),%xmm2        # 1daf8 <__abi_tag+0x1d7fc>
  1d893a:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d893c:	vmovss -0x1bb014(%rip),%xmm3        # 1d930 <__abi_tag+0x1d634>
  1d8944:	vucomiss %xmm2,%xmm3
  1d8948:	jae    1d8402 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x6f2>
  1d894e:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8950:	vmovd  %xmm0,%eax
  1d8954:	add    %eax,%eax
  1d8956:	cmp    $0xfeffffff,%eax
  1d895b:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8961:	vbroadcastss -0x1bae3a(%rip),%xmm1        # 1db30 <__abi_tag+0x1d834>
  1d896a:	vandps %xmm1,%xmm0,%xmm0
  1d896e:	xor    %eax,%eax
  1d8970:	vucomiss -0x1bae80(%rip),%xmm0        # 1daf8 <__abi_tag+0x1d7fc>
  1d8978:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d897a:	vmovss -0x1bb052(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1d8982:	vucomiss %xmm0,%xmm1
  1d8986:	jae    1d8412 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x702>
  1d898c:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8991:	vmovd  %xmm0,%eax
  1d8995:	add    %eax,%eax
  1d8997:	cmp    $0xfeffffff,%eax
  1d899c:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d89a2:	vbroadcastss -0x1bae7b(%rip),%xmm1        # 1db30 <__abi_tag+0x1d834>
  1d89ab:	vandps %xmm1,%xmm0,%xmm0
  1d89af:	xor    %eax,%eax
  1d89b1:	vucomiss -0x1baec1(%rip),%xmm0        # 1daf8 <__abi_tag+0x1d7fc>
  1d89b9:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d89bf:	vmovss -0x1bb097(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1d89c7:	vucomiss %xmm0,%xmm1
  1d89cb:	jae    1d8735 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xa25>
  1d89d1:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d89d6:	vmovd  %xmm2,%eax
  1d89da:	add    %eax,%eax
  1d89dc:	cmp    $0xfeffffff,%eax
  1d89e1:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d89e7:	vbroadcastss -0x1baec0(%rip),%xmm3        # 1db30 <__abi_tag+0x1d834>
  1d89f0:	vandps %xmm3,%xmm2,%xmm2
  1d89f4:	xor    %eax,%eax
  1d89f6:	vucomiss -0x1baf06(%rip),%xmm2        # 1daf8 <__abi_tag+0x1d7fc>
  1d89fe:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8a04:	vmovss -0x1bb0dc(%rip),%xmm3        # 1d930 <__abi_tag+0x1d634>
  1d8a0c:	vucomiss %xmm2,%xmm3
  1d8a10:	jae    1d8483 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x773>
  1d8a16:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8a1b:	vmovd  %xmm0,%eax
  1d8a1f:	add    %eax,%eax
  1d8a21:	cmp    $0xfeffffff,%eax
  1d8a26:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8a2c:	vbroadcastss -0x1baf05(%rip),%xmm1        # 1db30 <__abi_tag+0x1d834>
  1d8a35:	vandps %xmm1,%xmm0,%xmm0
  1d8a39:	xor    %eax,%eax
  1d8a3b:	vucomiss -0x1baf4b(%rip),%xmm0        # 1daf8 <__abi_tag+0x1d7fc>
  1d8a43:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8a49:	vmovss -0x1bb121(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1d8a51:	vucomiss %xmm0,%xmm1
  1d8a55:	jae    1d878b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xa7b>
  1d8a5b:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8a60:	vmovd  %xmm0,%eax
  1d8a64:	add    %eax,%eax
  1d8a66:	cmp    $0xfeffffff,%eax
  1d8a6b:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8a71:	vbroadcastss -0x1baf4a(%rip),%xmm1        # 1db30 <__abi_tag+0x1d834>
  1d8a7a:	vandps %xmm1,%xmm0,%xmm0
  1d8a7e:	xor    %eax,%eax
  1d8a80:	vucomiss -0x1baf90(%rip),%xmm0        # 1daf8 <__abi_tag+0x1d7fc>
  1d8a88:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8a8e:	vmovss -0x1bb166(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1d8a96:	vucomiss %xmm0,%xmm1
  1d8a9a:	jae    1d8493 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x783>
  1d8aa0:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8aa5:	vmovd  %xmm0,%eax
  1d8aa9:	add    %eax,%eax
  1d8aab:	cmp    $0xfeffffff,%eax
  1d8ab0:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8ab6:	vbroadcastss -0x1baf8f(%rip),%xmm1        # 1db30 <__abi_tag+0x1d834>
  1d8abf:	vandps %xmm1,%xmm0,%xmm0
  1d8ac3:	xor    %eax,%eax
  1d8ac5:	vucomiss -0x1bafd5(%rip),%xmm0        # 1daf8 <__abi_tag+0x1d7fc>
  1d8acd:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8ad3:	vmovss -0x1bb1ab(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1d8adb:	vucomiss %xmm0,%xmm1
  1d8adf:	jae    1d87df <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xacf>
  1d8ae5:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8aea:	vmovd  %xmm2,%eax
  1d8aee:	add    %eax,%eax
  1d8af0:	cmp    $0xfeffffff,%eax
  1d8af5:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8afb:	vbroadcastss -0x1bafd4(%rip),%xmm3        # 1db30 <__abi_tag+0x1d834>
  1d8b04:	vandps %xmm3,%xmm2,%xmm2
  1d8b08:	xor    %eax,%eax
  1d8b0a:	vucomiss -0x1bb01a(%rip),%xmm2        # 1daf8 <__abi_tag+0x1d7fc>
  1d8b12:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8b18:	vmovss -0x1bb1f0(%rip),%xmm3        # 1d930 <__abi_tag+0x1d634>
  1d8b20:	vucomiss %xmm2,%xmm3
  1d8b24:	jae    1d8502 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x7f2>
  1d8b2a:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8b2f:	vmovd  %xmm0,%eax
  1d8b33:	add    %eax,%eax
  1d8b35:	cmp    $0xfeffffff,%eax
  1d8b3a:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8b40:	vbroadcastss -0x1bb019(%rip),%xmm1        # 1db30 <__abi_tag+0x1d834>
  1d8b49:	vandps %xmm1,%xmm0,%xmm0
  1d8b4d:	xor    %eax,%eax
  1d8b4f:	vucomiss -0x1bb05f(%rip),%xmm0        # 1daf8 <__abi_tag+0x1d7fc>
  1d8b57:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8b5d:	vmovss -0x1bb235(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1d8b65:	vucomiss %xmm0,%xmm1
  1d8b69:	jae    1d8512 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x802>
  1d8b6f:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8b74:	vmovd  %xmm0,%eax
  1d8b78:	add    %eax,%eax
  1d8b7a:	cmp    $0xfeffffff,%eax
  1d8b7f:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8b85:	vbroadcastss -0x1bb05e(%rip),%xmm1        # 1db30 <__abi_tag+0x1d834>
  1d8b8e:	vandps %xmm1,%xmm0,%xmm0
  1d8b92:	xor    %eax,%eax
  1d8b94:	vucomiss -0x1bb0a4(%rip),%xmm0        # 1daf8 <__abi_tag+0x1d7fc>
  1d8b9c:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8ba2:	vmovss -0x1bb27a(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1d8baa:	vucomiss %xmm0,%xmm1
  1d8bae:	jae    1d8833 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xb23>
  1d8bb4:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8bb9:	vmovd  %xmm2,%eax
  1d8bbd:	add    %eax,%eax
  1d8bbf:	cmp    $0xfeffffff,%eax
  1d8bc4:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8bca:	vbroadcastss -0x1bb0a3(%rip),%xmm3        # 1db30 <__abi_tag+0x1d834>
  1d8bd3:	vandps %xmm3,%xmm2,%xmm2
  1d8bd7:	xor    %eax,%eax
  1d8bd9:	vucomiss -0x1bb0e9(%rip),%xmm2        # 1daf8 <__abi_tag+0x1d7fc>
  1d8be1:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8be7:	vmovss -0x1bb2bf(%rip),%xmm3        # 1d930 <__abi_tag+0x1d634>
  1d8bef:	vucomiss %xmm2,%xmm3
  1d8bf3:	jae    1d8581 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x871>
  1d8bf9:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8bfe:	vmovd  %xmm0,%eax
  1d8c02:	add    %eax,%eax
  1d8c04:	cmp    $0xfeffffff,%eax
  1d8c09:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8c0f:	vbroadcastss -0x1bb0e8(%rip),%xmm1        # 1db30 <__abi_tag+0x1d834>
  1d8c18:	vandps %xmm1,%xmm0,%xmm0
  1d8c1c:	xor    %eax,%eax
  1d8c1e:	vucomiss -0x1bb12e(%rip),%xmm0        # 1daf8 <__abi_tag+0x1d7fc>
  1d8c26:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8c2c:	vmovss -0x1bb304(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1d8c34:	vucomiss %xmm0,%xmm1
  1d8c38:	jae    1d8591 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x881>
  1d8c3e:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8c43:	vmovd  %xmm0,%eax
  1d8c47:	add    %eax,%eax
  1d8c49:	cmp    $0xfeffffff,%eax
  1d8c4e:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8c54:	vbroadcastss -0x1bb12d(%rip),%xmm1        # 1db30 <__abi_tag+0x1d834>
  1d8c5d:	vandps %xmm1,%xmm0,%xmm0
  1d8c61:	xor    %eax,%eax
  1d8c63:	vucomiss -0x1bb173(%rip),%xmm0        # 1daf8 <__abi_tag+0x1d7fc>
  1d8c6b:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8c71:	vmovss -0x1bb349(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1d8c79:	vucomiss %xmm0,%xmm1
  1d8c7d:	jae    1d8887 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xb77>
  1d8c83:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8c88:	vmovd  %xmm2,%eax
  1d8c8c:	add    %eax,%eax
  1d8c8e:	cmp    $0xfeffffff,%eax
  1d8c93:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8c99:	vbroadcastss -0x1bb172(%rip),%xmm3        # 1db30 <__abi_tag+0x1d834>
  1d8ca2:	vandps %xmm3,%xmm2,%xmm2
  1d8ca6:	xor    %eax,%eax
  1d8ca8:	vucomiss -0x1bb1b8(%rip),%xmm2        # 1daf8 <__abi_tag+0x1d7fc>
  1d8cb0:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8cb6:	vmovss -0x1bb38e(%rip),%xmm3        # 1d930 <__abi_tag+0x1d634>
  1d8cbe:	vucomiss %xmm2,%xmm3
  1d8cc2:	jae    1d8600 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x8f0>
  1d8cc8:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8ccd:	vmovd  %xmm0,%eax
  1d8cd1:	add    %eax,%eax
  1d8cd3:	cmp    $0xfeffffff,%eax
  1d8cd8:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8cde:	vbroadcastss -0x1bb1b7(%rip),%xmm1        # 1db30 <__abi_tag+0x1d834>
  1d8ce7:	vandps %xmm1,%xmm0,%xmm0
  1d8ceb:	xor    %eax,%eax
  1d8ced:	vucomiss -0x1bb1fd(%rip),%xmm0        # 1daf8 <__abi_tag+0x1d7fc>
  1d8cf5:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8cfb:	vmovss -0x1bb3d3(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1d8d03:	vucomiss %xmm0,%xmm1
  1d8d07:	jae    1d88d7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbc7>
  1d8d0d:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8d12:	mov    0x10(%rsp),%r12
  1d8d17:	mov    %r12,%rbx
  1d8d1a:	cmp    $0x6,%r12d
  1d8d1e:	mov    0x18(%rsp),%rax
  1d8d23:	je     1d9009 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12f9>
  1d8d29:	vmovss 0x18(%rax),%xmm0
  1d8d2e:	vxorps %xmm1,%xmm1,%xmm1
  1d8d32:	vucomiss %xmm1,%xmm0
  1d8d36:	jne    1d8daf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x109f>
  1d8d38:	jp     1d8daf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x109f>
  1d8d3a:	cmpl   $0x6,0x60(%rsp)
  1d8d3f:	je     1d8fd4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x12c4>
  1d8d45:	mov    $0x1,%al
  1d8d47:	cmpl   $0x6,0x8(%rsp)
  1d8d4c:	jne    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8d52:	lea    0x6953f(%rip),%rdx        # 242298 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x2d0>
  1d8d59:	mov    0x8(%rsp),%rdi
  1d8d5e:	mov    %rdi,%rsi
  1d8d61:	vzeroupper
  1d8d64:	call   *0x6d61e(%rip)        # 246388 <_DYNAMIC+0x260>
  1d8d6a:	vmovd  %xmm0,%eax
  1d8d6e:	add    %eax,%eax
  1d8d70:	cmp    $0xfeffffff,%eax
  1d8d75:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8d7b:	vbroadcastss -0x1bb254(%rip),%xmm1        # 1db30 <__abi_tag+0x1d834>
  1d8d84:	vandps %xmm1,%xmm0,%xmm0
  1d8d88:	xor    %eax,%eax
  1d8d8a:	vucomiss -0x1bb29a(%rip),%xmm0        # 1daf8 <__abi_tag+0x1d7fc>
  1d8d92:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8d98:	vmovss -0x1bb470(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1d8da0:	vucomiss %xmm0,%xmm1
  1d8da4:	jae    1d8610 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x900>
  1d8daa:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8daf:	vmovd  %xmm0,%eax
  1d8db3:	add    %eax,%eax
  1d8db5:	cmp    $0xfeffffff,%eax
  1d8dba:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8dc0:	vbroadcastss -0x1bb299(%rip),%xmm1        # 1db30 <__abi_tag+0x1d834>
  1d8dc9:	vandps %xmm1,%xmm0,%xmm0
  1d8dcd:	xor    %eax,%eax
  1d8dcf:	vucomiss -0x1bb2df(%rip),%xmm0        # 1daf8 <__abi_tag+0x1d7fc>
  1d8dd7:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8ddd:	vmovss -0x1bb4b5(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1d8de5:	vucomiss %xmm0,%xmm1
  1d8de9:	jae    1d8d3a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x102a>
  1d8def:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8df4:	vmovd  %xmm2,%eax
  1d8df8:	add    %eax,%eax
  1d8dfa:	cmp    $0xfeffffff,%eax
  1d8dff:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8e05:	vbroadcastss -0x1bb2de(%rip),%xmm3        # 1db30 <__abi_tag+0x1d834>
  1d8e0e:	vandps %xmm3,%xmm2,%xmm2
  1d8e12:	xor    %eax,%eax
  1d8e14:	vucomiss -0x1bb324(%rip),%xmm2        # 1daf8 <__abi_tag+0x1d7fc>
  1d8e1c:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8e22:	vmovss -0x1bb4fa(%rip),%xmm3        # 1d930 <__abi_tag+0x1d634>
  1d8e2a:	vucomiss %xmm2,%xmm3
  1d8e2e:	jae    1d867f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x96f>
  1d8e34:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8e39:	lea    0x693e0(%rip),%rdx        # 242220 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x258>
  1d8e40:	mov    %r11,%rdi
  1d8e43:	mov    0x48(%rsp),%rsi
  1d8e48:	vzeroupper
  1d8e4b:	call   *0x6d537(%rip)        # 246388 <_DYNAMIC+0x260>
  1d8e51:	lea    0x693e0(%rip),%rdx        # 242238 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x270>
  1d8e58:	mov    %rbx,%rdi
  1d8e5b:	mov    0x40(%rsp),%rsi
  1d8e60:	vzeroupper
  1d8e63:	call   *0x6d51f(%rip)        # 246388 <_DYNAMIC+0x260>
  1d8e69:	vmovd  %xmm0,%eax
  1d8e6d:	add    %eax,%eax
  1d8e6f:	cmp    $0xfeffffff,%eax
  1d8e74:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8e7a:	vbroadcastss -0x1bb353(%rip),%xmm1        # 1db30 <__abi_tag+0x1d834>
  1d8e83:	vandps %xmm1,%xmm0,%xmm0
  1d8e87:	xor    %eax,%eax
  1d8e89:	vucomiss -0x1bb399(%rip),%xmm0        # 1daf8 <__abi_tag+0x1d7fc>
  1d8e91:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8e97:	vmovss -0x1bb56f(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1d8e9f:	vucomiss %xmm0,%xmm1
  1d8ea3:	jae    1d868f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x97f>
  1d8ea9:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8eae:	lea    0x693b3(%rip),%rdx        # 242268 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x2a0>
  1d8eb5:	mov    %r15,%rdi
  1d8eb8:	vzeroupper
  1d8ebb:	call   *0x6d4c7(%rip)        # 246388 <_DYNAMIC+0x260>
  1d8ec1:	lea    0x69388(%rip),%rdx        # 242250 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x288>
  1d8ec8:	mov    %r15,%rdi
  1d8ecb:	mov    0x58(%rsp),%rsi
  1d8ed0:	vzeroupper
  1d8ed3:	call   *0x6d4af(%rip)        # 246388 <_DYNAMIC+0x260>
  1d8ed9:	vmovd  %xmm2,%eax
  1d8edd:	add    %eax,%eax
  1d8edf:	cmp    $0xfeffffff,%eax
  1d8ee4:	ja     1d8092 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x382>
  1d8eea:	vbroadcastss -0x1bb3c3(%rip),%xmm3        # 1db30 <__abi_tag+0x1d834>
  1d8ef3:	vandps %xmm3,%xmm2,%xmm2
  1d8ef7:	xor    %eax,%eax
  1d8ef9:	vucomiss -0x1bb409(%rip),%xmm2        # 1daf8 <__abi_tag+0x1d7fc>
  1d8f01:	jb     1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8f07:	vmovss -0x1bb5df(%rip),%xmm3        # 1d930 <__abi_tag+0x1d634>
  1d8f0f:	vucomiss %xmm2,%xmm3
  1d8f13:	jae    1d86fe <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x9ee>
  1d8f19:	jmp    1d88fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0xbed>
  1d8f1e:	lea    0x69283(%rip),%rdx        # 2421a8 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x1e0>
  1d8f25:	mov    %r15,%rdi
  1d8f28:	mov    0x40(%rsp),%rsi
  1d8f2d:	vzeroupper
  1d8f30:	call   *0x6d452(%rip)        # 246388 <_DYNAMIC+0x260>
  1d8f36:	lea    0x69253(%rip),%rdx        # 242190 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x1c8>
  1d8f3d:	mov    %r14,%rdi
  1d8f40:	mov    0x48(%rsp),%rsi
  1d8f45:	vzeroupper
  1d8f48:	call   *0x6d43a(%rip)        # 246388 <_DYNAMIC+0x260>
  1d8f4e:	lea    0x692b3(%rip),%rdx        # 242208 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x240>
  1d8f55:	mov    0x28(%rsp),%rdi
  1d8f5a:	mov    %rdi,%rsi
  1d8f5d:	vzeroupper
  1d8f60:	call   *0x6d422(%rip)        # 246388 <_DYNAMIC+0x260>
  1d8f66:	lea    0x6935b(%rip),%rdx        # 2422c8 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x300>
  1d8f6d:	mov    0x10(%rsp),%rdi
  1d8f72:	mov    %rdi,%rsi
  1d8f75:	vzeroupper
  1d8f78:	call   *0x6d40a(%rip)        # 246388 <_DYNAMIC+0x260>
  1d8f7e:	lea    0x6932b(%rip),%rdx        # 2422b0 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x2e8>
  1d8f85:	mov    0x20(%rsp),%rdi
  1d8f8a:	mov    %rdi,%rsi
  1d8f8d:	vzeroupper
  1d8f90:	call   *0x6d3f2(%rip)        # 246388 <_DYNAMIC+0x260>
  1d8f96:	lea    0x69223(%rip),%rdx        # 2421c0 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x1f8>
  1d8f9d:	mov    %rax,%rdi
  1d8fa0:	mov    0x58(%rsp),%rsi
  1d8fa5:	vzeroupper
  1d8fa8:	call   *0x6d3da(%rip)        # 246388 <_DYNAMIC+0x260>
  1d8fae:	lea    0x69223(%rip),%rdx        # 2421d8 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x210>
  1d8fb5:	mov    %rax,%rdi
  1d8fb8:	vzeroupper
  1d8fbb:	call   *0x6d3c7(%rip)        # 246388 <_DYNAMIC+0x260>
  1d8fc1:	lea    0x69228(%rip),%rdx        # 2421f0 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x228>
  1d8fc8:	mov    %r8,%rsi
  1d8fcb:	vzeroupper
  1d8fce:	call   *0x6d3b4(%rip)        # 246388 <_DYNAMIC+0x260>
  1d8fd4:	lea    0x692a5(%rip),%rdx        # 242280 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x2b8>
  1d8fdb:	mov    0x60(%rsp),%rdi
  1d8fe0:	mov    %rdi,%rsi
  1d8fe3:	vzeroupper
  1d8fe6:	call   *0x6d39c(%rip)        # 246388 <_DYNAMIC+0x260>
  1d8fec:	lea    0x6916d(%rip),%rdx        # 242160 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x198>
  1d8ff3:	mov    %rbx,%rdi
  1d8ff6:	mov    0x28(%rsp),%rsi
  1d8ffb:	vzeroupper
  1d8ffe:	call   *0x6d384(%rip)        # 246388 <_DYNAMIC+0x260>
  1d9004:	mov    0x10(%rsp),%r12
  1d9009:	lea    0x69168(%rip),%rdx        # 242178 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x1b0>
  1d9010:	mov    %rbx,%rdi
  1d9013:	mov    %r12,%rsi
  1d9016:	vzeroupper
  1d9019:	call   *0x6d369(%rip)        # 246388 <_DYNAMIC+0x260>
  1d901f:	int3
