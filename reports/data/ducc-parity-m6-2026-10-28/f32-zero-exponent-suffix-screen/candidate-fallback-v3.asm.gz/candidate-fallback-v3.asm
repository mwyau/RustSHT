
matched release binary: ELF64 x86-64


Disassembly of section .text:

00000000001d9020 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>>:
  1d9020:	push   %rbp
  1d9021:	push   %r15
  1d9023:	push   %r14
  1d9025:	push   %r13
  1d9027:	push   %r12
  1d9029:	push   %rbx
  1d902a:	sub    $0x828,%rsp
  1d9031:	mov    %rdi,%r14
  1d9034:	mov    0x8(%rsi),%rbx
  1d9038:	test   %rbx,%rbx
  1d903b:	je     1db39b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x237b>
  1d9041:	mov    0xc8(%rsi),%rcx
  1d9048:	mov    0xd0(%rsi),%rdx
  1d904f:	mov    (%rsi),%r13
  1d9052:	mov    0x10(%rsi),%rdi
  1d9056:	mov    0x18(%rsi),%rax
  1d905a:	mov    %rax,0xb8(%rsp)
  1d9062:	vmovss 0xd8(%rsi),%xmm0
  1d906a:	vmovss %xmm0,0x114(%rsp)
  1d9073:	mov    0x20(%rsi),%rax
  1d9077:	mov    %rax,0x190(%rsp)
  1d907f:	mov    0x28(%rsi),%rax
  1d9083:	mov    %rax,0xc8(%rsp)
  1d908b:	mov    0x30(%rsi),%rax
  1d908f:	mov    %rax,0x188(%rsp)
  1d9097:	mov    0x38(%rsi),%rax
  1d909b:	mov    %rax,0xc0(%rsp)
  1d90a3:	mov    0x40(%rsi),%rax
  1d90a7:	mov    %rax,0x178(%rsp)
  1d90af:	mov    0x48(%rsi),%rax
  1d90b3:	mov    %rax,0xb0(%rsp)
  1d90bb:	mov    0x50(%rsi),%rax
  1d90bf:	mov    %rax,0x170(%rsp)
  1d90c7:	mov    %rbx,%r8
  1d90ca:	shr    $0x3,%r8
  1d90ce:	mov    %ebx,%eax
  1d90d0:	and    $0x7,%eax
  1d90d3:	cmp    $0x1,%rax
  1d90d7:	mov    0x58(%rsi),%rax
  1d90db:	mov    %rax,0xa8(%rsp)
  1d90e3:	mov    0x60(%rsi),%rbp
  1d90e7:	mov    0x68(%rsi),%rax
  1d90eb:	mov    %rax,0x158(%rsp)
  1d90f3:	mov    0x70(%rsi),%rax
  1d90f7:	mov    %rax,0x48(%rsp)
  1d90fc:	mov    0x78(%rsi),%rax
  1d9100:	mov    %rax,0x150(%rsp)
  1d9108:	mov    0x80(%rsi),%rax
  1d910f:	mov    %rax,0x220(%rsp)
  1d9117:	mov    0x88(%rsi),%rax
  1d911e:	mov    %rax,0x148(%rsp)
  1d9126:	mov    0x90(%rsi),%r9
  1d912d:	mov    0x98(%rsi),%rax
  1d9134:	mov    %rax,0x140(%rsp)
  1d913c:	mov    0xa0(%rsi),%r10
  1d9143:	mov    0xa8(%rsi),%rax
  1d914a:	mov    %rax,0x30(%rsp)
  1d914f:	mov    0xb0(%rsi),%r11
  1d9156:	mov    0xb8(%rsi),%rax
  1d915d:	mov    %rax,0x28(%rsp)
  1d9162:	mov    0xc0(%rsi),%rax
  1d9169:	mov    %rax,0x108(%rsp)
  1d9171:	sbb    $0xffffffffffffffff,%r8
  1d9175:	mov    %r8,0x168(%rsp)
  1d917d:	mov    %rdx,0xd8(%rsp)
  1d9185:	mov    %rcx,0x90(%rsp)
  1d918d:	sub    %rcx,%rdx
  1d9190:	add    $0x2,%rdx
  1d9194:	shr    $1,%rdx
  1d9197:	mov    %rdx,0x88(%rsp)
  1d919f:	lea    -0x1b077a(%rip),%rax        # 28a2c <anon.f2b1d4bcaf4adfc9d3638ed6f0755141.18.llvm.15276152473248788830+0xba>
  1d91a6:	mov    %rax,%rcx
  1d91a9:	shr    $0x20,%rcx
  1d91ad:	mov    %rcx,0x120(%rsp)
  1d91b5:	shr    $0x8,%eax
  1d91b8:	mov    %rax,0x128(%rsp)
  1d91c0:	mov    $0x8,%ecx
  1d91c5:	xor    %eax,%eax
  1d91c7:	mov    %rdi,0x228(%rsp)
  1d91cf:	mov    %r10,0xa0(%rsp)
  1d91d7:	mov    %r10,0xf0(%rsp)
  1d91df:	mov    %r11,0x98(%rsp)
  1d91e7:	mov    %r11,0xe8(%rsp)
  1d91ef:	movq   $0x0,0x138(%rsp)
  1d91fb:	xor    %edx,%edx
  1d91fd:	mov    %rbp,0x58(%rsp)
  1d9202:	mov    %r14,0x100(%rsp)
  1d920a:	mov    %rbx,0x238(%rsp)
  1d9212:	mov    %r13,0x230(%rsp)
  1d921a:	mov    %r9,0x40(%rsp)
  1d921f:	mov    %rax,%r8
  1d9222:	cmp    %rcx,%rbx
  1d9225:	mov    %rcx,%r12
  1d9228:	cmovb  %rbx,%r12
  1d922c:	lea    (%r12,%rdx,1),%rsi
  1d9230:	mov    %rsi,0x180(%rsp)
  1d9238:	cmp    $0x1,%rsi
  1d923c:	mov    %r12,%r15
  1d923f:	adc    %rdx,%r15
  1d9242:	add    $0x8,%rax
  1d9246:	cmp    %rax,%rbx
  1d9249:	mov    %rax,%r10
  1d924c:	cmovb  %rbx,%r10
  1d9250:	mov    %r10,%rsi
  1d9253:	mov    %r8,0x8(%rsp)
  1d9258:	sub    %r8,%rsi
  1d925b:	jb     1db4c6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x24a6>
  1d9261:	cmp    0xb8(%rsp),%r10
  1d9269:	ja     1db510 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x24f0>
  1d926f:	cmp    0x158(%rsp),%rsi
  1d9277:	ja     1db4e1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x24c1>
  1d927d:	cmp    0x150(%rsp),%rsi
  1d9285:	ja     1db530 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2510>
  1d928b:	cmp    0x148(%rsp),%rsi
  1d9293:	ja     1db54a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x252a>
  1d9299:	cmp    0x140(%rsp),%rsi
  1d92a1:	ja     1db564 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2544>
  1d92a7:	mov    %r15,0x198(%rsp)
  1d92af:	mov    %r10,0x1a0(%rsp)
  1d92b7:	mov    %rdx,0x250(%rsp)
  1d92bf:	mov    %rdi,0xe0(%rsp)
  1d92c7:	mov    %rax,0x160(%rsp)
  1d92cf:	mov    %rcx,0x258(%rsp)
  1d92d7:	mov    %rsi,%rcx
  1d92da:	mov    0x8(%rsp),%r15
  1d92df:	lea    0x0(%r13,%r15,4),%rdx
  1d92e4:	mov    %rbp,0x420(%rsp)
  1d92ec:	mov    %rsi,0x428(%rsp)
  1d92f4:	mov    0x48(%rsp),%rax
  1d92f9:	mov    %rax,0x430(%rsp)
  1d9301:	mov    %rsi,0x438(%rsp)
  1d9309:	mov    %r9,0x440(%rsp)
  1d9311:	mov    %rsi,0x448(%rsp)
  1d9319:	lea    0x320(%rsp),%rdi
  1d9321:	mov    0x90(%rsp),%rsi
  1d9329:	mov    %rcx,0x60(%rsp)
  1d932e:	vmovss 0x114(%rsp),%xmm0
  1d9337:	lea    0x420(%rsp),%r8
  1d933f:	vzeroupper
  1d9342:	call   1d4a00 <rustsht::legendre::numeric::initialize_scalar_recurrence_lanes::<f32, rustsht::legendre::scalar::scaled_power_f32, rustsht::legendre::scalar::normalize_value_f32>>
  1d9347:	mov    0x320(%rsp),%rcx
  1d934f:	cmp    $0xffffffffffffffff,%rcx
  1d9353:	jne    1db470 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2450>
  1d9359:	mov    $0x1,%bl
  1d935b:	mov    0x1a0(%rsp),%r11
  1d9363:	cmp    %r15,%r11
  1d9366:	mov    0x40(%rsp),%r9
  1d936b:	vmovss -0x1bb933(%rip),%xmm3        # 1da40 <__abi_tag+0x1d744>
  1d9373:	vmovss -0x1bbaab(%rip),%xmm9        # 1d8d0 <__abi_tag+0x1d5d4>
  1d937b:	mov    0x60(%rsp),%r10
  1d9380:	mov    %r12,%r15
  1d9383:	mov    0x198(%rsp),%r12
  1d938b:	jne    1d9430 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x410>
  1d9391:	mov    0xd8(%rsp),%rax
  1d9399:	cmp    0x90(%rsp),%rax
  1d93a1:	jae    1d95b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x590>
  1d93a7:	mov    0x168(%rsp),%rax
  1d93af:	dec    %rax
  1d93b2:	mov    0x258(%rsp),%rcx
  1d93ba:	add    $0x8,%rcx
  1d93be:	mov    0x250(%rsp),%rdx
  1d93c6:	add    $0xfffffffffffffff8,%rdx
  1d93ca:	addq   $0xffffffffffffffc0,0x138(%rsp)
  1d93d3:	addq   $0x20,0xe8(%rsp)
  1d93dc:	addq   $0x20,0xf0(%rsp)
  1d93e5:	mov    0xe0(%rsp),%rdi
  1d93ed:	add    $0x20,%rdi
  1d93f1:	mov    %rax,0x168(%rsp)
  1d93f9:	test   %rax,%rax
  1d93fc:	mov    0x100(%rsp),%r14
  1d9404:	mov    0x238(%rsp),%rbx
  1d940c:	mov    0x230(%rsp),%r13
  1d9414:	mov    0x160(%rsp),%rax
  1d941c:	jne    1d921f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1ff>
  1d9422:	jmp    1db39b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x237b>
  1d9427:	nopw   0x0(%rax,%rax,1)
  1d9430:	xor    %eax,%eax
  1d9432:	jmp    1d948b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x46b>
  1d9434:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1d9440:	mov    %rcx,(%r9,%rax,8)
  1d9444:	vmovss %xmm2,0x0(%rbp,%rax,4)
  1d944a:	mov    0x48(%rsp),%rcx
  1d944f:	vmovss %xmm0,(%rcx,%rax,4)
  1d9454:	cmpq   $0x0,(%r9,%rax,8)
  1d9459:	lea    0x1(%rax),%rax
  1d945d:	sete   %cl
  1d9460:	cmp    $0x53800001,%edx
  1d9466:	setb   %sil
  1d946a:	add    $0xd4800000,%edx
  1d9470:	cmp    $0xd4800001,%edx
  1d9476:	setb   %dl
  1d9479:	and    %cl,%sil
  1d947c:	and    %dl,%sil
  1d947f:	and    %sil,%bl
  1d9482:	cmp    %r12,%rax
  1d9485:	je     1d9391 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x371>
  1d948b:	mov    0x0(%rbp,%rax,4),%edx
  1d948f:	vmovd  %edx,%xmm0
  1d9493:	and    $0x7fffffff,%edx
  1d9499:	mov    0x48(%rsp),%rcx
  1d949e:	mov    (%rcx,%rax,4),%ecx
  1d94a1:	vmovd  %ecx,%xmm1
  1d94a5:	and    $0x7fffffff,%ecx
  1d94ab:	cmp    %edx,%ecx
  1d94ad:	cmovbe %edx,%ecx
  1d94b0:	cmp    $0x53800001,%ecx
  1d94b6:	jb     1d9510 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x4f0>
  1d94b8:	mov    (%r9,%rax,8),%rsi
  1d94bc:	vmulss %xmm3,%xmm0,%xmm0
  1d94c0:	vmulss %xmm3,%xmm1,%xmm1
  1d94c4:	add    $0x50,%rsi
  1d94c8:	jo     1db3ea <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x23ca>
  1d94ce:	vmovd  %ecx,%xmm2
  1d94d2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1d94e0:	mov    %rsi,%rdi
  1d94e3:	vmulss %xmm3,%xmm2,%xmm2
  1d94e7:	vmovd  %xmm2,%ecx
  1d94eb:	mov    %ecx,%edx
  1d94ed:	and    $0x7fffffff,%edx
  1d94f3:	cmp    $0x53800000,%edx
  1d94f9:	jbe    1d9530 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x510>
  1d94fb:	vmulss %xmm3,%xmm0,%xmm0
  1d94ff:	vmulss %xmm3,%xmm1,%xmm1
  1d9503:	add    $0x50,%rsi
  1d9507:	jno    1d94e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x4c0>
  1d9509:	jmp    1db3e6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x23c6>
  1d950e:	xchg   %ax,%ax
  1d9510:	mov    %ecx,%edx
  1d9512:	lea    -0x1(%rdx),%esi
  1d9515:	cmp    $0x2b7ffffe,%esi
  1d951b:	ja     1d9454 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x434>
  1d9521:	jmp    1d9553 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x533>
  1d9523:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1d9530:	mov    %rdi,(%r9,%rax,8)
  1d9534:	vmovss %xmm0,0x0(%rbp,%rax,4)
  1d953a:	mov    0x48(%rsp),%rsi
  1d953f:	vmovss %xmm1,(%rsi,%rax,4)
  1d9544:	lea    -0x1(%rdx),%esi
  1d9547:	cmp    $0x2b7ffffe,%esi
  1d954d:	ja     1d9454 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x434>
  1d9553:	mov    (%r9,%rax,8),%rsi
  1d9557:	vmulss %xmm0,%xmm9,%xmm2
  1d955b:	vmulss %xmm1,%xmm9,%xmm0
  1d955f:	add    $0xffffffffffffffb0,%rsi
  1d9563:	jo     1db400 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x23e0>
  1d9569:	vmovd  %ecx,%xmm1
  1d956d:	nopl   (%rax)
  1d9570:	mov    %rsi,%rcx
  1d9573:	vmulss %xmm1,%xmm9,%xmm1
  1d9577:	vmovd  %xmm1,%edx
  1d957b:	and    $0x7fffffff,%edx
  1d9581:	lea    -0x1(%rdx),%edi
  1d9584:	cmp    $0x2b7fffff,%edi
  1d958a:	jae    1d9440 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x420>
  1d9590:	vmulss %xmm2,%xmm9,%xmm2
  1d9594:	vmulss %xmm0,%xmm9,%xmm0
  1d9598:	add    $0xffffffffffffffb0,%rsi
  1d959c:	jno    1d9570 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x550>
  1d959e:	jmp    1db3fc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x23dc>
  1d95a3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1d95b0:	mov    0x180(%rsp),%rax
  1d95b8:	shr    $0x3,%rax
  1d95bc:	mov    %rax,0xd0(%rsp)
  1d95c4:	mov    %rax,%rsi
  1d95c7:	and    $0xfffffffffffffffe,%rsi
  1d95cb:	mov    0x138(%rsp),%rax
  1d95d3:	lea    (%rax,%r15,8),%rax
  1d95d7:	mov    %rax,0x248(%rsp)
  1d95df:	and    $0x7,%r15d
  1d95e3:	mov    0x228(%rsp),%rax
  1d95eb:	mov    0x8(%rsp),%rcx
  1d95f0:	lea    (%rax,%rcx,4),%rax
  1d95f4:	mov    %rax,0x20(%rsp)
  1d95f9:	lea    0x7(%rcx),%rax
  1d95fd:	mov    %rax,0x218(%rsp)
  1d9605:	mov    %r10,%rcx
  1d9608:	movabs $0x1ffffffffffffff8,%rax
  1d9612:	and    %rax,%rcx
  1d9615:	mov    %rcx,(%rsp)
  1d9619:	mov    %r11d,%eax
  1d961c:	and    $0x7,%eax
  1d961f:	mov    %rax,0x38(%rsp)
  1d9624:	movq   $0x0,0x18(%rsp)
  1d962d:	mov    %rbp,%rax
  1d9630:	mov    0x48(%rsp),%r14
  1d9635:	mov    0x220(%rsp),%rdi
  1d963d:	movq   $0x0,0x1a8(%rsp)
  1d9649:	mov    0x90(%rsp),%rcx
  1d9651:	xor    %edx,%edx
  1d9653:	mov    %rsi,0x68(%rsp)
  1d9658:	mov    %r15,0x240(%rsp)
  1d9660:	jmp    1d9695 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x675>
  1d9662:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1d9670:	lea    0x1(%r8),%rcx
  1d9674:	incq   0x1a8(%rsp)
  1d967c:	mov    $0x1,%edx
  1d9681:	mov    %r14,%rax
  1d9684:	mov    %r13,%r14
  1d9687:	cmp    0xd8(%rsp),%r8
  1d968f:	jae    1d93a7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x387>
  1d9695:	add    %rdx,%rcx
  1d9698:	jb     1d93a7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x387>
  1d969e:	mov    %rcx,%r8
  1d96a1:	cmp    0xd8(%rsp),%rcx
  1d96a9:	ja     1d93a7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x387>
  1d96af:	mov    %rdi,%r13
  1d96b2:	mov    %rax,0xf8(%rsp)
  1d96ba:	testb  $0x1,0x18(%rsp)
  1d96bf:	je     1d98f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x8d0>
  1d96c5:	mov    $0x1,%al
  1d96c7:	mov    %rax,0x18(%rsp)
  1d96cc:	mov    0x108(%rsp),%rax
  1d96d4:	cmpb   $0x1,(%rax)
  1d96d7:	jne    1da7da <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x17ba>
  1d96dd:	mov    %r8,%rdi
  1d96e0:	sub    0x90(%rsp),%rdi
  1d96e8:	shr    $1,%rdi
  1d96eb:	cmp    0xb0(%rsp),%rdi
  1d96f3:	jae    1db68e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x266e>
  1d96f9:	mov    %r8,0x80(%rsp)
  1d9701:	cmp    0xa8(%rsp),%rdi
  1d9709:	jae    1db6a6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2686>
  1d970f:	mov    0x178(%rsp),%rax
  1d9717:	vmovss (%rax,%rdi,8),%xmm0
  1d971c:	vmovaps %xmm0,0x260(%rsp)
  1d9725:	vmovss 0x4(%rax,%rdi,8),%xmm0
  1d972b:	vmovaps %xmm0,0x200(%rsp)
  1d9734:	mov    0x170(%rsp),%rax
  1d973c:	vmovss (%rax,%rdi,8),%xmm0
  1d9741:	vmovaps %xmm0,0x1f0(%rsp)
  1d974a:	vmovss 0x4(%rax,%rdi,8),%xmm0
  1d9750:	vmovaps %xmm0,0x1e0(%rsp)
  1d9759:	vbroadcastss -0x1bc1d2(%rip),%ymm0        # 1d590 <__abi_tag+0x1d294>
  1d9762:	vmovups %ymm0,0x728(%rsp)
  1d976b:	vmovups %ymm0,0x748(%rsp)
  1d9774:	vmovups %ymm0,0x768(%rsp)
  1d977d:	vmovups %ymm0,0x788(%rsp)
  1d9786:	vmovups %ymm0,0x7a8(%rsp)
  1d978f:	vmovups %ymm0,0x7c8(%rsp)
  1d9798:	vmovups %ymm0,0x7e8(%rsp)
  1d97a1:	vmovups %ymm0,0x808(%rsp)
  1d97aa:	cmp    $0x8,%r10
  1d97ae:	jae    1d99c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x9a0>
  1d97b4:	mov    (%rsp),%rax
  1d97b8:	cmp    0x60(%rsp),%rax
  1d97bd:	je     1da7b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1790>
  1d97c3:	mov    (%rsp),%r15
  1d97c7:	nopw   0x0(%rax,%rax,1)
  1d97d0:	mov    0xe0(%rsp),%rax
  1d97d8:	vmovss (%rax,%r15,4),%xmm1
  1d97de:	vmovaps %xmm1,%xmm0
  1d97e2:	vmovaps 0x1f0(%rsp),%xmm2
  1d97eb:	vfmadd213ss 0x260(%rsp),%xmm2,%xmm0
  1d97f5:	vmovaps 0x1e0(%rsp),%xmm2
  1d97fe:	vfmadd213ss 0x200(%rsp),%xmm2,%xmm1
  1d9808:	mov    (%r9,%r15,8),%rdi
  1d980c:	vmovss (%r14,%r15,4),%xmm2
  1d9812:	test   %rdi,%rdi
  1d9815:	je     1d9840 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x820>
  1d9817:	vzeroupper
  1d981a:	call   *0x6d358(%rip)        # 246b78 <_DYNAMIC+0xa50>
  1d9820:	mov    0x8(%rsp),%rax
  1d9825:	lea    (%rax,%r15,1),%rdi
  1d9829:	cmp    0x30(%rsp),%rdi
  1d982e:	jb     1d985c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x83c>
  1d9830:	jmp    1db619 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x25f9>
  1d9835:	data16 cs nopw 0x0(%rax,%rax,1)
  1d9840:	vmulss %xmm2,%xmm0,%xmm0
  1d9844:	vmulss %xmm2,%xmm1,%xmm1
  1d9848:	mov    0x8(%rsp),%rax
  1d984d:	lea    (%rax,%r15,1),%rdi
  1d9851:	cmp    0x30(%rsp),%rdi
  1d9856:	jae    1db619 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x25f9>
  1d985c:	cmp    0x28(%rsp),%rdi
  1d9861:	mov    0x40(%rsp),%r9
  1d9866:	vmovss -0x1bbf9e(%rip),%xmm9        # 1d8d0 <__abi_tag+0x1d5d4>
  1d986e:	jae    1db604 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x25e4>
  1d9874:	mov    0xf0(%rsp),%rax
  1d987c:	vaddss (%rax,%r15,4),%xmm0,%xmm0
  1d9882:	mov    0xe8(%rsp),%rax
  1d988a:	vaddss (%rax,%r15,4),%xmm1,%xmm1
  1d9890:	vmovd  %xmm1,%eax
  1d9894:	vmovd  %xmm0,%ecx
  1d9898:	add    %ecx,%ecx
  1d989a:	add    %eax,%eax
  1d989c:	cmp    $0xff000000,%eax
  1d98a1:	setb   %al
  1d98a4:	cmp    $0xfeffffff,%ecx
  1d98aa:	ja     1da7a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1780>
  1d98b0:	test   %al,%al
  1d98b2:	je     1da7a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1780>
  1d98b8:	mov    0xf0(%rsp),%rax
  1d98c0:	vmovss %xmm0,(%rax,%r15,4)
  1d98c6:	mov    0xe8(%rsp),%rax
  1d98ce:	vmovss %xmm1,(%rax,%r15,4)
  1d98d4:	inc    %r15
  1d98d7:	cmp    0x60(%rsp),%r15
  1d98dc:	mov    0x58(%rsp),%rbp
  1d98e1:	jb     1d97d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x7b0>
  1d98e7:	jmp    1da7b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1790>
  1d98ec:	nopl   0x0(%rax)
  1d98f0:	mov    %r8,%rdi
  1d98f3:	sub    0x90(%rsp),%rdi
  1d98fb:	shr    $1,%rdi
  1d98fe:	mov    0x88(%rsp),%rax
  1d9906:	sub    %rdi,%rax
  1d9909:	cmp    $0x4,%rax
  1d990d:	setb   %cl
  1d9910:	mov    %rcx,0x18(%rsp)
  1d9915:	cmp    $0x8,%r10
  1d9919:	mov    0x248(%rsp),%rcx
  1d9921:	jne    1d96cc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x6ac>
  1d9927:	cmp    $0x4,%rax
  1d992b:	jb     1d96cc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x6ac>
  1d9931:	xor    %eax,%eax
  1d9933:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1d9940:	cmpq   $0x0,(%r9,%rax,1)
  1d9945:	jne    1dae9b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1e7b>
  1d994b:	add    $0x8,%rax
  1d994f:	cmp    %rax,%rcx
  1d9952:	jne    1d9940 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x920>
  1d9954:	mov    0xb8(%rsp),%rax
  1d995c:	cmp    %rax,0x218(%rsp)
  1d9964:	jae    1db5ab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x258b>
  1d996a:	mov    0x8(%rsp),%rax
  1d996f:	lea    0x8(%rax),%rsi
  1d9973:	cmp    0x30(%rsp),%rsi
  1d9978:	ja     1db5d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x25b0>
  1d997e:	cmp    0x28(%rsp),%rsi
  1d9983:	ja     1db5ea <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x25ca>
  1d9989:	mov    0x88(%rsp),%rax
  1d9991:	sub    %rdi,%rax
  1d9994:	mov    $0x0,%ecx
  1d9999:	cmovae %rax,%rcx
  1d999d:	cmp    $0x4,%rcx
  1d99a1:	jae    1daea9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1e89>
  1d99a7:	mov    $0x1,%al
  1d99a9:	mov    %rax,0x18(%rsp)
  1d99ae:	mov    0x68(%rsp),%rsi
  1d99b3:	jmp    1d96cc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x6ac>
  1d99b8:	nopl   0x0(%rax,%rax,1)
  1d99c0:	vmovdqa 0x1f0(%rsp),%xmm0
  1d99c9:	vmovd  %xmm0,%edx
  1d99cd:	vpbroadcastd %xmm0,%ymm0
  1d99d2:	vmovdqu %ymm0,0x300(%rsp)
  1d99db:	vmovdqa 0x260(%rsp),%xmm0
  1d99e4:	vmovd  %xmm0,%ecx
  1d99e8:	vpbroadcastd %xmm0,%ymm0
  1d99ed:	vmovdqu %ymm0,0x2e0(%rsp)
  1d99f6:	vmovdqa 0x1e0(%rsp),%xmm0
  1d99ff:	vmovd  %xmm0,%eax
  1d9a03:	vpbroadcastd %xmm0,%ymm0
  1d9a08:	vmovdqu %ymm0,0x2c0(%rsp)
  1d9a11:	vmovdqa 0x200(%rsp),%xmm0
  1d9a1a:	vmovd  %xmm0,%esi
  1d9a1e:	vpbroadcastd %xmm0,%ymm0
  1d9a23:	vmovdqu %ymm0,0x2a0(%rsp)
  1d9a2c:	and    $0x7fffffff,%ecx
  1d9a32:	cmp    $0x7f800000,%ecx
  1d9a38:	sete   %dil
  1d9a3c:	lea    -0x1(%rcx),%r8d
  1d9a40:	cmp    $0x7fffff,%r8d
  1d9a47:	setb   %r8b
  1d9a4b:	cmp    $0x7f800001,%ecx
  1d9a51:	setge  %cl
  1d9a54:	or     %dil,%cl
  1d9a57:	or     %r8b,%cl
  1d9a5a:	and    $0x7fffffff,%esi
  1d9a60:	cmp    $0x7f800000,%esi
  1d9a66:	sete   %dil
  1d9a6a:	lea    -0x1(%rsi),%r8d
  1d9a6e:	cmp    $0x7fffff,%r8d
  1d9a75:	setb   %r8b
  1d9a79:	cmp    $0x7f800001,%esi
  1d9a7f:	setge  %r10b
  1d9a83:	or     %dil,%r10b
  1d9a86:	or     %r8b,%r10b
  1d9a89:	and    $0x7fffffff,%edx
  1d9a8f:	cmp    $0x7f800000,%edx
  1d9a95:	sete   %sil
  1d9a99:	lea    -0x1(%rdx),%edi
  1d9a9c:	cmp    $0x7fffff,%edi
  1d9aa2:	setb   %dil
  1d9aa6:	cmp    $0x7f800001,%edx
  1d9aac:	setge  %dl
  1d9aaf:	or     %sil,%dl
  1d9ab2:	or     %dil,%dl
  1d9ab5:	and    $0x7fffffff,%eax
  1d9aba:	cmp    $0x7f800000,%eax
  1d9abf:	sete   %sil
  1d9ac3:	lea    -0x1(%rax),%edi
  1d9ac6:	cmp    $0x7fffff,%edi
  1d9acc:	setb   %dil
  1d9ad0:	cmp    $0x7f800001,%eax
  1d9ad5:	setge  %al
  1d9ad8:	or     %sil,%al
  1d9adb:	or     %dil,%al
  1d9ade:	or     %dl,%al
  1d9ae0:	or     %cl,%r10b
  1d9ae3:	or     %al,%r10b
  1d9ae6:	mov    %r10b,0x17(%rsp)
  1d9aeb:	mov    0xe0(%rsp),%rax
  1d9af3:	mov    %rax,0x1c8(%rsp)
  1d9afb:	mov    %r9,0x1c0(%rsp)
  1d9b03:	mov    %r14,0x1b8(%rsp)
  1d9b0b:	mov    0xf0(%rsp),%r15
  1d9b13:	mov    0xe8(%rsp),%r12
  1d9b1b:	mov    0x8(%rsp),%rax
  1d9b20:	mov    %rax,0x1b0(%rsp)
  1d9b28:	xor    %eax,%eax
  1d9b2a:	lea    0x0(,%rax,8),%r8
  1d9b32:	lea    0x8(,%rax,8),%rsi
  1d9b3a:	cmp    0x60(%rsp),%rsi
  1d9b3f:	ja     1db57e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x255e>
  1d9b45:	mov    %rax,0x130(%rsp)
  1d9b4d:	lea    (%r9,%r8,8),%rax
  1d9b51:	mov    (%r9,%r8,8),%rdx
  1d9b55:	mov    %rdx,0x78(%rsp)
  1d9b5a:	lea    0x7e(%rdx),%rcx
  1d9b5e:	cmp    $0xfe,%rcx
  1d9b65:	jae    1d9ef0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xed0>
  1d9b6b:	mov    0x8(%rax),%rcx
  1d9b6f:	lea    0x7e(%rcx),%rdx
  1d9b73:	cmp    $0xfd,%rdx
  1d9b7a:	ja     1d9ef0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xed0>
  1d9b80:	mov    0x10(%rax),%rdx
  1d9b84:	lea    0x7e(%rdx),%rdi
  1d9b88:	cmp    $0xfd,%rdi
  1d9b8f:	ja     1d9ef0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xed0>
  1d9b95:	mov    0x18(%rax),%rdi
  1d9b99:	lea    0x7e(%rdi),%r9
  1d9b9d:	cmp    $0xfd,%r9
  1d9ba4:	ja     1d9ef0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xed0>
  1d9baa:	mov    0x20(%rax),%r9
  1d9bae:	lea    0x7e(%r9),%r10
  1d9bb2:	cmp    $0xfd,%r10
  1d9bb9:	ja     1d9ef0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xed0>
  1d9bbf:	mov    0x28(%rax),%r10
  1d9bc3:	lea    0x7e(%r10),%r11
  1d9bc7:	cmp    $0xfd,%r11
  1d9bce:	ja     1d9ef0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xed0>
  1d9bd4:	mov    0x30(%rax),%r11
  1d9bd8:	lea    0x7e(%r11),%rbp
  1d9bdc:	cmp    $0xfd,%rbp
  1d9be3:	mov    0x58(%rsp),%rbp
  1d9be8:	ja     1d9ef0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xed0>
  1d9bee:	mov    %r11,0x50(%rsp)
  1d9bf3:	mov    0x38(%rax),%r11
  1d9bf7:	mov    %r11,0x70(%rsp)
  1d9bfc:	lea    0x7e(%r11),%rbp
  1d9c00:	mov    0x50(%rsp),%r11
  1d9c05:	cmp    $0xfe,%rbp
  1d9c0c:	mov    0x58(%rsp),%rbp
  1d9c11:	jae    1d9ef0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xed0>
  1d9c17:	cmpq   $0x8,0x130(%rsp)
  1d9c20:	jae    1db724 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2704>
  1d9c26:	vmovd  %r9d,%xmm0
  1d9c2b:	vpinsrd $0x1,%r10d,%xmm0,%xmm0
  1d9c31:	vpinsrd $0x2,%r11d,%xmm0,%xmm0
  1d9c37:	vpinsrd $0x3,0x70(%rsp),%xmm0,%xmm0
  1d9c3f:	vmovd  0x78(%rsp),%xmm1
  1d9c45:	vpinsrd $0x1,%ecx,%xmm1,%xmm1
  1d9c4b:	vpinsrd $0x2,%edx,%xmm1,%xmm1
  1d9c51:	vpinsrd $0x3,%edi,%xmm1,%xmm1
  1d9c57:	vinserti128 $0x1,%xmm0,%ymm1,%ymm0
  1d9c5d:	vpslld $0x17,%ymm0,%ymm0
  1d9c62:	vpbroadcastd -0x1bc6db(%rip),%ymm1        # 1d590 <__abi_tag+0x1d294>
  1d9c6b:	vpaddd %ymm1,%ymm0,%ymm0
  1d9c6f:	vmovdqu %ymm0,0x728(%rsp,%r8,4)
  1d9c79:	mov    0x8(%rsp),%rax
  1d9c7e:	lea    (%r8,%rax,1),%rdi
  1d9c82:	add    %rax,%rsi
  1d9c85:	cmp    %rdi,%rsi
  1d9c88:	jb     1db62e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x260e>
  1d9c8e:	cmp    0x30(%rsp),%rsi
  1d9c93:	ja     1db62e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x260e>
  1d9c99:	cmp    0x28(%rsp),%rsi
  1d9c9e:	mov    0x40(%rsp),%r9
  1d9ca3:	ja     1db679 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2659>
  1d9ca9:	lea    (%rsp,%r8,4),%rsi
  1d9cad:	add    $0x728,%rsi
  1d9cb4:	mov    0x20(%rsp),%rax
  1d9cb9:	lea    (%rax,%r8,4),%rax
  1d9cbd:	lea    (%r14,%r8,4),%rdx
  1d9cc1:	mov    0x6cec0(%rip),%r10        # 246b88 <_DYNAMIC+0xa60>
  1d9cc8:	mov    0x800(%r10),%r8
  1d9ccf:	lea    0x3(%rip),%rcx        # 1d9cd9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xcb9>
  1d9cd6:	jmp    *%r8
  1d9cd9:	vmovaps %ymm0,%ymm2
  1d9cdd:	mov    0x800(%r10),%r8
  1d9ce4:	mov    %rdx,%rax
  1d9ce7:	lea    0x3(%rip),%rcx        # 1d9cf1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xcd1>
  1d9cee:	jmp    *%r8
  1d9cf1:	vmovaps %ymm0,%ymm3
  1d9cf5:	mov    0x800(%r10),%rdx
  1d9cfc:	mov    %rsi,%rax
  1d9cff:	lea    0x2(%rip),%rcx        # 1d9d08 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xce8>
  1d9d06:	jmp    *%rdx
  1d9d08:	vmovaps %ymm2,%ymm6
  1d9d0c:	vmovups 0x2e0(%rsp),%ymm1
  1d9d15:	vfmadd132ps 0x300(%rsp),%ymm1,%ymm6
  1d9d1f:	vbroadcastss -0x1bc1f8(%rip),%ymm1        # 1db30 <__abi_tag+0x1d834>
  1d9d28:	vandps %ymm1,%ymm6,%ymm5
  1d9d2c:	vpbroadcastd -0x1bc1fd(%rip),%ymm4        # 1db38 <__abi_tag+0x1d83c>
  1d9d35:	vpsubd %ymm4,%ymm5,%ymm7
  1d9d39:	vpbroadcastd -0x1bc242(%rip),%ymm5        # 1db00 <__abi_tag+0x1d804>
  1d9d42:	vpminud %ymm5,%ymm7,%ymm8
  1d9d47:	vpxor  %ymm7,%ymm8,%ymm7
  1d9d4b:	vptest %ymm7,%ymm7
  1d9d50:	jne    1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1d9d56:	vmovups 0x2a0(%rsp),%ymm7
  1d9d5f:	vfmadd132ps 0x2c0(%rsp),%ymm7,%ymm2
  1d9d69:	vandps %ymm1,%ymm2,%ymm7
  1d9d6d:	vpsubd %ymm4,%ymm7,%ymm7
  1d9d71:	vpminud %ymm5,%ymm7,%ymm8
  1d9d76:	vpcmpeqd %ymm7,%ymm8,%ymm7
  1d9d7a:	vmovmskps %ymm7,%eax
  1d9d7e:	cmp    $0xff,%al
  1d9d80:	jne    1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1d9d86:	vandps %ymm1,%ymm3,%ymm7
  1d9d8a:	vpsubd %ymm4,%ymm7,%ymm7
  1d9d8e:	vpminud %ymm5,%ymm7,%ymm8
  1d9d93:	vpcmpeqd %ymm7,%ymm8,%ymm7
  1d9d97:	vmovmskps %ymm7,%eax
  1d9d9b:	cmp    $0xff,%al
  1d9d9d:	jne    1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1d9da3:	vmulps %ymm3,%ymm6,%ymm6
  1d9da7:	vandps %ymm1,%ymm6,%ymm7
  1d9dab:	vpsubd %ymm4,%ymm7,%ymm7
  1d9daf:	vpminud %ymm5,%ymm7,%ymm8
  1d9db4:	vpxor  %ymm7,%ymm8,%ymm7
  1d9db8:	vptest %ymm7,%ymm7
  1d9dbd:	jne    1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1d9dc3:	vmulps %ymm3,%ymm2,%ymm3
  1d9dc7:	vandps %ymm1,%ymm3,%ymm2
  1d9dcb:	vpsubd %ymm4,%ymm2,%ymm2
  1d9dcf:	vpminud %ymm5,%ymm2,%ymm7
  1d9dd4:	vpcmpeqd %ymm7,%ymm2,%ymm2
  1d9dd8:	vmovmskps %ymm2,%eax
  1d9ddc:	cmp    $0xff,%al
  1d9dde:	jne    1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1d9de4:	vmulps %ymm0,%ymm6,%ymm2
  1d9de8:	vandps %ymm1,%ymm2,%ymm6
  1d9dec:	vpsubd %ymm4,%ymm6,%ymm6
  1d9df0:	vpminud %ymm5,%ymm6,%ymm7
  1d9df5:	vpxor  %ymm7,%ymm6,%ymm6
  1d9df9:	vptest %ymm6,%ymm6
  1d9dfe:	jne    1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1d9e04:	vmulps %ymm0,%ymm3,%ymm3
  1d9e08:	vandps %ymm1,%ymm3,%ymm0
  1d9e0c:	vpsubd %ymm4,%ymm0,%ymm0
  1d9e10:	vpminud %ymm5,%ymm0,%ymm1
  1d9e15:	vpcmpeqd %ymm1,%ymm0,%ymm0
  1d9e19:	vmovmskps %ymm0,%eax
  1d9e1d:	cmp    $0xff,%al
  1d9e1f:	jne    1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1d9e25:	mov    0xa0(%rsp),%rax
  1d9e2d:	lea    (%rax,%rdi,4),%rsi
  1d9e31:	mov    0x98(%rsp),%rax
  1d9e39:	lea    (%rax,%rdi,4),%rdx
  1d9e3d:	mov    0x6cd44(%rip),%r8        # 246b88 <_DYNAMIC+0xa60>
  1d9e44:	mov    0x800(%r8),%rdi
  1d9e4b:	mov    %rsi,%rax
  1d9e4e:	lea    0x2(%rip),%rcx        # 1d9e57 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xe37>
  1d9e55:	jmp    *%rdi
  1d9e57:	vaddps %ymm0,%ymm2,%ymm2
  1d9e5b:	mov    0x800(%r8),%rdi
  1d9e62:	mov    %rdx,%rax
  1d9e65:	lea    0x2(%rip),%rcx        # 1d9e6e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xe4e>
  1d9e6c:	jmp    *%rdi
  1d9e6e:	vpaddd %ymm2,%ymm2,%ymm4
  1d9e72:	vpbroadcastd -0x1bc8f3(%rip),%ymm1        # 1d588 <__abi_tag+0x1d28c>
  1d9e7b:	vpminud %ymm1,%ymm4,%ymm5
  1d9e80:	vpxor  %ymm5,%ymm4,%ymm4
  1d9e84:	vptest %ymm4,%ymm4
  1d9e89:	jne    1da7a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1780>
  1d9e8f:	vaddps %ymm0,%ymm3,%ymm3
  1d9e93:	vpaddd %ymm3,%ymm3,%ymm0
  1d9e97:	vpminud %ymm1,%ymm0,%ymm1
  1d9e9c:	vpxor  %ymm1,%ymm0,%ymm0
  1d9ea0:	vptest %ymm0,%ymm0
  1d9ea5:	jne    1da7a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1780>
  1d9eab:	mov    0x6ccd6(%rip),%r8        # 246b88 <_DYNAMIC+0xa60>
  1d9eb2:	mov    0x808(%r8),%rdi
  1d9eb9:	mov    %rsi,%rax
  1d9ebc:	vmovaps %ymm2,%ymm0
  1d9ec0:	lea    0x2(%rip),%rcx        # 1d9ec9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xea9>
  1d9ec7:	jmp    *%rdi
  1d9ec9:	mov    0x808(%r8),%rsi
  1d9ed0:	mov    %rdx,%rax
  1d9ed3:	vmovaps %ymm3,%ymm0
  1d9ed7:	lea    0x2(%rip),%rcx        # 1d9ee0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xec0>
  1d9ede:	jmp    *%rsi
  1d9ee0:	mov    0x58(%rsp),%rbp
  1d9ee5:	jmp    1da1ca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x11aa>
  1d9eea:	nopw   0x0(%rax,%rax,1)
  1d9ef0:	mov    %rax,0x78(%rsp)
  1d9ef5:	mov    0x8(%rsp),%rax
  1d9efa:	lea    (%r8,%rax,1),%rdi
  1d9efe:	add    %rax,%rsi
  1d9f01:	cmp    %rdi,%rsi
  1d9f04:	jb     1db4fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x24db>
  1d9f0a:	cmp    0x30(%rsp),%rsi
  1d9f0f:	ja     1db4fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x24db>
  1d9f15:	cmp    0x28(%rsp),%rsi
  1d9f1a:	ja     1db596 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2576>
  1d9f20:	cmpb   $0x0,0x17(%rsp)
  1d9f25:	mov    0x40(%rsp),%r9
  1d9f2a:	jne    1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1d9f30:	mov    0x20(%rsp),%rax
  1d9f35:	lea    (%rax,%r8,4),%rax
  1d9f39:	lea    (%r14,%r8,4),%rdx
  1d9f3d:	mov    0x6cc44(%rip),%r8        # 246b88 <_DYNAMIC+0xa60>
  1d9f44:	mov    0x800(%r8),%rsi
  1d9f4b:	lea    0x2(%rip),%rcx        # 1d9f54 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xf34>
  1d9f52:	jmp    *%rsi
  1d9f54:	vmovaps %ymm0,%ymm2
  1d9f58:	mov    0x800(%r8),%rsi
  1d9f5f:	mov    %rdx,%rax
  1d9f62:	lea    0x2(%rip),%rcx        # 1d9f6b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xf4b>
  1d9f69:	jmp    *%rsi
  1d9f6b:	vmovaps %ymm2,%ymm1
  1d9f6f:	vmovups 0x2e0(%rsp),%ymm3
  1d9f78:	vfmadd132ps 0x300(%rsp),%ymm3,%ymm1
  1d9f82:	vbroadcastss -0x1bc45b(%rip),%ymm3        # 1db30 <__abi_tag+0x1d834>
  1d9f8b:	vandps %ymm3,%ymm1,%ymm5
  1d9f8f:	vpbroadcastd -0x1bc460(%rip),%ymm4        # 1db38 <__abi_tag+0x1d83c>
  1d9f98:	vpsubd %ymm4,%ymm5,%ymm6
  1d9f9c:	vpbroadcastd -0x1bc4a5(%rip),%ymm5        # 1db00 <__abi_tag+0x1d804>
  1d9fa5:	vpminud %ymm5,%ymm6,%ymm7
  1d9faa:	vpcmpeqd %ymm7,%ymm6,%ymm6
  1d9fae:	vpxor  %xmm7,%xmm7,%xmm7
  1d9fb2:	vcmpeqps %ymm7,%ymm1,%ymm7
  1d9fb7:	vpcmpeqd %ymm8,%ymm8,%ymm8
  1d9fbc:	vpcmpeqd %ymm7,%ymm8,%ymm7
  1d9fc0:	vpor   %ymm7,%ymm6,%ymm6
  1d9fc4:	vtestps %ymm8,%ymm6
  1d9fc9:	jae    1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1d9fcf:	vmovups 0x2a0(%rsp),%ymm6
  1d9fd8:	vfmadd132ps 0x2c0(%rsp),%ymm6,%ymm2
  1d9fe2:	vandps %ymm3,%ymm2,%ymm6
  1d9fe6:	vpsubd %ymm4,%ymm6,%ymm6
  1d9fea:	vpminud %ymm5,%ymm6,%ymm7
  1d9fef:	vpcmpeqd %ymm7,%ymm6,%ymm6
  1d9ff3:	vpxor  %xmm7,%xmm7,%xmm7
  1d9ff7:	vcmpeqps %ymm7,%ymm2,%ymm7
  1d9ffc:	vpcmpeqd %ymm7,%ymm8,%ymm7
  1da000:	vpor   %ymm7,%ymm6,%ymm6
  1da004:	vtestps %ymm8,%ymm6
  1da009:	jae    1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1da00f:	vandps %ymm3,%ymm0,%ymm6
  1da013:	vpsubd %ymm4,%ymm6,%ymm6
  1da017:	vpminud %ymm5,%ymm6,%ymm7
  1da01c:	vpcmpeqd %ymm7,%ymm6,%ymm6
  1da020:	vpxor  %xmm7,%xmm7,%xmm7
  1da024:	vcmpeqps %ymm7,%ymm0,%ymm7
  1da029:	vpcmpeqd %ymm7,%ymm8,%ymm7
  1da02d:	vpor   %ymm7,%ymm6,%ymm6
  1da031:	vtestps %ymm8,%ymm6
  1da036:	jae    1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1da038:	vmulps %ymm0,%ymm1,%ymm1
  1da03c:	vandps %ymm3,%ymm1,%ymm6
  1da040:	vpsubd %ymm4,%ymm6,%ymm6
  1da044:	vpminud %ymm5,%ymm6,%ymm7
  1da049:	vpcmpeqd %ymm7,%ymm6,%ymm6
  1da04d:	vpxor  %xmm7,%xmm7,%xmm7
  1da051:	vcmpeqps %ymm7,%ymm1,%ymm7
  1da056:	vpcmpeqd %ymm7,%ymm8,%ymm7
  1da05a:	vpor   %ymm7,%ymm6,%ymm6
  1da05e:	vtestps %ymm8,%ymm6
  1da063:	jae    1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1da065:	vmulps %ymm0,%ymm2,%ymm2
  1da069:	vandps %ymm3,%ymm2,%ymm0
  1da06d:	vpsubd %ymm4,%ymm0,%ymm0
  1da071:	vpminud %ymm5,%ymm0,%ymm3
  1da076:	vpcmpeqd %ymm3,%ymm0,%ymm0
  1da07a:	vpxor  %xmm3,%xmm3,%xmm3
  1da07e:	vcmpeqps %ymm3,%ymm2,%ymm3
  1da083:	vpcmpeqd %ymm4,%ymm4,%ymm4
  1da087:	vpcmpeqd %ymm4,%ymm3,%ymm3
  1da08b:	vpor   %ymm3,%ymm0,%ymm0
  1da08f:	vtestps %ymm4,%ymm0
  1da094:	jb     1da214 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x11f4>
  1da09a:	nopw   0x0(%rax,%rax,1)
  1da0a0:	xor    %ebp,%ebp
  1da0a2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1da0b0:	mov    0x1c8(%rsp),%rax
  1da0b8:	vmovss (%rax,%rbp,4),%xmm1
  1da0bd:	vmovaps %xmm1,%xmm0
  1da0c1:	vmovaps 0x1f0(%rsp),%xmm2
  1da0ca:	vfmadd213ss 0x260(%rsp),%xmm2,%xmm0
  1da0d4:	vmovaps 0x1e0(%rsp),%xmm2
  1da0dd:	vfmadd213ss 0x200(%rsp),%xmm2,%xmm1
  1da0e7:	mov    0x1c0(%rsp),%rax
  1da0ef:	mov    (%rax,%rbp,8),%rdi
  1da0f3:	mov    0x1b8(%rsp),%rax
  1da0fb:	vmovss (%rax,%rbp,4),%xmm2
  1da100:	test   %rdi,%rdi
  1da103:	je     1da130 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1110>
  1da105:	vzeroupper
  1da108:	call   *0x6ca6a(%rip)        # 246b78 <_DYNAMIC+0xa50>
  1da10e:	mov    0x1b0(%rsp),%rax
  1da116:	lea    (%rax,%rbp,1),%rdi
  1da11a:	cmp    0x30(%rsp),%rdi
  1da11f:	jb     1da14f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x112f>
  1da121:	jmp    1db619 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x25f9>
  1da126:	cs nopw 0x0(%rax,%rax,1)
  1da130:	vmulss %xmm2,%xmm0,%xmm0
  1da134:	vmulss %xmm2,%xmm1,%xmm1
  1da138:	mov    0x1b0(%rsp),%rax
  1da140:	lea    (%rax,%rbp,1),%rdi
  1da144:	cmp    0x30(%rsp),%rdi
  1da149:	jae    1db619 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x25f9>
  1da14f:	cmp    0x28(%rsp),%rdi
  1da154:	mov    0x40(%rsp),%r9
  1da159:	vmovss -0x1bc891(%rip),%xmm9        # 1d8d0 <__abi_tag+0x1d5d4>
  1da161:	jae    1db604 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x25e4>
  1da167:	vaddss (%r15,%rbp,4),%xmm0,%xmm0
  1da16d:	vaddss (%r12,%rbp,4),%xmm1,%xmm1
  1da173:	vmovd  %xmm1,%eax
  1da177:	vmovd  %xmm0,%ecx
  1da17b:	add    %ecx,%ecx
  1da17d:	add    %eax,%eax
  1da17f:	cmp    $0xff000000,%eax
  1da184:	setb   %al
  1da187:	cmp    $0xfeffffff,%ecx
  1da18d:	ja     1da7a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1780>
  1da193:	test   %al,%al
  1da195:	je     1da7a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1780>
  1da19b:	vmovss %xmm0,(%r15,%rbp,4)
  1da1a1:	vmovss %xmm1,(%r12,%rbp,4)
  1da1a7:	inc    %rbp
  1da1aa:	cmp    $0x8,%rbp
  1da1ae:	jne    1da0b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1090>
  1da1b4:	mov    0x108(%rsp),%rax
  1da1bc:	cmpb   $0x0,(%rax)
  1da1bf:	mov    0x58(%rsp),%rbp
  1da1c4:	je     1da7b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1790>
  1da1ca:	mov    0x130(%rsp),%rax
  1da1d2:	inc    %rax
  1da1d5:	addq   $0x8,0x1b0(%rsp)
  1da1de:	add    $0x20,%r12
  1da1e2:	add    $0x20,%r15
  1da1e6:	addq   $0x20,0x1b8(%rsp)
  1da1ef:	addq   $0x40,0x1c0(%rsp)
  1da1f8:	addq   $0x20,0x1c8(%rsp)
  1da201:	cmp    0xd0(%rsp),%rax
  1da209:	jne    1d9b2a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0xb0a>
  1da20f:	jmp    1d97b4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x794>
  1da214:	mov    0xa0(%rsp),%rax
  1da21c:	lea    (%rax,%rdi,4),%rax
  1da220:	mov    %rax,0x210(%rsp)
  1da228:	vxorps %xmm0,%xmm0,%xmm0
  1da22c:	vmovups %ymm0,0x700(%rsp)
  1da235:	vmovups %ymm0,0x6e0(%rsp)
  1da23e:	vmovups %ymm0,0x6c0(%rsp)
  1da247:	vmovups %ymm0,0x6a0(%rsp)
  1da250:	vmovups %ymm0,0x680(%rsp)
  1da259:	vmovups %ymm0,0x660(%rsp)
  1da262:	vmovups %ymm0,0x640(%rsp)
  1da26b:	vmovups %ymm0,0x620(%rsp)
  1da274:	vmovups %ymm0,0x600(%rsp)
  1da27d:	vmovups %ymm0,0x5e0(%rsp)
  1da286:	vmovups %ymm0,0x5c0(%rsp)
  1da28f:	vmovups %ymm0,0x5a0(%rsp)
  1da298:	vmovups %ymm0,0x580(%rsp)
  1da2a1:	vmovups %ymm0,0x560(%rsp)
  1da2aa:	vmovups %ymm0,0x540(%rsp)
  1da2b3:	vmovups %ymm0,0x520(%rsp)
  1da2bc:	mov    0x6c8c5(%rip),%rsi        # 246b88 <_DYNAMIC+0xa60>
  1da2c3:	mov    0x808(%rsi),%rdx
  1da2ca:	lea    0x620(%rsp),%rax
  1da2d2:	vmovaps %ymm1,%ymm0
  1da2d6:	lea    0x2(%rip),%rcx        # 1da2df <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x12bf>
  1da2dd:	jmp    *%rdx
  1da2df:	mov    0x808(%rsi),%rdx
  1da2e6:	lea    0x520(%rsp),%rax
  1da2ee:	vmovaps %ymm2,%ymm0
  1da2f2:	lea    0x2(%rip),%rcx        # 1da2fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x12db>
  1da2f9:	jmp    *%rdx
  1da2fb:	vbroadcastss -0x1bcd74(%rip),%ymm0        # 1d590 <__abi_tag+0x1d294>
  1da304:	vmovups %ymm0,0x320(%rsp)
  1da30d:	vmovups %ymm0,0x340(%rsp)
  1da316:	vmovups %ymm0,0x360(%rsp)
  1da31f:	vmovups %ymm0,0x380(%rsp)
  1da328:	vmovups %ymm0,0x3a0(%rsp)
  1da331:	vmovups %ymm0,0x3c0(%rsp)
  1da33a:	vmovups %ymm0,0x3e0(%rsp)
  1da343:	vmovups %ymm0,0x400(%rsp)
  1da34c:	vmovups %ymm0,0x420(%rsp)
  1da355:	vmovups %ymm0,0x440(%rsp)
  1da35e:	vmovups %ymm0,0x460(%rsp)
  1da367:	vmovups %ymm0,0x480(%rsp)
  1da370:	vmovups %ymm0,0x4a0(%rsp)
  1da379:	vmovups %ymm0,0x4c0(%rsp)
  1da382:	vmovups %ymm0,0x4e0(%rsp)
  1da38b:	mov    0x98(%rsp),%rax
  1da393:	lea    (%rax,%rdi,4),%rax
  1da397:	mov    %rax,0x118(%rsp)
  1da39f:	vmovups %ymm0,0x500(%rsp)
  1da3a8:	xor    %r8d,%r8d
  1da3ab:	mov    0x78(%rsp),%rsi
  1da3b0:	jmp    1da3f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x13d0>
  1da3b2:	vbroadcastss -0x1bcb93(%rip),%xmm0        # 1d828 <__abi_tag+0x1d52c>
  1da3bb:	vandps %xmm0,%xmm1,%xmm1
  1da3bf:	vmovss %xmm2,0x620(%rsp,%r8,4)
  1da3c9:	vmovss %xmm1,0x520(%rsp,%r8,4)
  1da3d3:	mov    %edi,0x320(%rsp,%r8,4)
  1da3db:	mov    %r10d,0x420(%rsp,%r8,4)
  1da3e3:	inc    %r8
  1da3e6:	cmp    $0x8,%r8
  1da3ea:	je     1da677 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1657>
  1da3f0:	mov    (%rsi,%r8,8),%r11
  1da3f4:	vmovss 0x620(%rsp,%r8,4),%xmm2
  1da3fe:	test   %r11,%r11
  1da401:	jle    1da42d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x140d>
  1da403:	vxorps %xmm0,%xmm0,%xmm0
  1da407:	vucomiss %xmm0,%xmm2
  1da40b:	jne    1da413 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x13f3>
  1da40d:	jnp    1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1da413:	vmovss 0x520(%rsp,%r8,4),%xmm0
  1da41d:	vxorps %xmm1,%xmm1,%xmm1
  1da421:	vucomiss %xmm1,%xmm0
  1da425:	jne    1da42d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x140d>
  1da427:	jnp    1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1da42d:	mov    $0x3f800000,%r10d
  1da433:	vxorps %xmm0,%xmm0,%xmm0
  1da437:	vucomiss %xmm0,%xmm2
  1da43b:	jne    1da557 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1537>
  1da441:	jp     1da557 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1537>
  1da447:	mov    $0x3f800000,%edi
  1da44c:	vmovss 0x520(%rsp,%r8,4),%xmm1
  1da456:	vxorps %xmm0,%xmm0,%xmm0
  1da45a:	vucomiss %xmm0,%xmm1
  1da45e:	jne    1da466 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1446>
  1da460:	jnp    1da3bf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x139f>
  1da466:	vmovd  %xmm1,%ecx
  1da46a:	mov    %ecx,%eax
  1da46c:	and    $0x7f800000,%eax
  1da471:	dec    %eax
  1da473:	cmp    $0x7f7ffffe,%eax
  1da478:	ja     1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1da47e:	mov    %ecx,%eax
  1da480:	shr    $0x17,%eax
  1da483:	movzbl %al,%edx
  1da486:	lea    -0x7f(%rdx),%rax
  1da48a:	add    %r11,%rax
  1da48d:	jo     1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1da493:	and    $0x807fffff,%ecx
  1da499:	or     $0x3f800000,%ecx
  1da49f:	vmovd  %ecx,%xmm1
  1da4a3:	cmp    $0xffffffffffffff82,%rax
  1da4a7:	jge    1da5cd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x15ad>
  1da4ad:	cmp    $0xfffffffffffff000,%rax
  1da4b3:	jb     1da3b2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1392>
  1da4b9:	mov    %rdi,0x50(%rsp)
  1da4be:	lea    (%r11,%rdx,1),%rax
  1da4c2:	add    $0xffffffffffffff03,%rax
  1da4c8:	lea    (%rdx,%r11,1),%edi
  1da4cc:	add    $0xffffff81,%edi
  1da4cf:	vmulss -0x1bc99f(%rip),%xmm1,%xmm1        # 1db38 <__abi_tag+0x1d83c>
  1da4d7:	vxorps %xmm0,%xmm0,%xmm0
  1da4db:	vucomiss %xmm0,%xmm1
  1da4df:	jne    1da4e3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x14c3>
  1da4e1:	jnp    1da54d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x152d>
  1da4e3:	add    $0x7e,%rax
  1da4e7:	add    $0x7e,%edi
  1da4ea:	cmp    $0xffffffffffffff04,%rax
  1da4f0:	jl     1da4cf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x14af>
  1da4f2:	vmovss -0x1bcd2a(%rip),%xmm0        # 1d7d0 <__abi_tag+0x1d4d4>
  1da4fa:	mov    %r8,0x70(%rsp)
  1da4ff:	vmovaps %xmm2,0x1d0(%rsp)
  1da508:	vmovaps %xmm1,0x280(%rsp)
  1da511:	vzeroupper
  1da514:	call   *0x6c606(%rip)        # 246b20 <_DYNAMIC+0x9f8>
  1da51a:	vmovaps 0x280(%rsp),%xmm1
  1da523:	mov    $0x3f800000,%r10d
  1da529:	vmovaps 0x1d0(%rsp),%xmm2
  1da532:	mov    0x70(%rsp),%r8
  1da537:	mov    0x78(%rsp),%rsi
  1da53c:	vmovss -0x1bcc74(%rip),%xmm9        # 1d8d0 <__abi_tag+0x1d5d4>
  1da544:	mov    0x40(%rsp),%r9
  1da549:	vmulss %xmm0,%xmm1,%xmm1
  1da54d:	mov    0x50(%rsp),%rdi
  1da552:	jmp    1da3bf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x139f>
  1da557:	vmovd  %xmm2,%eax
  1da55b:	mov    %eax,%ecx
  1da55d:	and    $0x7f800000,%ecx
  1da563:	dec    %ecx
  1da565:	cmp    $0x7f7ffffe,%ecx
  1da56b:	ja     1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1da571:	mov    %eax,%ecx
  1da573:	shr    $0x17,%ecx
  1da576:	movzbl %cl,%ecx
  1da579:	lea    -0x7f(%rcx),%rdi
  1da57d:	add    %r11,%rdi
  1da580:	jo     1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1da586:	and    $0x807fffff,%eax
  1da58b:	or     $0x3f800000,%eax
  1da590:	vmovd  %eax,%xmm2
  1da594:	cmp    $0xffffffffffffff82,%rdi
  1da598:	jge    1da5b5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1595>
  1da59a:	cmp    $0xfffffffffffff000,%rdi
  1da5a1:	jae    1da5e7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x15c7>
  1da5a3:	vbroadcastss -0x1bcd84(%rip),%xmm0        # 1d828 <__abi_tag+0x1d52c>
  1da5ac:	vandps %xmm0,%xmm2,%xmm2
  1da5b0:	jmp    1da447 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1427>
  1da5b5:	cmp    $0x7f,%rdi
  1da5b9:	jg     1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1da5bf:	shl    $0x17,%edi
  1da5c2:	add    $0x3f800000,%edi
  1da5c8:	jmp    1da44c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x142c>
  1da5cd:	cmp    $0x7f,%rax
  1da5d1:	jg     1da0a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1080>
  1da5d7:	shl    $0x17,%eax
  1da5da:	add    $0x3f800000,%eax
  1da5df:	mov    %eax,%r10d
  1da5e2:	jmp    1da3bf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x139f>
  1da5e7:	lea    (%r11,%rcx,1),%rax
  1da5eb:	add    $0xffffffffffffff03,%rax
  1da5f1:	lea    (%rcx,%r11,1),%edi
  1da5f5:	add    $0xffffff81,%edi
  1da5f8:	vmulss -0x1bcac8(%rip),%xmm2,%xmm2        # 1db38 <__abi_tag+0x1d83c>
  1da600:	vxorps %xmm0,%xmm0,%xmm0
  1da604:	vucomiss %xmm0,%xmm2
  1da608:	jne    1da610 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x15f0>
  1da60a:	jnp    1da447 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1427>
  1da610:	add    $0x7e,%rax
  1da614:	add    $0x7e,%edi
  1da617:	cmp    $0xffffffffffffff04,%rax
  1da61d:	jl     1da5f8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x15d8>
  1da61f:	vmovss -0x1bce57(%rip),%xmm0        # 1d7d0 <__abi_tag+0x1d4d4>
  1da627:	mov    %r8,0x70(%rsp)
  1da62c:	vmovaps %xmm2,0x1d0(%rsp)
  1da635:	mov    %r11,0x50(%rsp)
  1da63a:	vzeroupper
  1da63d:	call   *0x6c4dd(%rip)        # 246b20 <_DYNAMIC+0x9f8>
  1da643:	mov    0x50(%rsp),%r11
  1da648:	mov    $0x3f800000,%r10d
  1da64e:	vmovaps 0x1d0(%rsp),%xmm2
  1da657:	mov    0x70(%rsp),%r8
  1da65c:	mov    0x78(%rsp),%rsi
  1da661:	vmovss -0x1bcd99(%rip),%xmm9        # 1d8d0 <__abi_tag+0x1d5d4>
  1da669:	mov    0x40(%rsp),%r9
  1da66e:	vmulss %xmm0,%xmm2,%xmm2
  1da672:	jmp    1da447 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1427>
  1da677:	mov    0x6c50a(%rip),%rsi        # 246b88 <_DYNAMIC+0xa60>
  1da67e:	mov    0x800(%rsi),%rdx
  1da685:	lea    0x620(%rsp),%rax
  1da68d:	lea    0x2(%rip),%rcx        # 1da696 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1676>
  1da694:	jmp    *%rdx
  1da696:	vmovaps %ymm0,%ymm2
  1da69a:	mov    0x800(%rsi),%rdx
  1da6a1:	lea    0x320(%rsp),%rax
  1da6a9:	lea    0x2(%rip),%rcx        # 1da6b2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1692>
  1da6b0:	jmp    *%rdx
  1da6b2:	vmulps %ymm0,%ymm2,%ymm3
  1da6b6:	mov    0x800(%rsi),%rdx
  1da6bd:	lea    0x520(%rsp),%rax
  1da6c5:	lea    0x2(%rip),%rcx        # 1da6ce <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x16ae>
  1da6cc:	jmp    *%rdx
  1da6ce:	vmovaps %ymm0,%ymm2
  1da6d2:	mov    0x800(%rsi),%rdx
  1da6d9:	lea    0x420(%rsp),%rax
  1da6e1:	lea    0x2(%rip),%rcx        # 1da6ea <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x16ca>
  1da6e8:	jmp    *%rdx
  1da6ea:	vmovaps %ymm0,%ymm4
  1da6ee:	mov    0x800(%rsi),%rdx
  1da6f5:	mov    0x210(%rsp),%rdi
  1da6fd:	mov    %rdi,%rax
  1da700:	lea    0x2(%rip),%rcx        # 1da709 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x16e9>
  1da707:	jmp    *%rdx
  1da709:	vaddps %ymm0,%ymm3,%ymm3
  1da70d:	mov    0x800(%rsi),%rdx
  1da714:	mov    0x118(%rsp),%rax
  1da71c:	lea    0x2(%rip),%rcx        # 1da725 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1705>
  1da723:	jmp    *%rdx
  1da725:	vpaddd %ymm3,%ymm3,%ymm5
  1da729:	vpbroadcastd -0x1bd1aa(%rip),%ymm1        # 1d588 <__abi_tag+0x1d28c>
  1da732:	vpminud %ymm1,%ymm5,%ymm6
  1da737:	vpxor  %ymm6,%ymm5,%ymm5
  1da73b:	vptest %ymm5,%ymm5
  1da740:	jne    1da7a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1780>
  1da742:	vmulps %ymm4,%ymm2,%ymm2
  1da746:	vaddps %ymm0,%ymm2,%ymm2
  1da74a:	vpaddd %ymm2,%ymm2,%ymm0
  1da74e:	vpminud %ymm1,%ymm0,%ymm1
  1da753:	vpxor  %ymm1,%ymm0,%ymm0
  1da757:	vptest %ymm0,%ymm0
  1da75c:	jne    1da7a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1780>
  1da75e:	mov    0x6c423(%rip),%rsi        # 246b88 <_DYNAMIC+0xa60>
  1da765:	mov    0x808(%rsi),%rdx
  1da76c:	mov    %rdi,%rax
  1da76f:	vmovaps %ymm3,%ymm0
  1da773:	lea    0x2(%rip),%rcx        # 1da77c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x175c>
  1da77a:	jmp    *%rdx
  1da77c:	mov    0x808(%rsi),%rdx
  1da783:	mov    0x118(%rsp),%rax
  1da78b:	vmovaps %ymm2,%ymm0
  1da78f:	lea    0x2(%rip),%rcx        # 1da798 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1778>
  1da796:	jmp    *%rdx
  1da798:	jmp    1da1ca <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x11aa>
  1da79d:	nopl   (%rax)
  1da7a0:	mov    0x108(%rsp),%rax
  1da7a8:	movb   $0x0,(%rax)
  1da7ab:	mov    0x58(%rsp),%rbp
  1da7b0:	mov    0x60(%rsp),%r10
  1da7b5:	mov    0x1a0(%rsp),%r11
  1da7bd:	mov    0x240(%rsp),%r15
  1da7c5:	mov    0x198(%rsp),%r12
  1da7cd:	mov    0x68(%rsp),%rsi
  1da7d2:	mov    0x80(%rsp),%r8
  1da7da:	lea    0x2(%r8),%rax
  1da7de:	cmp    0xd8(%rsp),%rax
  1da7e6:	mov    0xf8(%rsp),%rdi
  1da7ee:	ja     1d93a7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x387>
  1da7f4:	mov    0x1a8(%rsp),%rcx
  1da7fc:	cmp    0xc8(%rsp),%rcx
  1da804:	je     1db65e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x263e>
  1da80a:	cmp    0xc0(%rsp),%rcx
  1da812:	je     1db643 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2623>
  1da818:	mov    0x190(%rsp),%rax
  1da820:	vbroadcastss (%rax,%rcx,4),%ymm0
  1da826:	mov    0x188(%rsp),%rax
  1da82e:	vbroadcastss (%rax,%rcx,4),%ymm1
  1da834:	cmp    $0x8,%r10
  1da838:	mov    0xe0(%rsp),%rdx
  1da840:	jb     1da8f6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x18d6>
  1da846:	cmpq   $0x1,0xd0(%rsp)
  1da84f:	jne    1da860 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1840>
  1da851:	xor    %eax,%eax
  1da853:	jmp    1da8cc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x18ac>
  1da855:	data16 cs nopw 0x0(%rax,%rax,1)
  1da860:	mov    $0x20,%ecx
  1da865:	xor    %eax,%eax
  1da867:	nopw   0x0(%rax,%rax,1)
  1da870:	vmovups -0x20(%rdx,%rcx,1),%ymm2
  1da876:	vmulps %ymm2,%ymm2,%ymm2
  1da87a:	vfmadd213ps %ymm1,%ymm0,%ymm2
  1da87f:	vmovups -0x20(%r14,%rcx,1),%ymm3
  1da886:	vfmadd213ps -0x20(%rdi,%rcx,1),%ymm2,%ymm3
  1da88d:	vmovups %ymm3,-0x20(%r13,%rcx,1)
  1da894:	add    $0x2,%rax
  1da898:	vmovups (%rdx,%rcx,1),%ymm2
  1da89d:	vmulps %ymm2,%ymm2,%ymm2
  1da8a1:	vfmadd213ps %ymm1,%ymm0,%ymm2
  1da8a6:	vmovups (%r14,%rcx,1),%ymm3
  1da8ac:	vfmadd213ps (%rdi,%rcx,1),%ymm2,%ymm3
  1da8b2:	vmovups %ymm3,0x0(%r13,%rcx,1)
  1da8b9:	add    $0x40,%rcx
  1da8bd:	cmp    %rax,%rsi
  1da8c0:	jne    1da870 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1850>
  1da8c2:	testb  $0x8,0x180(%rsp)
  1da8ca:	je     1da8f6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x18d6>
  1da8cc:	shl    $0x5,%rax
  1da8d0:	mov    0x20(%rsp),%rcx
  1da8d5:	vmovups (%rcx,%rax,1),%ymm2
  1da8da:	vmulps %ymm2,%ymm2,%ymm2
  1da8de:	vfmadd213ps %ymm1,%ymm0,%ymm2
  1da8e3:	vmovups (%r14,%rax,1),%ymm3
  1da8e9:	vfmadd213ps (%rdi,%rax,1),%ymm2,%ymm3
  1da8ef:	vmovups %ymm3,0x0(%r13,%rax,1)
  1da8f6:	cmpq   $0x0,0x38(%rsp)
  1da8fc:	je     1daa70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1a50>
  1da902:	mov    0x20(%rsp),%rax
  1da907:	mov    (%rsp),%rcx
  1da90b:	vmovss (%rax,%rcx,4),%xmm2
  1da910:	vmulss %xmm2,%xmm2,%xmm2
  1da914:	vfmadd213ss %xmm1,%xmm0,%xmm2
  1da919:	vmovss (%r14,%rcx,4),%xmm3
  1da91f:	vfmadd213ss (%rdi,%rcx,4),%xmm2,%xmm3
  1da925:	vmovss %xmm3,0x0(%r13,%rcx,4)
  1da92c:	cmp    $0x1,%r15d
  1da930:	je     1daa70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1a50>
  1da936:	mov    0x20(%rsp),%rax
  1da93b:	mov    (%rsp),%rcx
  1da93f:	vmovss 0x4(%rax,%rcx,4),%xmm2
  1da945:	vmulss %xmm2,%xmm2,%xmm2
  1da949:	vfmadd213ss %xmm1,%xmm0,%xmm2
  1da94e:	vmovss 0x4(%r14,%rcx,4),%xmm3
  1da955:	vfmadd213ss 0x4(%rdi,%rcx,4),%xmm2,%xmm3
  1da95c:	vmovss %xmm3,0x4(%r13,%rcx,4)
  1da963:	cmp    $0x2,%r15d
  1da967:	je     1daa70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1a50>
  1da96d:	mov    0x20(%rsp),%rax
  1da972:	mov    (%rsp),%rcx
  1da976:	vmovss 0x8(%rax,%rcx,4),%xmm2
  1da97c:	vmulss %xmm2,%xmm2,%xmm2
  1da980:	vfmadd213ss %xmm1,%xmm0,%xmm2
  1da985:	vmovss 0x8(%r14,%rcx,4),%xmm3
  1da98c:	vfmadd213ss 0x8(%rdi,%rcx,4),%xmm2,%xmm3
  1da993:	vmovss %xmm3,0x8(%r13,%rcx,4)
  1da99a:	cmp    $0x3,%r15d
  1da99e:	je     1daa70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1a50>
  1da9a4:	mov    0x20(%rsp),%rax
  1da9a9:	mov    (%rsp),%rcx
  1da9ad:	vmovss 0xc(%rax,%rcx,4),%xmm2
  1da9b3:	vmulss %xmm2,%xmm2,%xmm2
  1da9b7:	vfmadd213ss %xmm1,%xmm0,%xmm2
  1da9bc:	vmovss 0xc(%r14,%rcx,4),%xmm3
  1da9c3:	vfmadd213ss 0xc(%rdi,%rcx,4),%xmm2,%xmm3
  1da9ca:	vmovss %xmm3,0xc(%r13,%rcx,4)
  1da9d1:	cmp    $0x4,%r15d
  1da9d5:	je     1daa70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1a50>
  1da9db:	mov    0x20(%rsp),%rax
  1da9e0:	mov    (%rsp),%rcx
  1da9e4:	vmovss 0x10(%rax,%rcx,4),%xmm2
  1da9ea:	vmulss %xmm2,%xmm2,%xmm2
  1da9ee:	vfmadd213ss %xmm1,%xmm0,%xmm2
  1da9f3:	vmovss 0x10(%r14,%rcx,4),%xmm3
  1da9fa:	vfmadd213ss 0x10(%rdi,%rcx,4),%xmm2,%xmm3
  1daa01:	vmovss %xmm3,0x10(%r13,%rcx,4)
  1daa08:	cmp    $0x5,%r15d
  1daa0c:	je     1daa70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1a50>
  1daa0e:	mov    0x20(%rsp),%rax
  1daa13:	mov    (%rsp),%rcx
  1daa17:	vmovss 0x14(%rax,%rcx,4),%xmm2
  1daa1d:	vmulss %xmm2,%xmm2,%xmm2
  1daa21:	vfmadd213ss %xmm1,%xmm0,%xmm2
  1daa26:	vmovss 0x14(%r14,%rcx,4),%xmm3
  1daa2d:	vfmadd213ss 0x14(%rdi,%rcx,4),%xmm2,%xmm3
  1daa34:	vmovss %xmm3,0x14(%r13,%rcx,4)
  1daa3b:	cmp    $0x6,%r15d
  1daa3f:	je     1daa70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1a50>
  1daa41:	mov    0x20(%rsp),%rax
  1daa46:	mov    (%rsp),%rcx
  1daa4a:	vmovss 0x18(%rax,%rcx,4),%xmm2
  1daa50:	vmulss %xmm2,%xmm2,%xmm2
  1daa54:	vfmadd213ss %xmm1,%xmm0,%xmm2
  1daa59:	vmovss 0x18(%r14,%rcx,4),%xmm0
  1daa60:	vfmadd213ss 0x18(%rdi,%rcx,4),%xmm2,%xmm0
  1daa67:	vmovss %xmm0,0x18(%r13,%rcx,4)
  1daa6e:	xchg   %ax,%ax
  1daa70:	test   $0x1,%bl
  1daa73:	vmovss -0x1bd03b(%rip),%xmm3        # 1da40 <__abi_tag+0x1d744>
  1daa7b:	je     1db100 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20e0>
  1daa81:	cmpq   $0x0,0xd0(%rsp)
  1daa8a:	je     1dab37 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1b17>
  1daa90:	mov    0xd0(%rsp),%rax
  1daa98:	xor    %ecx,%ecx
  1daa9a:	nopw   0x0(%rax,%rax,1)
  1daaa0:	vbroadcastss -0x1bcf79(%rip),%ymm0        # 1db30 <__abi_tag+0x1d834>
  1daaa9:	vandps (%r14,%rcx,1),%ymm0,%ymm1
  1daaaf:	vandps 0x0(%r13,%rcx,1),%ymm0,%ymm0
  1daab6:	vcmpeqps %ymm0,%ymm0,%ymm2
  1daabb:	vmaxps %ymm0,%ymm1,%ymm3
  1daabf:	vblendvps %ymm2,%ymm3,%ymm1,%ymm2
  1daac5:	vcmpeqps %ymm1,%ymm1,%ymm1
  1daaca:	vblendvps %ymm1,%ymm2,%ymm0,%ymm0
  1daad0:	vbroadcastss -0x1bd1a9(%rip),%ymm4        # 1d930 <__abi_tag+0x1d634>
  1daad9:	vcmple_oqps %ymm4,%ymm0,%ymm1
  1daade:	vxorps %xmm3,%xmm3,%xmm3
  1daae2:	vcmpeqps %ymm3,%ymm0,%ymm2
  1daae7:	vblendvps %ymm2,%ymm4,%ymm0,%ymm0
  1daaed:	vpcmpgtd %ymm1,%ymm3,%ymm1
  1daaf1:	vmovss -0x1bd0b9(%rip),%xmm3        # 1da40 <__abi_tag+0x1d744>
  1daaf9:	vpand  %ymm0,%ymm1,%ymm0
  1daafd:	vextracti128 $0x1,%ymm0,%xmm1
  1dab03:	vminps %xmm1,%xmm0,%xmm0
  1dab07:	vshufpd $0x3,%xmm0,%xmm0,%xmm1
  1dab0c:	vminps %xmm1,%xmm0,%xmm0
  1dab10:	vmovshdup %xmm0,%xmm1
  1dab14:	vminss %xmm1,%xmm0,%xmm0
  1dab18:	vmovss -0x1bd028(%rip),%xmm1        # 1daf8 <__abi_tag+0x1d7fc>
  1dab20:	vucomiss %xmm0,%xmm1
  1dab24:	ja     1db100 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20e0>
  1dab2a:	add    $0x20,%rcx
  1dab2e:	dec    %rax
  1dab31:	jne    1daaa0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1a80>
  1dab37:	mov    $0x1,%bl
  1dab39:	cmpq   $0x0,0x38(%rsp)
  1dab3f:	je     1d9670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x650>
  1dab45:	mov    (%rsp),%rax
  1dab49:	vmovss (%r14,%rax,4),%xmm0
  1dab4f:	vbroadcastss -0x1bd028(%rip),%xmm2        # 1db30 <__abi_tag+0x1d834>
  1dab58:	vandps %xmm2,%xmm0,%xmm0
  1dab5c:	vmovss 0x0(%r13,%rax,4),%xmm1
  1dab63:	vandps %xmm2,%xmm1,%xmm1
  1dab67:	vmaxss %xmm1,%xmm0,%xmm2
  1dab6b:	vcmpunordss %xmm1,%xmm1,%xmm1
  1dab70:	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  1dab76:	vmovss -0x1bd24e(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1dab7e:	vucomiss %xmm0,%xmm1
  1dab82:	jb     1db0ec <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20cc>
  1dab88:	vmovss -0x1bd098(%rip),%xmm1        # 1daf8 <__abi_tag+0x1d7fc>
  1dab90:	vcmpnless %xmm0,%xmm1,%xmm1
  1dab95:	vxorps %xmm2,%xmm2,%xmm2
  1dab99:	vcmpneqss %xmm2,%xmm0,%xmm0
  1dab9e:	vandps %xmm1,%xmm0,%xmm0
  1daba2:	vmovd  %xmm0,%ecx
  1daba6:	mov    $0x0,%eax
  1dabab:	test   $0x1,%cl
  1dabae:	jne    1db0ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20ce>
  1dabb4:	cmpl   $0x1,0x38(%rsp)
  1dabb9:	je     1d9670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x650>
  1dabbf:	mov    (%rsp),%rax
  1dabc3:	vmovss 0x4(%r14,%rax,4),%xmm0
  1dabca:	vbroadcastss -0x1bd0a3(%rip),%xmm2        # 1db30 <__abi_tag+0x1d834>
  1dabd3:	vandps %xmm2,%xmm0,%xmm0
  1dabd7:	vmovss 0x4(%r13,%rax,4),%xmm1
  1dabde:	vandps %xmm2,%xmm1,%xmm1
  1dabe2:	vmaxss %xmm1,%xmm0,%xmm2
  1dabe6:	vcmpunordss %xmm1,%xmm1,%xmm1
  1dabeb:	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  1dabf1:	vmovss -0x1bd2c9(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1dabf9:	vucomiss %xmm0,%xmm1
  1dabfd:	mov    $0x1,%eax
  1dac02:	jb     1db0ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20ce>
  1dac08:	vmovss -0x1bd118(%rip),%xmm1        # 1daf8 <__abi_tag+0x1d7fc>
  1dac10:	vcmpnless %xmm0,%xmm1,%xmm1
  1dac15:	vxorps %xmm2,%xmm2,%xmm2
  1dac19:	vcmpneqss %xmm2,%xmm0,%xmm0
  1dac1e:	vandps %xmm1,%xmm0,%xmm0
  1dac22:	vmovd  %xmm0,%ecx
  1dac26:	test   $0x1,%cl
  1dac29:	jne    1db0ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20ce>
  1dac2f:	cmpl   $0x2,0x38(%rsp)
  1dac34:	je     1d9670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x650>
  1dac3a:	mov    (%rsp),%rax
  1dac3e:	vmovss 0x8(%r14,%rax,4),%xmm0
  1dac45:	vbroadcastss -0x1bd11e(%rip),%xmm2        # 1db30 <__abi_tag+0x1d834>
  1dac4e:	vandps %xmm2,%xmm0,%xmm0
  1dac52:	vmovss 0x8(%r13,%rax,4),%xmm1
  1dac59:	vandps %xmm2,%xmm1,%xmm1
  1dac5d:	vmaxss %xmm1,%xmm0,%xmm2
  1dac61:	vcmpunordss %xmm1,%xmm1,%xmm1
  1dac66:	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  1dac6c:	vmovss -0x1bd344(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1dac74:	vucomiss %xmm0,%xmm1
  1dac78:	mov    $0x2,%eax
  1dac7d:	jb     1db0ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20ce>
  1dac83:	vmovss -0x1bd193(%rip),%xmm1        # 1daf8 <__abi_tag+0x1d7fc>
  1dac8b:	vcmpnless %xmm0,%xmm1,%xmm1
  1dac90:	vxorps %xmm2,%xmm2,%xmm2
  1dac94:	vcmpneqss %xmm2,%xmm0,%xmm0
  1dac99:	vandps %xmm1,%xmm0,%xmm0
  1dac9d:	vmovd  %xmm0,%ecx
  1daca1:	test   $0x1,%cl
  1daca4:	jne    1db0ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20ce>
  1dacaa:	cmpl   $0x3,0x38(%rsp)
  1dacaf:	je     1d9670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x650>
  1dacb5:	mov    (%rsp),%rax
  1dacb9:	vmovss 0xc(%r14,%rax,4),%xmm0
  1dacc0:	vbroadcastss -0x1bd199(%rip),%xmm2        # 1db30 <__abi_tag+0x1d834>
  1dacc9:	vandps %xmm2,%xmm0,%xmm0
  1daccd:	vmovss 0xc(%r13,%rax,4),%xmm1
  1dacd4:	vandps %xmm2,%xmm1,%xmm1
  1dacd8:	vmaxss %xmm1,%xmm0,%xmm2
  1dacdc:	vcmpunordss %xmm1,%xmm1,%xmm1
  1dace1:	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  1dace7:	vmovss -0x1bd3bf(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1dacef:	vucomiss %xmm0,%xmm1
  1dacf3:	mov    $0x3,%eax
  1dacf8:	jb     1db0ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20ce>
  1dacfe:	vmovss -0x1bd20e(%rip),%xmm1        # 1daf8 <__abi_tag+0x1d7fc>
  1dad06:	vcmpnless %xmm0,%xmm1,%xmm1
  1dad0b:	vxorps %xmm2,%xmm2,%xmm2
  1dad0f:	vcmpneqss %xmm2,%xmm0,%xmm0
  1dad14:	vandps %xmm1,%xmm0,%xmm0
  1dad18:	vmovd  %xmm0,%ecx
  1dad1c:	test   $0x1,%cl
  1dad1f:	jne    1db0ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20ce>
  1dad25:	cmpl   $0x4,0x38(%rsp)
  1dad2a:	je     1d9670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x650>
  1dad30:	mov    (%rsp),%rax
  1dad34:	vmovss 0x10(%r14,%rax,4),%xmm0
  1dad3b:	vbroadcastss -0x1bd214(%rip),%xmm2        # 1db30 <__abi_tag+0x1d834>
  1dad44:	vandps %xmm2,%xmm0,%xmm0
  1dad48:	vmovss 0x10(%r13,%rax,4),%xmm1
  1dad4f:	vandps %xmm2,%xmm1,%xmm1
  1dad53:	vmaxss %xmm1,%xmm0,%xmm2
  1dad57:	vcmpunordss %xmm1,%xmm1,%xmm1
  1dad5c:	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  1dad62:	vmovss -0x1bd43a(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1dad6a:	vucomiss %xmm0,%xmm1
  1dad6e:	mov    $0x4,%eax
  1dad73:	jb     1db0ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20ce>
  1dad79:	vmovss -0x1bd289(%rip),%xmm1        # 1daf8 <__abi_tag+0x1d7fc>
  1dad81:	vcmpnless %xmm0,%xmm1,%xmm1
  1dad86:	vxorps %xmm2,%xmm2,%xmm2
  1dad8a:	vcmpneqss %xmm2,%xmm0,%xmm0
  1dad8f:	vandps %xmm1,%xmm0,%xmm0
  1dad93:	vmovd  %xmm0,%ecx
  1dad97:	test   $0x1,%cl
  1dad9a:	jne    1db0ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20ce>
  1dada0:	cmpl   $0x5,0x38(%rsp)
  1dada5:	je     1d9670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x650>
  1dadab:	mov    (%rsp),%rax
  1dadaf:	vmovss 0x14(%r14,%rax,4),%xmm0
  1dadb6:	vbroadcastss -0x1bd28f(%rip),%xmm2        # 1db30 <__abi_tag+0x1d834>
  1dadbf:	vandps %xmm2,%xmm0,%xmm0
  1dadc3:	vmovss 0x14(%r13,%rax,4),%xmm1
  1dadca:	vandps %xmm2,%xmm1,%xmm1
  1dadce:	vmaxss %xmm1,%xmm0,%xmm2
  1dadd2:	vcmpunordss %xmm1,%xmm1,%xmm1
  1dadd7:	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  1daddd:	vmovss -0x1bd4b5(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1dade5:	vucomiss %xmm0,%xmm1
  1dade9:	mov    $0x5,%eax
  1dadee:	jb     1db0ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20ce>
  1dadf4:	vmovss -0x1bd304(%rip),%xmm1        # 1daf8 <__abi_tag+0x1d7fc>
  1dadfc:	vcmpnless %xmm0,%xmm1,%xmm1
  1dae01:	vxorps %xmm2,%xmm2,%xmm2
  1dae05:	vcmpneqss %xmm2,%xmm0,%xmm0
  1dae0a:	vandps %xmm1,%xmm0,%xmm0
  1dae0e:	vmovd  %xmm0,%ecx
  1dae12:	test   $0x1,%cl
  1dae15:	jne    1db0ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20ce>
  1dae1b:	cmpl   $0x6,0x38(%rsp)
  1dae20:	je     1d9670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x650>
  1dae26:	mov    (%rsp),%rax
  1dae2a:	vmovss 0x18(%r14,%rax,4),%xmm0
  1dae31:	vbroadcastss -0x1bd30a(%rip),%xmm2        # 1db30 <__abi_tag+0x1d834>
  1dae3a:	vandps %xmm2,%xmm0,%xmm0
  1dae3e:	vmovss 0x18(%r13,%rax,4),%xmm1
  1dae45:	vandps %xmm2,%xmm1,%xmm1
  1dae49:	vmaxss %xmm1,%xmm0,%xmm2
  1dae4d:	vcmpunordss %xmm1,%xmm1,%xmm1
  1dae52:	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  1dae58:	vmovss -0x1bd530(%rip),%xmm1        # 1d930 <__abi_tag+0x1d634>
  1dae60:	vucomiss %xmm0,%xmm1
  1dae64:	mov    $0x6,%eax
  1dae69:	jb     1db0ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20ce>
  1dae6f:	vmovss -0x1bd37f(%rip),%xmm1        # 1daf8 <__abi_tag+0x1d7fc>
  1dae77:	vcmpnless %xmm0,%xmm1,%xmm1
  1dae7c:	vxorps %xmm2,%xmm2,%xmm2
  1dae80:	vcmpneqss %xmm2,%xmm0,%xmm0
  1dae85:	vandps %xmm1,%xmm0,%xmm0
  1dae89:	vmovd  %xmm0,%ecx
  1dae8d:	test   $0x1,%cl
  1dae90:	je     1d9670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x650>
  1dae96:	jmp    1db0ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x20ce>
  1dae9b:	movq   $0x0,0x18(%rsp)
  1daea4:	jmp    1d96cc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x6ac>
  1daea9:	mov    0xf8(%rsp),%rax
  1daeb1:	vmovups (%rax),%ymm4
  1daeb5:	vmovups (%r14),%ymm3
  1daeba:	vbroadcastss -0x1bd393(%rip),%ymm13        # 1db30 <__abi_tag+0x1d834>
  1daec3:	vandps %ymm4,%ymm13,%ymm0
  1daec7:	vandps %ymm3,%ymm13,%ymm1
  1daecb:	vbroadcastss -0x1bd5a4(%rip),%ymm8        # 1d930 <__abi_tag+0x1d634>
  1daed4:	vcmple_oqps %ymm8,%ymm0,%ymm5
  1daeda:	vxorps %xmm7,%xmm7,%xmm7
  1daede:	vcmpeqps %ymm7,%ymm0,%ymm6
  1daee3:	vbroadcastss -0x1bd3f4(%rip),%ymm2        # 1daf8 <__abi_tag+0x1d7fc>
  1daeec:	vcmpge_oqps %ymm2,%ymm0,%ymm0
  1daef1:	vorps  %ymm6,%ymm0,%ymm0
  1daef5:	vcmple_oqps %ymm8,%ymm1,%ymm6
  1daefb:	vandps %ymm6,%ymm5,%ymm5
  1daeff:	vandps %ymm5,%ymm0,%ymm0
  1daf03:	vcmpeqps %ymm7,%ymm1,%ymm5
  1daf08:	vcmpge_oqps %ymm2,%ymm1,%ymm1
  1daf0d:	vorps  %ymm5,%ymm1,%ymm1
  1daf11:	vandps %ymm1,%ymm0,%ymm0
  1daf15:	vpcmpeqd %ymm1,%ymm1,%ymm1
  1daf19:	vptest %ymm1,%ymm0
  1daf1e:	mov    0x68(%rsp),%rsi
  1daf23:	jae    1d96c5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x6a5>
  1daf29:	mov    %r8,0x80(%rsp)
  1daf31:	mov    0xa0(%rsp),%rax
  1daf39:	mov    0x8(%rsp),%rcx
  1daf3e:	vmovups (%rax,%rcx,4),%ymm1
  1daf43:	mov    0x98(%rsp),%rax
  1daf4b:	vmovups (%rax,%rcx,4),%ymm0
  1daf50:	cmp    %rdi,0x88(%rsp)
  1daf58:	jbe    1db293 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2273>
  1daf5e:	mov    0x20(%rsp),%rax
  1daf63:	vmovups (%rax),%ymm15
  1daf67:	vmulps %ymm15,%ymm15,%ymm5
  1daf6c:	vmovups %ymm5,0x260(%rsp)
  1daf75:	mov    0xb0(%rsp),%rcx
  1daf7d:	cmp    %rdi,%rcx
  1daf80:	mov    %rdi,%rax
  1daf83:	cmova  %rcx,%rax
  1daf87:	mov    0xa8(%rsp),%rdx
  1daf8f:	cmp    %rdi,%rdx
  1daf92:	mov    %rdi,%rcx
  1daf95:	cmova  %rdx,%rcx
  1daf99:	jmp    1dafdb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1fbb>
  1daf9b:	nopl   0x0(%rax,%rax,1)
  1dafa0:	vmovaps %ymm3,%ymm11
  1dafa4:	mov    0x68(%rsp),%rsi
  1dafa9:	vfmadd213ps %ymm9,%ymm15,%ymm7
  1dafae:	vfmadd213ps %ymm10,%ymm15,%ymm8
  1dafb3:	vfmadd231ps %ymm7,%ymm3,%ymm1
  1dafb8:	vfmadd231ps %ymm8,%ymm3,%ymm0
  1dafbd:	mov    %rdx,%rdi
  1dafc0:	vmovaps %ymm11,%ymm3
  1dafc4:	cmp    %rdx,0x88(%rsp)
  1dafcc:	vbroadcastss -0x1bd6fd(%rip),%xmm6        # 1d8d8 <__abi_tag+0x1d5dc>
  1dafd5:	je     1db29c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x227c>
  1dafdb:	cmp    %rdi,%rax
  1dafde:	je     1db6d9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x26b9>
  1dafe4:	cmp    %rdi,%rcx
  1dafe7:	je     1db6be <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x269e>
  1dafed:	lea    0x1(%rdi),%rdx
  1daff1:	mov    0x170(%rsp),%r8
  1daff9:	vbroadcastss (%r8,%rdi,8),%ymm7
  1dafff:	mov    0x178(%rsp),%rsi
  1db007:	vbroadcastss (%rsi,%rdi,8),%ymm9
  1db00d:	vbroadcastss -0x4(%r8,%rdx,8),%ymm8
  1db014:	vbroadcastss -0x4(%rsi,%rdx,8),%ymm10
  1db01b:	cmp    0x88(%rsp),%rdx
  1db023:	jae    1dafa0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1f80>
  1db029:	cmp    0xc8(%rsp),%rdi
  1db031:	jae    1db6f4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x26d4>
  1db037:	cmp    0xc0(%rsp),%rdi
  1db03f:	jae    1db70c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x26ec>
  1db045:	mov    0x190(%rsp),%rsi
  1db04d:	vbroadcastss (%rsi,%rdi,4),%ymm12
  1db053:	mov    0x188(%rsp),%rsi
  1db05b:	vbroadcastss (%rsi,%rdi,4),%ymm11
  1db061:	vfmadd231ps 0x260(%rsp),%ymm12,%ymm11
  1db06b:	vfmadd213ps %ymm4,%ymm3,%ymm11
  1db070:	vandps %ymm3,%ymm13,%ymm4
  1db074:	vandps %ymm13,%ymm11,%ymm12
  1db079:	vmovaps %ymm13,%ymm5
  1db07d:	vbroadcastss -0x1bd756(%rip),%ymm6        # 1d930 <__abi_tag+0x1d634>
  1db086:	vcmple_oqps %ymm6,%ymm4,%ymm13
  1db08b:	vxorps %xmm2,%xmm2,%xmm2
  1db08f:	vcmpeqps %ymm2,%ymm4,%ymm14
  1db094:	vbroadcastss -0x1bd5a5(%rip),%ymm2        # 1daf8 <__abi_tag+0x1d7fc>
  1db09d:	vcmpge_oqps %ymm2,%ymm4,%ymm4
  1db0a2:	vorps  %ymm4,%ymm14,%ymm4
  1db0a6:	vandps %ymm4,%ymm13,%ymm4
  1db0aa:	vcmple_oqps %ymm6,%ymm12,%ymm13
  1db0af:	vandps %ymm4,%ymm13,%ymm4
  1db0b3:	vxorps %xmm6,%xmm6,%xmm6
  1db0b7:	vcmpeqps %ymm6,%ymm12,%ymm13
  1db0bc:	vcmpge_oqps %ymm2,%ymm12,%ymm12
  1db0c1:	vorps  %ymm13,%ymm12,%ymm12
  1db0c6:	vmovaps %ymm5,%ymm13
  1db0ca:	vandps %ymm4,%ymm12,%ymm4
  1db0ce:	vpcmpeqd %ymm12,%ymm12,%ymm12
  1db0d3:	vptest %ymm12,%ymm4
  1db0d8:	vmovaps %ymm3,%ymm4
  1db0dc:	mov    0x68(%rsp),%rsi
  1db0e1:	jb     1dafa9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x1f89>
  1db0e7:	jmp    1db35b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x233b>
  1db0ec:	xor    %eax,%eax
  1db0ee:	cmp    0x38(%rsp),%eax
  1db0f2:	jae    1d9670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x650>
  1db0f8:	nopl   0x0(%rax,%rax,1)
  1db100:	mov    $0x1,%bl
  1db102:	cmp    0x8(%rsp),%r11
  1db107:	je     1d9670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x650>
  1db10d:	xor    %eax,%eax
  1db10f:	jmp    1db175 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2155>
  1db111:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1db120:	mov    %rcx,(%r9,%rax,8)
  1db124:	vmovss %xmm2,(%r14,%rax,4)
  1db12a:	vmovss %xmm0,0x0(%r13,%rax,4)
  1db131:	mov    0xf8(%rsp),%rdi
  1db139:	cmpq   $0x0,(%r9,%rax,8)
  1db13e:	lea    0x1(%rax),%rax
  1db142:	sete   %cl
  1db145:	cmp    $0x53800001,%edx
  1db14b:	setb   %sil
  1db14f:	add    $0xd4800000,%edx
  1db155:	cmp    $0xd4800001,%edx
  1db15b:	setb   %dl
  1db15e:	and    %cl,%sil
  1db161:	and    %dl,%sil
  1db164:	and    %sil,%bl
  1db167:	cmp    %r12,%rax
  1db16a:	mov    0x68(%rsp),%rsi
  1db16f:	je     1d9670 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x650>
  1db175:	mov    (%r14,%rax,4),%edx
  1db179:	vmovd  %edx,%xmm0
  1db17d:	and    $0x7fffffff,%edx
  1db183:	mov    0x0(%r13,%rax,4),%ecx
  1db188:	vmovd  %ecx,%xmm1
  1db18c:	and    $0x7fffffff,%ecx
  1db192:	cmp    %edx,%ecx
  1db194:	cmovbe %edx,%ecx
  1db197:	cmp    $0x53800001,%ecx
  1db19d:	jb     1db1f0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x21d0>
  1db19f:	mov    (%r9,%rax,8),%rsi
  1db1a3:	vmulss %xmm3,%xmm0,%xmm0
  1db1a7:	vmulss %xmm3,%xmm1,%xmm1
  1db1ab:	add    $0x50,%rsi
  1db1af:	jo     1db3ab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x238b>
  1db1b5:	vmovd  %ecx,%xmm2
  1db1b9:	nopl   0x0(%rax)
  1db1c0:	mov    %rsi,%rdi
  1db1c3:	vmulss %xmm3,%xmm2,%xmm2
  1db1c7:	vmovd  %xmm2,%ecx
  1db1cb:	mov    %ecx,%edx
  1db1cd:	and    $0x7fffffff,%edx
  1db1d3:	cmp    $0x53800000,%edx
  1db1d9:	jbe    1db210 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x21f0>
  1db1db:	vmulss %xmm3,%xmm0,%xmm0
  1db1df:	vmulss %xmm3,%xmm1,%xmm1
  1db1e3:	add    $0x50,%rsi
  1db1e7:	jno    1db1c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x21a0>
  1db1e9:	jmp    1db3a7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2387>
  1db1ee:	xchg   %ax,%ax
  1db1f0:	mov    %ecx,%edx
  1db1f2:	lea    -0x1(%rdx),%esi
  1db1f5:	cmp    $0x2b7ffffe,%esi
  1db1fb:	ja     1db139 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2119>
  1db201:	jmp    1db238 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2218>
  1db203:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1db210:	mov    %rdi,(%r9,%rax,8)
  1db214:	vmovss %xmm0,(%r14,%rax,4)
  1db21a:	vmovss %xmm1,0x0(%r13,%rax,4)
  1db221:	mov    0xf8(%rsp),%rdi
  1db229:	lea    -0x1(%rdx),%esi
  1db22c:	cmp    $0x2b7ffffe,%esi
  1db232:	ja     1db139 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2119>
  1db238:	mov    (%r9,%rax,8),%rsi
  1db23c:	vmulss %xmm0,%xmm9,%xmm2
  1db240:	vmulss %xmm1,%xmm9,%xmm0
  1db244:	add    $0xffffffffffffffb0,%rsi
  1db248:	jo     1db3be <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x239e>
  1db24e:	vmovd  %ecx,%xmm1
  1db252:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1db260:	mov    %rsi,%rcx
  1db263:	vmulss %xmm1,%xmm9,%xmm1
  1db267:	vmovd  %xmm1,%edx
  1db26b:	and    $0x7fffffff,%edx
  1db271:	lea    -0x1(%rdx),%edi
  1db274:	cmp    $0x2b7fffff,%edi
  1db27a:	jae    1db120 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2100>
  1db280:	vmulss %xmm2,%xmm9,%xmm2
  1db284:	vmulss %xmm0,%xmm9,%xmm0
  1db288:	add    $0xffffffffffffffb0,%rsi
  1db28c:	jno    1db260 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2240>
  1db28e:	jmp    1db3ba <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x239a>
  1db293:	vbroadcastss -0x1bd9c4(%rip),%xmm6        # 1d8d8 <__abi_tag+0x1d5dc>
  1db29c:	vandps %ymm1,%ymm13,%ymm2
  1db2a0:	vextractf128 $0x1,%ymm1,%xmm3
  1db2a6:	vextractps $0x2,%xmm3,%eax
  1db2ac:	add    %eax,%eax
  1db2ae:	cmp    $0xff000000,%eax
  1db2b3:	setae  %al
  1db2b6:	vcmpeq_uqps %xmm6,%xmm2,%xmm3
  1db2bb:	vtestps %xmm3,%xmm3
  1db2c0:	jne    1db35b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x233b>
  1db2c6:	vextractf128 $0x1,%ymm2,%xmm2
  1db2cc:	vcmpeq_uqps %xmm6,%xmm2,%xmm2
  1db2d1:	vshufps $0x50,%xmm2,%xmm2,%xmm2
  1db2d6:	vmovmskpd %xmm2,%ecx
  1db2da:	test   $0x1,%cl
  1db2dd:	vmovss -0x1bda15(%rip),%xmm9        # 1d8d0 <__abi_tag+0x1d5d4>
  1db2e5:	mov    0x80(%rsp),%r8
  1db2ed:	jne    1d96c5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x6a5>
  1db2f3:	shr    $1,%cl
  1db2f5:	jne    1d96c5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x6a5>
  1db2fb:	test   %al,%al
  1db2fd:	jne    1d96c5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x6a5>
  1db303:	vperm2f128 $0x21,%ymm0,%ymm1,%ymm2
  1db309:	vshufps $0x3,%ymm0,%ymm2,%ymm2
  1db30e:	vshufps $0x98,%ymm0,%ymm2,%ymm2
  1db313:	vpaddd %ymm2,%ymm2,%ymm2
  1db317:	vextractf128 $0x1,%ymm0,%xmm3
  1db31d:	vextractps $0x3,%xmm3,%eax
  1db323:	vpbroadcastd -0x1bdda4(%rip),%ymm3        # 1d588 <__abi_tag+0x1d28c>
  1db32c:	add    %eax,%eax
  1db32e:	cmp    $0xff000000,%eax
  1db333:	setae  %al
  1db336:	vpminud %ymm3,%ymm2,%ymm3
  1db33b:	vpxor  %ymm3,%ymm2,%ymm2
  1db33f:	vptest %ymm2,%ymm2
  1db344:	jne    1d96c5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x6a5>
  1db34a:	mov    $0x1,%cl
  1db34c:	mov    %rcx,0x18(%rsp)
  1db351:	test   %al,%al
  1db353:	jne    1d96cc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x6ac>
  1db359:	jmp    1db377 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2357>
  1db35b:	mov    $0x1,%al
  1db35d:	mov    %rax,0x18(%rsp)
  1db362:	vmovss -0x1bda9a(%rip),%xmm9        # 1d8d0 <__abi_tag+0x1d5d4>
  1db36a:	mov    0x80(%rsp),%r8
  1db372:	jmp    1d96cc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x6ac>
  1db377:	mov    0xa0(%rsp),%rax
  1db37f:	mov    0x8(%rsp),%rcx
  1db384:	vmovups %ymm1,(%rax,%rcx,4)
  1db389:	mov    0x98(%rsp),%rax
  1db391:	vmovups %ymm0,(%rax,%rcx,4)
  1db396:	jmp    1d93a7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x387>
  1db39b:	movq   $0xffffffffffffffff,(%r14)
  1db3a2:	jmp    1db45b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x243b>
  1db3a7:	mov    %rdi,(%r9,%rax,8)
  1db3ab:	vmovss %xmm0,(%r14,%rax,4)
  1db3b1:	vmovss %xmm1,0x0(%r13,%rax,4)
  1db3b8:	jmp    1db3cb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x23ab>
  1db3ba:	mov    %rcx,(%r9,%rax,8)
  1db3be:	vmovss %xmm2,(%r14,%rax,4)
  1db3c4:	vmovss %xmm0,0x0(%r13,%rax,4)
  1db3cb:	lea    -0x1b29a6(%rip),%rax        # 28a2c <anon.f2b1d4bcaf4adfc9d3638ed6f0755141.18.llvm.15276152473248788830+0xba>
  1db3d2:	mov    $0x10,%ecx
  1db3d7:	mov    $0x17,%edx
  1db3dc:	mov    0x100(%rsp),%r14
  1db3e4:	jmp    1db421 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2401>
  1db3e6:	mov    %rdi,(%r9,%rax,8)
  1db3ea:	vmovss %xmm0,0x0(%rbp,%rax,4)
  1db3f0:	mov    0x48(%rsp),%rcx
  1db3f5:	vmovss %xmm1,(%rcx,%rax,4)
  1db3fa:	jmp    1db410 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x23f0>
  1db3fc:	mov    %rcx,(%r9,%rax,8)
  1db400:	vmovss %xmm2,0x0(%rbp,%rax,4)
  1db406:	mov    0x48(%rsp),%rcx
  1db40b:	vmovss %xmm0,(%rcx,%rax,4)
  1db410:	lea    -0x1b29eb(%rip),%rax        # 28a2c <anon.f2b1d4bcaf4adfc9d3638ed6f0755141.18.llvm.15276152473248788830+0xba>
  1db417:	mov    $0x10,%ecx
  1db41c:	mov    $0x17,%edx
  1db421:	mov    %rcx,(%r14)
  1db424:	mov    %al,0x8(%r14)
  1db428:	mov    0x128(%rsp),%rax
  1db430:	mov    %ax,0x9(%r14)
  1db435:	shr    $0x10,%eax
  1db438:	mov    %al,0xb(%r14)
  1db43c:	mov    0x120(%rsp),%rax
  1db444:	mov    %eax,0xc(%r14)
  1db448:	mov    %rdx,0x10(%r14)
  1db44c:	vmovaps 0x290(%rsp),%xmm0
  1db455:	vmovups %xmm0,0x18(%r14)
  1db45b:	add    $0x828,%rsp
  1db462:	pop    %rbx
  1db463:	pop    %r12
  1db465:	pop    %r13
  1db467:	pop    %r14
  1db469:	pop    %r15
  1db46b:	pop    %rbp
  1db46c:	vzeroupper
  1db46f:	ret
  1db470:	movzbl 0x328(%rsp),%eax
  1db478:	movzbl 0x32b(%rsp),%edx
  1db480:	shl    $0x10,%edx
  1db483:	movzwl 0x329(%rsp),%esi
  1db48b:	or     %edx,%esi
  1db48d:	mov    %rsi,0x128(%rsp)
  1db495:	mov    0x32c(%rsp),%edx
  1db49c:	mov    %rdx,0x120(%rsp)
  1db4a4:	mov    0x330(%rsp),%rdx
  1db4ac:	lea    0x338(%rsp),%rsi
  1db4b4:	vmovups (%rsi),%xmm0
  1db4b8:	vmovaps %xmm0,0x290(%rsp)
  1db4c1:	jmp    1db421 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::F32SynthesisFallback>>+0x2401>
  1db4c6:	lea    0x66e8b(%rip),%rcx        # 242358 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x390>
  1db4cd:	mov    0x8(%rsp),%rdi
  1db4d2:	mov    %r10,%rsi
  1db4d5:	mov    %rbx,%rdx
  1db4d8:	vzeroupper
  1db4db:	call   *0x6aedf(%rip)        # 2463c0 <_DYNAMIC+0x298>
  1db4e1:	lea    0x66e58(%rip),%rcx        # 242340 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x378>
  1db4e8:	xor    %edi,%edi
  1db4ea:	mov    0x158(%rsp),%rdx
  1db4f2:	vzeroupper
  1db4f5:	call   *0x6aec5(%rip)        # 2463c0 <_DYNAMIC+0x298>
  1db4fb:	lea    0x66be6(%rip),%rcx        # 2420e8 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x120>
  1db502:	mov    0x30(%rsp),%rdx
  1db507:	vzeroupper
  1db50a:	call   *0x6aeb0(%rip)        # 2463c0 <_DYNAMIC+0x298>
  1db510:	lea    0x66dc9(%rip),%rcx        # 2422e0 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x318>
  1db517:	mov    0x8(%rsp),%rdi
  1db51c:	mov    %r10,%rsi
  1db51f:	mov    0xb8(%rsp),%rdx
  1db527:	vzeroupper
  1db52a:	call   *0x6ae90(%rip)        # 2463c0 <_DYNAMIC+0x298>
  1db530:	lea    0x66dc1(%rip),%rcx        # 2422f8 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x330>
  1db537:	xor    %edi,%edi
  1db539:	mov    0x150(%rsp),%rdx
  1db541:	vzeroupper
  1db544:	call   *0x6ae76(%rip)        # 2463c0 <_DYNAMIC+0x298>
  1db54a:	lea    0x66dbf(%rip),%rcx        # 242310 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x348>
  1db551:	xor    %edi,%edi
  1db553:	mov    0x148(%rsp),%rdx
  1db55b:	vzeroupper
  1db55e:	call   *0x6ae5c(%rip)        # 2463c0 <_DYNAMIC+0x298>
  1db564:	lea    0x66dbd(%rip),%rcx        # 242328 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x360>
  1db56b:	xor    %edi,%edi
  1db56d:	mov    0x140(%rsp),%rdx
  1db575:	vzeroupper
  1db578:	call   *0x6ae42(%rip)        # 2463c0 <_DYNAMIC+0x298>
  1db57e:	lea    0x66bc3(%rip),%rcx        # 242148 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x180>
  1db585:	mov    %r8,%rdi
  1db588:	mov    0x60(%rsp),%rdx
  1db58d:	vzeroupper
  1db590:	call   *0x6ae2a(%rip)        # 2463c0 <_DYNAMIC+0x298>
  1db596:	lea    0x66b33(%rip),%rcx        # 2420d0 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x108>
  1db59d:	mov    0x28(%rsp),%rdx
  1db5a2:	vzeroupper
  1db5a5:	call   *0x6ae15(%rip)        # 2463c0 <_DYNAMIC+0x298>
  1db5ab:	lea    0x66ad6(%rip),%rcx        # 242088 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0xc0>
  1db5b2:	mov    0x8(%rsp),%rdi
  1db5b7:	mov    0x160(%rsp),%rsi
  1db5bf:	mov    0xb8(%rsp),%rdx
  1db5c7:	vzeroupper
  1db5ca:	call   *0x6adf0(%rip)        # 2463c0 <_DYNAMIC+0x298>
  1db5d0:	lea    0x66a81(%rip),%rcx        # 242058 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x90>
  1db5d7:	mov    0x8(%rsp),%rdi
  1db5dc:	mov    0x30(%rsp),%rdx
  1db5e1:	vzeroupper
  1db5e4:	call   *0x6add6(%rip)        # 2463c0 <_DYNAMIC+0x298>
  1db5ea:	lea    0x66a7f(%rip),%rcx        # 242070 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0xa8>
  1db5f1:	mov    0x8(%rsp),%rdi
  1db5f6:	mov    0x28(%rsp),%rdx
  1db5fb:	vzeroupper
  1db5fe:	call   *0x6adbc(%rip)        # 2463c0 <_DYNAMIC+0x298>
  1db604:	lea    0x66d7d(%rip),%rdx        # 242388 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x3c0>
  1db60b:	mov    0x28(%rsp),%rsi
  1db610:	vzeroupper
  1db613:	call   *0x6ad6f(%rip)        # 246388 <_DYNAMIC+0x260>
  1db619:	lea    0x66d50(%rip),%rdx        # 242370 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x3a8>
  1db620:	mov    0x30(%rsp),%rsi
  1db625:	vzeroupper
  1db628:	call   *0x6ad5a(%rip)        # 246388 <_DYNAMIC+0x260>
  1db62e:	lea    0x66ae3(%rip),%rcx        # 242118 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x150>
  1db635:	mov    0x30(%rsp),%rdx
  1db63a:	vzeroupper
  1db63d:	call   *0x6ad7d(%rip)        # 2463c0 <_DYNAMIC+0x298>
  1db643:	lea    0x669ae(%rip),%rdx        # 241ff8 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x30>
  1db64a:	mov    0xc0(%rsp),%rdi
  1db652:	mov    %rdi,%rsi
  1db655:	vzeroupper
  1db658:	call   *0x6ad2a(%rip)        # 246388 <_DYNAMIC+0x260>
  1db65e:	lea    0x6697b(%rip),%rdx        # 241fe0 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x18>
  1db665:	mov    0xc8(%rsp),%rdi
  1db66d:	mov    %rdi,%rsi
  1db670:	vzeroupper
  1db673:	call   *0x6ad0f(%rip)        # 246388 <_DYNAMIC+0x260>
  1db679:	lea    0x66a80(%rip),%rcx        # 242100 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x138>
  1db680:	mov    0x28(%rsp),%rdx
  1db685:	vzeroupper
  1db688:	call   *0x6ad32(%rip)        # 2463c0 <_DYNAMIC+0x298>
  1db68e:	lea    0x66a0b(%rip),%rdx        # 2420a0 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0xd8>
  1db695:	mov    0xb0(%rsp),%rsi
  1db69d:	vzeroupper
  1db6a0:	call   *0x6ace2(%rip)        # 246388 <_DYNAMIC+0x260>
  1db6a6:	lea    0x66a0b(%rip),%rdx        # 2420b8 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0xf0>
  1db6ad:	mov    0xa8(%rsp),%rsi
  1db6b5:	vzeroupper
  1db6b8:	call   *0x6acca(%rip)        # 246388 <_DYNAMIC+0x260>
  1db6be:	lea    0x66b73(%rip),%rdx        # 242238 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x270>
  1db6c5:	mov    %rcx,%rdi
  1db6c8:	mov    0xa8(%rsp),%rsi
  1db6d0:	vzeroupper
  1db6d3:	call   *0x6acaf(%rip)        # 246388 <_DYNAMIC+0x260>
  1db6d9:	lea    0x66b40(%rip),%rdx        # 242220 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x258>
  1db6e0:	mov    %rax,%rdi
  1db6e3:	mov    0xb0(%rsp),%rsi
  1db6eb:	vzeroupper
  1db6ee:	call   *0x6ac94(%rip)        # 246388 <_DYNAMIC+0x260>
  1db6f4:	lea    0x66b55(%rip),%rdx        # 242250 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x288>
  1db6fb:	mov    0xc8(%rsp),%rsi
  1db703:	vzeroupper
  1db706:	call   *0x6ac7c(%rip)        # 246388 <_DYNAMIC+0x260>
  1db70c:	lea    0x66b55(%rip),%rdx        # 242268 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x2a0>
  1db713:	mov    0xc0(%rsp),%rsi
  1db71b:	vzeroupper
  1db71e:	call   *0x6ac64(%rip)        # 246388 <_DYNAMIC+0x260>
  1db724:	lea    0x66a05(%rip),%rdx        # 242130 <anon.ce069422c6965ff00ac021267fc201ab.95.llvm.5128532103865790292+0x168>
  1db72b:	mov    $0x40,%esi
  1db730:	mov    %r8,%rdi
  1db733:	vzeroupper
  1db736:	call   *0x6ac4c(%rip)        # 246388 <_DYNAMIC+0x260>
