
/tmp/rustsht-m6-f32-internal-double-current-20261028-01/bin/rust-f32:     file format elf64-x86-64


Disassembly of section .text:

00000000001d79e0 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32>:
  1d79e0:	sub    $0x18,%rsp
  1d79e4:	vmovd  %xmm0,%eax
  1d79e8:	mov    %eax,%ecx
  1d79ea:	and    $0x7f800000,%ecx
  1d79f0:	dec    %ecx
  1d79f2:	cmp    $0x7f7ffffe,%ecx
  1d79f8:	ja     1d7a5b <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x7b>
  1d79fa:	lea    -0x1001(%rdi),%rcx
  1d7a01:	cmp    $0xffffffffffffdfff,%rcx
  1d7a08:	jb     1d7a5b <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x7b>
  1d7a0a:	vmulss %xmm1,%xmm0,%xmm2
  1d7a0e:	vmovd  %xmm2,%ecx
  1d7a12:	mov    %ecx,%edx
  1d7a14:	and    $0x7f800000,%edx
  1d7a1a:	add    $0x80800000,%edx
  1d7a20:	cmp    $0x80800000,%edx
  1d7a26:	jbe    1d7a5b <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x7b>
  1d7a28:	mov    %ecx,%edx
  1d7a2a:	shr    $0x17,%edx
  1d7a2d:	movzbl %dl,%edx
  1d7a30:	lea    (%rdi,%rdx,1),%rsi
  1d7a34:	dec    %rsi
  1d7a37:	cmp    $0xfd,%rsi
  1d7a3e:	ja     1d7a5b <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x7b>
  1d7a40:	add    %rdx,%rdi
  1d7a43:	and    $0x807fffff,%ecx
  1d7a49:	shl    $0x17,%edi
  1d7a4c:	or     %ecx,%edi
  1d7a4e:	vmovd  %edi,%xmm2
  1d7a52:	vmovdqa %xmm2,%xmm0
  1d7a56:	add    $0x18,%rsp
  1d7a5a:	ret
  1d7a5b:	mov    %eax,%ecx
  1d7a5d:	and    $0x7fffffff,%ecx
  1d7a63:	lea    -0x800000(%rcx),%edx
  1d7a69:	cmp    $0x7f000000,%edx
  1d7a6f:	setb   %dl
  1d7a72:	dec    %ecx
  1d7a74:	cmp    $0x7fffff,%ecx
  1d7a7a:	setb   %cl
  1d7a7d:	or     %dl,%cl
  1d7a7f:	je     1d7b5d <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x17d>
  1d7a85:	mov    %eax,%ecx
  1d7a87:	shr    $0x17,%ecx
  1d7a8a:	movzbl %cl,%ecx
  1d7a8d:	vmovss -0x1b82dd(%rip),%xmm2        # 1f7b8 <__abi_tag+0x1f4bc>
  1d7a95:	vmulss %xmm2,%xmm0,%xmm0
  1d7a99:	vmovd  %xmm0,%esi
  1d7a9d:	mov    %esi,%edx
  1d7a9f:	shr    $0x17,%edx
  1d7aa2:	test   %ecx,%ecx
  1d7aa4:	movzbl %dl,%edx
  1d7aa7:	cmovne %ecx,%edx
  1d7aaa:	lea    -0x7e(%rdx),%r8
  1d7aae:	add    $0xffffffffffffff6a,%rdx
  1d7ab5:	test   %ecx,%ecx
  1d7ab7:	cmove  %esi,%eax
  1d7aba:	cmovne %r8,%rdx
  1d7abe:	lea    (%rdi,%rdx,1),%rcx
  1d7ac2:	sar    $0x3f,%rcx
  1d7ac6:	movabs $0x8000000000000000,%r8
  1d7ad0:	xor    %r8,%rcx
  1d7ad3:	add    %rdi,%rdx
  1d7ad6:	vmovd  %xmm1,%esi
  1d7ada:	cmovo  %rcx,%rdx
  1d7ade:	mov    %esi,%ecx
  1d7ae0:	shr    $0x17,%ecx
  1d7ae3:	movzbl %cl,%edi
  1d7ae6:	vmulss %xmm2,%xmm1,%xmm0
  1d7aea:	vmovd  %xmm0,%r9d
  1d7aef:	mov    %r9d,%ecx
  1d7af2:	shr    $0x17,%ecx
  1d7af5:	test   %edi,%edi
  1d7af7:	movzbl %cl,%ecx
  1d7afa:	cmovne %edi,%ecx
  1d7afd:	lea    -0x7e(%rcx),%r10
  1d7b01:	add    $0xffffffffffffff6a,%rcx
  1d7b08:	test   %edi,%edi
  1d7b0a:	cmove  %r9d,%esi
  1d7b0e:	cmovne %r10,%rcx
  1d7b12:	lea    (%rdx,%rcx,1),%rdi
  1d7b16:	sar    $0x3f,%rdi
  1d7b1a:	xor    %r8,%rdi
  1d7b1d:	add    %rdx,%rcx
  1d7b20:	cmovo  %rdi,%rcx
  1d7b24:	and    $0x807fffff,%eax
  1d7b29:	or     $0x3f000000,%eax
  1d7b2e:	vmovd  %eax,%xmm0
  1d7b32:	and    $0x807fffff,%esi
  1d7b38:	or     $0x3f000000,%esi
  1d7b3e:	vmovd  %esi,%xmm1
  1d7b42:	vmulss %xmm1,%xmm0,%xmm2
  1d7b46:	vxorps %xmm0,%xmm0,%xmm0
  1d7b4a:	vucomiss %xmm0,%xmm2
  1d7b4e:	jne    1d7be5 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x205>
  1d7b54:	vmovaps %xmm2,%xmm0
  1d7b58:	add    $0x18,%rsp
  1d7b5c:	ret
  1d7b5d:	vmulss %xmm1,%xmm0,%xmm2
  1d7b61:	vmovd  %xmm2,%eax
  1d7b65:	mov    %eax,%ecx
  1d7b67:	and    $0x7fffffff,%ecx
  1d7b6d:	cmp    $0x7f800000,%ecx
  1d7b73:	sete   %dl
  1d7b76:	test   %ecx,%ecx
  1d7b78:	sete   %sil
  1d7b7c:	or     %dl,%sil
  1d7b7f:	cmp    $0x7f800001,%ecx
  1d7b85:	setge  %cl
  1d7b88:	or     %sil,%cl
  1d7b8b:	jne    1d7b54 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x174>
  1d7b8d:	cmp    $0x1000,%rdi
  1d7b94:	jg     1d7c0f <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x22f>
  1d7b96:	cmp    $0xfffffffffffff000,%rdi
  1d7b9d:	jl     1d7c43 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x263>
  1d7ba3:	mov    %eax,%ecx
  1d7ba5:	shr    $0x17,%ecx
  1d7ba8:	movzbl %cl,%ecx
  1d7bab:	lea    (%rdi,%rcx,1),%rdx
  1d7baf:	dec    %rdx
  1d7bb2:	cmp    $0xfe,%rdx
  1d7bb9:	setb   %dl
  1d7bbc:	mov    %ecx,%esi
  1d7bbe:	dec    %esi
  1d7bc0:	cmp    $0xfe,%esi
  1d7bc6:	setb   %sil
  1d7bca:	test   %dl,%sil
  1d7bcd:	je     1d7c55 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x275>
  1d7bd3:	add    %rcx,%rdi
  1d7bd6:	and    $0x807fffff,%eax
  1d7bdb:	shl    $0x17,%edi
  1d7bde:	or     %eax,%edi
  1d7be0:	jmp    1d7a4e <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x6e>
  1d7be5:	vmovd  %xmm2,%eax
  1d7be9:	lea    (%rax,%rax,1),%edx
  1d7bec:	cmp    $0xff000000,%edx
  1d7bf2:	setae  %dl
  1d7bf5:	test   %rcx,%rcx
  1d7bf8:	je     1d7b54 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x174>
  1d7bfe:	test   %dl,%dl
  1d7c00:	jne    1d7b54 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x174>
  1d7c06:	cmp    $0x1000,%rcx
  1d7c0d:	jle    1d7c3a <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x25a>
  1d7c0f:	vbroadcastss -0x1b8300(%rip),%xmm0        # 1f918 <__abi_tag+0x1f61c>
  1d7c18:	vandps %xmm0,%xmm2,%xmm0
  1d7c1c:	vbroadcastss -0x1b85c5(%rip),%xmm1        # 1f660 <__abi_tag+0x1f364>
  1d7c25:	vorps  %xmm1,%xmm0,%xmm0
  1d7c29:	vmulss -0x1b8289(%rip),%xmm0,%xmm2        # 1f9a8 <__abi_tag+0x1f6ac>
  1d7c31:	vmovaps %xmm2,%xmm0
  1d7c35:	add    $0x18,%rsp
  1d7c39:	ret
  1d7c3a:	cmp    $0xfffffffffffff000,%rcx
  1d7c41:	jge    1d7c97 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x2b7>
  1d7c43:	vbroadcastss -0x1b8334(%rip),%xmm0        # 1f918 <__abi_tag+0x1f61c>
  1d7c4c:	vandps %xmm0,%xmm2,%xmm0
  1d7c50:	add    $0x18,%rsp
  1d7c54:	ret
  1d7c55:	cmp    $0x80,%rdi
  1d7c5c:	jl     1d7cd4 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x2f4>
  1d7c5e:	vmovss -0x1b8616(%rip),%xmm0        # 1f650 <__abi_tag+0x1f354>
  1d7c66:	cs nopw 0x0(%rax,%rax,1)
  1d7c70:	vmulss %xmm0,%xmm2,%xmm2
  1d7c74:	vmovd  %xmm2,%eax
  1d7c78:	add    %eax,%eax
  1d7c7a:	cmp    $0xfeffffff,%eax
  1d7c7f:	ja     1d7b54 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x174>
  1d7c85:	lea    -0x7f(%rdi),%rax
  1d7c89:	cmp    $0xfe,%rdi
  1d7c90:	mov    %rax,%rdi
  1d7c93:	jg     1d7c70 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x290>
  1d7c95:	jmp    1d7cd7 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x2f7>
  1d7c97:	mov    %eax,%edx
  1d7c99:	shr    $0x17,%edx
  1d7c9c:	movzbl %dl,%edx
  1d7c9f:	lea    -0x1(%rdx),%esi
  1d7ca2:	cmp    $0xfd,%esi
  1d7ca8:	ja     1d7d0e <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x32e>
  1d7caa:	lea    (%rcx,%rdx,1),%rsi
  1d7cae:	dec    %rsi
  1d7cb1:	cmp    $0xfe,%rsi
  1d7cb8:	jae    1d7d0e <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x32e>
  1d7cba:	add    %rdx,%rcx
  1d7cbd:	and    $0x807fffff,%eax
  1d7cc2:	shl    $0x17,%ecx
  1d7cc5:	or     %eax,%ecx
  1d7cc7:	vmovd  %ecx,%xmm2
  1d7ccb:	vmovdqa %xmm2,%xmm0
  1d7ccf:	add    $0x18,%rsp
  1d7cd3:	ret
  1d7cd4:	mov    %rdi,%rax
  1d7cd7:	cmp    $0xffffffffffffff81,%rax
  1d7cdb:	jg     1d7d7c <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x39c>
  1d7ce1:	vmovss -0x1b8081(%rip),%xmm0        # 1fc68 <__abi_tag+0x1f96c>
  1d7ce9:	vxorps %xmm1,%xmm1,%xmm1
  1d7ced:	vmulss %xmm0,%xmm2,%xmm2
  1d7cf1:	vucomiss %xmm1,%xmm2
  1d7cf5:	jne    1d7cfd <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x31d>
  1d7cf7:	jnp    1d7b54 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x174>
  1d7cfd:	lea    0x7e(%rax),%rdi
  1d7d01:	cmp    $0xffffffffffffff04,%rax
  1d7d07:	mov    %rdi,%rax
  1d7d0a:	jl     1d7ced <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x30d>
  1d7d0c:	jmp    1d7d7f <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x39f>
  1d7d0e:	cmp    $0x80,%rcx
  1d7d15:	jl     1d7d46 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x366>
  1d7d17:	vmovss -0x1b86cf(%rip),%xmm0        # 1f650 <__abi_tag+0x1f354>
  1d7d1f:	vmulss %xmm0,%xmm2,%xmm2
  1d7d23:	vmovd  %xmm2,%eax
  1d7d27:	add    %eax,%eax
  1d7d29:	cmp    $0xfeffffff,%eax
  1d7d2e:	ja     1d7b54 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x174>
  1d7d34:	lea    -0x7f(%rcx),%rax
  1d7d38:	cmp    $0xfe,%rcx
  1d7d3f:	mov    %rax,%rcx
  1d7d42:	jg     1d7d1f <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x33f>
  1d7d44:	jmp    1d7d49 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x369>
  1d7d46:	mov    %rcx,%rax
  1d7d49:	cmp    $0xffffffffffffff81,%rax
  1d7d4d:	jg     1d7d7c <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x39c>
  1d7d4f:	vmovss -0x1b80ef(%rip),%xmm0        # 1fc68 <__abi_tag+0x1f96c>
  1d7d57:	vxorps %xmm1,%xmm1,%xmm1
  1d7d5b:	vmulss %xmm0,%xmm2,%xmm2
  1d7d5f:	vucomiss %xmm1,%xmm2
  1d7d63:	jne    1d7d6b <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x38b>
  1d7d65:	jnp    1d7b54 <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x174>
  1d7d6b:	lea    0x7e(%rax),%rdi
  1d7d6f:	cmp    $0xffffffffffffff04,%rax
  1d7d75:	mov    %rdi,%rax
  1d7d78:	jl     1d7d5b <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x37b>
  1d7d7a:	jmp    1d7d7f <rustsht::legendre::scalar::multiply_component_scaled_with_normal_factor_f32+0x39f>
  1d7d7c:	mov    %rax,%rdi
  1d7d7f:	vmovaps %xmm2,(%rsp)
  1d7d84:	vmovss -0x1b84c4(%rip),%xmm0        # 1f8c8 <__abi_tag+0x1f5cc>
  1d7d8c:	call   *0xab08e(%rip)        # 282e20 <_DYNAMIC+0x990>
  1d7d92:	vmovaps (%rsp),%xmm2
  1d7d97:	vmulss %xmm0,%xmm2,%xmm2
  1d7d9b:	vmovaps %xmm2,%xmm0
  1d7d9f:	add    $0x18,%rsp
  1d7da3:	ret
