
/tmp/rustsht-m6-f32-internal-double-current-20261028-01/bin/rust-f64-paired:     file format elf64-x86-64


Disassembly of section .text:

00000000001e4cb0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>>:
  1e4cb0:	push   %rbp
  1e4cb1:	push   %r15
  1e4cb3:	push   %r14
  1e4cb5:	push   %r13
  1e4cb7:	push   %r12
  1e4cb9:	push   %rbx
  1e4cba:	sub    $0x68,%rsp
  1e4cbe:	mov    %rdi,%rdx
  1e4cc1:	mov    0x88(%rdi),%r12
  1e4cc8:	mov    (%rdi),%rax
  1e4ccb:	mov    %rax,0x48(%rsp)
  1e4cd0:	mov    0x8(%rdi),%r9
  1e4cd4:	mov    0x10(%rdi),%r13
  1e4cd8:	mov    0x18(%rdi),%rsi
  1e4cdc:	mov    0x20(%rdi),%rbp
  1e4ce0:	mov    0x28(%rdi),%rax
  1e4ce4:	mov    0x30(%rdi),%r15
  1e4ce8:	mov    0x38(%rdi),%rdi
  1e4cec:	mov    0x40(%rdx),%rbx
  1e4cf0:	mov    0x48(%rdx),%rcx
  1e4cf4:	mov    0x50(%rdx),%r8
  1e4cf8:	mov    %r8,0x40(%rsp)
  1e4cfd:	mov    0x58(%rdx),%r8
  1e4d01:	mov    %r8,0x30(%rsp)
  1e4d06:	sub    0x80(%rdx),%r12
  1e4d0d:	mov    0x60(%rdx),%r8
  1e4d11:	mov    %r8,0x28(%rsp)
  1e4d16:	mov    0x68(%rdx),%r8
  1e4d1a:	mov    %r8,0x18(%rsp)
  1e4d1f:	mov    0x70(%rdx),%r8
  1e4d23:	mov    %r8,0x20(%rsp)
  1e4d28:	mov    0x78(%rdx),%rdx
  1e4d2c:	mov    %rdx,0x10(%rsp)
  1e4d31:	mov    %r9,0x38(%rsp)
  1e4d36:	shr    $0x2,%r9
  1e4d3a:	add    $0x2,%r12
  1e4d3e:	shr    $1,%r12
  1e4d41:	mov    %r9,0x8(%rsp)
  1e4d46:	test   %r9,%r9
  1e4d49:	je     1e4f05 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x255>
  1e4d4f:	mov    0x30(%rsp),%rdx
  1e4d54:	shr    $0x2,%rdx
  1e4d58:	mov    %rdx,0x60(%rsp)
  1e4d5d:	mov    0x18(%rsp),%rdx
  1e4d62:	shr    $0x2,%rdx
  1e4d66:	mov    %rdx,0x58(%rsp)
  1e4d6b:	mov    0x10(%rsp),%rdx
  1e4d70:	shr    $0x2,%rdx
  1e4d74:	mov    %rdx,0x50(%rsp)
  1e4d79:	test   %r12,%r12
  1e4d7c:	je     1e4eac <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x1fc>
  1e4d82:	xor    %r14d,%r14d
  1e4d85:	data16 cs nopw 0x0(%rax,%rax,1)
  1e4d90:	cmp    0x60(%rsp),%r14
  1e4d95:	je     1e53ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x73e>
  1e4d9b:	lea    0x1(%r14),%r11
  1e4d9f:	mov    %r14,%r8
  1e4da2:	shl    $0x5,%r8
  1e4da6:	mov    0x48(%rsp),%rdx
  1e4dab:	vmovupd (%rdx,%r8,1),%ymm1
  1e4db1:	mov    0x40(%rsp),%rdx
  1e4db6:	vmovupd (%rdx,%r8,1),%ymm5
  1e4dbc:	vmulpd %ymm1,%ymm1,%ymm2
  1e4dc0:	vxorpd %xmm4,%xmm4,%xmm4
  1e4dc4:	mov    $0x1,%r9d
  1e4dca:	xor    %r10d,%r10d
  1e4dcd:	vxorpd %xmm0,%xmm0,%xmm0
  1e4dd1:	vxorpd %xmm3,%xmm3,%xmm3
  1e4dd5:	jmp    1e4e08 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x158>
  1e4dd7:	nopw   0x0(%rax,%rax,1)
  1e4de0:	vmovapd %ymm5,%ymm10
  1e4de4:	vfmadd213pd %ymm8,%ymm1,%ymm6
  1e4de9:	vfmadd213pd %ymm9,%ymm1,%ymm7
  1e4dee:	vfmadd231pd %ymm6,%ymm5,%ymm3
  1e4df3:	vfmadd231pd %ymm7,%ymm5,%ymm0
  1e4df8:	add    $0x2,%r9
  1e4dfc:	mov    %rdx,%r10
  1e4dff:	vmovapd %ymm10,%ymm5
  1e4e03:	cmp    %rdx,%r12
  1e4e06:	je     1e4e70 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x1c0>
  1e4e08:	cmp    %r10,%rdi
  1e4e0b:	je     1e5389 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x6d9>
  1e4e11:	cmp    %r10,%rcx
  1e4e14:	je     1e5373 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x6c3>
  1e4e1a:	lea    0x1(%r10),%rdx
  1e4e1e:	vbroadcastsd -0x8(%rbx,%r9,8),%ymm6
  1e4e25:	vbroadcastsd -0x8(%r15,%r9,8),%ymm8
  1e4e2c:	vbroadcastsd (%rbx,%r9,8),%ymm7
  1e4e32:	vbroadcastsd (%r15,%r9,8),%ymm9
  1e4e38:	cmp    %r12,%rdx
  1e4e3b:	jae    1e4de0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x130>
  1e4e3d:	cmp    %rsi,%r10
  1e4e40:	jae    1e53b2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x702>
  1e4e46:	cmp    %rax,%r10
  1e4e49:	jae    1e539c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x6ec>
  1e4e4f:	vbroadcastsd 0x0(%r13,%r10,8),%ymm11
  1e4e56:	vbroadcastsd 0x0(%rbp,%r10,8),%ymm10
  1e4e5d:	vfmadd231pd %ymm11,%ymm2,%ymm10
  1e4e62:	vfmadd213pd %ymm4,%ymm5,%ymm10
  1e4e67:	vmovapd %ymm5,%ymm4
  1e4e6b:	jmp    1e4de4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x134>
  1e4e70:	cmp    0x58(%rsp),%r14
  1e4e75:	je     1e5406 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x756>
  1e4e7b:	mov    0x28(%rsp),%rdx
  1e4e80:	vmovupd %ymm3,(%rdx,%r8,1)
  1e4e86:	cmp    0x50(%rsp),%r14
  1e4e8b:	je     1e541e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x76e>
  1e4e91:	mov    0x20(%rsp),%rdx
  1e4e96:	vmovupd %ymm0,(%rdx,%r8,1)
  1e4e9c:	mov    %r11,%r14
  1e4e9f:	cmp    0x8(%rsp),%r11
  1e4ea4:	jne    1e4d90 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0xe0>
  1e4eaa:	jmp    1e4f05 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x255>
  1e4eac:	xor    %edx,%edx
  1e4eae:	vxorpd %xmm0,%xmm0,%xmm0
  1e4eb2:	xor    %r8d,%r8d
  1e4eb5:	data16 cs nopw 0x0(%rax,%rax,1)
  1e4ec0:	cmp    %r8,0x60(%rsp)
  1e4ec5:	je     1e53ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x73e>
  1e4ecb:	cmp    %r8,0x58(%rsp)
  1e4ed0:	je     1e5406 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x756>
  1e4ed6:	mov    0x28(%rsp),%r9
  1e4edb:	vmovupd %ymm0,(%r9,%rdx,1)
  1e4ee1:	cmp    %r8,0x50(%rsp)
  1e4ee6:	je     1e541e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x76e>
  1e4eec:	inc    %r8
  1e4eef:	mov    0x20(%rsp),%r9
  1e4ef4:	vmovupd %ymm0,(%r9,%rdx,1)
  1e4efa:	add    $0x20,%rdx
  1e4efe:	cmp    %r8,0x8(%rsp)
  1e4f03:	jne    1e4ec0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x210>
  1e4f05:	mov    0x38(%rsp),%r11
  1e4f0a:	and    $0x3,%r11d
  1e4f0e:	je     1e5361 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x6b1>
  1e4f14:	movabs $0xffffffffffffffc,%rdx
  1e4f1e:	mov    0x30(%rsp),%r9
  1e4f23:	and    $0x3,%r9d
  1e4f27:	mov    0x18(%rsp),%r10
  1e4f2c:	mov    %r10d,%r8d
  1e4f2f:	and    $0x3,%r8d
  1e4f33:	and    %rdx,%r10
  1e4f36:	mov    %r10,0x18(%rsp)
  1e4f3b:	mov    0x10(%rsp),%r10
  1e4f40:	mov    %r10d,%r14d
  1e4f43:	and    $0x3,%r14d
  1e4f47:	mov    %r14,0x8(%rsp)
  1e4f4c:	and    %rdx,%r10
  1e4f4f:	mov    %r10,0x10(%rsp)
  1e4f54:	test   %r12,%r12
  1e4f57:	je     1e5140 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x490>
  1e4f5d:	test   %r9,%r9
  1e4f60:	je     1e545f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7af>
  1e4f66:	mov    0x38(%rsp),%r10
  1e4f6b:	and    %rdx,%r10
  1e4f6e:	mov    0x30(%rsp),%r14
  1e4f73:	and    %rdx,%r14
  1e4f76:	mov    0x48(%rsp),%rdx
  1e4f7b:	mov    %r10,0x38(%rsp)
  1e4f80:	vmovsd (%rdx,%r10,8),%xmm1
  1e4f86:	mov    0x40(%rsp),%rdx
  1e4f8b:	mov    %r14,0x30(%rsp)
  1e4f90:	vmovsd (%rdx,%r14,8),%xmm5
  1e4f96:	vmulsd %xmm1,%xmm1,%xmm2
  1e4f9a:	vxorpd %xmm3,%xmm3,%xmm3
  1e4f9e:	mov    $0x1,%edx
  1e4fa3:	xor    %r10d,%r10d
  1e4fa6:	vxorpd %xmm0,%xmm0,%xmm0
  1e4faa:	vxorpd %xmm4,%xmm4,%xmm4
  1e4fae:	jmp    1e4fce <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x31e>
  1e4fb0:	vmovapd %xmm5,%xmm8
  1e4fb4:	vfmadd231sd %xmm6,%xmm5,%xmm4
  1e4fb9:	vfmadd231sd %xmm7,%xmm5,%xmm0
  1e4fbe:	add    $0x2,%rdx
  1e4fc2:	mov    %r14,%r10
  1e4fc5:	vmovapd %xmm8,%xmm5
  1e4fc9:	cmp    %r14,%r12
  1e4fcc:	je     1e502c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x37c>
  1e4fce:	cmp    %r10,%rdi
  1e4fd1:	je     1e53c5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x715>
  1e4fd7:	cmp    %r10,%rcx
  1e4fda:	je     1e53d8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x728>
  1e4fe0:	lea    0x1(%r10),%r14
  1e4fe4:	vmovsd -0x8(%rbx,%rdx,8),%xmm6
  1e4fea:	vfmadd213sd -0x8(%r15,%rdx,8),%xmm1,%xmm6
  1e4ff1:	vmovsd (%rbx,%rdx,8),%xmm7
  1e4ff6:	vfmadd213sd (%r15,%rdx,8),%xmm1,%xmm7
  1e4ffc:	cmp    %r12,%r14
  1e4fff:	jae    1e4fb0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x300>
  1e5001:	cmp    %rsi,%r10
  1e5004:	jae    1e544c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x79c>
  1e500a:	cmp    %rax,%r10
  1e500d:	jae    1e5436 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x786>
  1e5013:	vmovsd 0x0(%r13,%r10,8),%xmm8
  1e501a:	vfmadd213sd 0x0(%rbp,%r10,8),%xmm2,%xmm8
  1e5021:	vfmadd213sd %xmm3,%xmm5,%xmm8
  1e5026:	vmovapd %xmm5,%xmm3
  1e502a:	jmp    1e4fb4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x304>
  1e502c:	test   %r8,%r8
  1e502f:	je     1e5475 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7c5>
  1e5035:	mov    0x28(%rsp),%rdx
  1e503a:	mov    0x18(%rsp),%r10
  1e503f:	vmovsd %xmm4,(%rdx,%r10,8)
  1e5045:	cmpq   $0x0,0x8(%rsp)
  1e504b:	je     1e548b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7db>
  1e5051:	mov    0x20(%rsp),%rdx
  1e5056:	mov    0x10(%rsp),%r10
  1e505b:	vmovsd %xmm0,(%rdx,%r10,8)
  1e5061:	cmp    $0x1,%r11d
  1e5065:	je     1e5361 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x6b1>
  1e506b:	cmp    $0x1,%r9d
  1e506f:	je     1e545f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7af>
  1e5075:	mov    0x48(%rsp),%rdx
  1e507a:	mov    0x38(%rsp),%r10
  1e507f:	vmovsd 0x8(%rdx,%r10,8),%xmm1
  1e5086:	mov    0x40(%rsp),%rdx
  1e508b:	mov    0x30(%rsp),%r10
  1e5090:	vmovsd 0x8(%rdx,%r10,8),%xmm5
  1e5097:	vmulsd %xmm1,%xmm1,%xmm2
  1e509b:	vxorpd %xmm4,%xmm4,%xmm4
  1e509f:	mov    $0x1,%edx
  1e50a4:	xor    %r10d,%r10d
  1e50a7:	vxorpd %xmm0,%xmm0,%xmm0
  1e50ab:	vxorpd %xmm3,%xmm3,%xmm3
  1e50af:	jmp    1e50e2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x432>
  1e50b1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1e50c0:	vmovapd %xmm5,%xmm8
  1e50c4:	vfmadd231sd %xmm6,%xmm5,%xmm3
  1e50c9:	vfmadd231sd %xmm7,%xmm5,%xmm0
  1e50ce:	add    $0x2,%rdx
  1e50d2:	mov    %r14,%r10
  1e50d5:	vmovapd %xmm8,%xmm5
  1e50d9:	cmp    %r14,%r12
  1e50dc:	je     1e5225 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x575>
  1e50e2:	cmp    %r10,%rdi
  1e50e5:	je     1e53c5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x715>
  1e50eb:	cmp    %r10,%rcx
  1e50ee:	je     1e53d8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x728>
  1e50f4:	lea    0x1(%r10),%r14
  1e50f8:	vmovsd -0x8(%rbx,%rdx,8),%xmm6
  1e50fe:	vfmadd213sd -0x8(%r15,%rdx,8),%xmm1,%xmm6
  1e5105:	vmovsd (%rbx,%rdx,8),%xmm7
  1e510a:	vfmadd213sd (%r15,%rdx,8),%xmm1,%xmm7
  1e5110:	cmp    %r12,%r14
  1e5113:	jae    1e50c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x410>
  1e5115:	cmp    %rsi,%r10
  1e5118:	jae    1e544c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x79c>
  1e511e:	cmp    %rax,%r10
  1e5121:	jae    1e5436 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x786>
  1e5127:	vmovsd 0x0(%r13,%r10,8),%xmm8
  1e512e:	vfmadd213sd 0x0(%rbp,%r10,8),%xmm2,%xmm8
  1e5135:	vfmadd213sd %xmm4,%xmm5,%xmm8
  1e513a:	vmovapd %xmm5,%xmm4
  1e513e:	jmp    1e50c4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x414>
  1e5140:	test   %r9,%r9
  1e5143:	je     1e545f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7af>
  1e5149:	test   %r8,%r8
  1e514c:	je     1e5475 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7c5>
  1e5152:	mov    0x28(%rsp),%rax
  1e5157:	mov    0x18(%rsp),%rcx
  1e515c:	movq   $0x0,(%rax,%rcx,8)
  1e5164:	cmpq   $0x0,0x8(%rsp)
  1e516a:	je     1e548b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7db>
  1e5170:	mov    0x20(%rsp),%rax
  1e5175:	mov    0x10(%rsp),%rcx
  1e517a:	movq   $0x0,(%rax,%rcx,8)
  1e5182:	cmp    $0x1,%r11d
  1e5186:	je     1e5361 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x6b1>
  1e518c:	cmp    $0x1,%r9d
  1e5190:	je     1e545f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7af>
  1e5196:	cmp    $0x1,%r8d
  1e519a:	je     1e5475 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7c5>
  1e51a0:	mov    0x28(%rsp),%rax
  1e51a5:	mov    0x18(%rsp),%rcx
  1e51aa:	movq   $0x0,0x8(%rax,%rcx,8)
  1e51b3:	cmpl   $0x1,0x8(%rsp)
  1e51b8:	je     1e548b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7db>
  1e51be:	mov    0x20(%rsp),%rax
  1e51c3:	mov    0x10(%rsp),%rcx
  1e51c8:	movq   $0x0,0x8(%rax,%rcx,8)
  1e51d1:	cmp    $0x2,%r11d
  1e51d5:	je     1e5361 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x6b1>
  1e51db:	cmp    $0x2,%r9d
  1e51df:	je     1e545f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7af>
  1e51e5:	cmp    $0x2,%r8d
  1e51e9:	je     1e5475 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7c5>
  1e51ef:	mov    0x28(%rsp),%rax
  1e51f4:	mov    0x18(%rsp),%rcx
  1e51f9:	movq   $0x0,0x10(%rax,%rcx,8)
  1e5202:	cmpl   $0x2,0x8(%rsp)
  1e5207:	je     1e548b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7db>
  1e520d:	mov    0x20(%rsp),%rax
  1e5212:	mov    0x10(%rsp),%rcx
  1e5217:	movq   $0x0,0x10(%rax,%rcx,8)
  1e5220:	jmp    1e5361 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x6b1>
  1e5225:	cmp    $0x1,%r8d
  1e5229:	je     1e5475 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7c5>
  1e522f:	mov    0x28(%rsp),%rdx
  1e5234:	mov    0x18(%rsp),%r10
  1e5239:	vmovsd %xmm3,0x8(%rdx,%r10,8)
  1e5240:	cmpl   $0x1,0x8(%rsp)
  1e5245:	je     1e548b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7db>
  1e524b:	mov    0x20(%rsp),%rdx
  1e5250:	mov    0x10(%rsp),%r10
  1e5255:	vmovsd %xmm0,0x8(%rdx,%r10,8)
  1e525c:	cmp    $0x2,%r11d
  1e5260:	je     1e5361 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x6b1>
  1e5266:	cmp    $0x2,%r9d
  1e526a:	je     1e545f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7af>
  1e5270:	mov    0x48(%rsp),%rdx
  1e5275:	mov    0x38(%rsp),%r9
  1e527a:	vmovsd 0x10(%rdx,%r9,8),%xmm1
  1e5281:	mov    0x40(%rsp),%rdx
  1e5286:	mov    0x30(%rsp),%r9
  1e528b:	vmovsd 0x10(%rdx,%r9,8),%xmm5
  1e5292:	vmulsd %xmm1,%xmm1,%xmm2
  1e5296:	vxorpd %xmm4,%xmm4,%xmm4
  1e529a:	mov    $0x1,%edx
  1e529f:	xor    %r10d,%r10d
  1e52a2:	vxorpd %xmm0,%xmm0,%xmm0
  1e52a6:	vxorpd %xmm3,%xmm3,%xmm3
  1e52aa:	jmp    1e52ce <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x61e>
  1e52ac:	nopl   0x0(%rax)
  1e52b0:	vmovapd %xmm5,%xmm8
  1e52b4:	vfmadd231sd %xmm6,%xmm5,%xmm3
  1e52b9:	vfmadd231sd %xmm7,%xmm5,%xmm0
  1e52be:	add    $0x2,%rdx
  1e52c2:	mov    %r9,%r10
  1e52c5:	vmovapd %xmm8,%xmm5
  1e52c9:	cmp    %r9,%r12
  1e52cc:	je     1e532c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x67c>
  1e52ce:	cmp    %r10,%rdi
  1e52d1:	je     1e53c5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x715>
  1e52d7:	cmp    %r10,%rcx
  1e52da:	je     1e53d8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x728>
  1e52e0:	lea    0x1(%r10),%r9
  1e52e4:	vmovsd -0x8(%rbx,%rdx,8),%xmm6
  1e52ea:	vfmadd213sd -0x8(%r15,%rdx,8),%xmm1,%xmm6
  1e52f1:	vmovsd (%rbx,%rdx,8),%xmm7
  1e52f6:	vfmadd213sd (%r15,%rdx,8),%xmm1,%xmm7
  1e52fc:	cmp    %r12,%r9
  1e52ff:	jae    1e52b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x600>
  1e5301:	cmp    %rsi,%r10
  1e5304:	jae    1e544c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x79c>
  1e530a:	cmp    %rax,%r10
  1e530d:	jae    1e5436 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x786>
  1e5313:	vmovsd 0x0(%r13,%r10,8),%xmm8
  1e531a:	vfmadd213sd 0x0(%rbp,%r10,8),%xmm2,%xmm8
  1e5321:	vfmadd213sd %xmm4,%xmm5,%xmm8
  1e5326:	vmovapd %xmm5,%xmm4
  1e532a:	jmp    1e52b4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x604>
  1e532c:	cmp    $0x2,%r8d
  1e5330:	je     1e5475 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7c5>
  1e5336:	mov    0x28(%rsp),%rax
  1e533b:	mov    0x18(%rsp),%rcx
  1e5340:	vmovsd %xmm3,0x10(%rax,%rcx,8)
  1e5346:	cmpl   $0x2,0x8(%rsp)
  1e534b:	je     1e548b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f64, false, true>>>+0x7db>
  1e5351:	mov    0x20(%rsp),%rax
  1e5356:	mov    0x10(%rsp),%rcx
  1e535b:	vmovsd %xmm0,0x10(%rax,%rcx,8)
  1e5361:	add    $0x68,%rsp
  1e5365:	pop    %rbx
  1e5366:	pop    %r12
  1e5368:	pop    %r13
  1e536a:	pop    %r14
  1e536c:	pop    %r15
  1e536e:	pop    %rbp
  1e536f:	vzeroupper
  1e5372:	ret
  1e5373:	lea    0xba0ee(%rip),%rdx        # 29f468 <anon.00fec7e820077a05d119dd377f58174c.74.llvm.14222643608304330708+0x4c8>
  1e537a:	mov    %rcx,%rdi
  1e537d:	mov    %rcx,%rsi
  1e5380:	vzeroupper
  1e5383:	call   *0xc04ff(%rip)        # 2a5888 <_DYNAMIC+0x2b8>
  1e5389:	lea    0xba0c0(%rip),%rdx        # 29f450 <anon.00fec7e820077a05d119dd377f58174c.74.llvm.14222643608304330708+0x4b0>
  1e5390:	mov    %rdi,%rsi
  1e5393:	vzeroupper
  1e5396:	call   *0xc04ec(%rip)        # 2a5888 <_DYNAMIC+0x2b8>
  1e539c:	lea    0xba0f5(%rip),%rdx        # 29f498 <anon.00fec7e820077a05d119dd377f58174c.74.llvm.14222643608304330708+0x4f8>
  1e53a3:	mov    %r10,%rdi
  1e53a6:	mov    %rax,%rsi
  1e53a9:	vzeroupper
  1e53ac:	call   *0xc04d6(%rip)        # 2a5888 <_DYNAMIC+0x2b8>
  1e53b2:	lea    0xba0c7(%rip),%rdx        # 29f480 <anon.00fec7e820077a05d119dd377f58174c.74.llvm.14222643608304330708+0x4e0>
  1e53b9:	mov    %r10,%rdi
  1e53bc:	vzeroupper
  1e53bf:	call   *0xc04c3(%rip)        # 2a5888 <_DYNAMIC+0x2b8>
  1e53c5:	lea    0xb9fdc(%rip),%rdx        # 29f3a8 <anon.00fec7e820077a05d119dd377f58174c.74.llvm.14222643608304330708+0x408>
  1e53cc:	mov    %rdi,%rsi
  1e53cf:	vzeroupper
  1e53d2:	call   *0xc04b0(%rip)        # 2a5888 <_DYNAMIC+0x2b8>
  1e53d8:	lea    0xb9fe1(%rip),%rdx        # 29f3c0 <anon.00fec7e820077a05d119dd377f58174c.74.llvm.14222643608304330708+0x420>
  1e53df:	mov    %rcx,%rdi
  1e53e2:	mov    %rcx,%rsi
  1e53e5:	vzeroupper
  1e53e8:	call   *0xc049a(%rip)        # 2a5888 <_DYNAMIC+0x2b8>
  1e53ee:	lea    0xba013(%rip),%rdx        # 29f408 <anon.00fec7e820077a05d119dd377f58174c.74.llvm.14222643608304330708+0x468>
  1e53f5:	mov    0x60(%rsp),%rdi
  1e53fa:	mov    %rdi,%rsi
  1e53fd:	vzeroupper
  1e5400:	call   *0xc0482(%rip)        # 2a5888 <_DYNAMIC+0x2b8>
  1e5406:	lea    0xba013(%rip),%rdx        # 29f420 <anon.00fec7e820077a05d119dd377f58174c.74.llvm.14222643608304330708+0x480>
  1e540d:	mov    0x58(%rsp),%rdi
  1e5412:	mov    %rdi,%rsi
  1e5415:	vzeroupper
  1e5418:	call   *0xc046a(%rip)        # 2a5888 <_DYNAMIC+0x2b8>
  1e541e:	lea    0xba013(%rip),%rdx        # 29f438 <anon.00fec7e820077a05d119dd377f58174c.74.llvm.14222643608304330708+0x498>
  1e5425:	mov    0x50(%rsp),%rdi
  1e542a:	mov    %rdi,%rsi
  1e542d:	vzeroupper
  1e5430:	call   *0xc0452(%rip)        # 2a5888 <_DYNAMIC+0x2b8>
  1e5436:	lea    0xb9fb3(%rip),%rdx        # 29f3f0 <anon.00fec7e820077a05d119dd377f58174c.74.llvm.14222643608304330708+0x450>
  1e543d:	mov    %r10,%rdi
  1e5440:	mov    %rax,%rsi
  1e5443:	vzeroupper
  1e5446:	call   *0xc043c(%rip)        # 2a5888 <_DYNAMIC+0x2b8>
  1e544c:	lea    0xb9f85(%rip),%rdx        # 29f3d8 <anon.00fec7e820077a05d119dd377f58174c.74.llvm.14222643608304330708+0x438>
  1e5453:	mov    %r10,%rdi
  1e5456:	vzeroupper
  1e5459:	call   *0xc0429(%rip)        # 2a5888 <_DYNAMIC+0x2b8>
  1e545f:	lea    0xb9efa(%rip),%rdx        # 29f360 <anon.00fec7e820077a05d119dd377f58174c.74.llvm.14222643608304330708+0x3c0>
  1e5466:	mov    %r9,%rdi
  1e5469:	mov    %r9,%rsi
  1e546c:	vzeroupper
  1e546f:	call   *0xc0413(%rip)        # 2a5888 <_DYNAMIC+0x2b8>
  1e5475:	lea    0xb9efc(%rip),%rdx        # 29f378 <anon.00fec7e820077a05d119dd377f58174c.74.llvm.14222643608304330708+0x3d8>
  1e547c:	mov    %r8,%rdi
  1e547f:	mov    %r8,%rsi
  1e5482:	vzeroupper
  1e5485:	call   *0xc03fd(%rip)        # 2a5888 <_DYNAMIC+0x2b8>
  1e548b:	lea    0xb9efe(%rip),%rdx        # 29f390 <anon.00fec7e820077a05d119dd377f58174c.74.llvm.14222643608304330708+0x3f0>
  1e5492:	mov    0x8(%rsp),%rdi
  1e5497:	mov    %rdi,%rsi
  1e549a:	vzeroupper
  1e549d:	call   *0xc03e5(%rip)        # 2a5888 <_DYNAMIC+0x2b8>
