
/tmp/rustsht-m6-f32-internal-double-current-20261028-01/bin/rust-f32:     file format elf64-x86-64


Disassembly of section .text:

0000000000202710 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>>:
  202710:	push   %rbp
  202711:	push   %r15
  202713:	push   %r14
  202715:	push   %r13
  202717:	push   %r12
  202719:	push   %rbx
  20271a:	sub    $0xe8,%rsp
  202721:	mov    0x88(%rdi),%r13
  202728:	mov    (%rdi),%r10
  20272b:	mov    0x8(%rdi),%r12
  20272f:	mov    0x10(%rdi),%rax
  202733:	mov    %rax,0x60(%rsp)
  202738:	mov    0x18(%rdi),%rax
  20273c:	mov    %rax,0x70(%rsp)
  202741:	mov    0x20(%rdi),%r15
  202745:	mov    0x28(%rdi),%rax
  202749:	mov    %rax,0x68(%rsp)
  20274e:	mov    0x30(%rdi),%rcx
  202752:	mov    0x38(%rdi),%r8
  202756:	mov    0x40(%rdi),%rdx
  20275a:	mov    0x48(%rdi),%r9
  20275e:	mov    0x50(%rdi),%r14
  202762:	mov    0x58(%rdi),%rbx
  202766:	sub    0x80(%rdi),%r13
  20276d:	mov    0x60(%rdi),%rax
  202771:	mov    %rax,0x18(%rsp)
  202776:	mov    0x68(%rdi),%rbp
  20277a:	mov    0x70(%rdi),%rax
  20277e:	mov    %rax,0x58(%rsp)
  202783:	mov    0x78(%rdi),%rax
  202787:	mov    %r12,%r11
  20278a:	shr    $0x3,%r11
  20278e:	mov    %r12,0x90(%rsp)
  202796:	and    $0x7,%r12d
  20279a:	mov    %r12,0x28(%rsp)
  20279f:	mov    %rbx,0x48(%rsp)
  2027a4:	mov    %ebx,%edi
  2027a6:	and    $0x7,%edi
  2027a9:	mov    %rdi,0x20(%rsp)
  2027ae:	mov    %rbp,0x38(%rsp)
  2027b3:	and    $0x7,%ebp
  2027b6:	mov    %rbp,0x10(%rsp)
  2027bb:	mov    %rax,0x40(%rsp)
  2027c0:	and    $0x7,%eax
  2027c3:	mov    %rax,0x8(%rsp)
  2027c8:	add    $0x2,%r13
  2027cc:	shr    $1,%r13
  2027cf:	mov    %r11,0x50(%rsp)
  2027d4:	test   %r11,%r11
  2027d7:	je     2029f5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x2e5>
  2027dd:	mov    0x48(%rsp),%rbx
  2027e2:	shr    $0x3,%rbx
  2027e6:	mov    0x38(%rsp),%rsi
  2027eb:	shr    $0x3,%rsi
  2027ef:	mov    0x40(%rsp),%rdi
  2027f4:	shr    $0x3,%rdi
  2027f8:	test   %r13,%r13
  2027fb:	mov    %rsi,0x30(%rsp)
  202800:	je     202a99 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x389>
  202806:	xor    %r11d,%r11d
  202809:	vpbroadcastd -0x1e2bea(%rip),%ymm0        # 1fc28 <__abi_tag+0x1f92c>
  202812:	vmovdqu %ymm0,0xa0(%rsp)
  20281b:	mov    %r10,0x88(%rsp)
  202823:	mov    %r14,0x80(%rsp)
  20282b:	mov    %rdi,0x78(%rsp)
  202830:	mov    0x70(%rsp),%r12
  202835:	mov    0x60(%rsp),%rbp
  20283a:	vbroadcastss -0x1e2e43(%rip),%ymm3        # 1fa00 <__abi_tag+0x1f704>
  202843:	vxorps %xmm8,%xmm8,%xmm8
  202848:	jmp    202889 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x179>
  20284a:	nopw   0x0(%rax,%rax,1)
  202850:	vmovups %ymm6,(%r10)
  202855:	mov    0x98(%rsp),%rax
  20285d:	vmovups %ymm7,(%rax)
  202861:	mov    %rdi,%r11
  202864:	cmp    0x50(%rsp),%rdi
  202869:	mov    0x88(%rsp),%r10
  202871:	mov    0x80(%rsp),%r14
  202879:	mov    0x78(%rsp),%rdi
  20287e:	mov    0x30(%rsp),%rsi
  202883:	je     2029f5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x2e5>
  202889:	cmp    %rbx,%r11
  20288c:	je     202d9e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x68e>
  202892:	cmp    %rsi,%r11
  202895:	mov    0x68(%rsp),%rsi
  20289a:	je     202d86 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x676>
  2028a0:	cmp    %rdi,%r11
  2028a3:	je     202d73 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x663>
  2028a9:	lea    0x1(%r11),%rdi
  2028ad:	shl    $0x5,%r11
  2028b1:	vmovups (%r10,%r11,1),%ymm5
  2028b7:	vmovups (%r14,%r11,1),%ymm9
  2028bd:	mov    0x18(%rsp),%r10
  2028c2:	add    %r11,%r10
  2028c5:	vmovups (%r10),%ymm6
  2028ca:	mov    0x58(%rsp),%r14
  2028cf:	lea    (%r14,%r11,1),%rax
  2028d3:	mov    %rax,0x98(%rsp)
  2028db:	vmovups (%r14,%r11,1),%ymm7
  2028e1:	vmulps %ymm5,%ymm5,%ymm0
  2028e5:	vmovups %ymm0,0xc0(%rsp)
  2028ee:	vxorps %xmm10,%xmm10,%xmm10
  2028f3:	xor    %r14d,%r14d
  2028f6:	jmp    20292a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x21a>
  2028f8:	nopl   0x0(%rax,%rax,1)
  202900:	vmovaps %ymm9,%ymm15
  202905:	vfmadd213ps %ymm13,%ymm5,%ymm11
  20290a:	vfmadd213ps %ymm14,%ymm5,%ymm12
  20290f:	vfmadd231ps %ymm11,%ymm9,%ymm6
  202914:	vfmadd231ps %ymm12,%ymm9,%ymm7
  202919:	mov    %r11,%r14
  20291c:	vmovaps %ymm15,%ymm9
  202921:	cmp    %r11,%r13
  202924:	je     202850 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x140>
  20292a:	cmp    %r14,%r8
  20292d:	je     202cdf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5cf>
  202933:	cmp    %r14,%r9
  202936:	je     202cc9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5b9>
  20293c:	lea    0x1(%r14),%r11
  202940:	vbroadcastss (%rdx,%r14,8),%ymm11
  202946:	vbroadcastss (%rcx,%r14,8),%ymm13
  20294c:	vbroadcastss 0x4(%rdx,%r14,8),%ymm12
  202953:	vbroadcastss 0x4(%rcx,%r14,8),%ymm14
  20295a:	cmp    %r13,%r11
  20295d:	jae    202900 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1f0>
  20295f:	cmp    %r12,%r14
  202962:	jae    202cf5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5e5>
  202968:	cmp    %rsi,%r14
  20296b:	jae    202d0b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5fb>
  202971:	vbroadcastss 0x0(%rbp,%r14,4),%ymm4
  202978:	vbroadcastss (%r15,%r14,4),%ymm15
  20297e:	vfmadd231ps 0xc0(%rsp),%ymm4,%ymm15
  202988:	vfmadd213ps %ymm10,%ymm9,%ymm15
  20298d:	vmovups 0xa0(%rsp),%ymm0
  202996:	vandps %ymm0,%ymm9,%ymm4
  20299a:	vandps %ymm0,%ymm15,%ymm10
  20299e:	vcmple_oqps %ymm3,%ymm4,%ymm1
  2029a3:	vcmpeqps %ymm4,%ymm8,%ymm2
  2029a8:	vbroadcastss -0x1e2da9(%rip),%ymm0        # 1fc08 <__abi_tag+0x1f90c>
  2029b1:	vcmpge_oqps %ymm0,%ymm4,%ymm4
  2029b6:	vorps  %ymm2,%ymm4,%ymm2
  2029ba:	vandps %ymm1,%ymm2,%ymm1
  2029be:	vcmple_oqps %ymm3,%ymm10,%ymm2
  2029c3:	vandps %ymm2,%ymm1,%ymm1
  2029c7:	vcmpeqps %ymm8,%ymm10,%ymm2
  2029cd:	vcmpge_oqps %ymm0,%ymm10,%ymm4
  2029d2:	vorps  %ymm2,%ymm4,%ymm2
  2029d6:	vandps %ymm2,%ymm1,%ymm1
  2029da:	vpcmpeqd %ymm0,%ymm0,%ymm0
  2029de:	vptest %ymm0,%ymm1
  2029e3:	vmovaps %ymm9,%ymm10
  2029e8:	jb     202905 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x1f5>
  2029ee:	xor    %eax,%eax
  2029f0:	jmp    202cb4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a4>
  2029f5:	mov    0x28(%rsp),%rdi
  2029fa:	test   %rdi,%rdi
  2029fd:	je     202cb2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a2>
  202a03:	test   %r13,%r13
  202a06:	je     202c5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x54d>
  202a0c:	movabs $0x1ffffffffffffff8,%rax
  202a16:	mov    0x90(%rsp),%rdi
  202a1e:	and    %rax,%rdi
  202a21:	lea    (%r10,%rdi,4),%rsi
  202a25:	mov    %rsi,0xc0(%rsp)
  202a2d:	mov    0x48(%rsp),%rdi
  202a32:	and    %rax,%rdi
  202a35:	lea    (%r14,%rdi,4),%rsi
  202a39:	mov    %rsi,0xa0(%rsp)
  202a41:	mov    0x38(%rsp),%r10
  202a46:	and    %rax,%r10
  202a49:	mov    0x18(%rsp),%rdi
  202a4e:	lea    (%rdi,%r10,4),%r10
  202a52:	mov    0x40(%rsp),%rdi
  202a57:	and    %rax,%rdi
  202a5a:	mov    0x58(%rsp),%rax
  202a5f:	lea    (%rax,%rdi,4),%rdi
  202a63:	xor    %r11d,%r11d
  202a66:	vpxor  %xmm0,%xmm0,%xmm0
  202a6a:	vbroadcastss -0x1e2e4b(%rip),%xmm1        # 1fc28 <__abi_tag+0x1f92c>
  202a73:	vmovss -0x1e2e73(%rip),%xmm2        # 1fc08 <__abi_tag+0x1f90c>
  202a7b:	vmovss -0x1e3083(%rip),%xmm3        # 1fa00 <__abi_tag+0x1f704>
  202a83:	mov    0x70(%rsp),%r12
  202a88:	mov    0x68(%rsp),%rsi
  202a8d:	mov    0x60(%rsp),%rbp
  202a92:	mov    %r10,0x18(%rsp)
  202a97:	jmp    202b01 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x3f1>
  202a99:	cmp    %rbx,%rsi
  202a9c:	mov    %rbx,%rcx
  202a9f:	cmovb  %rsi,%rcx
  202aa3:	cmp    %rdi,%rcx
  202aa6:	cmovae %rdi,%rcx
  202aaa:	mov    0x50(%rsp),%rdx
  202aaf:	dec    %rdx
  202ab2:	cmp    %rdx,%rcx
  202ab5:	mov    %rdx,%rax
  202ab8:	cmovb  %rcx,%rdx
  202abc:	cmp    %rdx,%rbx
  202abf:	je     202d9e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x68e>
  202ac5:	cmp    %rdx,%rsi
  202ac8:	je     202d86 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x676>
  202ace:	cmp    %rdx,%rdi
  202ad1:	je     202d73 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x663>
  202ad7:	cmp    %rcx,%rax
  202ada:	jbe    202c53 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x543>
  202ae0:	jmp    202ae0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x3d0>
  202ae2:	mov    0x18(%rsp),%r10
  202ae7:	vmovss %xmm7,(%r10,%r11,4)
  202aed:	vmovss %xmm8,(%rdi,%r11,4)
  202af3:	mov    %rbx,%r11
  202af6:	cmp    0x28(%rsp),%rbx
  202afb:	je     202cb2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a2>
  202b01:	cmp    0x20(%rsp),%r11
  202b06:	je     202de4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x6d4>
  202b0c:	cmp    0x10(%rsp),%r11
  202b11:	je     202dcc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x6bc>
  202b17:	cmp    0x8(%rsp),%r11
  202b1c:	je     202db4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x6a4>
  202b22:	lea    0x1(%r11),%rbx
  202b26:	mov    0xc0(%rsp),%rax
  202b2e:	vmovss (%rax,%r11,4),%xmm4
  202b34:	mov    0xa0(%rsp),%rax
  202b3c:	vmovss (%rax,%r11,4),%xmm6
  202b42:	vmovss (%r10,%r11,4),%xmm7
  202b48:	vmovss (%rdi,%r11,4),%xmm8
  202b4e:	vmulss %xmm4,%xmm4,%xmm5
  202b52:	vxorps %xmm11,%xmm11,%xmm11
  202b57:	xor    %r10d,%r10d
  202b5a:	jmp    202b7e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x46e>
  202b5c:	nopl   0x0(%rax)
  202b60:	vmovaps %xmm6,%xmm12
  202b64:	vfmadd213ss %xmm10,%xmm6,%xmm7
  202b69:	vfmadd213ss %xmm9,%xmm6,%xmm8
  202b6e:	mov    %r14,%r10
  202b71:	vmovaps %xmm12,%xmm6
  202b75:	cmp    %r14,%r13
  202b78:	je     202ae2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x3d2>
  202b7e:	cmp    %r10,%r8
  202b81:	je     202d1e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x60e>
  202b87:	cmp    %r10,%r9
  202b8a:	je     202d34 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x624>
  202b90:	vmovaps %xmm7,%xmm10
  202b94:	vmovaps %xmm8,%xmm9
  202b99:	lea    0x1(%r10),%r14
  202b9d:	vmovss (%rdx,%r10,8),%xmm7
  202ba3:	vfmadd213ss (%rcx,%r10,8),%xmm4,%xmm7
  202ba9:	vmovss 0x4(%rdx,%r10,8),%xmm8
  202bb0:	vfmadd213ss 0x4(%rcx,%r10,8),%xmm4,%xmm8
  202bb7:	cmp    %r13,%r14
  202bba:	jae    202b60 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x450>
  202bbc:	cmp    %r12,%r10
  202bbf:	jae    202d5d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x64d>
  202bc5:	cmp    %rsi,%r10
  202bc8:	jae    202d4a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x63a>
  202bce:	vmovss 0x0(%rbp,%r10,4),%xmm12
  202bd5:	vfmadd213ss (%r15,%r10,4),%xmm5,%xmm12
  202bdb:	vucomiss %xmm0,%xmm6
  202bdf:	jne    202be3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x4d3>
  202be1:	jnp    202c0f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x4ff>
  202be3:	vmovd  %xmm6,%eax
  202be7:	add    %eax,%eax
  202be9:	cmp    $0xfeffffff,%eax
  202bee:	ja     2029ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x2de>
  202bf4:	vandps %xmm1,%xmm6,%xmm13
  202bf8:	xor    %eax,%eax
  202bfa:	vucomiss %xmm2,%xmm13
  202bfe:	jb     202cb4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a4>
  202c04:	vucomiss %xmm13,%xmm3
  202c09:	jb     202cb4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a4>
  202c0f:	vfmadd213ss %xmm11,%xmm6,%xmm12
  202c14:	vucomiss %xmm0,%xmm12
  202c18:	jne    202c25 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x515>
  202c1a:	jp     202c25 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x515>
  202c1c:	vmovaps %xmm6,%xmm11
  202c20:	jmp    202b64 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x454>
  202c25:	vmovd  %xmm12,%eax
  202c29:	add    %eax,%eax
  202c2b:	cmp    $0xfeffffff,%eax
  202c30:	ja     2029ee <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x2de>
  202c36:	vandps %xmm1,%xmm12,%xmm11
  202c3a:	xor    %eax,%eax
  202c3c:	vucomiss %xmm2,%xmm11
  202c40:	jb     202cb4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a4>
  202c42:	vucomiss %xmm11,%xmm3
  202c47:	vmovaps %xmm6,%xmm11
  202c4b:	jae    202b64 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x454>
  202c51:	jmp    202cb4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a4>
  202c53:	mov    0x28(%rsp),%rdi
  202c58:	test   %rdi,%rdi
  202c5b:	je     202cb2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a2>
  202c5d:	dec    %rdi
  202c60:	mov    0x10(%rsp),%rax
  202c65:	cmp    %rax,%rdi
  202c68:	cmovb  %rdi,%rax
  202c6c:	mov    0x20(%rsp),%rdx
  202c71:	cmp    %rdx,%rax
  202c74:	cmovae %rdx,%rax
  202c78:	mov    0x8(%rsp),%rcx
  202c7d:	cmp    %rcx,%rax
  202c80:	cmovb  %rax,%rcx
  202c84:	cmp    %rcx,%rdx
  202c87:	je     202de4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x6d4>
  202c8d:	cmp    %ecx,0x10(%rsp)
  202c91:	je     202dcc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x6bc>
  202c97:	cmp    %eax,0x8(%rsp)
  202c9b:	jbe    202db4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x6a4>
  202ca1:	mov    $0x1,%al
  202ca3:	cmp    %ecx,%edi
  202ca5:	je     202cb4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a4>
  202ca7:	nopw   0x0(%rax,%rax,1)
  202cb0:	jmp    202cb0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedSynthesisBlock<f32, true, false>>>+0x5a0>
  202cb2:	mov    $0x1,%al
  202cb4:	add    $0xe8,%rsp
  202cbb:	pop    %rbx
  202cbc:	pop    %r12
  202cbe:	pop    %r13
  202cc0:	pop    %r14
  202cc2:	pop    %r15
  202cc4:	pop    %rbp
  202cc5:	vzeroupper
  202cc8:	ret
  202cc9:	lea    0x7a8d0(%rip),%rdx        # 27d5a0 <anon.83851886f91b5742ed845431b9b9f48b.18.llvm.385686576749158458+0x1b38>
  202cd0:	mov    %r9,%rdi
  202cd3:	mov    %r9,%rsi
  202cd6:	vzeroupper
  202cd9:	call   *0x7fa11(%rip)        # 2826f0 <_DYNAMIC+0x260>
  202cdf:	lea    0x7a8a2(%rip),%rdx        # 27d588 <anon.83851886f91b5742ed845431b9b9f48b.18.llvm.385686576749158458+0x1b20>
  202ce6:	mov    %r8,%rdi
  202ce9:	mov    %r8,%rsi
  202cec:	vzeroupper
  202cef:	call   *0x7f9fb(%rip)        # 2826f0 <_DYNAMIC+0x260>
  202cf5:	lea    0x7a8bc(%rip),%rdx        # 27d5b8 <anon.83851886f91b5742ed845431b9b9f48b.18.llvm.385686576749158458+0x1b50>
  202cfc:	mov    %r14,%rdi
  202cff:	mov    %r12,%rsi
  202d02:	vzeroupper
  202d05:	call   *0x7f9e5(%rip)        # 2826f0 <_DYNAMIC+0x260>
  202d0b:	lea    0x7a8be(%rip),%rdx        # 27d5d0 <anon.83851886f91b5742ed845431b9b9f48b.18.llvm.385686576749158458+0x1b68>
  202d12:	mov    %r14,%rdi
  202d15:	vzeroupper
  202d18:	call   *0x7f9d2(%rip)        # 2826f0 <_DYNAMIC+0x260>
  202d1e:	lea    0x7a7eb(%rip),%rdx        # 27d510 <anon.83851886f91b5742ed845431b9b9f48b.18.llvm.385686576749158458+0x1aa8>
  202d25:	mov    %r8,%rdi
  202d28:	mov    %r8,%rsi
  202d2b:	vzeroupper
  202d2e:	call   *0x7f9bc(%rip)        # 2826f0 <_DYNAMIC+0x260>
  202d34:	lea    0x7a7ed(%rip),%rdx        # 27d528 <anon.83851886f91b5742ed845431b9b9f48b.18.llvm.385686576749158458+0x1ac0>
  202d3b:	mov    %r9,%rdi
  202d3e:	mov    %r9,%rsi
  202d41:	vzeroupper
  202d44:	call   *0x7f9a6(%rip)        # 2826f0 <_DYNAMIC+0x260>
  202d4a:	lea    0x7a807(%rip),%rdx        # 27d558 <anon.83851886f91b5742ed845431b9b9f48b.18.llvm.385686576749158458+0x1af0>
  202d51:	mov    %r10,%rdi
  202d54:	vzeroupper
  202d57:	call   *0x7f993(%rip)        # 2826f0 <_DYNAMIC+0x260>
  202d5d:	lea    0x7a7dc(%rip),%rdx        # 27d540 <anon.83851886f91b5742ed845431b9b9f48b.18.llvm.385686576749158458+0x1ad8>
  202d64:	mov    %r10,%rdi
  202d67:	mov    %r12,%rsi
  202d6a:	vzeroupper
  202d6d:	call   *0x7f97d(%rip)        # 2826f0 <_DYNAMIC+0x260>
  202d73:	lea    0x7a8b6(%rip),%rdx        # 27d630 <anon.83851886f91b5742ed845431b9b9f48b.18.llvm.385686576749158458+0x1bc8>
  202d7a:	mov    %rdi,%rsi
  202d7d:	vzeroupper
  202d80:	call   *0x7f96a(%rip)        # 2826f0 <_DYNAMIC+0x260>
  202d86:	lea    0x7a88b(%rip),%rdx        # 27d618 <anon.83851886f91b5742ed845431b9b9f48b.18.llvm.385686576749158458+0x1bb0>
  202d8d:	mov    0x30(%rsp),%rdi
  202d92:	mov    %rdi,%rsi
  202d95:	vzeroupper
  202d98:	call   *0x7f952(%rip)        # 2826f0 <_DYNAMIC+0x260>
  202d9e:	lea    0x7a7cb(%rip),%rdx        # 27d570 <anon.83851886f91b5742ed845431b9b9f48b.18.llvm.385686576749158458+0x1b08>
  202da5:	mov    %rbx,%rdi
  202da8:	mov    %rbx,%rsi
  202dab:	vzeroupper
  202dae:	call   *0x7f93c(%rip)        # 2826f0 <_DYNAMIC+0x260>
  202db4:	lea    0x7a845(%rip),%rdx        # 27d600 <anon.83851886f91b5742ed845431b9b9f48b.18.llvm.385686576749158458+0x1b98>
  202dbb:	mov    0x8(%rsp),%rdi
  202dc0:	mov    %rdi,%rsi
  202dc3:	vzeroupper
  202dc6:	call   *0x7f924(%rip)        # 2826f0 <_DYNAMIC+0x260>
  202dcc:	lea    0x7a815(%rip),%rdx        # 27d5e8 <anon.83851886f91b5742ed845431b9b9f48b.18.llvm.385686576749158458+0x1b80>
  202dd3:	mov    0x10(%rsp),%rdi
  202dd8:	mov    %rdi,%rsi
  202ddb:	vzeroupper
  202dde:	call   *0x7f90c(%rip)        # 2826f0 <_DYNAMIC+0x260>
  202de4:	lea    0x7a70d(%rip),%rdx        # 27d4f8 <anon.83851886f91b5742ed845431b9b9f48b.18.llvm.385686576749158458+0x1a90>
  202deb:	mov    0x20(%rsp),%rdi
  202df0:	mov    %rdi,%rsi
  202df3:	vzeroupper
  202df6:	call   *0x7f8f4(%rip)        # 2826f0 <_DYNAMIC+0x260>
