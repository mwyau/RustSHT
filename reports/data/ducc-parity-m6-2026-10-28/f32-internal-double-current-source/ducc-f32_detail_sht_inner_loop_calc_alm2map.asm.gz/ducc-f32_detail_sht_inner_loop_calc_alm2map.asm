
/tmp/rustsht-m6-f32-internal-double-current-20261028-01/bin/ducc-f32:     file format elf64-x86-64


Disassembly of section .text:

00000000006813c0 <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)>:
  6813c0:	lea    0x8(%rsp),%r10
  6813c5:	and    $0xffffffffffffffe0,%rsp
  6813c9:	push   -0x8(%r10)
  6813cd:	push   %rbp
  6813ce:	mov    %rsp,%rbp
  6813d1:	push   %r15
  6813d3:	mov    %rsi,%r15
  6813d6:	push   %r14
  6813d8:	push   %r13
  6813da:	lea    0x3(%rcx),%r13
  6813de:	lea    -0x40(%rbp),%rcx
  6813e2:	push   %r12
  6813e4:	shr    $0x2,%r13
  6813e8:	mov    %rdx,%r12
  6813eb:	lea    -0x48(%rbp),%rdx
  6813ef:	push   %r10
  6813f1:	mov    %r12,%rsi
  6813f4:	push   %rbx
  6813f5:	mov    %rdi,%rbx
  6813f8:	mov    %r15,%rdi
  6813fb:	sub    $0x28,%rsp
  6813ff:	mov    %fs:0x28,%r14
  681408:	mov    %r14,-0x38(%rbp)
  68140c:	mov    %r9,%r14
  68140f:	movq   $0x0,-0x40(%rbp)
  681417:	push   %r9
  681419:	mov    %r8,%r9
  68141c:	mov    %r13,%r8
  68141f:	call   680d90 <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]>
  681424:	mov    -0x48(%rbp),%r10
  681428:	pop    %rcx
  681429:	pop    %rsi
  68142a:	cmp    %r14,%r10
  68142d:	jae    681684 <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0x2c4>
  681433:	test   %r13,%r13
  681436:	je     68172b <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0x36b>
  68143c:	mov    %r13,%rsi
  68143f:	mov    %r12,%rax
  681442:	vxorpd %xmm4,%xmm4,%xmm4
  681446:	mov    $0x1,%edx
  68144b:	shl    $0x5,%rsi
  68144f:	vpcmpeqd %ymm3,%ymm3,%ymm3
  681453:	vbroadcastsd 0x1a2e44(%rip),%ymm13        # 8242a0 <_IO_stdin_used+0x2f2a0>
  68145c:	add    %r12,%rsi
  68145f:	nop
  681460:	vmovapd 0x1000(%rax),%ymm0
  681468:	vbroadcastsd 0x1a2b4f(%rip),%ymm5        # 823fc0 <_IO_stdin_used+0x2efc0>
  681471:	vcmpltpd 0x1a3126(%rip),%ymm0,%ymm1        # 8245a0 <_IO_stdin_used+0x2f5a0>
  68147a:	vcmpltpd %ymm0,%ymm5,%ymm2
  68147f:	vcmplepd %ymm0,%ymm4,%ymm0
  681484:	vandnpd %ymm13,%ymm1,%ymm1
  681489:	vblendvpd %ymm2,0x1a30cd(%rip),%ymm1,%ymm1        # 824560 <_IO_stdin_used+0x2f560>
  681493:	vtestpd %ymm3,%ymm0
  681498:	vmovapd %ymm1,0x800(%rax)
  6814a0:	setb   %cl
  6814a3:	add    $0x20,%rax
  6814a7:	and    %ecx,%edx
  6814a9:	cmp    %rax,%rsi
  6814ac:	jne    681460 <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0xa0>
  6814ae:	test   %dl,%dl
  6814b0:	jne    681731 <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0x371>
  6814b6:	mov    %r10,%rdi
  6814b9:	mov    -0x40(%rbp),%r8
  6814bd:	vxorpd %xmm10,%xmm10,%xmm10
  6814c2:	vpcmpeqd %ymm9,%ymm9,%ymm9
  6814c7:	shl    $0x4,%rdi
  6814cb:	mov    0xe0(%r15),%r9
  6814d2:	vbroadcastsd 0x1a2d45(%rip),%ymm12        # 824220 <_IO_stdin_used+0x2f220>
  6814db:	vbroadcastsd 0x1a309c(%rip),%ymm11        # 824580 <_IO_stdin_used+0x2f580>
  6814e4:	add    %rbx,%rdi
  6814e7:	vbroadcastsd 0x1a3050(%rip),%ymm14        # 824540 <_IO_stdin_used+0x2f540>
  6814f0:	mov    %r8,%rax
  6814f3:	vbroadcastsd (%rdi),%ymm7
  6814f8:	vbroadcastsd 0x8(%rdi),%ymm6
  6814fe:	mov    $0x1,%edx
  681503:	shl    $0x4,%rax
  681507:	vbroadcastsd 0x10(%rdi),%ymm5
  68150d:	vbroadcastsd 0x18(%rdi),%ymm4
  681513:	add    %r9,%rax
  681516:	vbroadcastsd (%rax),%ymm3
  68151b:	vbroadcastsd 0x8(%rax),%ymm2
  681521:	mov    %r12,%rax
  681524:	jmp    681550 <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0x190>
  681526:	cs nopw 0x0(%rax,%rax,1)
  681530:	vcmplepd 0x1000(%rax),%ymm10,%ymm0
  681539:	vtestpd %ymm9,%ymm0
  68153e:	setb   %cl
  681541:	add    $0x20,%rax
  681545:	and    %ecx,%edx
  681547:	cmp    %rax,%rsi
  68154a:	je     681668 <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0x2a8>
  681550:	vmovapd 0x2000(%rax),%ymm1
  681558:	vmulpd 0x800(%rax),%ymm1,%ymm0
  681560:	vmovapd %ymm7,%ymm8
  681564:	vfmadd213pd 0x3000(%rax),%ymm0,%ymm8
  68156d:	vmovapd %ymm8,0x3000(%rax)
  681575:	vmovapd %ymm6,%ymm8
  681579:	vfmadd213pd 0x3800(%rax),%ymm0,%ymm8
  681582:	vmovapd %ymm8,0x3800(%rax)
  68158a:	vmovapd %ymm5,%ymm8
  68158e:	vfmadd213pd 0x4000(%rax),%ymm0,%ymm8
  681597:	vfmadd213pd 0x4800(%rax),%ymm4,%ymm0
  6815a0:	vmovapd %ymm8,0x4000(%rax)
  6815a8:	vmovapd %ymm0,0x4800(%rax)
  6815b0:	vmovapd %ymm3,%ymm0
  6815b4:	vfmadd132pd 0x2800(%rax),%ymm2,%ymm0
  6815bd:	vfmadd213pd 0x1800(%rax),%ymm1,%ymm0
  6815c6:	vmovapd %ymm1,0x1800(%rax)
  6815ce:	vandpd %ymm12,%ymm0,%ymm8
  6815d3:	vmovapd %ymm0,0x2000(%rax)
  6815db:	vcmpltpd %ymm8,%ymm11,%ymm8
  6815e1:	vtestpd %ymm8,%ymm8
  6815e6:	je     681530 <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0x170>
  6815ec:	vmulpd %ymm14,%ymm1,%ymm15
  6815f1:	vblendvpd %ymm8,%ymm15,%ymm1,%ymm1
  6815f7:	vbroadcastsd 0x1a29c0(%rip),%ymm15        # 823fc0 <_IO_stdin_used+0x2efc0>
  681600:	vmovapd %ymm1,0x1800(%rax)
  681608:	vmulpd %ymm14,%ymm0,%ymm1
  68160d:	vblendvpd %ymm8,%ymm1,%ymm0,%ymm0
  681613:	vmovapd %ymm0,0x2000(%rax)
  68161b:	vmovapd 0x1000(%rax),%ymm0
  681623:	vaddpd %ymm13,%ymm0,%ymm1
  681628:	vblendvpd %ymm8,%ymm1,%ymm0,%ymm0
  68162e:	vcmpltpd 0x1a2f69(%rip),%ymm0,%ymm1        # 8245a0 <_IO_stdin_used+0x2f5a0>
  681637:	vcmpltpd %ymm0,%ymm15,%ymm8
  68163c:	vmovapd %ymm0,0x1000(%rax)
  681644:	vcmplepd %ymm0,%ymm10,%ymm0
  681649:	vandnpd %ymm13,%ymm1,%ymm1
  68164e:	vblendvpd %ymm8,0x1a2f08(%rip),%ymm1,%ymm1        # 824560 <_IO_stdin_used+0x2f560>
  681658:	vmovapd %ymm1,0x800(%rax)
  681660:	jmp    681539 <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0x179>
  681665:	nopl   (%rax)
  681668:	add    $0x2,%r10
  68166c:	add    $0x1,%r8
  681670:	test   %dl,%dl
  681672:	jne    6816ac <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0x2ec>
  681674:	add    $0x20,%rdi
  681678:	cmp    %r14,%r10
  68167b:	jb     6814f0 <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0x130>
  681681:	vzeroupper
  681684:	mov    -0x38(%rbp),%rax
  681688:	sub    %fs:0x28,%rax
  681691:	jne    68173a <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0x37a>
  681697:	lea    -0x30(%rbp),%rsp
  68169b:	pop    %rbx
  68169c:	pop    %r10
  68169e:	pop    %r12
  6816a0:	pop    %r13
  6816a2:	pop    %r14
  6816a4:	pop    %r15
  6816a6:	pop    %rbp
  6816a7:	lea    -0x8(%r10),%rsp
  6816ab:	ret
  6816ac:	cmp    %r14,%r10
  6816af:	jae    681681 <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0x2c1>
  6816b1:	lea    0x800(%r12),%rax
  6816b9:	xor    %edx,%edx
  6816bb:	vxorpd %xmm2,%xmm2,%xmm2
  6816bf:	nop
  6816c0:	vmovapd (%rax),%ymm0
  6816c4:	vmulpd 0x1000(%rax),%ymm0,%ymm1
  6816cc:	mov    %rdx,%rcx
  6816cf:	add    $0x1,%rdx
  6816d3:	vmulpd 0x1800(%rax),%ymm0,%ymm0
  6816db:	shl    $0x5,%rcx
  6816df:	add    $0x20,%rax
  6816e3:	vmovapd %ymm1,0xfe0(%rax)
  6816eb:	vmovapd %ymm0,0x17e0(%rax)
  6816f3:	vmovapd %ymm2,0x1000(%r12,%rcx,1)
  6816fd:	cmp    %rdx,%r13
  681700:	jne    6816c0 <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0x300>
  681702:	vzeroupper
  681705:	sub    $0x8,%rsp
  681709:	mov    %rbx,%rdx
  68170c:	lea    -0x1(%r14),%r9
  681710:	mov    %r10,%rcx
  681713:	mov    0xe0(%r15),%rsi
  68171a:	push   %r13
  68171c:	mov    %r12,%rdi
  68171f:	call   67cc80 <ducc0::detail_sht::detail_sht_inner_loop::alm2map_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double> const*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]>
  681724:	pop    %rax
  681725:	pop    %rdx
  681726:	jmp    681684 <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0x2c4>
  68172b:	mov    -0x40(%rbp),%r8
  68172f:	jmp    681705 <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0x345>
  681731:	mov    -0x40(%rbp),%r8
  681735:	jmp    6816b1 <ducc0::detail_sht::detail_sht_inner_loop::calc_alm2map(std::complex<double> const*, ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long, unsigned long, unsigned long)+0x2f1>
  68173a:	call   1cea0 <__stack_chk_fail@plt>
