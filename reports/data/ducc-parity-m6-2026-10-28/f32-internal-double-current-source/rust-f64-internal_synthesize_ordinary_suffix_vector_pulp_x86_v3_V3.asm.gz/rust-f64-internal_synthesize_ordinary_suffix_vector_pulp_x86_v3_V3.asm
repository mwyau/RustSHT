
/tmp/rustsht-m6-f32-internal-double-current-20261028-01/bin/rust-f64-internal:     file format elf64-x86-64


Disassembly of section .text:

00000000001d6f50 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>>:
  1d6f50:	push   %rbp
  1d6f51:	push   %r15
  1d6f53:	push   %r14
  1d6f55:	push   %r13
  1d6f57:	push   %r12
  1d6f59:	push   %rbx
  1d6f5a:	sub    $0x48,%rsp
  1d6f5e:	cmp    %rsi,%rcx
  1d6f61:	seta   %al
  1d6f64:	cmp    %rdx,%r8
  1d6f67:	setae  %cl
  1d6f6a:	or     %al,%cl
  1d6f6c:	mov    $0x1,%al
  1d6f6e:	jne    1d72d2 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x382>
  1d6f74:	mov    0x80(%rsp),%rsi
  1d6f7c:	mov    0x78(%rdi),%r10
  1d6f80:	mov    %rsi,%rcx
  1d6f83:	sub    %r9,%rcx
  1d6f86:	jb     1d72e4 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x394>
  1d6f8c:	cmp    %r10,%rsi
  1d6f8f:	ja     1d72e4 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x394>
  1d6f95:	cmp    $0x4,%rcx
  1d6f99:	jne    1d7204 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x2b4>
  1d6f9f:	mov    0x88(%rdi),%r10
  1d6fa6:	cmp    %r10,%rsi
  1d6fa9:	ja     1d72f7 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x3a7>
  1d6faf:	mov    0x98(%rdi),%r10
  1d6fb6:	cmp    %r10,%rsi
  1d6fb9:	ja     1d730a <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x3ba>
  1d6fbf:	mov    0xc8(%rdi),%r10
  1d6fc6:	cmp    %r10,%rsi
  1d6fc9:	ja     1d731d <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x3cd>
  1d6fcf:	mov    0xd8(%rdi),%r10
  1d6fd6:	cmp    %r10,%rsi
  1d6fd9:	ja     1d7330 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x3e0>
  1d6fdf:	mov    0xe8(%rdi),%r10
  1d6fe6:	cmp    %r10,%rsi
  1d6fe9:	ja     1d7343 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x3f3>
  1d6fef:	mov    0xf8(%rdi),%r10
  1d6ff6:	cmp    %r10,%rsi
  1d6ff9:	ja     1d7356 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x406>
  1d6fff:	mov    0x70(%rdi),%rbx
  1d7003:	mov    0x20(%rdi),%r15
  1d7007:	mov    0x28(%rdi),%r11
  1d700b:	mov    0x30(%rdi),%r12
  1d700f:	mov    0x38(%rdi),%r10
  1d7013:	mov    0x40(%rdi),%r13
  1d7017:	mov    0x48(%rdi),%rcx
  1d701b:	mov    0x50(%rdi),%rax
  1d701f:	mov    %rax,0x10(%rsp)
  1d7024:	mov    0x58(%rdi),%rsi
  1d7028:	vmovupd (%rbx,%r9,8),%ymm6
  1d702e:	mov    0x80(%rdi),%rax
  1d7035:	vmovupd (%rax,%r9,8),%ymm0
  1d703b:	mov    0x90(%rdi),%rbp
  1d7042:	vmovupd 0x0(%rbp,%r9,8),%ymm2
  1d7049:	mov    0xc0(%rdi),%rbx
  1d7050:	vmovupd (%rbx,%r9,8),%ymm1
  1d7056:	mov    0xd0(%rdi),%r14
  1d705d:	mov    %r14,0x8(%rsp)
  1d7062:	vmovupd (%r14,%r9,8),%ymm3
  1d7068:	mov    0xe0(%rdi),%r14
  1d706f:	mov    %r14,0x40(%rsp)
  1d7074:	vmovupd (%r14,%r9,8),%ymm4
  1d707a:	mov    0xf0(%rdi),%r14
  1d7081:	vmovupd (%r14,%r9,8),%ymm5
  1d7087:	lea    0x1(%r8),%rdi
  1d708b:	cmp    %rdx,%rdi
  1d708e:	mov    %r13,0x30(%rsp)
  1d7093:	mov    %r14,0x38(%rsp)
  1d7098:	jae    1d720b <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x2bb>
  1d709e:	mov    %rbx,0x18(%rsp)
  1d70a3:	mov    %rbp,0x20(%rsp)
  1d70a8:	mov    %rax,0x28(%rsp)
  1d70ad:	shl    $0x4,%r8
  1d70b1:	add    %r8,%r13
  1d70b4:	mov    0x10(%rsp),%rax
  1d70b9:	add    %rax,%r8
  1d70bc:	mov    $0x8,%ebp
  1d70c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1d70d0:	lea    -0x1(%rdi),%rbx
  1d70d4:	cmp    %r11,%rbx
  1d70d7:	jae    1d73f1 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x4a1>
  1d70dd:	cmp    %r10,%rbx
  1d70e0:	jae    1d73db <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x48b>
  1d70e6:	cmp    %r11,%rdi
  1d70e9:	jae    1d73c8 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x478>
  1d70ef:	cmp    %r10,%rdi
  1d70f2:	jae    1d73b5 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x465>
  1d70f8:	cmp    %rcx,%rbx
  1d70fb:	jae    1d739f <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x44f>
  1d7101:	cmp    %rsi,%rbx
  1d7104:	jae    1d738c <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x43c>
  1d710a:	cmp    %rcx,%rdi
  1d710d:	jae    1d7379 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x429>
  1d7113:	cmp    %rsi,%rdi
  1d7116:	jae    1d7369 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x419>
  1d711c:	vmovsd -0x8(%r15,%rdi,8),%xmm7
  1d7123:	vmovsd -0x10(%r13,%rbp,2),%xmm8
  1d712a:	vbroadcastsd %xmm8,%ymm8
  1d712f:	vfmadd231pd %ymm8,%ymm2,%ymm1
  1d7134:	vmovsd -0x8(%r13,%rbp,2),%xmm8
  1d713b:	vbroadcastsd %xmm8,%ymm8
  1d7140:	vfmadd231pd %ymm8,%ymm2,%ymm3
  1d7145:	vmovsd -0x10(%r8,%rbp,2),%xmm8
  1d714c:	vbroadcastsd %xmm8,%ymm8
  1d7151:	vfmadd231pd %ymm8,%ymm2,%ymm4
  1d7156:	vmovsd -0x8(%r8,%rbp,2),%xmm8
  1d715d:	vbroadcastsd %xmm8,%ymm8
  1d7162:	vfmadd231pd %ymm8,%ymm2,%ymm5
  1d7167:	vmovsd -0x8(%r12,%rdi,8),%xmm8
  1d716e:	vbroadcastsd %xmm7,%ymm7
  1d7173:	vbroadcastsd %xmm8,%ymm8
  1d7178:	vfmadd231pd %ymm7,%ymm6,%ymm8
  1d717d:	vmovsd (%r15,%rdi,8),%xmm7
  1d7183:	vfmadd231pd %ymm8,%ymm2,%ymm0
  1d7188:	vbroadcastsd 0x0(%r13,%rbp,2),%ymm8
  1d718f:	vfmadd231pd %ymm8,%ymm0,%ymm1
  1d7194:	vbroadcastsd 0x8(%r13,%rbp,2),%ymm8
  1d719b:	vfmadd231pd %ymm8,%ymm0,%ymm3
  1d71a0:	vbroadcastsd (%r8,%rbp,2),%ymm8
  1d71a6:	vfmadd231pd %ymm8,%ymm0,%ymm4
  1d71ab:	vbroadcastsd 0x8(%r8,%rbp,2),%ymm8
  1d71b2:	vfmadd231pd %ymm8,%ymm0,%ymm5
  1d71b7:	vmovsd (%r12,%rdi,8),%xmm8
  1d71bd:	vbroadcastsd %xmm7,%ymm7
  1d71c2:	vbroadcastsd %xmm8,%ymm8
  1d71c7:	vfmadd231pd %ymm7,%ymm6,%ymm8
  1d71cc:	vfmadd231pd %ymm8,%ymm0,%ymm2
  1d71d1:	add    $0x2,%rdi
  1d71d5:	add    $0x10,%rbp
  1d71d9:	cmp    %rdx,%rdi
  1d71dc:	jb     1d70d0 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x180>
  1d71e2:	mov    %rax,%r14
  1d71e5:	dec    %rdi
  1d71e8:	mov    %rdi,%r8
  1d71eb:	mov    0x28(%rsp),%rax
  1d71f0:	mov    0x20(%rsp),%rbp
  1d71f5:	mov    0x18(%rsp),%rbx
  1d71fa:	cmp    %rdx,%r8
  1d71fd:	jb     1d7219 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x2c9>
  1d71ff:	jmp    1d729c <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x34c>
  1d7204:	xor    %eax,%eax
  1d7206:	jmp    1d72d2 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x382>
  1d720b:	mov    0x10(%rsp),%r14
  1d7210:	cmp    %rdx,%r8
  1d7213:	jae    1d729c <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x34c>
  1d7219:	cmp    %r11,%r8
  1d721c:	jae    1d7407 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x4b7>
  1d7222:	cmp    %r10,%r8
  1d7225:	jae    1d741d <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x4cd>
  1d722b:	cmp    %rcx,%r8
  1d722e:	jae    1d7433 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x4e3>
  1d7234:	cmp    %rsi,%r8
  1d7237:	mov    0x30(%rsp),%rcx
  1d723c:	jae    1d7449 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x4f9>
  1d7242:	vmovsd (%r15,%r8,8),%xmm7
  1d7248:	vmovsd (%r12,%r8,8),%xmm8
  1d724e:	shl    $0x4,%r8
  1d7252:	vbroadcastsd %xmm7,%ymm7
  1d7257:	vbroadcastsd %xmm8,%ymm8
  1d725c:	vbroadcastsd (%rcx,%r8,1),%ymm9
  1d7262:	vbroadcastsd 0x8(%rcx,%r8,1),%ymm10
  1d7269:	vbroadcastsd (%r14,%r8,1),%ymm11
  1d726f:	vbroadcastsd 0x8(%r14,%r8,1),%ymm12
  1d7276:	vfmadd231pd %ymm9,%ymm2,%ymm1
  1d727b:	vfmadd231pd %ymm10,%ymm2,%ymm3
  1d7280:	vfmadd231pd %ymm11,%ymm2,%ymm4
  1d7285:	vfmadd231pd %ymm12,%ymm2,%ymm5
  1d728a:	vfmadd213pd %ymm8,%ymm7,%ymm6
  1d728f:	vfmadd213pd %ymm0,%ymm2,%ymm6
  1d7294:	vmovapd %ymm2,%ymm0
  1d7298:	vmovapd %ymm6,%ymm2
  1d729c:	mov    0x8(%rsp),%rcx
  1d72a1:	vmovupd %ymm0,(%rax,%r9,8)
  1d72a7:	vmovupd %ymm2,0x0(%rbp,%r9,8)
  1d72ae:	vmovupd %ymm1,(%rbx,%r9,8)
  1d72b4:	vmovupd %ymm3,(%rcx,%r9,8)
  1d72ba:	mov    0x40(%rsp),%rcx
  1d72bf:	vmovupd %ymm4,(%rcx,%r9,8)
  1d72c5:	mov    0x38(%rsp),%rax
  1d72ca:	vmovupd %ymm5,(%rax,%r9,8)
  1d72d0:	mov    $0x1,%al
  1d72d2:	add    $0x48,%rsp
  1d72d6:	pop    %rbx
  1d72d7:	pop    %r12
  1d72d9:	pop    %r13
  1d72db:	pop    %r14
  1d72dd:	pop    %r15
  1d72df:	pop    %rbp
  1d72e0:	vzeroupper
  1d72e3:	ret
  1d72e4:	lea    0xc7dcd(%rip),%rcx        # 29f0b8 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x1c8>
  1d72eb:	mov    %r9,%rdi
  1d72ee:	mov    %r10,%rdx
  1d72f1:	call   *0xce571(%rip)        # 2a5868 <_DYNAMIC+0x348>
  1d72f7:	lea    0xc7c0a(%rip),%rcx        # 29ef08 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x18>
  1d72fe:	mov    %r9,%rdi
  1d7301:	mov    %r10,%rdx
  1d7304:	call   *0xce55e(%rip)        # 2a5868 <_DYNAMIC+0x348>
  1d730a:	lea    0xc7c0f(%rip),%rcx        # 29ef20 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x30>
  1d7311:	mov    %r9,%rdi
  1d7314:	mov    %r10,%rdx
  1d7317:	call   *0xce54b(%rip)        # 2a5868 <_DYNAMIC+0x348>
  1d731d:	lea    0xc7c14(%rip),%rcx        # 29ef38 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x48>
  1d7324:	mov    %r9,%rdi
  1d7327:	mov    %r10,%rdx
  1d732a:	call   *0xce538(%rip)        # 2a5868 <_DYNAMIC+0x348>
  1d7330:	lea    0xc7c19(%rip),%rcx        # 29ef50 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x60>
  1d7337:	mov    %r9,%rdi
  1d733a:	mov    %r10,%rdx
  1d733d:	call   *0xce525(%rip)        # 2a5868 <_DYNAMIC+0x348>
  1d7343:	lea    0xc7c1e(%rip),%rcx        # 29ef68 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x78>
  1d734a:	mov    %r9,%rdi
  1d734d:	mov    %r10,%rdx
  1d7350:	call   *0xce512(%rip)        # 2a5868 <_DYNAMIC+0x348>
  1d7356:	lea    0xc7c23(%rip),%rcx        # 29ef80 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x90>
  1d735d:	mov    %r9,%rdi
  1d7360:	mov    %r10,%rdx
  1d7363:	call   *0xce4ff(%rip)        # 2a5868 <_DYNAMIC+0x348>
  1d7369:	lea    0xc7d30(%rip),%rdx        # 29f0a0 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x1b0>
  1d7370:	vzeroupper
  1d7373:	call   *0xce45f(%rip)        # 2a57d8 <_DYNAMIC+0x2b8>
  1d7379:	lea    0xc7d08(%rip),%rdx        # 29f088 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x198>
  1d7380:	mov    %rcx,%rsi
  1d7383:	vzeroupper
  1d7386:	call   *0xce44c(%rip)        # 2a57d8 <_DYNAMIC+0x2b8>
  1d738c:	lea    0xc7cdd(%rip),%rdx        # 29f070 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x180>
  1d7393:	mov    %rbx,%rdi
  1d7396:	vzeroupper
  1d7399:	call   *0xce439(%rip)        # 2a57d8 <_DYNAMIC+0x2b8>
  1d739f:	lea    0xc7cb2(%rip),%rdx        # 29f058 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x168>
  1d73a6:	mov    %rbx,%rdi
  1d73a9:	mov    %rcx,%rsi
  1d73ac:	vzeroupper
  1d73af:	call   *0xce423(%rip)        # 2a57d8 <_DYNAMIC+0x2b8>
  1d73b5:	lea    0xc7c84(%rip),%rdx        # 29f040 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x150>
  1d73bc:	mov    %r10,%rsi
  1d73bf:	vzeroupper
  1d73c2:	call   *0xce410(%rip)        # 2a57d8 <_DYNAMIC+0x2b8>
  1d73c8:	lea    0xc7c59(%rip),%rdx        # 29f028 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x138>
  1d73cf:	mov    %r11,%rsi
  1d73d2:	vzeroupper
  1d73d5:	call   *0xce3fd(%rip)        # 2a57d8 <_DYNAMIC+0x2b8>
  1d73db:	lea    0xc7c2e(%rip),%rdx        # 29f010 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x120>
  1d73e2:	mov    %rbx,%rdi
  1d73e5:	mov    %r10,%rsi
  1d73e8:	vzeroupper
  1d73eb:	call   *0xce3e7(%rip)        # 2a57d8 <_DYNAMIC+0x2b8>
  1d73f1:	lea    0xc7c00(%rip),%rdx        # 29eff8 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x108>
  1d73f8:	mov    %rbx,%rdi
  1d73fb:	mov    %r11,%rsi
  1d73fe:	vzeroupper
  1d7401:	call   *0xce3d1(%rip)        # 2a57d8 <_DYNAMIC+0x2b8>
  1d7407:	lea    0xc7b8a(%rip),%rdx        # 29ef98 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0xa8>
  1d740e:	mov    %r8,%rdi
  1d7411:	mov    %r11,%rsi
  1d7414:	vzeroupper
  1d7417:	call   *0xce3bb(%rip)        # 2a57d8 <_DYNAMIC+0x2b8>
  1d741d:	lea    0xc7b8c(%rip),%rdx        # 29efb0 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0xc0>
  1d7424:	mov    %r8,%rdi
  1d7427:	mov    %r10,%rsi
  1d742a:	vzeroupper
  1d742d:	call   *0xce3a5(%rip)        # 2a57d8 <_DYNAMIC+0x2b8>
  1d7433:	lea    0xc7b8e(%rip),%rdx        # 29efc8 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0xd8>
  1d743a:	mov    %r8,%rdi
  1d743d:	mov    %rcx,%rsi
  1d7440:	vzeroupper
  1d7443:	call   *0xce38f(%rip)        # 2a57d8 <_DYNAMIC+0x2b8>
  1d7449:	lea    0xc7b90(%rip),%rdx        # 29efe0 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0xf0>
  1d7450:	mov    %r8,%rdi
  1d7453:	vzeroupper
  1d7456:	call   *0xce37c(%rip)        # 2a57d8 <_DYNAMIC+0x2b8>
