
/tmp/rustsht-m6-f32-internal-double-current-20261028-01/bin/ducc-f32:     file format elf64-x86-64


Disassembly of section .text:

0000000000680d90 <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]>:
  680d90:	push   %rbp
  680d91:	mov    %r9,%r10
  680d94:	mov    %rsi,%r11
  680d97:	mov    %rsp,%rbp
  680d9a:	push   %r14
  680d9c:	push   %r13
  680d9e:	mov    %rdi,%r13
  680da1:	push   %r12
  680da3:	mov    %rcx,%r12
  680da6:	mov    %r8,%rcx
  680da9:	mov    0x10(%rbp),%r8
  680dad:	push   %rbx
  680dae:	sub    0xc0(%rdi),%r10
  680db5:	mov    %rdx,%rbx
  680db8:	shr    $1,%r10
  680dbb:	test   %rcx,%rcx
  680dbe:	je     680e89 <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0xf9>
  680dc4:	mov    %rcx,%rdi
  680dc7:	mov    %rsi,%rax
  680dca:	vpcmpeqd %ymm6,%ymm6,%ymm6
  680dce:	mov    $0x1,%edx
  680dd3:	vbroadcastsd 0x1a3444(%rip),%ymm3        # 824220 <_IO_stdin_used+0x2f220>
  680ddc:	shl    $0x5,%rdi
  680de0:	vbroadcastsd 0x1a3797(%rip),%ymm2        # 824580 <_IO_stdin_used+0x2f580>
  680de9:	vbroadcastsd 0x1a34ae(%rip),%ymm5        # 8242a0 <_IO_stdin_used+0x2f2a0>
  680df2:	add    %rsi,%rdi
  680df5:	vbroadcastsd 0x1a3742(%rip),%ymm7        # 824540 <_IO_stdin_used+0x2f540>
  680dfe:	jmp    680e21 <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0x91>
  680e00:	vmovapd 0x1000(%rax),%ymm0
  680e08:	vcmpltpd %ymm5,%ymm0,%ymm0
  680e0d:	vtestpd %ymm6,%ymm0
  680e12:	setb   %sil
  680e16:	add    $0x20,%rax
  680e1a:	and    %esi,%edx
  680e1c:	cmp    %rax,%rdi
  680e1f:	je     680e81 <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0xf1>
  680e21:	vmovapd 0x2000(%rax),%ymm1
  680e29:	vandpd %ymm3,%ymm1,%ymm0
  680e2d:	vcmpltpd %ymm0,%ymm2,%ymm0
  680e32:	vtestpd %ymm0,%ymm0
  680e37:	je     680e00 <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0x70>
  680e39:	vmovapd 0x1800(%rax),%ymm4
  680e41:	vmulpd %ymm7,%ymm4,%ymm8
  680e45:	vblendvpd %ymm0,%ymm8,%ymm4,%ymm4
  680e4b:	vmovapd %ymm4,0x1800(%rax)
  680e53:	vmulpd %ymm7,%ymm1,%ymm4
  680e57:	vblendvpd %ymm0,%ymm4,%ymm1,%ymm1
  680e5d:	vmovapd %ymm1,0x2000(%rax)
  680e65:	vmovapd 0x1000(%rax),%ymm1
  680e6d:	vaddpd %ymm5,%ymm1,%ymm4
  680e71:	vblendvpd %ymm0,%ymm4,%ymm1,%ymm0
  680e77:	vmovapd %ymm0,0x1000(%rax)
  680e7f:	jmp    680e08 <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0x78>
  680e81:	test   %dl,%dl
  680e83:	je     68100f <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0x27f>
  680e89:	cmp    %r8,%r9
  680e8c:	je     68100f <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0x27f>
  680e92:	mov    0x0(%r13),%r14
  680e96:	add    $0x4,%r9
  680e9a:	cmp    %r9,%r14
  680e9d:	jb     680fea <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0x25a>
  680ea3:	test   %rcx,%rcx
  680ea6:	je     681006 <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0x276>
  680eac:	mov    %r10,%rdi
  680eaf:	shl    $0x5,%rcx
  680eb3:	vbroadcastsd 0x1a3364(%rip),%ymm3        # 824220 <_IO_stdin_used+0x2f220>
  680ebc:	vbroadcastsd 0x1a36bb(%rip),%ymm2        # 824580 <_IO_stdin_used+0x2f580>
  680ec5:	mov    0xe0(%r13),%r13
  680ecc:	shl    $0x4,%rdi
  680ed0:	add    %r11,%rcx
  680ed3:	vpcmpeqd %ymm10,%ymm10,%ymm10
  680ed8:	vbroadcastsd 0x1a365f(%rip),%ymm9        # 824540 <_IO_stdin_used+0x2f540>
  680ee1:	vbroadcastsd 0x1a33b6(%rip),%ymm8        # 8242a0 <_IO_stdin_used+0x2f2a0>
  680eea:	nopw   0x0(%rax,%rax,1)
  680ef0:	lea    0x0(%r13,%rdi,1),%rax
  680ef5:	mov    $0x1,%edx
  680efa:	vbroadcastsd (%rax),%ymm7
  680eff:	vbroadcastsd 0x8(%rax),%ymm6
  680f05:	lea    0x10(%r13,%rdi,1),%rax
  680f0a:	vbroadcastsd (%rax),%ymm5
  680f0f:	vbroadcastsd 0x8(%rax),%ymm4
  680f15:	mov    %r11,%rax
  680f18:	nopl   0x0(%rax,%rax,1)
  680f20:	vmovapd 0x2800(%rax),%ymm0
  680f28:	vmovapd %ymm7,%ymm1
  680f2c:	vmovapd 0x2000(%rax),%ymm11
  680f34:	vfmadd132pd %ymm0,%ymm6,%ymm1
  680f39:	vfmadd132pd %ymm5,%ymm4,%ymm0
  680f3e:	vfmadd213pd 0x1800(%rax),%ymm11,%ymm1
  680f47:	vfmadd132pd %ymm1,%ymm11,%ymm0
  680f4c:	vmovapd %ymm1,0x1800(%rax)
  680f54:	vandpd %ymm3,%ymm0,%ymm11
  680f58:	vmovapd %ymm0,0x2000(%rax)
  680f60:	vcmpltpd %ymm11,%ymm2,%ymm11
  680f66:	vtestpd %ymm11,%ymm11
  680f6b:	je     680fbf <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0x22f>
  680f6d:	vmulpd %ymm9,%ymm1,%ymm12
  680f72:	vblendvpd %ymm11,%ymm12,%ymm1,%ymm1
  680f78:	vmovapd %ymm1,0x1800(%rax)
  680f80:	vmulpd %ymm9,%ymm0,%ymm1
  680f85:	vblendvpd %ymm11,%ymm1,%ymm0,%ymm0
  680f8b:	vmovapd %ymm0,0x2000(%rax)
  680f93:	vmovapd 0x1000(%rax),%ymm0
  680f9b:	vaddpd %ymm8,%ymm0,%ymm1
  680fa0:	vblendvpd %ymm11,%ymm1,%ymm0,%ymm0
  680fa6:	vmovapd %ymm0,0x1000(%rax)
  680fae:	vcmpltpd %ymm8,%ymm0,%ymm0
  680fb4:	vtestpd %ymm10,%ymm0
  680fb9:	setb   %sil
  680fbd:	and    %esi,%edx
  680fbf:	add    $0x20,%rax
  680fc3:	cmp    %rax,%rcx
  680fc6:	jne    680f20 <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0x190>
  680fcc:	add    $0x2,%r10
  680fd0:	test   %dl,%dl
  680fd2:	je     68100f <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0x27f>
  680fd4:	cmp    %r9,%r8
  680fd7:	je     68100f <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0x27f>
  680fd9:	add    $0x4,%r9
  680fdd:	add    $0x20,%rdi
  680fe1:	cmp    %r9,%r14
  680fe4:	jae    680ef0 <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0x160>
  680fea:	add    $0x1,%r14
  680fee:	mov    %r14,(%rbx)
  680ff1:	vzeroupper
  680ff4:	pop    %rbx
  680ff5:	pop    %r12
  680ff7:	pop    %r13
  680ff9:	pop    %r14
  680ffb:	pop    %rbp
  680ffc:	ret
  680ffd:	add    $0x4,%r9
  681001:	cmp    %r9,%r14
  681004:	jb     680fea <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0x25a>
  681006:	add    $0x2,%r10
  68100a:	cmp    %r9,%r8
  68100d:	jne    680ffd <ducc0::detail_sht::detail_sht_inner_loop::iter_to_ieee(ducc0::detail_sht::detail_sht_inner_loop::Ylmgen const&, ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, unsigned long&, unsigned long&, unsigned long, unsigned long, unsigned long) [clone .constprop.0]+0x26d>
  68100f:	mov    %r9,(%rbx)
  681012:	mov    %r10,(%r12)
  681016:	vzeroupper
  681019:	pop    %rbx
  68101a:	pop    %r12
  68101c:	pop    %r13
  68101e:	pop    %r14
  681020:	pop    %rbp
  681021:	ret
