
/tmp/rustsht-m6-scalar-pair-20261029-5j52VV/target-callgrind-parent/release/examples/ducc_f32_full_transform_parity:     file format elf64-x86-64


Disassembly of section .text:

00000000002c4770 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>>:
  2c4770:	55                   	push   %rbp
  2c4771:	41 57                	push   %r15
  2c4773:	41 56                	push   %r14
  2c4775:	41 55                	push   %r13
  2c4777:	41 54                	push   %r12
  2c4779:	53                   	push   %rbx
  2c477a:	48 83 ec 48          	sub    $0x48,%rsp
  2c477e:	48 39 f1             	cmp    %rsi,%rcx
  2c4781:	0f 97 c0             	seta   %al
  2c4784:	49 39 d0             	cmp    %rdx,%r8
  2c4787:	0f 93 c1             	setae  %cl
  2c478a:	08 c1                	or     %al,%cl
  2c478c:	b0 01                	mov    $0x1,%al
  2c478e:	0f 85 5e 03 00 00    	jne    2c4af2 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x382>
  2c4794:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  2c479b:	00 
  2c479c:	4c 8b 57 78          	mov    0x78(%rdi),%r10
  2c47a0:	48 89 f1             	mov    %rsi,%rcx
  2c47a3:	4c 29 c9             	sub    %r9,%rcx
  2c47a6:	0f 82 58 03 00 00    	jb     2c4b04 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x394>
  2c47ac:	4c 39 d6             	cmp    %r10,%rsi
  2c47af:	0f 87 4f 03 00 00    	ja     2c4b04 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x394>
  2c47b5:	48 83 f9 04          	cmp    $0x4,%rcx
  2c47b9:	0f 85 65 02 00 00    	jne    2c4a24 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x2b4>
  2c47bf:	4c 8b 97 88 00 00 00 	mov    0x88(%rdi),%r10
  2c47c6:	4c 39 d6             	cmp    %r10,%rsi
  2c47c9:	0f 87 48 03 00 00    	ja     2c4b17 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x3a7>
  2c47cf:	4c 8b 97 98 00 00 00 	mov    0x98(%rdi),%r10
  2c47d6:	4c 39 d6             	cmp    %r10,%rsi
  2c47d9:	0f 87 4b 03 00 00    	ja     2c4b2a <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x3ba>
  2c47df:	4c 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%r10
  2c47e6:	4c 39 d6             	cmp    %r10,%rsi
  2c47e9:	0f 87 4e 03 00 00    	ja     2c4b3d <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x3cd>
  2c47ef:	4c 8b 97 d8 00 00 00 	mov    0xd8(%rdi),%r10
  2c47f6:	4c 39 d6             	cmp    %r10,%rsi
  2c47f9:	0f 87 51 03 00 00    	ja     2c4b50 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x3e0>
  2c47ff:	4c 8b 97 e8 00 00 00 	mov    0xe8(%rdi),%r10
  2c4806:	4c 39 d6             	cmp    %r10,%rsi
  2c4809:	0f 87 54 03 00 00    	ja     2c4b63 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x3f3>
  2c480f:	4c 8b 97 f8 00 00 00 	mov    0xf8(%rdi),%r10
  2c4816:	4c 39 d6             	cmp    %r10,%rsi
  2c4819:	0f 87 57 03 00 00    	ja     2c4b76 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x406>
  2c481f:	48 8b 5f 70          	mov    0x70(%rdi),%rbx
  2c4823:	4c 8b 7f 20          	mov    0x20(%rdi),%r15
  2c4827:	4c 8b 5f 28          	mov    0x28(%rdi),%r11
  2c482b:	4c 8b 67 30          	mov    0x30(%rdi),%r12
  2c482f:	4c 8b 57 38          	mov    0x38(%rdi),%r10
  2c4833:	4c 8b 6f 40          	mov    0x40(%rdi),%r13
  2c4837:	48 8b 4f 48          	mov    0x48(%rdi),%rcx
  2c483b:	48 8b 47 50          	mov    0x50(%rdi),%rax
  2c483f:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  2c4844:	48 8b 77 58          	mov    0x58(%rdi),%rsi
  2c4848:	c4 a1 7d 10 34 cb    	vmovupd (%rbx,%r9,8),%ymm6
  2c484e:	48 8b 87 80 00 00 00 	mov    0x80(%rdi),%rax
  2c4855:	c4 a1 7d 10 04 c8    	vmovupd (%rax,%r9,8),%ymm0
  2c485b:	48 8b af 90 00 00 00 	mov    0x90(%rdi),%rbp
  2c4862:	c4 a1 7d 10 54 cd 00 	vmovupd 0x0(%rbp,%r9,8),%ymm2
  2c4869:	48 8b 9f c0 00 00 00 	mov    0xc0(%rdi),%rbx
  2c4870:	c4 a1 7d 10 0c cb    	vmovupd (%rbx,%r9,8),%ymm1
  2c4876:	4c 8b b7 d0 00 00 00 	mov    0xd0(%rdi),%r14
  2c487d:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
  2c4882:	c4 81 7d 10 1c ce    	vmovupd (%r14,%r9,8),%ymm3
  2c4888:	4c 8b b7 e0 00 00 00 	mov    0xe0(%rdi),%r14
  2c488f:	4c 89 74 24 40       	mov    %r14,0x40(%rsp)
  2c4894:	c4 81 7d 10 24 ce    	vmovupd (%r14,%r9,8),%ymm4
  2c489a:	4c 8b b7 f0 00 00 00 	mov    0xf0(%rdi),%r14
  2c48a1:	c4 81 7d 10 2c ce    	vmovupd (%r14,%r9,8),%ymm5
  2c48a7:	49 8d 78 01          	lea    0x1(%r8),%rdi
  2c48ab:	48 39 d7             	cmp    %rdx,%rdi
  2c48ae:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
  2c48b3:	4c 89 74 24 38       	mov    %r14,0x38(%rsp)
  2c48b8:	0f 83 6d 01 00 00    	jae    2c4a2b <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x2bb>
  2c48be:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
  2c48c3:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
  2c48c8:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  2c48cd:	49 c1 e0 04          	shl    $0x4,%r8
  2c48d1:	4d 01 c5             	add    %r8,%r13
  2c48d4:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  2c48d9:	49 01 c0             	add    %rax,%r8
  2c48dc:	bd 08 00 00 00       	mov    $0x8,%ebp
  2c48e1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  2c48e8:	0f 1f 84 00 00 00 00 
  2c48ef:	00 
  2c48f0:	48 8d 5f ff          	lea    -0x1(%rdi),%rbx
  2c48f4:	4c 39 db             	cmp    %r11,%rbx
  2c48f7:	0f 83 14 03 00 00    	jae    2c4c11 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x4a1>
  2c48fd:	4c 39 d3             	cmp    %r10,%rbx
  2c4900:	0f 83 f5 02 00 00    	jae    2c4bfb <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x48b>
  2c4906:	4c 39 df             	cmp    %r11,%rdi
  2c4909:	0f 83 d9 02 00 00    	jae    2c4be8 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x478>
  2c490f:	4c 39 d7             	cmp    %r10,%rdi
  2c4912:	0f 83 bd 02 00 00    	jae    2c4bd5 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x465>
  2c4918:	48 39 cb             	cmp    %rcx,%rbx
  2c491b:	0f 83 9e 02 00 00    	jae    2c4bbf <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x44f>
  2c4921:	48 39 f3             	cmp    %rsi,%rbx
  2c4924:	0f 83 82 02 00 00    	jae    2c4bac <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x43c>
  2c492a:	48 39 cf             	cmp    %rcx,%rdi
  2c492d:	0f 83 66 02 00 00    	jae    2c4b99 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x429>
  2c4933:	48 39 f7             	cmp    %rsi,%rdi
  2c4936:	0f 83 4d 02 00 00    	jae    2c4b89 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x419>
  2c493c:	c4 c1 7b 10 7c ff f8 	vmovsd -0x8(%r15,%rdi,8),%xmm7
  2c4943:	c4 41 7b 10 44 6d f0 	vmovsd -0x10(%r13,%rbp,2),%xmm8
  2c494a:	c4 42 7d 19 c0       	vbroadcastsd %xmm8,%ymm8
  2c494f:	c4 c2 ed b8 c8       	vfmadd231pd %ymm8,%ymm2,%ymm1
  2c4954:	c4 41 7b 10 44 6d f8 	vmovsd -0x8(%r13,%rbp,2),%xmm8
  2c495b:	c4 42 7d 19 c0       	vbroadcastsd %xmm8,%ymm8
  2c4960:	c4 c2 ed b8 d8       	vfmadd231pd %ymm8,%ymm2,%ymm3
  2c4965:	c4 41 7b 10 44 68 f0 	vmovsd -0x10(%r8,%rbp,2),%xmm8
  2c496c:	c4 42 7d 19 c0       	vbroadcastsd %xmm8,%ymm8
  2c4971:	c4 c2 ed b8 e0       	vfmadd231pd %ymm8,%ymm2,%ymm4
  2c4976:	c4 41 7b 10 44 68 f8 	vmovsd -0x8(%r8,%rbp,2),%xmm8
  2c497d:	c4 42 7d 19 c0       	vbroadcastsd %xmm8,%ymm8
  2c4982:	c4 c2 ed b8 e8       	vfmadd231pd %ymm8,%ymm2,%ymm5
  2c4987:	c4 41 7b 10 44 fc f8 	vmovsd -0x8(%r12,%rdi,8),%xmm8
  2c498e:	c4 e2 7d 19 ff       	vbroadcastsd %xmm7,%ymm7
  2c4993:	c4 42 7d 19 c0       	vbroadcastsd %xmm8,%ymm8
  2c4998:	c4 62 cd b8 c7       	vfmadd231pd %ymm7,%ymm6,%ymm8
  2c499d:	c4 c1 7b 10 3c ff    	vmovsd (%r15,%rdi,8),%xmm7
  2c49a3:	c4 c2 ed b8 c0       	vfmadd231pd %ymm8,%ymm2,%ymm0
  2c49a8:	c4 42 7d 19 44 6d 00 	vbroadcastsd 0x0(%r13,%rbp,2),%ymm8
  2c49af:	c4 c2 fd b8 c8       	vfmadd231pd %ymm8,%ymm0,%ymm1
  2c49b4:	c4 42 7d 19 44 6d 08 	vbroadcastsd 0x8(%r13,%rbp,2),%ymm8
  2c49bb:	c4 c2 fd b8 d8       	vfmadd231pd %ymm8,%ymm0,%ymm3
  2c49c0:	c4 42 7d 19 04 68    	vbroadcastsd (%r8,%rbp,2),%ymm8
  2c49c6:	c4 c2 fd b8 e0       	vfmadd231pd %ymm8,%ymm0,%ymm4
  2c49cb:	c4 42 7d 19 44 68 08 	vbroadcastsd 0x8(%r8,%rbp,2),%ymm8
  2c49d2:	c4 c2 fd b8 e8       	vfmadd231pd %ymm8,%ymm0,%ymm5
  2c49d7:	c4 41 7b 10 04 fc    	vmovsd (%r12,%rdi,8),%xmm8
  2c49dd:	c4 e2 7d 19 ff       	vbroadcastsd %xmm7,%ymm7
  2c49e2:	c4 42 7d 19 c0       	vbroadcastsd %xmm8,%ymm8
  2c49e7:	c4 62 cd b8 c7       	vfmadd231pd %ymm7,%ymm6,%ymm8
  2c49ec:	c4 c2 fd b8 d0       	vfmadd231pd %ymm8,%ymm0,%ymm2
  2c49f1:	48 83 c7 02          	add    $0x2,%rdi
  2c49f5:	48 83 c5 10          	add    $0x10,%rbp
  2c49f9:	48 39 d7             	cmp    %rdx,%rdi
  2c49fc:	0f 82 ee fe ff ff    	jb     2c48f0 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x180>
  2c4a02:	49 89 c6             	mov    %rax,%r14
  2c4a05:	48 ff cf             	dec    %rdi
  2c4a08:	49 89 f8             	mov    %rdi,%r8
  2c4a0b:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  2c4a10:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  2c4a15:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  2c4a1a:	49 39 d0             	cmp    %rdx,%r8
  2c4a1d:	72 1a                	jb     2c4a39 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x2c9>
  2c4a1f:	e9 98 00 00 00       	jmp    2c4abc <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x34c>
  2c4a24:	31 c0                	xor    %eax,%eax
  2c4a26:	e9 c7 00 00 00       	jmp    2c4af2 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x382>
  2c4a2b:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  2c4a30:	49 39 d0             	cmp    %rdx,%r8
  2c4a33:	0f 83 83 00 00 00    	jae    2c4abc <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x34c>
  2c4a39:	4d 39 d8             	cmp    %r11,%r8
  2c4a3c:	0f 83 e5 01 00 00    	jae    2c4c27 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x4b7>
  2c4a42:	4d 39 d0             	cmp    %r10,%r8
  2c4a45:	0f 83 f2 01 00 00    	jae    2c4c3d <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x4cd>
  2c4a4b:	49 39 c8             	cmp    %rcx,%r8
  2c4a4e:	0f 83 ff 01 00 00    	jae    2c4c53 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x4e3>
  2c4a54:	49 39 f0             	cmp    %rsi,%r8
  2c4a57:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  2c4a5c:	0f 83 07 02 00 00    	jae    2c4c69 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x4f9>
  2c4a62:	c4 81 7b 10 3c c7    	vmovsd (%r15,%r8,8),%xmm7
  2c4a68:	c4 01 7b 10 04 c4    	vmovsd (%r12,%r8,8),%xmm8
  2c4a6e:	49 c1 e0 04          	shl    $0x4,%r8
  2c4a72:	c4 e2 7d 19 ff       	vbroadcastsd %xmm7,%ymm7
  2c4a77:	c4 42 7d 19 c0       	vbroadcastsd %xmm8,%ymm8
  2c4a7c:	c4 22 7d 19 0c 01    	vbroadcastsd (%rcx,%r8,1),%ymm9
  2c4a82:	c4 22 7d 19 54 01 08 	vbroadcastsd 0x8(%rcx,%r8,1),%ymm10
  2c4a89:	c4 02 7d 19 1c 06    	vbroadcastsd (%r14,%r8,1),%ymm11
  2c4a8f:	c4 02 7d 19 64 06 08 	vbroadcastsd 0x8(%r14,%r8,1),%ymm12
  2c4a96:	c4 c2 ed b8 c9       	vfmadd231pd %ymm9,%ymm2,%ymm1
  2c4a9b:	c4 c2 ed b8 da       	vfmadd231pd %ymm10,%ymm2,%ymm3
  2c4aa0:	c4 c2 ed b8 e3       	vfmadd231pd %ymm11,%ymm2,%ymm4
  2c4aa5:	c4 c2 ed b8 ec       	vfmadd231pd %ymm12,%ymm2,%ymm5
  2c4aaa:	c4 c2 c5 a8 f0       	vfmadd213pd %ymm8,%ymm7,%ymm6
  2c4aaf:	c4 e2 ed a8 f0       	vfmadd213pd %ymm0,%ymm2,%ymm6
  2c4ab4:	c5 fd 28 c2          	vmovapd %ymm2,%ymm0
  2c4ab8:	c5 fd 28 d6          	vmovapd %ymm6,%ymm2
  2c4abc:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  2c4ac1:	c4 a1 7d 11 04 c8    	vmovupd %ymm0,(%rax,%r9,8)
  2c4ac7:	c4 a1 7d 11 54 cd 00 	vmovupd %ymm2,0x0(%rbp,%r9,8)
  2c4ace:	c4 a1 7d 11 0c cb    	vmovupd %ymm1,(%rbx,%r9,8)
  2c4ad4:	c4 a1 7d 11 1c c9    	vmovupd %ymm3,(%rcx,%r9,8)
  2c4ada:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  2c4adf:	c4 a1 7d 11 24 c9    	vmovupd %ymm4,(%rcx,%r9,8)
  2c4ae5:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  2c4aea:	c4 a1 7d 11 2c c8    	vmovupd %ymm5,(%rax,%r9,8)
  2c4af0:	b0 01                	mov    $0x1,%al
  2c4af2:	48 83 c4 48          	add    $0x48,%rsp
  2c4af6:	5b                   	pop    %rbx
  2c4af7:	41 5c                	pop    %r12
  2c4af9:	41 5d                	pop    %r13
  2c4afb:	41 5e                	pop    %r14
  2c4afd:	41 5f                	pop    %r15
  2c4aff:	5d                   	pop    %rbp
  2c4b00:	c5 f8 77             	vzeroupper
  2c4b03:	c3                   	ret
  2c4b04:	48 8d 0d 65 45 0a 00 	lea    0xa4565(%rip),%rcx        # 369070 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x1c8>
  2c4b0b:	4c 89 cf             	mov    %r9,%rdi
  2c4b0e:	4c 89 d2             	mov    %r10,%rdx
  2c4b11:	ff 15 11 d8 0a 00    	call   *0xad811(%rip)        # 372328 <_DYNAMIC+0x348>
  2c4b17:	48 8d 0d a2 43 0a 00 	lea    0xa43a2(%rip),%rcx        # 368ec0 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x18>
  2c4b1e:	4c 89 cf             	mov    %r9,%rdi
  2c4b21:	4c 89 d2             	mov    %r10,%rdx
  2c4b24:	ff 15 fe d7 0a 00    	call   *0xad7fe(%rip)        # 372328 <_DYNAMIC+0x348>
  2c4b2a:	48 8d 0d a7 43 0a 00 	lea    0xa43a7(%rip),%rcx        # 368ed8 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x30>
  2c4b31:	4c 89 cf             	mov    %r9,%rdi
  2c4b34:	4c 89 d2             	mov    %r10,%rdx
  2c4b37:	ff 15 eb d7 0a 00    	call   *0xad7eb(%rip)        # 372328 <_DYNAMIC+0x348>
  2c4b3d:	48 8d 0d ac 43 0a 00 	lea    0xa43ac(%rip),%rcx        # 368ef0 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x48>
  2c4b44:	4c 89 cf             	mov    %r9,%rdi
  2c4b47:	4c 89 d2             	mov    %r10,%rdx
  2c4b4a:	ff 15 d8 d7 0a 00    	call   *0xad7d8(%rip)        # 372328 <_DYNAMIC+0x348>
  2c4b50:	48 8d 0d b1 43 0a 00 	lea    0xa43b1(%rip),%rcx        # 368f08 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x60>
  2c4b57:	4c 89 cf             	mov    %r9,%rdi
  2c4b5a:	4c 89 d2             	mov    %r10,%rdx
  2c4b5d:	ff 15 c5 d7 0a 00    	call   *0xad7c5(%rip)        # 372328 <_DYNAMIC+0x348>
  2c4b63:	48 8d 0d b6 43 0a 00 	lea    0xa43b6(%rip),%rcx        # 368f20 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x78>
  2c4b6a:	4c 89 cf             	mov    %r9,%rdi
  2c4b6d:	4c 89 d2             	mov    %r10,%rdx
  2c4b70:	ff 15 b2 d7 0a 00    	call   *0xad7b2(%rip)        # 372328 <_DYNAMIC+0x348>
  2c4b76:	48 8d 0d bb 43 0a 00 	lea    0xa43bb(%rip),%rcx        # 368f38 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x90>
  2c4b7d:	4c 89 cf             	mov    %r9,%rdi
  2c4b80:	4c 89 d2             	mov    %r10,%rdx
  2c4b83:	ff 15 9f d7 0a 00    	call   *0xad79f(%rip)        # 372328 <_DYNAMIC+0x348>
  2c4b89:	48 8d 15 c8 44 0a 00 	lea    0xa44c8(%rip),%rdx        # 369058 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x1b0>
  2c4b90:	c5 f8 77             	vzeroupper
  2c4b93:	ff 15 ff d6 0a 00    	call   *0xad6ff(%rip)        # 372298 <_DYNAMIC+0x2b8>
  2c4b99:	48 8d 15 a0 44 0a 00 	lea    0xa44a0(%rip),%rdx        # 369040 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x198>
  2c4ba0:	48 89 ce             	mov    %rcx,%rsi
  2c4ba3:	c5 f8 77             	vzeroupper
  2c4ba6:	ff 15 ec d6 0a 00    	call   *0xad6ec(%rip)        # 372298 <_DYNAMIC+0x2b8>
  2c4bac:	48 8d 15 75 44 0a 00 	lea    0xa4475(%rip),%rdx        # 369028 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x180>
  2c4bb3:	48 89 df             	mov    %rbx,%rdi
  2c4bb6:	c5 f8 77             	vzeroupper
  2c4bb9:	ff 15 d9 d6 0a 00    	call   *0xad6d9(%rip)        # 372298 <_DYNAMIC+0x2b8>
  2c4bbf:	48 8d 15 4a 44 0a 00 	lea    0xa444a(%rip),%rdx        # 369010 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x168>
  2c4bc6:	48 89 df             	mov    %rbx,%rdi
  2c4bc9:	48 89 ce             	mov    %rcx,%rsi
  2c4bcc:	c5 f8 77             	vzeroupper
  2c4bcf:	ff 15 c3 d6 0a 00    	call   *0xad6c3(%rip)        # 372298 <_DYNAMIC+0x2b8>
  2c4bd5:	48 8d 15 1c 44 0a 00 	lea    0xa441c(%rip),%rdx        # 368ff8 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x150>
  2c4bdc:	4c 89 d6             	mov    %r10,%rsi
  2c4bdf:	c5 f8 77             	vzeroupper
  2c4be2:	ff 15 b0 d6 0a 00    	call   *0xad6b0(%rip)        # 372298 <_DYNAMIC+0x2b8>
  2c4be8:	48 8d 15 f1 43 0a 00 	lea    0xa43f1(%rip),%rdx        # 368fe0 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x138>
  2c4bef:	4c 89 de             	mov    %r11,%rsi
  2c4bf2:	c5 f8 77             	vzeroupper
  2c4bf5:	ff 15 9d d6 0a 00    	call   *0xad69d(%rip)        # 372298 <_DYNAMIC+0x2b8>
  2c4bfb:	48 8d 15 c6 43 0a 00 	lea    0xa43c6(%rip),%rdx        # 368fc8 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x120>
  2c4c02:	48 89 df             	mov    %rbx,%rdi
  2c4c05:	4c 89 d6             	mov    %r10,%rsi
  2c4c08:	c5 f8 77             	vzeroupper
  2c4c0b:	ff 15 87 d6 0a 00    	call   *0xad687(%rip)        # 372298 <_DYNAMIC+0x2b8>
  2c4c11:	48 8d 15 98 43 0a 00 	lea    0xa4398(%rip),%rdx        # 368fb0 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0x108>
  2c4c18:	48 89 df             	mov    %rbx,%rdi
  2c4c1b:	4c 89 de             	mov    %r11,%rsi
  2c4c1e:	c5 f8 77             	vzeroupper
  2c4c21:	ff 15 71 d6 0a 00    	call   *0xad671(%rip)        # 372298 <_DYNAMIC+0x2b8>
  2c4c27:	48 8d 15 22 43 0a 00 	lea    0xa4322(%rip),%rdx        # 368f50 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0xa8>
  2c4c2e:	4c 89 c7             	mov    %r8,%rdi
  2c4c31:	4c 89 de             	mov    %r11,%rsi
  2c4c34:	c5 f8 77             	vzeroupper
  2c4c37:	ff 15 5b d6 0a 00    	call   *0xad65b(%rip)        # 372298 <_DYNAMIC+0x2b8>
  2c4c3d:	48 8d 15 24 43 0a 00 	lea    0xa4324(%rip),%rdx        # 368f68 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0xc0>
  2c4c44:	4c 89 c7             	mov    %r8,%rdi
  2c4c47:	4c 89 d6             	mov    %r10,%rsi
  2c4c4a:	c5 f8 77             	vzeroupper
  2c4c4d:	ff 15 45 d6 0a 00    	call   *0xad645(%rip)        # 372298 <_DYNAMIC+0x2b8>
  2c4c53:	48 8d 15 26 43 0a 00 	lea    0xa4326(%rip),%rdx        # 368f80 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0xd8>
  2c4c5a:	4c 89 c7             	mov    %r8,%rdi
  2c4c5d:	48 89 ce             	mov    %rcx,%rsi
  2c4c60:	c5 f8 77             	vzeroupper
  2c4c63:	ff 15 2f d6 0a 00    	call   *0xad62f(%rip)        # 372298 <_DYNAMIC+0x2b8>
  2c4c69:	48 8d 15 28 43 0a 00 	lea    0xa4328(%rip),%rdx        # 368f98 <anon.57e367dc796540cb2490dff35027e128.74.llvm.1542733964043350120+0xf0>
  2c4c70:	4c 89 c7             	mov    %r8,%rdi
  2c4c73:	c5 f8 77             	vzeroupper
  2c4c76:	ff 15 1c d6 0a 00    	call   *0xad61c(%rip)        # 372298 <_DYNAMIC+0x2b8>
