
/tmp/rustsht-m6-scalar-pair-20261029-5j52VV/target-callgrind-candidate/release/examples/ducc_f32_full_transform_parity:     file format elf64-x86-64


Disassembly of section .text:

00000000002ca660 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>>:
  2ca660:	55                   	push   %rbp
  2ca661:	41 57                	push   %r15
  2ca663:	41 56                	push   %r14
  2ca665:	41 55                	push   %r13
  2ca667:	41 54                	push   %r12
  2ca669:	53                   	push   %rbx
  2ca66a:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
  2ca671:	49 39 d0             	cmp    %rdx,%r8
  2ca674:	0f 97 c0             	seta   %al
  2ca677:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  2ca67c:	49 39 c9             	cmp    %rcx,%r9
  2ca67f:	0f 93 c1             	setae  %cl
  2ca682:	08 c1                	or     %al,%cl
  2ca684:	b0 01                	mov    $0x1,%al
  2ca686:	0f 85 6c 05 00 00    	jne    2cabf8 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x598>
  2ca68c:	49 89 f2             	mov    %rsi,%r10
  2ca68f:	4c 8b 84 24 18 01 00 	mov    0x118(%rsp),%r8
  2ca696:	00 
  2ca697:	48 8b b4 24 10 01 00 	mov    0x110(%rsp),%rsi
  2ca69e:	00 
  2ca69f:	48 8b 57 78          	mov    0x78(%rdi),%rdx
  2ca6a3:	4c 89 c0             	mov    %r8,%rax
  2ca6a6:	48 29 f0             	sub    %rsi,%rax
  2ca6a9:	0f 82 5e 05 00 00    	jb     2cac0d <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x5ad>
  2ca6af:	49 39 d0             	cmp    %rdx,%r8
  2ca6b2:	0f 87 55 05 00 00    	ja     2cac0d <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x5ad>
  2ca6b8:	48 83 f8 04          	cmp    $0x4,%rax
  2ca6bc:	0f 85 92 04 00 00    	jne    2cab54 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x4f4>
  2ca6c2:	48 8b 97 88 00 00 00 	mov    0x88(%rdi),%rdx
  2ca6c9:	49 39 d0             	cmp    %rdx,%r8
  2ca6cc:	0f 87 4e 05 00 00    	ja     2cac20 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x5c0>
  2ca6d2:	48 8b 97 98 00 00 00 	mov    0x98(%rdi),%rdx
  2ca6d9:	49 39 d0             	cmp    %rdx,%r8
  2ca6dc:	0f 87 51 05 00 00    	ja     2cac33 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x5d3>
  2ca6e2:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
  2ca6e9:	49 39 d0             	cmp    %rdx,%r8
  2ca6ec:	0f 87 54 05 00 00    	ja     2cac46 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x5e6>
  2ca6f2:	48 8b 97 d8 00 00 00 	mov    0xd8(%rdi),%rdx
  2ca6f9:	49 39 d0             	cmp    %rdx,%r8
  2ca6fc:	0f 87 57 05 00 00    	ja     2cac59 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x5f9>
  2ca702:	48 8b 97 e8 00 00 00 	mov    0xe8(%rdi),%rdx
  2ca709:	49 39 d0             	cmp    %rdx,%r8
  2ca70c:	0f 87 5a 05 00 00    	ja     2cac6c <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x60c>
  2ca712:	48 8b 97 f8 00 00 00 	mov    0xf8(%rdi),%rdx
  2ca719:	49 39 d0             	cmp    %rdx,%r8
  2ca71c:	0f 87 5d 05 00 00    	ja     2cac7f <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x61f>
  2ca722:	49 8b 52 28          	mov    0x28(%r10),%rdx
  2ca726:	49 39 d0             	cmp    %rdx,%r8
  2ca729:	0f 87 63 05 00 00    	ja     2cac92 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x632>
  2ca72f:	49 8b 52 38          	mov    0x38(%r10),%rdx
  2ca733:	49 39 d0             	cmp    %rdx,%r8
  2ca736:	0f 87 69 05 00 00    	ja     2caca5 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x645>
  2ca73c:	49 8b 52 48          	mov    0x48(%r10),%rdx
  2ca740:	49 39 d0             	cmp    %rdx,%r8
  2ca743:	0f 87 6f 05 00 00    	ja     2cacb8 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x658>
  2ca749:	49 8b 52 58          	mov    0x58(%r10),%rdx
  2ca74d:	49 39 d0             	cmp    %rdx,%r8
  2ca750:	0f 87 75 05 00 00    	ja     2caccb <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x66b>
  2ca756:	48 8b 47 70          	mov    0x70(%rdi),%rax
  2ca75a:	c5 fc 10 04 f0       	vmovups (%rax,%rsi,8),%ymm0
  2ca75f:	c5 fc 11 84 24 b0 00 	vmovups %ymm0,0xb0(%rsp)
  2ca766:	00 00 
  2ca768:	48 8b 87 80 00 00 00 	mov    0x80(%rdi),%rax
  2ca76f:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  2ca774:	c5 fd 10 24 f0       	vmovupd (%rax,%rsi,8),%ymm4
  2ca779:	48 8b 87 90 00 00 00 	mov    0x90(%rdi),%rax
  2ca780:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  2ca785:	c5 7d 10 0c f0       	vmovupd (%rax,%rsi,8),%ymm9
  2ca78a:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
  2ca791:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  2ca796:	c5 fc 10 04 f0       	vmovups (%rax,%rsi,8),%ymm0
  2ca79b:	c5 fc 11 84 24 90 00 	vmovups %ymm0,0x90(%rsp)
  2ca7a2:	00 00 
  2ca7a4:	48 8b 87 d0 00 00 00 	mov    0xd0(%rdi),%rax
  2ca7ab:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  2ca7b0:	c5 7d 10 2c f0       	vmovupd (%rax,%rsi,8),%ymm13
  2ca7b5:	48 8b 87 e0 00 00 00 	mov    0xe0(%rdi),%rax
  2ca7bc:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  2ca7c1:	c5 7d 10 34 f0       	vmovupd (%rax,%rsi,8),%ymm14
  2ca7c6:	48 8b 87 f0 00 00 00 	mov    0xf0(%rdi),%rax
  2ca7cd:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  2ca7d2:	c5 fd 10 04 f0       	vmovupd (%rax,%rsi,8),%ymm0
  2ca7d7:	c5 fd 11 44 24 70    	vmovupd %ymm0,0x70(%rsp)
  2ca7dd:	49 8b 42 20          	mov    0x20(%r10),%rax
  2ca7e1:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  2ca7e6:	c5 fd 10 1c f0       	vmovupd (%rax,%rsi,8),%ymm3
  2ca7eb:	49 8b 42 30          	mov    0x30(%r10),%rax
  2ca7ef:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  2ca7f4:	c5 fd 10 34 f0       	vmovupd (%rax,%rsi,8),%ymm6
  2ca7f9:	49 8b 42 40          	mov    0x40(%r10),%rax
  2ca7fd:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  2ca802:	c5 fd 10 3c f0       	vmovupd (%rax,%rsi,8),%ymm7
  2ca807:	49 8b 42 50          	mov    0x50(%r10),%rax
  2ca80b:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  2ca810:	c5 7d 10 04 f0       	vmovupd (%rax,%rsi,8),%ymm8
  2ca815:	49 8d 41 01          	lea    0x1(%r9),%rax
  2ca819:	48 3b 44 24 10       	cmp    0x10(%rsp),%rax
  2ca81e:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
  2ca823:	0f 83 32 03 00 00    	jae    2cab5b <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x4fb>
  2ca829:	48 8b 47 48          	mov    0x48(%rdi),%rax
  2ca82d:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  2ca832:	48 8b 77 58          	mov    0x58(%rdi),%rsi
  2ca836:	4d 8b 5a 08          	mov    0x8(%r10),%r11
  2ca83a:	49 8b 5a 18          	mov    0x18(%r10),%rbx
  2ca83e:	4c 8b 77 28          	mov    0x28(%rdi),%r14
  2ca842:	4a 8d 14 cd 08 00 00 	lea    0x8(,%r9,8),%rdx
  2ca849:	00 
  2ca84a:	48 8b 6f 20          	mov    0x20(%rdi),%rbp
  2ca84e:	48 01 d5             	add    %rdx,%rbp
  2ca851:	48 03 57 30          	add    0x30(%rdi),%rdx
  2ca855:	4c 8b 7f 38          	mov    0x38(%rdi),%r15
  2ca859:	4d 89 cd             	mov    %r9,%r13
  2ca85c:	49 c1 e5 04          	shl    $0x4,%r13
  2ca860:	49 83 c5 18          	add    $0x18,%r13
  2ca864:	49 8b 02             	mov    (%r10),%rax
  2ca867:	4c 01 e8             	add    %r13,%rax
  2ca86a:	4d 8b 42 10          	mov    0x10(%r10),%r8
  2ca86e:	4d 01 e8             	add    %r13,%r8
  2ca871:	4c 8b 57 40          	mov    0x40(%rdi),%r10
  2ca875:	4d 01 ea             	add    %r13,%r10
  2ca878:	4c 03 6f 50          	add    0x50(%rdi),%r13
  2ca87c:	31 c9                	xor    %ecx,%ecx
  2ca87e:	c5 fd 10 ac 24 b0 00 	vmovupd 0xb0(%rsp),%ymm5
  2ca885:	00 00 
  2ca887:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  2ca88e:	00 00 
  2ca890:	4c 3b 4c 24 08       	cmp    0x8(%rsp),%r9
  2ca895:	0f 83 31 05 00 00    	jae    2cadcc <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x76c>
  2ca89b:	49 39 f1             	cmp    %rsi,%r9
  2ca89e:	c5 fd 10 84 24 90 00 	vmovupd 0x90(%rsp),%ymm0
  2ca8a5:	00 00 
  2ca8a7:	0f 83 0c 05 00 00    	jae    2cadb9 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x759>
  2ca8ad:	4d 39 d9             	cmp    %r11,%r9
  2ca8b0:	0f 83 ed 04 00 00    	jae    2cada3 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x743>
  2ca8b6:	49 39 d9             	cmp    %rbx,%r9
  2ca8b9:	0f 83 ce 04 00 00    	jae    2cad8d <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x72d>
  2ca8bf:	4d 39 f1             	cmp    %r14,%r9
  2ca8c2:	0f 83 af 04 00 00    	jae    2cad77 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x717>
  2ca8c8:	4d 39 f9             	cmp    %r15,%r9
  2ca8cb:	0f 83 90 04 00 00    	jae    2cad61 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x701>
  2ca8d1:	4d 8d 61 01          	lea    0x1(%r9),%r12
  2ca8d5:	4c 3b 64 24 08       	cmp    0x8(%rsp),%r12
  2ca8da:	0f 83 69 04 00 00    	jae    2cad49 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x6e9>
  2ca8e0:	49 39 f4             	cmp    %rsi,%r12
  2ca8e3:	0f 83 4d 04 00 00    	jae    2cad36 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x6d6>
  2ca8e9:	4d 39 dc             	cmp    %r11,%r12
  2ca8ec:	0f 83 2e 04 00 00    	jae    2cad20 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x6c0>
  2ca8f2:	49 39 dc             	cmp    %rbx,%r12
  2ca8f5:	0f 83 0f 04 00 00    	jae    2cad0a <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x6aa>
  2ca8fb:	4d 39 f4             	cmp    %r14,%r12
  2ca8fe:	0f 83 f0 03 00 00    	jae    2cacf4 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x694>
  2ca904:	4d 39 fc             	cmp    %r15,%r12
  2ca907:	0f 83 d1 03 00 00    	jae    2cacde <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x67e>
  2ca90d:	c5 7d 29 e9          	vmovapd %ymm13,%ymm1
  2ca911:	c5 7d 29 f2          	vmovapd %ymm14,%ymm2
  2ca915:	c4 42 7d 19 64 4a e8 	vbroadcastsd -0x18(%r10,%rcx,2),%ymm12
  2ca91c:	c4 62 b5 a8 e0       	vfmadd213pd %ymm0,%ymm9,%ymm12
  2ca921:	c4 42 7d 19 6c 4a f0 	vbroadcastsd -0x10(%r10,%rcx,2),%ymm13
  2ca928:	c4 62 b5 a8 e9       	vfmadd213pd %ymm1,%ymm9,%ymm13
  2ca92d:	c4 42 7d 19 74 4d e8 	vbroadcastsd -0x18(%r13,%rcx,2),%ymm14
  2ca934:	c4 62 b5 a8 f2       	vfmadd213pd %ymm2,%ymm9,%ymm14
  2ca939:	c4 42 7d 19 7c 4d f0 	vbroadcastsd -0x10(%r13,%rcx,2),%ymm15
  2ca940:	c4 62 b5 a8 7c 24 70 	vfmadd213pd 0x70(%rsp),%ymm9,%ymm15
  2ca947:	c4 e2 7d 19 44 48 e8 	vbroadcastsd -0x18(%rax,%rcx,2),%ymm0
  2ca94e:	c4 e2 b5 a8 c3       	vfmadd213pd %ymm3,%ymm9,%ymm0
  2ca953:	c4 62 7d 19 54 48 f0 	vbroadcastsd -0x10(%rax,%rcx,2),%ymm10
  2ca95a:	c4 62 b5 a8 d6       	vfmadd213pd %ymm6,%ymm9,%ymm10
  2ca95f:	c4 c2 7d 19 4c 48 e8 	vbroadcastsd -0x18(%r8,%rcx,2),%ymm1
  2ca966:	c4 e2 b5 a8 cf       	vfmadd213pd %ymm7,%ymm9,%ymm1
  2ca96b:	c4 c2 7d 19 54 48 f0 	vbroadcastsd -0x10(%r8,%rcx,2),%ymm2
  2ca972:	c4 c2 b5 a8 d0       	vfmadd213pd %ymm8,%ymm9,%ymm2
  2ca977:	c4 e2 7d 19 5c 0d f8 	vbroadcastsd -0x8(%rbp,%rcx,1),%ymm3
  2ca97e:	c4 62 7d 19 5c 0a f8 	vbroadcastsd -0x8(%rdx,%rcx,1),%ymm11
  2ca985:	c4 62 d5 b8 db       	vfmadd231pd %ymm3,%ymm5,%ymm11
  2ca98a:	c4 62 b5 a8 dc       	vfmadd213pd %ymm4,%ymm9,%ymm11
  2ca98f:	c4 c2 7d 19 5c 4a f8 	vbroadcastsd -0x8(%r10,%rcx,2),%ymm3
  2ca996:	c4 c2 a5 a8 dc       	vfmadd213pd %ymm12,%ymm11,%ymm3
  2ca99b:	c5 fd 11 9c 24 90 00 	vmovupd %ymm3,0x90(%rsp)
  2ca9a2:	00 00 
  2ca9a4:	c4 c2 7d 19 1c 4a    	vbroadcastsd (%r10,%rcx,2),%ymm3
  2ca9aa:	c4 c2 a5 a8 dd       	vfmadd213pd %ymm13,%ymm11,%ymm3
  2ca9af:	c5 7d 28 eb          	vmovapd %ymm3,%ymm13
  2ca9b3:	c4 c2 7d 19 5c 4d f8 	vbroadcastsd -0x8(%r13,%rcx,2),%ymm3
  2ca9ba:	c4 c2 a5 a8 de       	vfmadd213pd %ymm14,%ymm11,%ymm3
  2ca9bf:	c5 7d 28 f3          	vmovapd %ymm3,%ymm14
  2ca9c3:	c4 c2 7d 19 5c 4d 00 	vbroadcastsd 0x0(%r13,%rcx,2),%ymm3
  2ca9ca:	c4 c2 a5 a8 df       	vfmadd213pd %ymm15,%ymm11,%ymm3
  2ca9cf:	c5 fd 11 5c 24 70    	vmovupd %ymm3,0x70(%rsp)
  2ca9d5:	c4 e2 7d 19 5c 48 f8 	vbroadcastsd -0x8(%rax,%rcx,2),%ymm3
  2ca9dc:	c4 e2 a5 a8 d8       	vfmadd213pd %ymm0,%ymm11,%ymm3
  2ca9e1:	c4 e2 7d 19 34 48    	vbroadcastsd (%rax,%rcx,2),%ymm6
  2ca9e7:	c4 c2 a5 a8 f2       	vfmadd213pd %ymm10,%ymm11,%ymm6
  2ca9ec:	c4 c2 7d 19 7c 48 f8 	vbroadcastsd -0x8(%r8,%rcx,2),%ymm7
  2ca9f3:	c4 e2 a5 a8 f9       	vfmadd213pd %ymm1,%ymm11,%ymm7
  2ca9f8:	c4 42 7d 19 04 48    	vbroadcastsd (%r8,%rcx,2),%ymm8
  2ca9fe:	c4 62 a5 a8 c2       	vfmadd213pd %ymm2,%ymm11,%ymm8
  2caa03:	c4 e2 7d 19 44 0d 00 	vbroadcastsd 0x0(%rbp,%rcx,1),%ymm0
  2caa0a:	c4 62 7d 19 24 0a    	vbroadcastsd (%rdx,%rcx,1),%ymm12
  2caa10:	c4 62 d5 b8 e0       	vfmadd231pd %ymm0,%ymm5,%ymm12
  2caa15:	c4 42 a5 a8 e1       	vfmadd213pd %ymm9,%ymm11,%ymm12
  2caa1a:	4d 8d 61 02          	lea    0x2(%r9),%r12
  2caa1e:	49 83 c1 03          	add    $0x3,%r9
  2caa22:	48 83 c1 10          	add    $0x10,%rcx
  2caa26:	c5 7d 29 dc          	vmovapd %ymm11,%ymm4
  2caa2a:	c4 41 7d 28 cc       	vmovapd %ymm12,%ymm9
  2caa2f:	4c 3b 4c 24 10       	cmp    0x10(%rsp),%r9
  2caa34:	4d 89 e1             	mov    %r12,%r9
  2caa37:	0f 82 53 fe ff ff    	jb     2ca890 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x230>
  2caa3d:	4c 3b 64 24 10       	cmp    0x10(%rsp),%r12
  2caa42:	0f 83 2a 01 00 00    	jae    2cab72 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x512>
  2caa48:	48 8b 4f 48          	mov    0x48(%rdi),%rcx
  2caa4c:	49 39 cc             	cmp    %rcx,%r12
  2caa4f:	c5 fd 10 8c 24 90 00 	vmovupd 0x90(%rsp),%ymm1
  2caa56:	00 00 
  2caa58:	c5 fd 10 54 24 70    	vmovupd 0x70(%rsp),%ymm2
  2caa5e:	0f 83 80 03 00 00    	jae    2cade4 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x784>
  2caa64:	48 8b 4f 58          	mov    0x58(%rdi),%rcx
  2caa68:	49 39 cc             	cmp    %rcx,%r12
  2caa6b:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  2caa70:	0f 83 84 03 00 00    	jae    2cadfa <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x79a>
  2caa76:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
  2caa7a:	49 39 cc             	cmp    %rcx,%r12
  2caa7d:	0f 83 8d 03 00 00    	jae    2cae10 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x7b0>
  2caa83:	48 8b 4e 18          	mov    0x18(%rsi),%rcx
  2caa87:	49 39 cc             	cmp    %rcx,%r12
  2caa8a:	0f 83 96 03 00 00    	jae    2cae26 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x7c6>
  2caa90:	48 8b 4f 28          	mov    0x28(%rdi),%rcx
  2caa94:	49 39 cc             	cmp    %rcx,%r12
  2caa97:	0f 83 9f 03 00 00    	jae    2cae3c <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x7dc>
  2caa9d:	48 8b 4f 38          	mov    0x38(%rdi),%rcx
  2caaa1:	49 39 cc             	cmp    %rcx,%r12
  2caaa4:	0f 83 a8 03 00 00    	jae    2cae52 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x7f2>
  2caaaa:	4c 89 e0             	mov    %r12,%rax
  2caaad:	48 c1 e0 04          	shl    $0x4,%rax
  2caab1:	48 8b 4f 40          	mov    0x40(%rdi),%rcx
  2caab5:	48 8b 57 50          	mov    0x50(%rdi),%rdx
  2caab9:	c4 62 7d 19 0c 01    	vbroadcastsd (%rcx,%rax,1),%ymm9
  2caabf:	c4 c2 9d b8 c9       	vfmadd231pd %ymm9,%ymm12,%ymm1
  2caac4:	c4 62 7d 19 4c 01 08 	vbroadcastsd 0x8(%rcx,%rax,1),%ymm9
  2caacb:	c4 42 9d b8 e9       	vfmadd231pd %ymm9,%ymm12,%ymm13
  2caad0:	c4 62 7d 19 0c 02    	vbroadcastsd (%rdx,%rax,1),%ymm9
  2caad6:	c4 42 9d b8 f1       	vfmadd231pd %ymm9,%ymm12,%ymm14
  2caadb:	c4 62 7d 19 4c 02 08 	vbroadcastsd 0x8(%rdx,%rax,1),%ymm9
  2caae2:	c4 c2 9d b8 d1       	vfmadd231pd %ymm9,%ymm12,%ymm2
  2caae7:	48 8b 0e             	mov    (%rsi),%rcx
  2caaea:	48 8b 56 10          	mov    0x10(%rsi),%rdx
  2caaee:	c4 62 7d 19 0c 01    	vbroadcastsd (%rcx,%rax,1),%ymm9
  2caaf4:	c4 c2 9d b8 d9       	vfmadd231pd %ymm9,%ymm12,%ymm3
  2caaf9:	c4 62 7d 19 4c 01 08 	vbroadcastsd 0x8(%rcx,%rax,1),%ymm9
  2cab00:	c4 c2 9d b8 f1       	vfmadd231pd %ymm9,%ymm12,%ymm6
  2cab05:	c4 62 7d 19 0c 02    	vbroadcastsd (%rdx,%rax,1),%ymm9
  2cab0b:	c4 c2 9d b8 f9       	vfmadd231pd %ymm9,%ymm12,%ymm7
  2cab10:	c4 62 7d 19 4c 02 08 	vbroadcastsd 0x8(%rdx,%rax,1),%ymm9
  2cab17:	c4 42 9d b8 c1       	vfmadd231pd %ymm9,%ymm12,%ymm8
  2cab1c:	48 8b 47 20          	mov    0x20(%rdi),%rax
  2cab20:	48 8b 4f 30          	mov    0x30(%rdi),%rcx
  2cab24:	c4 22 7d 19 0c e0    	vbroadcastsd (%rax,%r12,8),%ymm9
  2cab2a:	c4 22 7d 19 14 e1    	vbroadcastsd (%rcx,%r12,8),%ymm10
  2cab30:	c5 fd 10 84 24 b0 00 	vmovupd 0xb0(%rsp),%ymm0
  2cab37:	00 00 
  2cab39:	c4 c2 b5 a8 c2       	vfmadd213pd %ymm10,%ymm9,%ymm0
  2cab3e:	c4 c2 9d a8 c3       	vfmadd213pd %ymm11,%ymm12,%ymm0
  2cab43:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  2cab48:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  2cab4d:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  2cab52:	eb 45                	jmp    2cab99 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x539>
  2cab54:	31 c0                	xor    %eax,%eax
  2cab56:	e9 9d 00 00 00       	jmp    2cabf8 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x598>
  2cab5b:	c4 41 7d 28 e1       	vmovapd %ymm9,%ymm12
  2cab60:	c5 7d 28 dc          	vmovapd %ymm4,%ymm11
  2cab64:	4d 89 cc             	mov    %r9,%r12
  2cab67:	4c 3b 64 24 10       	cmp    0x10(%rsp),%r12
  2cab6c:	0f 82 d6 fe ff ff    	jb     2caa48 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector_pair::<pulp::x86::v3::V3>+0x3e8>
  2cab72:	c5 7d 29 e0          	vmovapd %ymm12,%ymm0
  2cab76:	c4 41 7d 28 e3       	vmovapd %ymm11,%ymm12
  2cab7b:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  2cab80:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  2cab85:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  2cab8a:	c5 fd 10 8c 24 90 00 	vmovupd 0x90(%rsp),%ymm1
  2cab91:	00 00 
  2cab93:	c5 fd 10 54 24 70    	vmovupd 0x70(%rsp),%ymm2
  2cab99:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
  2caba0:	00 
  2caba1:	c5 7d 11 24 c1       	vmovupd %ymm12,(%rcx,%rax,8)
  2caba6:	c5 fd 11 04 c2       	vmovupd %ymm0,(%rdx,%rax,8)
  2cabab:	c5 fd 11 0c c6       	vmovupd %ymm1,(%rsi,%rax,8)
  2cabb0:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  2cabb5:	c5 7d 11 2c c1       	vmovupd %ymm13,(%rcx,%rax,8)
  2cabba:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  2cabbf:	c5 7d 11 34 c1       	vmovupd %ymm14,(%rcx,%rax,8)
  2cabc4:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  2cabc9:	c5 fd 11 14 c1       	vmovupd %ymm2,(%rcx,%rax,8)
  2cabce:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  2cabd3:	c5 fd 11 1c c1       	vmovupd %ymm3,(%rcx,%rax,8)
  2cabd8:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  2cabdd:	c5 fd 11 34 c1       	vmovupd %ymm6,(%rcx,%rax,8)
  2cabe2:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  2cabe7:	c5 fd 11 3c c1       	vmovupd %ymm7,(%rcx,%rax,8)
  2cabec:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  2cabf1:	c5 7d 11 04 c1       	vmovupd %ymm8,(%rcx,%rax,8)
  2cabf6:	b0 01                	mov    $0x1,%al
  2cabf8:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
  2cabff:	5b                   	pop    %rbx
  2cac00:	41 5c                	pop    %r12
  2cac02:	41 5d                	pop    %r13
  2cac04:	41 5e                	pop    %r14
  2cac06:	41 5f                	pop    %r15
  2cac08:	5d                   	pop    %rbp
  2cac09:	c5 f8 77             	vzeroupper
  2cac0c:	c3                   	ret
  2cac0d:	48 8d 0d 44 b1 0b 00 	lea    0xbb144(%rip),%rcx        # 385d58 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x480>
  2cac14:	48 89 f7             	mov    %rsi,%rdi
  2cac17:	4c 89 c6             	mov    %r8,%rsi
  2cac1a:	ff 15 30 4d 0c 00    	call   *0xc4d30(%rip)        # 38f950 <_DYNAMIC+0x348>
  2cac20:	48 8d 0d 91 ae 0b 00 	lea    0xbae91(%rip),%rcx        # 385ab8 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x1e0>
  2cac27:	48 89 f7             	mov    %rsi,%rdi
  2cac2a:	4c 89 c6             	mov    %r8,%rsi
  2cac2d:	ff 15 1d 4d 0c 00    	call   *0xc4d1d(%rip)        # 38f950 <_DYNAMIC+0x348>
  2cac33:	48 8d 0d 96 ae 0b 00 	lea    0xbae96(%rip),%rcx        # 385ad0 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x1f8>
  2cac3a:	48 89 f7             	mov    %rsi,%rdi
  2cac3d:	4c 89 c6             	mov    %r8,%rsi
  2cac40:	ff 15 0a 4d 0c 00    	call   *0xc4d0a(%rip)        # 38f950 <_DYNAMIC+0x348>
  2cac46:	48 8d 0d 9b ae 0b 00 	lea    0xbae9b(%rip),%rcx        # 385ae8 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x210>
  2cac4d:	48 89 f7             	mov    %rsi,%rdi
  2cac50:	4c 89 c6             	mov    %r8,%rsi
  2cac53:	ff 15 f7 4c 0c 00    	call   *0xc4cf7(%rip)        # 38f950 <_DYNAMIC+0x348>
  2cac59:	48 8d 0d a0 ae 0b 00 	lea    0xbaea0(%rip),%rcx        # 385b00 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x228>
  2cac60:	48 89 f7             	mov    %rsi,%rdi
  2cac63:	4c 89 c6             	mov    %r8,%rsi
  2cac66:	ff 15 e4 4c 0c 00    	call   *0xc4ce4(%rip)        # 38f950 <_DYNAMIC+0x348>
  2cac6c:	48 8d 0d a5 ae 0b 00 	lea    0xbaea5(%rip),%rcx        # 385b18 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x240>
  2cac73:	48 89 f7             	mov    %rsi,%rdi
  2cac76:	4c 89 c6             	mov    %r8,%rsi
  2cac79:	ff 15 d1 4c 0c 00    	call   *0xc4cd1(%rip)        # 38f950 <_DYNAMIC+0x348>
  2cac7f:	48 8d 0d aa ae 0b 00 	lea    0xbaeaa(%rip),%rcx        # 385b30 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x258>
  2cac86:	48 89 f7             	mov    %rsi,%rdi
  2cac89:	4c 89 c6             	mov    %r8,%rsi
  2cac8c:	ff 15 be 4c 0c 00    	call   *0xc4cbe(%rip)        # 38f950 <_DYNAMIC+0x348>
  2cac92:	48 8d 0d af ae 0b 00 	lea    0xbaeaf(%rip),%rcx        # 385b48 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x270>
  2cac99:	48 89 f7             	mov    %rsi,%rdi
  2cac9c:	4c 89 c6             	mov    %r8,%rsi
  2cac9f:	ff 15 ab 4c 0c 00    	call   *0xc4cab(%rip)        # 38f950 <_DYNAMIC+0x348>
  2caca5:	48 8d 0d b4 ae 0b 00 	lea    0xbaeb4(%rip),%rcx        # 385b60 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x288>
  2cacac:	48 89 f7             	mov    %rsi,%rdi
  2cacaf:	4c 89 c6             	mov    %r8,%rsi
  2cacb2:	ff 15 98 4c 0c 00    	call   *0xc4c98(%rip)        # 38f950 <_DYNAMIC+0x348>
  2cacb8:	48 8d 0d b9 ae 0b 00 	lea    0xbaeb9(%rip),%rcx        # 385b78 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x2a0>
  2cacbf:	48 89 f7             	mov    %rsi,%rdi
  2cacc2:	4c 89 c6             	mov    %r8,%rsi
  2cacc5:	ff 15 85 4c 0c 00    	call   *0xc4c85(%rip)        # 38f950 <_DYNAMIC+0x348>
  2caccb:	48 8d 0d be ae 0b 00 	lea    0xbaebe(%rip),%rcx        # 385b90 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x2b8>
  2cacd2:	48 89 f7             	mov    %rsi,%rdi
  2cacd5:	4c 89 c6             	mov    %r8,%rsi
  2cacd8:	ff 15 72 4c 0c 00    	call   *0xc4c72(%rip)        # 38f950 <_DYNAMIC+0x348>
  2cacde:	48 8d 15 5b b0 0b 00 	lea    0xbb05b(%rip),%rdx        # 385d40 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x468>
  2cace5:	4c 89 e7             	mov    %r12,%rdi
  2cace8:	4c 89 fe             	mov    %r15,%rsi
  2caceb:	c5 f8 77             	vzeroupper
  2cacee:	ff 15 cc 4b 0c 00    	call   *0xc4bcc(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cacf4:	48 8d 15 2d b0 0b 00 	lea    0xbb02d(%rip),%rdx        # 385d28 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x450>
  2cacfb:	4c 89 e7             	mov    %r12,%rdi
  2cacfe:	4c 89 f6             	mov    %r14,%rsi
  2cad01:	c5 f8 77             	vzeroupper
  2cad04:	ff 15 b6 4b 0c 00    	call   *0xc4bb6(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cad0a:	48 8d 15 ff af 0b 00 	lea    0xbafff(%rip),%rdx        # 385d10 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x438>
  2cad11:	4c 89 e7             	mov    %r12,%rdi
  2cad14:	48 89 de             	mov    %rbx,%rsi
  2cad17:	c5 f8 77             	vzeroupper
  2cad1a:	ff 15 a0 4b 0c 00    	call   *0xc4ba0(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cad20:	48 8d 15 d1 af 0b 00 	lea    0xbafd1(%rip),%rdx        # 385cf8 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x420>
  2cad27:	4c 89 e7             	mov    %r12,%rdi
  2cad2a:	4c 89 de             	mov    %r11,%rsi
  2cad2d:	c5 f8 77             	vzeroupper
  2cad30:	ff 15 8a 4b 0c 00    	call   *0xc4b8a(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cad36:	48 8d 15 a3 af 0b 00 	lea    0xbafa3(%rip),%rdx        # 385ce0 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x408>
  2cad3d:	4c 89 e7             	mov    %r12,%rdi
  2cad40:	c5 f8 77             	vzeroupper
  2cad43:	ff 15 77 4b 0c 00    	call   *0xc4b77(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cad49:	48 8d 15 78 af 0b 00 	lea    0xbaf78(%rip),%rdx        # 385cc8 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x3f0>
  2cad50:	4c 89 e7             	mov    %r12,%rdi
  2cad53:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  2cad58:	c5 f8 77             	vzeroupper
  2cad5b:	ff 15 5f 4b 0c 00    	call   *0xc4b5f(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cad61:	48 8d 15 48 af 0b 00 	lea    0xbaf48(%rip),%rdx        # 385cb0 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x3d8>
  2cad68:	4c 89 cf             	mov    %r9,%rdi
  2cad6b:	4c 89 fe             	mov    %r15,%rsi
  2cad6e:	c5 f8 77             	vzeroupper
  2cad71:	ff 15 49 4b 0c 00    	call   *0xc4b49(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cad77:	48 8d 15 1a af 0b 00 	lea    0xbaf1a(%rip),%rdx        # 385c98 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x3c0>
  2cad7e:	4c 89 cf             	mov    %r9,%rdi
  2cad81:	4c 89 f6             	mov    %r14,%rsi
  2cad84:	c5 f8 77             	vzeroupper
  2cad87:	ff 15 33 4b 0c 00    	call   *0xc4b33(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cad8d:	48 8d 15 ec ae 0b 00 	lea    0xbaeec(%rip),%rdx        # 385c80 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x3a8>
  2cad94:	4c 89 cf             	mov    %r9,%rdi
  2cad97:	48 89 de             	mov    %rbx,%rsi
  2cad9a:	c5 f8 77             	vzeroupper
  2cad9d:	ff 15 1d 4b 0c 00    	call   *0xc4b1d(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cada3:	48 8d 15 be ae 0b 00 	lea    0xbaebe(%rip),%rdx        # 385c68 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x390>
  2cadaa:	4c 89 cf             	mov    %r9,%rdi
  2cadad:	4c 89 de             	mov    %r11,%rsi
  2cadb0:	c5 f8 77             	vzeroupper
  2cadb3:	ff 15 07 4b 0c 00    	call   *0xc4b07(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cadb9:	48 8d 15 90 ae 0b 00 	lea    0xbae90(%rip),%rdx        # 385c50 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x378>
  2cadc0:	4c 89 cf             	mov    %r9,%rdi
  2cadc3:	c5 f8 77             	vzeroupper
  2cadc6:	ff 15 f4 4a 0c 00    	call   *0xc4af4(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cadcc:	48 8d 15 65 ae 0b 00 	lea    0xbae65(%rip),%rdx        # 385c38 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x360>
  2cadd3:	4c 89 cf             	mov    %r9,%rdi
  2cadd6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  2caddb:	c5 f8 77             	vzeroupper
  2cadde:	ff 15 dc 4a 0c 00    	call   *0xc4adc(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cade4:	48 8d 15 bd ad 0b 00 	lea    0xbadbd(%rip),%rdx        # 385ba8 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x2d0>
  2cadeb:	4c 89 e7             	mov    %r12,%rdi
  2cadee:	48 89 ce             	mov    %rcx,%rsi
  2cadf1:	c5 f8 77             	vzeroupper
  2cadf4:	ff 15 c6 4a 0c 00    	call   *0xc4ac6(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cadfa:	48 8d 15 bf ad 0b 00 	lea    0xbadbf(%rip),%rdx        # 385bc0 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x2e8>
  2cae01:	4c 89 e7             	mov    %r12,%rdi
  2cae04:	48 89 ce             	mov    %rcx,%rsi
  2cae07:	c5 f8 77             	vzeroupper
  2cae0a:	ff 15 b0 4a 0c 00    	call   *0xc4ab0(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cae10:	48 8d 15 c1 ad 0b 00 	lea    0xbadc1(%rip),%rdx        # 385bd8 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x300>
  2cae17:	4c 89 e7             	mov    %r12,%rdi
  2cae1a:	48 89 ce             	mov    %rcx,%rsi
  2cae1d:	c5 f8 77             	vzeroupper
  2cae20:	ff 15 9a 4a 0c 00    	call   *0xc4a9a(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cae26:	48 8d 15 c3 ad 0b 00 	lea    0xbadc3(%rip),%rdx        # 385bf0 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x318>
  2cae2d:	4c 89 e7             	mov    %r12,%rdi
  2cae30:	48 89 ce             	mov    %rcx,%rsi
  2cae33:	c5 f8 77             	vzeroupper
  2cae36:	ff 15 84 4a 0c 00    	call   *0xc4a84(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cae3c:	48 8d 15 c5 ad 0b 00 	lea    0xbadc5(%rip),%rdx        # 385c08 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x330>
  2cae43:	4c 89 e7             	mov    %r12,%rdi
  2cae46:	48 89 ce             	mov    %rcx,%rsi
  2cae49:	c5 f8 77             	vzeroupper
  2cae4c:	ff 15 6e 4a 0c 00    	call   *0xc4a6e(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
  2cae52:	48 8d 15 c7 ad 0b 00 	lea    0xbadc7(%rip),%rdx        # 385c20 <anon.ea8a2c4768bfd0d3a77a3e2be344ddf6.96.llvm.7932808256229573138+0x348>
  2cae59:	4c 89 e7             	mov    %r12,%rdi
  2cae5c:	48 89 ce             	mov    %rcx,%rsi
  2cae5f:	c5 f8 77             	vzeroupper
  2cae62:	ff 15 58 4a 0c 00    	call   *0xc4a58(%rip)        # 38f8c0 <_DYNAMIC+0x2b8>
