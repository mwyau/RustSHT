00000000001f6a30 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>>:
  1f6a30:	push   %rbp
  1f6a31:	push   %r15
  1f6a33:	push   %r14
  1f6a35:	push   %r13
  1f6a37:	push   %r12
  1f6a39:	push   %rbx
  1f6a3a:	sub    $0x228,%rsp
  1f6a41:	mov    0xc0(%rdi),%r11
  1f6a48:	mov    (%rdi),%rax
  1f6a4b:	mov    %rax,0x60(%rsp)
  1f6a50:	mov    0x8(%rdi),%rsi
  1f6a54:	mov    0x10(%rdi),%r14
  1f6a58:	mov    0x18(%rdi),%r10
  1f6a5c:	mov    0x20(%rdi),%rbp
  1f6a60:	mov    0x28(%rdi),%rax
  1f6a64:	mov    0x30(%rdi),%rdx
  1f6a68:	mov    0x38(%rdi),%rcx
  1f6a6c:	mov    0x40(%rdi),%rbx
  1f6a70:	mov    0x48(%rdi),%r9
  1f6a74:	mov    0x50(%rdi),%r15
  1f6a78:	mov    0x58(%rdi),%r8
  1f6a7c:	mov    %rsi,0x50(%rsp)
  1f6a81:	shr    $0x2,%rsi
  1f6a85:	cmp    %r10,%rax
  1f6a88:	cmovb  %rax,%r10
  1f6a8c:	mov    0x60(%rdi),%r13
  1f6a90:	cmp    %r10,%rcx
  1f6a93:	cmovb  %rcx,%r10
  1f6a97:	mov    0x68(%rdi),%rax
  1f6a9b:	cmp    %r10,%r9
  1f6a9e:	cmovb  %r9,%r10
  1f6aa2:	mov    0x70(%rdi),%rcx
  1f6aa6:	mov    %rcx,0x58(%rsp)
  1f6aab:	cmp    %r10,%r8
  1f6aae:	cmovb  %r8,%r10
  1f6ab2:	mov    0x78(%rdi),%rcx
  1f6ab6:	mov    %rcx,0x48(%rsp)
  1f6abb:	cmp    %r10,%rax
  1f6abe:	cmovb  %rax,%r10
  1f6ac2:	mov    %r10,0x40(%rsp)
  1f6ac7:	mov    0x80(%rdi),%rax
  1f6ace:	mov    %rax,0x38(%rsp)
  1f6ad3:	mov    0x88(%rdi),%rax
  1f6ada:	mov    %rax,0x18(%rsp)
  1f6adf:	mov    0x90(%rdi),%rax
  1f6ae6:	mov    %rax,0x30(%rsp)
  1f6aeb:	mov    0x98(%rdi),%rax
  1f6af2:	mov    %rax,0x10(%rsp)
  1f6af7:	mov    0xa0(%rdi),%rax
  1f6afe:	mov    %rax,0x28(%rsp)
  1f6b03:	mov    0xa8(%rdi),%rax
  1f6b0a:	mov    %rax,0x8(%rsp)
  1f6b0f:	mov    0xb0(%rdi),%rax
  1f6b16:	mov    %rax,0x20(%rsp)
  1f6b1b:	mov    0xb8(%rdi),%rax
  1f6b22:	mov    %rax,(%rsp)
  1f6b26:	test   %rsi,%rsi
  1f6b29:	je     1f6f98 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x568>
  1f6b2f:	mov    %rsi,%r10
  1f6b32:	mov    0x48(%rsp),%rsi
  1f6b37:	shr    $0x2,%rsi
  1f6b3b:	mov    0x18(%rsp),%rax
  1f6b40:	shr    $0x2,%rax
  1f6b44:	mov    %rax,0x80(%rsp)
  1f6b4c:	mov    0x10(%rsp),%rax
  1f6b51:	shr    $0x2,%rax
  1f6b55:	mov    %rax,0x78(%rsp)
  1f6b5a:	mov    0x8(%rsp),%rax
  1f6b5f:	shr    $0x2,%rax
  1f6b63:	mov    %rax,0x70(%rsp)
  1f6b68:	mov    (%rsp),%rax
  1f6b6c:	shr    $0x2,%rax
  1f6b70:	mov    %rax,0x68(%rsp)
  1f6b75:	mov    0x40(%rsp),%rax
  1f6b7a:	neg    %rax
  1f6b7d:	xor    %edi,%edi
  1f6b7f:	mov    %rsi,0x88(%rsp)
  1f6b87:	mov    %r10,0xd8(%rsp)
  1f6b8f:	jmp    1f6bb8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x188>
  1f6b91:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1f6ba0:	mov    0x20(%rsp),%r8
  1f6ba5:	vmovupd %ymm0,(%r8,%rcx,1)
  1f6bab:	add    $0x2,%rdi
  1f6baf:	cmp    %r10,%rdi
  1f6bb2:	jae    1f6f98 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x568>
  1f6bb8:	lea    0x1(%rdi),%r9
  1f6bbc:	mov    %rdi,%rcx
  1f6bbf:	shl    $0x5,%rcx
  1f6bc3:	mov    0x60(%rsp),%r8
  1f6bc8:	vmovups (%r8,%rcx,1),%ymm0
  1f6bce:	vmovups %ymm0,0x100(%rsp)
  1f6bd7:	cmp    %r10,%r9
  1f6bda:	jae    1f6d40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x310>
  1f6be0:	cmp    %rsi,%rdi
  1f6be3:	jae    1f75b7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xb87>
  1f6be9:	cmp    %rsi,%r9
  1f6bec:	jae    1f75f7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xbc7>
  1f6bf2:	mov    %r9,%r8
  1f6bf5:	shl    $0x5,%r8
  1f6bf9:	mov    0x60(%rsp),%r10
  1f6bfe:	vmovupd (%r10,%r8,1),%ymm0
  1f6c04:	vmovupd %ymm0,0xe0(%rsp)
  1f6c0d:	mov    0x58(%rsp),%r10
  1f6c12:	vmovupd (%r10,%rcx,1),%ymm13
  1f6c18:	vmovupd (%r10,%r8,1),%ymm12
  1f6c1e:	cmpq   $0x0,0x40(%rsp)
  1f6c24:	jne    1f6d77 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x347>
  1f6c2a:	vxorpd %xmm9,%xmm9,%xmm9
  1f6c2f:	vxorpd %xmm8,%xmm8,%xmm8
  1f6c34:	vxorpd %xmm0,%xmm0,%xmm0
  1f6c38:	vmovupd %ymm0,0xb0(%rsp)
  1f6c41:	vmovupd %ymm0,0x90(%rsp)
  1f6c4a:	vxorpd %xmm5,%xmm5,%xmm5
  1f6c4e:	vxorpd %xmm3,%xmm3,%xmm3
  1f6c52:	vxorpd %xmm1,%xmm1,%xmm1
  1f6c56:	cmp    0x80(%rsp),%rdi
  1f6c5e:	mov    0xd8(%rsp),%r10
  1f6c66:	jae    1f759f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xb6f>
  1f6c6c:	mov    0x38(%rsp),%r8
  1f6c71:	vmovupd %ymm9,(%r8,%rcx,1)
  1f6c77:	cmp    0x78(%rsp),%rdi
  1f6c7c:	mov    0x88(%rsp),%rsi
  1f6c84:	jae    1f758a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xb5a>
  1f6c8a:	mov    0x30(%rsp),%r8
  1f6c8f:	vmovupd %ymm8,(%r8,%rcx,1)
  1f6c95:	cmp    0x70(%rsp),%rdi
  1f6c9a:	jae    1f7575 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xb45>
  1f6ca0:	mov    0x28(%rsp),%r8
  1f6ca5:	vmovups 0xb0(%rsp),%ymm2
  1f6cae:	vmovups %ymm2,(%r8,%rcx,1)
  1f6cb4:	cmp    0x68(%rsp),%rdi
  1f6cb9:	jae    1f7560 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xb30>
  1f6cbf:	mov    0x20(%rsp),%r8
  1f6cc4:	vmovupd 0x90(%rsp),%ymm2
  1f6ccd:	vmovupd %ymm2,(%r8,%rcx,1)
  1f6cd3:	cmp    %r10,%r9
  1f6cd6:	jae    1f6bab <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x17b>
  1f6cdc:	cmp    0x80(%rsp),%r9
  1f6ce4:	jae    1f762a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xbfa>
  1f6cea:	mov    %r9,%rcx
  1f6ced:	shl    $0x5,%rcx
  1f6cf1:	mov    0x38(%rsp),%r8
  1f6cf6:	vmovupd %ymm5,(%r8,%rcx,1)
  1f6cfc:	cmp    0x78(%rsp),%r9
  1f6d01:	jae    1f75c7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xb97>
  1f6d07:	mov    0x30(%rsp),%r8
  1f6d0c:	vmovupd %ymm3,(%r8,%rcx,1)
  1f6d12:	cmp    0x70(%rsp),%r9
  1f6d17:	jae    1f7612 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xbe2>
  1f6d1d:	mov    0x28(%rsp),%r8
  1f6d22:	vmovupd %ymm1,(%r8,%rcx,1)
  1f6d28:	cmp    0x68(%rsp),%r9
  1f6d2d:	jb     1f6ba0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x170>
  1f6d33:	jmp    1f75df <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xbaf>
  1f6d38:	nopl   0x0(%rax,%rax,1)
  1f6d40:	cmp    %rsi,%rdi
  1f6d43:	jae    1f75b7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xb87>
  1f6d49:	mov    0x58(%rsp),%r8
  1f6d4e:	vmovupd (%r8,%rcx,1),%ymm13
  1f6d54:	vmovapd %ymm13,%ymm12
  1f6d59:	vmovupd 0x100(%rsp),%ymm0
  1f6d62:	vmovupd %ymm0,0xe0(%rsp)
  1f6d6b:	cmpq   $0x0,0x40(%rsp)
  1f6d71:	je     1f6c2a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x1fa>
  1f6d77:	vmovupd 0x100(%rsp),%ymm0
  1f6d80:	vmulpd %ymm0,%ymm0,%ymm0
  1f6d84:	vmovupd %ymm0,0x180(%rsp)
  1f6d8d:	vmovupd 0xe0(%rsp),%ymm0
  1f6d96:	vmulpd %ymm0,%ymm0,%ymm0
  1f6d9a:	vmovupd %ymm0,0x160(%rsp)
  1f6da3:	vxorpd %xmm0,%xmm0,%xmm0
  1f6da7:	mov    $0x1,%r10d
  1f6dad:	xor    %r8d,%r8d
  1f6db0:	vxorps %xmm1,%xmm1,%xmm1
  1f6db4:	vxorps %xmm3,%xmm3,%xmm3
  1f6db8:	vxorps %xmm5,%xmm5,%xmm5
  1f6dbc:	vxorps %xmm2,%xmm2,%xmm2
  1f6dc0:	vmovups %ymm2,0x90(%rsp)
  1f6dc9:	vmovups %ymm2,0xb0(%rsp)
  1f6dd2:	vxorpd %xmm8,%xmm8,%xmm8
  1f6dd7:	vxorpd %xmm9,%xmm9,%xmm9
  1f6ddc:	vmovups %ymm2,0x140(%rsp)
  1f6de5:	vmovups %ymm2,0x120(%rsp)
  1f6dee:	jmp    1f6f5c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x52c>
  1f6df3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1f6e00:	vbroadcastsd (%r14,%r8,1),%ymm11
  1f6e06:	vbroadcastsd 0x0(%rbp,%r8,1),%ymm14
  1f6e0d:	vmovupd 0x180(%rsp),%ymm10
  1f6e16:	vfmadd213pd %ymm14,%ymm11,%ymm10
  1f6e1b:	vfmadd132pd 0x160(%rsp),%ymm14,%ymm11
  1f6e25:	vfmadd213pd 0x120(%rsp),%ymm13,%ymm10
  1f6e2f:	vfmadd213pd 0x140(%rsp),%ymm12,%ymm11
  1f6e39:	vmovupd %ymm13,0x120(%rsp)
  1f6e42:	vmovupd %ymm12,0x140(%rsp)
  1f6e4b:	vbroadcastsd (%rdx,%r8,2),%ymm15
  1f6e51:	vbroadcastsd (%rbx,%r8,2),%ymm14
  1f6e57:	vmovupd 0x100(%rsp),%ymm5
  1f6e60:	vmovapd %ymm5,%ymm3
  1f6e64:	vfmadd213pd %ymm15,%ymm14,%ymm3
  1f6e69:	vfmadd231pd %ymm3,%ymm13,%ymm9
  1f6e6e:	vbroadcastsd 0x8(%rdx,%r8,2),%ymm3
  1f6e75:	vbroadcastsd 0x8(%rbx,%r8,2),%ymm7
  1f6e7c:	vmovapd %ymm5,%ymm0
  1f6e80:	vfmadd213pd %ymm3,%ymm7,%ymm0
  1f6e85:	vfmadd231pd %ymm0,%ymm13,%ymm8
  1f6e8a:	vbroadcastsd (%r15,%r8,2),%ymm0
  1f6e90:	vbroadcastsd 0x0(%r13,%r8,2),%ymm1
  1f6e97:	vmovapd %ymm5,%ymm2
  1f6e9b:	vfmadd213pd %ymm0,%ymm1,%ymm2
  1f6ea0:	vmovupd 0xb0(%rsp),%ymm4
  1f6ea9:	vfmadd231pd %ymm2,%ymm13,%ymm4
  1f6eae:	vmovupd %ymm4,0xb0(%rsp)
  1f6eb7:	vbroadcastsd 0x8(%r15,%r8,2),%ymm2
  1f6ebe:	vbroadcastsd 0x8(%r13,%r8,2),%ymm4
  1f6ec5:	vfmadd213pd %ymm2,%ymm4,%ymm5
  1f6eca:	vmovupd 0x90(%rsp),%ymm6
  1f6ed3:	vfmadd231pd %ymm5,%ymm13,%ymm6
  1f6ed8:	vmovupd %ymm6,0x90(%rsp)
  1f6ee1:	vmovupd 0xe0(%rsp),%ymm6
  1f6eea:	vfmadd213pd %ymm15,%ymm6,%ymm14
  1f6eef:	vmovupd 0x1a0(%rsp),%ymm5
  1f6ef8:	vfmadd231pd %ymm14,%ymm12,%ymm5
  1f6efd:	vfmadd213pd %ymm3,%ymm6,%ymm7
  1f6f02:	vmovupd 0x1c0(%rsp),%ymm3
  1f6f0b:	vfmadd231pd %ymm7,%ymm12,%ymm3
  1f6f10:	vfmadd213pd %ymm0,%ymm6,%ymm1
  1f6f15:	vmovupd 0x1e0(%rsp),%ymm0
  1f6f1e:	vfmadd231pd %ymm1,%ymm12,%ymm0
  1f6f23:	vmovapd %ymm0,%ymm1
  1f6f27:	vfmadd213pd %ymm2,%ymm6,%ymm4
  1f6f2c:	vmovupd 0x200(%rsp),%ymm0
  1f6f35:	vfmadd231pd %ymm4,%ymm12,%ymm0
  1f6f3a:	add    $0x8,%r8
  1f6f3e:	lea    (%rax,%r10,1),%r12
  1f6f42:	inc    %r12
  1f6f45:	inc    %r10
  1f6f48:	vmovapd %ymm11,%ymm12
  1f6f4d:	vmovapd %ymm10,%ymm13
  1f6f52:	cmp    $0x1,%r12
  1f6f56:	je     1f6c56 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x226>
  1f6f5c:	cmp    %r11,%r10
  1f6f5f:	vmovupd %ymm0,0x200(%rsp)
  1f6f68:	vmovups %ymm1,0x1e0(%rsp)
  1f6f71:	vmovups %ymm3,0x1c0(%rsp)
  1f6f7a:	vmovups %ymm5,0x1a0(%rsp)
  1f6f83:	jb     1f6e00 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x3d0>
  1f6f89:	vmovapd %ymm13,%ymm10
  1f6f8e:	vmovapd %ymm12,%ymm11
  1f6f93:	jmp    1f6e4b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x41b>
  1f6f98:	mov    0x50(%rsp),%r9
  1f6f9d:	and    $0x3,%r9d
  1f6fa1:	je     1f754b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xb1b>
  1f6fa7:	movabs $0xffffffffffffffc,%r10
  1f6fb1:	mov    0x48(%rsp),%r8
  1f6fb6:	and    $0x3,%r8d
  1f6fba:	mov    0x18(%rsp),%rax
  1f6fbf:	mov    %eax,%ecx
  1f6fc1:	and    $0x3,%ecx
  1f6fc4:	and    %r10,%rax
  1f6fc7:	mov    %rax,0x18(%rsp)
  1f6fcc:	mov    0x10(%rsp),%rsi
  1f6fd1:	mov    %esi,%edi
  1f6fd3:	and    $0x3,%edi
  1f6fd6:	and    %r10,%rsi
  1f6fd9:	mov    %rsi,0x10(%rsp)
  1f6fde:	mov    0x8(%rsp),%rsi
  1f6fe3:	mov    %esi,%eax
  1f6fe5:	and    $0x3,%eax
  1f6fe8:	and    %r10,%rsi
  1f6feb:	mov    %rsi,0x8(%rsp)
  1f6ff0:	mov    (%rsp),%rsi
  1f6ff4:	mov    %esi,%r12d
  1f6ff7:	and    $0x3,%r12d
  1f6ffb:	and    %r10,%rsi
  1f6ffe:	mov    %rsi,(%rsp)
  1f7002:	cmpq   $0x0,0x40(%rsp)
  1f7008:	je     1f721d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x7ed>
  1f700e:	test   %r8,%r8
  1f7011:	je     1f7645 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc15>
  1f7017:	mov    %rax,0x90(%rsp)
  1f701f:	mov    %r12,0xb0(%rsp)
  1f7027:	mov    0x50(%rsp),%r12
  1f702c:	and    %r10,%r12
  1f702f:	mov    0x48(%rsp),%rax
  1f7034:	and    %r10,%rax
  1f7037:	mov    0x58(%rsp),%rsi
  1f703c:	mov    %rax,0x48(%rsp)
  1f7041:	vmovsd (%rsi,%rax,8),%xmm4
  1f7046:	mov    0x60(%rsp),%rsi
  1f704b:	mov    %r12,0x50(%rsp)
  1f7050:	vbroadcastsd (%rsi,%r12,8),%ymm1
  1f7056:	vmulsd %xmm1,%xmm1,%xmm2
  1f705a:	negq   0x40(%rsp)
  1f705f:	vxorpd %xmm0,%xmm0,%xmm0
  1f7063:	vxorpd %xmm3,%xmm3,%xmm3
  1f7067:	mov    $0x1,%r10d
  1f706d:	xor    %r12d,%r12d
  1f7070:	jmp    1f70de <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x6ae>
  1f7072:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1f7080:	vmovsd (%r14,%r12,1),%xmm5
  1f7086:	vfmadd213sd 0x0(%rbp,%r12,1),%xmm2,%xmm5
  1f708d:	vfmadd213sd %xmm3,%xmm4,%xmm5
  1f7092:	vmovapd %xmm4,%xmm3
  1f7096:	vpermilpd $0x1,0x0(%r13,%r12,2),%xmm6
  1f709e:	vinsertf128 $0x1,(%rbx,%r12,2),%ymm6,%ymm6
  1f70a5:	vpermilpd $0x1,(%r15,%r12,2),%xmm7
  1f70ac:	vinsertf128 $0x1,(%rdx,%r12,2),%ymm7,%ymm7
  1f70b3:	vfmadd231pd %ymm6,%ymm1,%ymm7
  1f70b8:	vbroadcastsd %xmm4,%ymm4
  1f70bd:	vfmadd231pd %ymm4,%ymm7,%ymm0
  1f70c2:	add    $0x8,%r12
  1f70c6:	mov    0x40(%rsp),%rsi
  1f70cb:	add    %r10,%rsi
  1f70ce:	inc    %rsi
  1f70d1:	inc    %r10
  1f70d4:	vmovapd %xmm5,%xmm4
  1f70d8:	cmp    $0x1,%rsi
  1f70dc:	je     1f70e9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x6b9>
  1f70de:	cmp    %r11,%r10
  1f70e1:	jb     1f7080 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x650>
  1f70e3:	vmovapd %xmm4,%xmm5
  1f70e7:	jmp    1f7096 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x666>
  1f70e9:	test   %rcx,%rcx
  1f70ec:	mov    0xb0(%rsp),%r12
  1f70f4:	mov    0x90(%rsp),%rax
  1f70fc:	je     1f765b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc2b>
  1f7102:	vextractf128 $0x1,%ymm0,%xmm1
  1f7108:	mov    0x38(%rsp),%rsi
  1f710d:	mov    0x18(%rsp),%r10
  1f7112:	vmovlpd %xmm1,(%rsi,%r10,8)
  1f7118:	test   %rdi,%rdi
  1f711b:	je     1f7671 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc41>
  1f7121:	mov    0x30(%rsp),%rsi
  1f7126:	mov    0x10(%rsp),%r10
  1f712b:	vmovhpd %xmm1,(%rsi,%r10,8)
  1f7131:	test   %rax,%rax
  1f7134:	je     1f7684 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc54>
  1f713a:	mov    0x28(%rsp),%rsi
  1f713f:	mov    0x8(%rsp),%r10
  1f7144:	vmovhpd %xmm0,(%rsi,%r10,8)
  1f714a:	test   %r12,%r12
  1f714d:	je     1f769a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc6a>
  1f7153:	mov    0x20(%rsp),%rsi
  1f7158:	mov    (%rsp),%r10
  1f715c:	vmovlpd %xmm0,(%rsi,%r10,8)
  1f7162:	cmp    $0x1,%r9d
  1f7166:	je     1f754b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xb1b>
  1f716c:	cmp    $0x1,%r8d
  1f7170:	je     1f7645 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc15>
  1f7176:	mov    0x58(%rsp),%rsi
  1f717b:	mov    0x48(%rsp),%r10
  1f7180:	vmovsd 0x8(%rsi,%r10,8),%xmm4
  1f7187:	mov    0x60(%rsp),%rsi
  1f718c:	mov    0x50(%rsp),%r10
  1f7191:	vbroadcastsd 0x8(%rsi,%r10,8),%ymm1
  1f7198:	vmulsd %xmm1,%xmm1,%xmm2
  1f719c:	vxorpd %xmm0,%xmm0,%xmm0
  1f71a0:	vxorpd %xmm3,%xmm3,%xmm3
  1f71a4:	mov    $0x1,%r10d
  1f71aa:	xor    %r12d,%r12d
  1f71ad:	jmp    1f7212 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x7e2>
  1f71af:	nop
  1f71b0:	vmovsd (%r14,%r12,1),%xmm5
  1f71b6:	vfmadd213sd 0x0(%rbp,%r12,1),%xmm2,%xmm5
  1f71bd:	vfmadd213sd %xmm3,%xmm4,%xmm5
  1f71c2:	vmovapd %xmm4,%xmm3
  1f71c6:	vpermilpd $0x1,0x0(%r13,%r12,2),%xmm6
  1f71ce:	vinsertf128 $0x1,(%rbx,%r12,2),%ymm6,%ymm6
  1f71d5:	vpermilpd $0x1,(%r15,%r12,2),%xmm7
  1f71dc:	vinsertf128 $0x1,(%rdx,%r12,2),%ymm7,%ymm7
  1f71e3:	vfmadd231pd %ymm6,%ymm1,%ymm7
  1f71e8:	vbroadcastsd %xmm4,%ymm4
  1f71ed:	vfmadd231pd %ymm4,%ymm7,%ymm0
  1f71f2:	add    $0x8,%r12
  1f71f6:	mov    0x40(%rsp),%rsi
  1f71fb:	add    %r10,%rsi
  1f71fe:	inc    %rsi
  1f7201:	inc    %r10
  1f7204:	vmovapd %xmm5,%xmm4
  1f7208:	cmp    $0x1,%rsi
  1f720c:	je     1f73a4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x974>
  1f7212:	cmp    %r11,%r10
  1f7215:	jb     1f71b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x780>
  1f7217:	vmovapd %xmm4,%xmm5
  1f721b:	jmp    1f71c6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x796>
  1f721d:	test   %r8,%r8
  1f7220:	je     1f7645 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc15>
  1f7226:	test   %rcx,%rcx
  1f7229:	je     1f765b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc2b>
  1f722f:	mov    0x38(%rsp),%rdx
  1f7234:	mov    0x18(%rsp),%rsi
  1f7239:	movq   $0x0,(%rdx,%rsi,8)
  1f7241:	test   %rdi,%rdi
  1f7244:	je     1f7671 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc41>
  1f724a:	mov    0x30(%rsp),%rdx
  1f724f:	mov    0x10(%rsp),%rsi
  1f7254:	movq   $0x0,(%rdx,%rsi,8)
  1f725c:	test   %rax,%rax
  1f725f:	je     1f7684 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc54>
  1f7265:	mov    0x28(%rsp),%rdx
  1f726a:	mov    0x8(%rsp),%rsi
  1f726f:	movq   $0x0,(%rdx,%rsi,8)
  1f7277:	test   %r12,%r12
  1f727a:	je     1f769a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc6a>
  1f7280:	mov    0x20(%rsp),%rdx
  1f7285:	mov    (%rsp),%rsi
  1f7289:	movq   $0x0,(%rdx,%rsi,8)
  1f7291:	cmp    $0x1,%r9d
  1f7295:	je     1f754b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xb1b>
  1f729b:	cmp    $0x1,%r8d
  1f729f:	je     1f7645 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc15>
  1f72a5:	cmp    $0x1,%ecx
  1f72a8:	je     1f765b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc2b>
  1f72ae:	mov    0x38(%rsp),%rdx
  1f72b3:	mov    0x18(%rsp),%rsi
  1f72b8:	movq   $0x0,0x8(%rdx,%rsi,8)
  1f72c1:	cmp    $0x1,%edi
  1f72c4:	je     1f7671 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc41>
  1f72ca:	mov    0x30(%rsp),%rdx
  1f72cf:	mov    0x10(%rsp),%rsi
  1f72d4:	movq   $0x0,0x8(%rdx,%rsi,8)
  1f72dd:	cmp    $0x1,%eax
  1f72e0:	je     1f7684 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc54>
  1f72e6:	mov    0x28(%rsp),%rdx
  1f72eb:	mov    0x8(%rsp),%rsi
  1f72f0:	movq   $0x0,0x8(%rdx,%rsi,8)
  1f72f9:	cmp    $0x1,%r12d
  1f72fd:	je     1f769a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc6a>
  1f7303:	mov    0x20(%rsp),%rdx
  1f7308:	mov    (%rsp),%rsi
  1f730c:	movq   $0x0,0x8(%rdx,%rsi,8)
  1f7315:	cmp    $0x2,%r9d
  1f7319:	je     1f754b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xb1b>
  1f731f:	cmp    $0x2,%r8d
  1f7323:	je     1f7645 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc15>
  1f7329:	cmp    $0x2,%ecx
  1f732c:	je     1f765b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc2b>
  1f7332:	mov    0x38(%rsp),%rcx
  1f7337:	mov    0x18(%rsp),%rdx
  1f733c:	movq   $0x0,0x10(%rcx,%rdx,8)
  1f7345:	cmp    $0x2,%edi
  1f7348:	je     1f7671 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc41>
  1f734e:	mov    %rax,%rdx
  1f7351:	mov    0x30(%rsp),%rax
  1f7356:	mov    0x10(%rsp),%rcx
  1f735b:	movq   $0x0,0x10(%rax,%rcx,8)
  1f7364:	mov    %rdx,%rax
  1f7367:	cmp    $0x2,%eax
  1f736a:	je     1f7684 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc54>
  1f7370:	mov    0x28(%rsp),%rax
  1f7375:	mov    0x8(%rsp),%rcx
  1f737a:	movq   $0x0,0x10(%rax,%rcx,8)
  1f7383:	cmp    $0x2,%r12d
  1f7387:	je     1f769a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc6a>
  1f738d:	mov    0x20(%rsp),%rax
  1f7392:	mov    (%rsp),%rcx
  1f7396:	movq   $0x0,0x10(%rax,%rcx,8)
  1f739f:	jmp    1f754b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xb1b>
  1f73a4:	cmp    $0x1,%ecx
  1f73a7:	mov    0xb0(%rsp),%r12
  1f73af:	je     1f765b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc2b>
  1f73b5:	vextractf128 $0x1,%ymm0,%xmm1
  1f73bb:	mov    0x38(%rsp),%rsi
  1f73c0:	mov    0x18(%rsp),%r10
  1f73c5:	vmovlpd %xmm1,0x8(%rsi,%r10,8)
  1f73cc:	cmp    $0x1,%edi
  1f73cf:	je     1f7671 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc41>
  1f73d5:	mov    0x30(%rsp),%rsi
  1f73da:	mov    0x10(%rsp),%r10
  1f73df:	vmovhpd %xmm1,0x8(%rsi,%r10,8)
  1f73e6:	cmp    $0x1,%eax
  1f73e9:	je     1f7684 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc54>
  1f73ef:	mov    0x28(%rsp),%rsi
  1f73f4:	mov    0x8(%rsp),%r10
  1f73f9:	vmovhpd %xmm0,0x8(%rsi,%r10,8)
  1f7400:	cmp    $0x1,%r12d
  1f7404:	je     1f769a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc6a>
  1f740a:	mov    0x20(%rsp),%rsi
  1f740f:	mov    (%rsp),%r10
  1f7413:	vmovlpd %xmm0,0x8(%rsi,%r10,8)
  1f741a:	cmp    $0x2,%r9d
  1f741e:	je     1f754b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xb1b>
  1f7424:	cmp    $0x2,%r8d
  1f7428:	je     1f7645 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc15>
  1f742e:	mov    0x58(%rsp),%rsi
  1f7433:	mov    0x48(%rsp),%r8
  1f7438:	vmovsd 0x10(%rsi,%r8,8),%xmm4
  1f743f:	mov    0x60(%rsp),%rsi
  1f7444:	mov    0x50(%rsp),%r8
  1f7449:	vbroadcastsd 0x10(%rsi,%r8,8),%ymm1
  1f7450:	vmulsd %xmm1,%xmm1,%xmm2
  1f7454:	vxorpd %xmm0,%xmm0,%xmm0
  1f7458:	vxorpd %xmm3,%xmm3,%xmm3
  1f745c:	mov    $0x1,%r8d
  1f7462:	xor    %r9d,%r9d
  1f7465:	jmp    1f74ce <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa9e>
  1f7467:	nopw   0x0(%rax,%rax,1)
  1f7470:	vmovsd (%r14,%r9,1),%xmm5
  1f7476:	vfmadd213sd 0x0(%rbp,%r9,1),%xmm2,%xmm5
  1f747d:	vfmadd213sd %xmm3,%xmm4,%xmm5
  1f7482:	vmovapd %xmm4,%xmm3
  1f7486:	vpermilpd $0x1,0x0(%r13,%r9,2),%xmm6
  1f748e:	vinsertf128 $0x1,(%rbx,%r9,2),%ymm6,%ymm6
  1f7495:	vpermilpd $0x1,(%r15,%r9,2),%xmm7
  1f749c:	vinsertf128 $0x1,(%rdx,%r9,2),%ymm7,%ymm7
  1f74a3:	vfmadd231pd %ymm6,%ymm1,%ymm7
  1f74a8:	vbroadcastsd %xmm4,%ymm4
  1f74ad:	vfmadd231pd %ymm4,%ymm7,%ymm0
  1f74b2:	add    $0x8,%r9
  1f74b6:	mov    0x40(%rsp),%rsi
  1f74bb:	add    %r8,%rsi
  1f74be:	inc    %rsi
  1f74c1:	inc    %r8
  1f74c4:	vmovapd %xmm5,%xmm4
  1f74c8:	cmp    $0x1,%rsi
  1f74cc:	je     1f74d9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xaa9>
  1f74ce:	cmp    %r11,%r8
  1f74d1:	jb     1f7470 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa40>
  1f74d3:	vmovapd %xmm4,%xmm5
  1f74d7:	jmp    1f7486 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa56>
  1f74d9:	cmp    $0x2,%ecx
  1f74dc:	je     1f765b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc2b>
  1f74e2:	vextractf128 $0x1,%ymm0,%xmm1
  1f74e8:	mov    0x38(%rsp),%rcx
  1f74ed:	mov    0x18(%rsp),%rdx
  1f74f2:	vmovlpd %xmm1,0x10(%rcx,%rdx,8)
  1f74f8:	cmp    $0x2,%edi
  1f74fb:	je     1f7671 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc41>
  1f7501:	mov    0x30(%rsp),%rax
  1f7506:	mov    0x10(%rsp),%rcx
  1f750b:	vmovhpd %xmm1,0x10(%rax,%rcx,8)
  1f7511:	mov    0x90(%rsp),%rax
  1f7519:	cmp    $0x2,%eax
  1f751c:	je     1f7684 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc54>
  1f7522:	mov    0x28(%rsp),%rax
  1f7527:	mov    0x8(%rsp),%rcx
  1f752c:	vmovhpd %xmm0,0x10(%rax,%rcx,8)
  1f7532:	cmp    $0x2,%r12d
  1f7536:	je     1f769a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xc6a>
  1f753c:	mov    0x20(%rsp),%rax
  1f7541:	mov    (%rsp),%rcx
  1f7545:	vmovlpd %xmm0,0x10(%rax,%rcx,8)
  1f754b:	add    $0x228,%rsp
  1f7552:	pop    %rbx
  1f7553:	pop    %r12
  1f7555:	pop    %r13
  1f7557:	pop    %r14
  1f7559:	pop    %r15
  1f755b:	pop    %rbp
  1f755c:	vzeroupper
  1f755f:	ret
  1f7560:	lea    0x14fc39(%rip),%rdx        # 3471a0 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.7064714083864131957+0x528>
  1f7567:	mov    0x68(%rsp),%rsi
  1f756c:	vzeroupper
  1f756f:	call   *0x15c1a3(%rip)        # 353718 <_DYNAMIC+0x2b8>
  1f7575:	lea    0x14fc0c(%rip),%rdx        # 347188 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.7064714083864131957+0x510>
  1f757c:	mov    0x70(%rsp),%rsi
  1f7581:	vzeroupper
  1f7584:	call   *0x15c18e(%rip)        # 353718 <_DYNAMIC+0x2b8>
  1f758a:	lea    0x14fbdf(%rip),%rdx        # 347170 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.7064714083864131957+0x4f8>
  1f7591:	mov    0x78(%rsp),%rsi
  1f7596:	vzeroupper
  1f7599:	call   *0x15c179(%rip)        # 353718 <_DYNAMIC+0x2b8>
  1f759f:	lea    0x14fbb2(%rip),%rdx        # 347158 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.7064714083864131957+0x4e0>
  1f75a6:	mov    0x80(%rsp),%rsi
  1f75ae:	vzeroupper
  1f75b1:	call   *0x15c161(%rip)        # 353718 <_DYNAMIC+0x2b8>
  1f75b7:	lea    0x14fb6a(%rip),%rdx        # 347128 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.7064714083864131957+0x4b0>
  1f75be:	vzeroupper
  1f75c1:	call   *0x15c151(%rip)        # 353718 <_DYNAMIC+0x2b8>
  1f75c7:	lea    0x14fc02(%rip),%rdx        # 3471d0 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.7064714083864131957+0x558>
  1f75ce:	mov    %r9,%rdi
  1f75d1:	mov    0x78(%rsp),%rsi
  1f75d6:	vzeroupper
  1f75d9:	call   *0x15c139(%rip)        # 353718 <_DYNAMIC+0x2b8>
  1f75df:	lea    0x14fc1a(%rip),%rdx        # 347200 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.7064714083864131957+0x588>
  1f75e6:	mov    %r9,%rdi
  1f75e9:	mov    0x68(%rsp),%rsi
  1f75ee:	vzeroupper
  1f75f1:	call   *0x15c121(%rip)        # 353718 <_DYNAMIC+0x2b8>
  1f75f7:	lea    0x14fb42(%rip),%rdx        # 347140 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.7064714083864131957+0x4c8>
  1f75fe:	mov    %r9,%rdi
  1f7601:	mov    0x88(%rsp),%rsi
  1f7609:	vzeroupper
  1f760c:	call   *0x15c106(%rip)        # 353718 <_DYNAMIC+0x2b8>
  1f7612:	lea    0x14fbcf(%rip),%rdx        # 3471e8 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.7064714083864131957+0x570>
  1f7619:	mov    %r9,%rdi
  1f761c:	mov    0x70(%rsp),%rsi
  1f7621:	vzeroupper
  1f7624:	call   *0x15c0ee(%rip)        # 353718 <_DYNAMIC+0x2b8>
  1f762a:	lea    0x14fb87(%rip),%rdx        # 3471b8 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.7064714083864131957+0x540>
  1f7631:	mov    %r9,%rdi
  1f7634:	mov    0x80(%rsp),%rsi
  1f763c:	vzeroupper
  1f763f:	call   *0x15c0d3(%rip)        # 353718 <_DYNAMIC+0x2b8>
  1f7645:	lea    0x14fa64(%rip),%rdx        # 3470b0 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.7064714083864131957+0x438>
  1f764c:	mov    %r8,%rdi
  1f764f:	mov    %r8,%rsi
  1f7652:	vzeroupper
  1f7655:	call   *0x15c0bd(%rip)        # 353718 <_DYNAMIC+0x2b8>
  1f765b:	lea    0x14fa66(%rip),%rdx        # 3470c8 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.7064714083864131957+0x450>
  1f7662:	mov    %rcx,%rdi
  1f7665:	mov    %rcx,%rsi
  1f7668:	vzeroupper
  1f766b:	call   *0x15c0a7(%rip)        # 353718 <_DYNAMIC+0x2b8>
  1f7671:	lea    0x14fa68(%rip),%rdx        # 3470e0 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.7064714083864131957+0x468>
  1f7678:	mov    %rdi,%rsi
  1f767b:	vzeroupper
  1f767e:	call   *0x15c094(%rip)        # 353718 <_DYNAMIC+0x2b8>
  1f7684:	lea    0x14fa6d(%rip),%rdx        # 3470f8 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.7064714083864131957+0x480>
  1f768b:	mov    %rax,%rdi
  1f768e:	mov    %rax,%rsi
  1f7691:	vzeroupper
  1f7694:	call   *0x15c07e(%rip)        # 353718 <_DYNAMIC+0x2b8>
  1f769a:	lea    0x14fa6f(%rip),%rdx        # 347110 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.7064714083864131957+0x498>
  1f76a1:	mov    %r12,%rdi
  1f76a4:	mov    %r12,%rsi
  1f76a7:	vzeroupper
  1f76aa:	call   *0x15c068(%rip)        # 353718 <_DYNAMIC+0x2b8>

