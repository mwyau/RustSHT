00000000001f6760 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>>:
  1f6760:	push   %rbp
  1f6761:	push   %r15
  1f6763:	push   %r14
  1f6765:	push   %r13
  1f6767:	push   %r12
  1f6769:	push   %rbx
  1f676a:	sub    $0x98,%rsp
  1f6771:	mov    0xc0(%rdi),%r13
  1f6778:	mov    (%rdi),%rax
  1f677b:	mov    %rax,0x70(%rsp)
  1f6780:	mov    0x8(%rdi),%rbx
  1f6784:	mov    0x10(%rdi),%rbp
  1f6788:	mov    0x18(%rdi),%r9
  1f678c:	mov    0x20(%rdi),%r11
  1f6790:	mov    0x28(%rdi),%rax
  1f6794:	mov    0x30(%rdi),%r14
  1f6798:	mov    0x38(%rdi),%rcx
  1f679c:	mov    0x40(%rdi),%r12
  1f67a0:	mov    0x48(%rdi),%rsi
  1f67a4:	mov    0x50(%rdi),%rdx
  1f67a8:	mov    0x58(%rdi),%r8
  1f67ac:	mov    %rbx,0x60(%rsp)
  1f67b1:	shr    $0x2,%rbx
  1f67b5:	cmp    %r9,%rax
  1f67b8:	cmovb  %rax,%r9
  1f67bc:	mov    0x60(%rdi),%r10
  1f67c0:	cmp    %r9,%rcx
  1f67c3:	cmovb  %rcx,%r9
  1f67c7:	mov    0x68(%rdi),%rax
  1f67cb:	cmp    %r9,%rsi
  1f67ce:	cmovb  %rsi,%r9
  1f67d2:	mov    0x70(%rdi),%rcx
  1f67d6:	mov    %rcx,0x68(%rsp)
  1f67db:	cmp    %r9,%r8
  1f67de:	cmovb  %r8,%r9
  1f67e2:	mov    0x78(%rdi),%rcx
  1f67e6:	mov    %rcx,0x58(%rsp)
  1f67eb:	cmp    %r9,%rax
  1f67ee:	cmovb  %rax,%r9
  1f67f2:	mov    %r9,0x90(%rsp)
  1f67fa:	mov    0x80(%rdi),%rax
  1f6801:	mov    %rax,0x50(%rsp)
  1f6806:	mov    0x88(%rdi),%rax
  1f680d:	mov    %rax,0x30(%rsp)
  1f6812:	mov    0x90(%rdi),%rax
  1f6819:	mov    %rax,0x48(%rsp)
  1f681e:	mov    0x98(%rdi),%rax
  1f6825:	mov    %rax,0x28(%rsp)
  1f682a:	mov    0xa0(%rdi),%rax
  1f6831:	mov    %rax,0x40(%rsp)
  1f6836:	mov    0xa8(%rdi),%rax
  1f683d:	mov    %rax,0x20(%rsp)
  1f6842:	mov    0xb0(%rdi),%rax
  1f6849:	mov    %rax,0x38(%rsp)
  1f684e:	mov    0xb8(%rdi),%rax
  1f6855:	mov    %rax,0x18(%rsp)
  1f685a:	mov    %rbx,0x10(%rsp)
  1f685f:	test   %rbx,%rbx
  1f6862:	je     1f6ab1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x351>
  1f6868:	mov    0x58(%rsp),%rax
  1f686d:	shr    $0x2,%rax
  1f6871:	mov    %rax,0x8(%rsp)
  1f6876:	mov    0x30(%rsp),%rax
  1f687b:	shr    $0x2,%rax
  1f687f:	mov    %rax,0x88(%rsp)
  1f6887:	mov    0x28(%rsp),%rax
  1f688c:	shr    $0x2,%rax
  1f6890:	mov    %rax,0x80(%rsp)
  1f6898:	mov    0x20(%rsp),%rax
  1f689d:	shr    $0x2,%rax
  1f68a1:	mov    %rax,0x78(%rsp)
  1f68a6:	mov    0x18(%rsp),%rdi
  1f68ab:	shr    $0x2,%rdi
  1f68af:	mov    0x90(%rsp),%r9
  1f68b7:	test   %r9,%r9
  1f68ba:	je     1f6a38 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x2d8>
  1f68c0:	neg    %r9
  1f68c3:	xor    %r15d,%r15d
  1f68c6:	cs nopw 0x0(%rax,%rax,1)
  1f68d0:	cmp    0x8(%rsp),%r15
  1f68d5:	je     1f70ce <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x96e>
  1f68db:	lea    0x1(%r15),%rbx
  1f68df:	mov    %r15,%rsi
  1f68e2:	shl    $0x5,%rsi
  1f68e6:	mov    0x70(%rsp),%rax
  1f68eb:	vmovupd (%rax,%rsi,1),%ymm3
  1f68f0:	mov    0x68(%rsp),%rax
  1f68f5:	vmovupd (%rax,%rsi,1),%ymm7
  1f68fa:	vmulpd %ymm3,%ymm3,%ymm4
  1f68fe:	vxorpd %xmm5,%xmm5,%xmm5
  1f6902:	mov    $0x1,%eax
  1f6907:	xor    %ecx,%ecx
  1f6909:	vxorpd %xmm0,%xmm0,%xmm0
  1f690d:	vxorpd %xmm1,%xmm1,%xmm1
  1f6911:	vxorpd %xmm2,%xmm2,%xmm2
  1f6915:	vxorpd %xmm6,%xmm6,%xmm6
  1f6919:	jmp    1f69af <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x24f>
  1f691e:	xchg   %ax,%ax
  1f6920:	vbroadcastsd 0x0(%rbp,%rcx,1),%ymm9
  1f6927:	vbroadcastsd (%r11,%rcx,1),%ymm8
  1f692d:	vfmadd231pd %ymm9,%ymm4,%ymm8
  1f6932:	vfmadd213pd %ymm5,%ymm7,%ymm8
  1f6937:	vmovapd %ymm7,%ymm5
  1f693b:	vbroadcastsd (%r12,%rcx,2),%ymm9
  1f6941:	vbroadcastsd (%r14,%rcx,2),%ymm10
  1f6947:	vfmadd231pd %ymm9,%ymm3,%ymm10
  1f694c:	vbroadcastsd 0x8(%r12,%rcx,2),%ymm9
  1f6953:	vbroadcastsd 0x8(%r14,%rcx,2),%ymm11
  1f695a:	vfmadd231pd %ymm9,%ymm3,%ymm11
  1f695f:	vbroadcastsd (%r10,%rcx,2),%ymm9
  1f6965:	vbroadcastsd (%rdx,%rcx,2),%ymm12
  1f696b:	vfmadd231pd %ymm9,%ymm3,%ymm12
  1f6970:	vbroadcastsd 0x8(%r10,%rcx,2),%ymm9
  1f6977:	vbroadcastsd 0x8(%rdx,%rcx,2),%ymm13
  1f697e:	vfmadd231pd %ymm9,%ymm3,%ymm13
  1f6983:	vfmadd231pd %ymm10,%ymm7,%ymm6
  1f6988:	vfmadd231pd %ymm11,%ymm7,%ymm2
  1f698d:	vfmadd231pd %ymm12,%ymm7,%ymm1
  1f6992:	vfmadd231pd %ymm13,%ymm7,%ymm0
  1f6997:	add    $0x8,%rcx
  1f699b:	lea    (%r9,%rax,1),%r8
  1f699f:	inc    %r8
  1f69a2:	inc    %rax
  1f69a5:	vmovapd %ymm8,%ymm7
  1f69a9:	cmp    $0x1,%r8
  1f69ad:	je     1f69d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x270>
  1f69af:	cmp    %r13,%rax
  1f69b2:	jb     1f6920 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x1c0>
  1f69b8:	vmovapd %ymm7,%ymm8
  1f69bc:	jmp    1f693b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x1db>
  1f69c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  1f69d0:	cmp    0x88(%rsp),%r15
  1f69d8:	je     1f70e6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x986>
  1f69de:	mov    0x50(%rsp),%rax
  1f69e3:	vmovupd %ymm6,(%rax,%rsi,1)
  1f69e8:	cmp    0x80(%rsp),%r15
  1f69f0:	je     1f7101 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9a1>
  1f69f6:	mov    0x48(%rsp),%rax
  1f69fb:	vmovupd %ymm2,(%rax,%rsi,1)
  1f6a00:	cmp    0x78(%rsp),%r15
  1f6a05:	je     1f711c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9bc>
  1f6a0b:	mov    0x40(%rsp),%rax
  1f6a10:	vmovupd %ymm1,(%rax,%rsi,1)
  1f6a15:	cmp    %rdi,%r15
  1f6a18:	je     1f7134 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9d4>
  1f6a1e:	mov    0x38(%rsp),%rax
  1f6a23:	vmovupd %ymm0,(%rax,%rsi,1)
  1f6a28:	mov    %rbx,%r15
  1f6a2b:	cmp    0x10(%rsp),%rbx
  1f6a30:	jne    1f68d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x170>
  1f6a36:	jmp    1f6ab1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x351>
  1f6a38:	xor    %eax,%eax
  1f6a3a:	vxorpd %xmm0,%xmm0,%xmm0
  1f6a3e:	xor    %ecx,%ecx
  1f6a40:	cmp    %rcx,0x8(%rsp)
  1f6a45:	je     1f70ce <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x96e>
  1f6a4b:	cmp    %rcx,0x88(%rsp)
  1f6a53:	je     1f70e6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x986>
  1f6a59:	mov    0x50(%rsp),%rsi
  1f6a5e:	vmovupd %ymm0,(%rsi,%rax,1)
  1f6a63:	cmp    %rcx,0x80(%rsp)
  1f6a6b:	je     1f7101 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9a1>
  1f6a71:	mov    0x48(%rsp),%rsi
  1f6a76:	vmovupd %ymm0,(%rsi,%rax,1)
  1f6a7b:	cmp    %rcx,0x78(%rsp)
  1f6a80:	je     1f711c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9bc>
  1f6a86:	mov    0x40(%rsp),%rsi
  1f6a8b:	vmovupd %ymm0,(%rsi,%rax,1)
  1f6a90:	cmp    %rcx,%rdi
  1f6a93:	je     1f7134 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9d4>
  1f6a99:	inc    %rcx
  1f6a9c:	mov    0x38(%rsp),%rsi
  1f6aa1:	vmovupd %ymm0,(%rsi,%rax,1)
  1f6aa6:	add    $0x20,%rax
  1f6aaa:	cmp    %rcx,0x10(%rsp)
  1f6aaf:	jne    1f6a40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x2e0>
  1f6ab1:	mov    0x60(%rsp),%rsi
  1f6ab6:	and    $0x3,%esi
  1f6ab9:	je     1f70b9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x959>
  1f6abf:	movabs $0xffffffffffffffc,%r9
  1f6ac9:	mov    0x58(%rsp),%r8
  1f6ace:	and    $0x3,%r8d
  1f6ad2:	mov    0x30(%rsp),%rax
  1f6ad7:	mov    %eax,%ecx
  1f6ad9:	and    $0x3,%ecx
  1f6adc:	and    %r9,%rax
  1f6adf:	mov    %rax,0x30(%rsp)
  1f6ae4:	mov    0x28(%rsp),%rdi
  1f6ae9:	mov    %edi,%eax
  1f6aeb:	and    $0x3,%eax
  1f6aee:	mov    %rax,0x10(%rsp)
  1f6af3:	and    %r9,%rdi
  1f6af6:	mov    %rdi,0x28(%rsp)
  1f6afb:	mov    0x20(%rsp),%rbx
  1f6b00:	mov    %ebx,%edi
  1f6b02:	and    $0x3,%edi
  1f6b05:	and    %r9,%rbx
  1f6b08:	mov    %rbx,0x20(%rsp)
  1f6b0d:	mov    0x18(%rsp),%rbx
  1f6b12:	mov    %ebx,%eax
  1f6b14:	and    $0x3,%eax
  1f6b17:	mov    %rax,0x8(%rsp)
  1f6b1c:	and    %r9,%rbx
  1f6b1f:	mov    %rbx,0x18(%rsp)
  1f6b24:	mov    0x90(%rsp),%rax
  1f6b2c:	test   %rax,%rax
  1f6b2f:	je     1f6d74 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x614>
  1f6b35:	test   %r8,%r8
  1f6b38:	je     1f7147 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9e7>
  1f6b3e:	mov    0x60(%rsp),%rbx
  1f6b43:	and    %r9,%rbx
  1f6b46:	mov    0x58(%rsp),%r15
  1f6b4b:	and    %r9,%r15
  1f6b4e:	mov    0x70(%rsp),%r9
  1f6b53:	mov    %rbx,0x60(%rsp)
  1f6b58:	vmovsd (%r9,%rbx,8),%xmm2
  1f6b5e:	mov    0x68(%rsp),%r9
  1f6b63:	mov    %r15,0x58(%rsp)
  1f6b68:	vmovsd (%r9,%r15,8),%xmm7
  1f6b6e:	vmulsd %xmm2,%xmm2,%xmm3
  1f6b72:	neg    %rax
  1f6b75:	vxorpd %xmm5,%xmm5,%xmm5
  1f6b79:	mov    $0x1,%r9d
  1f6b7f:	xor    %ebx,%ebx
  1f6b81:	vxorpd %xmm0,%xmm0,%xmm0
  1f6b85:	vxorpd %xmm1,%xmm1,%xmm1
  1f6b89:	vxorpd %xmm4,%xmm4,%xmm4
  1f6b8d:	vxorpd %xmm6,%xmm6,%xmm6
  1f6b91:	jmp    1f6c15 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x4b5>
  1f6b96:	cs nopw 0x0(%rax,%rax,1)
  1f6ba0:	vmovsd 0x0(%rbp,%rbx,1),%xmm8
  1f6ba6:	vfmadd213sd (%r11,%rbx,1),%xmm3,%xmm8
  1f6bac:	vfmadd213sd %xmm5,%xmm7,%xmm8
  1f6bb1:	vmovapd %xmm7,%xmm5
  1f6bb5:	vmovsd (%r12,%rbx,2),%xmm9
  1f6bbb:	vmovsd 0x8(%r12,%rbx,2),%xmm10
  1f6bc2:	vfmadd213sd (%r14,%rbx,2),%xmm2,%xmm9
  1f6bc8:	vfmadd231sd %xmm9,%xmm7,%xmm6
  1f6bcd:	vfmadd213sd 0x8(%r14,%rbx,2),%xmm2,%xmm10
  1f6bd4:	vfmadd231sd %xmm10,%xmm7,%xmm4
  1f6bd9:	vmovsd (%r10,%rbx,2),%xmm9
  1f6bdf:	vmovsd 0x8(%r10,%rbx,2),%xmm10
  1f6be6:	vfmadd213sd (%rdx,%rbx,2),%xmm2,%xmm9
  1f6bec:	vfmadd231sd %xmm9,%xmm7,%xmm1
  1f6bf1:	vfmadd213sd 0x8(%rdx,%rbx,2),%xmm2,%xmm10
  1f6bf8:	vfmadd231sd %xmm10,%xmm7,%xmm0
  1f6bfd:	add    $0x8,%rbx
  1f6c01:	lea    (%rax,%r9,1),%r15
  1f6c05:	inc    %r15
  1f6c08:	inc    %r9
  1f6c0b:	vmovapd %xmm8,%xmm7
  1f6c0f:	cmp    $0x1,%r15
  1f6c13:	je     1f6c20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x4c0>
  1f6c15:	cmp    %r13,%r9
  1f6c18:	jb     1f6ba0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x440>
  1f6c1a:	vmovapd %xmm7,%xmm8
  1f6c1e:	jmp    1f6bb5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x455>
  1f6c20:	test   %rcx,%rcx
  1f6c23:	je     1f715d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9fd>
  1f6c29:	mov    0x50(%rsp),%r9
  1f6c2e:	mov    0x30(%rsp),%rbx
  1f6c33:	vmovsd %xmm6,(%r9,%rbx,8)
  1f6c39:	cmpq   $0x0,0x10(%rsp)
  1f6c3f:	je     1f7173 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa13>
  1f6c45:	mov    0x48(%rsp),%r9
  1f6c4a:	mov    0x28(%rsp),%rbx
  1f6c4f:	vmovsd %xmm4,(%r9,%rbx,8)
  1f6c55:	test   %rdi,%rdi
  1f6c58:	je     1f718b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa2b>
  1f6c5e:	mov    0x40(%rsp),%r9
  1f6c63:	mov    0x20(%rsp),%rbx
  1f6c68:	vmovsd %xmm1,(%r9,%rbx,8)
  1f6c6e:	cmpq   $0x0,0x8(%rsp)
  1f6c74:	je     1f719e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa3e>
  1f6c7a:	mov    0x38(%rsp),%r9
  1f6c7f:	mov    0x18(%rsp),%rbx
  1f6c84:	vmovsd %xmm0,(%r9,%rbx,8)
  1f6c8a:	cmp    $0x1,%esi
  1f6c8d:	je     1f70b9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x959>
  1f6c93:	cmp    $0x1,%r8d
  1f6c97:	je     1f7147 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9e7>
  1f6c9d:	mov    0x70(%rsp),%r9
  1f6ca2:	mov    0x60(%rsp),%rbx
  1f6ca7:	vmovsd 0x8(%r9,%rbx,8),%xmm3
  1f6cae:	mov    0x68(%rsp),%r9
  1f6cb3:	mov    0x58(%rsp),%rbx
  1f6cb8:	vmovsd 0x8(%r9,%rbx,8),%xmm7
  1f6cbf:	vmulsd %xmm3,%xmm3,%xmm4
  1f6cc3:	vxorpd %xmm5,%xmm5,%xmm5
  1f6cc7:	mov    $0x1,%r9d
  1f6ccd:	xor    %ebx,%ebx
  1f6ccf:	vxorpd %xmm0,%xmm0,%xmm0
  1f6cd3:	vxorpd %xmm1,%xmm1,%xmm1
  1f6cd7:	vxorpd %xmm2,%xmm2,%xmm2
  1f6cdb:	vxorpd %xmm6,%xmm6,%xmm6
  1f6cdf:	jmp    1f6d69 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x609>
  1f6ce4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  1f6cf0:	vmovsd 0x0(%rbp,%rbx,1),%xmm8
  1f6cf6:	vfmadd213sd (%r11,%rbx,1),%xmm4,%xmm8
  1f6cfc:	vfmadd213sd %xmm5,%xmm7,%xmm8
  1f6d01:	vmovapd %xmm7,%xmm5
  1f6d05:	vmovsd (%r12,%rbx,2),%xmm9
  1f6d0b:	vmovsd 0x8(%r12,%rbx,2),%xmm10
  1f6d12:	vfmadd213sd (%r14,%rbx,2),%xmm3,%xmm9
  1f6d18:	vfmadd231sd %xmm9,%xmm7,%xmm6
  1f6d1d:	vfmadd213sd 0x8(%r14,%rbx,2),%xmm3,%xmm10
  1f6d24:	vfmadd231sd %xmm10,%xmm7,%xmm2
  1f6d29:	vmovsd (%r10,%rbx,2),%xmm9
  1f6d2f:	vmovsd 0x8(%r10,%rbx,2),%xmm10
  1f6d36:	vfmadd213sd (%rdx,%rbx,2),%xmm3,%xmm9
  1f6d3c:	vfmadd231sd %xmm9,%xmm7,%xmm1
  1f6d41:	vfmadd213sd 0x8(%rdx,%rbx,2),%xmm3,%xmm10
  1f6d48:	vfmadd231sd %xmm10,%xmm7,%xmm0
  1f6d4d:	add    $0x8,%rbx
  1f6d51:	lea    (%rax,%r9,1),%r15
  1f6d55:	inc    %r15
  1f6d58:	inc    %r9
  1f6d5b:	vmovapd %xmm8,%xmm7
  1f6d5f:	cmp    $0x1,%r15
  1f6d63:	je     1f6f02 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x7a2>
  1f6d69:	cmp    %r13,%r9
  1f6d6c:	jb     1f6cf0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x590>
  1f6d6e:	vmovapd %xmm7,%xmm8
  1f6d72:	jmp    1f6d05 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x5a5>
  1f6d74:	test   %r8,%r8
  1f6d77:	je     1f7147 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9e7>
  1f6d7d:	test   %rcx,%rcx
  1f6d80:	je     1f715d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9fd>
  1f6d86:	mov    0x50(%rsp),%rdx
  1f6d8b:	mov    0x30(%rsp),%r9
  1f6d90:	movq   $0x0,(%rdx,%r9,8)
  1f6d98:	cmpq   $0x0,0x10(%rsp)
  1f6d9e:	je     1f7173 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa13>
  1f6da4:	mov    0x48(%rsp),%rdx
  1f6da9:	mov    0x28(%rsp),%r9
  1f6dae:	movq   $0x0,(%rdx,%r9,8)
  1f6db6:	test   %rdi,%rdi
  1f6db9:	je     1f718b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa2b>
  1f6dbf:	mov    0x40(%rsp),%rdx
  1f6dc4:	mov    0x20(%rsp),%r9
  1f6dc9:	movq   $0x0,(%rdx,%r9,8)
  1f6dd1:	cmpq   $0x0,0x8(%rsp)
  1f6dd7:	je     1f719e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa3e>
  1f6ddd:	mov    0x38(%rsp),%rdx
  1f6de2:	mov    0x18(%rsp),%r9
  1f6de7:	movq   $0x0,(%rdx,%r9,8)
  1f6def:	cmp    $0x1,%esi
  1f6df2:	je     1f70b9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x959>
  1f6df8:	cmp    $0x1,%r8d
  1f6dfc:	je     1f7147 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9e7>
  1f6e02:	cmp    $0x1,%ecx
  1f6e05:	je     1f715d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9fd>
  1f6e0b:	mov    0x50(%rsp),%rdx
  1f6e10:	mov    0x30(%rsp),%r9
  1f6e15:	movq   $0x0,0x8(%rdx,%r9,8)
  1f6e1e:	cmpl   $0x1,0x10(%rsp)
  1f6e23:	je     1f7173 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa13>
  1f6e29:	mov    0x48(%rsp),%rdx
  1f6e2e:	mov    0x28(%rsp),%r9
  1f6e33:	movq   $0x0,0x8(%rdx,%r9,8)
  1f6e3c:	cmp    $0x1,%edi
  1f6e3f:	je     1f718b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa2b>
  1f6e45:	mov    0x40(%rsp),%rdx
  1f6e4a:	mov    0x20(%rsp),%r9
  1f6e4f:	movq   $0x0,0x8(%rdx,%r9,8)
  1f6e58:	cmpl   $0x1,0x8(%rsp)
  1f6e5d:	je     1f719e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa3e>
  1f6e63:	mov    0x38(%rsp),%rdx
  1f6e68:	mov    0x18(%rsp),%r9
  1f6e6d:	movq   $0x0,0x8(%rdx,%r9,8)
  1f6e76:	cmp    $0x2,%esi
  1f6e79:	je     1f70b9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x959>
  1f6e7f:	cmp    $0x2,%r8d
  1f6e83:	je     1f7147 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9e7>
  1f6e89:	cmp    $0x2,%ecx
  1f6e8c:	je     1f715d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9fd>
  1f6e92:	mov    0x50(%rsp),%rcx
  1f6e97:	mov    0x30(%rsp),%rdx
  1f6e9c:	movq   $0x0,0x10(%rcx,%rdx,8)
  1f6ea5:	cmpl   $0x2,0x10(%rsp)
  1f6eaa:	je     1f7173 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa13>
  1f6eb0:	mov    0x48(%rsp),%rax
  1f6eb5:	mov    0x28(%rsp),%rcx
  1f6eba:	movq   $0x0,0x10(%rax,%rcx,8)
  1f6ec3:	cmp    $0x2,%edi
  1f6ec6:	je     1f718b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa2b>
  1f6ecc:	mov    0x40(%rsp),%rax
  1f6ed1:	mov    0x20(%rsp),%rcx
  1f6ed6:	movq   $0x0,0x10(%rax,%rcx,8)
  1f6edf:	cmpl   $0x2,0x8(%rsp)
  1f6ee4:	je     1f719e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa3e>
  1f6eea:	mov    0x38(%rsp),%rax
  1f6eef:	mov    0x18(%rsp),%rcx
  1f6ef4:	movq   $0x0,0x10(%rax,%rcx,8)
  1f6efd:	jmp    1f70b9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x959>
  1f6f02:	cmp    $0x1,%ecx
  1f6f05:	je     1f715d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9fd>
  1f6f0b:	mov    0x50(%rsp),%r9
  1f6f10:	mov    0x30(%rsp),%rbx
  1f6f15:	vmovsd %xmm6,0x8(%r9,%rbx,8)
  1f6f1c:	cmpl   $0x1,0x10(%rsp)
  1f6f21:	je     1f7173 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa13>
  1f6f27:	mov    0x48(%rsp),%r9
  1f6f2c:	mov    0x28(%rsp),%rbx
  1f6f31:	vmovsd %xmm2,0x8(%r9,%rbx,8)
  1f6f38:	cmp    $0x1,%edi
  1f6f3b:	je     1f718b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa2b>
  1f6f41:	mov    0x40(%rsp),%r9
  1f6f46:	mov    0x20(%rsp),%rbx
  1f6f4b:	vmovsd %xmm1,0x8(%r9,%rbx,8)
  1f6f52:	cmpl   $0x1,0x8(%rsp)
  1f6f57:	je     1f719e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa3e>
  1f6f5d:	mov    0x38(%rsp),%r9
  1f6f62:	mov    0x18(%rsp),%rbx
  1f6f67:	vmovsd %xmm0,0x8(%r9,%rbx,8)
  1f6f6e:	cmp    $0x2,%esi
  1f6f71:	je     1f70b9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x959>
  1f6f77:	cmp    $0x2,%r8d
  1f6f7b:	je     1f7147 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9e7>
  1f6f81:	mov    0x70(%rsp),%rsi
  1f6f86:	mov    0x60(%rsp),%r8
  1f6f8b:	vmovsd 0x10(%rsi,%r8,8),%xmm3
  1f6f92:	mov    0x68(%rsp),%rsi
  1f6f97:	mov    0x58(%rsp),%r8
  1f6f9c:	vmovsd 0x10(%rsi,%r8,8),%xmm7
  1f6fa3:	vmulsd %xmm3,%xmm3,%xmm4
  1f6fa7:	vxorpd %xmm5,%xmm5,%xmm5
  1f6fab:	mov    $0x1,%esi
  1f6fb0:	xor    %r8d,%r8d
  1f6fb3:	vxorpd %xmm0,%xmm0,%xmm0
  1f6fb7:	vxorpd %xmm1,%xmm1,%xmm1
  1f6fbb:	vxorpd %xmm2,%xmm2,%xmm2
  1f6fbf:	vxorpd %xmm6,%xmm6,%xmm6
  1f6fc3:	jmp    1f7046 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x8e6>
  1f6fc8:	nopl   0x0(%rax,%rax,1)
  1f6fd0:	vmovsd 0x0(%rbp,%r8,1),%xmm8
  1f6fd7:	vfmadd213sd (%r11,%r8,1),%xmm4,%xmm8
  1f6fdd:	vfmadd213sd %xmm5,%xmm7,%xmm8
  1f6fe2:	vmovapd %xmm7,%xmm5
  1f6fe6:	vmovsd (%r12,%r8,2),%xmm9
  1f6fec:	vmovsd 0x8(%r12,%r8,2),%xmm10
  1f6ff3:	vfmadd213sd (%r14,%r8,2),%xmm3,%xmm9
  1f6ff9:	vfmadd231sd %xmm9,%xmm7,%xmm6
  1f6ffe:	vfmadd213sd 0x8(%r14,%r8,2),%xmm3,%xmm10
  1f7005:	vfmadd231sd %xmm10,%xmm7,%xmm2
  1f700a:	vmovsd (%r10,%r8,2),%xmm9
  1f7010:	vmovsd 0x8(%r10,%r8,2),%xmm10
  1f7017:	vfmadd213sd (%rdx,%r8,2),%xmm3,%xmm9
  1f701d:	vfmadd231sd %xmm9,%xmm7,%xmm1
  1f7022:	vfmadd213sd 0x8(%rdx,%r8,2),%xmm3,%xmm10
  1f7029:	vfmadd231sd %xmm10,%xmm7,%xmm0
  1f702e:	add    $0x8,%r8
  1f7032:	lea    (%rax,%rsi,1),%r9
  1f7036:	inc    %r9
  1f7039:	inc    %rsi
  1f703c:	vmovapd %xmm8,%xmm7
  1f7040:	cmp    $0x1,%r9
  1f7044:	je     1f7051 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x8f1>
  1f7046:	cmp    %r13,%rsi
  1f7049:	jb     1f6fd0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x870>
  1f704b:	vmovapd %xmm7,%xmm8
  1f704f:	jmp    1f6fe6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x886>
  1f7051:	cmp    $0x2,%ecx
  1f7054:	je     1f715d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0x9fd>
  1f705a:	mov    0x50(%rsp),%rcx
  1f705f:	mov    0x30(%rsp),%rdx
  1f7064:	vmovsd %xmm6,0x10(%rcx,%rdx,8)
  1f706a:	cmpl   $0x2,0x10(%rsp)
  1f706f:	je     1f7173 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa13>
  1f7075:	mov    0x48(%rsp),%rax
  1f707a:	mov    0x28(%rsp),%rcx
  1f707f:	vmovsd %xmm2,0x10(%rax,%rcx,8)
  1f7085:	cmp    $0x2,%edi
  1f7088:	je     1f718b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa2b>
  1f708e:	mov    0x40(%rsp),%rax
  1f7093:	mov    0x20(%rsp),%rcx
  1f7098:	vmovsd %xmm1,0x10(%rax,%rcx,8)
  1f709e:	cmpl   $0x2,0x8(%rsp)
  1f70a3:	je     1f719e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::synthesis::FusedPreparedSynthesisPairBlock>>+0xa3e>
  1f70a9:	mov    0x38(%rsp),%rax
  1f70ae:	mov    0x18(%rsp),%rcx
  1f70b3:	vmovsd %xmm0,0x10(%rax,%rcx,8)
  1f70b9:	add    $0x98,%rsp
  1f70c0:	pop    %rbx
  1f70c1:	pop    %r12
  1f70c3:	pop    %r13
  1f70c5:	pop    %r14
  1f70c7:	pop    %r15
  1f70c9:	pop    %rbp
  1f70ca:	vzeroupper
  1f70cd:	ret
  1f70ce:	lea    0x14fb93(%rip),%rdx        # 346c68 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.5944516456826808612+0x4b0>
  1f70d5:	mov    0x8(%rsp),%rdi
  1f70da:	mov    %rdi,%rsi
  1f70dd:	vzeroupper
  1f70e0:	call   *0x15c0fa(%rip)        # 3531e0 <_DYNAMIC+0x2b8>
  1f70e6:	lea    0x14fb93(%rip),%rdx        # 346c80 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.5944516456826808612+0x4c8>
  1f70ed:	mov    0x88(%rsp),%rdi
  1f70f5:	mov    %rdi,%rsi
  1f70f8:	vzeroupper
  1f70fb:	call   *0x15c0df(%rip)        # 3531e0 <_DYNAMIC+0x2b8>
  1f7101:	lea    0x14fb90(%rip),%rdx        # 346c98 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.5944516456826808612+0x4e0>
  1f7108:	mov    0x80(%rsp),%rdi
  1f7110:	mov    %rdi,%rsi
  1f7113:	vzeroupper
  1f7116:	call   *0x15c0c4(%rip)        # 3531e0 <_DYNAMIC+0x2b8>
  1f711c:	lea    0x14fb8d(%rip),%rdx        # 346cb0 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.5944516456826808612+0x4f8>
  1f7123:	mov    0x78(%rsp),%rdi
  1f7128:	mov    %rdi,%rsi
  1f712b:	vzeroupper
  1f712e:	call   *0x15c0ac(%rip)        # 3531e0 <_DYNAMIC+0x2b8>
  1f7134:	lea    0x14fb8d(%rip),%rdx        # 346cc8 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.5944516456826808612+0x510>
  1f713b:	mov    %rdi,%rsi
  1f713e:	vzeroupper
  1f7141:	call   *0x15c099(%rip)        # 3531e0 <_DYNAMIC+0x2b8>
  1f7147:	lea    0x14faa2(%rip),%rdx        # 346bf0 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.5944516456826808612+0x438>
  1f714e:	mov    %r8,%rdi
  1f7151:	mov    %r8,%rsi
  1f7154:	vzeroupper
  1f7157:	call   *0x15c083(%rip)        # 3531e0 <_DYNAMIC+0x2b8>
  1f715d:	lea    0x14faa4(%rip),%rdx        # 346c08 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.5944516456826808612+0x450>
  1f7164:	mov    %rcx,%rdi
  1f7167:	mov    %rcx,%rsi
  1f716a:	vzeroupper
  1f716d:	call   *0x15c06d(%rip)        # 3531e0 <_DYNAMIC+0x2b8>
  1f7173:	lea    0x14faa6(%rip),%rdx        # 346c20 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.5944516456826808612+0x468>
  1f717a:	mov    0x10(%rsp),%rdi
  1f717f:	mov    %rdi,%rsi
  1f7182:	vzeroupper
  1f7185:	call   *0x15c055(%rip)        # 3531e0 <_DYNAMIC+0x2b8>
  1f718b:	lea    0x14faa6(%rip),%rdx        # 346c38 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.5944516456826808612+0x480>
  1f7192:	mov    %rdi,%rsi
  1f7195:	vzeroupper
  1f7198:	call   *0x15c042(%rip)        # 3531e0 <_DYNAMIC+0x2b8>
  1f719e:	lea    0x14faab(%rip),%rdx        # 346c50 <anon.90c8f467974d2f2a528245fe12e87011.81.llvm.5944516456826808612+0x498>
  1f71a5:	mov    0x8(%rsp),%rdi
  1f71aa:	mov    %rdi,%rsi
  1f71ad:	vzeroupper
  1f71b0:	call   *0x15c02a(%rip)        # 3531e0 <_DYNAMIC+0x2b8>
  1f71b6:	int3
  1f71b7:	int3
  1f71b8:	int3
  1f71b9:	int3
  1f71ba:	int3
  1f71bb:	int3
  1f71bc:	int3
  1f71bd:	int3
  1f71be:	int3
  1f71bf:	int3

00000000001f71c0 <rustsht::legendre::scalar_paired::try_accumulate_scaled_pair_vector::<pulp::x86::v4::V4>::{closure#0}>:
  1f71c0:	push   %rbp
  1f71c1:	mov    %rsp,%rbp
  1f71c4:	push   %r15
  1f71c6:	push   %r14
  1f71c8:	push   %r13
  1f71ca:	push   %r12
  1f71cc:	push   %rbx
  1f71cd:	and    $0xffffffffffffffc0,%rsp
  1f71d1:	sub    $0x1c0,%rsp
  1f71d8:	mov    %ecx,%r15d
  1f71db:	mov    %rdx,0x78(%rsp)
  1f71e0:	mov    %rdi,%r14
  1f71e3:	vmovups (%rsi),%ymm0
  1f71e7:	vmovaps %ymm0,0x120(%rsp)
  1f71f0:	vmovups 0x20(%rsi),%ymm0
  1f71f5:	vmovaps %ymm0,0x100(%rsp)
  1f71fe:	mov    %rsp,%r12
  1f7201:	vmovsd -0x1ce099(%rip),%xmm0        # 29170 <anon.bb3ba90984c43fdac1b866536a519791.107.llvm.17542271190522676961+0x650>
  1f7209:	mov    %r12,%rdi
  1f720c:	vzeroupper
  1f720f:	call   1f79d0 <core::core_arch::x86::avx512f::_mm512_set1_pd>
  1f7214:	lea    0x80(%rsp),%r13
  1f721c:	mov    %r13,%rdi
  1f721f:	call   2b5210 <core::core_arch::x86::avx512f::_mm512_set1_epi64>
  1f7224:	lea    0x140(%rsp),%rbx
  1f722c:	mov    %rbx,%rdi
  1f722f:	mov    %r12,%rsi
  1f7232:	mov    %r13,%rdx
  1f7235:	call   2b51f0 <core::core_arch::x86::avx512f::_mm512_xor_si512>
  1f723a:	vmovaps 0x100(%rsp),%ymm0
  1f7243:	vmovaps %ymm0,0xa0(%rsp)
  1f724c:	vmovaps 0x120(%rsp),%ymm0
  1f7255:	vmovaps %ymm0,0x80(%rsp)
  1f725e:	mov    %rsp,%rdi
  1f7261:	lea    0x80(%rsp),%rdx
  1f7269:	mov    %rbx,%rsi
  1f726c:	vzeroupper
  1f726f:	call   1f7aa0 <core::core_arch::x86::avx512dq::_mm512_and_pd>
  1f7274:	vmovaps (%rsp),%ymm0
  1f7279:	vmovaps %ymm0,0xe0(%rsp)
  1f7282:	vmovaps 0x20(%rsp),%ymm0
  1f7288:	vmovaps %ymm0,0xc0(%rsp)
  1f7291:	lea    0x80(%rsp),%rbx
  1f7299:	vmovsd -0x1ce3a1(%rip),%xmm0        # 28f00 <anon.bb3ba90984c43fdac1b866536a519791.107.llvm.17542271190522676961+0x3e0>
  1f72a1:	mov    %rbx,%rdi
  1f72a4:	vzeroupper
  1f72a7:	call   1f79d0 <core::core_arch::x86::avx512f::_mm512_set1_pd>
  1f72ac:	vmovaps 0xc0(%rsp),%ymm0
  1f72b5:	vmovaps %ymm0,0x20(%rsp)
  1f72bb:	vmovaps 0xe0(%rsp),%ymm0
  1f72c4:	vmovaps %ymm0,(%rsp)
  1f72c9:	mov    %rsp,%rdi
  1f72cc:	mov    %rbx,%rsi
  1f72cf:	vzeroupper
  1f72d2:	call   1df760 <core::core_arch::x86::avx512f::_mm512_cmp_pd_mask::<29>>
  1f72d7:	mov    %eax,%ebx
  1f72d9:	lea    0x80(%rsp),%r12
  1f72e1:	vmovsd -0x1ce541(%rip),%xmm0        # 28da8 <anon.bb3ba90984c43fdac1b866536a519791.107.llvm.17542271190522676961+0x288>
  1f72e9:	mov    %r12,%rdi
  1f72ec:	call   1f79d0 <core::core_arch::x86::avx512f::_mm512_set1_pd>
  1f72f1:	vmovaps 0xc0(%rsp),%ymm0
  1f72fa:	vmovaps %ymm0,0x20(%rsp)
  1f7300:	vmovaps 0xe0(%rsp),%ymm0
  1f7309:	vmovaps %ymm0,(%rsp)
  1f730e:	mov    %rsp,%rdi
  1f7311:	mov    %r12,%rsi
  1f7314:	vzeroupper
  1f7317:	call   1df740 <core::core_arch::x86::avx512f::_mm512_cmp_pd_mask::<18>>
  1f731c:	and    %bl,%al
  1f731e:	test   %r15d,%r15d
  1f7321:	je     1f73e4 <rustsht::legendre::scalar_paired::try_accumulate_scaled_pair_vector::<pulp::x86::v4::V4>::{closure#0}+0x224>
  1f7327:	vmovups (%r14),%ymm1
  1f732c:	vmovaps %ymm1,0xe0(%rsp)
  1f7335:	vmovups 0x20(%r14),%ymm2
  1f733b:	vmovaps %ymm2,0xc0(%rsp)
  1f7344:	vmovaps 0x100(%rsp),%ymm0
  1f734d:	vmovaps %ymm0,0x20(%rsp)
  1f7353:	vmovaps 0x120(%rsp),%ymm0
  1f735c:	vmovaps %ymm0,(%rsp)
  1f7361:	vmovaps %ymm2,0xa0(%rsp)
  1f736a:	vmovaps %ymm1,0x80(%rsp)
  1f7373:	mov    %rsp,%rdi
  1f7376:	lea    0x80(%rsp),%rsi
  1f737e:	mov    %eax,%r14d
  1f7381:	vzeroupper
