use super::*;
use std::{collections::BTreeMap, fs, sync::atomic::Ordering};

fn read_map(path: &str, count: usize) -> Vec<f64> {
    let bytes = fs::read(path).expect("map fixture");
    assert_eq!(bytes.len(), count * 4);
    bytes
        .chunks_exact(4)
        .map(|x| f32::from_le_bytes(x.try_into().unwrap()) as f64)
        .collect()
}

fn read_map_f32(path: &str, count: usize) -> Vec<f32> {
    let bytes = fs::read(path).expect("map fixture");
    assert_eq!(bytes.len(), count * 4);
    bytes
        .chunks_exact(4)
        .map(|x| f32::from_le_bytes(x.try_into().unwrap()))
        .collect()
}

#[test]
fn m6_profile_spin1_analysis_stages() {
    let ntheta = 721usize;
    let nphi = std::env::var("M6_SPIN1_NPHI")
        .unwrap()
        .parse::<usize>()
        .unwrap();
    let mmax = std::env::var("M6_SPIN1_MMAX")
        .unwrap()
        .parse::<usize>()
        .unwrap();
    let threads = std::env::var("M6_SPIN1_THREADS")
        .unwrap()
        .parse::<usize>()
        .unwrap();
    let map0 = read_map(&std::env::var("M6_SPIN1_MAP0").unwrap(), ntheta * nphi);
    let map1 = read_map(&std::env::var("M6_SPIN1_MAP1").unwrap(), ntheta * nphi);
    rayon::ThreadPoolBuilder::new()
        .num_threads(threads)
        .build_global()
        .unwrap();
    let plan = ShtPlan::<f64>::new(
        crate::grid::GridSpec::new(crate::grid::GridKind::GaussLegendre, ntheta, nphi, 0.23)
            .unwrap(),
        crate::harmonics::HarmonicSpec::new(720, mmax, 1).unwrap(),
    )
    .unwrap();
    let mut workspace = plan.workspace().unwrap();
    plan.prepare_workspace(&mut workspace, threads).unwrap();
    let nalm = plan.harmonics.nalm();
    let mut e = vec![Complex::<f64>::new(0.0, 0.0); nalm];
    let mut b = vec![Complex::<f64>::new(0.0, 0.0); nalm];
    let phases = workspace.observe_transform_phases();
    plan.analysis_spin_into(&map0, &map1, &mut e, &mut b, &mut workspace)
        .unwrap();
    phases.lock().unwrap().clear();
    let mut whole = Vec::new();
    for _ in 0..7 {
        let t = std::time::Instant::now();
        plan.analysis_spin_into(&map0, &map1, &mut e, &mut b, &mut workspace)
            .unwrap();
        whole.push(t.elapsed().as_secs_f64() * 1e3);
    }
    let mut groups: BTreeMap<&'static str, Vec<f64>> = BTreeMap::new();
    for item in phases.lock().unwrap().iter() {
        groups
            .entry(item.phase)
            .or_default()
            .push(item.elapsed_ns as f64 / 7.0e6);
    }
    let mut out = String::from("{\"profile_calls\":7,\"phases_ms_per_call\":{");
    for (i, (phase, values)) in groups.iter_mut().enumerate() {
        values.sort_by(f64::total_cmp);
        if i > 0 {
            out.push(',');
        }
        out.push_str(&format!("\"{}\":{:.6}", phase, values[values.len() / 2]));
    }
    out.push_str("},\"phase_records\":{");
    for (i, (phase, values)) in groups.iter().enumerate() {
        if i > 0 {
            out.push(',');
        }
        out.push_str(&format!("\"{}\":{{\"count\":{},\"mean_ms\":{:.6},\"min_ms\":{:.6},\"median_ms\":{:.6},\"max_ms\":{:.6},\"samples_ms\":[",phase,values.len(),values.iter().sum::<f64>() / values.len() as f64,values[0],values[values.len()/2],values[values.len()-1]));
        for (sample_index, sample) in values.iter().enumerate() {
            if sample_index > 0 {
                out.push(',');
            }
            out.push_str(&format!("{sample:.6}"));
        }
        out.push_str("]}");
    }
    let safe = workspace
        .spin1_analysis_pair_range_safe
        .iter()
        .filter(|x| x.load(Ordering::Relaxed))
        .count();
    whole.sort_by(f64::total_cmp);
    out.push_str(&format!("}},\"whole_ms_per_call\":{:.6},\"spin1_range_cache_safe_tiles\":{},\"spin1_range_cache_total_tiles\":{},\"e_checksum\":{:.17},\"b_checksum\":{:.17}}}",whole[whole.len()/2],safe,workspace.spin1_analysis_pair_range_safe.len(),e.iter().map(|x|x.re+x.im).sum::<f64>(),b.iter().map(|x|x.re+x.im).sum::<f64>()));
    println!("{out}");
    assert!(groups.contains_key("forward FFT"));
    assert!(groups.contains_key("Legendre recurrence and accumulation"));
}

#[test]
fn m6_profile_spin1_analysis_two_scalar_route() {
    let ntheta = 721usize;
    let nphi = std::env::var("M6_SPIN1_NPHI")
        .unwrap()
        .parse::<usize>()
        .unwrap();
    let mmax = std::env::var("M6_SPIN1_MMAX")
        .unwrap()
        .parse::<usize>()
        .unwrap();
    let threads = std::env::var("M6_SPIN1_THREADS")
        .unwrap()
        .parse::<usize>()
        .unwrap();
    let map_count = ntheta * nphi;
    let map0_32 = read_map_f32(&std::env::var("M6_SPIN1_MAP0").unwrap(), map_count);
    let map1_32 = read_map_f32(&std::env::var("M6_SPIN1_MAP1").unwrap(), map_count);
    rayon::ThreadPoolBuilder::new()
        .num_threads(threads)
        .build_global()
        .unwrap();

    let grid = crate::grid::GridSpec::new(crate::grid::GridKind::GaussLegendre, ntheta, nphi, 0.23)
        .unwrap();
    let theta_sin = grid
        .theta()
        .iter()
        .map(|theta| theta.sin())
        .collect::<Vec<_>>();
    let scalar_plan = ShtPlan::<f64>::new(
        grid.clone(),
        crate::harmonics::HarmonicSpec::new(721, mmax, 0).unwrap(),
    )
    .unwrap();
    let spin_plan = ShtPlan::<f64>::new(
        grid,
        crate::harmonics::HarmonicSpec::new(720, mmax, 1).unwrap(),
    )
    .unwrap();
    let mut scalar_workspace = scalar_plan.workspace().unwrap();
    let mut spin_workspace = spin_plan.workspace().unwrap();
    scalar_plan
        .prepare_workspace(&mut scalar_workspace, threads)
        .unwrap();
    spin_plan
        .prepare_workspace(&mut spin_workspace, threads)
        .unwrap();
    let scalar_nalm = scalar_plan.harmonics.nalm();
    let spin_nalm = spin_plan.harmonics.nalm();
    let mut map0_64 = vec![0.0; map_count];
    let mut map1_64 = vec![0.0; map_count];
    let mut scalar0 = vec![Complex::<f64>::new(0.0, 0.0); scalar_nalm];
    let mut scalar1 = vec![Complex::<f64>::new(0.0, 0.0); scalar_nalm];
    let mut scalar_by_degree0 = vec![Complex::<f64>::new(0.0, 0.0); 722];
    let mut scalar_by_degree1 = vec![Complex::<f64>::new(0.0, 0.0); 722];
    let mut epsilon = vec![0.0; 722];
    let mut e64 = vec![Complex::<f64>::new(0.0, 0.0); spin_nalm];
    let mut b64 = vec![Complex::<f64>::new(0.0, 0.0); spin_nalm];
    let mut e32 = vec![Complex::<f32>::new(0.0, 0.0); spin_nalm];
    let mut b32 = vec![Complex::<f32>::new(0.0, 0.0); spin_nalm];

    let mut convert_ms = Vec::new();
    let mut first_analysis_ms = Vec::new();
    let mut second_analysis_ms = Vec::new();
    let mut spin_conversion_ms = Vec::new();
    let mut output_conversion_ms = Vec::new();
    let mut whole_ms = Vec::new();
    for repetition in 0..63 {
        let whole_started = std::time::Instant::now();
        let phase_started = std::time::Instant::now();
        for ring in 0..ntheta {
            let start = ring * nphi;
            let end = start + nphi;
            let inverse_sine = theta_sin[ring].recip();
            for index in start..end {
                map0_64[index] = f64::from(map0_32[index]) * inverse_sine;
                map1_64[index] = f64::from(map1_32[index]) * inverse_sine;
            }
        }
        let convert_elapsed = phase_started.elapsed().as_secs_f64() * 1e3;

        let phase_started = std::time::Instant::now();
        scalar_plan
            .analysis_projected_into(&map0_64, &mut scalar0, &mut scalar_workspace)
            .unwrap();
        let first_elapsed = phase_started.elapsed().as_secs_f64() * 1e3;

        let phase_started = std::time::Instant::now();
        scalar_plan
            .analysis_projected_into(&map1_64, &mut scalar1, &mut scalar_workspace)
            .unwrap();
        let second_elapsed = phase_started.elapsed().as_secs_f64() * 1e3;

        let phase_started = std::time::Instant::now();
        let mut scalar_start = 0;
        let mut spin_start = 0;
        for m in 0..=mmax {
            let scalar_count = 722 - m;
            let spin_count = 721 - m;
            scalar_by_degree0.fill(Complex::<f64>::new(0.0, 0.0));
            scalar_by_degree1.fill(Complex::<f64>::new(0.0, 0.0));
            scalar_by_degree0[m..722]
                .copy_from_slice(&scalar0[scalar_start..scalar_start + scalar_count]);
            scalar_by_degree1[m..722]
                .copy_from_slice(&scalar1[scalar_start..scalar_start + scalar_count]);
            <f64 as crate::legendre::ShtScalar>::fill_epsilon(m, 721, &mut epsilon);
            let end = spin_start + spin_count;
            crate::legendre::scalar_to_spin1_with_epsilon(
                m,
                720,
                &scalar_by_degree0,
                &scalar_by_degree1,
                &epsilon,
                &mut e64[spin_start..end],
                &mut b64[spin_start..end],
            );
            scalar_start += scalar_count;
            spin_start = end;
        }
        let conversion_elapsed = phase_started.elapsed().as_secs_f64() * 1e3;

        let phase_started = std::time::Instant::now();
        for ((e, b), (e_out, b_out)) in e64.iter().zip(&b64).zip(e32.iter_mut().zip(&mut b32)) {
            *e_out = Complex::<f32>::new(e.re as f32, e.im as f32);
            *b_out = Complex::<f32>::new(b.re as f32, b.im as f32);
        }
        let output_elapsed = phase_started.elapsed().as_secs_f64() * 1e3;
        std::hint::black_box((&e32, &b32));
        if repetition >= 3 {
            convert_ms.push(convert_elapsed);
            first_analysis_ms.push(first_elapsed);
            second_analysis_ms.push(second_elapsed);
            spin_conversion_ms.push(conversion_elapsed);
            output_conversion_ms.push(output_elapsed);
            whole_ms.push(whole_started.elapsed().as_secs_f64() * 1e3);
        }
    }

    for (source, target) in map0_32.iter().zip(&mut map0_64) {
        *target = f64::from(*source);
    }
    for (source, target) in map1_32.iter().zip(&mut map1_64) {
        *target = f64::from(*source);
    }
    let mut direct_e = vec![Complex::<f64>::new(0.0, 0.0); spin_nalm];
    let mut direct_b = vec![Complex::<f64>::new(0.0, 0.0); spin_nalm];
    spin_plan
        .analysis_spin_into(
            &map0_64,
            &map1_64,
            &mut direct_e,
            &mut direct_b,
            &mut spin_workspace,
        )
        .unwrap();
    let max_difference = direct_e
        .iter()
        .zip(&e64)
        .chain(direct_b.iter().zip(&b64))
        .map(|(a, b)| (a.re - b.re).abs().max((a.im - b.im).abs()))
        .fold(0.0_f64, f64::max);
    let (error_energy, direct_energy) = direct_e
        .iter()
        .zip(&e64)
        .chain(direct_b.iter().zip(&b64))
        .fold((0.0_f64, 0.0_f64), |(error, reference), (a, b)| {
            (
                error + (a.re - b.re).powi(2) + (a.im - b.im).powi(2),
                reference + a.re.powi(2) + a.im.powi(2),
            )
        });

    fn median(values: &mut [f64]) -> f64 {
        values.sort_by(f64::total_cmp);
        values[values.len() / 2]
    }
    fs::write(
        std::env::var("M6_SPIN1_OUT_E").unwrap(),
        e32.iter()
            .flat_map(|x| [x.re.to_le_bytes(), x.im.to_le_bytes()])
            .flatten()
            .collect::<Vec<_>>(),
    )
    .unwrap();
    fs::write(
        std::env::var("M6_SPIN1_OUT_B").unwrap(),
        b32.iter()
            .flat_map(|x| [x.re.to_le_bytes(), x.im.to_le_bytes()])
            .flatten()
            .collect::<Vec<_>>(),
    )
    .unwrap();
    println!(
        "{{\"route\":\"two_scalar_analysis\",\"threads\":{},\"calls\":60,\"convert_ms\":{:.6},\"scalar0_ms\":{:.6},\"scalar1_ms\":{:.6},\"spin_conversion_ms\":{:.6},\"f32_writeback_ms\":{:.6},\"whole_ms\":{:.6},\"max_abs_vs_spin_api\":{:.6e},\"relative_l2_vs_spin_api\":{:.6e},\"reusable_buffer_bytes\":{}}}",
        threads,
        median(&mut convert_ms),
        median(&mut first_analysis_ms),
        median(&mut second_analysis_ms),
        median(&mut spin_conversion_ms),
        median(&mut output_conversion_ms),
        median(&mut whole_ms),
        max_difference,
        (error_energy / direct_energy).sqrt(),
        (map0_64.capacity() + map1_64.capacity()) * 8
            + (scalar0.capacity() + scalar1.capacity() + e64.capacity() + b64.capacity()) * 16
            + (scalar_by_degree0.capacity() + scalar_by_degree1.capacity() + epsilon.capacity())
                * 8
            + (e32.capacity() + b32.capacity()) * 8,
    );
}
