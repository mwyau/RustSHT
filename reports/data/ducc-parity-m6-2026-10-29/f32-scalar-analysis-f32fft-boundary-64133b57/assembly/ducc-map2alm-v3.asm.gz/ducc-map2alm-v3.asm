
/tmp/rustsht-m6-spin1-analysis-profile-20261029.p2LsmK/ducc-build/ducc_f32_spin_analysis_profile:     file format elf64-x86-64


Disassembly of section .text:

000000000067c9a0 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]>:
  67c9a0:	55                   	push   %rbp
  67c9a1:	48 8d 41 02          	lea    0x2(%rcx),%rax
  67c9a5:	49 89 f3             	mov    %rsi,%r11
  67c9a8:	49 89 d2             	mov    %rdx,%r10
  67c9ab:	48 89 e5             	mov    %rsp,%rbp
  67c9ae:	41 55                	push   %r13
  67c9b0:	41 54                	push   %r12
  67c9b2:	4d 89 c4             	mov    %r8,%r12
  67c9b5:	4c 8b 45 10          	mov    0x10(%rbp),%r8
  67c9b9:	53                   	push   %rbx
  67c9ba:	48 89 cb             	mov    %rcx,%rbx
  67c9bd:	49 39 c1             	cmp    %rax,%r9
  67c9c0:	0f 82 93 01 00 00    	jb     67cb59 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x1b9>
  67c9c6:	48 c1 e1 04          	shl    $0x4,%rcx
  67c9ca:	4c 89 e6             	mov    %r12,%rsi
  67c9cd:	48 01 d1             	add    %rdx,%rcx
  67c9d0:	4c 89 c2             	mov    %r8,%rdx
  67c9d3:	48 c1 e6 04          	shl    $0x4,%rsi
  67c9d7:	48 c1 e2 05          	shl    $0x5,%rdx
  67c9db:	4c 01 de             	add    %r11,%rsi
  67c9de:	48 01 fa             	add    %rdi,%rdx
  67c9e1:	4d 85 c0             	test   %r8,%r8
  67c9e4:	0f 84 44 01 00 00    	je     67cb2e <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x18e>
  67c9ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  67c9f0:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  67c9f5:	c4 62 7d 19 3e       	vbroadcastsd (%rsi),%ymm15
  67c9fa:	48 89 f8             	mov    %rdi,%rax
  67c9fd:	c4 e2 7d 19 7e 08    	vbroadcastsd 0x8(%rsi),%ymm7
  67ca03:	c4 e2 7d 19 76 10    	vbroadcastsd 0x10(%rsi),%ymm6
  67ca09:	c4 41 7d 28 cb       	vmovapd %ymm11,%ymm9
  67ca0e:	c4 41 7d 28 e3       	vmovapd %ymm11,%ymm12
  67ca13:	c5 7d 29 db          	vmovapd %ymm11,%ymm3
  67ca17:	c4 e2 7d 19 6e 18    	vbroadcastsd 0x18(%rsi),%ymm5
  67ca1d:	c4 41 7d 28 eb       	vmovapd %ymm11,%ymm13
  67ca22:	c4 41 7d 28 d3       	vmovapd %ymm11,%ymm10
  67ca27:	c4 41 7d 28 f3       	vmovapd %ymm11,%ymm14
  67ca2c:	c5 7d 29 dc          	vmovapd %ymm11,%ymm4
  67ca30:	c5 fd 28 90 00 28 00 	vmovapd 0x2800(%rax),%ymm2
  67ca37:	00 
  67ca38:	c5 7d 29 f8          	vmovapd %ymm15,%ymm0
  67ca3c:	48 83 c0 20          	add    $0x20,%rax
  67ca40:	c5 fd 28 88 e0 1f 00 	vmovapd 0x1fe0(%rax),%ymm1
  67ca47:	00 
  67ca48:	c5 7d 28 80 e0 2f 00 	vmovapd 0x2fe0(%rax),%ymm8
  67ca4f:	00 
  67ca50:	c4 62 f5 b8 b0 e0 37 	vfmadd231pd 0x37e0(%rax),%ymm1,%ymm14
  67ca57:	00 00 
  67ca59:	c4 62 f5 b8 90 e0 3f 	vfmadd231pd 0x3fe0(%rax),%ymm1,%ymm10
  67ca60:	00 00 
  67ca62:	c4 e2 c5 98 c2       	vfmadd132pd %ymm2,%ymm7,%ymm0
  67ca67:	c4 e2 f5 a8 80 e0 17 	vfmadd213pd 0x17e0(%rax),%ymm1,%ymm0
  67ca6e:	00 00 
  67ca70:	c4 e2 d5 98 d6       	vfmadd132pd %ymm6,%ymm5,%ymm2
  67ca75:	c4 62 fd b8 a0 e0 37 	vfmadd231pd 0x37e0(%rax),%ymm0,%ymm12
  67ca7c:	00 00 
  67ca7e:	c4 c2 f5 b8 e0       	vfmadd231pd %ymm8,%ymm1,%ymm4
  67ca83:	c4 62 fd b8 88 e0 3f 	vfmadd231pd 0x3fe0(%rax),%ymm0,%ymm9
  67ca8a:	00 00 
  67ca8c:	c4 62 fd b8 98 e0 47 	vfmadd231pd 0x47e0(%rax),%ymm0,%ymm11
  67ca93:	00 00 
  67ca95:	c4 62 f5 b8 a8 e0 47 	vfmadd231pd 0x47e0(%rax),%ymm1,%ymm13
  67ca9c:	00 00 
  67ca9e:	c5 fd 29 80 e0 17 00 	vmovapd %ymm0,0x17e0(%rax)
  67caa5:	00 
  67caa6:	c4 e2 bd b8 d8       	vfmadd231pd %ymm0,%ymm8,%ymm3
  67caab:	c4 e2 f5 98 c2       	vfmadd132pd %ymm2,%ymm1,%ymm0
  67cab0:	c5 fd 29 80 e0 1f 00 	vmovapd %ymm0,0x1fe0(%rax)
  67cab7:	00 
  67cab8:	48 39 c2             	cmp    %rax,%rdx
  67cabb:	0f 85 6f ff ff ff    	jne    67ca30 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x90>
  67cac1:	c4 c1 5d 7c e6       	vhaddpd %ymm14,%ymm4,%ymm4
  67cac6:	c4 41 2d 7c d5       	vhaddpd %ymm13,%ymm10,%ymm10
  67cacb:	49 83 c4 02          	add    $0x2,%r12
  67cacf:	48 83 c1 40          	add    $0x40,%rcx
  67cad3:	c4 c1 65 7c dc       	vhaddpd %ymm12,%ymm3,%ymm3
  67cad8:	c4 41 35 7c cb       	vhaddpd %ymm11,%ymm9,%ymm9
  67cadd:	48 83 c6 20          	add    $0x20,%rsi
  67cae1:	4c 8d 6b 04          	lea    0x4(%rbx),%r13
  67cae5:	48 83 c3 06          	add    $0x6,%rbx
  67cae9:	c4 c3 5d 06 c2 31    	vperm2f128 $0x31,%ymm10,%ymm4,%ymm0
  67caef:	c4 c3 5d 18 e2 01    	vinsertf128 $0x1,%xmm10,%ymm4,%ymm4
  67caf5:	c5 fd 58 c4          	vaddpd %ymm4,%ymm0,%ymm0
  67caf9:	c5 fd 58 41 c0       	vaddpd -0x40(%rcx),%ymm0,%ymm0
  67cafe:	c5 fd 11 41 c0       	vmovupd %ymm0,-0x40(%rcx)
  67cb03:	c4 c3 65 06 c1 31    	vperm2f128 $0x31,%ymm9,%ymm3,%ymm0
  67cb09:	c4 c3 65 18 d9 01    	vinsertf128 $0x1,%xmm9,%ymm3,%ymm3
  67cb0f:	c5 fd 58 c3          	vaddpd %ymm3,%ymm0,%ymm0
  67cb13:	c5 fd 58 41 e0       	vaddpd -0x20(%rcx),%ymm0,%ymm0
  67cb18:	c5 fd 11 41 e0       	vmovupd %ymm0,-0x20(%rcx)
  67cb1d:	49 39 d9             	cmp    %rbx,%r9
  67cb20:	72 3e                	jb     67cb60 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x1c0>
  67cb22:	4c 89 eb             	mov    %r13,%rbx
  67cb25:	4d 85 c0             	test   %r8,%r8
  67cb28:	0f 85 c2 fe ff ff    	jne    67c9f0 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x50>
  67cb2e:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  67cb33:	c4 41 7d 28 cb       	vmovapd %ymm11,%ymm9
  67cb38:	c4 41 7d 28 e3       	vmovapd %ymm11,%ymm12
  67cb3d:	c5 7d 29 db          	vmovapd %ymm11,%ymm3
  67cb41:	c4 41 7d 28 eb       	vmovapd %ymm11,%ymm13
  67cb46:	c4 41 7d 28 d3       	vmovapd %ymm11,%ymm10
  67cb4b:	c4 41 7d 28 f3       	vmovapd %ymm11,%ymm14
  67cb50:	c5 7d 29 dc          	vmovapd %ymm11,%ymm4
  67cb54:	e9 68 ff ff ff       	jmp    67cac1 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x121>
  67cb59:	49 89 cd             	mov    %rcx,%r13
  67cb5c:	0f 1f 40 00          	nopl   0x0(%rax)
  67cb60:	4d 39 e9             	cmp    %r13,%r9
  67cb63:	0f 82 eb 00 00 00    	jb     67cc54 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x2b4>
  67cb69:	4c 89 e8             	mov    %r13,%rax
  67cb6c:	4c 89 c2             	mov    %r8,%rdx
  67cb6f:	49 c1 e4 04          	shl    $0x4,%r12
  67cb73:	48 c1 e0 04          	shl    $0x4,%rax
  67cb77:	48 c1 e2 05          	shl    $0x5,%rdx
  67cb7b:	4d 01 e3             	add    %r12,%r11
  67cb7e:	49 01 c2             	add    %rax,%r10
  67cb81:	48 01 fa             	add    %rdi,%rdx
  67cb84:	90                   	nop
  67cb85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  67cb8c:	00 00 00 00 
  67cb90:	4d 85 c0             	test   %r8,%r8
  67cb93:	0f 84 c7 00 00 00    	je     67cc60 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x2c0>
  67cb99:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  67cb9d:	c4 c2 7d 19 3b       	vbroadcastsd (%r11),%ymm7
  67cba2:	c4 c2 7d 19 73 08    	vbroadcastsd 0x8(%r11),%ymm6
  67cba8:	48 89 f8             	mov    %rdi,%rax
  67cbab:	c5 fd 28 dc          	vmovapd %ymm4,%ymm3
  67cbaf:	c5 fd 28 ec          	vmovapd %ymm4,%ymm5
  67cbb3:	c5 fd 28 d4          	vmovapd %ymm4,%ymm2
  67cbb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  67cbbe:	00 00 
  67cbc0:	c5 fd 28 cf          	vmovapd %ymm7,%ymm1
  67cbc4:	c5 fd 28 80 00 20 00 	vmovapd 0x2000(%rax),%ymm0
  67cbcb:	00 
  67cbcc:	48 83 c0 20          	add    $0x20,%rax
  67cbd0:	c4 e2 cd 98 88 e0 27 	vfmadd132pd 0x27e0(%rax),%ymm6,%ymm1
  67cbd7:	00 00 
  67cbd9:	c4 e2 fd b8 90 e0 2f 	vfmadd231pd 0x2fe0(%rax),%ymm0,%ymm2
  67cbe0:	00 00 
  67cbe2:	c4 e2 fd a8 88 e0 17 	vfmadd213pd 0x17e0(%rax),%ymm0,%ymm1
  67cbe9:	00 00 
  67cbeb:	c4 e2 fd b8 a8 e0 37 	vfmadd231pd 0x37e0(%rax),%ymm0,%ymm5
  67cbf2:	00 00 
  67cbf4:	c5 fd 29 80 e0 17 00 	vmovapd %ymm0,0x17e0(%rax)
  67cbfb:	00 
  67cbfc:	c4 e2 fd b8 98 e0 3f 	vfmadd231pd 0x3fe0(%rax),%ymm0,%ymm3
  67cc03:	00 00 
  67cc05:	c4 e2 fd b8 a0 e0 47 	vfmadd231pd 0x47e0(%rax),%ymm0,%ymm4
  67cc0c:	00 00 
  67cc0e:	c5 fd 29 88 e0 1f 00 	vmovapd %ymm1,0x1fe0(%rax)
  67cc15:	00 
  67cc16:	48 39 d0             	cmp    %rdx,%rax
  67cc19:	75 a5                	jne    67cbc0 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x220>
  67cc1b:	c5 ed 7c d5          	vhaddpd %ymm5,%ymm2,%ymm2
  67cc1f:	c5 e5 7c dc          	vhaddpd %ymm4,%ymm3,%ymm3
  67cc23:	49 83 c5 02          	add    $0x2,%r13
  67cc27:	49 83 c2 20          	add    $0x20,%r10
  67cc2b:	49 83 c3 10          	add    $0x10,%r11
  67cc2f:	c4 e3 6d 06 c3 31    	vperm2f128 $0x31,%ymm3,%ymm2,%ymm0
  67cc35:	c4 e3 6d 18 d3 01    	vinsertf128 $0x1,%xmm3,%ymm2,%ymm2
  67cc3b:	c5 fd 58 c2          	vaddpd %ymm2,%ymm0,%ymm0
  67cc3f:	c4 c1 7d 58 42 e0    	vaddpd -0x20(%r10),%ymm0,%ymm0
  67cc45:	c4 c1 7d 11 42 e0    	vmovupd %ymm0,-0x20(%r10)
  67cc4b:	4d 39 e9             	cmp    %r13,%r9
  67cc4e:	0f 83 3c ff ff ff    	jae    67cb90 <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x1f0>
  67cc54:	c5 f8 77             	vzeroupper
  67cc57:	5b                   	pop    %rbx
  67cc58:	41 5c                	pop    %r12
  67cc5a:	41 5d                	pop    %r13
  67cc5c:	5d                   	pop    %rbp
  67cc5d:	c3                   	ret
  67cc5e:	66 90                	xchg   %ax,%ax
  67cc60:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  67cc64:	c5 fd 28 dc          	vmovapd %ymm4,%ymm3
  67cc68:	c5 fd 28 ec          	vmovapd %ymm4,%ymm5
  67cc6c:	c5 fd 28 d4          	vmovapd %ymm4,%ymm2
  67cc70:	eb a9                	jmp    67cc1b <ducc0::detail_sht::detail_sht_inner_loop::map2alm_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double>*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x27b>
  67cc72:	0f 1f 00             	nopl   (%rax)
  67cc75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  67cc7c:	00 00 00 00 
