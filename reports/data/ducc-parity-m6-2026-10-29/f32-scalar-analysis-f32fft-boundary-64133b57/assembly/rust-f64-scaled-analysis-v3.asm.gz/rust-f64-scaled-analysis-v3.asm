
/tmp/rustsht-m6-spin1-analysis-profile-20261029.p2LsmK/source/target/release/deps/rustsht-7b2799b2f834d251:     file format elf64-x86-64


Disassembly of section .text:

0000000000377500 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>>:
  377500:	55                   	push   %rbp
  377501:	41 57                	push   %r15
  377503:	41 56                	push   %r14
  377505:	41 55                	push   %r13
  377507:	41 54                	push   %r12
  377509:	53                   	push   %rbx
  37750a:	48 81 ec 48 02 00 00 	sub    $0x248,%rsp
  377511:	49 89 fe             	mov    %rdi,%r14
  377514:	48 8b 96 e8 00 00 00 	mov    0xe8(%rsi),%rdx
  37751b:	48 8b 8e f0 00 00 00 	mov    0xf0(%rsi),%rcx
  377522:	48 89 cf             	mov    %rcx,%rdi
  377525:	48 29 d7             	sub    %rdx,%rdi
  377528:	48 83 c7 02          	add    $0x2,%rdi
  37752c:	48 b8 01 80 fa ca 73 	movabs $0x1ff973cafa8001,%rax
  377533:	f9 1f 00 
  377536:	48 39 c7             	cmp    %rax,%rdi
  377539:	76 22                	jbe    37755d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x5d>
  37753b:	31 c0                	xor    %eax,%eax
  37753d:	41 88 46 08          	mov    %al,0x8(%r14)
  377541:	49 c7 06 ff ff ff ff 	movq   $0xffffffffffffffff,(%r14)
  377548:	48 81 c4 48 02 00 00 	add    $0x248,%rsp
  37754f:	5b                   	pop    %rbx
  377550:	41 5c                	pop    %r12
  377552:	41 5d                	pop    %r13
  377554:	41 5e                	pop    %r14
  377556:	41 5f                	pop    %r15
  377558:	5d                   	pop    %rbp
  377559:	c5 f8 77             	vzeroupper
  37755c:	c3                   	ret
  37755d:	48 89 94 24 18 01 00 	mov    %rdx,0x118(%rsp)
  377564:	00 
  377565:	48 89 8c 24 10 01 00 	mov    %rcx,0x110(%rsp)
  37756c:	00 
  37756d:	48 8b 06             	mov    (%rsi),%rax
  377570:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  377577:	00 
  377578:	48 8b 46 10          	mov    0x10(%rsi),%rax
  37757c:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  377583:	00 
  377584:	48 8b 46 18          	mov    0x18(%rsi),%rax
  377588:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  37758f:	00 
  377590:	48 8b 46 20          	mov    0x20(%rsi),%rax
  377594:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
  37759b:	00 
  37759c:	48 8b 46 28          	mov    0x28(%rsi),%rax
  3775a0:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  3775a7:	00 
  3775a8:	48 8b 46 30          	mov    0x30(%rsi),%rax
  3775ac:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  3775b3:	00 
  3775b4:	48 8b 46 38          	mov    0x38(%rsi),%rax
  3775b8:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  3775bf:	00 
  3775c0:	48 8b 46 40          	mov    0x40(%rsi),%rax
  3775c4:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  3775cb:	00 
  3775cc:	48 8b 46 48          	mov    0x48(%rsi),%rax
  3775d0:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  3775d5:	48 8b 46 50          	mov    0x50(%rsi),%rax
  3775d9:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
  3775e0:	00 
  3775e1:	48 8b 46 58          	mov    0x58(%rsi),%rax
  3775e5:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  3775ec:	00 
  3775ed:	48 8b 46 60          	mov    0x60(%rsi),%rax
  3775f1:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  3775f8:	00 
  3775f9:	48 8b 46 68          	mov    0x68(%rsi),%rax
  3775fd:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  377604:	00 
  377605:	48 8b 46 70          	mov    0x70(%rsi),%rax
  377609:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  377610:	00 
  377611:	48 8b 46 78          	mov    0x78(%rsi),%rax
  377615:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  37761c:	00 
  37761d:	48 8b 86 80 00 00 00 	mov    0x80(%rsi),%rax
  377624:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  37762b:	00 
  37762c:	48 8b 86 88 00 00 00 	mov    0x88(%rsi),%rax
  377633:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  377638:	48 8b 86 90 00 00 00 	mov    0x90(%rsi),%rax
  37763f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  377644:	4c 8b ae 98 00 00 00 	mov    0x98(%rsi),%r13
  37764b:	48 8b 86 a0 00 00 00 	mov    0xa0(%rsi),%rax
  377652:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  377657:	48 8b 86 a8 00 00 00 	mov    0xa8(%rsi),%rax
  37765e:	48 89 04 24          	mov    %rax,(%rsp)
  377662:	48 8b 86 b0 00 00 00 	mov    0xb0(%rsi),%rax
  377669:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  37766e:	4c 8b 86 b8 00 00 00 	mov    0xb8(%rsi),%r8
  377675:	48 8b 86 c0 00 00 00 	mov    0xc0(%rsi),%rax
  37767c:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  377683:	00 
  377684:	4c 8b be c8 00 00 00 	mov    0xc8(%rsi),%r15
  37768b:	4c 8b 8e d0 00 00 00 	mov    0xd0(%rsi),%r9
  377692:	48 8b 9e d8 00 00 00 	mov    0xd8(%rsi),%rbx
  377699:	48 8b ae e0 00 00 00 	mov    0xe0(%rsi),%rbp
  3776a0:	48 89 bc 24 18 02 00 	mov    %rdi,0x218(%rsp)
  3776a7:	00 
  3776a8:	48 d1 ef             	shr    $1,%rdi
  3776ab:	48 89 bc 24 a8 00 00 	mov    %rdi,0xa8(%rsp)
  3776b2:	00 
  3776b3:	4d 85 c9             	test   %r9,%r9
  3776b6:	74 6d                	je     377725 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x225>
  3776b8:	c4 e1 83 2a 84 24 a8 	vcvtsi2sdq 0xa8(%rsp),%xmm15,%xmm0
  3776bf:	00 00 00 
  3776c2:	c5 fb 10 0d d6 cf d0 	vmovsd -0x2f302a(%rip),%xmm1        # 846a0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x10>
  3776c9:	ff 
  3776ca:	c5 f3 5c c0          	vsubsd %xmm0,%xmm1,%xmm0
  3776ce:	4a 8d 0c cd 00 00 00 	lea    0x0(,%r9,8),%rcx
  3776d5:	00 
  3776d6:	31 f6                	xor    %esi,%esi
  3776d8:	c5 fb 10 0d e8 e0 d0 	vmovsd -0x2f1f18(%rip),%xmm1        # 857c8 <anon.890d649631ab6ab37a03cdc207a0d7b9.1026.llvm.3426226200983260467+0x1e0>
  3776df:	ff 
  3776e0:	c4 c1 7a 7e 14 37    	vmovq  (%r15,%rsi,1),%xmm2
  3776e6:	c4 e1 f9 7e d0       	vmovq  %xmm2,%rax
  3776eb:	48 c1 e8 34          	shr    $0x34,%rax
  3776ef:	25 ff 07 00 00       	and    $0x7ff,%eax
  3776f4:	3d ff 07 00 00       	cmp    $0x7ff,%eax
  3776f9:	40 0f 93 c7          	setae  %dil
  3776fd:	31 c0                	xor    %eax,%eax
  3776ff:	c5 f9 2e d1          	vucomisd %xmm1,%xmm2
  377703:	0f 82 34 fe ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  377709:	40 84 ff             	test   %dil,%dil
  37770c:	0f 85 2b fe ff ff    	jne    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  377712:	c5 f9 2e c2          	vucomisd %xmm2,%xmm0
  377716:	0f 82 21 fe ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37771c:	48 83 c6 08          	add    $0x8,%rsi
  377720:	48 39 f1             	cmp    %rsi,%rcx
  377723:	75 bb                	jne    3776e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1e0>
  377725:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  37772a:	48 39 ee             	cmp    %rbp,%rsi
  37772d:	0f 87 0b 18 00 00    	ja     378f3e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1a3e>
  377733:	49 39 f1             	cmp    %rsi,%r9
  377736:	49 0f 42 f1          	cmovb  %r9,%rsi
  37773a:	48 85 f6             	test   %rsi,%rsi
  37773d:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
  377742:	0f 84 1b 01 00 00    	je     377863 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x363>
  377748:	b1 01                	mov    $0x1,%cl
  37774a:	31 ff                	xor    %edi,%edi
  37774c:	c5 fb 10 05 6c d7 d0 	vmovsd -0x2f2894(%rip),%xmm0        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  377753:	ff 
  377754:	c5 fb 12 0d 74 ee d0 	vmovddup -0x2f118c(%rip),%xmm1        # 865d0 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0x2e8>
  37775b:	ff 
  37775c:	c5 fb 12 15 5c d7 d0 	vmovddup -0x2f28a4(%rip),%xmm2        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  377763:	ff 
  377764:	c5 fb 12 1d cc d7 d0 	vmovddup -0x2f2834(%rip),%xmm3        # 84f38 <anon.890d649631ab6ab37a03cdc207a0d7b9.203.llvm.3426226200983260467+0x10>
  37776b:	ff 
  37776c:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  377770:	c5 fb 10 2d 78 d0 d0 	vmovsd -0x2f2f88(%rip),%xmm5        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  377777:	ff 
  377778:	c5 fb 10 35 38 d9 d0 	vmovsd -0x2f26c8(%rip),%xmm6        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  37777f:	ff 
  377780:	41 b3 01             	mov    $0x1,%r11b
  377783:	eb 28                	jmp    3777ad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2ad>
  377785:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  37778c:	00 00 00 00 
  377790:	45 31 db             	xor    %r11d,%r11d
  377793:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  377797:	0f 97 c0             	seta   %al
  37779a:	c5 7b 11 04 fb       	vmovsd %xmm8,(%rbx,%rdi,8)
  37779f:	48 ff c7             	inc    %rdi
  3777a2:	20 c1                	and    %al,%cl
  3777a4:	48 39 fe             	cmp    %rdi,%rsi
  3777a7:	0f 84 bb 00 00 00    	je     377868 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x368>
  3777ad:	48 8b 04 24          	mov    (%rsp),%rax
  3777b1:	c5 7a 7e 0c f8       	vmovq  (%rax,%rdi,8),%xmm9
  3777b6:	c4 61 f9 7e cb       	vmovq  %xmm9,%rbx
  3777bb:	c4 c1 7a 7e 3c ff    	vmovq  (%r15,%rdi,8),%xmm7
  3777c1:	c4 e1 f9 7e f8       	vmovq  %xmm7,%rax
  3777c6:	48 c1 eb 34          	shr    $0x34,%rbx
  3777ca:	81 e3 ff 07 00 00    	and    $0x7ff,%ebx
  3777d0:	48 c1 e8 34          	shr    $0x34,%rax
  3777d4:	25 ff 07 00 00       	and    $0x7ff,%eax
  3777d9:	3d ff 07 00 00       	cmp    $0x7ff,%eax
  3777de:	41 0f 92 c2          	setb   %r10b
  3777e2:	31 c0                	xor    %eax,%eax
  3777e4:	81 fb fe 07 00 00    	cmp    $0x7fe,%ebx
  3777ea:	0f 87 4d fd ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3777f0:	45 84 d2             	test   %r10b,%r10b
  3777f3:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  3777f8:	0f 84 3f fd ff ff    	je     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3777fe:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  377803:	c5 79 2e c7          	vucomisd %xmm7,%xmm8
  377807:	77 8a                	ja     377793 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x293>
  377809:	c5 43 c2 c0 01       	vcmpltsd %xmm0,%xmm7,%xmm8
  37780e:	c4 63 71 4b c2 80    	vblendvpd %xmm8,%xmm2,%xmm1,%xmm8
  377814:	c4 41 33 59 c8       	vmulsd %xmm8,%xmm9,%xmm9
  377819:	c4 61 f9 7e c8       	vmovq  %xmm9,%rax
  37781e:	48 c1 e8 34          	shr    $0x34,%rax
  377822:	25 ff 07 00 00       	and    $0x7ff,%eax
  377827:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37782c:	0f 87 09 fd ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  377832:	c5 79 2e cc          	vucomisd %xmm4,%xmm9
  377836:	75 06                	jne    37783e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x33e>
  377838:	0f 8b 52 ff ff ff    	jnp    377790 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x290>
  37783e:	c5 31 54 cb          	vandpd %xmm3,%xmm9,%xmm9
  377842:	45 31 db             	xor    %r11d,%r11d
  377845:	c5 79 2e cd          	vucomisd %xmm5,%xmm9
  377849:	0f 82 ec fc ff ff    	jb     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37784f:	c5 79 2e ce          	vucomisd %xmm6,%xmm9
  377853:	b8 00 00 00 00       	mov    $0x0,%eax
  377858:	0f 86 35 ff ff ff    	jbe    377793 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x293>
  37785e:	e9 da fc ff ff       	jmp    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  377863:	41 b3 01             	mov    $0x1,%r11b
  377866:	b1 01                	mov    $0x1,%cl
  377868:	45 31 e4             	xor    %r12d,%r12d
  37786b:	48 83 bc 24 a8 00 00 	cmpq   $0x0,0xa8(%rsp)
  377872:	00 00 
  377874:	4c 89 ea             	mov    %r13,%rdx
  377877:	0f 84 08 11 00 00    	je     378985 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1485>
  37787d:	84 c9                	test   %cl,%cl
  37787f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  377884:	0f 84 fb 10 00 00    	je     378985 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1485>
  37788a:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
  37788f:	48 89 d8             	mov    %rbx,%rax
  377892:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
  377897:	4c 31 e0             	xor    %r12,%rax
  37789a:	4c 89 e1             	mov    %r12,%rcx
  37789d:	48 8b bc 24 38 01 00 	mov    0x138(%rsp),%rdi
  3778a4:	00 
  3778a5:	48 31 f9             	xor    %rdi,%rcx
  3778a8:	48 09 c1             	or     %rax,%rcx
  3778ab:	4c 89 e0             	mov    %r12,%rax
  3778ae:	4c 31 c8             	xor    %r9,%rax
  3778b1:	48 09 c8             	or     %rcx,%rax
  3778b4:	4c 89 e1             	mov    %r12,%rcx
  3778b7:	48 31 e9             	xor    %rbp,%rcx
  3778ba:	48 09 c1             	or     %rax,%rcx
  3778bd:	49 8d 44 dd 00       	lea    0x0(%r13,%rbx,8),%rax
  3778c2:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  3778c9:	00 
  3778ca:	0f 84 ee 00 00 00    	je     3779be <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4be>
  3778d0:	48 85 f6             	test   %rsi,%rsi
  3778d3:	0f 84 e0 47 00 00    	je     37c0b9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4bb9>
  3778d9:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  3778dd:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  3778e2:	c5 f9 11 00          	vmovupd %xmm0,(%rax)
  3778e6:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
  3778ed:	00 
  3778ee:	48 3b 84 24 18 01 00 	cmp    0x118(%rsp),%rax
  3778f5:	00 
  3778f6:	76 14                	jbe    37790c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x40c>
  3778f8:	48 83 fe 01          	cmp    $0x1,%rsi
  3778fc:	0f 84 30 48 00 00    	je     37c132 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c32>
  377902:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  377907:	c5 f9 11 41 10       	vmovupd %xmm0,0x10(%rcx)
  37790c:	48 83 bc 24 a8 00 00 	cmpq   $0x1,0xa8(%rsp)
  377913:	00 01 
  377915:	74 50                	je     377967 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x467>
  377917:	48 83 fe 03          	cmp    $0x3,%rsi
  37791b:	0f 82 28 48 00 00    	jb     37c149 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c49>
  377921:	48 8b bc 24 18 01 00 	mov    0x118(%rsp),%rdi
  377928:	00 
  377929:	48 83 c7 02          	add    $0x2,%rdi
  37792d:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  377932:	c5 f9 11 41 20       	vmovupd %xmm0,0x20(%rcx)
  377937:	48 39 c7             	cmp    %rax,%rdi
  37793a:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  377941:	00 
  377942:	73 14                	jae    377958 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x458>
  377944:	48 83 fe 03          	cmp    $0x3,%rsi
  377948:	0f 84 f7 48 00 00    	je     37c245 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4d45>
  37794e:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  377953:	c5 f9 11 40 30       	vmovupd %xmm0,0x30(%rax)
  377958:	48 83 bc 24 a8 00 00 	cmpq   $0x2,0xa8(%rsp)
  37795f:	00 02 
  377961:	0f 85 c9 12 00 00    	jne    378c30 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1730>
  377967:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  37796c:	48 3b 44 24 30       	cmp    0x30(%rsp),%rax
  377971:	0f 85 c4 fb ff ff    	jne    37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  377977:	48 8b 0c 24          	mov    (%rsp),%rcx
  37797b:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  37797f:	4c 89 ac 24 f0 01 00 	mov    %r13,0x1f0(%rsp)
  377986:	00 
  377987:	48 8b 94 24 30 01 00 	mov    0x130(%rsp),%rdx
  37798e:	00 
  37798f:	48 89 94 24 f8 01 00 	mov    %rdx,0x1f8(%rsp)
  377996:	00 
  377997:	48 89 8c 24 00 02 00 	mov    %rcx,0x200(%rsp)
  37799e:	00 
  37799f:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  3779a6:	00 
  3779a7:	48 8d bc 24 f0 01 00 	lea    0x1f0(%rsp),%rdi
  3779ae:	00 
  3779af:	c5 f8 77             	vzeroupper
  3779b2:	e8 99 41 05 00       	call   3cbb50 <<core::iter::adapters::chain::Chain<core::slice::iter::Iter<f64>, core::slice::iter::Iter<f64>> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::traits::iterator::Iterator::all::check<&f64, rustsht::legendre::scalar_paired::analysis::advance_and_rescale_analysis_pair<pulp::Scalar>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  3779b7:	34 01                	xor    $0x1,%al
  3779b9:	e9 7f fb ff ff       	jmp    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3779be:	48 89 d8             	mov    %rbx,%rax
  3779c1:	48 c1 e8 02          	shr    $0x2,%rax
  3779c5:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  3779ca:	89 d8                	mov    %ebx,%eax
  3779cc:	83 e0 03             	and    $0x3,%eax
  3779cf:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  3779d6:	00 
  3779d7:	48 b9 fc ff ff ff ff 	movabs $0xffffffffffffffc,%rcx
  3779de:	ff ff 0f 
  3779e1:	48 89 d8             	mov    %rbx,%rax
  3779e4:	48 21 c8             	and    %rcx,%rax
  3779e7:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  3779ec:	4d 89 e2             	mov    %r12,%r10
  3779ef:	49 c1 ea 02          	shr    $0x2,%r10
  3779f3:	44 89 e0             	mov    %r12d,%eax
  3779f6:	83 e0 03             	and    $0x3,%eax
  3779f9:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  377a00:	00 
  377a01:	4c 89 e0             	mov    %r12,%rax
  377a04:	48 21 c8             	and    %rcx,%rax
  377a07:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  377a0c:	48 89 f8             	mov    %rdi,%rax
  377a0f:	48 c1 e8 02          	shr    $0x2,%rax
  377a13:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  377a1a:	00 
  377a1b:	89 f8                	mov    %edi,%eax
  377a1d:	83 e0 03             	and    $0x3,%eax
  377a20:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  377a27:	00 
  377a28:	48 21 cf             	and    %rcx,%rdi
  377a2b:	48 89 bc 24 b0 00 00 	mov    %rdi,0xb0(%rsp)
  377a32:	00 
  377a33:	4c 89 c8             	mov    %r9,%rax
  377a36:	48 c1 e8 02          	shr    $0x2,%rax
  377a3a:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  377a3f:	44 89 c8             	mov    %r9d,%eax
  377a42:	83 e0 03             	and    $0x3,%eax
  377a45:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  377a4a:	4c 89 c8             	mov    %r9,%rax
  377a4d:	48 21 c8             	and    %rcx,%rax
  377a50:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  377a57:	00 
  377a58:	48 89 e8             	mov    %rbp,%rax
  377a5b:	48 c1 e8 02          	shr    $0x2,%rax
  377a5f:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
  377a66:	00 
  377a67:	89 e8                	mov    %ebp,%eax
  377a69:	83 e0 03             	and    $0x3,%eax
  377a6c:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  377a71:	48 21 e9             	and    %rbp,%rcx
  377a74:	48 89 8c 24 b8 00 00 	mov    %rcx,0xb8(%rsp)
  377a7b:	00 
  377a7c:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  377a81:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  377a85:	c4 62 7d 59 2d 32 d4 	vpbroadcastq -0x2f2bce(%rip),%ymm13        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  377a8c:	d0 ff 
  377a8e:	c5 6d c2 f2 00       	vcmpeqpd %ymm2,%ymm2,%ymm14
  377a93:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  377a98:	c5 fb 10 3d d0 e9 d0 	vmovsd -0x2f1630(%rip),%xmm7        # 86470 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0x188>
  377a9f:	ff 
  377aa0:	48 8d 04 dd 00 00 00 	lea    0x0(,%rbx,8),%rax
  377aa7:	00 
  377aa8:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
  377aaf:	00 
  377ab0:	4a 8d 04 e5 00 00 00 	lea    0x0(,%r12,8),%rax
  377ab7:	00 
  377ab8:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  377abf:	00 
  377ac0:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
  377ac7:	00 00 00 00 00 
  377acc:	45 31 e4             	xor    %r12d,%r12d
  377acf:	4c 89 b4 24 08 01 00 	mov    %r14,0x108(%rsp)
  377ad6:	00 
  377ad7:	4c 89 84 24 f0 00 00 	mov    %r8,0xf0(%rsp)
  377ade:	00 
  377adf:	c5 7d 11 b4 24 20 02 	vmovupd %ymm14,0x220(%rsp)
  377ae6:	00 00 
  377ae8:	4b 8d 3c 24          	lea    (%r12,%r12,1),%rdi
  377aec:	48 39 f7             	cmp    %rsi,%rdi
  377aef:	0f 83 59 46 00 00    	jae    37c14e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c4e>
  377af5:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
  377afc:	00 
  377afd:	48 01 f8             	add    %rdi,%rax
  377b00:	48 89 f9             	mov    %rdi,%rcx
  377b03:	48 c1 e1 04          	shl    $0x4,%rcx
  377b07:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
  377b0c:	c5 79 11 24 0b       	vmovupd %xmm12,(%rbx,%rcx,1)
  377b11:	48 3b 84 24 10 01 00 	cmp    0x110(%rsp),%rax
  377b18:	00 
  377b19:	73 1a                	jae    377b35 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x635>
  377b1b:	48 ff c7             	inc    %rdi
  377b1e:	48 39 f7             	cmp    %rsi,%rdi
  377b21:	0f 83 23 47 00 00    	jae    37c24a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4d4a>
  377b27:	48 c1 e7 04          	shl    $0x4,%rdi
  377b2b:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  377b30:	c5 79 11 24 38       	vmovupd %xmm12,(%rax,%rdi,1)
  377b35:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  377b3c:	00 
  377b3d:	4c 29 e0             	sub    %r12,%rax
  377b40:	48 83 f8 01          	cmp    $0x1,%rax
  377b44:	0f 84 1d fe ff ff    	je     377967 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x467>
  377b4a:	4a 8d 3c 65 02 00 00 	lea    0x2(,%r12,2),%rdi
  377b51:	00 
  377b52:	48 39 f7             	cmp    %rsi,%rdi
  377b55:	0f 83 f3 45 00 00    	jae    37c14e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c4e>
  377b5b:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
  377b62:	00 
  377b63:	48 01 f8             	add    %rdi,%rax
  377b66:	48 89 f9             	mov    %rdi,%rcx
  377b69:	48 c1 e1 04          	shl    $0x4,%rcx
  377b6d:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
  377b72:	c5 79 11 24 0b       	vmovupd %xmm12,(%rbx,%rcx,1)
  377b77:	48 3b 84 24 10 01 00 	cmp    0x110(%rsp),%rax
  377b7e:	00 
  377b7f:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  377b86:	00 
  377b87:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  377b8c:	73 1a                	jae    377ba8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x6a8>
  377b8e:	48 ff c7             	inc    %rdi
  377b91:	48 39 f7             	cmp    %rsi,%rdi
  377b94:	0f 83 b0 46 00 00    	jae    37c24a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4d4a>
  377b9a:	48 c1 e7 04          	shl    $0x4,%rdi
  377b9e:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  377ba3:	c5 79 11 24 38       	vmovupd %xmm12,(%rax,%rdi,1)
  377ba8:	49 8d 7c 24 01       	lea    0x1(%r12),%rdi
  377bad:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  377bb4:	00 
  377bb5:	48 29 f8             	sub    %rdi,%rax
  377bb8:	48 83 f8 01          	cmp    $0x1,%rax
  377bbc:	0f 84 a5 fd ff ff    	je     377967 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x467>
  377bc2:	49 39 cc             	cmp    %rcx,%r12
  377bc5:	0f 83 58 44 00 00    	jae    37c023 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4b23>
  377bcb:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  377bd2:	00 
  377bd3:	49 39 c4             	cmp    %rax,%r12
  377bd6:	0f 83 62 44 00 00    	jae    37c03e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4b3e>
  377bdc:	48 39 cf             	cmp    %rcx,%rdi
  377bdf:	0f 83 ad 46 00 00    	jae    37c292 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4d92>
  377be5:	48 39 c7             	cmp    %rax,%rdi
  377be8:	0f 83 75 10 00 00    	jae    378c63 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1763>
  377bee:	48 8b 84 24 a0 01 00 	mov    0x1a0(%rsp),%rax
  377bf5:	00 
  377bf6:	c4 21 7b 10 04 e0    	vmovsd (%rax,%r12,8),%xmm8
  377bfc:	48 8b 8c 24 98 01 00 	mov    0x198(%rsp),%rcx
  377c03:	00 
  377c04:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
  377c09:	c4 a1 7b 10 04 e1    	vmovsd (%rcx,%r12,8),%xmm0
  377c0f:	c4 62 7d 19 0c f8    	vbroadcastsd (%rax,%rdi,8),%ymm9
  377c15:	c4 62 7d 19 3c f9    	vbroadcastsd (%rcx,%rdi,8),%ymm15
  377c1b:	b0 01                	mov    $0x1,%al
  377c1d:	89 44 24 78          	mov    %eax,0x78(%rsp)
  377c21:	4d 85 d2             	test   %r10,%r10
  377c24:	c5 f9 29 84 24 20 01 	vmovapd %xmm0,0x120(%rsp)
  377c2b:	00 00 
  377c2d:	0f 84 c0 03 00 00    	je     377ff3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xaf3>
  377c33:	c4 c2 7d 19 f0       	vbroadcastsd %xmm8,%ymm6
  377c38:	c4 e2 7d 19 d8       	vbroadcastsd %xmm0,%ymm3
  377c3d:	c6 44 24 28 01       	movb   $0x1,0x28(%rsp)
  377c42:	31 f6                	xor    %esi,%esi
  377c44:	31 c9                	xor    %ecx,%ecx
  377c46:	c5 7d 29 f4          	vmovapd %ymm14,%ymm4
  377c4a:	c5 7d 11 b4 24 b0 01 	vmovupd %ymm14,0x1b0(%rsp)
  377c51:	00 00 
  377c53:	c5 79 29 84 24 40 01 	vmovapd %xmm8,0x140(%rsp)
  377c5a:	00 00 
  377c5c:	49 89 e8             	mov    %rbp,%r8
  377c5f:	48 8b 5c 24 70       	mov    0x70(%rsp),%rbx
  377c64:	48 39 d9             	cmp    %rbx,%rcx
  377c67:	48 0f 47 d9          	cmova  %rcx,%rbx
  377c6b:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
  377c72:	00 
  377c73:	48 39 f9             	cmp    %rdi,%rcx
  377c76:	48 0f 47 f9          	cmova  %rcx,%rdi
  377c7a:	41 f6 c3 01          	test   $0x1,%r11b
  377c7e:	0f 84 a7 00 00 00    	je     377d2b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x82b>
  377c84:	49 89 ce             	mov    %rcx,%r14
  377c87:	49 c1 e6 05          	shl    $0x5,%r14
  377c8b:	48 89 c8             	mov    %rcx,%rax
  377c8e:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  377c95:	00 
  377c96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  377c9d:	00 00 00 
  377ca0:	48 39 c3             	cmp    %rax,%rbx
  377ca3:	4c 8b 24 24          	mov    (%rsp),%r12
  377ca7:	0f 84 8d 42 00 00    	je     37bf3a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4a3a>
  377cad:	48 39 c7             	cmp    %rax,%rdi
  377cb0:	0f 84 6c 42 00 00    	je     37bf22 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4a22>
  377cb6:	c4 81 7d 10 04 34    	vmovupd (%r12,%r14,1),%ymm0
  377cbc:	c4 21 7d 10 1c 31    	vmovupd (%rcx,%r14,1),%ymm11
  377cc2:	c5 7d 29 d9          	vmovapd %ymm11,%ymm1
  377cc6:	c4 e2 cd a8 cb       	vfmadd213pd %ymm3,%ymm6,%ymm1
  377ccb:	49 89 d5             	mov    %rdx,%r13
  377cce:	c4 a2 fd a8 0c 32    	vfmadd213pd (%rdx,%r14,1),%ymm0,%ymm1
  377cd4:	c4 42 b5 a8 df       	vfmadd213pd %ymm15,%ymm9,%ymm11
  377cd9:	c4 e2 7d 19 2d 56 d2 	vbroadcastsd -0x2f2daa(%rip),%ymm5        # 84f38 <anon.890d649631ab6ab37a03cdc207a0d7b9.203.llvm.3426226200983260467+0x10>
  377ce0:	d0 ff 
  377ce2:	c4 62 f5 a8 d8       	vfmadd213pd %ymm0,%ymm1,%ymm11
  377ce7:	c5 a5 54 ed          	vandpd %ymm5,%ymm11,%ymm5
  377ceb:	c4 e3 7d 19 e8 01    	vextractf128 $0x1,%ymm5,%xmm0
  377cf1:	c5 d1 5f c0          	vmaxpd %xmm0,%xmm5,%xmm0
  377cf5:	c5 79 c6 c0 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm8
  377cfa:	c4 c1 7b 5f c0       	vmaxsd %xmm8,%xmm0,%xmm0
  377cff:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  377d03:	0f 87 27 01 00 00    	ja     377e30 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x930>
  377d09:	48 ff c0             	inc    %rax
  377d0c:	c4 81 7d 11 4c 35 00 	vmovupd %ymm1,0x0(%r13,%r14,1)
  377d13:	c4 01 7d 11 1c 34    	vmovupd %ymm11,(%r12,%r14,1)
  377d19:	49 83 c6 20          	add    $0x20,%r14
  377d1d:	4c 39 d0             	cmp    %r10,%rax
  377d20:	0f 82 7a ff ff ff    	jb     377ca0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x7a0>
  377d26:	e9 eb 0a 00 00       	jmp    378816 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1316>
  377d2b:	48 8b 6c 24 48       	mov    0x48(%rsp),%rbp
  377d30:	48 39 e9             	cmp    %rbp,%rcx
  377d33:	48 0f 47 e9          	cmova  %rcx,%rbp
  377d37:	49 89 ce             	mov    %rcx,%r14
  377d3a:	49 c1 e6 05          	shl    $0x5,%r14
  377d3e:	41 89 f4             	mov    %esi,%r12d
  377d41:	48 89 c8             	mov    %rcx,%rax
  377d44:	4c 8b 2c 24          	mov    (%rsp),%r13
  377d48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  377d4f:	00 
  377d50:	48 39 c3             	cmp    %rax,%rbx
  377d53:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  377d5a:	00 
  377d5b:	0f 84 d9 41 00 00    	je     37bf3a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4a3a>
  377d61:	48 39 c7             	cmp    %rax,%rdi
  377d64:	0f 84 b8 41 00 00    	je     37bf22 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4a22>
  377d6a:	c4 81 7d 10 44 35 00 	vmovupd 0x0(%r13,%r14,1),%ymm0
  377d71:	c4 21 7d 10 1c 31    	vmovupd (%rcx,%r14,1),%ymm11
  377d77:	c5 7d 29 d9          	vmovapd %ymm11,%ymm1
  377d7b:	c4 e2 cd a8 cb       	vfmadd213pd %ymm3,%ymm6,%ymm1
  377d80:	c4 a2 fd a8 0c 32    	vfmadd213pd (%rdx,%r14,1),%ymm0,%ymm1
  377d86:	c4 42 b5 a8 df       	vfmadd213pd %ymm15,%ymm9,%ymm11
  377d8b:	c4 e2 7d 19 2d a4 d1 	vbroadcastsd -0x2f2e5c(%rip),%ymm5        # 84f38 <anon.890d649631ab6ab37a03cdc207a0d7b9.203.llvm.3426226200983260467+0x10>
  377d92:	d0 ff 
  377d94:	c4 62 f5 a8 d8       	vfmadd213pd %ymm0,%ymm1,%ymm11
  377d99:	c5 a5 54 ed          	vandpd %ymm5,%ymm11,%ymm5
  377d9d:	c4 e3 7d 19 e8 01    	vextractf128 $0x1,%ymm5,%xmm0
  377da3:	c5 d1 5f c0          	vmaxpd %xmm0,%xmm5,%xmm0
  377da7:	c5 79 c6 c0 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm8
  377dac:	c4 c1 7b 5f c0       	vmaxsd %xmm8,%xmm0,%xmm0
  377db1:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  377db5:	0f 97 c1             	seta   %cl
  377db8:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  377dbc:	0f 87 80 00 00 00    	ja     377e42 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x942>
  377dc2:	48 39 c5             	cmp    %rax,%rbp
  377dc5:	0f 84 87 41 00 00    	je     37bf52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4a52>
  377dcb:	48 ff c0             	inc    %rax
  377dce:	40 08 ce             	or     %cl,%sil
  377dd1:	41 08 cc             	or     %cl,%r12b
  377dd4:	c4 e2 7d 19 05 13 ca 	vbroadcastsd -0x2f35ed(%rip),%ymm0        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  377ddb:	d0 ff 
  377ddd:	c5 d5 c2 c0 1d       	vcmpge_oqpd %ymm0,%ymm5,%ymm0
  377de2:	c5 55 c2 c2 00       	vcmpeqpd %ymm2,%ymm5,%ymm8
  377de7:	c5 bd 56 c0          	vorpd  %ymm0,%ymm8,%ymm0
  377deb:	c4 62 7d 19 05 b4 c5 	vbroadcastsd -0x2f3a4c(%rip),%ymm8        # 843a8 <GCC_except_table0+0x884>
  377df2:	d0 ff 
  377df4:	c4 c1 55 c2 e8 12    	vcmple_oqpd %ymm8,%ymm5,%ymm5
  377dfa:	c4 01 7d 10 04 37    	vmovupd (%r15,%r14,1),%ymm8
  377e00:	c5 3d c2 c2 11       	vcmplt_oqpd %ymm2,%ymm8,%ymm8
  377e05:	c5 bd 56 c0          	vorpd  %ymm0,%ymm8,%ymm0
  377e09:	c5 d5 54 e4          	vandpd %ymm4,%ymm5,%ymm4
  377e0d:	c5 dd 54 e0          	vandpd %ymm0,%ymm4,%ymm4
  377e11:	c4 a1 7d 11 0c 32    	vmovupd %ymm1,(%rdx,%r14,1)
  377e17:	c4 01 7d 11 5c 35 00 	vmovupd %ymm11,0x0(%r13,%r14,1)
  377e1e:	49 83 c6 20          	add    $0x20,%r14
  377e22:	4c 39 d0             	cmp    %r10,%rax
  377e25:	0f 82 25 ff ff ff    	jb     377d50 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x850>
  377e2b:	e9 25 0b 00 00       	jmp    378955 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1455>
  377e30:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  377e35:	48 8d 48 01          	lea    0x1(%rax),%rcx
  377e39:	4b 8d 34 2e          	lea    (%r14,%r13,1),%rsi
  377e3d:	4d 01 e6             	add    %r12,%r14
  377e40:	eb 16                	jmp    377e58 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x958>
  377e42:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  377e47:	48 8d 48 01          	lea    0x1(%rax),%rcx
  377e4b:	4c 89 ef             	mov    %r13,%rdi
  377e4e:	49 89 d5             	mov    %rdx,%r13
  377e51:	4a 8d 34 32          	lea    (%rdx,%r14,1),%rsi
  377e55:	49 01 fe             	add    %rdi,%r14
  377e58:	4c 89 c5             	mov    %r8,%rbp
  377e5b:	48 3b 44 24 48       	cmp    0x48(%rsp),%rax
  377e60:	0f 83 0b 42 00 00    	jae    37c071 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4b71>
  377e66:	c4 41 7d 6f f5       	vmovdqa %ymm13,%ymm14
  377e6b:	c4 e2 7d 19 05 fc e5 	vbroadcastsd -0x2f1a04(%rip),%ymm0        # 86470 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0x188>
  377e72:	d0 ff 
  377e74:	c5 55 c2 c0 1e       	vcmpgt_oqpd %ymm0,%ymm5,%ymm8
  377e79:	48 89 c7             	mov    %rax,%rdi
  377e7c:	48 c1 e7 05          	shl    $0x5,%rdi
  377e80:	c4 c1 7d 10 04 3f    	vmovupd (%r15,%rdi,1),%ymm0
  377e86:	c4 62 7d 19 2d 31 d0 	vbroadcastsd -0x2f2fcf(%rip),%ymm13        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  377e8d:	d0 ff 
  377e8f:	c5 95 58 e8          	vaddpd %ymm0,%ymm13,%ymm5
  377e93:	c4 e3 7d 4b ed 80    	vblendvpd %ymm8,%ymm5,%ymm0,%ymm5
  377e99:	c4 41 55 c2 e5 11    	vcmplt_oqpd %ymm13,%ymm5,%ymm12
  377e9f:	c4 c2 6d 37 c4       	vpcmpgtq %ymm12,%ymm2,%ymm0
  377ea4:	c5 95 db c0          	vpand  %ymm0,%ymm13,%ymm0
  377ea8:	c4 c3 7d 39 c5 01    	vextracti128 $0x1,%ymm0,%xmm13
  377eae:	c4 c1 79 5d c5       	vminpd %xmm13,%xmm0,%xmm0
  377eb3:	c5 79 c6 e8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm13
  377eb8:	c4 c1 7b 5d c5       	vminsd %xmm13,%xmm0,%xmm0
  377ebd:	c4 c1 79 2e c2       	vucomisd %xmm10,%xmm0
  377ec2:	0f 97 c3             	seta   %bl
  377ec5:	c5 d5 c2 c2 11       	vcmplt_oqpd %ymm2,%ymm5,%ymm0
  377eca:	41 f6 c3 01          	test   $0x1,%r11b
  377ece:	74 16                	je     377ee6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x9e6>
  377ed0:	c5 7d 10 94 24 b0 01 	vmovupd 0x1b0(%rsp),%ymm10
  377ed7:	00 00 
  377ed9:	c5 2d 54 d0          	vandpd %ymm0,%ymm10,%ymm10
  377edd:	c5 7d 11 94 24 b0 01 	vmovupd %ymm10,0x1b0(%rsp)
  377ee4:	00 00 
  377ee6:	48 3b 84 24 d0 01 00 	cmp    0x1d0(%rsp),%rax
  377eed:	00 
  377eee:	0f 83 95 41 00 00    	jae    37c089 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4b89>
  377ef4:	c4 62 7d 19 15 43 e0 	vbroadcastsd -0x2f1fbd(%rip),%ymm10        # 85f40 <anon.890d649631ab6ab37a03cdc207a0d7b9.1026.llvm.3426226200983260467+0x958>
  377efb:	d0 ff 
  377efd:	c5 2d 59 e9          	vmulpd %ymm1,%ymm10,%ymm13
  377f01:	c4 c3 75 4b cd 80    	vblendvpd %ymm8,%ymm13,%ymm1,%ymm1
  377f07:	c4 41 25 59 ea       	vmulpd %ymm10,%ymm11,%ymm13
  377f0c:	c4 43 25 4b dd 80    	vblendvpd %ymm8,%ymm13,%ymm11,%ymm11
  377f12:	49 8d 04 3f          	lea    (%r15,%rdi,1),%rax
  377f16:	20 5c 24 28          	and    %bl,0x28(%rsp)
  377f1a:	c4 62 7d 19 15 9d cf 	vbroadcastsd -0x2f3063(%rip),%ymm10        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  377f21:	d0 ff 
  377f23:	c4 62 7d 19 2d a4 e6 	vbroadcastsd -0x2f195c(%rip),%ymm13        # 865d0 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0x2e8>
  377f2a:	d0 ff 
  377f2c:	c4 43 15 4b e2 c0    	vblendvpd %ymm12,%ymm10,%ymm13,%ymm12
  377f32:	c4 e2 6d 37 c0       	vpcmpgtq %ymm0,%ymm2,%ymm0
  377f37:	c4 c1 7d df c4       	vpandn %ymm12,%ymm0,%ymm0
  377f3c:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  377f41:	c5 7d 10 24 3b       	vmovupd (%rbx,%rdi,1),%ymm12
  377f46:	c4 e3 1d 4b c0 80    	vblendvpd %ymm8,%ymm0,%ymm12,%ymm0
  377f4c:	c5 25 59 c0          	vmulpd %ymm0,%ymm11,%ymm8
  377f50:	c4 62 7d 19 25 df cf 	vbroadcastsd -0x2f3021(%rip),%ymm12        # 84f38 <anon.890d649631ab6ab37a03cdc207a0d7b9.203.llvm.3426226200983260467+0x10>
  377f57:	d0 ff 
  377f59:	c4 41 3d 54 c4       	vandpd %ymm12,%ymm8,%ymm8
  377f5e:	c4 41 25 54 e4       	vandpd %ymm12,%ymm11,%ymm12
  377f63:	c4 62 7d 19 15 3c c4 	vbroadcastsd -0x2f3bc4(%rip),%ymm10        # 843a8 <GCC_except_table0+0x884>
  377f6a:	d0 ff 
  377f6c:	c4 41 1d c2 e2 12    	vcmple_oqpd %ymm10,%ymm12,%ymm12
  377f72:	c5 9d 54 e4          	vandpd %ymm4,%ymm12,%ymm4
  377f76:	c5 3d c2 e2 00       	vcmpeqpd %ymm2,%ymm8,%ymm12
  377f7b:	c4 62 7d 19 15 6c c8 	vbroadcastsd -0x2f3794(%rip),%ymm10        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  377f82:	d0 ff 
  377f84:	c4 41 3d c2 ea 1d    	vcmpge_oqpd %ymm10,%ymm8,%ymm13
  377f8a:	c4 62 7d 19 15 25 d1 	vbroadcastsd -0x2f2edb(%rip),%ymm10        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  377f91:	d0 ff 
  377f93:	c4 41 3d c2 c2 12    	vcmple_oqpd %ymm10,%ymm8,%ymm8
  377f99:	c4 41 3d 54 c5       	vandpd %ymm13,%ymm8,%ymm8
  377f9e:	c4 41 3d 56 c4       	vorpd  %ymm12,%ymm8,%ymm8
  377fa3:	c5 bd 54 e4          	vandpd %ymm4,%ymm8,%ymm4
  377fa7:	c5 fd 11 0e          	vmovupd %ymm1,(%rsi)
  377fab:	c4 41 7d 11 1e       	vmovupd %ymm11,(%r14)
  377fb0:	c5 fd 11 28          	vmovupd %ymm5,(%rax)
  377fb4:	c5 fd 11 04 3b       	vmovupd %ymm0,(%rbx,%rdi,1)
  377fb9:	40 b6 01             	mov    $0x1,%sil
  377fbc:	41 b4 01             	mov    $0x1,%r12b
  377fbf:	4c 39 d1             	cmp    %r10,%rcx
  377fc2:	4c 8b b4 24 08 01 00 	mov    0x108(%rsp),%r14
  377fc9:	00 
  377fca:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  377fcf:	c4 41 7d 6f ee       	vmovdqa %ymm14,%ymm13
  377fd4:	c5 7d 10 b4 24 20 02 	vmovupd 0x220(%rsp),%ymm14
  377fdb:	00 00 
  377fdd:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  377fe2:	c5 79 28 84 24 40 01 	vmovapd 0x140(%rsp),%xmm8
  377fe9:	00 00 
  377feb:	0f 82 6b fc ff ff    	jb     377c5c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x75c>
  377ff1:	eb 17                	jmp    37800a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xb0a>
  377ff3:	45 31 e4             	xor    %r12d,%r12d
  377ff6:	c5 7d 11 b4 24 b0 01 	vmovupd %ymm14,0x1b0(%rsp)
  377ffd:	00 00 
  377fff:	c6 44 24 28 01       	movb   $0x1,0x28(%rsp)
  378004:	c5 7d 29 f4          	vmovapd %ymm14,%ymm4
  378008:	31 f6                	xor    %esi,%esi
  37800a:	48 83 bc 24 50 01 00 	cmpq   $0x0,0x150(%rsp)
  378011:	00 00 
  378013:	0f 84 28 08 00 00    	je     378841 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1341>
  378019:	48 83 bc 24 e8 00 00 	cmpq   $0x0,0xe8(%rsp)
  378020:	00 00 
  378022:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  378029:	00 
  37802a:	4c 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%r8
  378031:	00 
  378032:	0f 84 d0 3f 00 00    	je     37c008 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4b08>
  378038:	48 83 bc 24 90 00 00 	cmpq   $0x0,0x90(%rsp)
  37803f:	00 00 
  378041:	0f 84 a6 3f 00 00    	je     37bfed <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4aed>
  378047:	48 8b 0c 24          	mov    (%rsp),%rcx
  37804b:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  378050:	c5 fb 10 04 f9       	vmovsd (%rcx,%rdi,8),%xmm0
  378055:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
  37805c:	00 
  37805d:	c5 fb 10 1c c8       	vmovsd (%rax,%rcx,8),%xmm3
  378062:	c5 f9 28 f3          	vmovapd %xmm3,%xmm6
  378066:	c4 e2 b9 a9 b4 24 20 	vfmadd213sd 0x120(%rsp),%xmm8,%xmm6
  37806d:	01 00 00 
  378070:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  378075:	c4 c2 f9 a9 74 c5 00 	vfmadd213sd 0x0(%r13,%rax,8),%xmm0,%xmm6
  37807c:	c4 e1 f9 7e f7       	vmovq  %xmm6,%rdi
  378081:	c4 c2 b1 a9 df       	vfmadd213sd %xmm15,%xmm9,%xmm3
  378086:	c4 e2 c9 a9 d8       	vfmadd213sd %xmm0,%xmm6,%xmm3
  37808b:	c4 e1 f9 7e d8       	vmovq  %xmm3,%rax
  378090:	48 c1 ef 34          	shr    $0x34,%rdi
  378094:	81 e7 ff 07 00 00    	and    $0x7ff,%edi
  37809a:	48 c1 e8 34          	shr    $0x34,%rax
  37809e:	25 ff 07 00 00       	and    $0x7ff,%eax
  3780a3:	3d ff 07 00 00       	cmp    $0x7ff,%eax
  3780a8:	0f 92 c1             	setb   %cl
  3780ab:	31 c0                	xor    %eax,%eax
  3780ad:	81 ff fe 07 00 00    	cmp    $0x7fe,%edi
  3780b3:	0f 87 84 f4 ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3780b9:	84 c9                	test   %cl,%cl
  3780bb:	0f 84 7c f4 ff ff    	je     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3780c1:	c5 e1 54 05 c7 ef d0 	vandpd -0x2f1039(%rip),%xmm3,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  3780c8:	ff 
  3780c9:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  3780cd:	40 0f 97 c7          	seta   %dil
  3780d1:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  3780d5:	0f 86 30 01 00 00    	jbe    37820b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xd0b>
  3780db:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
  3780e1:	0f 84 de 42 00 00    	je     37c3c5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4ec5>
  3780e7:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  3780ee:	00 
  3780ef:	c4 c1 7b 10 04 c7    	vmovsd (%r15,%rax,8),%xmm0
  3780f5:	c5 fb 58 2d c3 cd d0 	vaddsd -0x2f323d(%rip),%xmm0,%xmm5        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  3780fc:	ff 
  3780fd:	c4 e1 f9 7e e8       	vmovq  %xmm5,%rax
  378102:	48 c1 e8 34          	shr    $0x34,%rax
  378106:	25 ff 07 00 00       	and    $0x7ff,%eax
  37810b:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  378110:	0f 87 25 f4 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  378116:	31 c0                	xor    %eax,%eax
  378118:	c5 f9 2e e8          	vucomisd %xmm0,%xmm5
  37811c:	75 06                	jne    378124 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xc24>
  37811e:	0f 8b 19 f4 ff ff    	jnp    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  378124:	c5 d1 54 05 64 ef d0 	vandpd -0x2f109c(%rip),%xmm5,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37812b:	ff 
  37812c:	c5 f9 2e 05 6c c5 d0 	vucomisd -0x2f3a94(%rip),%xmm0        # 846a0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x10>
  378133:	ff 
  378134:	0f 87 03 f4 ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37813a:	c5 e3 59 1d fe dd d0 	vmulsd -0x2f2202(%rip),%xmm3,%xmm3        # 85f40 <anon.890d649631ab6ab37a03cdc207a0d7b9.1026.llvm.3426226200983260467+0x958>
  378141:	ff 
  378142:	c5 e1 54 05 46 ef d0 	vandpd -0x2f10ba(%rip),%xmm3,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  378149:	ff 
  37814a:	c5 f9 2e 05 9e c6 d0 	vucomisd -0x2f3962(%rip),%xmm0        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  378151:	ff 
  378152:	0f 82 e3 f3 ff ff    	jb     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  378158:	c5 fb 10 05 60 cd d0 	vmovsd -0x2f32a0(%rip),%xmm0        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  37815f:	ff 
  378160:	c5 f9 2e c5          	vucomisd %xmm5,%xmm0
  378164:	0f 97 c1             	seta   %cl
  378167:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  37816e:	00 
  37816f:	c4 c1 7b 11 2c c7    	vmovsd %xmm5,(%r15,%rax,8)
  378175:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  378179:	c5 f9 2e cd          	vucomisd %xmm5,%xmm1
  37817d:	77 67                	ja     3781e6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xce6>
  37817f:	c5 d3 c2 05 38 cd d0 	vcmpltsd -0x2f32c8(%rip),%xmm5,%xmm0        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  378186:	ff 01 
  378188:	c5 fb 12 0d 40 e4 d0 	vmovddup -0x2f1bc0(%rip),%xmm1        # 865d0 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0x2e8>
  37818f:	ff 
  378190:	c4 e3 71 4b 0d 36 30 	vblendvpd %xmm0,-0x2ecfca(%rip),%xmm1,%xmm1        # 8b1d0 <anon.f9efbf6a85811f011f9cd7c053310384.235.llvm.15014775230106348234+0x11f0>
  378197:	d1 ff 00 
  37819a:	c5 e3 59 c1          	vmulsd %xmm1,%xmm3,%xmm0
  37819e:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  3781a3:	48 c1 e8 34          	shr    $0x34,%rax
  3781a7:	25 ff 07 00 00       	and    $0x7ff,%eax
  3781ac:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  3781b1:	0f 87 84 f3 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  3781b7:	c4 c1 79 2e c2       	vucomisd %xmm10,%xmm0
  3781bc:	75 02                	jne    3781c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xcc0>
  3781be:	7b 26                	jnp    3781e6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xce6>
  3781c0:	c5 f9 54 05 c8 ee d0 	vandpd -0x2f1138(%rip),%xmm0,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  3781c7:	ff 
  3781c8:	31 c0                	xor    %eax,%eax
  3781ca:	c5 f9 2e 05 1e c6 d0 	vucomisd -0x2f39e2(%rip),%xmm0        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  3781d1:	ff 
  3781d2:	0f 82 65 f3 ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3781d8:	c5 f9 2e 05 d8 ce d0 	vucomisd -0x2f3128(%rip),%xmm0        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  3781df:	ff 
  3781e0:	0f 87 57 f3 ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3781e6:	48 83 7c 24 60 00    	cmpq   $0x0,0x60(%rsp)
  3781ec:	0f 84 27 42 00 00    	je     37c419 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4f19>
  3781f2:	c5 cb 59 35 46 dd d0 	vmulsd -0x2f22ba(%rip),%xmm6,%xmm6        # 85f40 <anon.890d649631ab6ab37a03cdc207a0d7b9.1026.llvm.3426226200983260467+0x958>
  3781f9:	ff 
  3781fa:	20 4c 24 28          	and    %cl,0x28(%rsp)
  3781fe:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  378205:	00 
  378206:	c5 fb 11 0c c3       	vmovsd %xmm1,(%rbx,%rax,8)
  37820b:	b0 01                	mov    $0x1,%al
  37820d:	89 44 24 78          	mov    %eax,0x78(%rsp)
  378211:	41 f6 c3 01          	test   $0x1,%r11b
  378215:	74 21                	je     378238 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xd38>
  378217:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
  37821d:	0f 84 cc 41 00 00    	je     37c3ef <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4eef>
  378223:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  37822a:	00 
  37822b:	c4 41 79 2e 14 c7    	vucomisd (%r15,%rax,8),%xmm10
  378231:	0f 97 c0             	seta   %al
  378234:	89 44 24 78          	mov    %eax,0x78(%rsp)
  378238:	48 83 7c 24 60 00    	cmpq   $0x0,0x60(%rsp)
  37823e:	0f 84 15 3e 00 00    	je     37c059 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4b59>
  378244:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  37824b:	00 
  37824c:	c5 e3 59 04 c3       	vmulsd (%rbx,%rax,8),%xmm3,%xmm0
  378251:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  378256:	48 c1 e8 34          	shr    $0x34,%rax
  37825a:	25 ff 07 00 00       	and    $0x7ff,%eax
  37825f:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  378264:	0f 87 d1 f2 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37826a:	c4 c1 79 2e c2       	vucomisd %xmm10,%xmm0
  37826f:	75 02                	jne    378273 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xd73>
  378271:	7b 2a                	jnp    37829d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xd9d>
  378273:	c5 f9 54 05 15 ee d0 	vandpd -0x2f11eb(%rip),%xmm0,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37827a:	ff 
  37827b:	31 c0                	xor    %eax,%eax
  37827d:	c5 f9 2e 05 6b c5 d0 	vucomisd -0x2f3a95(%rip),%xmm0        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  378284:	ff 
  378285:	0f 82 b2 f2 ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37828b:	c5 fb 10 0d 25 ce d0 	vmovsd -0x2f31db(%rip),%xmm1        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  378292:	ff 
  378293:	c5 f9 2e c8          	vucomisd %xmm0,%xmm1
  378297:	0f 82 a0 f2 ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37829d:	40 08 fe             	or     %dil,%sil
  3782a0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  3782a5:	c4 c1 7b 11 74 c5 00 	vmovsd %xmm6,0x0(%r13,%rax,8)
  3782ac:	48 8b 04 24          	mov    (%rsp),%rax
  3782b0:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  3782b5:	c5 fb 11 1c c8       	vmovsd %xmm3,(%rax,%rcx,8)
  3782ba:	83 bc 24 50 01 00 00 	cmpl   $0x1,0x150(%rsp)
  3782c1:	01 
  3782c2:	0f 84 81 05 00 00    	je     378849 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1349>
  3782c8:	83 bc 24 e8 00 00 00 	cmpl   $0x1,0xe8(%rsp)
  3782cf:	01 
  3782d0:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  3782d7:	00 
  3782d8:	0f 84 2a 3d 00 00    	je     37c008 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4b08>
  3782de:	83 bc 24 90 00 00 00 	cmpl   $0x1,0x90(%rsp)
  3782e5:	01 
  3782e6:	0f 84 01 3d 00 00    	je     37bfed <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4aed>
  3782ec:	48 8b 0c 24          	mov    (%rsp),%rcx
  3782f0:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  3782f5:	c5 fb 10 44 f9 08    	vmovsd 0x8(%rcx,%rdi,8),%xmm0
  3782fb:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
  378302:	00 
  378303:	c5 fb 10 5c c8 08    	vmovsd 0x8(%rax,%rcx,8),%xmm3
  378309:	c5 f9 28 f3          	vmovapd %xmm3,%xmm6
  37830d:	c4 e2 b9 a9 b4 24 20 	vfmadd213sd 0x120(%rsp),%xmm8,%xmm6
  378314:	01 00 00 
  378317:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  37831c:	c4 c2 f9 a9 74 c5 08 	vfmadd213sd 0x8(%r13,%rax,8),%xmm0,%xmm6
  378323:	c4 e1 f9 7e f7       	vmovq  %xmm6,%rdi
  378328:	c4 c2 b1 a9 df       	vfmadd213sd %xmm15,%xmm9,%xmm3
  37832d:	c4 e2 c9 a9 d8       	vfmadd213sd %xmm0,%xmm6,%xmm3
  378332:	c4 e1 f9 7e d8       	vmovq  %xmm3,%rax
  378337:	48 c1 ef 34          	shr    $0x34,%rdi
  37833b:	81 e7 ff 07 00 00    	and    $0x7ff,%edi
  378341:	48 c1 e8 34          	shr    $0x34,%rax
  378345:	25 ff 07 00 00       	and    $0x7ff,%eax
  37834a:	3d ff 07 00 00       	cmp    $0x7ff,%eax
  37834f:	0f 92 c1             	setb   %cl
  378352:	31 c0                	xor    %eax,%eax
  378354:	81 ff fe 07 00 00    	cmp    $0x7fe,%edi
  37835a:	0f 87 dd f1 ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  378360:	84 c9                	test   %cl,%cl
  378362:	0f 84 d5 f1 ff ff    	je     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  378368:	c5 e1 54 05 20 ed d0 	vandpd -0x2f12e0(%rip),%xmm3,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37836f:	ff 
  378370:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  378374:	40 0f 97 c7          	seta   %dil
  378378:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  37837c:	0f 86 31 01 00 00    	jbe    3784b3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xfb3>
  378382:	83 7c 24 40 02       	cmpl   $0x2,0x40(%rsp)
  378387:	0f 82 d6 3d 00 00    	jb     37c163 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c63>
  37838d:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  378394:	00 
  378395:	c4 c1 7b 10 44 c7 08 	vmovsd 0x8(%r15,%rax,8),%xmm0
  37839c:	c5 fb 58 2d 1c cb d0 	vaddsd -0x2f34e4(%rip),%xmm0,%xmm5        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  3783a3:	ff 
  3783a4:	c4 e1 f9 7e e8       	vmovq  %xmm5,%rax
  3783a9:	48 c1 e8 34          	shr    $0x34,%rax
  3783ad:	25 ff 07 00 00       	and    $0x7ff,%eax
  3783b2:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  3783b7:	0f 87 7e f1 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  3783bd:	31 c0                	xor    %eax,%eax
  3783bf:	c5 f9 2e e8          	vucomisd %xmm0,%xmm5
  3783c3:	75 06                	jne    3783cb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xecb>
  3783c5:	0f 8b 72 f1 ff ff    	jnp    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3783cb:	c5 d1 54 05 bd ec d0 	vandpd -0x2f1343(%rip),%xmm5,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  3783d2:	ff 
  3783d3:	c5 f9 2e 05 c5 c2 d0 	vucomisd -0x2f3d3b(%rip),%xmm0        # 846a0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x10>
  3783da:	ff 
  3783db:	0f 87 5c f1 ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3783e1:	c5 e3 59 1d 57 db d0 	vmulsd -0x2f24a9(%rip),%xmm3,%xmm3        # 85f40 <anon.890d649631ab6ab37a03cdc207a0d7b9.1026.llvm.3426226200983260467+0x958>
  3783e8:	ff 
  3783e9:	c5 e1 54 05 9f ec d0 	vandpd -0x2f1361(%rip),%xmm3,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  3783f0:	ff 
  3783f1:	c5 f9 2e 05 f7 c3 d0 	vucomisd -0x2f3c09(%rip),%xmm0        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  3783f8:	ff 
  3783f9:	0f 82 3c f1 ff ff    	jb     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  3783ff:	c5 fb 10 05 b9 ca d0 	vmovsd -0x2f3547(%rip),%xmm0        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  378406:	ff 
  378407:	c5 f9 2e c5          	vucomisd %xmm5,%xmm0
  37840b:	0f 97 c1             	seta   %cl
  37840e:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  378415:	00 
  378416:	c4 c1 7b 11 6c c7 08 	vmovsd %xmm5,0x8(%r15,%rax,8)
  37841d:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  378421:	c5 f9 2e cd          	vucomisd %xmm5,%xmm1
  378425:	77 67                	ja     37848e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xf8e>
  378427:	c5 d3 c2 05 90 ca d0 	vcmpltsd -0x2f3570(%rip),%xmm5,%xmm0        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  37842e:	ff 01 
  378430:	c5 fb 12 0d 98 e1 d0 	vmovddup -0x2f1e68(%rip),%xmm1        # 865d0 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0x2e8>
  378437:	ff 
  378438:	c4 e3 71 4b 0d 8e 2d 	vblendvpd %xmm0,-0x2ed272(%rip),%xmm1,%xmm1        # 8b1d0 <anon.f9efbf6a85811f011f9cd7c053310384.235.llvm.15014775230106348234+0x11f0>
  37843f:	d1 ff 00 
  378442:	c5 e3 59 c1          	vmulsd %xmm1,%xmm3,%xmm0
  378446:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  37844b:	48 c1 e8 34          	shr    $0x34,%rax
  37844f:	25 ff 07 00 00       	and    $0x7ff,%eax
  378454:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  378459:	0f 87 dc f0 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37845f:	c4 c1 79 2e c2       	vucomisd %xmm10,%xmm0
  378464:	75 02                	jne    378468 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xf68>
  378466:	7b 26                	jnp    37848e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xf8e>
  378468:	c5 f9 54 05 20 ec d0 	vandpd -0x2f13e0(%rip),%xmm0,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37846f:	ff 
  378470:	31 c0                	xor    %eax,%eax
  378472:	c5 f9 2e 05 76 c3 d0 	vucomisd -0x2f3c8a(%rip),%xmm0        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  378479:	ff 
  37847a:	0f 82 bd f0 ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  378480:	c5 f9 2e 05 30 cc d0 	vucomisd -0x2f33d0(%rip),%xmm0        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  378487:	ff 
  378488:	0f 87 af f0 ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37848e:	83 7c 24 60 01       	cmpl   $0x1,0x60(%rsp)
  378493:	0f 84 de 3c 00 00    	je     37c177 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c77>
  378499:	c5 cb 59 35 9f da d0 	vmulsd -0x2f2561(%rip),%xmm6,%xmm6        # 85f40 <anon.890d649631ab6ab37a03cdc207a0d7b9.1026.llvm.3426226200983260467+0x958>
  3784a0:	ff 
  3784a1:	20 4c 24 28          	and    %cl,0x28(%rsp)
  3784a5:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  3784ac:	00 
  3784ad:	c5 fb 11 4c c3 08    	vmovsd %xmm1,0x8(%rbx,%rax,8)
  3784b3:	41 f6 c3 01          	test   $0x1,%r11b
  3784b7:	74 2d                	je     3784e6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xfe6>
  3784b9:	83 7c 24 40 02       	cmpl   $0x2,0x40(%rsp)
  3784be:	0f 82 a9 3c 00 00    	jb     37c16d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c6d>
  3784c4:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  3784cb:	00 
  3784cc:	c4 41 79 2e 54 c7 08 	vucomisd 0x8(%r15,%rax,8),%xmm10
  3784d3:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  3784d7:	0f b6 c9             	movzbl %cl,%ecx
  3784da:	b8 00 00 00 00       	mov    $0x0,%eax
  3784df:	0f 46 c8             	cmovbe %eax,%ecx
  3784e2:	89 4c 24 78          	mov    %ecx,0x78(%rsp)
  3784e6:	83 7c 24 60 01       	cmpl   $0x1,0x60(%rsp)
  3784eb:	0f 84 68 3b 00 00    	je     37c059 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4b59>
  3784f1:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  3784f8:	00 
  3784f9:	c5 e3 59 44 c3 08    	vmulsd 0x8(%rbx,%rax,8),%xmm3,%xmm0
  3784ff:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  378504:	48 c1 e8 34          	shr    $0x34,%rax
  378508:	25 ff 07 00 00       	and    $0x7ff,%eax
  37850d:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  378512:	0f 87 23 f0 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  378518:	c4 c1 79 2e c2       	vucomisd %xmm10,%xmm0
  37851d:	75 02                	jne    378521 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1021>
  37851f:	7b 2a                	jnp    37854b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x104b>
  378521:	c5 f9 54 05 67 eb d0 	vandpd -0x2f1499(%rip),%xmm0,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  378528:	ff 
  378529:	31 c0                	xor    %eax,%eax
  37852b:	c5 f9 2e 05 bd c2 d0 	vucomisd -0x2f3d43(%rip),%xmm0        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  378532:	ff 
  378533:	0f 82 04 f0 ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  378539:	c5 fb 10 0d 77 cb d0 	vmovsd -0x2f3489(%rip),%xmm1        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  378540:	ff 
  378541:	c5 f9 2e c8          	vucomisd %xmm0,%xmm1
  378545:	0f 82 f2 ef ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37854b:	40 08 fe             	or     %dil,%sil
  37854e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  378553:	c4 c1 7b 11 74 c5 08 	vmovsd %xmm6,0x8(%r13,%rax,8)
  37855a:	48 8b 04 24          	mov    (%rsp),%rax
  37855e:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  378563:	c5 fb 11 5c c8 08    	vmovsd %xmm3,0x8(%rax,%rcx,8)
  378569:	83 bc 24 50 01 00 00 	cmpl   $0x2,0x150(%rsp)
  378570:	02 
  378571:	0f 84 d2 02 00 00    	je     378849 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1349>
  378577:	83 bc 24 e8 00 00 00 	cmpl   $0x2,0xe8(%rsp)
  37857e:	02 
  37857f:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  378586:	00 
  378587:	0f 84 7b 3a 00 00    	je     37c008 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4b08>
  37858d:	83 bc 24 90 00 00 00 	cmpl   $0x2,0x90(%rsp)
  378594:	02 
  378595:	0f 84 52 3a 00 00    	je     37bfed <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4aed>
  37859b:	48 8b 0c 24          	mov    (%rsp),%rcx
  37859f:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  3785a4:	c5 fb 10 44 f9 10    	vmovsd 0x10(%rcx,%rdi,8),%xmm0
  3785aa:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
  3785b1:	00 
  3785b2:	c5 fb 10 4c c8 10    	vmovsd 0x10(%rax,%rcx,8),%xmm1
  3785b8:	c4 62 f1 a9 84 24 20 	vfmadd213sd 0x120(%rsp),%xmm1,%xmm8
  3785bf:	01 00 00 
  3785c2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  3785c7:	c4 42 f9 a9 44 c5 10 	vfmadd213sd 0x10(%r13,%rax,8),%xmm0,%xmm8
  3785ce:	c4 61 f9 7e c7       	vmovq  %xmm8,%rdi
  3785d3:	c4 42 f1 a9 cf       	vfmadd213sd %xmm15,%xmm1,%xmm9
  3785d8:	c4 62 b9 a9 c8       	vfmadd213sd %xmm0,%xmm8,%xmm9
  3785dd:	c4 61 f9 7e c8       	vmovq  %xmm9,%rax
  3785e2:	48 c1 ef 34          	shr    $0x34,%rdi
  3785e6:	81 e7 ff 07 00 00    	and    $0x7ff,%edi
  3785ec:	48 c1 e8 34          	shr    $0x34,%rax
  3785f0:	25 ff 07 00 00       	and    $0x7ff,%eax
  3785f5:	3d ff 07 00 00       	cmp    $0x7ff,%eax
  3785fa:	0f 92 c1             	setb   %cl
  3785fd:	31 c0                	xor    %eax,%eax
  3785ff:	81 ff fe 07 00 00    	cmp    $0x7fe,%edi
  378605:	0f 87 32 ef ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37860b:	84 c9                	test   %cl,%cl
  37860d:	0f 84 2a ef ff ff    	je     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  378613:	c5 b1 54 05 75 ea d0 	vandpd -0x2f158b(%rip),%xmm9,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37861a:	ff 
  37861b:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  37861f:	40 0f 97 c7          	seta   %dil
  378623:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  378627:	0f 86 31 01 00 00    	jbe    37875e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x125e>
  37862d:	83 7c 24 40 03       	cmpl   $0x3,0x40(%rsp)
  378632:	0f 85 80 3d 00 00    	jne    37c3b8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4eb8>
  378638:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  37863f:	00 
  378640:	c4 c1 7b 10 44 c7 10 	vmovsd 0x10(%r15,%rax,8),%xmm0
  378647:	c5 fb 58 0d 71 c8 d0 	vaddsd -0x2f378f(%rip),%xmm0,%xmm1        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  37864e:	ff 
  37864f:	c4 e1 f9 7e c8       	vmovq  %xmm1,%rax
  378654:	48 c1 e8 34          	shr    $0x34,%rax
  378658:	25 ff 07 00 00       	and    $0x7ff,%eax
  37865d:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  378662:	0f 87 d3 ee ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  378668:	31 c0                	xor    %eax,%eax
  37866a:	c5 f9 2e c8          	vucomisd %xmm0,%xmm1
  37866e:	75 06                	jne    378676 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1176>
  378670:	0f 8b c7 ee ff ff    	jnp    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  378676:	c5 f1 54 05 12 ea d0 	vandpd -0x2f15ee(%rip),%xmm1,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37867d:	ff 
  37867e:	c5 f9 2e 05 1a c0 d0 	vucomisd -0x2f3fe6(%rip),%xmm0        # 846a0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x10>
  378685:	ff 
  378686:	0f 87 b1 ee ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37868c:	c5 33 59 0d ac d8 d0 	vmulsd -0x2f2754(%rip),%xmm9,%xmm9        # 85f40 <anon.890d649631ab6ab37a03cdc207a0d7b9.1026.llvm.3426226200983260467+0x958>
  378693:	ff 
  378694:	c5 b1 54 05 f4 e9 d0 	vandpd -0x2f160c(%rip),%xmm9,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37869b:	ff 
  37869c:	c5 f9 2e 05 4c c1 d0 	vucomisd -0x2f3eb4(%rip),%xmm0        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  3786a3:	ff 
  3786a4:	0f 82 91 ee ff ff    	jb     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  3786aa:	c5 fb 10 05 0e c8 d0 	vmovsd -0x2f37f2(%rip),%xmm0        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  3786b1:	ff 
  3786b2:	c5 f9 2e c1          	vucomisd %xmm1,%xmm0
  3786b6:	0f 97 c1             	seta   %cl
  3786b9:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  3786c0:	00 
  3786c1:	c4 c1 7b 11 4c c7 10 	vmovsd %xmm1,0x10(%r15,%rax,8)
  3786c8:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  3786cc:	c5 f9 2e c1          	vucomisd %xmm1,%xmm0
  3786d0:	77 67                	ja     378739 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1239>
  3786d2:	c5 f3 c2 05 e5 c7 d0 	vcmpltsd -0x2f381b(%rip),%xmm1,%xmm0        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  3786d9:	ff 01 
  3786db:	c5 fb 12 0d ed de d0 	vmovddup -0x2f2113(%rip),%xmm1        # 865d0 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0x2e8>
  3786e2:	ff 
  3786e3:	c4 e3 71 4b 05 e3 2a 	vblendvpd %xmm0,-0x2ed51d(%rip),%xmm1,%xmm0        # 8b1d0 <anon.f9efbf6a85811f011f9cd7c053310384.235.llvm.15014775230106348234+0x11f0>
  3786ea:	d1 ff 00 
  3786ed:	c5 b3 59 c8          	vmulsd %xmm0,%xmm9,%xmm1
  3786f1:	c4 e1 f9 7e c8       	vmovq  %xmm1,%rax
  3786f6:	48 c1 e8 34          	shr    $0x34,%rax
  3786fa:	25 ff 07 00 00       	and    $0x7ff,%eax
  3786ff:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  378704:	0f 87 31 ee ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37870a:	c4 c1 79 2e ca       	vucomisd %xmm10,%xmm1
  37870f:	75 02                	jne    378713 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1213>
  378711:	7b 26                	jnp    378739 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1239>
  378713:	c5 f1 54 0d 75 e9 d0 	vandpd -0x2f168b(%rip),%xmm1,%xmm1        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37871a:	ff 
  37871b:	31 c0                	xor    %eax,%eax
  37871d:	c5 f9 2e 0d cb c0 d0 	vucomisd -0x2f3f35(%rip),%xmm1        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  378724:	ff 
  378725:	0f 82 12 ee ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37872b:	c5 f9 2e 0d 85 c9 d0 	vucomisd -0x2f367b(%rip),%xmm1        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  378732:	ff 
  378733:	0f 87 04 ee ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  378739:	83 7c 24 60 03       	cmpl   $0x3,0x60(%rsp)
  37873e:	0f 85 c8 3c 00 00    	jne    37c40c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4f0c>
  378744:	c5 3b 59 05 f4 d7 d0 	vmulsd -0x2f280c(%rip),%xmm8,%xmm8        # 85f40 <anon.890d649631ab6ab37a03cdc207a0d7b9.1026.llvm.3426226200983260467+0x958>
  37874b:	ff 
  37874c:	20 4c 24 28          	and    %cl,0x28(%rsp)
  378750:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  378757:	00 
  378758:	c5 fb 11 44 c3 10    	vmovsd %xmm0,0x10(%rbx,%rax,8)
  37875e:	41 f6 c3 01          	test   $0x1,%r11b
  378762:	74 2d                	je     378791 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1291>
  378764:	83 7c 24 40 03       	cmpl   $0x3,0x40(%rsp)
  378769:	0f 85 73 3c 00 00    	jne    37c3e2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4ee2>
  37876f:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  378776:	00 
  378777:	c4 41 79 2e 54 c7 10 	vucomisd 0x10(%r15,%rax,8),%xmm10
  37877e:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  378782:	0f b6 c9             	movzbl %cl,%ecx
  378785:	b8 00 00 00 00       	mov    $0x0,%eax
  37878a:	0f 46 c8             	cmovbe %eax,%ecx
  37878d:	89 4c 24 78          	mov    %ecx,0x78(%rsp)
  378791:	83 7c 24 60 02       	cmpl   $0x2,0x60(%rsp)
  378796:	0f 84 bd 38 00 00    	je     37c059 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4b59>
  37879c:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  3787a3:	00 
  3787a4:	c5 b3 59 44 c3 10    	vmulsd 0x10(%rbx,%rax,8),%xmm9,%xmm0
  3787aa:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  3787af:	48 c1 e8 34          	shr    $0x34,%rax
  3787b3:	25 ff 07 00 00       	and    $0x7ff,%eax
  3787b8:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  3787bd:	0f 87 78 ed ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  3787c3:	c4 c1 79 2e c2       	vucomisd %xmm10,%xmm0
  3787c8:	75 02                	jne    3787cc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x12cc>
  3787ca:	7b 2a                	jnp    3787f6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x12f6>
  3787cc:	c5 f9 54 05 bc e8 d0 	vandpd -0x2f1744(%rip),%xmm0,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  3787d3:	ff 
  3787d4:	31 c0                	xor    %eax,%eax
  3787d6:	c5 f9 2e 05 12 c0 d0 	vucomisd -0x2f3fee(%rip),%xmm0        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  3787dd:	ff 
  3787de:	0f 82 59 ed ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3787e4:	c5 fb 10 0d cc c8 d0 	vmovsd -0x2f3734(%rip),%xmm1        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  3787eb:	ff 
  3787ec:	c5 f9 2e c8          	vucomisd %xmm0,%xmm1
  3787f0:	0f 82 47 ed ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3787f6:	40 08 fe             	or     %dil,%sil
  3787f9:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  3787fe:	c4 41 7b 11 44 c5 10 	vmovsd %xmm8,0x10(%r13,%rax,8)
  378805:	48 8b 04 24          	mov    (%rsp),%rax
  378809:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  37880e:	c5 7b 11 4c c8 10    	vmovsd %xmm9,0x10(%rax,%rcx,8)
  378814:	eb 33                	jmp    378849 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1349>
  378816:	41 89 f4             	mov    %esi,%r12d
  378819:	4c 8b b4 24 08 01 00 	mov    0x108(%rsp),%r14
  378820:	00 
  378821:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  378826:	4c 89 c5             	mov    %r8,%rbp
  378829:	c5 79 28 84 24 40 01 	vmovapd 0x140(%rsp),%xmm8
  378830:	00 00 
  378832:	48 83 bc 24 50 01 00 	cmpq   $0x0,0x150(%rsp)
  378839:	00 00 
  37883b:	0f 85 d8 f7 ff ff    	jne    378019 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xb19>
  378841:	4c 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%r8
  378848:	00 
  378849:	c4 e2 6d 37 c4       	vpcmpgtq %ymm4,%ymm2,%ymm0
  37884e:	c5 95 db c0          	vpand  %ymm0,%ymm13,%ymm0
  378852:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
  378858:	c5 f9 5d c1          	vminpd %xmm1,%xmm0,%xmm0
  37885c:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  378861:	c5 fb 5d c1          	vminsd %xmm1,%xmm0,%xmm0
  378865:	c4 c1 79 2e c2       	vucomisd %xmm10,%xmm0
  37886a:	0f 86 cb ec ff ff    	jbe    37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  378870:	41 f6 c3 01          	test   $0x1,%r11b
  378874:	0f 84 b3 00 00 00    	je     37892d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x142d>
  37887a:	40 f6 c6 01          	test   $0x1,%sil
  37887e:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  378883:	48 8b bc 24 a8 01 00 	mov    0x1a8(%rsp),%rdi
  37888a:	00 
  37888b:	4c 8b 9c 24 10 02 00 	mov    0x210(%rsp),%r11
  378892:	00 
  378893:	74 62                	je     3788f7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x13f7>
  378895:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
  37889b:	74 27                	je     3788c4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x13c4>
  37889d:	31 c0                	xor    %eax,%eax
  37889f:	90                   	nop
  3788a0:	49 8b 4c 05 00       	mov    0x0(%r13,%rax,1),%rcx
  3788a5:	48 c1 e9 34          	shr    $0x34,%rcx
  3788a9:	81 e1 ff 07 00 00    	and    $0x7ff,%ecx
  3788af:	81 f9 fe 07 00 00    	cmp    $0x7fe,%ecx
  3788b5:	0f 87 80 ec ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  3788bb:	48 83 c0 08          	add    $0x8,%rax
  3788bf:	48 39 c7             	cmp    %rax,%rdi
  3788c2:	75 dc                	jne    3788a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x13a0>
  3788c4:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  3788ca:	74 2b                	je     3788f7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x13f7>
  3788cc:	31 c0                	xor    %eax,%eax
  3788ce:	66 90                	xchg   %ax,%ax
  3788d0:	48 8b 0c 24          	mov    (%rsp),%rcx
  3788d4:	48 8b 0c 01          	mov    (%rcx,%rax,1),%rcx
  3788d8:	48 c1 e9 34          	shr    $0x34,%rcx
  3788dc:	81 e1 ff 07 00 00    	and    $0x7ff,%ecx
  3788e2:	81 f9 fe 07 00 00    	cmp    $0x7fe,%ecx
  3788e8:	0f 87 4d ec ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  3788ee:	48 83 c0 08          	add    $0x8,%rax
  3788f2:	49 39 c3             	cmp    %rax,%r11
  3788f5:	75 d9                	jne    3788d0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x13d0>
  3788f7:	44 8b 5c 24 78       	mov    0x78(%rsp),%r11d
  3788fc:	45 84 e3             	test   %r12b,%r11b
  3788ff:	74 34                	je     378935 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1435>
  378901:	c4 e2 6d 37 84 24 b0 	vpcmpgtq 0x1b0(%rsp),%ymm2,%ymm0
  378908:	01 00 00 
  37890b:	c5 95 db c0          	vpand  %ymm0,%ymm13,%ymm0
  37890f:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
  378915:	c5 f9 5d c1          	vminpd %xmm1,%xmm0,%xmm0
  378919:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  37891e:	c5 fb 5d c1          	vminsd %xmm1,%xmm0,%xmm0
  378922:	c4 c1 79 2e c2       	vucomisd %xmm10,%xmm0
  378927:	41 0f 97 c3          	seta   %r11b
  37892b:	eb 08                	jmp    378935 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1435>
  37892d:	45 31 db             	xor    %r11d,%r11d
  378930:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  378935:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
  37893a:	49 83 c4 02          	add    $0x2,%r12
  37893e:	4c 3b a4 24 a8 00 00 	cmp    0xa8(%rsp),%r12
  378945:	00 
  378946:	0f 92 c0             	setb   %al
  378949:	84 44 24 28          	test   %al,0x28(%rsp)
  37894d:	0f 85 95 f1 ff ff    	jne    377ae8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x5e8>
  378953:	eb 30                	jmp    378985 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1485>
  378955:	4c 8b b4 24 08 01 00 	mov    0x108(%rsp),%r14
  37895c:	00 
  37895d:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  378962:	4c 89 c5             	mov    %r8,%rbp
  378965:	49 89 d5             	mov    %rdx,%r13
  378968:	c5 79 28 84 24 40 01 	vmovapd 0x140(%rsp),%xmm8
  37896f:	00 00 
  378971:	48 83 bc 24 50 01 00 	cmpq   $0x0,0x150(%rsp)
  378978:	00 00 
  37897a:	0f 85 99 f6 ff ff    	jne    378019 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0xb19>
  378980:	e9 bc fe ff ff       	jmp    378841 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1341>
  378985:	4c 3b a4 24 a8 00 00 	cmp    0xa8(%rsp),%r12
  37898c:	00 
  37898d:	75 73                	jne    378a02 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1502>
  37898f:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  378994:	48 3b 7c 24 30       	cmp    0x30(%rsp),%rdi
  378999:	0f 85 9c eb ff ff    	jne    37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37899f:	b0 01                	mov    $0x1,%al
  3789a1:	48 85 ff             	test   %rdi,%rdi
  3789a4:	0f 84 93 eb ff ff    	je     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3789aa:	48 c1 e7 03          	shl    $0x3,%rdi
  3789ae:	31 c9                	xor    %ecx,%ecx
  3789b0:	49 8b 74 0d 00       	mov    0x0(%r13,%rcx,1),%rsi
  3789b5:	48 c1 ee 34          	shr    $0x34,%rsi
  3789b9:	81 e6 ff 07 00 00    	and    $0x7ff,%esi
  3789bf:	81 fe fe 07 00 00    	cmp    $0x7fe,%esi
  3789c5:	0f 87 70 eb ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  3789cb:	48 83 c1 08          	add    $0x8,%rcx
  3789cf:	48 39 cf             	cmp    %rcx,%rdi
  3789d2:	75 dc                	jne    3789b0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x14b0>
  3789d4:	31 c9                	xor    %ecx,%ecx
  3789d6:	48 8b 14 24          	mov    (%rsp),%rdx
  3789da:	48 8b 34 0a          	mov    (%rdx,%rcx,1),%rsi
  3789de:	48 c1 ee 34          	shr    $0x34,%rsi
  3789e2:	81 e6 ff 07 00 00    	and    $0x7ff,%esi
  3789e8:	81 fe fe 07 00 00    	cmp    $0x7fe,%esi
  3789ee:	0f 87 47 eb ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  3789f4:	48 83 c1 08          	add    $0x8,%rcx
  3789f8:	48 39 cf             	cmp    %rcx,%rdi
  3789fb:	75 dd                	jne    3789da <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x14da>
  3789fd:	e9 3b eb ff ff       	jmp    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  378a02:	48 89 ac 24 50 01 00 	mov    %rbp,0x150(%rsp)
  378a09:	00 
  378a0a:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  378a0f:	48 89 e8             	mov    %rbp,%rax
  378a12:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  378a17:	48 31 c8             	xor    %rcx,%rax
  378a1a:	49 31 c9             	xor    %rcx,%r9
  378a1d:	49 09 c1             	or     %rax,%r9
  378a20:	0f 85 15 eb ff ff    	jne    37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  378a26:	4c 89 84 24 f0 00 00 	mov    %r8,0xf0(%rsp)
  378a2d:	00 
  378a2e:	48 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%rax
  378a35:	ff ff 0f 
  378a38:	48 89 e9             	mov    %rbp,%rcx
  378a3b:	48 c1 e9 02          	shr    $0x2,%rcx
  378a3f:	41 89 e8             	mov    %ebp,%r8d
  378a42:	41 83 e0 03          	and    $0x3,%r8d
  378a46:	49 89 ea             	mov    %rbp,%r10
  378a49:	49 21 c2             	and    %rax,%r10
  378a4c:	48 85 c9             	test   %rcx,%rcx
  378a4f:	48 89 d5             	mov    %rdx,%rbp
  378a52:	4c 8b 2c 24          	mov    (%rsp),%r13
  378a56:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
  378a5b:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
  378a60:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
  378a65:	0f 84 de 00 00 00    	je     378b49 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1649>
  378a6b:	31 c0                	xor    %eax,%eax
  378a6d:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  378a71:	c4 e2 7d 59 0d 46 c4 	vpbroadcastq -0x2f3bba(%rip),%ymm1        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  378a78:	d0 ff 
  378a7a:	c4 e2 7d 19 15 b5 c4 	vbroadcastsd -0x2f3b4b(%rip),%ymm2        # 84f38 <anon.890d649631ab6ab37a03cdc207a0d7b9.203.llvm.3426226200983260467+0x10>
  378a81:	d0 ff 
  378a83:	c4 e2 7d 19 1d 64 bd 	vbroadcastsd -0x2f429c(%rip),%ymm3        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  378a8a:	d0 ff 
  378a8c:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  378a90:	c4 e2 7d 19 2d 1f c6 	vbroadcastsd -0x2f39e1(%rip),%ymm5        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  378a97:	d0 ff 
  378a99:	c4 c1 7d 10 34 07    	vmovupd (%r15,%rax,1),%ymm6
  378a9f:	c5 cd c2 f0 1d       	vcmpge_oqpd %ymm0,%ymm6,%ymm6
  378aa4:	c4 e2 7d 37 f6       	vpcmpgtq %ymm6,%ymm0,%ymm6
  378aa9:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
  378aad:	c4 e3 7d 39 f7 01    	vextracti128 $0x1,%ymm6,%xmm7
  378ab3:	c5 c9 5d f7          	vminpd %xmm7,%xmm6,%xmm6
  378ab7:	c5 c9 c6 fe 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm7
  378abc:	c5 cb 5d f7          	vminsd %xmm7,%xmm6,%xmm6
  378ac0:	c5 f9 2e f4          	vucomisd %xmm4,%xmm6
  378ac4:	0f 86 95 06 00 00    	jbe    37915f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c5f>
  378aca:	c5 fd 10 34 03       	vmovupd (%rbx,%rax,1),%ymm6
  378acf:	c5 cd 59 7c 05 00    	vmulpd 0x0(%rbp,%rax,1),%ymm6,%ymm7
  378ad5:	c4 c1 4d 59 74 05 00 	vmulpd 0x0(%r13,%rax,1),%ymm6,%ymm6
  378adc:	c5 c5 54 fa          	vandpd %ymm2,%ymm7,%ymm7
  378ae0:	c5 cd 54 f2          	vandpd %ymm2,%ymm6,%ymm6
  378ae4:	c5 45 c2 c0 00       	vcmpeqpd %ymm0,%ymm7,%ymm8
  378ae9:	c5 45 c2 cb 1d       	vcmpge_oqpd %ymm3,%ymm7,%ymm9
  378aee:	c5 c5 c2 fd 12       	vcmple_oqpd %ymm5,%ymm7,%ymm7
  378af3:	c5 b5 54 ff          	vandpd %ymm7,%ymm9,%ymm7
  378af7:	c5 bd 56 ff          	vorpd  %ymm7,%ymm8,%ymm7
  378afb:	c5 4d c2 c0 00       	vcmpeqpd %ymm0,%ymm6,%ymm8
  378b00:	c5 4d c2 cb 1d       	vcmpge_oqpd %ymm3,%ymm6,%ymm9
  378b05:	c5 cd c2 f5 12       	vcmple_oqpd %ymm5,%ymm6,%ymm6
  378b0a:	c5 b5 54 f6          	vandpd %ymm6,%ymm9,%ymm6
  378b0e:	c5 bd 56 f6          	vorpd  %ymm6,%ymm8,%ymm6
  378b12:	c5 cd 54 f7          	vandpd %ymm7,%ymm6,%ymm6
  378b16:	c4 e2 7d 37 f6       	vpcmpgtq %ymm6,%ymm0,%ymm6
  378b1b:	c5 cd db f1          	vpand  %ymm1,%ymm6,%ymm6
  378b1f:	c4 e3 7d 39 f7 01    	vextracti128 $0x1,%ymm6,%xmm7
  378b25:	c5 c9 5d f7          	vminpd %xmm7,%xmm6,%xmm6
  378b29:	c5 c9 c6 fe 01       	vshufpd $0x1,%xmm6,%xmm6,%xmm7
  378b2e:	c5 cb 5d f7          	vminsd %xmm7,%xmm6,%xmm6
  378b32:	c5 f9 2e f4          	vucomisd %xmm4,%xmm6
  378b36:	0f 86 23 06 00 00    	jbe    37915f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c5f>
  378b3c:	48 83 c0 20          	add    $0x20,%rax
  378b40:	48 ff c9             	dec    %rcx
  378b43:	0f 85 50 ff ff ff    	jne    378a99 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1599>
  378b49:	4d 85 c0             	test   %r8,%r8
  378b4c:	74 7a                	je     378bc8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x16c8>
  378b4e:	4b 8b 04 d7          	mov    (%r15,%r10,8),%rax
  378b52:	b1 3f                	mov    $0x3f,%cl
  378b54:	c4 e2 f0 f5 f8       	bzhi   %rcx,%rax,%rdi
  378b59:	48 8d 77 ff          	lea    -0x1(%rdi),%rsi
  378b5d:	48 b9 ff ff ff ff ff 	movabs $0xfffffffffffff,%rcx
  378b64:	ff 0f 00 
  378b67:	48 39 ce             	cmp    %rcx,%rsi
  378b6a:	41 0f 92 c0          	setb   %r8b
  378b6e:	48 85 c0             	test   %rax,%rax
  378b71:	41 0f 98 c1          	sets   %r9b
  378b75:	45 20 c8             	and    %r9b,%r8b
  378b78:	48 be 00 00 00 00 00 	movabs $0x7ff0000000000000,%rsi
  378b7f:	00 f0 7f 
  378b82:	48 39 f7             	cmp    %rsi,%rdi
  378b85:	0f 9f c0             	setg   %al
  378b88:	41 0f 94 c3          	sete   %r11b
  378b8c:	41 08 c3             	or     %al,%r11b
  378b8f:	45 08 c3             	or     %r8b,%r11b
  378b92:	48 b8 00 00 00 00 00 	movabs $0xfff0000000000000,%rax
  378b99:	00 f0 ff 
  378b9c:	48 01 c7             	add    %rax,%rdi
  378b9f:	48 c1 ef 35          	shr    $0x35,%rdi
  378ba3:	81 ff ff 03 00 00    	cmp    $0x3ff,%edi
  378ba9:	40 0f 92 c7          	setb   %dil
  378bad:	44 20 cf             	and    %r9b,%dil
  378bb0:	44 08 df             	or     %r11b,%dil
  378bb3:	0f 85 a6 05 00 00    	jne    37915f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c5f>
  378bb9:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  378bbe:	41 83 f8 01          	cmp    $0x1,%r8d
  378bc2:	0f 85 b3 00 00 00    	jne    378c7b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x177b>
  378bc8:	4d 85 c0             	test   %r8,%r8
  378bcb:	0f 84 f5 01 00 00    	je     378dc6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x18c6>
  378bd1:	c4 a1 7b 10 04 d3    	vmovsd (%rbx,%r10,8),%xmm0
  378bd7:	c4 a1 7b 59 4c d5 00 	vmulsd 0x0(%rbp,%r10,8),%xmm0,%xmm1
  378bde:	c4 e1 f9 7e c8       	vmovq  %xmm1,%rax
  378be3:	48 c1 e8 34          	shr    $0x34,%rax
  378be7:	25 ff 07 00 00       	and    $0x7ff,%eax
  378bec:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  378bf1:	0f 87 68 05 00 00    	ja     37915f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c5f>
  378bf7:	c4 81 7b 59 44 d5 00 	vmulsd 0x0(%r13,%r10,8),%xmm0,%xmm0
  378bfe:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  378c02:	c5 f9 2e ca          	vucomisd %xmm2,%xmm1
  378c06:	0f 85 32 01 00 00    	jne    378d3e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x183e>
  378c0c:	0f 8a 2c 01 00 00    	jp     378d3e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x183e>
  378c12:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  378c17:	48 c1 e8 34          	shr    $0x34,%rax
  378c1b:	25 ff 07 00 00       	and    $0x7ff,%eax
  378c20:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  378c25:	0f 86 5b 01 00 00    	jbe    378d86 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1886>
  378c2b:	e9 2f 05 00 00       	jmp    37915f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c5f>
  378c30:	48 85 c9             	test   %rcx,%rcx
  378c33:	0f 84 26 36 00 00    	je     37c25f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4d5f>
  378c39:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
  378c40:	00 
  378c41:	48 85 c0             	test   %rax,%rax
  378c44:	0f 84 2c 36 00 00    	je     37c276 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4d76>
  378c4a:	48 83 f9 01          	cmp    $0x1,%rcx
  378c4e:	0f 84 39 36 00 00    	je     37c28d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4d8d>
  378c54:	48 83 f8 01          	cmp    $0x1,%rax
  378c58:	0f 85 dd e8 ff ff    	jne    37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  378c5e:	bf 01 00 00 00       	mov    $0x1,%edi
  378c63:	48 8d 15 d6 90 4b 00 	lea    0x4b90d6(%rip),%rdx        # 831d40 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xa80>
  378c6a:	48 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%rsi
  378c71:	00 
  378c72:	c5 f8 77             	vzeroupper
  378c75:	ff 15 95 22 4f 00    	call   *0x4f2295(%rip)        # 86af10 <_DYNAMIC+0x298>
  378c7b:	4b 8b 7c d7 08       	mov    0x8(%r15,%r10,8),%rdi
  378c80:	41 b0 3f             	mov    $0x3f,%r8b
  378c83:	c4 62 b8 f5 c7       	bzhi   %r8,%rdi,%r8
  378c88:	4d 8d 48 ff          	lea    -0x1(%r8),%r9
  378c8c:	49 39 c9             	cmp    %rcx,%r9
  378c8f:	41 0f 92 c1          	setb   %r9b
  378c93:	48 85 ff             	test   %rdi,%rdi
  378c96:	40 0f 98 c7          	sets   %dil
  378c9a:	41 20 f9             	and    %dil,%r9b
  378c9d:	49 39 f0             	cmp    %rsi,%r8
  378ca0:	41 0f 9f c3          	setg   %r11b
  378ca4:	0f 94 c3             	sete   %bl
  378ca7:	44 08 db             	or     %r11b,%bl
  378caa:	44 08 cb             	or     %r9b,%bl
  378cad:	49 01 c0             	add    %rax,%r8
  378cb0:	49 c1 e8 35          	shr    $0x35,%r8
  378cb4:	41 81 f8 ff 03 00 00 	cmp    $0x3ff,%r8d
  378cbb:	41 0f 92 c0          	setb   %r8b
  378cbf:	41 20 f8             	and    %dil,%r8b
  378cc2:	41 08 d8             	or     %bl,%r8b
  378cc5:	74 0c                	je     378cd3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x17d3>
  378cc7:	31 f6                	xor    %esi,%esi
  378cc9:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  378cce:	e9 8e 04 00 00       	jmp    379161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c61>
  378cd3:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  378cd8:	41 83 f8 02          	cmp    $0x2,%r8d
  378cdc:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  378ce1:	0f 84 e1 fe ff ff    	je     378bc8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x16c8>
  378ce7:	4b 8b 7c d7 10       	mov    0x10(%r15,%r10,8),%rdi
  378cec:	41 b0 3f             	mov    $0x3f,%r8b
  378cef:	c4 62 b8 f5 c7       	bzhi   %r8,%rdi,%r8
  378cf4:	4d 8d 48 ff          	lea    -0x1(%r8),%r9
  378cf8:	49 39 c9             	cmp    %rcx,%r9
  378cfb:	0f 92 c1             	setb   %cl
  378cfe:	48 85 ff             	test   %rdi,%rdi
  378d01:	40 0f 98 c7          	sets   %dil
  378d05:	40 20 f9             	and    %dil,%cl
  378d08:	49 39 f0             	cmp    %rsi,%r8
  378d0b:	40 0f 9f c6          	setg   %sil
  378d0f:	41 0f 94 c1          	sete   %r9b
  378d13:	41 08 f1             	or     %sil,%r9b
  378d16:	41 08 c9             	or     %cl,%r9b
  378d19:	4c 01 c0             	add    %r8,%rax
  378d1c:	48 c1 e8 35          	shr    $0x35,%rax
  378d20:	3d ff 03 00 00       	cmp    $0x3ff,%eax
  378d25:	0f 92 c0             	setb   %al
  378d28:	40 20 f8             	and    %dil,%al
  378d2b:	44 08 c8             	or     %r9b,%al
  378d2e:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  378d33:	0f 84 8f fe ff ff    	je     378bc8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x16c8>
  378d39:	e9 21 04 00 00       	jmp    37915f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c5f>
  378d3e:	c5 f1 54 0d 4a e3 d0 	vandpd -0x2f1cb6(%rip),%xmm1,%xmm1        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  378d45:	ff 
  378d46:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  378d4b:	48 c1 e8 34          	shr    $0x34,%rax
  378d4f:	25 ff 07 00 00       	and    $0x7ff,%eax
  378d54:	3d ff 07 00 00       	cmp    $0x7ff,%eax
  378d59:	0f 92 c1             	setb   %cl
  378d5c:	31 f6                	xor    %esi,%esi
  378d5e:	c5 f9 2e 0d 8a ba d0 	vucomisd -0x2f4576(%rip),%xmm1        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  378d65:	ff 
  378d66:	0f 82 f5 03 00 00    	jb     379161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c61>
  378d6c:	c5 fb 10 15 44 c3 d0 	vmovsd -0x2f3cbc(%rip),%xmm2        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  378d73:	ff 
  378d74:	c5 f9 2e d1          	vucomisd %xmm1,%xmm2
  378d78:	0f 82 e3 03 00 00    	jb     379161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c61>
  378d7e:	84 c9                	test   %cl,%cl
  378d80:	0f 84 db 03 00 00    	je     379161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c61>
  378d86:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  378d8a:	c5 f9 2e c1          	vucomisd %xmm1,%xmm0
  378d8e:	75 02                	jne    378d92 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1892>
  378d90:	7b 2a                	jnp    378dbc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x18bc>
  378d92:	c5 f9 54 05 f6 e2 d0 	vandpd -0x2f1d0a(%rip),%xmm0,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  378d99:	ff 
  378d9a:	31 f6                	xor    %esi,%esi
  378d9c:	c5 f9 2e 05 4c ba d0 	vucomisd -0x2f45b4(%rip),%xmm0        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  378da3:	ff 
  378da4:	0f 82 b7 03 00 00    	jb     379161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c61>
  378daa:	c5 fb 10 0d 06 c3 d0 	vmovsd -0x2f3cfa(%rip),%xmm1        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  378db1:	ff 
  378db2:	c5 f9 2e c8          	vucomisd %xmm0,%xmm1
  378db6:	0f 82 a5 03 00 00    	jb     379161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c61>
  378dbc:	41 83 f8 01          	cmp    $0x1,%r8d
  378dc0:	0f 85 24 01 00 00    	jne    378eea <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x19ea>
  378dc6:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  378dcb:	48 85 c9             	test   %rcx,%rcx
  378dce:	74 47                	je     378e17 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1917>
  378dd0:	31 c0                	xor    %eax,%eax
  378dd2:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  378dd6:	c4 e2 7d 19 0d e1 c0 	vbroadcastsd -0x2f3f1f(%rip),%ymm1        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  378ddd:	d0 ff 
  378ddf:	c5 fd 10 54 05 00    	vmovupd 0x0(%rbp,%rax,1),%ymm2
  378de5:	c5 ed 59 14 03       	vmulpd (%rbx,%rax,1),%ymm2,%ymm2
  378dea:	c5 fd 11 54 05 00    	vmovupd %ymm2,0x0(%rbp,%rax,1)
  378df0:	c4 c1 7d 10 54 05 00 	vmovupd 0x0(%r13,%rax,1),%ymm2
  378df7:	c5 ed 59 14 03       	vmulpd (%rbx,%rax,1),%ymm2,%ymm2
  378dfc:	c4 c1 7d 11 54 05 00 	vmovupd %ymm2,0x0(%r13,%rax,1)
  378e03:	c4 c1 7d 11 04 07    	vmovupd %ymm0,(%r15,%rax,1)
  378e09:	c5 fd 11 0c 03       	vmovupd %ymm1,(%rbx,%rax,1)
  378e0e:	48 83 c0 20          	add    $0x20,%rax
  378e12:	48 ff c9             	dec    %rcx
  378e15:	75 c8                	jne    378ddf <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x18df>
  378e17:	40 b6 01             	mov    $0x1,%sil
  378e1a:	4d 85 c0             	test   %r8,%r8
  378e1d:	0f 84 3e 03 00 00    	je     379161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c61>
  378e23:	c4 a1 7b 10 04 d3    	vmovsd (%rbx,%r10,8),%xmm0
  378e29:	c4 a1 7b 59 44 d5 00 	vmulsd 0x0(%rbp,%r10,8),%xmm0,%xmm0
  378e30:	c4 a1 7b 11 44 d5 00 	vmovsd %xmm0,0x0(%rbp,%r10,8)
  378e37:	c4 a1 7b 10 04 d3    	vmovsd (%rbx,%r10,8),%xmm0
  378e3d:	c4 81 7b 59 44 d5 00 	vmulsd 0x0(%r13,%r10,8),%xmm0,%xmm0
  378e44:	c4 81 7b 11 44 d5 00 	vmovsd %xmm0,0x0(%r13,%r10,8)
  378e4b:	4b c7 04 d7 00 00 00 	movq   $0x0,(%r15,%r10,8)
  378e52:	00 
  378e53:	48 b9 00 00 00 00 00 	movabs $0x3ff0000000000000,%rcx
  378e5a:	00 f0 3f 
  378e5d:	4a 89 0c d3          	mov    %rcx,(%rbx,%r10,8)
  378e61:	41 83 f8 01          	cmp    $0x1,%r8d
  378e65:	0f 84 f6 02 00 00    	je     379161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c61>
  378e6b:	c4 a1 7b 10 44 d3 08 	vmovsd 0x8(%rbx,%r10,8),%xmm0
  378e72:	c4 a1 7b 59 44 d5 08 	vmulsd 0x8(%rbp,%r10,8),%xmm0,%xmm0
  378e79:	c4 a1 7b 11 44 d5 08 	vmovsd %xmm0,0x8(%rbp,%r10,8)
  378e80:	c4 a1 7b 10 44 d3 08 	vmovsd 0x8(%rbx,%r10,8),%xmm0
  378e87:	c4 81 7b 59 44 d5 08 	vmulsd 0x8(%r13,%r10,8),%xmm0,%xmm0
  378e8e:	c4 81 7b 11 44 d5 08 	vmovsd %xmm0,0x8(%r13,%r10,8)
  378e95:	4b c7 44 d7 08 00 00 	movq   $0x0,0x8(%r15,%r10,8)
  378e9c:	00 00 
  378e9e:	4a 89 4c d3 08       	mov    %rcx,0x8(%rbx,%r10,8)
  378ea3:	41 83 f8 02          	cmp    $0x2,%r8d
  378ea7:	0f 84 b4 02 00 00    	je     379161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c61>
  378ead:	c4 a1 7b 10 44 d3 10 	vmovsd 0x10(%rbx,%r10,8),%xmm0
  378eb4:	c4 a1 7b 59 44 d5 10 	vmulsd 0x10(%rbp,%r10,8),%xmm0,%xmm0
  378ebb:	c4 a1 7b 11 44 d5 10 	vmovsd %xmm0,0x10(%rbp,%r10,8)
  378ec2:	c4 a1 7b 10 44 d3 10 	vmovsd 0x10(%rbx,%r10,8),%xmm0
  378ec9:	c4 81 7b 59 44 d5 10 	vmulsd 0x10(%r13,%r10,8),%xmm0,%xmm0
  378ed0:	c4 81 7b 11 44 d5 10 	vmovsd %xmm0,0x10(%r13,%r10,8)
  378ed7:	4b c7 44 d7 10 00 00 	movq   $0x0,0x10(%r15,%r10,8)
  378ede:	00 00 
  378ee0:	4a 89 4c d3 10       	mov    %rcx,0x10(%rbx,%r10,8)
  378ee5:	e9 77 02 00 00       	jmp    379161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c61>
  378eea:	c4 a1 7b 10 44 d3 08 	vmovsd 0x8(%rbx,%r10,8),%xmm0
  378ef1:	c4 a1 7b 59 4c d5 08 	vmulsd 0x8(%rbp,%r10,8),%xmm0,%xmm1
  378ef8:	c4 e1 f9 7e c8       	vmovq  %xmm1,%rax
  378efd:	48 c1 e8 34          	shr    $0x34,%rax
  378f01:	25 ff 07 00 00       	and    $0x7ff,%eax
  378f06:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  378f0b:	0f 87 4e 02 00 00    	ja     37915f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c5f>
  378f11:	c4 81 7b 59 44 d5 08 	vmulsd 0x8(%r13,%r10,8),%xmm0,%xmm0
  378f18:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  378f1c:	c5 f9 2e ca          	vucomisd %xmm2,%xmm1
  378f20:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  378f25:	75 29                	jne    378f50 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1a50>
  378f27:	7a 27                	jp     378f50 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1a50>
  378f29:	48 c1 e8 34          	shr    $0x34,%rax
  378f2d:	25 ff 07 00 00       	and    $0x7ff,%eax
  378f32:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  378f37:	76 75                	jbe    378fae <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1aae>
  378f39:	e9 21 02 00 00       	jmp    37915f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c5f>
  378f3e:	48 8d 0d 13 8e 4b 00 	lea    0x4b8e13(%rip),%rcx        # 831d58 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xa98>
  378f45:	31 ff                	xor    %edi,%edi
  378f47:	48 89 ea             	mov    %rbp,%rdx
  378f4a:	ff 15 c8 1f 4f 00    	call   *0x4f1fc8(%rip)        # 86af18 <_DYNAMIC+0x2a0>
  378f50:	c5 f1 54 0d 38 e1 d0 	vandpd -0x2f1ec8(%rip),%xmm1,%xmm1        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  378f57:	ff 
  378f58:	48 c1 e8 34          	shr    $0x34,%rax
  378f5c:	25 ff 07 00 00       	and    $0x7ff,%eax
  378f61:	3d ff 07 00 00       	cmp    $0x7ff,%eax
  378f66:	40 0f 92 c6          	setb   %sil
  378f6a:	c5 f9 2e 0d 7e b8 d0 	vucomisd -0x2f4782(%rip),%xmm1        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  378f71:	ff 
  378f72:	0f 82 db 01 00 00    	jb     379153 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c53>
  378f78:	c5 fb 10 15 38 c1 d0 	vmovsd -0x2f3ec8(%rip),%xmm2        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  378f7f:	ff 
  378f80:	c5 f9 2e d1          	vucomisd %xmm1,%xmm2
  378f84:	0f 82 c9 01 00 00    	jb     379153 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c53>
  378f8a:	40 84 f6             	test   %sil,%sil
  378f8d:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  378f92:	48 89 d5             	mov    %rdx,%rbp
  378f95:	4c 8b 2c 24          	mov    (%rsp),%r13
  378f99:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  378f9e:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  378fa3:	be 00 00 00 00       	mov    $0x0,%esi
  378fa8:	0f 84 b3 01 00 00    	je     379161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c61>
  378fae:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  378fb2:	c5 f9 2e c1          	vucomisd %xmm1,%xmm0
  378fb6:	75 02                	jne    378fba <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1aba>
  378fb8:	7b 43                	jnp    378ffd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1afd>
  378fba:	c5 f9 54 05 ce e0 d0 	vandpd -0x2f1f32(%rip),%xmm0,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  378fc1:	ff 
  378fc2:	c5 f9 2e 05 26 b8 d0 	vucomisd -0x2f47da(%rip),%xmm0        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  378fc9:	ff 
  378fca:	0f 82 83 01 00 00    	jb     379153 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c53>
  378fd0:	c5 fb 10 0d e0 c0 d0 	vmovsd -0x2f3f20(%rip),%xmm1        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  378fd7:	ff 
  378fd8:	c5 f9 2e c8          	vucomisd %xmm0,%xmm1
  378fdc:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  378fe1:	48 89 d5             	mov    %rdx,%rbp
  378fe4:	4c 8b 2c 24          	mov    (%rsp),%r13
  378fe8:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  378fed:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  378ff2:	be 00 00 00 00       	mov    $0x0,%esi
  378ff7:	0f 82 64 01 00 00    	jb     379161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c61>
  378ffd:	41 83 f8 02          	cmp    $0x2,%r8d
  379001:	0f 84 bf fd ff ff    	je     378dc6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x18c6>
  379007:	4c 89 e7             	mov    %r12,%rdi
  37900a:	4c 89 f1             	mov    %r14,%rcx
  37900d:	c4 a1 7b 10 44 d3 10 	vmovsd 0x10(%rbx,%r10,8),%xmm0
  379014:	c4 a1 7b 59 4c d5 10 	vmulsd 0x10(%rbp,%r10,8),%xmm0,%xmm1
  37901b:	c4 e1 f9 7e c8       	vmovq  %xmm1,%rax
  379020:	48 c1 e8 34          	shr    $0x34,%rax
  379024:	25 ff 07 00 00       	and    $0x7ff,%eax
  379029:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37902e:	76 19                	jbe    379049 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1b49>
  379030:	31 f6                	xor    %esi,%esi
  379032:	49 89 ce             	mov    %rcx,%r14
  379035:	49 89 fc             	mov    %rdi,%r12
  379038:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  37903d:	48 89 d5             	mov    %rdx,%rbp
  379040:	4c 8b 2c 24          	mov    (%rsp),%r13
  379044:	e9 18 01 00 00       	jmp    379161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c61>
  379049:	48 8b 04 24          	mov    (%rsp),%rax
  37904d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  379052:	c5 fb 59 44 f0 10    	vmulsd 0x10(%rax,%rsi,8),%xmm0,%xmm0
  379058:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  37905c:	c5 f9 2e ca          	vucomisd %xmm2,%xmm1
  379060:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  379065:	75 33                	jne    37909a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1b9a>
  379067:	7a 31                	jp     37909a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1b9a>
  379069:	48 c1 e8 34          	shr    $0x34,%rax
  37906d:	25 ff 07 00 00       	and    $0x7ff,%eax
  379072:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  379077:	49 89 ce             	mov    %rcx,%r14
  37907a:	49 89 fc             	mov    %rdi,%r12
  37907d:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  379082:	48 89 d5             	mov    %rdx,%rbp
  379085:	4c 8b 2c 24          	mov    (%rsp),%r13
  379089:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  37908e:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  379093:	76 61                	jbe    3790f6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1bf6>
  379095:	e9 c5 00 00 00       	jmp    37915f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c5f>
  37909a:	c5 f1 54 0d ee df d0 	vandpd -0x2f2012(%rip),%xmm1,%xmm1        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  3790a1:	ff 
  3790a2:	48 c1 e8 34          	shr    $0x34,%rax
  3790a6:	25 ff 07 00 00       	and    $0x7ff,%eax
  3790ab:	3d ff 07 00 00       	cmp    $0x7ff,%eax
  3790b0:	40 0f 92 c6          	setb   %sil
  3790b4:	c5 f9 2e 0d 34 b7 d0 	vucomisd -0x2f48cc(%rip),%xmm1        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  3790bb:	ff 
  3790bc:	0f 82 8b 00 00 00    	jb     37914d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c4d>
  3790c2:	c5 fb 10 15 ee bf d0 	vmovsd -0x2f4012(%rip),%xmm2        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  3790c9:	ff 
  3790ca:	c5 f9 2e d1          	vucomisd %xmm1,%xmm2
  3790ce:	72 7d                	jb     37914d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c4d>
  3790d0:	40 84 f6             	test   %sil,%sil
  3790d3:	49 89 ce             	mov    %rcx,%r14
  3790d6:	49 89 fc             	mov    %rdi,%r12
  3790d9:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  3790de:	48 89 d5             	mov    %rdx,%rbp
  3790e1:	4c 8b 2c 24          	mov    (%rsp),%r13
  3790e5:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  3790ea:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  3790ef:	be 00 00 00 00       	mov    $0x0,%esi
  3790f4:	74 6b                	je     379161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c61>
  3790f6:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  3790fa:	c5 f9 2e c1          	vucomisd %xmm1,%xmm0
  3790fe:	75 06                	jne    379106 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c06>
  379100:	0f 8b c0 fc ff ff    	jnp    378dc6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x18c6>
  379106:	c5 f9 54 05 82 df d0 	vandpd -0x2f207e(%rip),%xmm0,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37910d:	ff 
  37910e:	c5 f9 2e 05 da b6 d0 	vucomisd -0x2f4926(%rip),%xmm0        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  379115:	ff 
  379116:	72 35                	jb     37914d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c4d>
  379118:	c5 fb 10 0d 98 bf d0 	vmovsd -0x2f4068(%rip),%xmm1        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  37911f:	ff 
  379120:	c5 f9 2e c8          	vucomisd %xmm0,%xmm1
  379124:	49 89 ce             	mov    %rcx,%r14
  379127:	49 89 fc             	mov    %rdi,%r12
  37912a:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  37912f:	48 89 d5             	mov    %rdx,%rbp
  379132:	4c 8b 2c 24          	mov    (%rsp),%r13
  379136:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
  37913b:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  379140:	be 00 00 00 00       	mov    $0x0,%esi
  379145:	0f 83 7b fc ff ff    	jae    378dc6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x18c6>
  37914b:	eb 14                	jmp    379161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1c61>
  37914d:	49 89 ce             	mov    %rcx,%r14
  379150:	49 89 fc             	mov    %rdi,%r12
  379153:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  379158:	48 89 d5             	mov    %rdx,%rbp
  37915b:	4c 8b 2c 24          	mov    (%rsp),%r13
  37915f:	31 f6                	xor    %esi,%esi
  379161:	4c 3b a4 24 a8 00 00 	cmp    0xa8(%rsp),%r12
  379168:	00 
  379169:	0f 83 94 18 00 00    	jae    37aa03 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3503>
  37916f:	4c 89 b4 24 08 01 00 	mov    %r14,0x108(%rsp)
  379176:	00 
  379177:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
  37917e:	00 
  37917f:	48 89 c8             	mov    %rcx,%rax
  379182:	48 c1 e8 02          	shr    $0x2,%rax
  379186:	89 ca                	mov    %ecx,%edx
  379188:	83 e2 03             	and    $0x3,%edx
  37918b:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
  379190:	89 34 24             	mov    %esi,(%rsp)
  379193:	48 be fc ff ff ff ff 	movabs $0xffffffffffffffc,%rsi
  37919a:	ff ff 0f 
  37919d:	48 21 f1             	and    %rsi,%rcx
  3791a0:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  3791a7:	00 
  3791a8:	48 8b 8c 24 80 01 00 	mov    0x180(%rsp),%rcx
  3791af:	00 
  3791b0:	49 89 ce             	mov    %rcx,%r14
  3791b3:	49 c1 ee 02          	shr    $0x2,%r14
  3791b7:	41 89 c8             	mov    %ecx,%r8d
  3791ba:	41 83 e0 03          	and    $0x3,%r8d
  3791be:	48 21 f1             	and    %rsi,%rcx
  3791c1:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  3791c6:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
  3791cd:	00 
  3791ce:	48 89 ca             	mov    %rcx,%rdx
  3791d1:	48 c1 ea 02          	shr    $0x2,%rdx
  3791d5:	41 89 ca             	mov    %ecx,%r10d
  3791d8:	41 83 e2 03          	and    $0x3,%r10d
  3791dc:	48 21 f1             	and    %rsi,%rcx
  3791df:	48 89 8c 24 40 01 00 	mov    %rcx,0x140(%rsp)
  3791e6:	00 
  3791e7:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
  3791ee:	00 
  3791ef:	48 89 cf             	mov    %rcx,%rdi
  3791f2:	48 c1 ef 02          	shr    $0x2,%rdi
  3791f6:	41 89 cb             	mov    %ecx,%r11d
  3791f9:	41 83 e3 03          	and    $0x3,%r11d
  3791fd:	48 21 f1             	and    %rsi,%rcx
  379200:	48 89 8c 24 b8 00 00 	mov    %rcx,0xb8(%rsp)
  379207:	00 
  379208:	48 8b 8c 24 38 01 00 	mov    0x138(%rsp),%rcx
  37920f:	00 
  379210:	49 89 c9             	mov    %rcx,%r9
  379213:	49 c1 e9 02          	shr    $0x2,%r9
  379217:	4c 89 8c 24 c0 00 00 	mov    %r9,0xc0(%rsp)
  37921e:	00 
  37921f:	41 89 c9             	mov    %ecx,%r9d
  379222:	41 83 e1 03          	and    $0x3,%r9d
  379226:	4c 89 8c 24 b0 01 00 	mov    %r9,0x1b0(%rsp)
  37922d:	00 
  37922e:	48 21 f1             	and    %rsi,%rcx
  379231:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  379236:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  37923b:	80 3c 24 00          	cmpb   $0x0,(%rsp)
  37923f:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  379246:	00 
  379247:	4c 89 74 24 70       	mov    %r14,0x70(%rsp)
  37924c:	48 89 54 24 78       	mov    %rdx,0x78(%rsp)
  379251:	48 89 bc 24 d8 00 00 	mov    %rdi,0xd8(%rsp)
  379258:	00 
  379259:	4c 89 84 24 b0 00 00 	mov    %r8,0xb0(%rsp)
  379260:	00 
  379261:	4c 89 94 24 90 00 00 	mov    %r10,0x90(%rsp)
  379268:	00 
  379269:	4c 89 5c 24 40       	mov    %r11,0x40(%rsp)
  37926e:	0f 84 bb 01 00 00    	je     37942f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1f2f>
  379274:	4c 8b 9c 24 f0 00 00 	mov    0xf0(%rsp),%r11
  37927b:	00 
  37927c:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  379281:	49 8d 7c 24 01       	lea    0x1(%r12),%rdi
  379286:	4c 8b b4 24 08 01 00 	mov    0x108(%rsp),%r14
  37928d:	00 
  37928e:	31 c0                	xor    %eax,%eax
  379290:	48 39 8c 24 90 01 00 	cmp    %rcx,0x190(%rsp)
  379297:	00 
  379298:	0f 85 9f e2 ff ff    	jne    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37929e:	48 39 8c 24 88 01 00 	cmp    %rcx,0x188(%rsp)
  3792a5:	00 
  3792a6:	0f 85 91 e2 ff ff    	jne    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3792ac:	48 39 8c 24 80 01 00 	cmp    %rcx,0x180(%rsp)
  3792b3:	00 
  3792b4:	0f 85 83 e2 ff ff    	jne    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3792ba:	48 39 8c 24 78 01 00 	cmp    %rcx,0x178(%rsp)
  3792c1:	00 
  3792c2:	0f 85 75 e2 ff ff    	jne    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3792c8:	48 39 8c 24 38 01 00 	cmp    %rcx,0x138(%rsp)
  3792cf:	00 
  3792d0:	0f 85 67 e2 ff ff    	jne    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3792d6:	4c 89 5c 24 30       	mov    %r11,0x30(%rsp)
  3792db:	48 39 8c 24 00 01 00 	cmp    %rcx,0x100(%rsp)
  3792e2:	00 
  3792e3:	0f 85 54 e2 ff ff    	jne    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3792e9:	48 39 8c 24 c8 00 00 	cmp    %rcx,0xc8(%rsp)
  3792f0:	00 
  3792f1:	0f 85 46 e2 ff ff    	jne    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  3792f7:	4d 89 e0             	mov    %r12,%r8
  3792fa:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  3792fe:	c5 7d c2 e0 00       	vcmpeqpd %ymm0,%ymm0,%ymm12
  379303:	31 c0                	xor    %eax,%eax
  379305:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
  37930c:	00 
  37930d:	48 83 e9 02          	sub    $0x2,%rcx
  379311:	48 0f 43 c1          	cmovae %rcx,%rax
  379315:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  37931c:	00 
  37931d:	49 39 c0             	cmp    %rax,%r8
  379320:	48 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%rsi
  379327:	00 
  379328:	0f 83 8e 20 00 00    	jae    37b3bc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3ebc>
  37932e:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  379335:	00 
  379336:	c6 00 01             	movb   $0x1,(%rax)
  379339:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  379340:	00 
  379341:	83 e1 03             	and    $0x3,%ecx
  379344:	4c 8b bc 24 b0 01 00 	mov    0x1b0(%rsp),%r15
  37934b:	00 
  37934c:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  379353:	00 
  379354:	41 39 cf             	cmp    %ecx,%r15d
  379357:	4c 8b 4c 24 68       	mov    0x68(%rsp),%r9
  37935c:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  379361:	4c 8b 54 24 70       	mov    0x70(%rsp),%r10
  379366:	0f 85 05 28 00 00    	jne    37bb71 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4671>
  37936c:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  379373:	00 
  379374:	39 44 24 40          	cmp    %eax,0x40(%rsp)
  379378:	0f 85 f3 27 00 00    	jne    37bb71 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4671>
  37937e:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  379385:	00 
  379386:	39 84 24 90 00 00 00 	cmp    %eax,0x90(%rsp)
  37938d:	0f 85 de 27 00 00    	jne    37bb71 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4671>
  379393:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  37939a:	00 
  37939b:	39 84 24 b0 00 00 00 	cmp    %eax,0xb0(%rsp)
  3793a2:	0f 85 c9 27 00 00    	jne    37bb71 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4671>
  3793a8:	3b 94 24 c8 00 00 00 	cmp    0xc8(%rsp),%edx
  3793af:	0f 85 bc 27 00 00    	jne    37bb71 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4671>
  3793b5:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  3793bc:	00 
  3793bd:	48 c1 e8 02          	shr    $0x2,%rax
  3793c1:	48 39 84 24 c0 00 00 	cmp    %rax,0xc0(%rsp)
  3793c8:	00 
  3793c9:	0f 85 a2 27 00 00    	jne    37bb71 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4671>
  3793cf:	48 39 84 24 e8 00 00 	cmp    %rax,0xe8(%rsp)
  3793d6:	00 
  3793d7:	0f 85 94 27 00 00    	jne    37bb71 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4671>
  3793dd:	49 39 c2             	cmp    %rax,%r10
  3793e0:	0f 85 8b 27 00 00    	jne    37bb71 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4671>
  3793e6:	48 39 44 24 78       	cmp    %rax,0x78(%rsp)
  3793eb:	0f 85 80 27 00 00    	jne    37bb71 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4671>
  3793f1:	48 39 84 24 d8 00 00 	cmp    %rax,0xd8(%rsp)
  3793f8:	00 
  3793f9:	0f 85 72 27 00 00    	jne    37bb71 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4671>
  3793ff:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  379404:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  37940b:	00 
  37940c:	48 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%rax
  379413:	ff ff 0f 
  379416:	48 21 c1             	and    %rax,%rcx
  379419:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  37941e:	41 b3 01             	mov    $0x1,%r11b
  379421:	c5 7d 11 a4 24 d0 01 	vmovupd %ymm12,0x1d0(%rsp)
  379428:	00 00 
  37942a:	e9 10 16 00 00       	jmp    37aa3f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x353f>
  37942f:	4c 89 f1             	mov    %r14,%rcx
  379432:	49 89 d6             	mov    %rdx,%r14
  379435:	48 89 ca             	mov    %rcx,%rdx
  379438:	48 39 c1             	cmp    %rax,%rcx
  37943b:	48 89 c1             	mov    %rax,%rcx
  37943e:	48 0f 42 ca          	cmovb  %rdx,%rcx
  379442:	4c 39 f1             	cmp    %r14,%rcx
  379445:	49 0f 43 ce          	cmovae %r14,%rcx
  379449:	48 39 f9             	cmp    %rdi,%rcx
  37944c:	48 0f 43 cf          	cmovae %rdi,%rcx
  379450:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  379455:	49 8d 41 ff          	lea    -0x1(%r9),%rax
  379459:	48 39 c1             	cmp    %rax,%rcx
  37945c:	48 0f 43 c8          	cmovae %rax,%rcx
  379460:	48 89 8c 24 20 02 00 	mov    %rcx,0x220(%rsp)
  379467:	00 
  379468:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  37946d:	48 8d 4a ff          	lea    -0x1(%rdx),%rcx
  379471:	4c 39 c1             	cmp    %r8,%rcx
  379474:	49 0f 43 c8          	cmovae %r8,%rcx
  379478:	48 39 f1             	cmp    %rsi,%rcx
  37947b:	48 0f 43 ce          	cmovae %rsi,%rcx
  37947f:	4c 39 d1             	cmp    %r10,%rcx
  379482:	49 0f 43 ca          	cmovae %r10,%rcx
  379486:	4c 39 d9             	cmp    %r11,%rcx
  379489:	48 89 8c 24 a8 01 00 	mov    %rcx,0x1a8(%rsp)
  379490:	00 
  379491:	4c 0f 42 d9          	cmovb  %rcx,%r11
  379495:	4c 89 9c 24 30 01 00 	mov    %r11,0x130(%rsp)
  37949c:	00 
  37949d:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  3794a1:	c4 e2 7d 19 05 16 ba 	vbroadcastsd -0x2f45ea(%rip),%ymm0        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  3794a8:	d0 ff 
  3794aa:	c5 fd 11 84 24 d0 01 	vmovupd %ymm0,0x1d0(%rsp)
  3794b1:	00 00 
  3794b3:	c4 62 7d 19 05 34 b3 	vbroadcastsd -0x2f4ccc(%rip),%ymm8        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  3794ba:	d0 ff 
  3794bc:	c4 62 7d 19 0d f3 bb 	vbroadcastsd -0x2f440d(%rip),%ymm9        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  3794c3:	d0 ff 
  3794c5:	c4 62 7d 19 3d a2 cf 	vbroadcastsd -0x2f305e(%rip),%ymm15        # 86470 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0x188>
  3794cc:	d0 ff 
  3794ce:	c4 e2 7d 19 0d e9 b9 	vbroadcastsd -0x2f4617(%rip),%ymm1        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  3794d5:	d0 ff 
  3794d7:	c4 62 7d 19 2d 60 ca 	vbroadcastsd -0x2f35a0(%rip),%ymm13        # 85f40 <anon.890d649631ab6ab37a03cdc207a0d7b9.1026.llvm.3426226200983260467+0x958>
  3794de:	d0 ff 
  3794e0:	c4 62 7d 19 35 e7 d0 	vbroadcastsd -0x2f2f19(%rip),%ymm14        # 865d0 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0x2e8>
  3794e7:	d0 ff 
  3794e9:	c4 e2 7d 19 35 b6 ae 	vbroadcastsd -0x2f514a(%rip),%ymm6        # 843a8 <GCC_except_table0+0x884>
  3794f0:	d0 ff 
  3794f2:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  3794f9:	00 
  3794fa:	4c 8b 54 24 70       	mov    0x70(%rsp),%r10
  3794ff:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  379506:	00 
  379507:	49 8d 4c 24 01       	lea    0x1(%r12),%rcx
  37950c:	4c 8b b4 24 08 01 00 	mov    0x108(%rsp),%r14
  379513:	00 
  379514:	eb 22                	jmp    379538 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2038>
  379516:	49 8d 4c 24 01       	lea    0x1(%r12),%rcx
  37951b:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  379520:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  379527:	00 
  379528:	4c 89 d8             	mov    %r11,%rax
  37952b:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  379532:	00 
  379533:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  379538:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
  37953d:	4c 89 ed             	mov    %r13,%rbp
  379540:	49 89 c5             	mov    %rax,%r13
  379543:	4c 89 e7             	mov    %r12,%rdi
  379546:	49 89 cc             	mov    %rcx,%r12
  379549:	48 3b 8c 24 a8 00 00 	cmp    0xa8(%rsp),%rcx
  379550:	00 
  379551:	48 89 3c 24          	mov    %rdi,(%rsp)
  379555:	0f 83 39 01 00 00    	jae    379694 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2194>
  37955b:	49 89 d3             	mov    %rdx,%r11
  37955e:	48 39 f7             	cmp    %rsi,%rdi
  379561:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  379568:	00 
  379569:	48 8b 94 24 d8 00 00 	mov    0xd8(%rsp),%rdx
  379570:	00 
  379571:	0f 83 9e 2c 00 00    	jae    37c215 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4d15>
  379577:	48 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%rsi
  37957e:	00 
  37957f:	48 39 f7             	cmp    %rsi,%rdi
  379582:	0f 83 9d 2c 00 00    	jae    37c225 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4d25>
  379588:	48 8b 8c 24 a0 01 00 	mov    0x1a0(%rsp),%rcx
  37958f:	00 
  379590:	c4 e2 7d 19 24 f9    	vbroadcastsd (%rcx,%rdi,8),%ymm4
  379596:	48 8b 8c 24 98 01 00 	mov    0x198(%rsp),%rcx
  37959d:	00 
  37959e:	c4 62 7d 19 14 f9    	vbroadcastsd (%rcx,%rdi,8),%ymm10
  3795a4:	4d 85 c9             	test   %r9,%r9
  3795a7:	0f 84 d6 02 00 00    	je     379883 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2383>
  3795ad:	48 8b bc 24 c8 00 00 	mov    0xc8(%rsp),%rdi
  3795b4:	00 
  3795b5:	48 c1 ef 02          	shr    $0x2,%rdi
  3795b9:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  3795be:	31 c9                	xor    %ecx,%ecx
  3795c0:	31 f6                	xor    %esi,%esi
  3795c2:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  3795c7:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  3795cb:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  3795cf:	4c 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%r9
  3795d6:	00 
  3795d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  3795de:	00 00 
  3795e0:	48 39 f0             	cmp    %rsi,%rax
  3795e3:	0f 84 db 29 00 00    	je     37bfc4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4ac4>
  3795e9:	49 39 f2             	cmp    %rsi,%r10
  3795ec:	0f 84 8e 29 00 00    	je     37bf80 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4a80>
  3795f2:	48 39 74 24 78       	cmp    %rsi,0x78(%rsp)
  3795f7:	0f 84 af 29 00 00    	je     37bfac <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4aac>
  3795fd:	48 39 f2             	cmp    %rsi,%rdx
  379600:	0f 84 64 29 00 00    	je     37bf6a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4a6a>
  379606:	49 39 f1             	cmp    %rsi,%r9
  379609:	0f 84 87 29 00 00    	je     37bf96 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4a96>
  37960f:	48 39 f7             	cmp    %rsi,%rdi
  379612:	0f 84 c2 29 00 00    	je     37bfda <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4ada>
  379618:	c5 fd 10 5c 0d 00    	vmovupd 0x0(%rbp,%rcx,1),%ymm3
  37961e:	c5 e5 59 3c 0b       	vmulpd (%rbx,%rcx,1),%ymm3,%ymm7
  379623:	4c 8b 44 24 68       	mov    0x68(%rsp),%r8
  379628:	c4 c2 c5 b8 04 08    	vfmadd231pd (%r8,%rcx,1),%ymm7,%ymm0
  37962e:	4c 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%r8
  379635:	00 
  379636:	c4 42 c5 b8 24 08    	vfmadd231pd (%r8,%rcx,1),%ymm7,%ymm12
  37963c:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  379643:	00 
  379644:	c4 42 c5 b8 1c 08    	vfmadd231pd (%r8,%rcx,1),%ymm7,%ymm11
  37964a:	4c 8b 84 24 98 00 00 	mov    0x98(%rsp),%r8
  379651:	00 
  379652:	c4 c2 c5 b8 2c 08    	vfmadd231pd (%r8,%rcx,1),%ymm7,%ymm5
  379658:	4c 8b 84 24 88 00 00 	mov    0x88(%rsp),%r8
  37965f:	00 
  379660:	c4 c1 7d 10 3c 08    	vmovupd (%r8,%rcx,1),%ymm7
  379666:	c4 c2 dd a8 fa       	vfmadd213pd %ymm10,%ymm4,%ymm7
  37966b:	4c 8b 44 24 30       	mov    0x30(%rsp),%r8
  379670:	c4 c2 e5 a8 3c 08    	vfmadd213pd (%r8,%rcx,1),%ymm3,%ymm7
  379676:	48 ff c6             	inc    %rsi
  379679:	c4 c1 7d 11 7c 0d 00 	vmovupd %ymm7,0x0(%r13,%rcx,1)
  379680:	48 83 c1 20          	add    $0x20,%rcx
  379684:	48 39 74 24 28       	cmp    %rsi,0x28(%rsp)
  379689:	0f 85 51 ff ff ff    	jne    3795e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x20e0>
  37968f:	e9 01 02 00 00       	jmp    379895 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2395>
  379694:	4d 85 c9             	test   %r9,%r9
  379697:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
  37969e:	00 
  37969f:	0f 84 a9 00 00 00    	je     37974e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x224e>
  3796a5:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
  3796ac:	00 
  3796ad:	48 39 c7             	cmp    %rax,%rdi
  3796b0:	0f 84 89 2c 00 00    	je     37c33f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4e3f>
  3796b6:	49 39 c2             	cmp    %rax,%r10
  3796b9:	0f 84 6a 2c 00 00    	je     37c329 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4e29>
  3796bf:	48 39 44 24 78       	cmp    %rax,0x78(%rsp)
  3796c4:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  3796c9:	0f 84 42 2c 00 00    	je     37c311 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4e11>
  3796cf:	48 39 84 24 d8 00 00 	cmp    %rax,0xd8(%rsp)
  3796d6:	00 
  3796d7:	0f 84 19 2c 00 00    	je     37c2f6 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4df6>
  3796dd:	49 89 d3             	mov    %rdx,%r11
  3796e0:	48 89 ea             	mov    %rbp,%rdx
  3796e3:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  3796e7:	31 f6                	xor    %esi,%esi
  3796e9:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  3796ee:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  3796f2:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  3796f6:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
  3796fd:	00 
  3796fe:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  379705:	00 
  379706:	48 8b 9c 24 98 00 00 	mov    0x98(%rsp),%rbx
  37970d:	00 
  37970e:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  379713:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  379718:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  37971f:	00 
  379720:	c5 fd 10 5c 35 00    	vmovupd 0x0(%rbp,%rsi,1),%ymm3
  379726:	c5 e5 59 1c 32       	vmulpd (%rdx,%rsi,1),%ymm3,%ymm3
  37972b:	c4 e2 e5 b8 04 30    	vfmadd231pd (%rax,%rsi,1),%ymm3,%ymm0
  379731:	c4 62 e5 b8 14 37    	vfmadd231pd (%rdi,%rsi,1),%ymm3,%ymm10
  379737:	c4 c2 e5 b8 2c 30    	vfmadd231pd (%r8,%rsi,1),%ymm3,%ymm5
  37973d:	c4 e2 e5 b8 24 33    	vfmadd231pd (%rbx,%rsi,1),%ymm3,%ymm4
  379743:	48 83 c6 20          	add    $0x20,%rsi
  379747:	48 ff c9             	dec    %rcx
  37974a:	75 d4                	jne    379720 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2220>
  37974c:	eb 17                	jmp    379765 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2265>
  37974e:	49 89 d3             	mov    %rdx,%r11
  379751:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  379755:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  379759:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  37975e:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  379762:	48 89 ea             	mov    %rbp,%rdx
  379765:	48 89 d5             	mov    %rdx,%rbp
  379768:	c4 e3 7d 19 c3 01    	vextractf128 $0x1,%ymm0,%xmm3
  37976e:	c5 f9 58 c3          	vaddpd %xmm3,%xmm0,%xmm0
  379772:	c5 f9 c6 d8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm3
  379777:	c5 fb 58 c3          	vaddsd %xmm3,%xmm0,%xmm0
  37977b:	c4 63 7d 19 d3 01    	vextractf128 $0x1,%ymm10,%xmm3
  379781:	c5 a9 58 db          	vaddpd %xmm3,%xmm10,%xmm3
  379785:	c5 61 c6 d3 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm10
  37978a:	c5 2b 58 e3          	vaddsd %xmm3,%xmm10,%xmm12
  37978e:	c4 e3 7d 19 eb 01    	vextractf128 $0x1,%ymm5,%xmm3
  379794:	c5 d1 58 db          	vaddpd %xmm3,%xmm5,%xmm3
  379798:	c5 e1 c6 eb 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm5
  37979d:	c5 63 58 dd          	vaddsd %xmm5,%xmm3,%xmm11
  3797a1:	c4 e3 7d 19 e3 01    	vextractf128 $0x1,%ymm4,%xmm3
  3797a7:	c5 d9 58 db          	vaddpd %xmm3,%xmm4,%xmm3
  3797ab:	c5 e1 c6 e3 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm4
  3797b0:	c5 e3 58 ec          	vaddsd %xmm4,%xmm3,%xmm5
  3797b4:	4d 85 db             	test   %r11,%r11
  3797b7:	0f 84 ff 03 00 00    	je     379bbc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x26bc>
  3797bd:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  3797c4:	00 
  3797c5:	39 44 24 48          	cmp    %eax,0x48(%rsp)
  3797c9:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  3797d0:	00 
  3797d1:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  3797d6:	0f 84 c4 2b 00 00    	je     37c3a0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4ea0>
  3797dc:	39 84 24 b0 00 00 00 	cmp    %eax,0xb0(%rsp)
  3797e3:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
  3797e8:	0f 84 97 2b 00 00    	je     37c385 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4e85>
  3797ee:	39 84 24 90 00 00 00 	cmp    %eax,0x90(%rsp)
  3797f5:	0f 84 6f 2b 00 00    	je     37c36a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4e6a>
  3797fb:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
  379802:	00 
  379803:	39 44 24 40          	cmp    %eax,0x40(%rsp)
  379807:	0f 86 45 2b 00 00    	jbe    37c352 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4e52>
  37980d:	c4 a1 7b 10 1c cb    	vmovsd (%rbx,%r9,8),%xmm3
  379813:	c4 a1 63 59 5c cd 00 	vmulsd 0x0(%rbp,%r9,8),%xmm3,%xmm3
  37981a:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  37981f:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
  379826:	00 
  379827:	c4 e2 e1 b9 04 c6    	vfmadd231sd (%rsi,%rax,8),%xmm3,%xmm0
  37982d:	4c 89 ca             	mov    %r9,%rdx
  379830:	4c 8b 54 24 50       	mov    0x50(%rsp),%r10
  379835:	c4 22 e1 b9 24 d1    	vfmadd231sd (%rcx,%r10,8),%xmm3,%xmm12
  37983b:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  379842:	00 
  379843:	4c 8b 9c 24 40 01 00 	mov    0x140(%rsp),%r11
  37984a:	00 
  37984b:	c4 22 e1 b9 1c df    	vfmadd231sd (%rdi,%r11,8),%xmm3,%xmm11
  379851:	4c 8b 84 24 98 00 00 	mov    0x98(%rsp),%r8
  379858:	00 
  379859:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  379860:	00 
  379861:	c4 c2 e1 b9 2c c0    	vfmadd231sd (%r8,%rax,8),%xmm3,%xmm5
  379867:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
  37986c:	41 83 f9 01          	cmp    $0x1,%r9d
  379870:	0f 85 52 03 00 00    	jne    379bc8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x26c8>
  379876:	4c 8b 54 24 70       	mov    0x70(%rsp),%r10
  37987b:	4d 89 cb             	mov    %r9,%r11
  37987e:	e9 bd 03 00 00       	jmp    379c40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2740>
  379883:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  379887:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  37988b:	c4 41 19 57 e4       	vxorpd %xmm12,%xmm12,%xmm12
  379890:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  379895:	c4 e3 7d 19 c3 01    	vextractf128 $0x1,%ymm0,%xmm3
  37989b:	c5 f9 58 c3          	vaddpd %xmm3,%xmm0,%xmm0
  37989f:	c5 f9 c6 d8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm3
  3798a4:	c5 fb 58 c3          	vaddsd %xmm3,%xmm0,%xmm0
  3798a8:	c4 63 7d 19 e3 01    	vextractf128 $0x1,%ymm12,%xmm3
  3798ae:	c5 99 58 db          	vaddpd %xmm3,%xmm12,%xmm3
  3798b2:	c5 61 c6 e3 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm12
  3798b7:	c5 1b 58 e3          	vaddsd %xmm3,%xmm12,%xmm12
  3798bb:	c4 63 7d 19 db 01    	vextractf128 $0x1,%ymm11,%xmm3
  3798c1:	c5 a1 58 db          	vaddpd %xmm3,%xmm11,%xmm3
  3798c5:	c5 61 c6 db 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm11
  3798ca:	c5 23 58 db          	vaddsd %xmm3,%xmm11,%xmm11
  3798ce:	c4 e3 7d 19 eb 01    	vextractf128 $0x1,%ymm5,%xmm3
  3798d4:	c5 d1 58 db          	vaddpd %xmm3,%xmm5,%xmm3
  3798d8:	c5 e1 c6 eb 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm5
  3798dd:	c5 e3 58 ed          	vaddsd %xmm5,%xmm3,%xmm5
  3798e1:	4d 85 db             	test   %r11,%r11
  3798e4:	0f 84 56 03 00 00    	je     379c40 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2740>
  3798ea:	48 83 7c 24 48 00    	cmpq   $0x0,0x48(%rsp)
  3798f0:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  3798f5:	0f 84 02 29 00 00    	je     37c1fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4cfd>
  3798fb:	48 83 bc 24 b0 00 00 	cmpq   $0x0,0xb0(%rsp)
  379902:	00 00 
  379904:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
  37990b:	00 
  37990c:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  379911:	0f 84 cb 28 00 00    	je     37c1e2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4ce2>
  379917:	48 83 bc 24 90 00 00 	cmpq   $0x0,0x90(%rsp)
  37991e:	00 00 
  379920:	0f 84 a1 28 00 00    	je     37c1c7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4cc7>
  379926:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
  37992c:	0f 84 7d 28 00 00    	je     37c1af <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4caf>
  379932:	48 83 bc 24 b0 01 00 	cmpq   $0x0,0x1b0(%rsp)
  379939:	00 00 
  37993b:	0f 84 53 28 00 00    	je     37c194 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c94>
  379941:	89 cf                	mov    %ecx,%edi
  379943:	83 e7 03             	and    $0x3,%edi
  379946:	0f 84 35 28 00 00    	je     37c181 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c81>
  37994c:	49 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%r8
  379953:	ff ff 0f 
  379956:	4c 21 c1             	and    %r8,%rcx
  379959:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
  37995e:	c4 a1 7b 10 5c cd 00 	vmovsd 0x0(%rbp,%r9,8),%xmm3
  379965:	c4 a1 63 59 3c cb    	vmulsd (%rbx,%r9,8),%xmm3,%xmm7
  37996b:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  379972:	00 
  379973:	c4 e2 c1 b9 04 d0    	vfmadd231sd (%rax,%rdx,8),%xmm7,%xmm0
  379979:	4c 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%r8
  379980:	00 
  379981:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  379986:	c4 42 c1 b9 24 d0    	vfmadd231sd (%r8,%rdx,8),%xmm7,%xmm12
  37998c:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  379993:	00 
  379994:	48 8b 94 24 40 01 00 	mov    0x140(%rsp),%rdx
  37999b:	00 
  37999c:	c4 42 c1 b9 1c d0    	vfmadd231sd (%r8,%rdx,8),%xmm7,%xmm11
  3799a2:	4c 8b 84 24 98 00 00 	mov    0x98(%rsp),%r8
  3799a9:	00 
  3799aa:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  3799b1:	00 
  3799b2:	c4 c2 c1 b9 2c c0    	vfmadd231sd (%r8,%rax,8),%xmm7,%xmm5
  3799b8:	4c 8b 84 24 88 00 00 	mov    0x88(%rsp),%r8
  3799bf:	00 
  3799c0:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  3799c5:	c4 c1 7b 10 3c c0    	vmovsd (%r8,%rax,8),%xmm7
  3799cb:	c4 c2 d9 a9 fa       	vfmadd213sd %xmm10,%xmm4,%xmm7
  3799d0:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  3799d5:	c4 a2 e1 a9 3c c8    	vfmadd213sd (%rax,%r9,8),%xmm3,%xmm7
  3799db:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
  3799e0:	c4 c1 7b 11 7c cd 00 	vmovsd %xmm7,0x0(%r13,%rcx,8)
  3799e7:	41 83 fb 01          	cmp    $0x1,%r11d
  3799eb:	0f 84 54 02 00 00    	je     379c45 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2745>
  3799f1:	83 7c 24 48 01       	cmpl   $0x1,0x48(%rsp)
  3799f6:	0f 84 01 28 00 00    	je     37c1fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4cfd>
  3799fc:	83 bc 24 b0 00 00 00 	cmpl   $0x1,0xb0(%rsp)
  379a03:	01 
  379a04:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  379a09:	0f 84 d3 27 00 00    	je     37c1e2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4ce2>
  379a0f:	83 bc 24 90 00 00 00 	cmpl   $0x1,0x90(%rsp)
  379a16:	01 
  379a17:	0f 84 aa 27 00 00    	je     37c1c7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4cc7>
  379a1d:	83 7c 24 40 01       	cmpl   $0x1,0x40(%rsp)
  379a22:	0f 84 87 27 00 00    	je     37c1af <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4caf>
  379a28:	83 bc 24 b0 01 00 00 	cmpl   $0x1,0x1b0(%rsp)
  379a2f:	01 
  379a30:	0f 84 5e 27 00 00    	je     37c194 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c94>
  379a36:	83 ff 01             	cmp    $0x1,%edi
  379a39:	0f 84 42 27 00 00    	je     37c181 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c81>
  379a3f:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
  379a44:	c4 a1 7b 10 5c cd 08 	vmovsd 0x8(%rbp,%r9,8),%xmm3
  379a4b:	c4 a1 63 59 7c cb 08 	vmulsd 0x8(%rbx,%r9,8),%xmm3,%xmm7
  379a52:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  379a59:	00 
  379a5a:	c4 e2 c1 b9 44 d0 08 	vfmadd231sd 0x8(%rax,%rdx,8),%xmm7,%xmm0
  379a61:	4c 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%r8
  379a68:	00 
  379a69:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  379a6e:	c4 42 c1 b9 64 d0 08 	vfmadd231sd 0x8(%r8,%rdx,8),%xmm7,%xmm12
  379a75:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  379a7c:	00 
  379a7d:	48 8b 94 24 40 01 00 	mov    0x140(%rsp),%rdx
  379a84:	00 
  379a85:	c4 42 c1 b9 5c d0 08 	vfmadd231sd 0x8(%r8,%rdx,8),%xmm7,%xmm11
  379a8c:	4c 8b 84 24 98 00 00 	mov    0x98(%rsp),%r8
  379a93:	00 
  379a94:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  379a9b:	00 
  379a9c:	c4 c2 c1 b9 6c c0 08 	vfmadd231sd 0x8(%r8,%rax,8),%xmm7,%xmm5
  379aa3:	4c 8b 84 24 88 00 00 	mov    0x88(%rsp),%r8
  379aaa:	00 
  379aab:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  379ab0:	c4 c1 7b 10 7c c0 08 	vmovsd 0x8(%r8,%rax,8),%xmm7
  379ab7:	c4 c2 d9 a9 fa       	vfmadd213sd %xmm10,%xmm4,%xmm7
  379abc:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  379ac1:	c4 a2 e1 a9 7c c8 08 	vfmadd213sd 0x8(%rax,%r9,8),%xmm3,%xmm7
  379ac8:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
  379acd:	c4 c1 7b 11 7c cd 08 	vmovsd %xmm7,0x8(%r13,%rcx,8)
  379ad4:	41 83 fb 02          	cmp    $0x2,%r11d
  379ad8:	0f 84 67 01 00 00    	je     379c45 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2745>
  379ade:	83 7c 24 48 02       	cmpl   $0x2,0x48(%rsp)
  379ae3:	0f 84 14 27 00 00    	je     37c1fd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4cfd>
  379ae9:	83 bc 24 b0 00 00 00 	cmpl   $0x2,0xb0(%rsp)
  379af0:	02 
  379af1:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  379af6:	0f 84 e6 26 00 00    	je     37c1e2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4ce2>
  379afc:	83 bc 24 90 00 00 00 	cmpl   $0x2,0x90(%rsp)
  379b03:	02 
  379b04:	0f 84 bd 26 00 00    	je     37c1c7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4cc7>
  379b0a:	83 7c 24 40 02       	cmpl   $0x2,0x40(%rsp)
  379b0f:	0f 84 9a 26 00 00    	je     37c1af <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4caf>
  379b15:	83 bc 24 b0 01 00 00 	cmpl   $0x2,0x1b0(%rsp)
  379b1c:	02 
  379b1d:	0f 84 71 26 00 00    	je     37c194 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c94>
  379b23:	83 ff 02             	cmp    $0x2,%edi
  379b26:	0f 84 55 26 00 00    	je     37c181 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c81>
  379b2c:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  379b31:	c4 a1 7b 10 5c c5 10 	vmovsd 0x10(%rbp,%r8,8),%xmm3
  379b38:	c4 a1 63 59 7c c3 10 	vmulsd 0x10(%rbx,%r8,8),%xmm3,%xmm7
  379b3f:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  379b46:	00 
  379b47:	c4 e2 c1 b9 44 d0 10 	vfmadd231sd 0x10(%rax,%rdx,8),%xmm7,%xmm0
  379b4e:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
  379b55:	00 
  379b56:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  379b5b:	c4 62 c1 b9 64 d7 10 	vfmadd231sd 0x10(%rdi,%rdx,8),%xmm7,%xmm12
  379b62:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  379b69:	00 
  379b6a:	48 8b 94 24 40 01 00 	mov    0x140(%rsp),%rdx
  379b71:	00 
  379b72:	c4 62 c1 b9 5c d7 10 	vfmadd231sd 0x10(%rdi,%rdx,8),%xmm7,%xmm11
  379b79:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
  379b80:	00 
  379b81:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  379b88:	00 
  379b89:	c4 e2 c1 b9 6c c7 10 	vfmadd231sd 0x10(%rdi,%rax,8),%xmm7,%xmm5
  379b90:	48 8b bc 24 88 00 00 	mov    0x88(%rsp),%rdi
  379b97:	00 
  379b98:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  379b9d:	c4 62 d9 b9 54 c7 10 	vfmadd231sd 0x10(%rdi,%rax,8),%xmm4,%xmm10
  379ba4:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  379ba9:	c4 22 e1 a9 54 c0 10 	vfmadd213sd 0x10(%rax,%r8,8),%xmm3,%xmm10
  379bb0:	c4 41 7b 11 54 cd 10 	vmovsd %xmm10,0x10(%r13,%rcx,8)
  379bb7:	e9 89 00 00 00       	jmp    379c45 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2745>
  379bbc:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  379bc1:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
  379bc6:	eb 7d                	jmp    379c45 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2745>
  379bc8:	c5 fb 10 5c d3 08    	vmovsd 0x8(%rbx,%rdx,8),%xmm3
  379bce:	c5 e3 59 5c d5 08    	vmulsd 0x8(%rbp,%rdx,8),%xmm3,%xmm3
  379bd4:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
  379bdb:	00 
  379bdc:	c4 e2 e1 b9 44 fe 08 	vfmadd231sd 0x8(%rsi,%rdi,8),%xmm3,%xmm0
  379be3:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  379bea:	00 
  379beb:	c4 22 e1 b9 64 d1 08 	vfmadd231sd 0x8(%rcx,%r10,8),%xmm3,%xmm12
  379bf2:	c4 22 e1 b9 5c df 08 	vfmadd231sd 0x8(%rdi,%r11,8),%xmm3,%xmm11
  379bf9:	c4 c2 e1 b9 6c c0 08 	vfmadd231sd 0x8(%r8,%rax,8),%xmm3,%xmm5
  379c00:	41 83 f9 02          	cmp    $0x2,%r9d
  379c04:	74 30                	je     379c36 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2736>
  379c06:	c5 fb 10 5c d3 10    	vmovsd 0x10(%rbx,%rdx,8),%xmm3
  379c0c:	c5 e3 59 5c d5 10    	vmulsd 0x10(%rbp,%rdx,8),%xmm3,%xmm3
  379c12:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  379c19:	00 
  379c1a:	c4 e2 e1 b9 44 d6 10 	vfmadd231sd 0x10(%rsi,%rdx,8),%xmm3,%xmm0
  379c21:	c4 22 e1 b9 64 d1 10 	vfmadd231sd 0x10(%rcx,%r10,8),%xmm3,%xmm12
  379c28:	c4 22 e1 b9 5c df 10 	vfmadd231sd 0x10(%rdi,%r11,8),%xmm3,%xmm11
  379c2f:	c4 c2 e1 b9 6c c0 10 	vfmadd231sd 0x10(%r8,%rax,8),%xmm3,%xmm5
  379c36:	4c 8b 54 24 70       	mov    0x70(%rsp),%r10
  379c3b:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
  379c40:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  379c45:	48 8b 04 24          	mov    (%rsp),%rax
  379c49:	48 8d 3c 00          	lea    (%rax,%rax,1),%rdi
  379c4d:	48 39 f7             	cmp    %rsi,%rdi
  379c50:	0f 83 b7 24 00 00    	jae    37c10d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c0d>
  379c56:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
  379c5d:	00 
  379c5e:	48 8d 04 41          	lea    (%rcx,%rax,2),%rax
  379c62:	48 89 f9             	mov    %rdi,%rcx
  379c65:	48 c1 e1 04          	shl    $0x4,%rcx
  379c69:	4c 8b 44 24 58       	mov    0x58(%rsp),%r8
  379c6e:	c4 c1 7b 11 04 08    	vmovsd %xmm0,(%r8,%rcx,1)
  379c74:	c4 41 7b 11 64 08 08 	vmovsd %xmm12,0x8(%r8,%rcx,1)
  379c7b:	48 3b 84 24 10 01 00 	cmp    0x110(%rsp),%rax
  379c82:	00 
  379c83:	73 20                	jae    379ca5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x27a5>
  379c85:	48 ff c7             	inc    %rdi
  379c88:	48 39 f7             	cmp    %rsi,%rdi
  379c8b:	0f 83 a4 25 00 00    	jae    37c235 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4d35>
  379c91:	48 c1 e7 04          	shl    $0x4,%rdi
  379c95:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  379c9a:	c5 7b 11 1c 38       	vmovsd %xmm11,(%rax,%rdi,1)
  379c9f:	c5 fb 11 6c 38 08    	vmovsd %xmm5,0x8(%rax,%rdi,1)
  379ca5:	4c 3b a4 24 a8 00 00 	cmp    0xa8(%rsp),%r12
  379cac:	00 
  379cad:	0f 84 50 0d 00 00    	je     37aa03 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3503>
  379cb3:	48 8b b4 24 c8 00 00 	mov    0xc8(%rsp),%rsi
  379cba:	00 
  379cbb:	48 3b b4 24 50 01 00 	cmp    0x150(%rsp),%rsi
  379cc2:	00 
  379cc3:	0f 87 3f 22 00 00    	ja     37bf08 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4a08>
  379cc9:	48 39 74 24 38       	cmp    %rsi,0x38(%rsp)
  379cce:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  379cd3:	0f 85 62 d8 ff ff    	jne    37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  379cd9:	c5 6d c2 da 00       	vcmpeqpd %ymm2,%ymm2,%ymm11
  379cde:	4d 85 c9             	test   %r9,%r9
  379ce1:	0f 84 ce 00 00 00    	je     379db5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x28b5>
  379ce7:	31 c0                	xor    %eax,%eax
  379ce9:	4c 89 c9             	mov    %r9,%rcx
  379cec:	c5 7d 29 d8          	vmovapd %ymm11,%ymm0
  379cf0:	c4 e2 7d 19 1d 3f b2 	vbroadcastsd -0x2f4dc1(%rip),%ymm3        # 84f38 <anon.890d649631ab6ab37a03cdc207a0d7b9.203.llvm.3426226200983260467+0x10>
  379cf7:	d0 ff 
  379cf9:	c4 c1 7d 10 64 05 00 	vmovupd 0x0(%r13,%rax,1),%ymm4
  379d00:	c5 dd 54 eb          	vandpd %ymm3,%ymm4,%ymm5
  379d04:	c4 c1 75 58 3c 07    	vaddpd (%r15,%rax,1),%ymm1,%ymm7
  379d0a:	c4 c1 55 c2 ef 1e    	vcmpgt_oqpd %ymm15,%ymm5,%ymm5
  379d10:	c5 15 59 54 05 00    	vmulpd 0x0(%rbp,%rax,1),%ymm13,%ymm10
  379d16:	c5 15 59 e4          	vmulpd %ymm4,%ymm13,%ymm12
  379d1a:	c4 62 55 2f 54 05 00 	vmaskmovpd %ymm10,%ymm5,0x0(%rbp,%rax,1)
  379d21:	c4 c3 5d 4b e4 50    	vblendvpd %ymm5,%ymm12,%ymm4,%ymm4
  379d27:	c4 c1 7d 11 64 05 00 	vmovupd %ymm4,0x0(%r13,%rax,1)
  379d2e:	c4 41 7d 10 14 07    	vmovupd (%r15,%rax,1),%ymm10
  379d34:	c4 c2 55 2f 3c 07    	vmaskmovpd %ymm7,%ymm5,(%r15,%rax,1)
  379d3a:	c4 e3 2d 4b ff 50    	vblendvpd %ymm5,%ymm7,%ymm10,%ymm7
  379d40:	c5 45 c2 d2 11       	vcmplt_oqpd %ymm2,%ymm7,%ymm10
  379d45:	c5 45 c2 e1 11       	vcmplt_oqpd %ymm1,%ymm7,%ymm12
  379d4a:	c4 63 0d 4b e1 c0    	vblendvpd %ymm12,%ymm1,%ymm14,%ymm12
  379d50:	c4 42 6d 37 d2       	vpcmpgtq %ymm10,%ymm2,%ymm10
  379d55:	c4 41 2d df d4       	vpandn %ymm12,%ymm10,%ymm10
  379d5a:	c5 7d 10 24 03       	vmovupd (%rbx,%rax,1),%ymm12
  379d5f:	c4 43 1d 4b e2 50    	vblendvpd %ymm5,%ymm10,%ymm12,%ymm12
  379d65:	c4 62 55 2f 14 03    	vmaskmovpd %ymm10,%ymm5,(%rbx,%rax,1)
  379d6b:	c5 9d 59 ec          	vmulpd %ymm4,%ymm12,%ymm5
  379d6f:	c5 d5 54 eb          	vandpd %ymm3,%ymm5,%ymm5
  379d73:	c5 dd 54 db          	vandpd %ymm3,%ymm4,%ymm3
  379d77:	c5 e5 c2 de 12       	vcmple_oqpd %ymm6,%ymm3,%ymm3
  379d7c:	c5 a5 54 db          	vandpd %ymm3,%ymm11,%ymm3
  379d80:	c5 d5 c2 e2 00       	vcmpeqpd %ymm2,%ymm5,%ymm4
  379d85:	c4 41 55 c2 d0 1d    	vcmpge_oqpd %ymm8,%ymm5,%ymm10
  379d8b:	c4 c1 55 c2 e9 12    	vcmple_oqpd %ymm9,%ymm5,%ymm5
  379d91:	c5 ad 54 ed          	vandpd %ymm5,%ymm10,%ymm5
  379d95:	c5 d5 56 e4          	vorpd  %ymm4,%ymm5,%ymm4
  379d99:	c5 65 54 dc          	vandpd %ymm4,%ymm3,%ymm11
  379d9d:	c5 c5 c2 da 1d       	vcmpge_oqpd %ymm2,%ymm7,%ymm3
  379da2:	c5 fd 54 c3          	vandpd %ymm3,%ymm0,%ymm0
  379da6:	48 83 c0 20          	add    $0x20,%rax
  379daa:	48 ff c9             	dec    %rcx
  379dad:	0f 85 3d ff ff ff    	jne    379cf0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x27f0>
  379db3:	eb 04                	jmp    379db9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x28b9>
  379db5:	c5 7d 29 d8          	vmovapd %ymm11,%ymm0
  379db9:	4d 85 db             	test   %r11,%r11
  379dbc:	0f 84 76 01 00 00    	je     379f38 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2a38>
  379dc2:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  379dc7:	c5 fa 7e 64 f5 00    	vmovq  0x0(%rbp,%rsi,8),%xmm4
  379dcd:	c4 e1 f9 7e e0       	vmovq  %xmm4,%rax
  379dd2:	48 c1 e8 34          	shr    $0x34,%rax
  379dd6:	25 ff 07 00 00       	and    $0x7ff,%eax
  379ddb:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  379de0:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  379de4:	0f 87 51 d7 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  379dea:	c4 c1 7a 7e 6c f5 00 	vmovq  0x0(%r13,%rsi,8),%xmm5
  379df1:	c4 e1 f9 7e e8       	vmovq  %xmm5,%rax
  379df6:	48 c1 e8 34          	shr    $0x34,%rax
  379dfa:	25 ff 07 00 00       	and    $0x7ff,%eax
  379dff:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  379e04:	0f 87 31 d7 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  379e0a:	c5 d1 db 1d 7e d2 d0 	vpand  -0x2f2d82(%rip),%xmm5,%xmm3        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  379e11:	ff 
  379e12:	c5 f9 2e 1d 56 c6 d0 	vucomisd -0x2f39aa(%rip),%xmm3        # 86470 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0x188>
  379e19:	ff 
  379e1a:	4c 89 e1             	mov    %r12,%rcx
  379e1d:	4c 89 ea             	mov    %r13,%rdx
  379e20:	0f 86 1e 01 00 00    	jbe    379f44 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2a44>
  379e26:	c4 41 7b 10 24 f7    	vmovsd (%r15,%rsi,8),%xmm12
  379e2c:	c5 1b 58 15 8c b0 d0 	vaddsd -0x2f4f74(%rip),%xmm12,%xmm10        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  379e33:	ff 
  379e34:	c4 61 f9 7e d0       	vmovq  %xmm10,%rax
  379e39:	48 c1 e8 34          	shr    $0x34,%rax
  379e3d:	25 ff 07 00 00       	and    $0x7ff,%eax
  379e42:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  379e47:	0f 87 ee d6 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  379e4d:	31 c0                	xor    %eax,%eax
  379e4f:	c4 41 79 2e d4       	vucomisd %xmm12,%xmm10
  379e54:	75 06                	jne    379e5c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x295c>
  379e56:	0f 8b e1 d6 ff ff    	jnp    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  379e5c:	c5 a9 54 1d 2c d2 d0 	vandpd -0x2f2dd4(%rip),%xmm10,%xmm3        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  379e63:	ff 
  379e64:	c5 f9 2e 1d 34 a8 d0 	vucomisd -0x2f57cc(%rip),%xmm3        # 846a0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x10>
  379e6b:	ff 
  379e6c:	0f 87 cb d6 ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  379e72:	c5 fb 10 3d c6 c0 d0 	vmovsd -0x2f3f3a(%rip),%xmm7        # 85f40 <anon.890d649631ab6ab37a03cdc207a0d7b9.1026.llvm.3426226200983260467+0x958>
  379e79:	ff 
  379e7a:	c5 d3 59 ef          	vmulsd %xmm7,%xmm5,%xmm5
  379e7e:	c5 d1 54 1d 0a d2 d0 	vandpd -0x2f2df6(%rip),%xmm5,%xmm3        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  379e85:	ff 
  379e86:	c5 f9 2e 1d 62 a9 d0 	vucomisd -0x2f569e(%rip),%xmm3        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  379e8d:	ff 
  379e8e:	0f 82 a7 d6 ff ff    	jb     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  379e94:	c5 db 59 df          	vmulsd %xmm7,%xmm4,%xmm3
  379e98:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  379e9d:	c5 fb 11 5c c5 00    	vmovsd %xmm3,0x0(%rbp,%rax,8)
  379ea3:	c5 fb 11 2c c2       	vmovsd %xmm5,(%rdx,%rax,8)
  379ea8:	c4 41 7b 11 14 c7    	vmovsd %xmm10,(%r15,%rax,8)
  379eae:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  379eb2:	c4 c1 79 2e e2       	vucomisd %xmm10,%xmm4
  379eb7:	77 6a                	ja     379f23 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2a23>
  379eb9:	c5 ab c2 1d fe af d0 	vcmpltsd -0x2f5002(%rip),%xmm10,%xmm3        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  379ec0:	ff 01 
  379ec2:	c5 fb 12 25 06 c7 d0 	vmovddup -0x2f38fa(%rip),%xmm4        # 865d0 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0x2e8>
  379ec9:	ff 
  379eca:	c4 e3 59 4b 25 fc 12 	vblendvpd %xmm3,-0x2eed04(%rip),%xmm4,%xmm4        # 8b1d0 <anon.f9efbf6a85811f011f9cd7c053310384.235.llvm.15014775230106348234+0x11f0>
  379ed1:	d1 ff 30 
  379ed4:	c5 d3 59 ec          	vmulsd %xmm4,%xmm5,%xmm5
  379ed8:	c4 e1 f9 7e e8       	vmovq  %xmm5,%rax
  379edd:	48 c1 e8 34          	shr    $0x34,%rax
  379ee1:	25 ff 07 00 00       	and    $0x7ff,%eax
  379ee6:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  379eeb:	0f 87 4a d6 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  379ef1:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  379ef5:	c5 f9 2e eb          	vucomisd %xmm3,%xmm5
  379ef9:	75 02                	jne    379efd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x29fd>
  379efb:	7b 26                	jnp    379f23 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2a23>
  379efd:	c5 d1 54 1d 8b d1 d0 	vandpd -0x2f2e75(%rip),%xmm5,%xmm3        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  379f04:	ff 
  379f05:	31 c0                	xor    %eax,%eax
  379f07:	c5 f9 2e 1d e1 a8 d0 	vucomisd -0x2f571f(%rip),%xmm3        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  379f0e:	ff 
  379f0f:	0f 82 28 d6 ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  379f15:	c5 f9 2e 1d 9b b1 d0 	vucomisd -0x2f4e65(%rip),%xmm3        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  379f1c:	ff 
  379f1d:	0f 87 1a d6 ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  379f23:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  379f28:	c5 fb 11 24 f3       	vmovsd %xmm4,(%rbx,%rsi,8)
  379f2d:	c5 fb 10 2c f2       	vmovsd (%rdx,%rsi,8),%xmm5
  379f32:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  379f36:	eb 11                	jmp    379f49 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2a49>
  379f38:	40 b6 01             	mov    $0x1,%sil
  379f3b:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  379f3f:	e9 53 04 00 00       	jmp    37a397 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2e97>
  379f44:	c5 fb 10 24 f3       	vmovsd (%rbx,%rsi,8),%xmm4
  379f49:	c5 db 59 e5          	vmulsd %xmm5,%xmm4,%xmm4
  379f4d:	c4 e1 f9 7e e0       	vmovq  %xmm4,%rax
  379f52:	48 c1 e8 34          	shr    $0x34,%rax
  379f56:	25 ff 07 00 00       	and    $0x7ff,%eax
  379f5b:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  379f60:	0f 87 d5 d5 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  379f66:	c5 f9 2e e7          	vucomisd %xmm7,%xmm4
  379f6a:	75 02                	jne    379f6e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2a6e>
  379f6c:	7b 2a                	jnp    379f98 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2a98>
  379f6e:	c5 d9 54 1d 1a d1 d0 	vandpd -0x2f2ee6(%rip),%xmm4,%xmm3        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  379f75:	ff 
  379f76:	31 c0                	xor    %eax,%eax
  379f78:	c5 f9 2e 1d 70 a8 d0 	vucomisd -0x2f5790(%rip),%xmm3        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  379f7f:	ff 
  379f80:	0f 82 b7 d5 ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  379f86:	c5 fb 10 25 2a b1 d0 	vmovsd -0x2f4ed6(%rip),%xmm4        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  379f8d:	ff 
  379f8e:	c5 f9 2e e3          	vucomisd %xmm3,%xmm4
  379f92:	0f 82 a5 d5 ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  379f98:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  379f9d:	c4 c1 7b 10 24 c7    	vmovsd (%r15,%rax,8),%xmm4
  379fa3:	c5 f9 2e e7          	vucomisd %xmm7,%xmm4
  379fa7:	40 0f 93 c6          	setae  %sil
  379fab:	83 7c 24 08 01       	cmpl   $0x1,0x8(%rsp)
  379fb0:	49 89 cc             	mov    %rcx,%r12
  379fb3:	49 89 d5             	mov    %rdx,%r13
  379fb6:	4c 8b 54 24 70       	mov    0x70(%rsp),%r10
  379fbb:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  379fc0:	0f 84 d1 03 00 00    	je     37a397 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2e97>
  379fc6:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  379fcb:	c5 fa 7e 6c f5 08    	vmovq  0x8(%rbp,%rsi,8),%xmm5
  379fd1:	c4 e1 f9 7e e8       	vmovq  %xmm5,%rax
  379fd6:	48 c1 e8 34          	shr    $0x34,%rax
  379fda:	25 ff 07 00 00       	and    $0x7ff,%eax
  379fdf:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  379fe4:	0f 87 51 d5 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  379fea:	c4 41 7a 7e 54 f5 08 	vmovq  0x8(%r13,%rsi,8),%xmm10
  379ff1:	c4 61 f9 7e d0       	vmovq  %xmm10,%rax
  379ff6:	48 c1 e8 34          	shr    $0x34,%rax
  379ffa:	25 ff 07 00 00       	and    $0x7ff,%eax
  379fff:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37a004:	0f 87 31 d5 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37a00a:	c5 a9 db 1d 7e d0 d0 	vpand  -0x2f2f82(%rip),%xmm10,%xmm3        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a011:	ff 
  37a012:	c5 f9 2e 1d 56 c4 d0 	vucomisd -0x2f3baa(%rip),%xmm3        # 86470 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0x188>
  37a019:	ff 
  37a01a:	0f 86 16 01 00 00    	jbe    37a136 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2c36>
  37a020:	c4 c1 7b 10 5c f7 08 	vmovsd 0x8(%r15,%rsi,8),%xmm3
  37a027:	c5 63 58 25 91 ae d0 	vaddsd -0x2f516f(%rip),%xmm3,%xmm12        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  37a02e:	ff 
  37a02f:	c4 61 f9 7e e0       	vmovq  %xmm12,%rax
  37a034:	48 c1 e8 34          	shr    $0x34,%rax
  37a038:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a03d:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37a042:	0f 87 f3 d4 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37a048:	31 c0                	xor    %eax,%eax
  37a04a:	c5 79 2e e3          	vucomisd %xmm3,%xmm12
  37a04e:	75 06                	jne    37a056 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2b56>
  37a050:	0f 8b e7 d4 ff ff    	jnp    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37a056:	c5 99 54 1d 32 d0 d0 	vandpd -0x2f2fce(%rip),%xmm12,%xmm3        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a05d:	ff 
  37a05e:	c5 f9 2e 1d 3a a6 d0 	vucomisd -0x2f59c6(%rip),%xmm3        # 846a0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x10>
  37a065:	ff 
  37a066:	0f 87 d1 d4 ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37a06c:	c5 fb 10 3d cc be d0 	vmovsd -0x2f4134(%rip),%xmm7        # 85f40 <anon.890d649631ab6ab37a03cdc207a0d7b9.1026.llvm.3426226200983260467+0x958>
  37a073:	ff 
  37a074:	c5 2b 59 d7          	vmulsd %xmm7,%xmm10,%xmm10
  37a078:	c5 a9 54 1d 10 d0 d0 	vandpd -0x2f2ff0(%rip),%xmm10,%xmm3        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a07f:	ff 
  37a080:	c5 f9 2e 1d 68 a7 d0 	vucomisd -0x2f5898(%rip),%xmm3        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37a087:	ff 
  37a088:	0f 82 ad d4 ff ff    	jb     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37a08e:	c5 d3 59 df          	vmulsd %xmm7,%xmm5,%xmm3
  37a092:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  37a097:	c5 fb 11 5c c5 08    	vmovsd %xmm3,0x8(%rbp,%rax,8)
  37a09d:	c5 7b 11 54 c2 08    	vmovsd %xmm10,0x8(%rdx,%rax,8)
  37a0a3:	c4 41 7b 11 64 c7 08 	vmovsd %xmm12,0x8(%r15,%rax,8)
  37a0aa:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  37a0ae:	c4 c1 79 2e ec       	vucomisd %xmm12,%xmm5
  37a0b3:	77 6a                	ja     37a11f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2c1f>
  37a0b5:	c5 9b c2 1d 02 ae d0 	vcmpltsd -0x2f51fe(%rip),%xmm12,%xmm3        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  37a0bc:	ff 01 
  37a0be:	c5 fb 12 2d 0a c5 d0 	vmovddup -0x2f3af6(%rip),%xmm5        # 865d0 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0x2e8>
  37a0c5:	ff 
  37a0c6:	c4 e3 51 4b 2d 00 11 	vblendvpd %xmm3,-0x2eef00(%rip),%xmm5,%xmm5        # 8b1d0 <anon.f9efbf6a85811f011f9cd7c053310384.235.llvm.15014775230106348234+0x11f0>
  37a0cd:	d1 ff 30 
  37a0d0:	c5 2b 59 d5          	vmulsd %xmm5,%xmm10,%xmm10
  37a0d4:	c4 61 f9 7e d0       	vmovq  %xmm10,%rax
  37a0d9:	48 c1 e8 34          	shr    $0x34,%rax
  37a0dd:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a0e2:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37a0e7:	0f 87 4e d4 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37a0ed:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  37a0f1:	c5 79 2e d3          	vucomisd %xmm3,%xmm10
  37a0f5:	75 02                	jne    37a0f9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2bf9>
  37a0f7:	7b 26                	jnp    37a11f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2c1f>
  37a0f9:	c5 a9 54 1d 8f cf d0 	vandpd -0x2f3071(%rip),%xmm10,%xmm3        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a100:	ff 
  37a101:	31 c0                	xor    %eax,%eax
  37a103:	c5 f9 2e 1d e5 a6 d0 	vucomisd -0x2f591b(%rip),%xmm3        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37a10a:	ff 
  37a10b:	0f 82 2c d4 ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37a111:	c5 f9 2e 1d 9f af d0 	vucomisd -0x2f5061(%rip),%xmm3        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  37a118:	ff 
  37a119:	0f 87 1e d4 ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37a11f:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  37a124:	c5 fb 11 6c f3 08    	vmovsd %xmm5,0x8(%rbx,%rsi,8)
  37a12a:	c5 7b 10 54 f2 08    	vmovsd 0x8(%rdx,%rsi,8),%xmm10
  37a130:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  37a134:	eb 06                	jmp    37a13c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2c3c>
  37a136:	c5 fb 10 6c f3 08    	vmovsd 0x8(%rbx,%rsi,8),%xmm5
  37a13c:	c5 ab 59 ed          	vmulsd %xmm5,%xmm10,%xmm5
  37a140:	c4 e1 f9 7e e8       	vmovq  %xmm5,%rax
  37a145:	48 c1 e8 34          	shr    $0x34,%rax
  37a149:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a14e:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37a153:	0f 87 e2 d3 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37a159:	c5 f9 2e ef          	vucomisd %xmm7,%xmm5
  37a15d:	75 02                	jne    37a161 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2c61>
  37a15f:	7b 2a                	jnp    37a18b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2c8b>
  37a161:	c5 d1 54 1d 27 cf d0 	vandpd -0x2f30d9(%rip),%xmm5,%xmm3        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a168:	ff 
  37a169:	31 c0                	xor    %eax,%eax
  37a16b:	c5 f9 2e 1d 7d a6 d0 	vucomisd -0x2f5983(%rip),%xmm3        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37a172:	ff 
  37a173:	0f 82 c4 d3 ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37a179:	c5 fb 10 2d 37 af d0 	vmovsd -0x2f50c9(%rip),%xmm5        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  37a180:	ff 
  37a181:	c5 f9 2e eb          	vucomisd %xmm3,%xmm5
  37a185:	0f 82 b2 d3 ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37a18b:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  37a190:	c4 c1 43 c2 5c ff 08 	vcmplesd 0x8(%r15,%rdi,8),%xmm7,%xmm3
  37a197:	02 
  37a198:	c5 c3 c2 e4 02       	vcmplesd %xmm4,%xmm7,%xmm4
  37a19d:	c5 e1 54 dc          	vandpd %xmm4,%xmm3,%xmm3
  37a1a1:	c5 f9 7e de          	vmovd  %xmm3,%esi
  37a1a5:	83 7c 24 08 02       	cmpl   $0x2,0x8(%rsp)
  37a1aa:	0f 84 d7 01 00 00    	je     37a387 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2e87>
  37a1b0:	c5 fa 7e 64 fd 10    	vmovq  0x10(%rbp,%rdi,8),%xmm4
  37a1b6:	c4 e1 f9 7e e0       	vmovq  %xmm4,%rax
  37a1bb:	48 c1 e8 34          	shr    $0x34,%rax
  37a1bf:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a1c4:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37a1c9:	0f 87 6c d3 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37a1cf:	c5 fa 7e 6c fa 10    	vmovq  0x10(%rdx,%rdi,8),%xmm5
  37a1d5:	c4 e1 f9 7e e8       	vmovq  %xmm5,%rax
  37a1da:	48 c1 e8 34          	shr    $0x34,%rax
  37a1de:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a1e3:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37a1e8:	0f 87 4d d3 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37a1ee:	c5 d1 db 1d 9a ce d0 	vpand  -0x2f3166(%rip),%xmm5,%xmm3        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a1f5:	ff 
  37a1f6:	c5 f9 2e 1d 72 c2 d0 	vucomisd -0x2f3d8e(%rip),%xmm3        # 86470 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0x188>
  37a1fd:	ff 
  37a1fe:	0f 86 16 01 00 00    	jbe    37a31a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2e1a>
  37a204:	c4 c1 7b 10 5c ff 10 	vmovsd 0x10(%r15,%rdi,8),%xmm3
  37a20b:	c5 63 58 15 ad ac d0 	vaddsd -0x2f5353(%rip),%xmm3,%xmm10        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  37a212:	ff 
  37a213:	c4 61 f9 7e d0       	vmovq  %xmm10,%rax
  37a218:	48 c1 e8 34          	shr    $0x34,%rax
  37a21c:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a221:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37a226:	0f 87 0f d3 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37a22c:	31 c0                	xor    %eax,%eax
  37a22e:	c5 79 2e d3          	vucomisd %xmm3,%xmm10
  37a232:	75 06                	jne    37a23a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2d3a>
  37a234:	0f 8b 03 d3 ff ff    	jnp    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37a23a:	c5 a9 54 1d 4e ce d0 	vandpd -0x2f31b2(%rip),%xmm10,%xmm3        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a241:	ff 
  37a242:	c5 f9 2e 1d 56 a4 d0 	vucomisd -0x2f5baa(%rip),%xmm3        # 846a0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x10>
  37a249:	ff 
  37a24a:	0f 87 ed d2 ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37a250:	c5 fb 10 3d e8 bc d0 	vmovsd -0x2f4318(%rip),%xmm7        # 85f40 <anon.890d649631ab6ab37a03cdc207a0d7b9.1026.llvm.3426226200983260467+0x958>
  37a257:	ff 
  37a258:	c5 d3 59 ef          	vmulsd %xmm7,%xmm5,%xmm5
  37a25c:	c5 d1 54 1d 2c ce d0 	vandpd -0x2f31d4(%rip),%xmm5,%xmm3        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a263:	ff 
  37a264:	c5 f9 2e 1d 84 a5 d0 	vucomisd -0x2f5a7c(%rip),%xmm3        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37a26b:	ff 
  37a26c:	0f 82 c9 d2 ff ff    	jb     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37a272:	c5 db 59 df          	vmulsd %xmm7,%xmm4,%xmm3
  37a276:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  37a27b:	c5 fb 11 5c c5 10    	vmovsd %xmm3,0x10(%rbp,%rax,8)
  37a281:	c5 fb 11 6c c2 10    	vmovsd %xmm5,0x10(%rdx,%rax,8)
  37a287:	c4 41 7b 11 54 c7 10 	vmovsd %xmm10,0x10(%r15,%rax,8)
  37a28e:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  37a292:	c4 c1 79 2e e2       	vucomisd %xmm10,%xmm4
  37a297:	77 6a                	ja     37a303 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2e03>
  37a299:	c5 ab c2 1d 1e ac d0 	vcmpltsd -0x2f53e2(%rip),%xmm10,%xmm3        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  37a2a0:	ff 01 
  37a2a2:	c5 fb 12 25 26 c3 d0 	vmovddup -0x2f3cda(%rip),%xmm4        # 865d0 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0x2e8>
  37a2a9:	ff 
  37a2aa:	c4 e3 59 4b 25 1c 0f 	vblendvpd %xmm3,-0x2ef0e4(%rip),%xmm4,%xmm4        # 8b1d0 <anon.f9efbf6a85811f011f9cd7c053310384.235.llvm.15014775230106348234+0x11f0>
  37a2b1:	d1 ff 30 
  37a2b4:	c5 d3 59 ec          	vmulsd %xmm4,%xmm5,%xmm5
  37a2b8:	c4 e1 f9 7e e8       	vmovq  %xmm5,%rax
  37a2bd:	48 c1 e8 34          	shr    $0x34,%rax
  37a2c1:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a2c6:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37a2cb:	0f 87 6a d2 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37a2d1:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  37a2d5:	c5 f9 2e eb          	vucomisd %xmm3,%xmm5
  37a2d9:	75 02                	jne    37a2dd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2ddd>
  37a2db:	7b 26                	jnp    37a303 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2e03>
  37a2dd:	c5 d1 54 1d ab cd d0 	vandpd -0x2f3255(%rip),%xmm5,%xmm3        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a2e4:	ff 
  37a2e5:	31 c0                	xor    %eax,%eax
  37a2e7:	c5 f9 2e 1d 01 a5 d0 	vucomisd -0x2f5aff(%rip),%xmm3        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37a2ee:	ff 
  37a2ef:	0f 82 48 d2 ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37a2f5:	c5 f9 2e 1d bb ad d0 	vucomisd -0x2f5245(%rip),%xmm3        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  37a2fc:	ff 
  37a2fd:	0f 87 3a d2 ff ff    	ja     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37a303:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  37a308:	c5 fb 11 64 fb 10    	vmovsd %xmm4,0x10(%rbx,%rdi,8)
  37a30e:	c5 fb 10 6c fa 10    	vmovsd 0x10(%rdx,%rdi,8),%xmm5
  37a314:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  37a318:	eb 06                	jmp    37a320 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2e20>
  37a31a:	c5 fb 10 64 fb 10    	vmovsd 0x10(%rbx,%rdi,8),%xmm4
  37a320:	c5 db 59 e5          	vmulsd %xmm5,%xmm4,%xmm4
  37a324:	c4 e1 f9 7e e0       	vmovq  %xmm4,%rax
  37a329:	48 c1 e8 34          	shr    $0x34,%rax
  37a32d:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a332:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37a337:	0f 87 fe d1 ff ff    	ja     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37a33d:	c5 f9 2e e7          	vucomisd %xmm7,%xmm4
  37a341:	75 02                	jne    37a345 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2e45>
  37a343:	7b 2a                	jnp    37a36f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2e6f>
  37a345:	c5 d9 54 1d 43 cd d0 	vandpd -0x2f32bd(%rip),%xmm4,%xmm3        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a34c:	ff 
  37a34d:	31 c0                	xor    %eax,%eax
  37a34f:	c5 f9 2e 1d 99 a4 d0 	vucomisd -0x2f5b67(%rip),%xmm3        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37a356:	ff 
  37a357:	0f 82 e0 d1 ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37a35d:	c5 fb 10 25 53 ad d0 	vmovsd -0x2f52ad(%rip),%xmm4        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  37a364:	ff 
  37a365:	c5 f9 2e e3          	vucomisd %xmm3,%xmm4
  37a369:	0f 82 ce d1 ff ff    	jb     37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37a36f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  37a374:	c4 c1 7b 10 5c c7 10 	vmovsd 0x10(%r15,%rax,8),%xmm3
  37a37b:	c5 f9 2e df          	vucomisd %xmm7,%xmm3
  37a37f:	0f 93 c0             	setae  %al
  37a382:	40 20 f0             	and    %sil,%al
  37a385:	89 c6                	mov    %eax,%esi
  37a387:	49 89 cc             	mov    %rcx,%r12
  37a38a:	49 89 d5             	mov    %rdx,%r13
  37a38d:	4c 8b 54 24 70       	mov    0x70(%rsp),%r10
  37a392:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  37a397:	c4 c2 6d 37 db       	vpcmpgtq %ymm11,%ymm2,%ymm3
  37a39c:	c5 7e 6f 94 24 d0 01 	vmovdqu 0x1d0(%rsp),%ymm10
  37a3a3:	00 00 
  37a3a5:	c5 ad db db          	vpand  %ymm3,%ymm10,%ymm3
  37a3a9:	c4 e3 7d 39 dc 01    	vextracti128 $0x1,%ymm3,%xmm4
  37a3af:	c5 e1 5d dc          	vminpd %xmm4,%xmm3,%xmm3
  37a3b3:	c5 e1 c6 e3 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm4
  37a3b8:	c5 e3 5d dc          	vminsd %xmm4,%xmm3,%xmm3
  37a3bc:	c5 f9 2e df          	vucomisd %xmm7,%xmm3
  37a3c0:	0f 86 75 d1 ff ff    	jbe    37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37a3c6:	c4 e2 6d 37 c0       	vpcmpgtq %ymm0,%ymm2,%ymm0
  37a3cb:	c5 ad db c0          	vpand  %ymm0,%ymm10,%ymm0
  37a3cf:	c4 e3 7d 39 c3 01    	vextracti128 $0x1,%ymm0,%xmm3
  37a3d5:	c5 f9 5d c3          	vminpd %xmm3,%xmm0,%xmm0
  37a3d9:	c5 f9 c6 d8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm3
  37a3de:	c5 fb 5d c3          	vminsd %xmm3,%xmm0,%xmm0
  37a3e2:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  37a3e6:	0f 97 c0             	seta   %al
  37a3e9:	40 84 f0             	test   %sil,%al
  37a3ec:	4c 8b 5c 24 30       	mov    0x30(%rsp),%r11
  37a3f1:	0f 84 1f f1 ff ff    	je     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a3f7:	4d 85 c9             	test   %r9,%r9
  37a3fa:	0f 84 c2 00 00 00    	je     37a4c2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2fc2>
  37a400:	4c 89 c8             	mov    %r9,%rax
  37a403:	31 c9                	xor    %ecx,%ecx
  37a405:	c4 c1 7d 10 04 0f    	vmovupd (%r15,%rcx,1),%ymm0
  37a40b:	c5 fd c2 c2 1d       	vcmpge_oqpd %ymm2,%ymm0,%ymm0
  37a410:	c4 e2 6d 37 c0       	vpcmpgtq %ymm0,%ymm2,%ymm0
  37a415:	c5 ad db c0          	vpand  %ymm0,%ymm10,%ymm0
  37a419:	c4 e3 7d 39 c3 01    	vextracti128 $0x1,%ymm0,%xmm3
  37a41f:	c5 f9 5d c3          	vminpd %xmm3,%xmm0,%xmm0
  37a423:	c5 f9 c6 d8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm3
  37a428:	c5 fb 5d c3          	vminsd %xmm3,%xmm0,%xmm0
  37a42c:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  37a430:	0f 86 e0 f0 ff ff    	jbe    379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a436:	c5 fd 10 04 0b       	vmovupd (%rbx,%rcx,1),%ymm0
  37a43b:	c5 fd 59 5c 0d 00    	vmulpd 0x0(%rbp,%rcx,1),%ymm0,%ymm3
  37a441:	c4 c1 7d 59 44 0d 00 	vmulpd 0x0(%r13,%rcx,1),%ymm0,%ymm0
  37a448:	c4 e2 7d 19 25 e7 aa 	vbroadcastsd -0x2f5519(%rip),%ymm4        # 84f38 <anon.890d649631ab6ab37a03cdc207a0d7b9.203.llvm.3426226200983260467+0x10>
  37a44f:	d0 ff 
  37a451:	c5 e5 54 dc          	vandpd %ymm4,%ymm3,%ymm3
  37a455:	c5 fd 54 c4          	vandpd %ymm4,%ymm0,%ymm0
  37a459:	c5 e5 c2 e2 00       	vcmpeqpd %ymm2,%ymm3,%ymm4
  37a45e:	c4 c1 65 c2 e8 1d    	vcmpge_oqpd %ymm8,%ymm3,%ymm5
  37a464:	c4 c1 65 c2 d9 12    	vcmple_oqpd %ymm9,%ymm3,%ymm3
  37a46a:	c5 e5 54 dd          	vandpd %ymm5,%ymm3,%ymm3
  37a46e:	c5 e5 56 dc          	vorpd  %ymm4,%ymm3,%ymm3
  37a472:	c5 fd c2 e2 00       	vcmpeqpd %ymm2,%ymm0,%ymm4
  37a477:	c4 c1 7d c2 e8 1d    	vcmpge_oqpd %ymm8,%ymm0,%ymm5
  37a47d:	c4 c1 7d c2 c1 12    	vcmple_oqpd %ymm9,%ymm0,%ymm0
  37a483:	c5 fd 54 c5          	vandpd %ymm5,%ymm0,%ymm0
  37a487:	c5 fd 56 c4          	vorpd  %ymm4,%ymm0,%ymm0
  37a48b:	c5 fd 54 c3          	vandpd %ymm3,%ymm0,%ymm0
  37a48f:	c4 e2 6d 37 c0       	vpcmpgtq %ymm0,%ymm2,%ymm0
  37a494:	c5 ad db c0          	vpand  %ymm0,%ymm10,%ymm0
  37a498:	c4 e3 7d 39 c3 01    	vextracti128 $0x1,%ymm0,%xmm3
  37a49e:	c5 f9 5d c3          	vminpd %xmm3,%xmm0,%xmm0
  37a4a2:	c5 f9 c6 d8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm3
  37a4a7:	c5 fb 5d c3          	vminsd %xmm3,%xmm0,%xmm0
  37a4ab:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  37a4af:	0f 86 61 f0 ff ff    	jbe    379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a4b5:	48 83 c1 20          	add    $0x20,%rcx
  37a4b9:	48 ff c8             	dec    %rax
  37a4bc:	0f 85 43 ff ff ff    	jne    37a405 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2f05>
  37a4c2:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
  37a4c8:	74 7f                	je     37a549 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3049>
  37a4ca:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  37a4cf:	49 8b 04 c7          	mov    (%r15,%rax,8),%rax
  37a4d3:	b1 3f                	mov    $0x3f,%cl
  37a4d5:	c4 e2 f0 f5 c8       	bzhi   %rcx,%rax,%rcx
  37a4da:	48 8d 71 ff          	lea    -0x1(%rcx),%rsi
  37a4de:	48 ba ff ff ff ff ff 	movabs $0xfffffffffffff,%rdx
  37a4e5:	ff 0f 00 
  37a4e8:	48 39 d6             	cmp    %rdx,%rsi
  37a4eb:	40 0f 92 c6          	setb   %sil
  37a4ef:	48 85 c0             	test   %rax,%rax
  37a4f2:	0f 98 c0             	sets   %al
  37a4f5:	40 20 c6             	and    %al,%sil
  37a4f8:	48 ba 00 00 00 00 00 	movabs $0x7ff0000000000000,%rdx
  37a4ff:	00 f0 7f 
  37a502:	48 39 d1             	cmp    %rdx,%rcx
  37a505:	40 0f 9f c7          	setg   %dil
  37a509:	41 0f 94 c0          	sete   %r8b
  37a50d:	41 08 f8             	or     %dil,%r8b
  37a510:	4c 8b 5c 24 30       	mov    0x30(%rsp),%r11
  37a515:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  37a51a:	41 08 f0             	or     %sil,%r8b
  37a51d:	48 ba 00 00 00 00 00 	movabs $0xfff0000000000000,%rdx
  37a524:	00 f0 ff 
  37a527:	48 01 d1             	add    %rdx,%rcx
  37a52a:	48 c1 e9 35          	shr    $0x35,%rcx
  37a52e:	81 f9 ff 03 00 00    	cmp    $0x3ff,%ecx
  37a534:	0f 92 c1             	setb   %cl
  37a537:	20 c1                	and    %al,%cl
  37a539:	44 08 c1             	or     %r8b,%cl
  37a53c:	0f 85 d4 ef ff ff    	jne    379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a542:	83 7c 24 08 01       	cmpl   $0x1,0x8(%rsp)
  37a547:	75 6f                	jne    37a5b8 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x30b8>
  37a549:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
  37a54f:	0f 84 85 03 00 00    	je     37a8da <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x33da>
  37a555:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  37a55a:	c5 fb 10 04 c3       	vmovsd (%rbx,%rax,8),%xmm0
  37a55f:	c5 fb 59 64 c5 00    	vmulsd 0x0(%rbp,%rax,8),%xmm0,%xmm4
  37a565:	c4 e1 f9 7e e0       	vmovq  %xmm4,%rax
  37a56a:	48 c1 e8 34          	shr    $0x34,%rax
  37a56e:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a573:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37a578:	0f 87 98 ef ff ff    	ja     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a57e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  37a583:	c4 c1 7b 59 44 c5 00 	vmulsd 0x0(%r13,%rax,8),%xmm0,%xmm0
  37a58a:	c5 f9 2e e7          	vucomisd %xmm7,%xmm4
  37a58e:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  37a593:	0f 85 21 01 00 00    	jne    37a6ba <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x31ba>
  37a599:	0f 8a 1b 01 00 00    	jp     37a6ba <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x31ba>
  37a59f:	48 c1 e8 34          	shr    $0x34,%rax
  37a5a3:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a5a8:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37a5ad:	0f 87 63 ef ff ff    	ja     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a5b3:	e9 43 01 00 00       	jmp    37a6fb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x31fb>
  37a5b8:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  37a5bd:	49 8b 44 c7 08       	mov    0x8(%r15,%rax,8),%rax
  37a5c2:	b1 3f                	mov    $0x3f,%cl
  37a5c4:	c4 e2 f0 f5 c8       	bzhi   %rcx,%rax,%rcx
  37a5c9:	48 8d 71 ff          	lea    -0x1(%rcx),%rsi
  37a5cd:	48 ba ff ff ff ff ff 	movabs $0xfffffffffffff,%rdx
  37a5d4:	ff 0f 00 
  37a5d7:	48 39 d6             	cmp    %rdx,%rsi
  37a5da:	40 0f 92 c6          	setb   %sil
  37a5de:	48 85 c0             	test   %rax,%rax
  37a5e1:	0f 98 c0             	sets   %al
  37a5e4:	40 20 c6             	and    %al,%sil
  37a5e7:	48 ba 00 00 00 00 00 	movabs $0x7ff0000000000000,%rdx
  37a5ee:	00 f0 7f 
  37a5f1:	48 39 d1             	cmp    %rdx,%rcx
  37a5f4:	40 0f 9f c7          	setg   %dil
  37a5f8:	41 0f 94 c0          	sete   %r8b
  37a5fc:	41 08 f8             	or     %dil,%r8b
  37a5ff:	4c 8b 5c 24 30       	mov    0x30(%rsp),%r11
  37a604:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  37a609:	41 08 f0             	or     %sil,%r8b
  37a60c:	48 ba 00 00 00 00 00 	movabs $0xfff0000000000000,%rdx
  37a613:	00 f0 ff 
  37a616:	48 01 d1             	add    %rdx,%rcx
  37a619:	48 c1 e9 35          	shr    $0x35,%rcx
  37a61d:	81 f9 ff 03 00 00    	cmp    $0x3ff,%ecx
  37a623:	0f 92 c1             	setb   %cl
  37a626:	20 c1                	and    %al,%cl
  37a628:	44 08 c1             	or     %r8b,%cl
  37a62b:	0f 85 e5 ee ff ff    	jne    379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a631:	83 7c 24 08 02       	cmpl   $0x2,0x8(%rsp)
  37a636:	0f 84 0d ff ff ff    	je     37a549 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3049>
  37a63c:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  37a641:	49 8b 44 c7 10       	mov    0x10(%r15,%rax,8),%rax
  37a646:	b1 3f                	mov    $0x3f,%cl
  37a648:	c4 e2 f0 f5 c8       	bzhi   %rcx,%rax,%rcx
  37a64d:	48 8d 71 ff          	lea    -0x1(%rcx),%rsi
  37a651:	48 ba ff ff ff ff ff 	movabs $0xfffffffffffff,%rdx
  37a658:	ff 0f 00 
  37a65b:	48 39 d6             	cmp    %rdx,%rsi
  37a65e:	40 0f 92 c6          	setb   %sil
  37a662:	48 85 c0             	test   %rax,%rax
  37a665:	0f 98 c0             	sets   %al
  37a668:	40 20 c6             	and    %al,%sil
  37a66b:	48 ba 00 00 00 00 00 	movabs $0x7ff0000000000000,%rdx
  37a672:	00 f0 7f 
  37a675:	48 39 d1             	cmp    %rdx,%rcx
  37a678:	40 0f 9f c7          	setg   %dil
  37a67c:	41 0f 94 c0          	sete   %r8b
  37a680:	41 08 f8             	or     %dil,%r8b
  37a683:	4c 8b 5c 24 30       	mov    0x30(%rsp),%r11
  37a688:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
  37a68d:	41 08 f0             	or     %sil,%r8b
  37a690:	48 ba 00 00 00 00 00 	movabs $0xfff0000000000000,%rdx
  37a697:	00 f0 ff 
  37a69a:	48 01 d1             	add    %rdx,%rcx
  37a69d:	48 c1 e9 35          	shr    $0x35,%rcx
  37a6a1:	81 f9 ff 03 00 00    	cmp    $0x3ff,%ecx
  37a6a7:	0f 92 c1             	setb   %cl
  37a6aa:	20 c1                	and    %al,%cl
  37a6ac:	44 08 c1             	or     %r8b,%cl
  37a6af:	0f 85 61 ee ff ff    	jne    379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a6b5:	e9 8f fe ff ff       	jmp    37a549 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3049>
  37a6ba:	c5 d9 54 25 ce c9 d0 	vandpd -0x2f3632(%rip),%xmm4,%xmm4        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a6c1:	ff 
  37a6c2:	48 c1 e8 34          	shr    $0x34,%rax
  37a6c6:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a6cb:	3d ff 07 00 00       	cmp    $0x7ff,%eax
  37a6d0:	0f 92 c0             	setb   %al
  37a6d3:	c5 f9 2e 25 15 a1 d0 	vucomisd -0x2f5eeb(%rip),%xmm4        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37a6da:	ff 
  37a6db:	0f 82 35 ee ff ff    	jb     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a6e1:	c5 fb 10 1d cf a9 d0 	vmovsd -0x2f5631(%rip),%xmm3        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  37a6e8:	ff 
  37a6e9:	c5 f9 2e dc          	vucomisd %xmm4,%xmm3
  37a6ed:	0f 82 23 ee ff ff    	jb     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a6f3:	84 c0                	test   %al,%al
  37a6f5:	0f 84 1b ee ff ff    	je     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a6fb:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  37a6ff:	75 02                	jne    37a703 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3203>
  37a701:	7b 28                	jnp    37a72b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x322b>
  37a703:	c5 f9 54 05 85 c9 d0 	vandpd -0x2f367b(%rip),%xmm0,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a70a:	ff 
  37a70b:	c5 f9 2e 05 dd a0 d0 	vucomisd -0x2f5f23(%rip),%xmm0        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37a712:	ff 
  37a713:	0f 82 fd ed ff ff    	jb     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a719:	c5 fb 10 1d 97 a9 d0 	vmovsd -0x2f5669(%rip),%xmm3        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  37a720:	ff 
  37a721:	c5 f9 2e d8          	vucomisd %xmm0,%xmm3
  37a725:	0f 82 eb ed ff ff    	jb     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a72b:	83 7c 24 08 01       	cmpl   $0x1,0x8(%rsp)
  37a730:	0f 84 a4 01 00 00    	je     37a8da <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x33da>
  37a736:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  37a73b:	c5 fb 10 44 c3 08    	vmovsd 0x8(%rbx,%rax,8),%xmm0
  37a741:	c5 fb 59 64 c5 08    	vmulsd 0x8(%rbp,%rax,8),%xmm0,%xmm4
  37a747:	c4 e1 f9 7e e0       	vmovq  %xmm4,%rax
  37a74c:	48 c1 e8 34          	shr    $0x34,%rax
  37a750:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a755:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37a75a:	0f 87 b6 ed ff ff    	ja     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a760:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  37a765:	c4 c1 7b 59 44 c5 08 	vmulsd 0x8(%r13,%rax,8),%xmm0,%xmm0
  37a76c:	c5 f9 2e e7          	vucomisd %xmm7,%xmm4
  37a770:	75 1d                	jne    37a78f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x328f>
  37a772:	7a 1b                	jp     37a78f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x328f>
  37a774:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  37a779:	48 c1 e8 34          	shr    $0x34,%rax
  37a77d:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a782:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37a787:	0f 87 89 ed ff ff    	ja     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a78d:	eb 46                	jmp    37a7d5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x32d5>
  37a78f:	c5 d9 54 25 f9 c8 d0 	vandpd -0x2f3707(%rip),%xmm4,%xmm4        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a796:	ff 
  37a797:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  37a79c:	48 c1 e8 34          	shr    $0x34,%rax
  37a7a0:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a7a5:	3d ff 07 00 00       	cmp    $0x7ff,%eax
  37a7aa:	0f 92 c0             	setb   %al
  37a7ad:	c5 f9 2e 25 3b a0 d0 	vucomisd -0x2f5fc5(%rip),%xmm4        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37a7b4:	ff 
  37a7b5:	0f 82 5b ed ff ff    	jb     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a7bb:	c5 fb 10 1d f5 a8 d0 	vmovsd -0x2f570b(%rip),%xmm3        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  37a7c2:	ff 
  37a7c3:	c5 f9 2e dc          	vucomisd %xmm4,%xmm3
  37a7c7:	0f 82 49 ed ff ff    	jb     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a7cd:	84 c0                	test   %al,%al
  37a7cf:	0f 84 41 ed ff ff    	je     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a7d5:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  37a7d9:	75 02                	jne    37a7dd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x32dd>
  37a7db:	7b 28                	jnp    37a805 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3305>
  37a7dd:	c5 f9 54 05 ab c8 d0 	vandpd -0x2f3755(%rip),%xmm0,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a7e4:	ff 
  37a7e5:	c5 f9 2e 05 03 a0 d0 	vucomisd -0x2f5ffd(%rip),%xmm0        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37a7ec:	ff 
  37a7ed:	0f 82 23 ed ff ff    	jb     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a7f3:	c5 fb 10 1d bd a8 d0 	vmovsd -0x2f5743(%rip),%xmm3        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  37a7fa:	ff 
  37a7fb:	c5 f9 2e d8          	vucomisd %xmm0,%xmm3
  37a7ff:	0f 82 11 ed ff ff    	jb     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a805:	83 7c 24 08 02       	cmpl   $0x2,0x8(%rsp)
  37a80a:	0f 84 ca 00 00 00    	je     37a8da <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x33da>
  37a810:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  37a815:	c5 fb 10 44 c3 10    	vmovsd 0x10(%rbx,%rax,8),%xmm0
  37a81b:	c5 fb 59 64 c5 10    	vmulsd 0x10(%rbp,%rax,8),%xmm0,%xmm4
  37a821:	c4 e1 f9 7e e0       	vmovq  %xmm4,%rax
  37a826:	48 c1 e8 34          	shr    $0x34,%rax
  37a82a:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a82f:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37a834:	0f 87 dc ec ff ff    	ja     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a83a:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  37a83f:	c4 c1 7b 59 44 c5 10 	vmulsd 0x10(%r13,%rax,8),%xmm0,%xmm0
  37a846:	c5 f9 2e e7          	vucomisd %xmm7,%xmm4
  37a84a:	c4 e1 f9 7e c0       	vmovq  %xmm0,%rax
  37a84f:	75 18                	jne    37a869 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3369>
  37a851:	7a 16                	jp     37a869 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3369>
  37a853:	48 c1 e8 34          	shr    $0x34,%rax
  37a857:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a85c:	3d fe 07 00 00       	cmp    $0x7fe,%eax
  37a861:	0f 87 af ec ff ff    	ja     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a867:	eb 41                	jmp    37a8aa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x33aa>
  37a869:	c5 d9 54 25 1f c8 d0 	vandpd -0x2f37e1(%rip),%xmm4,%xmm4        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a870:	ff 
  37a871:	48 c1 e8 34          	shr    $0x34,%rax
  37a875:	25 ff 07 00 00       	and    $0x7ff,%eax
  37a87a:	3d ff 07 00 00       	cmp    $0x7ff,%eax
  37a87f:	0f 92 c0             	setb   %al
  37a882:	c5 f9 2e 25 66 9f d0 	vucomisd -0x2f609a(%rip),%xmm4        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37a889:	ff 
  37a88a:	0f 82 86 ec ff ff    	jb     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a890:	c5 fb 10 1d 20 a8 d0 	vmovsd -0x2f57e0(%rip),%xmm3        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  37a897:	ff 
  37a898:	c5 f9 2e dc          	vucomisd %xmm4,%xmm3
  37a89c:	0f 82 74 ec ff ff    	jb     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a8a2:	84 c0                	test   %al,%al
  37a8a4:	0f 84 6c ec ff ff    	je     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a8aa:	c5 f9 2e c7          	vucomisd %xmm7,%xmm0
  37a8ae:	75 02                	jne    37a8b2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x33b2>
  37a8b0:	7b 28                	jnp    37a8da <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x33da>
  37a8b2:	c5 f9 54 05 d6 c7 d0 	vandpd -0x2f382a(%rip),%xmm0,%xmm0        # 87090 <anon.e3530c2e58bbba455a4969fa168fa85e.137.llvm.12026719078398232946+0xda8>
  37a8b9:	ff 
  37a8ba:	c5 f9 2e 05 2e 9f d0 	vucomisd -0x2f60d2(%rip),%xmm0        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37a8c1:	ff 
  37a8c2:	0f 82 4e ec ff ff    	jb     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a8c8:	c5 fb 10 1d e8 a7 d0 	vmovsd -0x2f5818(%rip),%xmm3        # 850b8 <anon.890d649631ab6ab37a03cdc207a0d7b9.0.llvm.3426226200983260467+0x28>
  37a8cf:	ff 
  37a8d0:	c5 f9 2e d8          	vucomisd %xmm0,%xmm3
  37a8d4:	0f 82 3c ec ff ff    	jb     379516 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x2016>
  37a8da:	4d 85 c9             	test   %r9,%r9
  37a8dd:	74 3e                	je     37a91d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x341d>
  37a8df:	31 c0                	xor    %eax,%eax
  37a8e1:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  37a8e5:	c5 fd 10 54 05 00    	vmovupd 0x0(%rbp,%rax,1),%ymm2
  37a8eb:	c5 ed 59 14 03       	vmulpd (%rbx,%rax,1),%ymm2,%ymm2
  37a8f0:	c5 fd 11 54 05 00    	vmovupd %ymm2,0x0(%rbp,%rax,1)
  37a8f6:	c4 c1 7d 10 54 05 00 	vmovupd 0x0(%r13,%rax,1),%ymm2
  37a8fd:	c5 ed 59 14 03       	vmulpd (%rbx,%rax,1),%ymm2,%ymm2
  37a902:	c4 c1 7d 11 54 05 00 	vmovupd %ymm2,0x0(%r13,%rax,1)
  37a909:	c4 c1 7d 11 04 07    	vmovupd %ymm0,(%r15,%rax,1)
  37a90f:	c5 fd 11 0c 03       	vmovupd %ymm1,(%rbx,%rax,1)
  37a914:	48 83 c0 20          	add    $0x20,%rax
  37a918:	49 ff c9             	dec    %r9
  37a91b:	75 c8                	jne    37a8e5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x33e5>
  37a91d:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  37a922:	48 85 f6             	test   %rsi,%rsi
  37a925:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  37a92a:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  37a92f:	0f 84 ac 00 00 00    	je     37a9e1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x34e1>
  37a935:	c5 fb 10 04 d3       	vmovsd (%rbx,%rdx,8),%xmm0
  37a93a:	c5 fb 59 44 d5 00    	vmulsd 0x0(%rbp,%rdx,8),%xmm0,%xmm0
  37a940:	c5 fb 11 44 d5 00    	vmovsd %xmm0,0x0(%rbp,%rdx,8)
  37a946:	c5 fb 10 04 d3       	vmovsd (%rbx,%rdx,8),%xmm0
  37a94b:	c4 c1 7b 59 44 d5 00 	vmulsd 0x0(%r13,%rdx,8),%xmm0,%xmm0
  37a952:	c4 c1 7b 11 44 d5 00 	vmovsd %xmm0,0x0(%r13,%rdx,8)
  37a959:	49 c7 04 d7 00 00 00 	movq   $0x0,(%r15,%rdx,8)
  37a960:	00 
  37a961:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
  37a968:	00 f0 3f 
  37a96b:	48 89 04 d3          	mov    %rax,(%rbx,%rdx,8)
  37a96f:	83 fe 01             	cmp    $0x1,%esi
  37a972:	74 6d                	je     37a9e1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x34e1>
  37a974:	c5 fb 10 44 d3 08    	vmovsd 0x8(%rbx,%rdx,8),%xmm0
  37a97a:	c5 fb 59 44 d5 08    	vmulsd 0x8(%rbp,%rdx,8),%xmm0,%xmm0
  37a980:	c5 fb 11 44 d5 08    	vmovsd %xmm0,0x8(%rbp,%rdx,8)
  37a986:	c5 fb 10 44 d3 08    	vmovsd 0x8(%rbx,%rdx,8),%xmm0
  37a98c:	c4 c1 7b 59 44 d5 08 	vmulsd 0x8(%r13,%rdx,8),%xmm0,%xmm0
  37a993:	c4 c1 7b 11 44 d5 08 	vmovsd %xmm0,0x8(%r13,%rdx,8)
  37a99a:	49 c7 44 d7 08 00 00 	movq   $0x0,0x8(%r15,%rdx,8)
  37a9a1:	00 00 
  37a9a3:	48 89 44 d3 08       	mov    %rax,0x8(%rbx,%rdx,8)
  37a9a8:	83 fe 02             	cmp    $0x2,%esi
  37a9ab:	74 34                	je     37a9e1 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x34e1>
  37a9ad:	c5 fb 10 44 d3 10    	vmovsd 0x10(%rbx,%rdx,8),%xmm0
  37a9b3:	c5 fb 59 44 d5 10    	vmulsd 0x10(%rbp,%rdx,8),%xmm0,%xmm0
  37a9b9:	c5 fb 11 44 d5 10    	vmovsd %xmm0,0x10(%rbp,%rdx,8)
  37a9bf:	c5 fb 10 44 d3 10    	vmovsd 0x10(%rbx,%rdx,8),%xmm0
  37a9c5:	c4 c1 7b 59 44 d5 10 	vmulsd 0x10(%r13,%rdx,8),%xmm0,%xmm0
  37a9cc:	c4 c1 7b 11 44 d5 10 	vmovsd %xmm0,0x10(%r13,%rdx,8)
  37a9d3:	49 c7 44 d7 10 00 00 	movq   $0x0,0x10(%r15,%rdx,8)
  37a9da:	00 00 
  37a9dc:	48 89 44 d3 10       	mov    %rax,0x10(%rbx,%rdx,8)
  37a9e1:	49 8d 7c 24 01       	lea    0x1(%r12),%rdi
  37a9e6:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  37a9ed:	00 
  37a9ee:	31 c0                	xor    %eax,%eax
  37a9f0:	48 39 8c 24 90 01 00 	cmp    %rcx,0x190(%rsp)
  37a9f7:	00 
  37a9f8:	0f 84 a0 e8 ff ff    	je     37929e <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x1d9e>
  37a9fe:	e9 3a cb ff ff       	jmp    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37aa03:	b0 01                	mov    $0x1,%al
  37aa05:	e9 33 cb ff ff       	jmp    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37aa0a:	48 c1 e7 04          	shl    $0x4,%rdi
  37aa0e:	4c 8b 4c 24 58       	mov    0x58(%rsp),%r9
  37aa13:	c4 41 7b 11 3c 39    	vmovsd %xmm15,(%r9,%rdi,1)
  37aa19:	c4 41 7b 11 44 39 08 	vmovsd %xmm8,0x8(%r9,%rdi,1)
  37aa20:	45 20 e3             	and    %r12b,%r11b
  37aa23:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
  37aa28:	49 83 c4 02          	add    $0x2,%r12
  37aa2c:	4c 3b a4 24 f0 00 00 	cmp    0xf0(%rsp),%r12
  37aa33:	00 
  37aa34:	4c 8b 4c 24 68       	mov    0x68(%rsp),%r9
  37aa39:	0f 83 cd 09 00 00    	jae    37b40c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3f0c>
  37aa3f:	4c 3b a4 24 d0 00 00 	cmp    0xd0(%rsp),%r12
  37aa46:	00 
  37aa47:	0f 83 70 18 00 00    	jae    37c2bd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4dbd>
  37aa4d:	49 39 f4             	cmp    %rsi,%r12
  37aa50:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  37aa57:	00 
  37aa58:	0f 83 4c 18 00 00    	jae    37c2aa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4daa>
  37aa5e:	4d 8d 44 24 01       	lea    0x1(%r12),%r8
  37aa63:	4c 3b 84 24 d0 00 00 	cmp    0xd0(%rsp),%r8
  37aa6a:	00 
  37aa6b:	0f 83 6a 18 00 00    	jae    37c2db <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4ddb>
  37aa71:	49 39 f0             	cmp    %rsi,%r8
  37aa74:	0f 83 26 11 00 00    	jae    37bba0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x46a0>
  37aa7a:	48 8b 84 24 a0 01 00 	mov    0x1a0(%rsp),%rax
  37aa81:	00 
  37aa82:	c4 a1 7b 10 04 e0    	vmovsd (%rax,%r12,8),%xmm0
  37aa88:	c4 22 7d 19 6c e0 08 	vbroadcastsd 0x8(%rax,%r12,8),%ymm13
  37aa8f:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
  37aa96:	00 
  37aa97:	c4 a1 7b 10 0c e0    	vmovsd (%rax,%r12,8),%xmm1
  37aa9d:	c4 22 7d 19 74 e0 08 	vbroadcastsd 0x8(%rax,%r12,8),%ymm14
  37aaa4:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
  37aaab:	00 
  37aaac:	48 85 ff             	test   %rdi,%rdi
  37aaaf:	c5 f9 29 84 24 50 01 	vmovapd %xmm0,0x150(%rsp)
  37aab6:	00 00 
  37aab8:	c5 f9 29 8c 24 60 01 	vmovapd %xmm1,0x160(%rsp)
  37aabf:	00 00 
  37aac1:	0f 84 c5 00 00 00    	je     37ab8c <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x368c>
  37aac7:	c4 e2 7d 19 d0       	vbroadcastsd %xmm0,%ymm2
  37aacc:	c4 e2 7d 19 c1       	vbroadcastsd %xmm1,%ymm0
  37aad1:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  37aad5:	31 db                	xor    %ebx,%ebx
  37aad7:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  37aadb:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  37aadf:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  37aae3:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  37aae8:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  37aaed:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  37aaf2:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  37aaf7:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  37aafe:	00 
  37aaff:	48 8b b4 24 98 00 00 	mov    0x98(%rsp),%rsi
  37ab06:	00 
  37ab07:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  37ab0e:	00 
  37ab0f:	90                   	nop
  37ab10:	c4 41 7d 10 7c 1d 00 	vmovupd 0x0(%r13,%rbx,1),%ymm15
  37ab17:	c4 41 7d 10 24 19    	vmovupd (%r9,%rbx,1),%ymm12
  37ab1d:	c4 42 9d b8 cf       	vfmadd231pd %ymm15,%ymm12,%ymm9
  37ab22:	c5 fd 10 0c 18       	vmovupd (%rax,%rbx,1),%ymm1
  37ab27:	c5 fd 28 d9          	vmovapd %ymm1,%ymm3
  37ab2b:	c4 e2 ed a8 d8       	vfmadd213pd %ymm0,%ymm2,%ymm3
  37ab30:	c4 e2 85 a8 5c 1d 00 	vfmadd213pd 0x0(%rbp,%rbx,1),%ymm15,%ymm3
  37ab37:	c4 c2 e5 b8 ec       	vfmadd231pd %ymm12,%ymm3,%ymm5
  37ab3c:	c5 7d 10 24 19       	vmovupd (%rcx,%rbx,1),%ymm12
  37ab41:	c4 42 9d b8 df       	vfmadd231pd %ymm15,%ymm12,%ymm11
  37ab46:	c4 c2 e5 b8 fc       	vfmadd231pd %ymm12,%ymm3,%ymm7
  37ab4b:	c4 41 7d 10 24 18    	vmovupd (%r8,%rbx,1),%ymm12
  37ab51:	c4 42 9d b8 c7       	vfmadd231pd %ymm15,%ymm12,%ymm8
  37ab56:	c4 c2 e5 b8 e4       	vfmadd231pd %ymm12,%ymm3,%ymm4
  37ab5b:	c5 7d 10 24 1e       	vmovupd (%rsi,%rbx,1),%ymm12
  37ab60:	c4 42 9d b8 d7       	vfmadd231pd %ymm15,%ymm12,%ymm10
  37ab65:	c4 c2 e5 b8 f4       	vfmadd231pd %ymm12,%ymm3,%ymm6
  37ab6a:	c4 c2 95 a8 ce       	vfmadd213pd %ymm14,%ymm13,%ymm1
  37ab6f:	c4 c2 e5 a8 cf       	vfmadd213pd %ymm15,%ymm3,%ymm1
  37ab74:	c5 fd 11 5c 1d 00    	vmovupd %ymm3,0x0(%rbp,%rbx,1)
  37ab7a:	c4 c1 7d 11 4c 1d 00 	vmovupd %ymm1,0x0(%r13,%rbx,1)
  37ab81:	48 83 c3 20          	add    $0x20,%rbx
  37ab85:	48 ff cf             	dec    %rdi
  37ab88:	75 86                	jne    37ab10 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3610>
  37ab8a:	eb 24                	jmp    37abb0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x36b0>
  37ab8c:	c4 41 31 57 c9       	vxorpd %xmm9,%xmm9,%xmm9
  37ab91:	c4 41 21 57 db       	vxorpd %xmm11,%xmm11,%xmm11
  37ab96:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  37ab9b:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  37aba0:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  37aba4:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  37aba8:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  37abac:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  37abb0:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
  37abb5:	c4 63 7d 19 c8 01    	vextractf128 $0x1,%ymm9,%xmm0
  37abbb:	c5 b1 58 c0          	vaddpd %xmm0,%xmm9,%xmm0
  37abbf:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  37abc4:	c5 fb 58 d9          	vaddsd %xmm1,%xmm0,%xmm3
  37abc8:	c4 63 7d 19 d8 01    	vextractf128 $0x1,%ymm11,%xmm0
  37abce:	c5 a1 58 c0          	vaddpd %xmm0,%xmm11,%xmm0
  37abd2:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  37abd7:	c5 7b 58 d9          	vaddsd %xmm1,%xmm0,%xmm11
  37abdb:	c4 63 7d 19 c0 01    	vextractf128 $0x1,%ymm8,%xmm0
  37abe1:	c5 b9 58 c0          	vaddpd %xmm0,%xmm8,%xmm0
  37abe5:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  37abea:	c5 7b 58 c9          	vaddsd %xmm1,%xmm0,%xmm9
  37abee:	c4 63 7d 19 d0 01    	vextractf128 $0x1,%ymm10,%xmm0
  37abf4:	c5 a9 58 c0          	vaddpd %xmm0,%xmm10,%xmm0
  37abf8:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  37abfd:	c5 7b 58 d1          	vaddsd %xmm1,%xmm0,%xmm10
  37ac01:	c4 e3 7d 19 e8 01    	vextractf128 $0x1,%ymm5,%xmm0
  37ac07:	c5 d1 58 c0          	vaddpd %xmm0,%xmm5,%xmm0
  37ac0b:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  37ac10:	c5 fb 58 e9          	vaddsd %xmm1,%xmm0,%xmm5
  37ac14:	c4 e3 7d 19 f8 01    	vextractf128 $0x1,%ymm7,%xmm0
  37ac1a:	c5 c1 58 c0          	vaddpd %xmm0,%xmm7,%xmm0
  37ac1e:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  37ac23:	c5 fb 58 f9          	vaddsd %xmm1,%xmm0,%xmm7
  37ac27:	c4 e3 7d 19 e0 01    	vextractf128 $0x1,%ymm4,%xmm0
  37ac2d:	c5 d9 58 c0          	vaddpd %xmm0,%xmm4,%xmm0
  37ac31:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  37ac36:	c5 7b 58 f9          	vaddsd %xmm1,%xmm0,%xmm15
  37ac3a:	c4 e3 7d 19 f0 01    	vextractf128 $0x1,%ymm6,%xmm0
  37ac40:	c5 c9 58 c0          	vaddpd %xmm0,%xmm6,%xmm0
  37ac44:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  37ac49:	c5 7b 58 c1          	vaddsd %xmm1,%xmm0,%xmm8
  37ac4d:	4d 85 ff             	test   %r15,%r15
  37ac50:	0f 84 ce 02 00 00    	je     37af24 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3a24>
  37ac56:	44 88 5c 24 18       	mov    %r11b,0x18(%rsp)
  37ac5b:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  37ac60:	c4 c1 7b 10 64 f5 00 	vmovsd 0x0(%r13,%rsi,8),%xmm4
  37ac67:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  37ac6e:	00 
  37ac6f:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  37ac74:	c5 fb 10 04 d0       	vmovsd (%rax,%rdx,8),%xmm0
  37ac79:	c5 f9 28 d0          	vmovapd %xmm0,%xmm2
  37ac7d:	c5 f9 28 b4 24 50 01 	vmovapd 0x150(%rsp),%xmm6
  37ac84:	00 00 
  37ac86:	c4 e2 c9 a9 94 24 60 	vfmadd213sd 0x160(%rsp),%xmm6,%xmm2
  37ac8d:	01 00 00 
  37ac90:	c4 e2 d9 a9 54 f5 00 	vfmadd213sd 0x0(%rbp,%rsi,8),%xmm4,%xmm2
  37ac97:	c4 c2 91 a9 c6       	vfmadd213sd %xmm14,%xmm13,%xmm0
  37ac9c:	c4 e2 e9 a9 c4       	vfmadd213sd %xmm4,%xmm2,%xmm0
  37aca1:	48 8b 94 24 20 01 00 	mov    0x120(%rsp),%rdx
  37aca8:	00 
  37aca9:	c4 c1 7b 10 0c d1    	vmovsd (%r9,%rdx,8),%xmm1
  37acaf:	c4 e2 f1 b9 dc       	vfmadd231sd %xmm4,%xmm1,%xmm3
  37acb4:	c5 fb 11 1c 24       	vmovsd %xmm3,(%rsp)
  37acb9:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  37acbe:	c5 fb 10 1c c1       	vmovsd (%rcx,%rax,8),%xmm3
  37acc3:	c4 62 e1 b9 dc       	vfmadd231sd %xmm4,%xmm3,%xmm11
  37acc8:	c5 7b 11 5c 24 08    	vmovsd %xmm11,0x8(%rsp)
  37acce:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  37acd5:	00 
  37acd6:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  37acdd:	00 
  37acde:	c5 7b 10 24 c7       	vmovsd (%rdi,%rax,8),%xmm12
  37ace3:	c4 62 99 b9 cc       	vfmadd231sd %xmm4,%xmm12,%xmm9
  37ace8:	4c 8b 9c 24 b8 00 00 	mov    0xb8(%rsp),%r11
  37acef:	00 
  37acf0:	c4 41 79 28 df       	vmovapd %xmm15,%xmm11
  37acf5:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
  37acfc:	00 
  37acfd:	c4 21 7b 10 3c df    	vmovsd (%rdi,%r11,8),%xmm15
  37ad03:	c4 62 81 b9 d4       	vfmadd231sd %xmm4,%xmm15,%xmm10
  37ad08:	c4 e2 e9 b9 e9       	vfmadd231sd %xmm1,%xmm2,%xmm5
  37ad0d:	c4 e2 e9 b9 fb       	vfmadd231sd %xmm3,%xmm2,%xmm7
  37ad12:	c4 42 e9 b9 dc       	vfmadd231sd %xmm12,%xmm2,%xmm11
  37ad17:	c4 42 e9 b9 c7       	vfmadd231sd %xmm15,%xmm2,%xmm8
  37ad1c:	c4 e1 f9 7e d1       	vmovq  %xmm2,%rcx
  37ad21:	c5 fb 11 54 f5 00    	vmovsd %xmm2,0x0(%rbp,%rsi,8)
  37ad27:	c4 e1 f9 7e c7       	vmovq  %xmm0,%rdi
  37ad2c:	c4 c1 7b 11 44 f5 00 	vmovsd %xmm0,0x0(%r13,%rsi,8)
  37ad33:	41 b2 3f             	mov    $0x3f,%r10b
  37ad36:	c4 e2 a8 f5 c9       	bzhi   %r10,%rcx,%rcx
  37ad3b:	49 b8 00 00 00 00 00 	movabs $0x7ff0000000000000,%r8
  37ad42:	00 f0 7f 
  37ad45:	4c 39 c1             	cmp    %r8,%rcx
  37ad48:	41 0f 94 c1          	sete   %r9b
  37ad4c:	48 85 c9             	test   %rcx,%rcx
  37ad4f:	0f 94 c3             	sete   %bl
  37ad52:	44 08 cb             	or     %r9b,%bl
  37ad55:	49 bc 00 00 00 00 00 	movabs $0xfff0000000000000,%r12
  37ad5c:	00 f0 ff 
  37ad5f:	4c 01 e1             	add    %r12,%rcx
  37ad62:	48 c1 e9 35          	shr    $0x35,%rcx
  37ad66:	81 f9 ff 03 00 00    	cmp    $0x3ff,%ecx
  37ad6c:	0f 92 c1             	setb   %cl
  37ad6f:	08 d9                	or     %bl,%cl
  37ad71:	c4 e2 a8 f5 ff       	bzhi   %r10,%rdi,%rdi
  37ad76:	4c 39 c7             	cmp    %r8,%rdi
  37ad79:	41 0f 94 c1          	sete   %r9b
  37ad7d:	48 85 ff             	test   %rdi,%rdi
  37ad80:	0f 94 c3             	sete   %bl
  37ad83:	44 08 cb             	or     %r9b,%bl
  37ad86:	4c 01 e7             	add    %r12,%rdi
  37ad89:	48 c1 ef 35          	shr    $0x35,%rdi
  37ad8d:	81 ff ff 03 00 00    	cmp    $0x3ff,%edi
  37ad93:	41 0f 92 c4          	setb   %r12b
  37ad97:	41 08 dc             	or     %bl,%r12b
  37ad9a:	41 20 cc             	and    %cl,%r12b
  37ad9d:	41 83 ff 01          	cmp    $0x1,%r15d
  37ada1:	0f 84 3c 01 00 00    	je     37aee3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x39e3>
  37ada7:	c4 c1 7b 10 64 f5 08 	vmovsd 0x8(%r13,%rsi,8),%xmm4
  37adae:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  37adb5:	00 
  37adb6:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  37adbb:	c5 fb 10 44 f9 08    	vmovsd 0x8(%rcx,%rdi,8),%xmm0
  37adc1:	c5 f9 28 d0          	vmovapd %xmm0,%xmm2
  37adc5:	c4 e2 c9 a9 94 24 60 	vfmadd213sd 0x160(%rsp),%xmm6,%xmm2
  37adcc:	01 00 00 
  37adcf:	c4 e2 d9 a9 54 f5 08 	vfmadd213sd 0x8(%rbp,%rsi,8),%xmm4,%xmm2
  37add6:	c4 c2 91 a9 c6       	vfmadd213sd %xmm14,%xmm13,%xmm0
  37addb:	c4 e2 e9 a9 c4       	vfmadd213sd %xmm4,%xmm2,%xmm0
  37ade0:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  37ade5:	c5 fb 10 4c d1 08    	vmovsd 0x8(%rcx,%rdx,8),%xmm1
  37adeb:	c5 fb 10 1c 24       	vmovsd (%rsp),%xmm3
  37adf0:	c4 e2 f1 b9 dc       	vfmadd231sd %xmm4,%xmm1,%xmm3
  37adf5:	c5 fb 11 1c 24       	vmovsd %xmm3,(%rsp)
  37adfa:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  37ae01:	00 
  37ae02:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  37ae07:	c5 fb 10 5c f9 08    	vmovsd 0x8(%rcx,%rdi,8),%xmm3
  37ae0d:	c5 7b 10 64 24 08    	vmovsd 0x8(%rsp),%xmm12
  37ae13:	c4 62 e1 b9 e4       	vfmadd231sd %xmm4,%xmm3,%xmm12
  37ae18:	c5 7b 11 64 24 08    	vmovsd %xmm12,0x8(%rsp)
  37ae1e:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  37ae25:	00 
  37ae26:	c5 7b 10 64 c1 08    	vmovsd 0x8(%rcx,%rax,8),%xmm12
  37ae2c:	c4 62 99 b9 cc       	vfmadd231sd %xmm4,%xmm12,%xmm9
  37ae31:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  37ae38:	00 
  37ae39:	c4 21 7b 10 7c d9 08 	vmovsd 0x8(%rcx,%r11,8),%xmm15
  37ae40:	c4 62 81 b9 d4       	vfmadd231sd %xmm4,%xmm15,%xmm10
  37ae45:	c4 e2 e9 b9 e9       	vfmadd231sd %xmm1,%xmm2,%xmm5
  37ae4a:	c4 e2 e9 b9 fb       	vfmadd231sd %xmm3,%xmm2,%xmm7
  37ae4f:	c4 42 e9 b9 dc       	vfmadd231sd %xmm12,%xmm2,%xmm11
  37ae54:	c4 42 e9 b9 c7       	vfmadd231sd %xmm15,%xmm2,%xmm8
  37ae59:	c4 e1 f9 7e d1       	vmovq  %xmm2,%rcx
  37ae5e:	c5 fb 11 54 f5 08    	vmovsd %xmm2,0x8(%rbp,%rsi,8)
  37ae64:	c4 e1 f9 7e c7       	vmovq  %xmm0,%rdi
  37ae69:	c4 c1 7b 11 44 f5 08 	vmovsd %xmm0,0x8(%r13,%rsi,8)
  37ae70:	41 b2 3f             	mov    $0x3f,%r10b
  37ae73:	c4 e2 a8 f5 c9       	bzhi   %r10,%rcx,%rcx
  37ae78:	4c 39 c1             	cmp    %r8,%rcx
  37ae7b:	41 0f 94 c1          	sete   %r9b
  37ae7f:	48 85 c9             	test   %rcx,%rcx
  37ae82:	0f 94 c3             	sete   %bl
  37ae85:	44 08 cb             	or     %r9b,%bl
  37ae88:	49 b9 00 00 00 00 00 	movabs $0xfff0000000000000,%r9
  37ae8f:	00 f0 ff 
  37ae92:	4c 01 c9             	add    %r9,%rcx
  37ae95:	48 c1 e9 35          	shr    $0x35,%rcx
  37ae99:	81 f9 ff 03 00 00    	cmp    $0x3ff,%ecx
  37ae9f:	0f 92 c1             	setb   %cl
  37aea2:	08 d9                	or     %bl,%cl
  37aea4:	c4 e2 a8 f5 ff       	bzhi   %r10,%rdi,%rdi
  37aea9:	4c 39 c7             	cmp    %r8,%rdi
  37aeac:	41 0f 94 c1          	sete   %r9b
  37aeb0:	48 85 ff             	test   %rdi,%rdi
  37aeb3:	0f 94 c3             	sete   %bl
  37aeb6:	44 08 cb             	or     %r9b,%bl
  37aeb9:	49 b9 00 00 00 00 00 	movabs $0xfff0000000000000,%r9
  37aec0:	00 f0 ff 
  37aec3:	4c 01 cf             	add    %r9,%rdi
  37aec6:	48 c1 ef 35          	shr    $0x35,%rdi
  37aeca:	81 ff ff 03 00 00    	cmp    $0x3ff,%edi
  37aed0:	40 0f 92 c7          	setb   %dil
  37aed4:	40 08 df             	or     %bl,%dil
  37aed7:	40 20 cf             	and    %cl,%dil
  37aeda:	41 20 fc             	and    %dil,%r12b
  37aedd:	41 83 ff 02          	cmp    $0x2,%r15d
  37aee1:	75 6f                	jne    37af52 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3a52>
  37aee3:	48 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%rsi
  37aeea:	00 
  37aeeb:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  37aef0:	4c 8b 54 24 70       	mov    0x70(%rsp),%r10
  37aef5:	44 0f b6 5c 24 18    	movzbl 0x18(%rsp),%r11d
  37aefb:	c5 7d 10 a4 24 d0 01 	vmovupd 0x1d0(%rsp),%ymm12
  37af02:	00 00 
  37af04:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  37af08:	41 b0 3f             	mov    $0x3f,%r8b
  37af0b:	c4 62 7d 19 2d dc 98 	vbroadcastsd -0x2f6724(%rip),%ymm13        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37af12:	d0 ff 
  37af14:	c4 41 79 28 fb       	vmovapd %xmm11,%xmm15
  37af19:	c5 7b 10 5c 24 08    	vmovsd 0x8(%rsp),%xmm11
  37af1f:	e9 89 01 00 00       	jmp    37b0ad <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3bad>
  37af24:	c5 fb 11 1c 24       	vmovsd %xmm3,(%rsp)
  37af29:	41 b4 01             	mov    $0x1,%r12b
  37af2c:	48 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%rsi
  37af33:	00 
  37af34:	c5 7d 10 a4 24 d0 01 	vmovupd 0x1d0(%rsp),%ymm12
  37af3b:	00 00 
  37af3d:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  37af41:	41 b0 3f             	mov    $0x3f,%r8b
  37af44:	c4 62 7d 19 2d a3 98 	vbroadcastsd -0x2f675d(%rip),%ymm13        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37af4b:	d0 ff 
  37af4d:	e9 63 01 00 00       	jmp    37b0b5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3bb5>
  37af52:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  37af59:	00 
  37af5a:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  37af5f:	c5 fb 10 44 f9 10    	vmovsd 0x10(%rcx,%rdi,8),%xmm0
  37af65:	c4 e2 f9 a9 b4 24 60 	vfmadd213sd 0x160(%rsp),%xmm0,%xmm6
  37af6c:	01 00 00 
  37af6f:	c4 42 f9 a9 ee       	vfmadd213sd %xmm14,%xmm0,%xmm13
  37af74:	c4 c1 7b 10 44 f5 10 	vmovsd 0x10(%r13,%rsi,8),%xmm0
  37af7b:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  37af80:	c5 fb 10 4c d1 10    	vmovsd 0x10(%rcx,%rdx,8),%xmm1
  37af86:	c4 e2 f9 a9 74 f5 10 	vfmadd213sd 0x10(%rbp,%rsi,8),%xmm0,%xmm6
  37af8d:	c5 fb 10 14 24       	vmovsd (%rsp),%xmm2
  37af92:	c4 e2 f1 b9 d0       	vfmadd231sd %xmm0,%xmm1,%xmm2
  37af97:	c5 fb 11 14 24       	vmovsd %xmm2,(%rsp)
  37af9c:	c4 e2 c9 b9 e9       	vfmadd231sd %xmm1,%xmm6,%xmm5
  37afa1:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  37afa8:	00 
  37afa9:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  37afae:	c5 fb 10 4c d1 10    	vmovsd 0x10(%rcx,%rdx,8),%xmm1
  37afb4:	c5 fb 10 54 24 08    	vmovsd 0x8(%rsp),%xmm2
  37afba:	c4 e2 f1 b9 d0       	vfmadd231sd %xmm0,%xmm1,%xmm2
  37afbf:	c4 e2 c9 b9 f9       	vfmadd231sd %xmm1,%xmm6,%xmm7
  37afc4:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  37afcb:	00 
  37afcc:	c5 fb 10 4c c1 10    	vmovsd 0x10(%rcx,%rax,8),%xmm1
  37afd2:	c4 62 f1 b9 c8       	vfmadd231sd %xmm0,%xmm1,%xmm9
  37afd7:	c4 62 c9 b9 d9       	vfmadd231sd %xmm1,%xmm6,%xmm11
  37afdc:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  37afe3:	00 
  37afe4:	c4 a1 7b 10 4c d8 10 	vmovsd 0x10(%rax,%r11,8),%xmm1
  37afeb:	c4 62 f1 b9 d0       	vfmadd231sd %xmm0,%xmm1,%xmm10
  37aff0:	c4 62 c9 b9 c1       	vfmadd231sd %xmm1,%xmm6,%xmm8
  37aff5:	c4 62 c9 a9 e8       	vfmadd213sd %xmm0,%xmm6,%xmm13
  37affa:	c4 e1 f9 7e f1       	vmovq  %xmm6,%rcx
  37afff:	c5 fb 11 74 f5 10    	vmovsd %xmm6,0x10(%rbp,%rsi,8)
  37b005:	c4 61 f9 7e ef       	vmovq  %xmm13,%rdi
  37b00a:	c4 41 7b 11 6c f5 10 	vmovsd %xmm13,0x10(%r13,%rsi,8)
  37b011:	b2 3f                	mov    $0x3f,%dl
  37b013:	c4 e2 e8 f5 c9       	bzhi   %rdx,%rcx,%rcx
  37b018:	4c 39 c1             	cmp    %r8,%rcx
  37b01b:	41 0f 94 c1          	sete   %r9b
  37b01f:	48 85 c9             	test   %rcx,%rcx
  37b022:	0f 94 c3             	sete   %bl
  37b025:	44 08 cb             	or     %r9b,%bl
  37b028:	48 b8 00 00 00 00 00 	movabs $0xfff0000000000000,%rax
  37b02f:	00 f0 ff 
  37b032:	48 01 c1             	add    %rax,%rcx
  37b035:	48 c1 e9 35          	shr    $0x35,%rcx
  37b039:	81 f9 ff 03 00 00    	cmp    $0x3ff,%ecx
  37b03f:	0f 92 c1             	setb   %cl
  37b042:	08 d9                	or     %bl,%cl
  37b044:	c4 e2 e8 f5 ff       	bzhi   %rdx,%rdi,%rdi
  37b049:	4c 39 c7             	cmp    %r8,%rdi
  37b04c:	41 0f 94 c1          	sete   %r9b
  37b050:	48 85 ff             	test   %rdi,%rdi
  37b053:	0f 94 c3             	sete   %bl
  37b056:	44 08 cb             	or     %r9b,%bl
  37b059:	48 01 c7             	add    %rax,%rdi
  37b05c:	48 c1 ef 35          	shr    $0x35,%rdi
  37b060:	81 ff ff 03 00 00    	cmp    $0x3ff,%edi
  37b066:	40 0f 92 c7          	setb   %dil
  37b06a:	40 08 df             	or     %bl,%dil
  37b06d:	40 20 cf             	and    %cl,%dil
  37b070:	41 20 fc             	and    %dil,%r12b
  37b073:	48 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%rsi
  37b07a:	00 
  37b07b:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  37b080:	4c 8b 54 24 70       	mov    0x70(%rsp),%r10
  37b085:	44 0f b6 5c 24 18    	movzbl 0x18(%rsp),%r11d
  37b08b:	c5 7d 10 a4 24 d0 01 	vmovupd 0x1d0(%rsp),%ymm12
  37b092:	00 00 
  37b094:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  37b098:	41 b0 3f             	mov    $0x3f,%r8b
  37b09b:	c4 62 7d 19 2d 4c 97 	vbroadcastsd -0x2f68b4(%rip),%ymm13        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37b0a2:	d0 ff 
  37b0a4:	c4 41 79 28 fb       	vmovapd %xmm11,%xmm15
  37b0a9:	c5 79 28 da          	vmovapd %xmm2,%xmm11
  37b0ad:	4c 8b bc 24 b0 01 00 	mov    0x1b0(%rsp),%r15
  37b0b4:	00 
  37b0b5:	c5 7d 29 e0          	vmovapd %ymm12,%ymm0
  37b0b9:	48 83 bc 24 d8 00 00 	cmpq   $0x0,0xd8(%rsp)
  37b0c0:	00 00 
  37b0c2:	74 61                	je     37b125 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3c25>
  37b0c4:	31 ff                	xor    %edi,%edi
  37b0c6:	48 8b 9c 24 d8 00 00 	mov    0xd8(%rsp),%rbx
  37b0cd:	00 
  37b0ce:	c5 7d 29 e0          	vmovapd %ymm12,%ymm0
  37b0d2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  37b0d9:	1f 84 00 00 00 00 00 
  37b0e0:	c4 e2 7d 19 0d 4f 9e 	vbroadcastsd -0x2f61b1(%rip),%ymm1        # 84f38 <anon.890d649631ab6ab37a03cdc207a0d7b9.203.llvm.3426226200983260467+0x10>
  37b0e7:	d0 ff 
  37b0e9:	c5 f5 54 54 3d 00    	vandpd 0x0(%rbp,%rdi,1),%ymm1,%ymm2
  37b0ef:	c4 c1 75 54 4c 3d 00 	vandpd 0x0(%r13,%rdi,1),%ymm1,%ymm1
  37b0f6:	c5 ed c2 dc 00       	vcmpeqpd %ymm4,%ymm2,%ymm3
  37b0fb:	c4 c1 6d c2 d5 1d    	vcmpge_oqpd %ymm13,%ymm2,%ymm2
  37b101:	c5 ed 56 d3          	vorpd  %ymm3,%ymm2,%ymm2
  37b105:	c5 f5 c2 dc 00       	vcmpeqpd %ymm4,%ymm1,%ymm3
  37b10a:	c4 c1 75 c2 cd 1d    	vcmpge_oqpd %ymm13,%ymm1,%ymm1
  37b110:	c5 f5 56 cb          	vorpd  %ymm3,%ymm1,%ymm1
  37b114:	c5 f5 54 ca          	vandpd %ymm2,%ymm1,%ymm1
  37b118:	c5 fd 54 c1          	vandpd %ymm1,%ymm0,%ymm0
  37b11c:	48 83 c7 20          	add    $0x20,%rdi
  37b120:	48 ff cb             	dec    %rbx
  37b123:	75 bb                	jne    37b0e0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3be0>
  37b125:	c4 e2 7d 59 0d 92 9d 	vpbroadcastq -0x2f626e(%rip),%ymm1        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  37b12c:	d0 ff 
  37b12e:	c4 e2 5d 37 c0       	vpcmpgtq %ymm0,%ymm4,%ymm0
  37b133:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
  37b137:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
  37b13d:	c5 f9 5d c1          	vminpd %xmm1,%xmm0,%xmm0
  37b141:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  37b146:	c5 fb 5d c1          	vminsd %xmm1,%xmm0,%xmm0
  37b14a:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  37b14e:	c5 f9 2e c1          	vucomisd %xmm1,%xmm0
  37b152:	0f 86 a3 0d 00 00    	jbe    37befb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x49fb>
  37b158:	48 85 d2             	test   %rdx,%rdx
  37b15b:	0f 84 84 00 00 00    	je     37b1e5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3ce5>
  37b161:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  37b166:	c4 e2 b8 f5 4c c5 00 	bzhi   %r8,0x0(%rbp,%rax,8),%rcx
  37b16d:	48 bf 00 00 00 00 00 	movabs $0x7ff0000000000000,%rdi
  37b174:	00 f0 7f 
  37b177:	48 39 f9             	cmp    %rdi,%rcx
  37b17a:	40 0f 95 c7          	setne  %dil
  37b17e:	48 85 c9             	test   %rcx,%rcx
  37b181:	41 0f 95 c1          	setne  %r9b
  37b185:	41 20 f9             	and    %dil,%r9b
  37b188:	48 bf 00 00 00 00 00 	movabs $0xfff0000000000000,%rdi
  37b18f:	00 f0 ff 
  37b192:	48 01 f9             	add    %rdi,%rcx
  37b195:	48 c1 e9 35          	shr    $0x35,%rcx
  37b199:	81 f9 ff 03 00 00    	cmp    $0x3ff,%ecx
  37b19f:	0f 93 c1             	setae  %cl
  37b1a2:	41 84 c9             	test   %cl,%r9b
  37b1a5:	75 34                	jne    37b1db <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3cdb>
  37b1a7:	c4 c2 b8 f5 4c c5 00 	bzhi   %r8,0x0(%r13,%rax,8),%rcx
  37b1ae:	48 b8 01 00 00 00 00 	movabs $0x7ff0000000000001,%rax
  37b1b5:	00 f0 7f 
  37b1b8:	48 39 c1             	cmp    %rax,%rcx
  37b1bb:	40 0f 9c c7          	setl   %dil
  37b1bf:	48 ff c9             	dec    %rcx
  37b1c2:	48 b8 fe ff ff ff ff 	movabs $0xffffffffffffe,%rax
  37b1c9:	ff 0f 00 
  37b1cc:	48 39 c1             	cmp    %rax,%rcx
  37b1cf:	0f 97 c1             	seta   %cl
  37b1d2:	40 84 f9             	test   %dil,%cl
  37b1d5:	0f 85 c9 00 00 00    	jne    37b2a4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3da4>
  37b1db:	31 ff                	xor    %edi,%edi
  37b1dd:	39 d7                	cmp    %edx,%edi
  37b1df:	0f 82 16 0d 00 00    	jb     37befb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x49fb>
  37b1e5:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  37b1ea:	48 8d 3c 00          	lea    (%rax,%rax,1),%rdi
  37b1ee:	48 3b 7c 24 20       	cmp    0x20(%rsp),%rdi
  37b1f3:	0f 83 ab 0e 00 00    	jae    37c0a4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4ba4>
  37b1f9:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
  37b200:	00 
  37b201:	48 8d 1c 41          	lea    (%rcx,%rax,2),%rbx
  37b205:	48 89 c8             	mov    %rcx,%rax
  37b208:	48 89 f9             	mov    %rdi,%rcx
  37b20b:	48 c1 e1 04          	shl    $0x4,%rcx
  37b20f:	4c 8b 4c 24 58       	mov    0x58(%rsp),%r9
  37b214:	c5 fb 10 04 24       	vmovsd (%rsp),%xmm0
  37b219:	c4 c1 7b 11 04 09    	vmovsd %xmm0,(%r9,%rcx,1)
  37b21f:	c4 41 7b 11 5c 09 08 	vmovsd %xmm11,0x8(%r9,%rcx,1)
  37b226:	48 3b 9c 24 10 01 00 	cmp    0x110(%rsp),%rbx
  37b22d:	00 
  37b22e:	73 22                	jae    37b252 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d52>
  37b230:	48 ff c7             	inc    %rdi
  37b233:	48 3b 7c 24 20       	cmp    0x20(%rsp),%rdi
  37b238:	0f 83 df 0e 00 00    	jae    37c11d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c1d>
  37b23e:	48 c1 e7 04          	shl    $0x4,%rdi
  37b242:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  37b247:	c5 7b 11 0c 39       	vmovsd %xmm9,(%rcx,%rdi,1)
  37b24c:	c5 7b 11 54 39 08    	vmovsd %xmm10,0x8(%rcx,%rdi,1)
  37b252:	48 83 c3 02          	add    $0x2,%rbx
  37b256:	48 89 df             	mov    %rbx,%rdi
  37b259:	48 29 c7             	sub    %rax,%rdi
  37b25c:	48 3b 7c 24 20       	cmp    0x20(%rsp),%rdi
  37b261:	0f 83 3d 0e 00 00    	jae    37c0a4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4ba4>
  37b267:	48 89 f9             	mov    %rdi,%rcx
  37b26a:	48 c1 e1 04          	shl    $0x4,%rcx
  37b26e:	4c 8b 4c 24 58       	mov    0x58(%rsp),%r9
  37b273:	c4 c1 7b 11 2c 09    	vmovsd %xmm5,(%r9,%rcx,1)
  37b279:	c4 c1 7b 11 7c 09 08 	vmovsd %xmm7,0x8(%r9,%rcx,1)
  37b280:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  37b287:	00 
  37b288:	48 39 cb             	cmp    %rcx,%rbx
  37b28b:	0f 83 8f f7 ff ff    	jae    37aa20 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3520>
  37b291:	48 ff c7             	inc    %rdi
  37b294:	48 3b 7c 24 20       	cmp    0x20(%rsp),%rdi
  37b299:	0f 82 6b f7 ff ff    	jb     37aa0a <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x350a>
  37b29f:	e9 79 0e 00 00       	jmp    37c11d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c1d>
  37b2a4:	83 fa 01             	cmp    $0x1,%edx
  37b2a7:	0f 84 38 ff ff ff    	je     37b1e5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3ce5>
  37b2ad:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  37b2b2:	c4 e2 b8 f5 4c c5 08 	bzhi   %r8,0x8(%rbp,%rax,8),%rcx
  37b2b9:	48 bb 00 00 00 00 00 	movabs $0x7ff0000000000000,%rbx
  37b2c0:	00 f0 7f 
  37b2c3:	48 39 d9             	cmp    %rbx,%rcx
  37b2c6:	40 0f 95 c7          	setne  %dil
  37b2ca:	48 85 c9             	test   %rcx,%rcx
  37b2cd:	41 0f 95 c1          	setne  %r9b
  37b2d1:	41 20 f9             	and    %dil,%r9b
  37b2d4:	48 bf 00 00 00 00 00 	movabs $0xfff0000000000000,%rdi
  37b2db:	00 f0 ff 
  37b2de:	48 01 f9             	add    %rdi,%rcx
  37b2e1:	48 c1 e9 35          	shr    $0x35,%rcx
  37b2e5:	81 f9 ff 03 00 00    	cmp    $0x3ff,%ecx
  37b2eb:	0f 93 c1             	setae  %cl
  37b2ee:	bf 01 00 00 00       	mov    $0x1,%edi
  37b2f3:	41 84 c9             	test   %cl,%r9b
  37b2f6:	0f 85 e1 fe ff ff    	jne    37b1dd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3cdd>
  37b2fc:	c4 c2 b8 f5 4c c5 08 	bzhi   %r8,0x8(%r13,%rax,8),%rcx
  37b303:	48 39 d9             	cmp    %rbx,%rcx
  37b306:	41 0f 9f c1          	setg   %r9b
  37b30a:	48 ff c9             	dec    %rcx
  37b30d:	48 b8 ff ff ff ff ff 	movabs $0xfffffffffffff,%rax
  37b314:	ff 0f 00 
  37b317:	48 39 c1             	cmp    %rax,%rcx
  37b31a:	0f 92 c1             	setb   %cl
  37b31d:	44 08 c9             	or     %r9b,%cl
  37b320:	0f 85 b7 fe ff ff    	jne    37b1dd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3cdd>
  37b326:	83 fa 02             	cmp    $0x2,%edx
  37b329:	0f 84 b6 fe ff ff    	je     37b1e5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3ce5>
  37b32f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  37b334:	c4 e2 b8 f5 4c c5 10 	bzhi   %r8,0x10(%rbp,%rax,8),%rcx
  37b33b:	48 b8 00 00 00 00 00 	movabs $0x7ff0000000000000,%rax
  37b342:	00 f0 7f 
  37b345:	48 39 c1             	cmp    %rax,%rcx
  37b348:	40 0f 95 c7          	setne  %dil
  37b34c:	48 85 c9             	test   %rcx,%rcx
  37b34f:	41 0f 95 c1          	setne  %r9b
  37b353:	41 20 f9             	and    %dil,%r9b
  37b356:	48 b8 00 00 00 00 00 	movabs $0xfff0000000000000,%rax
  37b35d:	00 f0 ff 
  37b360:	48 01 c1             	add    %rax,%rcx
  37b363:	48 c1 e9 35          	shr    $0x35,%rcx
  37b367:	81 f9 ff 03 00 00    	cmp    $0x3ff,%ecx
  37b36d:	0f 93 c1             	setae  %cl
  37b370:	bf 02 00 00 00       	mov    $0x2,%edi
  37b375:	41 84 c9             	test   %cl,%r9b
  37b378:	0f 85 5f fe ff ff    	jne    37b1dd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3cdd>
  37b37e:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  37b383:	c4 c2 b8 f5 4c c5 10 	bzhi   %r8,0x10(%r13,%rax,8),%rcx
  37b38a:	48 b8 00 00 00 00 00 	movabs $0x7ff0000000000000,%rax
  37b391:	00 f0 7f 
  37b394:	48 39 c1             	cmp    %rax,%rcx
  37b397:	41 0f 9f c1          	setg   %r9b
  37b39b:	48 ff c9             	dec    %rcx
  37b39e:	48 b8 ff ff ff ff ff 	movabs $0xfffffffffffff,%rax
  37b3a5:	ff 0f 00 
  37b3a8:	48 39 c1             	cmp    %rax,%rcx
  37b3ab:	0f 92 c1             	setb   %cl
  37b3ae:	44 08 c9             	or     %r9b,%cl
  37b3b1:	0f 85 26 fe ff ff    	jne    37b1dd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3cdd>
  37b3b7:	e9 29 fe ff ff       	jmp    37b1e5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3ce5>
  37b3bc:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  37b3c3:	00 
  37b3c4:	48 89 c1             	mov    %rax,%rcx
  37b3c7:	48 c1 e9 02          	shr    $0x2,%rcx
  37b3cb:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
  37b3d0:	89 c1                	mov    %eax,%ecx
  37b3d2:	83 e1 03             	and    $0x3,%ecx
  37b3d5:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  37b3dc:	00 
  37b3dd:	48 89 c1             	mov    %rax,%rcx
  37b3e0:	48 b8 fc ff ff ff ff 	movabs $0xffffffffffffffc,%rax
  37b3e7:	ff ff 0f 
  37b3ea:	48 21 c1             	and    %rax,%rcx
  37b3ed:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  37b3f2:	41 b3 01             	mov    $0x1,%r11b
  37b3f5:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  37b3fc:	00 
  37b3fd:	4c 8b 4c 24 68       	mov    0x68(%rsp),%r9
  37b402:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  37b407:	4c 8b 54 24 70       	mov    0x70(%rsp),%r10
  37b40c:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  37b413:	00 
  37b414:	48 ff c8             	dec    %rax
  37b417:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  37b41e:	00 
  37b41f:	49 39 c4             	cmp    %rax,%r12
  37b422:	0f 83 05 06 00 00    	jae    37ba2d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x452d>
  37b428:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  37b42f:	00 
  37b430:	49 39 c4             	cmp    %rax,%r12
  37b433:	49 0f 47 c4          	cmova  %r12,%rax
  37b437:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
  37b43e:	00 
  37b43f:	49 39 f4             	cmp    %rsi,%r12
  37b442:	49 0f 47 f4          	cmova  %r12,%rsi
  37b446:	48 89 b4 24 f0 00 00 	mov    %rsi,0xf0(%rsp)
  37b44d:	00 
  37b44e:	48 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%rcx
  37b455:	00 
  37b456:	49 39 ca             	cmp    %rcx,%r10
  37b459:	49 0f 42 ca          	cmovb  %r10,%rcx
  37b45d:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  37b462:	48 39 c8             	cmp    %rcx,%rax
  37b465:	48 0f 42 c8          	cmovb  %rax,%rcx
  37b469:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
  37b470:	00 
  37b471:	48 39 c8             	cmp    %rcx,%rax
  37b474:	48 0f 42 c8          	cmovb  %rax,%rcx
  37b478:	48 89 8c 24 d0 01 00 	mov    %rcx,0x1d0(%rsp)
  37b47f:	00 
  37b480:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  37b487:	00 
  37b488:	48 39 d0             	cmp    %rdx,%rax
  37b48b:	48 0f 42 d0          	cmovb  %rax,%rdx
  37b48f:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  37b496:	00 
  37b497:	48 39 d0             	cmp    %rdx,%rax
  37b49a:	48 0f 42 d0          	cmovb  %rax,%rdx
  37b49e:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  37b4a3:	48 39 d0             	cmp    %rdx,%rax
  37b4a6:	48 0f 42 d0          	cmovb  %rax,%rdx
  37b4aa:	48 89 94 24 20 02 00 	mov    %rdx,0x220(%rsp)
  37b4b1:	00 
  37b4b2:	c4 e2 7d 19 15 35 93 	vbroadcastsd -0x2f6ccb(%rip),%ymm2        # 847f0 <anon.890d649631ab6ab37a03cdc207a0d7b9.388.llvm.3426226200983260467+0x160>
  37b4b9:	d0 ff 
  37b4bb:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  37b4bf:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  37b4c6:	00 
  37b4c7:	49 89 c7             	mov    %rax,%r15
  37b4ca:	c5 7d 29 e1          	vmovapd %ymm12,%ymm1
  37b4ce:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  37b4d3:	eb 3c                	jmp    37b511 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4011>
  37b4d5:	c5 dd 54 c9          	vandpd %ymm1,%ymm4,%ymm1
  37b4d9:	45 20 f3             	and    %r14b,%r11b
  37b4dc:	49 ff c4             	inc    %r12
  37b4df:	48 8b b4 24 38 01 00 	mov    0x138(%rsp),%rsi
  37b4e6:	00 
  37b4e7:	49 89 f6             	mov    %rsi,%r14
  37b4ea:	4d 89 e8             	mov    %r13,%r8
  37b4ed:	49 89 c7             	mov    %rax,%r15
  37b4f0:	48 89 f0             	mov    %rsi,%rax
  37b4f3:	48 89 da             	mov    %rbx,%rdx
  37b4f6:	4c 89 94 24 38 01 00 	mov    %r10,0x138(%rsp)
  37b4fd:	00 
  37b4fe:	4c 3b a4 24 a8 00 00 	cmp    0xa8(%rsp),%r12
  37b505:	00 
  37b506:	4c 8b 4c 24 68       	mov    0x68(%rsp),%r9
  37b50b:	0f 84 45 05 00 00    	je     37ba56 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4556>
  37b511:	4c 3b a4 24 50 01 00 	cmp    0x150(%rsp),%r12
  37b518:	00 
  37b519:	0f 84 ae 0b 00 00    	je     37c0cd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4bcd>
  37b51f:	4d 89 fa             	mov    %r15,%r10
  37b522:	48 89 eb             	mov    %rbp,%rbx
  37b525:	4c 3b a4 24 f0 00 00 	cmp    0xf0(%rsp),%r12
  37b52c:	00 
  37b52d:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  37b534:	00 
  37b535:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
  37b53c:	00 
  37b53d:	4c 89 e7             	mov    %r12,%rdi
  37b540:	4c 8b a4 24 98 00 00 	mov    0x98(%rsp),%r12
  37b547:	00 
  37b548:	4c 8b b4 24 38 01 00 	mov    0x138(%rsp),%r14
  37b54f:	00 
  37b550:	48 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%rbp
  37b557:	00 
  37b558:	0f 84 8f 0b 00 00    	je     37c0ed <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4bed>
  37b55e:	48 8b b4 24 a0 01 00 	mov    0x1a0(%rsp),%rsi
  37b565:	00 
  37b566:	c4 e2 7d 19 34 fe    	vbroadcastsd (%rsi,%rdi,8),%ymm6
  37b56c:	48 8b b4 24 98 01 00 	mov    0x198(%rsp),%rsi
  37b573:	00 
  37b574:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  37b579:	c4 e2 7d 19 2c fe    	vbroadcastsd (%rsi,%rdi,8),%ymm5
  37b57f:	4d 89 f0             	mov    %r14,%r8
  37b582:	49 c1 e8 02          	shr    $0x2,%r8
  37b586:	4c 89 d7             	mov    %r10,%rdi
  37b589:	48 c1 ef 02          	shr    $0x2,%rdi
  37b58d:	48 8b b4 24 d0 01 00 	mov    0x1d0(%rsp),%rsi
  37b594:	00 
  37b595:	48 39 f7             	cmp    %rsi,%rdi
  37b598:	48 0f 43 fe          	cmovae %rsi,%rdi
  37b59c:	48 89 c6             	mov    %rax,%rsi
  37b59f:	48 c1 ee 02          	shr    $0x2,%rsi
  37b5a3:	48 39 fe             	cmp    %rdi,%rsi
  37b5a6:	48 0f 43 f7          	cmovae %rdi,%rsi
  37b5aa:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  37b5af:	48 39 f7             	cmp    %rsi,%rdi
  37b5b2:	48 0f 42 f7          	cmovb  %rdi,%rsi
  37b5b6:	48 39 f5             	cmp    %rsi,%rbp
  37b5b9:	48 0f 42 f5          	cmovb  %rbp,%rsi
  37b5bd:	49 39 f0             	cmp    %rsi,%r8
  37b5c0:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
  37b5c5:	49 0f 42 f0          	cmovb  %r8,%rsi
  37b5c9:	48 85 f6             	test   %rsi,%rsi
  37b5cc:	0f 84 8f 00 00 00    	je     37b661 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4161>
  37b5d2:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  37b5d7:	31 ff                	xor    %edi,%edi
  37b5d9:	c5 7d 29 e4          	vmovapd %ymm12,%ymm4
  37b5dd:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  37b5e1:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  37b5e5:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  37b5ea:	4c 8b 84 24 88 00 00 	mov    0x88(%rsp),%r8
  37b5f1:	00 
  37b5f2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  37b5f9:	1f 84 00 00 00 00 00 
  37b600:	c4 41 7d 10 4c 3d 00 	vmovupd 0x0(%r13,%rdi,1),%ymm9
  37b607:	c4 42 b5 b8 04 39    	vfmadd231pd (%r9,%rdi,1),%ymm9,%ymm8
  37b60d:	c4 e2 b5 b8 3c 39    	vfmadd231pd (%rcx,%rdi,1),%ymm9,%ymm7
  37b613:	c4 c2 b5 b8 04 3f    	vfmadd231pd (%r15,%rdi,1),%ymm9,%ymm0
  37b619:	c4 42 b5 b8 14 3c    	vfmadd231pd (%r12,%rdi,1),%ymm9,%ymm10
  37b61f:	c4 41 7d 10 1c 38    	vmovupd (%r8,%rdi,1),%ymm11
  37b625:	c4 62 cd a8 dd       	vfmadd213pd %ymm5,%ymm6,%ymm11
  37b62a:	c4 62 b5 a8 1c 3b    	vfmadd213pd (%rbx,%rdi,1),%ymm9,%ymm11
  37b630:	c4 62 7d 19 0d ff 98 	vbroadcastsd -0x2f6701(%rip),%ymm9        # 84f38 <anon.890d649631ab6ab37a03cdc207a0d7b9.203.llvm.3426226200983260467+0x10>
  37b637:	d0 ff 
  37b639:	c5 7d 11 1c 3a       	vmovupd %ymm11,(%rdx,%rdi,1)
  37b63e:	c4 41 25 54 c9       	vandpd %ymm9,%ymm11,%ymm9
  37b643:	c5 35 c2 db 00       	vcmpeqpd %ymm3,%ymm9,%ymm11
  37b648:	c5 35 c2 ca 1d       	vcmpge_oqpd %ymm2,%ymm9,%ymm9
  37b64d:	c4 41 35 56 cb       	vorpd  %ymm11,%ymm9,%ymm9
  37b652:	c5 b5 54 e4          	vandpd %ymm4,%ymm9,%ymm4
  37b656:	48 83 c7 20          	add    $0x20,%rdi
  37b65a:	48 ff ce             	dec    %rsi
  37b65d:	75 a1                	jne    37b600 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4100>
  37b65f:	eb 16                	jmp    37b677 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4177>
  37b661:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  37b666:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  37b66a:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  37b66e:	c4 41 29 57 d2       	vxorpd %xmm10,%xmm10,%xmm10
  37b673:	c5 7d 29 e4          	vmovapd %ymm12,%ymm4
  37b677:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  37b67c:	4c 89 2c 24          	mov    %r13,(%rsp)
  37b680:	45 89 f0             	mov    %r14d,%r8d
  37b683:	41 83 e0 03          	and    $0x3,%r8d
  37b687:	4c 89 f6             	mov    %r14,%rsi
  37b68a:	48 b9 fc ff ff ff ff 	movabs $0xffffffffffffffc,%rcx
  37b691:	ff ff 0f 
  37b694:	48 21 ce             	and    %rcx,%rsi
  37b697:	c4 43 7d 19 c1 01    	vextractf128 $0x1,%ymm8,%xmm9
  37b69d:	c4 41 39 58 c1       	vaddpd %xmm9,%xmm8,%xmm8
  37b6a2:	c4 41 39 c6 c8 01    	vshufpd $0x1,%xmm8,%xmm8,%xmm9
  37b6a8:	c4 41 3b 58 c1       	vaddsd %xmm9,%xmm8,%xmm8
  37b6ad:	c4 c3 7d 19 f9 01    	vextractf128 $0x1,%ymm7,%xmm9
  37b6b3:	c5 b1 58 ff          	vaddpd %xmm7,%xmm9,%xmm7
  37b6b7:	c5 41 c6 cf 01       	vshufpd $0x1,%xmm7,%xmm7,%xmm9
  37b6bc:	c5 33 58 cf          	vaddsd %xmm7,%xmm9,%xmm9
  37b6c0:	c4 e3 7d 19 c7 01    	vextractf128 $0x1,%ymm0,%xmm7
  37b6c6:	c5 f9 58 c7          	vaddpd %xmm7,%xmm0,%xmm0
  37b6ca:	c5 f9 c6 f8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm7
  37b6cf:	c5 fb 58 ff          	vaddsd %xmm7,%xmm0,%xmm7
  37b6d3:	c4 63 7d 19 d0 01    	vextractf128 $0x1,%ymm10,%xmm0
  37b6d9:	c5 a9 58 c0          	vaddpd %xmm0,%xmm10,%xmm0
  37b6dd:	44 89 d7             	mov    %r10d,%edi
  37b6e0:	83 e7 03             	and    $0x3,%edi
  37b6e3:	48 8b 94 24 20 02 00 	mov    0x220(%rsp),%rdx
  37b6ea:	00 
  37b6eb:	48 39 d7             	cmp    %rdx,%rdi
  37b6ee:	48 0f 43 fa          	cmovae %rdx,%rdi
  37b6f2:	41 89 c6             	mov    %eax,%r14d
  37b6f5:	41 83 e6 03          	and    $0x3,%r14d
  37b6f9:	49 39 fe             	cmp    %rdi,%r14
  37b6fc:	49 0f 42 fe          	cmovb  %r14,%rdi
  37b700:	c5 79 c6 d0 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm10
  37b705:	48 8b 94 24 c8 00 00 	mov    0xc8(%rsp),%rdx
  37b70c:	00 
  37b70d:	48 39 fa             	cmp    %rdi,%rdx
  37b710:	48 0f 42 fa          	cmovb  %rdx,%rdi
  37b714:	c5 2b 58 d0          	vaddsd %xmm0,%xmm10,%xmm10
  37b718:	48 8b 94 24 b0 01 00 	mov    0x1b0(%rsp),%rdx
  37b71f:	00 
  37b720:	48 39 fa             	cmp    %rdi,%rdx
  37b723:	48 0f 42 fa          	cmovb  %rdx,%rdi
  37b727:	49 39 f8             	cmp    %rdi,%r8
  37b72a:	4c 89 84 24 60 01 00 	mov    %r8,0x160(%rsp)
  37b731:	00 
  37b732:	49 0f 42 f8          	cmovb  %r8,%rdi
  37b736:	48 85 ff             	test   %rdi,%rdi
  37b739:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  37b73e:	0f 84 e4 00 00 00    	je     37b828 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4328>
  37b744:	44 88 5c 24 18       	mov    %r11b,0x18(%rsp)
  37b749:	4c 89 fa             	mov    %r15,%rdx
  37b74c:	4d 89 e3             	mov    %r12,%r11
  37b74f:	4d 89 d5             	mov    %r10,%r13
  37b752:	49 21 cd             	and    %rcx,%r13
  37b755:	49 89 c7             	mov    %rax,%r15
  37b758:	49 21 cf             	and    %rcx,%r15
  37b75b:	48 8b 0c 24          	mov    (%rsp),%rcx
  37b75f:	c4 a1 7b 10 04 f9    	vmovsd (%rcx,%r15,8),%xmm0
  37b765:	4c 8b 84 24 88 00 00 	mov    0x88(%rsp),%r8
  37b76c:	00 
  37b76d:	4c 8b 64 24 60       	mov    0x60(%rsp),%r12
  37b772:	c4 01 7b 10 1c e0    	vmovsd (%r8,%r12,8),%xmm11
  37b778:	c4 62 c9 a9 dd       	vfmadd213sd %xmm5,%xmm6,%xmm11
  37b77d:	c4 22 f9 a9 1c eb    	vfmadd213sd (%rbx,%r13,8),%xmm0,%xmm11
  37b783:	c4 41 f9 7e de       	vmovq  %xmm11,%r14
  37b788:	b1 3f                	mov    $0x3f,%cl
  37b78a:	c4 42 f0 f5 f6       	bzhi   %rcx,%r14,%r14
  37b78f:	48 b9 00 00 00 00 00 	movabs $0x7ff0000000000000,%rcx
  37b796:	00 f0 7f 
  37b799:	49 39 ce             	cmp    %rcx,%r14
  37b79c:	41 0f 94 c1          	sete   %r9b
  37b7a0:	4d 85 f6             	test   %r14,%r14
  37b7a3:	0f 94 c1             	sete   %cl
  37b7a6:	44 08 c9             	or     %r9b,%cl
  37b7a9:	49 b9 00 00 00 00 00 	movabs $0xfff0000000000000,%r9
  37b7b0:	00 f0 ff 
  37b7b3:	4d 01 ce             	add    %r9,%r14
  37b7b6:	49 c1 ee 35          	shr    $0x35,%r14
  37b7ba:	41 81 fe ff 03 00 00 	cmp    $0x3ff,%r14d
  37b7c1:	41 0f 92 c6          	setb   %r14b
  37b7c5:	41 08 ce             	or     %cl,%r14b
  37b7c8:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  37b7cd:	48 8b ac 24 20 01 00 	mov    0x120(%rsp),%rbp
  37b7d4:	00 
  37b7d5:	c4 62 f9 b9 04 e9    	vfmadd231sd (%rcx,%rbp,8),%xmm0,%xmm8
  37b7db:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  37b7e2:	00 
  37b7e3:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
  37b7e8:	c4 22 f9 b9 0c c9    	vfmadd231sd (%rcx,%r9,8),%xmm0,%xmm9
  37b7ee:	48 8b 8c 24 40 01 00 	mov    0x140(%rsp),%rcx
  37b7f5:	00 
  37b7f6:	c4 e2 f9 b9 3c ca    	vfmadd231sd (%rdx,%rcx,8),%xmm0,%xmm7
  37b7fc:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
  37b803:	00 
  37b804:	c4 42 f9 b9 14 d3    	vfmadd231sd (%r11,%rdx,8),%xmm0,%xmm10
  37b80a:	4c 8b 5c 24 30       	mov    0x30(%rsp),%r11
  37b80f:	c4 41 7b 11 1c f3    	vmovsd %xmm11,(%r11,%rsi,8)
  37b815:	83 ff 01             	cmp    $0x1,%edi
  37b818:	75 1b                	jne    37b835 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4335>
  37b81a:	4d 89 dd             	mov    %r11,%r13
  37b81d:	44 0f b6 5c 24 18    	movzbl 0x18(%rsp),%r11d
  37b823:	e9 8b 01 00 00       	jmp    37b9b3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x44b3>
  37b828:	41 b6 01             	mov    $0x1,%r14b
  37b82b:	4c 8b 6c 24 30       	mov    0x30(%rsp),%r13
  37b830:	e9 7e 01 00 00       	jmp    37b9b3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x44b3>
  37b835:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  37b83c:	00 
  37b83d:	41 b1 3f             	mov    $0x3f,%r9b
  37b840:	48 89 c8             	mov    %rcx,%rax
  37b843:	48 8b 0c 24          	mov    (%rsp),%rcx
  37b847:	c4 a1 7b 10 44 f9 08 	vmovsd 0x8(%rcx,%r15,8),%xmm0
  37b84e:	c4 01 7b 10 5c e0 08 	vmovsd 0x8(%r8,%r12,8),%xmm11
  37b855:	c4 62 c9 a9 dd       	vfmadd213sd %xmm5,%xmm6,%xmm11
  37b85a:	c4 22 f9 a9 5c eb 08 	vfmadd213sd 0x8(%rbx,%r13,8),%xmm0,%xmm11
  37b861:	c4 61 f9 7e d9       	vmovq  %xmm11,%rcx
  37b866:	c4 e2 b0 f5 c9       	bzhi   %r9,%rcx,%rcx
  37b86b:	49 b8 00 00 00 00 00 	movabs $0xfff0000000000000,%r8
  37b872:	00 f0 ff 
  37b875:	4e 8d 0c 01          	lea    (%rcx,%r8,1),%r9
  37b879:	49 c1 e9 35          	shr    $0x35,%r9
  37b87d:	41 81 f9 ff 03 00 00 	cmp    $0x3ff,%r9d
  37b884:	45 0f b6 ce          	movzbl %r14b,%r9d
  37b888:	41 be 00 00 00 00    	mov    $0x0,%r14d
  37b88e:	45 0f 42 f1          	cmovb  %r9d,%r14d
  37b892:	49 b8 00 00 00 00 00 	movabs $0x7ff0000000000000,%r8
  37b899:	00 f0 7f 
  37b89c:	4c 39 c1             	cmp    %r8,%rcx
  37b89f:	45 0f 44 f1          	cmove  %r9d,%r14d
  37b8a3:	48 85 c9             	test   %rcx,%rcx
  37b8a6:	45 0f 44 f1          	cmove  %r9d,%r14d
  37b8aa:	4c 8b 4c 24 68       	mov    0x68(%rsp),%r9
  37b8af:	c4 42 f9 b9 44 e9 08 	vfmadd231sd 0x8(%r9,%rbp,8),%xmm0,%xmm8
  37b8b6:	4c 8b a4 24 a0 00 00 	mov    0xa0(%rsp),%r12
  37b8bd:	00 
  37b8be:	48 8b 6c 24 50       	mov    0x50(%rsp),%rbp
  37b8c3:	c4 42 f9 b9 4c ec 08 	vfmadd231sd 0x8(%r12,%rbp,8),%xmm0,%xmm9
  37b8ca:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  37b8d1:	00 
  37b8d2:	c4 e2 f9 b9 7c c1 08 	vfmadd231sd 0x8(%rcx,%rax,8),%xmm0,%xmm7
  37b8d9:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  37b8e0:	00 
  37b8e1:	c4 62 f9 b9 54 d1 08 	vfmadd231sd 0x8(%rcx,%rdx,8),%xmm0,%xmm10
  37b8e8:	c4 41 7b 11 5c f3 08 	vmovsd %xmm11,0x8(%r11,%rsi,8)
  37b8ef:	83 ff 02             	cmp    $0x2,%edi
  37b8f2:	0f 84 aa 00 00 00    	je     37b9a2 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x44a2>
  37b8f8:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  37b8ff:	00 
  37b900:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  37b905:	c4 e2 c9 b9 6c f9 10 	vfmadd231sd 0x10(%rcx,%rdi,8),%xmm6,%xmm5
  37b90c:	48 8b 0c 24          	mov    (%rsp),%rcx
  37b910:	c4 a1 7b 10 44 f9 10 	vmovsd 0x10(%rcx,%r15,8),%xmm0
  37b917:	c4 a2 f9 a9 6c eb 10 	vfmadd213sd 0x10(%rbx,%r13,8),%xmm0,%xmm5
  37b91e:	c4 e1 f9 7e e9       	vmovq  %xmm5,%rcx
  37b923:	40 b7 3f             	mov    $0x3f,%dil
  37b926:	c4 e2 c0 f5 c9       	bzhi   %rdi,%rcx,%rcx
  37b92b:	48 b8 00 00 00 00 00 	movabs $0xfff0000000000000,%rax
  37b932:	00 f0 ff 
  37b935:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
  37b939:	48 c1 ef 35          	shr    $0x35,%rdi
  37b93d:	81 ff ff 03 00 00    	cmp    $0x3ff,%edi
  37b943:	41 0f b6 fe          	movzbl %r14b,%edi
  37b947:	41 be 00 00 00 00    	mov    $0x0,%r14d
  37b94d:	44 0f 42 f7          	cmovb  %edi,%r14d
  37b951:	4c 39 c1             	cmp    %r8,%rcx
  37b954:	44 0f 44 f7          	cmove  %edi,%r14d
  37b958:	48 85 c9             	test   %rcx,%rcx
  37b95b:	44 0f 44 f7          	cmove  %edi,%r14d
  37b95f:	48 8b 8c 24 20 01 00 	mov    0x120(%rsp),%rcx
  37b966:	00 
  37b967:	c4 42 f9 b9 44 c9 10 	vfmadd231sd 0x10(%r9,%rcx,8),%xmm0,%xmm8
  37b96e:	c4 42 f9 b9 4c ec 10 	vfmadd231sd 0x10(%r12,%rbp,8),%xmm0,%xmm9
  37b975:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  37b97c:	00 
  37b97d:	48 8b bc 24 40 01 00 	mov    0x140(%rsp),%rdi
  37b984:	00 
  37b985:	c4 e2 f9 b9 7c f9 10 	vfmadd231sd 0x10(%rcx,%rdi,8),%xmm0,%xmm7
  37b98c:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  37b993:	00 
  37b994:	c4 62 f9 b9 54 d1 10 	vfmadd231sd 0x10(%rcx,%rdx,8),%xmm0,%xmm10
  37b99b:	c4 c1 7b 11 6c f3 10 	vmovsd %xmm5,0x10(%r11,%rsi,8)
  37b9a2:	4d 89 dd             	mov    %r11,%r13
  37b9a5:	44 0f b6 5c 24 18    	movzbl 0x18(%rsp),%r11d
  37b9ab:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  37b9b2:	00 
  37b9b3:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
  37b9b8:	4b 8d 3c 24          	lea    (%r12,%r12,1),%rdi
  37b9bc:	48 3b 7c 24 20       	cmp    0x20(%rsp),%rdi
  37b9c1:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
  37b9c8:	00 
  37b9c9:	0f 83 d5 06 00 00    	jae    37c0a4 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4ba4>
  37b9cf:	4a 8d 0c 61          	lea    (%rcx,%r12,2),%rcx
  37b9d3:	49 89 f9             	mov    %rdi,%r9
  37b9d6:	49 c1 e1 04          	shl    $0x4,%r9
  37b9da:	4c 8b 7c 24 58       	mov    0x58(%rsp),%r15
  37b9df:	c4 01 7b 11 04 0f    	vmovsd %xmm8,(%r15,%r9,1)
  37b9e5:	c4 01 7b 11 4c 0f 08 	vmovsd %xmm9,0x8(%r15,%r9,1)
  37b9ec:	4c 8b 8c 24 10 01 00 	mov    0x110(%rsp),%r9
  37b9f3:	00 
  37b9f4:	4c 39 c9             	cmp    %r9,%rcx
  37b9f7:	4c 89 c9             	mov    %r9,%rcx
  37b9fa:	48 8b 2c 24          	mov    (%rsp),%rbp
  37b9fe:	0f 83 d1 fa ff ff    	jae    37b4d5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3fd5>
  37ba04:	48 ff c7             	inc    %rdi
  37ba07:	48 3b 7c 24 20       	cmp    0x20(%rsp),%rdi
  37ba0c:	0f 83 0b 07 00 00    	jae    37c11d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4c1d>
  37ba12:	48 c1 e7 04          	shl    $0x4,%rdi
  37ba16:	4c 8b 4c 24 58       	mov    0x58(%rsp),%r9
  37ba1b:	c4 c1 7b 11 3c 39    	vmovsd %xmm7,(%r9,%rdi,1)
  37ba21:	c4 41 7b 11 54 39 08 	vmovsd %xmm10,0x8(%r9,%rdi,1)
  37ba28:	e9 a8 fa ff ff       	jmp    37b4d5 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3fd5>
  37ba2d:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  37ba34:	00 
  37ba35:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  37ba3c:	00 
  37ba3d:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  37ba42:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  37ba47:	c5 7d 29 e1          	vmovapd %ymm12,%ymm1
  37ba4b:	4c 8b b4 24 00 01 00 	mov    0x100(%rsp),%r14
  37ba52:	00 
  37ba53:	4d 89 e8             	mov    %r13,%r8
  37ba56:	44 88 5c 24 18       	mov    %r11b,0x18(%rsp)
  37ba5b:	48 8b 84 24 78 01 00 	mov    0x178(%rsp),%rax
  37ba62:	00 
  37ba63:	48 c1 e8 03          	shr    $0x3,%rax
  37ba67:	48 8b 94 24 80 01 00 	mov    0x180(%rsp),%rdx
  37ba6e:	00 
  37ba6f:	48 c1 ea 03          	shr    $0x3,%rdx
  37ba73:	48 39 c2             	cmp    %rax,%rdx
  37ba76:	48 0f 43 d0          	cmovae %rax,%rdx
  37ba7a:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  37ba81:	00 
  37ba82:	48 c1 e8 03          	shr    $0x3,%rax
  37ba86:	48 39 d0             	cmp    %rdx,%rax
  37ba89:	48 0f 43 c2          	cmovae %rdx,%rax
  37ba8d:	48 8b 94 24 90 01 00 	mov    0x190(%rsp),%rdx
  37ba94:	00 
  37ba95:	48 c1 ea 03          	shr    $0x3,%rdx
  37ba99:	48 39 c2             	cmp    %rax,%rdx
  37ba9c:	48 0f 43 d0          	cmovae %rax,%rdx
  37baa0:	4d 89 f2             	mov    %r14,%r10
  37baa3:	49 c1 ea 03          	shr    $0x3,%r10
  37baa7:	49 39 d2             	cmp    %rdx,%r10
  37baaa:	4c 0f 43 d2          	cmovae %rdx,%r10
  37baae:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  37bab5:	00 
  37bab6:	48 c1 e8 03          	shr    $0x3,%rax
  37baba:	4c 39 d0             	cmp    %r10,%rax
  37babd:	49 0f 43 c2          	cmovae %r10,%rax
  37bac1:	48 85 c0             	test   %rax,%rax
  37bac4:	0f 84 e9 00 00 00    	je     37bbb3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x46b3>
  37baca:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  37bace:	ba 20 00 00 00       	mov    $0x20,%edx
  37bad3:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  37bad7:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  37badb:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  37bae0:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  37bae4:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  37bae8:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  37baec:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  37baf0:	4c 8b 54 24 68       	mov    0x68(%rsp),%r10
  37baf5:	4c 8b 9c 24 a0 00 00 	mov    0xa0(%rsp),%r11
  37bafc:	00 
  37bafd:	48 8b 9c 24 80 00 00 	mov    0x80(%rsp),%rbx
  37bb04:	00 
  37bb05:	4c 8b bc 24 98 00 00 	mov    0x98(%rsp),%r15
  37bb0c:	00 
  37bb0d:	4c 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%r13
  37bb14:	00 
  37bb15:	48 8b ac 24 90 00 00 	mov    0x90(%rsp),%rbp
  37bb1c:	00 
  37bb1d:	4c 8b 4c 24 78       	mov    0x78(%rsp),%r9
  37bb22:	c4 41 7d 10 4c 10 e0 	vmovupd -0x20(%r8,%rdx,1),%ymm9
  37bb29:	c4 41 7d 10 14 10    	vmovupd (%r8,%rdx,1),%ymm10
  37bb2f:	c4 c2 b5 b8 54 12 e0 	vfmadd231pd -0x20(%r10,%rdx,1),%ymm9,%ymm2
  37bb36:	c4 c2 b5 b8 64 13 e0 	vfmadd231pd -0x20(%r11,%rdx,1),%ymm9,%ymm4
  37bb3d:	c4 e2 b5 b8 7c 13 e0 	vfmadd231pd -0x20(%rbx,%rdx,1),%ymm9,%ymm7
  37bb44:	c4 42 b5 b8 44 17 e0 	vfmadd231pd -0x20(%r15,%rdx,1),%ymm9,%ymm8
  37bb4b:	c4 c2 ad b8 1c 12    	vfmadd231pd (%r10,%rdx,1),%ymm10,%ymm3
  37bb51:	c4 c2 ad b8 2c 13    	vfmadd231pd (%r11,%rdx,1),%ymm10,%ymm5
  37bb57:	c4 e2 ad b8 04 13    	vfmadd231pd (%rbx,%rdx,1),%ymm10,%ymm0
  37bb5d:	c4 c2 ad b8 34 17    	vfmadd231pd (%r15,%rdx,1),%ymm10,%ymm6
  37bb63:	48 83 c2 40          	add    $0x40,%rdx
  37bb67:	48 ff c8             	dec    %rax
  37bb6a:	75 b6                	jne    37bb22 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4622>
  37bb6c:	e9 88 00 00 00       	jmp    37bbf9 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x46f9>
  37bb71:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  37bb78:	00 
  37bb79:	49 39 c4             	cmp    %rax,%r12
  37bb7c:	0f 83 3e 07 00 00    	jae    37c2c0 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4dc0>
  37bb82:	49 39 f4             	cmp    %rsi,%r12
  37bb85:	0f 83 1f 07 00 00    	jae    37c2aa <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4daa>
  37bb8b:	48 39 c7             	cmp    %rax,%rdi
  37bb8e:	0f 83 4a 07 00 00    	jae    37c2de <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4dde>
  37bb94:	49 89 f8             	mov    %rdi,%r8
  37bb97:	48 39 f7             	cmp    %rsi,%rdi
  37bb9a:	0f 82 9b b9 ff ff    	jb     37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37bba0:	48 8d 15 41 62 4b 00 	lea    0x4b6241(%rip),%rdx        # 831de8 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xb28>
  37bba7:	4c 89 c7             	mov    %r8,%rdi
  37bbaa:	c5 f8 77             	vzeroupper
  37bbad:	ff 15 5d f3 4e 00    	call   *0x4ef35d(%rip)        # 86af10 <_DYNAMIC+0x298>
  37bbb3:	c5 c9 57 f6          	vxorpd %xmm6,%xmm6,%xmm6
  37bbb7:	c5 e9 57 d2          	vxorpd %xmm2,%xmm2,%xmm2
  37bbbb:	c5 d9 57 e4          	vxorpd %xmm4,%xmm4,%xmm4
  37bbbf:	c5 c1 57 ff          	vxorpd %xmm7,%xmm7,%xmm7
  37bbc3:	c4 41 39 57 c0       	vxorpd %xmm8,%xmm8,%xmm8
  37bbc8:	c5 e1 57 db          	vxorpd %xmm3,%xmm3,%xmm3
  37bbcc:	c5 d1 57 ed          	vxorpd %xmm5,%xmm5,%xmm5
  37bbd0:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  37bbd4:	48 8b 9c 24 80 00 00 	mov    0x80(%rsp),%rbx
  37bbdb:	00 
  37bbdc:	4c 8b bc 24 98 00 00 	mov    0x98(%rsp),%r15
  37bbe3:	00 
  37bbe4:	4c 8b ac 24 b0 00 00 	mov    0xb0(%rsp),%r13
  37bbeb:	00 
  37bbec:	48 8b ac 24 90 00 00 	mov    0x90(%rsp),%rbp
  37bbf3:	00 
  37bbf4:	4c 8b 4c 24 78       	mov    0x78(%rsp),%r9
  37bbf9:	41 f6 c6 04          	test   $0x4,%r14b
  37bbfd:	75 1a                	jne    37bc19 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4719>
  37bbff:	4c 8b b4 24 08 01 00 	mov    0x108(%rsp),%r14
  37bc06:	00 
  37bc07:	48 8b b4 24 20 01 00 	mov    0x120(%rsp),%rsi
  37bc0e:	00 
  37bc0f:	4c 8b 5c 24 50       	mov    0x50(%rsp),%r11
  37bc14:	e9 d2 00 00 00       	jmp    37bceb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x47eb>
  37bc19:	f6 84 24 00 01 00 00 	testb  $0x4,0x100(%rsp)
  37bc20:	04 
  37bc21:	4c 8b b4 24 08 01 00 	mov    0x108(%rsp),%r14
  37bc28:	00 
  37bc29:	48 8b b4 24 20 01 00 	mov    0x120(%rsp),%rsi
  37bc30:	00 
  37bc31:	4c 8b 5c 24 50       	mov    0x50(%rsp),%r11
  37bc36:	0f 84 5f 08 00 00    	je     37c49b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4f9b>
  37bc3c:	f6 84 24 78 01 00 00 	testb  $0x4,0x178(%rsp)
  37bc43:	04 
  37bc44:	0f 84 65 08 00 00    	je     37c4af <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4faf>
  37bc4a:	f6 84 24 80 01 00 00 	testb  $0x4,0x180(%rsp)
  37bc51:	04 
  37bc52:	0f 84 6b 08 00 00    	je     37c4c3 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4fc3>
  37bc58:	f6 84 24 88 01 00 00 	testb  $0x4,0x188(%rsp)
  37bc5f:	04 
  37bc60:	0f 84 71 08 00 00    	je     37c4d7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4fd7>
  37bc66:	f6 84 24 90 01 00 00 	testb  $0x4,0x190(%rsp)
  37bc6d:	04 
  37bc6e:	0f 84 77 08 00 00    	je     37c4eb <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4feb>
  37bc74:	48 b8 fe ff ff ff ff 	movabs $0x3fffffffffffffe,%rax
  37bc7b:	ff ff 03 
  37bc7e:	48 8b 94 24 e8 00 00 	mov    0xe8(%rsp),%rdx
  37bc85:	00 
  37bc86:	48 21 c2             	and    %rax,%rdx
  37bc89:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  37bc8e:	48 21 c7             	and    %rax,%rdi
  37bc91:	49 21 c1             	and    %rax,%r9
  37bc94:	4c 8b a4 24 d8 00 00 	mov    0xd8(%rsp),%r12
  37bc9b:	00 
  37bc9c:	49 21 c4             	and    %rax,%r12
  37bc9f:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
  37bca4:	49 21 c2             	and    %rax,%r10
  37bca7:	48 c1 e2 05          	shl    $0x5,%rdx
  37bcab:	48 c1 e7 05          	shl    $0x5,%rdi
  37bcaf:	49 c1 e1 05          	shl    $0x5,%r9
  37bcb3:	49 c1 e4 05          	shl    $0x5,%r12
  37bcb7:	49 c1 e2 05          	shl    $0x5,%r10
  37bcbb:	48 03 54 24 68       	add    0x68(%rsp),%rdx
  37bcc0:	48 03 bc 24 a0 00 00 	add    0xa0(%rsp),%rdi
  37bcc7:	00 
  37bcc8:	49 01 d9             	add    %rbx,%r9
  37bccb:	4d 01 fc             	add    %r15,%r12
  37bcce:	4d 01 c2             	add    %r8,%r10
  37bcd1:	c4 41 7d 10 0a       	vmovupd (%r10),%ymm9
  37bcd6:	c4 e2 b5 b8 12       	vfmadd231pd (%rdx),%ymm9,%ymm2
  37bcdb:	c4 e2 b5 b8 27       	vfmadd231pd (%rdi),%ymm9,%ymm4
  37bce0:	c4 c2 b5 b8 39       	vfmadd231pd (%r9),%ymm9,%ymm7
  37bce5:	c4 42 b5 b8 04 24    	vfmadd231pd (%r12),%ymm9,%ymm8
  37bceb:	c5 bd 58 f6          	vaddpd %ymm6,%ymm8,%ymm6
  37bcef:	c5 fd 58 c7          	vaddpd %ymm7,%ymm0,%ymm0
  37bcf3:	c5 d5 58 e4          	vaddpd %ymm4,%ymm5,%ymm4
  37bcf7:	c5 e5 58 d2          	vaddpd %ymm2,%ymm3,%ymm2
  37bcfb:	c4 e3 7d 19 d3 01    	vextractf128 $0x1,%ymm2,%xmm3
  37bd01:	c5 e9 58 d3          	vaddpd %xmm3,%xmm2,%xmm2
  37bd05:	c5 e9 c6 da 01       	vshufpd $0x1,%xmm2,%xmm2,%xmm3
  37bd0a:	c5 eb 58 d3          	vaddsd %xmm3,%xmm2,%xmm2
  37bd0e:	c4 e3 7d 19 e3 01    	vextractf128 $0x1,%ymm4,%xmm3
  37bd14:	c5 d9 58 db          	vaddpd %xmm3,%xmm4,%xmm3
  37bd18:	c5 e1 c6 e3 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm4
  37bd1d:	c5 e3 58 e4          	vaddsd %xmm4,%xmm3,%xmm4
  37bd21:	c4 e3 7d 19 c3 01    	vextractf128 $0x1,%ymm0,%xmm3
  37bd27:	c5 f9 58 c3          	vaddpd %xmm3,%xmm0,%xmm0
  37bd2b:	c5 f9 c6 d8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm3
  37bd30:	c5 fb 58 c3          	vaddsd %xmm3,%xmm0,%xmm0
  37bd34:	c4 e3 7d 19 f3 01    	vextractf128 $0x1,%ymm6,%xmm3
  37bd3a:	c5 c9 58 db          	vaddpd %xmm3,%xmm6,%xmm3
  37bd3e:	c5 e1 c6 eb 01       	vshufpd $0x1,%xmm3,%xmm3,%xmm5
  37bd43:	c5 e3 58 dd          	vaddsd %xmm5,%xmm3,%xmm3
  37bd47:	48 8b 94 24 60 01 00 	mov    0x160(%rsp),%rdx
  37bd4e:	00 
  37bd4f:	48 85 d2             	test   %rdx,%rdx
  37bd52:	0f 84 ec 00 00 00    	je     37be44 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4944>
  37bd58:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  37bd5d:	49 39 fd             	cmp    %rdi,%r13
  37bd60:	48 89 f8             	mov    %rdi,%rax
  37bd63:	49 0f 42 c5          	cmovb  %r13,%rax
  37bd67:	48 39 e8             	cmp    %rbp,%rax
  37bd6a:	48 0f 43 c5          	cmovae %rbp,%rax
  37bd6e:	48 ff ca             	dec    %rdx
  37bd71:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  37bd76:	4c 39 c8             	cmp    %r9,%rax
  37bd79:	49 0f 43 c1          	cmovae %r9,%rax
  37bd7d:	48 39 c2             	cmp    %rax,%rdx
  37bd80:	48 0f 42 c2          	cmovb  %rdx,%rax
  37bd84:	48 39 c7             	cmp    %rax,%rdi
  37bd87:	0f 84 b9 06 00 00    	je     37c446 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4f46>
  37bd8d:	41 39 c5             	cmp    %eax,%r13d
  37bd90:	0f 84 c3 06 00 00    	je     37c459 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4f59>
  37bd96:	4d 89 cc             	mov    %r9,%r12
  37bd99:	39 c5                	cmp    %eax,%ebp
  37bd9b:	4c 8b 8c 24 60 01 00 	mov    0x160(%rsp),%r9
  37bda2:	00 
  37bda3:	0f 84 c6 06 00 00    	je     37c46f <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4f6f>
  37bda9:	41 39 c4             	cmp    %eax,%r12d
  37bdac:	0f 84 d3 06 00 00    	je     37c485 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4f85>
  37bdb2:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  37bdb7:	c4 c1 7b 10 2c f8    	vmovsd (%r8,%rdi,8),%xmm5
  37bdbd:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  37bdc2:	c4 e2 d1 b9 14 f0    	vfmadd231sd (%rax,%rsi,8),%xmm5,%xmm2
  37bdc8:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
  37bdcf:	00 
  37bdd0:	c4 a2 d1 b9 24 da    	vfmadd231sd (%rdx,%r11,8),%xmm5,%xmm4
  37bdd6:	4c 8b a4 24 40 01 00 	mov    0x140(%rsp),%r12
  37bddd:	00 
  37bdde:	c4 a2 d1 b9 04 e3    	vfmadd231sd (%rbx,%r12,8),%xmm5,%xmm0
  37bde4:	4c 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%r10
  37bdeb:	00 
  37bdec:	c4 82 d1 b9 1c d7    	vfmadd231sd (%r15,%r10,8),%xmm5,%xmm3
  37bdf2:	41 83 f9 01          	cmp    $0x1,%r9d
  37bdf6:	74 4c                	je     37be44 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4944>
  37bdf8:	c4 c1 7b 10 6c f8 08 	vmovsd 0x8(%r8,%rdi,8),%xmm5
  37bdff:	c4 e2 d1 b9 54 f0 08 	vfmadd231sd 0x8(%rax,%rsi,8),%xmm5,%xmm2
  37be06:	c4 a2 d1 b9 64 da 08 	vfmadd231sd 0x8(%rdx,%r11,8),%xmm5,%xmm4
  37be0d:	c4 a2 d1 b9 44 e3 08 	vfmadd231sd 0x8(%rbx,%r12,8),%xmm5,%xmm0
  37be14:	c4 82 d1 b9 5c d7 08 	vfmadd231sd 0x8(%r15,%r10,8),%xmm5,%xmm3
  37be1b:	41 83 f9 02          	cmp    $0x2,%r9d
  37be1f:	74 23                	je     37be44 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4944>
  37be21:	c4 c1 7b 10 6c f8 10 	vmovsd 0x10(%r8,%rdi,8),%xmm5
  37be28:	c4 e2 d1 b9 54 f0 10 	vfmadd231sd 0x10(%rax,%rsi,8),%xmm5,%xmm2
  37be2f:	c4 a2 d1 b9 64 da 10 	vfmadd231sd 0x10(%rdx,%r11,8),%xmm5,%xmm4
  37be36:	c4 a2 d1 b9 44 e3 10 	vfmadd231sd 0x10(%rbx,%r12,8),%xmm5,%xmm0
  37be3d:	c4 82 d1 b9 5c d7 10 	vfmadd231sd 0x10(%r15,%r10,8),%xmm5,%xmm3
  37be44:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  37be49:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffe,%rax
  37be50:	ff 1f 00 
  37be53:	4c 8b 84 24 18 02 00 	mov    0x218(%rsp),%r8
  37be5a:	00 
  37be5b:	49 21 c0             	and    %rax,%r8
  37be5e:	49 8d 78 fe          	lea    -0x2(%r8),%rdi
  37be62:	48 39 f7             	cmp    %rsi,%rdi
  37be65:	44 0f b6 4c 24 18    	movzbl 0x18(%rsp),%r9d
  37be6b:	0f 83 c5 05 00 00    	jae    37c436 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4f36>
  37be71:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
  37be78:	00 
  37be79:	4c 01 c0             	add    %r8,%rax
  37be7c:	48 83 c0 fe          	add    $0xfffffffffffffffe,%rax
  37be80:	48 c1 e7 04          	shl    $0x4,%rdi
  37be84:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
  37be89:	c5 fb 11 14 3a       	vmovsd %xmm2,(%rdx,%rdi,1)
  37be8e:	c5 fb 11 64 3a 08    	vmovsd %xmm4,0x8(%rdx,%rdi,1)
  37be94:	48 39 c8             	cmp    %rcx,%rax
  37be97:	73 23                	jae    37bebc <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x49bc>
  37be99:	49 ff c8             	dec    %r8
  37be9c:	49 39 f0             	cmp    %rsi,%r8
  37be9f:	4c 89 c7             	mov    %r8,%rdi
  37bea2:	0f 83 57 06 00 00    	jae    37c4ff <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4fff>
  37bea8:	48 c1 e7 04          	shl    $0x4,%rdi
  37beac:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  37beb1:	c5 fb 11 04 38       	vmovsd %xmm0,(%rax,%rdi,1)
  37beb6:	c5 fb 11 5c 38 08    	vmovsd %xmm3,0x8(%rax,%rdi,1)
  37bebc:	c5 f9 57 c0          	vxorpd %xmm0,%xmm0,%xmm0
  37bec0:	c4 e2 7d 37 c1       	vpcmpgtq %ymm1,%ymm0,%ymm0
  37bec5:	c4 e2 7d 59 0d f2 8f 	vpbroadcastq -0x2f700e(%rip),%ymm1        # 84ec0 <anon.890d649631ab6ab37a03cdc207a0d7b9.1007.llvm.3426226200983260467+0x658>
  37becc:	d0 ff 
  37bece:	c5 fd db c1          	vpand  %ymm1,%ymm0,%ymm0
  37bed2:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
  37bed8:	c5 f9 5d c1          	vminpd %xmm1,%xmm0,%xmm0
  37bedc:	c5 f9 c6 c8 01       	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  37bee1:	c5 fb 5d c1          	vminsd %xmm1,%xmm0,%xmm0
  37bee5:	31 d2                	xor    %edx,%edx
  37bee7:	c5 f1 57 c9          	vxorpd %xmm1,%xmm1,%xmm1
  37beeb:	c5 f9 2e c1          	vucomisd %xmm1,%xmm0
  37beef:	41 0f b6 c1          	movzbl %r9b,%eax
  37bef3:	0f 46 c2             	cmovbe %edx,%eax
  37bef6:	e9 42 b6 ff ff       	jmp    37753d <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3d>
  37befb:	f0 48 ff 05 a5 20 4f 	lock incq 0x4f20a5(%rip)        # 86dfa8 <rustsht::legendre::scalar_paired::ANALYSIS_PAIR_GROUP_RANGE_DECLINES>
  37bf02:	00 
  37bf03:	e9 33 b6 ff ff       	jmp    37753b <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x3b>
  37bf08:	48 8d 0d d1 5d 4b 00 	lea    0x4b5dd1(%rip),%rcx        # 831ce0 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xa20>
  37bf0f:	31 ff                	xor    %edi,%edi
  37bf11:	48 8b 94 24 50 01 00 	mov    0x150(%rsp),%rdx
  37bf18:	00 
  37bf19:	c5 f8 77             	vzeroupper
  37bf1c:	ff 15 f6 ef 4e 00    	call   *0x4eeff6(%rip)        # 86af18 <_DYNAMIC+0x2a0>
  37bf22:	48 8d 15 57 54 4b 00 	lea    0x4b5457(%rip),%rdx        # 831380 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xc0>
  37bf29:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
  37bf30:	00 
  37bf31:	c5 f8 77             	vzeroupper
  37bf34:	ff 15 d6 ef 4e 00    	call   *0x4eefd6(%rip)        # 86af10 <_DYNAMIC+0x298>
  37bf3a:	48 8d 15 27 54 4b 00 	lea    0x4b5427(%rip),%rdx        # 831368 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xa8>
  37bf41:	48 89 df             	mov    %rbx,%rdi
  37bf44:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  37bf49:	c5 f8 77             	vzeroupper
  37bf4c:	ff 15 be ef 4e 00    	call   *0x4eefbe(%rip)        # 86af10 <_DYNAMIC+0x298>
  37bf52:	48 8d 15 3f 54 4b 00 	lea    0x4b543f(%rip),%rdx        # 831398 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xd8>
  37bf59:	48 89 ef             	mov    %rbp,%rdi
  37bf5c:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  37bf61:	c5 f8 77             	vzeroupper
  37bf64:	ff 15 a6 ef 4e 00    	call   *0x4eefa6(%rip)        # 86af10 <_DYNAMIC+0x298>
  37bf6a:	48 89 d7             	mov    %rdx,%rdi
  37bf6d:	48 8d 15 3c 60 4b 00 	lea    0x4b603c(%rip),%rdx        # 831fb0 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xcf0>
  37bf74:	48 89 fe             	mov    %rdi,%rsi
  37bf77:	c5 f8 77             	vzeroupper
  37bf7a:	ff 15 90 ef 4e 00    	call   *0x4eef90(%rip)        # 86af10 <_DYNAMIC+0x298>
  37bf80:	48 8d 15 f9 5f 4b 00 	lea    0x4b5ff9(%rip),%rdx        # 831f80 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xcc0>
  37bf87:	4c 89 d7             	mov    %r10,%rdi
  37bf8a:	4c 89 d6             	mov    %r10,%rsi
  37bf8d:	c5 f8 77             	vzeroupper
  37bf90:	ff 15 7a ef 4e 00    	call   *0x4eef7a(%rip)        # 86af10 <_DYNAMIC+0x298>
  37bf96:	48 8d 15 2b 60 4b 00 	lea    0x4b602b(%rip),%rdx        # 831fc8 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xd08>
  37bf9d:	4c 89 cf             	mov    %r9,%rdi
  37bfa0:	4c 89 ce             	mov    %r9,%rsi
  37bfa3:	c5 f8 77             	vzeroupper
  37bfa6:	ff 15 64 ef 4e 00    	call   *0x4eef64(%rip)        # 86af10 <_DYNAMIC+0x298>
  37bfac:	48 8d 15 e5 5f 4b 00 	lea    0x4b5fe5(%rip),%rdx        # 831f98 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xcd8>
  37bfb3:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  37bfb8:	48 89 fe             	mov    %rdi,%rsi
  37bfbb:	c5 f8 77             	vzeroupper
  37bfbe:	ff 15 4c ef 4e 00    	call   *0x4eef4c(%rip)        # 86af10 <_DYNAMIC+0x298>
  37bfc4:	48 8d 15 9d 5f 4b 00 	lea    0x4b5f9d(%rip),%rdx        # 831f68 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xca8>
  37bfcb:	48 89 c7             	mov    %rax,%rdi
  37bfce:	48 89 c6             	mov    %rax,%rsi
  37bfd1:	c5 f8 77             	vzeroupper
  37bfd4:	ff 15 36 ef 4e 00    	call   *0x4eef36(%rip)        # 86af10 <_DYNAMIC+0x298>
  37bfda:	48 8d 15 ff 5f 4b 00 	lea    0x4b5fff(%rip),%rdx        # 831fe0 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xd20>
  37bfe1:	48 89 fe             	mov    %rdi,%rsi
  37bfe4:	c5 f8 77             	vzeroupper
  37bfe7:	ff 15 23 ef 4e 00    	call   *0x4eef23(%rip)        # 86af10 <_DYNAMIC+0x298>
  37bfed:	48 8d 15 fc 52 4b 00 	lea    0x4b52fc(%rip),%rdx        # 8312f0 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0x30>
  37bff4:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  37bffb:	00 
  37bffc:	48 89 fe             	mov    %rdi,%rsi
  37bfff:	c5 f8 77             	vzeroupper
  37c002:	ff 15 08 ef 4e 00    	call   *0x4eef08(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c008:	48 8d 15 c9 52 4b 00 	lea    0x4b52c9(%rip),%rdx        # 8312d8 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0x18>
  37c00f:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
  37c016:	00 
  37c017:	48 89 fe             	mov    %rdi,%rsi
  37c01a:	c5 f8 77             	vzeroupper
  37c01d:	ff 15 ed ee 4e 00    	call   *0x4eeeed(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c023:	4c 89 e7             	mov    %r12,%rdi
  37c026:	48 8d 15 cb 5c 4b 00 	lea    0x4b5ccb(%rip),%rdx        # 831cf8 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xa38>
  37c02d:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  37c034:	00 
  37c035:	c5 f8 77             	vzeroupper
  37c038:	ff 15 d2 ee 4e 00    	call   *0x4eeed2(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c03e:	4c 89 e7             	mov    %r12,%rdi
  37c041:	48 8d 15 c8 5c 4b 00 	lea    0x4b5cc8(%rip),%rdx        # 831d10 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xa50>
  37c048:	48 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%rsi
  37c04f:	00 
  37c050:	c5 f8 77             	vzeroupper
  37c053:	ff 15 b7 ee 4e 00    	call   *0x4eeeb7(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c059:	48 8d 15 f0 52 4b 00 	lea    0x4b52f0(%rip),%rdx        # 831350 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0x90>
  37c060:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  37c065:	48 89 fe             	mov    %rdi,%rsi
  37c068:	c5 f8 77             	vzeroupper
  37c06b:	ff 15 9f ee 4e 00    	call   *0x4eee9f(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c071:	48 8d 15 38 53 4b 00 	lea    0x4b5338(%rip),%rdx        # 8313b0 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xf0>
  37c078:	48 89 c7             	mov    %rax,%rdi
  37c07b:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  37c080:	c5 f8 77             	vzeroupper
  37c083:	ff 15 87 ee 4e 00    	call   *0x4eee87(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c089:	48 8d 15 38 53 4b 00 	lea    0x4b5338(%rip),%rdx        # 8313c8 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0x108>
  37c090:	48 89 c7             	mov    %rax,%rdi
  37c093:	48 8b b4 24 d0 01 00 	mov    0x1d0(%rsp),%rsi
  37c09a:	00 
  37c09b:	c5 f8 77             	vzeroupper
  37c09e:	ff 15 6c ee 4e 00    	call   *0x4eee6c(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c0a4:	48 8d 15 1d 68 4b 00 	lea    0x4b681d(%rip),%rdx        # 8328c8 <anon.32a531e794c2355d36f56847bc5de751.278.llvm.11216980332326776229+0x240>
  37c0ab:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  37c0b0:	c5 f8 77             	vzeroupper
  37c0b3:	ff 15 57 ee 4e 00    	call   *0x4eee57(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c0b9:	31 ff                	xor    %edi,%edi
  37c0bb:	48 8d 15 36 68 4b 00 	lea    0x4b6836(%rip),%rdx        # 8328f8 <anon.32a531e794c2355d36f56847bc5de751.278.llvm.11216980332326776229+0x270>
  37c0c2:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  37c0c7:	ff 15 43 ee 4e 00    	call   *0x4eee43(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c0cd:	48 8d 15 9c 5c 4b 00 	lea    0x4b5c9c(%rip),%rdx        # 831d70 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xab0>
  37c0d4:	48 8b bc 24 50 01 00 	mov    0x150(%rsp),%rdi
  37c0db:	00 
  37c0dc:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  37c0e3:	00 
  37c0e4:	c5 f8 77             	vzeroupper
  37c0e7:	ff 15 23 ee 4e 00    	call   *0x4eee23(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c0ed:	48 8d 15 94 5c 4b 00 	lea    0x4b5c94(%rip),%rdx        # 831d88 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xac8>
  37c0f4:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  37c0fb:	00 
  37c0fc:	48 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%rsi
  37c103:	00 
  37c104:	c5 f8 77             	vzeroupper
  37c107:	ff 15 03 ee 4e 00    	call   *0x4eee03(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c10d:	48 8d 15 9c 5b 4b 00 	lea    0x4b5b9c(%rip),%rdx        # 831cb0 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0x9f0>
  37c114:	c5 f8 77             	vzeroupper
  37c117:	ff 15 f3 ed 4e 00    	call   *0x4eedf3(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c11d:	48 8d 15 bc 67 4b 00 	lea    0x4b67bc(%rip),%rdx        # 8328e0 <anon.32a531e794c2355d36f56847bc5de751.278.llvm.11216980332326776229+0x258>
  37c124:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  37c129:	c5 f8 77             	vzeroupper
  37c12c:	ff 15 de ed 4e 00    	call   *0x4eedde(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c132:	bf 01 00 00 00       	mov    $0x1,%edi
  37c137:	48 8d 15 d2 67 4b 00 	lea    0x4b67d2(%rip),%rdx        # 832910 <anon.32a531e794c2355d36f56847bc5de751.278.llvm.11216980332326776229+0x288>
  37c13e:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  37c143:	ff 15 c7 ed 4e 00    	call   *0x4eedc7(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c149:	bf 02 00 00 00       	mov    $0x2,%edi
  37c14e:	48 8d 15 a3 67 4b 00 	lea    0x4b67a3(%rip),%rdx        # 8328f8 <anon.32a531e794c2355d36f56847bc5de751.278.llvm.11216980332326776229+0x270>
  37c155:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  37c15a:	c5 f8 77             	vzeroupper
  37c15d:	ff 15 ad ed 4e 00    	call   *0x4eedad(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c163:	b8 01 00 00 00       	mov    $0x1,%eax
  37c168:	e9 50 02 00 00       	jmp    37c3bd <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4ebd>
  37c16d:	b8 01 00 00 00       	mov    $0x1,%eax
  37c172:	e9 70 02 00 00       	jmp    37c3e7 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4ee7>
  37c177:	b8 01 00 00 00       	mov    $0x1,%eax
  37c17c:	e9 90 02 00 00       	jmp    37c411 <<pulp::x86::v3::V3>::vectorize::imp::<<pulp::x86::v3::V3 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::analysis::FusedScaledScalarAnalysisPair<true, true>>>+0x4f11>
  37c181:	48 8d 15 c8 5d 4b 00 	lea    0x4b5dc8(%rip),%rdx        # 831f50 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xc90>
  37c188:	48 89 fe             	mov    %rdi,%rsi
  37c18b:	c5 f8 77             	vzeroupper
  37c18e:	ff 15 7c ed 4e 00    	call   *0x4eed7c(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c194:	48 8d 15 9d 5d 4b 00 	lea    0x4b5d9d(%rip),%rdx        # 831f38 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xc78>
  37c19b:	48 8b bc 24 b0 01 00 	mov    0x1b0(%rsp),%rdi
  37c1a2:	00 
  37c1a3:	48 89 fe             	mov    %rdi,%rsi
  37c1a6:	c5 f8 77             	vzeroupper
  37c1a9:	ff 15 61 ed 4e 00    	call   *0x4eed61(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c1af:	48 8d 15 6a 5d 4b 00 	lea    0x4b5d6a(%rip),%rdx        # 831f20 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xc60>
  37c1b6:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  37c1bb:	48 89 fe             	mov    %rdi,%rsi
  37c1be:	c5 f8 77             	vzeroupper
  37c1c1:	ff 15 49 ed 4e 00    	call   *0x4eed49(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c1c7:	48 8d 15 3a 5d 4b 00 	lea    0x4b5d3a(%rip),%rdx        # 831f08 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xc48>
  37c1ce:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  37c1d5:	00 
  37c1d6:	48 89 fe             	mov    %rdi,%rsi
  37c1d9:	c5 f8 77             	vzeroupper
  37c1dc:	ff 15 2e ed 4e 00    	call   *0x4eed2e(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c1e2:	48 8d 15 07 5d 4b 00 	lea    0x4b5d07(%rip),%rdx        # 831ef0 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xc30>
  37c1e9:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
  37c1f0:	00 
  37c1f1:	48 89 fe             	mov    %rdi,%rsi
  37c1f4:	c5 f8 77             	vzeroupper
  37c1f7:	ff 15 13 ed 4e 00    	call   *0x4eed13(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c1fd:	48 8d 15 d4 5c 4b 00 	lea    0x4b5cd4(%rip),%rdx        # 831ed8 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xc18>
  37c204:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  37c209:	48 89 fe             	mov    %rdi,%rsi
  37c20c:	c5 f8 77             	vzeroupper
  37c20f:	ff 15 fb ec 4e 00    	call   *0x4eecfb(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c215:	48 8d 15 64 5a 4b 00 	lea    0x4b5a64(%rip),%rdx        # 831c80 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0x9c0>
  37c21c:	c5 f8 77             	vzeroupper
  37c21f:	ff 15 eb ec 4e 00    	call   *0x4eeceb(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c225:	48 8d 15 6c 5a 4b 00 	lea    0x4b5a6c(%rip),%rdx        # 831c98 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0x9d8>
  37c22c:	c5 f8 77             	vzeroupper
  37c22f:	ff 15 db ec 4e 00    	call   *0x4eecdb(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c235:	48 8d 15 8c 5a 4b 00 	lea    0x4b5a8c(%rip),%rdx        # 831cc8 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xa08>
  37c23c:	c5 f8 77             	vzeroupper
  37c23f:	ff 15 cb ec 4e 00    	call   *0x4eeccb(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c245:	bf 03 00 00 00       	mov    $0x3,%edi
  37c24a:	48 8d 15 bf 66 4b 00 	lea    0x4b66bf(%rip),%rdx        # 832910 <anon.32a531e794c2355d36f56847bc5de751.278.llvm.11216980332326776229+0x288>
  37c251:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  37c256:	c5 f8 77             	vzeroupper
  37c259:	ff 15 b1 ec 4e 00    	call   *0x4eecb1(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c25f:	31 ff                	xor    %edi,%edi
  37c261:	48 8d 15 90 5a 4b 00 	lea    0x4b5a90(%rip),%rdx        # 831cf8 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xa38>
  37c268:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  37c26f:	00 
  37c270:	ff 15 9a ec 4e 00    	call   *0x4eec9a(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c276:	31 ff                	xor    %edi,%edi
  37c278:	48 8d 15 91 5a 4b 00 	lea    0x4b5a91(%rip),%rdx        # 831d10 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xa50>
  37c27f:	48 8b b4 24 e0 00 00 	mov    0xe0(%rsp),%rsi
  37c286:	00 
  37c287:	ff 15 83 ec 4e 00    	call   *0x4eec83(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c28d:	bf 01 00 00 00       	mov    $0x1,%edi
  37c292:	48 8d 15 8f 5a 4b 00 	lea    0x4b5a8f(%rip),%rdx        # 831d28 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xa68>
  37c299:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  37c2a0:	00 
  37c2a1:	c5 f8 77             	vzeroupper
  37c2a4:	ff 15 66 ec 4e 00    	call   *0x4eec66(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c2aa:	48 8d 15 07 5b 4b 00 	lea    0x4b5b07(%rip),%rdx        # 831db8 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xaf8>
  37c2b1:	4c 89 e7             	mov    %r12,%rdi
  37c2b4:	c5 f8 77             	vzeroupper
  37c2b7:	ff 15 53 ec 4e 00    	call   *0x4eec53(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c2bd:	4d 89 e0             	mov    %r12,%r8
  37c2c0:	48 8d 15 d9 5a 4b 00 	lea    0x4b5ad9(%rip),%rdx        # 831da0 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xae0>
  37c2c7:	4c 89 c7             	mov    %r8,%rdi
  37c2ca:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  37c2d1:	00 
  37c2d2:	c5 f8 77             	vzeroupper
  37c2d5:	ff 15 35 ec 4e 00    	call   *0x4eec35(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c2db:	4c 89 c7             	mov    %r8,%rdi
  37c2de:	48 8d 15 eb 5a 4b 00 	lea    0x4b5aeb(%rip),%rdx        # 831dd0 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xb10>
  37c2e5:	48 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%rsi
  37c2ec:	00 
  37c2ed:	c5 f8 77             	vzeroupper
  37c2f0:	ff 15 1a ec 4e 00    	call   *0x4eec1a(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c2f6:	48 8d 15 a3 5d 4b 00 	lea    0x4b5da3(%rip),%rdx        # 8320a0 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xde0>
  37c2fd:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
  37c304:	00 
  37c305:	48 89 fe             	mov    %rdi,%rsi
  37c308:	c5 f8 77             	vzeroupper
  37c30b:	ff 15 ff eb 4e 00    	call   *0x4eebff(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c311:	48 8d 15 70 5d 4b 00 	lea    0x4b5d70(%rip),%rdx        # 832088 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xdc8>
  37c318:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  37c31d:	48 89 fe             	mov    %rdi,%rsi
  37c320:	c5 f8 77             	vzeroupper
  37c323:	ff 15 e7 eb 4e 00    	call   *0x4eebe7(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c329:	48 8d 15 40 5d 4b 00 	lea    0x4b5d40(%rip),%rdx        # 832070 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xdb0>
  37c330:	4c 89 d7             	mov    %r10,%rdi
  37c333:	4c 89 d6             	mov    %r10,%rsi
  37c336:	c5 f8 77             	vzeroupper
  37c339:	ff 15 d1 eb 4e 00    	call   *0x4eebd1(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c33f:	48 8d 15 12 5d 4b 00 	lea    0x4b5d12(%rip),%rdx        # 832058 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xd98>
  37c346:	48 89 fe             	mov    %rdi,%rsi
  37c349:	c5 f8 77             	vzeroupper
  37c34c:	ff 15 be eb 4e 00    	call   *0x4eebbe(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c352:	48 8d 15 e7 5c 4b 00 	lea    0x4b5ce7(%rip),%rdx        # 832040 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xd80>
  37c359:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  37c35e:	48 89 fe             	mov    %rdi,%rsi
  37c361:	c5 f8 77             	vzeroupper
  37c364:	ff 15 a6 eb 4e 00    	call   *0x4eeba6(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c36a:	48 8d 15 b7 5c 4b 00 	lea    0x4b5cb7(%rip),%rdx        # 832028 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xd68>
  37c371:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  37c378:	00 
  37c379:	48 89 fe             	mov    %rdi,%rsi
  37c37c:	c5 f8 77             	vzeroupper
  37c37f:	ff 15 8b eb 4e 00    	call   *0x4eeb8b(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c385:	48 8d 15 84 5c 4b 00 	lea    0x4b5c84(%rip),%rdx        # 832010 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xd50>
  37c38c:	48 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%rdi
  37c393:	00 
  37c394:	48 89 fe             	mov    %rdi,%rsi
  37c397:	c5 f8 77             	vzeroupper
  37c39a:	ff 15 70 eb 4e 00    	call   *0x4eeb70(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c3a0:	48 8d 15 51 5c 4b 00 	lea    0x4b5c51(%rip),%rdx        # 831ff8 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xd38>
  37c3a7:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  37c3ac:	48 89 fe             	mov    %rdi,%rsi
  37c3af:	c5 f8 77             	vzeroupper
  37c3b2:	ff 15 58 eb 4e 00    	call   *0x4eeb58(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c3b8:	b8 02 00 00 00       	mov    $0x2,%eax
  37c3bd:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  37c3c4:	00 
  37c3c5:	48 8d 15 3c 4f 4b 00 	lea    0x4b4f3c(%rip),%rdx        # 831308 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0x48>
  37c3cc:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
  37c3d3:	00 
  37c3d4:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  37c3d9:	c5 f8 77             	vzeroupper
  37c3dc:	ff 15 2e eb 4e 00    	call   *0x4eeb2e(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c3e2:	b8 02 00 00 00       	mov    $0x2,%eax
  37c3e7:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  37c3ee:	00 
  37c3ef:	48 8d 15 42 4f 4b 00 	lea    0x4b4f42(%rip),%rdx        # 831338 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0x78>
  37c3f6:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
  37c3fd:	00 
  37c3fe:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  37c403:	c5 f8 77             	vzeroupper
  37c406:	ff 15 04 eb 4e 00    	call   *0x4eeb04(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c40c:	b8 02 00 00 00       	mov    $0x2,%eax
  37c411:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  37c418:	00 
  37c419:	48 8d 15 00 4f 4b 00 	lea    0x4b4f00(%rip),%rdx        # 831320 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0x60>
  37c420:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
  37c427:	00 
  37c428:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  37c42d:	c5 f8 77             	vzeroupper
  37c430:	ff 15 da ea 4e 00    	call   *0x4eeada(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c436:	48 8d 15 8b 64 4b 00 	lea    0x4b648b(%rip),%rdx        # 8328c8 <anon.32a531e794c2355d36f56847bc5de751.278.llvm.11216980332326776229+0x240>
  37c43d:	c5 f8 77             	vzeroupper
  37c440:	ff 15 ca ea 4e 00    	call   *0x4eeaca(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c446:	48 8d 15 2b 5a 4b 00 	lea    0x4b5a2b(%rip),%rdx        # 831e78 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xbb8>
  37c44d:	48 89 fe             	mov    %rdi,%rsi
  37c450:	c5 f8 77             	vzeroupper
  37c453:	ff 15 b7 ea 4e 00    	call   *0x4eeab7(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c459:	48 8d 15 30 5a 4b 00 	lea    0x4b5a30(%rip),%rdx        # 831e90 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xbd0>
  37c460:	4c 89 ef             	mov    %r13,%rdi
  37c463:	4c 89 ee             	mov    %r13,%rsi
  37c466:	c5 f8 77             	vzeroupper
  37c469:	ff 15 a1 ea 4e 00    	call   *0x4eeaa1(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c46f:	48 8d 15 32 5a 4b 00 	lea    0x4b5a32(%rip),%rdx        # 831ea8 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xbe8>
  37c476:	48 89 ef             	mov    %rbp,%rdi
  37c479:	48 89 ee             	mov    %rbp,%rsi
  37c47c:	c5 f8 77             	vzeroupper
  37c47f:	ff 15 8b ea 4e 00    	call   *0x4eea8b(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c485:	48 8d 15 34 5a 4b 00 	lea    0x4b5a34(%rip),%rdx        # 831ec0 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xc00>
  37c48c:	4c 89 e7             	mov    %r12,%rdi
  37c48f:	4c 89 e6             	mov    %r12,%rsi
  37c492:	c5 f8 77             	vzeroupper
  37c495:	ff 15 75 ea 4e 00    	call   *0x4eea75(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c49b:	48 8d 15 5e 59 4b 00 	lea    0x4b595e(%rip),%rdx        # 831e00 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xb40>
  37c4a2:	31 ff                	xor    %edi,%edi
  37c4a4:	31 f6                	xor    %esi,%esi
  37c4a6:	c5 f8 77             	vzeroupper
  37c4a9:	ff 15 61 ea 4e 00    	call   *0x4eea61(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c4af:	48 8d 15 62 59 4b 00 	lea    0x4b5962(%rip),%rdx        # 831e18 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xb58>
  37c4b6:	31 ff                	xor    %edi,%edi
  37c4b8:	31 f6                	xor    %esi,%esi
  37c4ba:	c5 f8 77             	vzeroupper
  37c4bd:	ff 15 4d ea 4e 00    	call   *0x4eea4d(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c4c3:	48 8d 15 66 59 4b 00 	lea    0x4b5966(%rip),%rdx        # 831e30 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xb70>
  37c4ca:	31 ff                	xor    %edi,%edi
  37c4cc:	31 f6                	xor    %esi,%esi
  37c4ce:	c5 f8 77             	vzeroupper
  37c4d1:	ff 15 39 ea 4e 00    	call   *0x4eea39(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c4d7:	48 8d 15 6a 59 4b 00 	lea    0x4b596a(%rip),%rdx        # 831e48 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xb88>
  37c4de:	31 ff                	xor    %edi,%edi
  37c4e0:	31 f6                	xor    %esi,%esi
  37c4e2:	c5 f8 77             	vzeroupper
  37c4e5:	ff 15 25 ea 4e 00    	call   *0x4eea25(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c4eb:	48 8d 15 6e 59 4b 00 	lea    0x4b596e(%rip),%rdx        # 831e60 <anon.32a531e794c2355d36f56847bc5de751.7.llvm.11216980332326776229+0xba0>
  37c4f2:	31 ff                	xor    %edi,%edi
  37c4f4:	31 f6                	xor    %esi,%esi
  37c4f6:	c5 f8 77             	vzeroupper
  37c4f9:	ff 15 11 ea 4e 00    	call   *0x4eea11(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c4ff:	48 8d 15 da 63 4b 00 	lea    0x4b63da(%rip),%rdx        # 8328e0 <anon.32a531e794c2355d36f56847bc5de751.278.llvm.11216980332326776229+0x258>
  37c506:	c5 f8 77             	vzeroupper
  37c509:	ff 15 01 ea 4e 00    	call   *0x4eea01(%rip)        # 86af10 <_DYNAMIC+0x298>
  37c50f:	cc                   	int3
