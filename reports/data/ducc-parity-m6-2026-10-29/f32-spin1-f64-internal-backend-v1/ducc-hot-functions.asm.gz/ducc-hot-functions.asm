000000000067cc80 <ducc0::detail_sht::detail_sht_inner_loop::alm2map_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double> const*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]>:
  67cc80:	push   %rbp
  67cc81:	mov    %rcx,%r11
  67cc84:	mov    %rdx,%r10
  67cc87:	lea    0x2(%r11),%rax
  67cc8b:	mov    %rsp,%rbp
  67cc8e:	push   %r13
  67cc90:	push   %r12
  67cc92:	mov    %r8,%r12
  67cc95:	push   %rbx
  67cc96:	mov    %rsi,%rbx
  67cc99:	and    $0xffffffffffffffe0,%rsp
  67cc9d:	mov    0x10(%rbp),%rcx
  67cca1:	cmp    %rax,%r9
  67cca4:	jb     67ce4d <ducc0::detail_sht::detail_sht_inner_loop::alm2map_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double> const*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x1cd>
  67ccaa:	test   %rcx,%rcx
  67ccad:	je     67ce1c <ducc0::detail_sht::detail_sht_inner_loop::alm2map_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double> const*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x19c>
  67ccb3:	mov    %r8,%r13
  67ccb6:	mov    %r11,%rdx
  67ccb9:	shl    $0x4,%r13
  67ccbd:	shl    $0x4,%rdx
  67ccc1:	add    %rsi,%r13
  67ccc4:	mov    %rcx,%rsi
  67ccc7:	add    %r10,%rdx
  67ccca:	shl    $0x5,%rsi
  67ccce:	add    %rdi,%rsi
  67ccd1:	nopl   0x0(%rax)
  67ccd5:	data16 cs nopw 0x0(%rax,%rax,1)
  67cce0:	vbroadcastsd 0x8(%r13),%ymm2
  67cce6:	vbroadcastsd (%rdx),%ymm15
  67cceb:	mov    %rdi,%rax
  67ccee:	vbroadcastsd 0x8(%rdx),%ymm14
  67ccf4:	vbroadcastsd 0x10(%rdx),%ymm13
  67ccfa:	vmovapd %ymm2,-0x20(%rsp)
  67cd00:	vbroadcastsd 0x10(%r13),%ymm2
  67cd06:	vbroadcastsd 0x18(%rdx),%ymm12
  67cd0c:	vbroadcastsd 0x20(%rdx),%ymm11
  67cd12:	vbroadcastsd 0x28(%rdx),%ymm10
  67cd18:	vmovapd %ymm2,-0x40(%rsp)
  67cd1e:	vbroadcastsd 0x18(%r13),%ymm2
  67cd24:	vbroadcastsd 0x30(%rdx),%ymm9
  67cd2a:	vbroadcastsd 0x38(%rdx),%ymm8
  67cd30:	vbroadcastsd 0x0(%r13),%ymm7
  67cd36:	vmovapd %ymm2,-0x60(%rsp)
  67cd3c:	nopl   0x0(%rax)
  67cd40:	vmovapd %ymm13,%ymm4
  67cd44:	vmovapd %ymm15,%ymm6
  67cd48:	vmovapd %ymm14,%ymm5
  67cd4c:	add    $0x20,%rax
  67cd50:	vmovapd 0x27e0(%rax),%ymm2
  67cd58:	vmovapd -0x20(%rsp),%ymm0
  67cd5e:	vmovapd %ymm12,%ymm3
  67cd62:	vmovapd 0x1fe0(%rax),%ymm1
  67cd6a:	vfmadd213pd 0x3fe0(%rax),%ymm1,%ymm4
  67cd73:	vfmadd213pd 0x2fe0(%rax),%ymm1,%ymm6
  67cd7c:	vfmadd231pd %ymm2,%ymm7,%ymm0
  67cd81:	vfmadd213pd 0x17e0(%rax),%ymm1,%ymm0
  67cd8a:	vfmadd213pd 0x37e0(%rax),%ymm1,%ymm5
  67cd93:	vfmadd213pd 0x47e0(%rax),%ymm1,%ymm3
  67cd9c:	vfmadd231pd %ymm0,%ymm9,%ymm4
  67cda1:	vfmadd231pd %ymm0,%ymm11,%ymm6
  67cda6:	vmovapd %ymm0,0x17e0(%rax)
  67cdae:	vfmadd231pd %ymm0,%ymm10,%ymm5
  67cdb3:	vfmadd231pd %ymm0,%ymm8,%ymm3
  67cdb8:	vmovapd %ymm4,0x3fe0(%rax)
  67cdc0:	vmovapd -0x60(%rsp),%ymm4
  67cdc6:	vfmadd132pd -0x40(%rsp),%ymm4,%ymm2
  67cdcd:	vmovapd %ymm6,0x2fe0(%rax)
  67cdd5:	vmovapd %ymm5,0x37e0(%rax)
  67cddd:	vmovapd %ymm3,0x47e0(%rax)
  67cde5:	vfmadd132pd %ymm2,%ymm1,%ymm0
  67cdea:	vmovapd %ymm0,0x1fe0(%rax)
  67cdf2:	cmp    %rax,%rsi
  67cdf5:	jne    67cd40 <ducc0::detail_sht::detail_sht_inner_loop::alm2map_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double> const*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0xc0>
  67cdfb:	lea    0x4(%r11),%r8
  67cdff:	add    $0x6,%r11
  67ce03:	add    $0x2,%r12
  67ce07:	add    $0x40,%rdx
  67ce0b:	add    $0x20,%r13
  67ce0f:	cmp    %r11,%r9
  67ce12:	jb     67ce50 <ducc0::detail_sht::detail_sht_inner_loop::alm2map_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double> const*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x1d0>
  67ce14:	mov    %r8,%r11
  67ce17:	jmp    67cce0 <ducc0::detail_sht::detail_sht_inner_loop::alm2map_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double> const*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x60>
  67ce1c:	lea    0x6(%r11),%rax
  67ce20:	cmp    %rax,%r9
  67ce23:	jb     67ce42 <ducc0::detail_sht::detail_sht_inner_loop::alm2map_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double> const*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x1c2>
  67ce25:	lea    0x8(%r11),%r8
  67ce29:	add    $0xa,%r11
  67ce2d:	add    $0x4,%r12
  67ce31:	cmp    %r11,%r9
  67ce34:	jb     67ce50 <ducc0::detail_sht::detail_sht_inner_loop::alm2map_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double> const*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x1d0>
  67ce36:	mov    %r8,%r11
  67ce39:	lea    0x6(%r11),%rax
  67ce3d:	cmp    %rax,%r9
  67ce40:	jae    67ce25 <ducc0::detail_sht::detail_sht_inner_loop::alm2map_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double> const*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x1a5>
  67ce42:	lea    -0x18(%rbp),%rsp
  67ce46:	pop    %rbx
  67ce47:	pop    %r12
  67ce49:	pop    %r13
  67ce4b:	pop    %rbp
  67ce4c:	ret
  67ce4d:	mov    %r11,%r8
  67ce50:	cmp    %r8,%r9
  67ce53:	jb     67cf54 <ducc0::detail_sht::detail_sht_inner_loop::alm2map_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double> const*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x2d4>
  67ce59:	test   %rcx,%rcx
  67ce5c:	je     67cf54 <ducc0::detail_sht::detail_sht_inner_loop::alm2map_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double> const*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x2d4>
  67ce62:	shl    $0x4,%r12
  67ce66:	mov    %r8,%rax
  67ce69:	shl    $0x5,%rcx
  67ce6d:	shl    $0x4,%rax
  67ce71:	add    %r12,%rbx
  67ce74:	lea    (%rdi,%rcx,1),%rdx
  67ce78:	lea    (%r10,%rax,1),%rsi
  67ce7c:	nopl   0x0(%rax)
  67ce80:	vbroadcastsd (%rsi),%ymm7
  67ce85:	vbroadcastsd 0x8(%rsi),%ymm6
  67ce8b:	mov    %rdi,%rax
  67ce8e:	vbroadcastsd 0x10(%rsi),%ymm5
  67ce94:	vbroadcastsd 0x18(%rsi),%ymm4
  67ce9a:	vbroadcastsd (%rbx),%ymm3
  67ce9f:	vbroadcastsd 0x8(%rbx),%ymm2
  67cea5:	data16 cs nopw 0x0(%rax,%rax,1)
  67ceb0:	vmovapd 0x2000(%rax),%ymm0
  67ceb8:	vmovapd %ymm7,%ymm1
  67cebc:	add    $0x20,%rax
  67cec0:	vfmadd213pd 0x2fe0(%rax),%ymm0,%ymm1
  67cec9:	vmovapd %ymm1,0x2fe0(%rax)
  67ced1:	vmovapd %ymm6,%ymm1
  67ced5:	vfmadd213pd 0x37e0(%rax),%ymm0,%ymm1
  67cede:	vmovapd %ymm1,0x37e0(%rax)
  67cee6:	vmovapd %ymm5,%ymm1
  67ceea:	vfmadd213pd 0x3fe0(%rax),%ymm0,%ymm1
  67cef3:	vmovapd %ymm1,0x3fe0(%rax)
  67cefb:	vmovapd %ymm4,%ymm1
  67ceff:	vfmadd213pd 0x47e0(%rax),%ymm0,%ymm1
  67cf08:	vmovapd %ymm1,0x47e0(%rax)
  67cf10:	vmovapd %ymm3,%ymm1
  67cf14:	vfmadd132pd 0x27e0(%rax),%ymm2,%ymm1
  67cf1d:	vfmadd213pd 0x17e0(%rax),%ymm0,%ymm1
  67cf26:	vmovapd %ymm0,0x17e0(%rax)
  67cf2e:	vmovapd %ymm1,0x1fe0(%rax)
  67cf36:	cmp    %rax,%rdx
  67cf39:	jne    67ceb0 <ducc0::detail_sht::detail_sht_inner_loop::alm2map_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double> const*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x230>
  67cf3f:	add    $0x2,%r8
  67cf43:	add    $0x20,%rsi
  67cf47:	add    $0x10,%rbx
  67cf4b:	cmp    %r8,%r9
  67cf4e:	jae    67ce80 <ducc0::detail_sht::detail_sht_inner_loop::alm2map_kernel(ducc0::detail_sht::detail_sht_inner_loop::s0data_v&, std::vector<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2, std::allocator<ducc0::detail_sht::detail_sht_inner_loop::Ylmgen::dbl2> > const&, std::complex<double> const*, unsigned long, unsigned long, unsigned long, unsigned long) [clone .isra.0]+0x200>
  67cf54:	vzeroupper
  67cf57:	lea    -0x18(%rbp),%rsp
  67cf5b:	pop    %rbx
  67cf5c:	pop    %r12
  67cf5e:	pop    %r13
  67cf60:	pop    %rbp
  67cf61:	ret
  67cf62:	nopl   (%rax)
  67cf65:	data16 cs nopw 0x0(%rax,%rax,1)


