000000000030a3c0 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched>:
  30a3c0:	push   %rbp
  30a3c1:	push   %r15
  30a3c3:	push   %r14
  30a3c5:	push   %r13
  30a3c7:	push   %r12
  30a3c9:	push   %rbx
  30a3ca:	sub    $0x1f8,%rsp
  30a3d1:	mov    %rdx,%r13
  30a3d4:	sub    %rsi,%r13
  30a3d7:	jb     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30a3dd:	cmp    $0xfffffffffffffffd,%r13
  30a3e1:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30a3e7:	vmovdqa %xmm0,%xmm4
  30a3eb:	mov    %rsi,0x60(%rsp)
  30a3f0:	mov    0x230(%rsp),%r14
  30a3f8:	add    $0x2,%r13
  30a3fc:	shr    $1,%r13
  30a3ff:	lea    -0x1(%r8),%rax
  30a403:	cmp    %r9,%rax
  30a406:	setae  %al
  30a409:	cmp    $0x101,%r9
  30a410:	setae  %sil
  30a414:	mov    0x68(%r14),%r10
  30a418:	mov    %r10,(%rsp)
  30a41c:	cmp    %r9,%r10
  30a41f:	setb   %r10b
  30a423:	vmovdqu 0xd8(%r14),%xmm0
  30a42c:	vmovq  0xe8(%r14),%xmm1
  30a435:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
  30a43b:	vmovdqu 0x78(%r14),%ymm1
  30a441:	vmovdqu 0xb8(%r14),%ymm2
  30a44a:	vpunpcklqdq %ymm0,%ymm2,%ymm0
  30a44e:	vpermq $0xd8,%ymm0,%ymm0
  30a454:	vpunpcklqdq 0x98(%r14),%ymm1,%ymm1
  30a45d:	vpermq $0xd8,%ymm1,%ymm1
  30a463:	vmovq  %r9,%xmm2
  30a468:	cmp    %r9,0xf8(%r14)
  30a46f:	vpbroadcastq %xmm2,%ymm2
  30a474:	setb   %r11b
  30a478:	mov    0x28(%r14),%rbx
  30a47c:	mov    0x38(%r14),%r12
  30a480:	mov    %rbx,0x110(%rsp)
  30a488:	cmp    %r13,%rbx
  30a48b:	setb   %bpl
  30a48f:	mov    %r12,0x30(%rsp)
  30a494:	cmp    %r13,%r12
  30a497:	setb   %r15b
  30a49b:	mov    0x48(%r14),%rbx
  30a49f:	mov    %rbx,0x48(%rsp)
  30a4a4:	cmp    %r13,%rbx
  30a4a7:	setb   %bl
  30a4aa:	mov    0x58(%r14),%r14
  30a4ae:	mov    %r14,0x38(%rsp)
  30a4b3:	mov    %r13,0x20(%rsp)
  30a4b8:	cmp    %r13,%r14
  30a4bb:	setb   %r12b
  30a4bf:	vpbroadcastq -0x2dd660(%rip),%ymm3        # 2ce68 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x698>
  30a4c8:	vpxor  %ymm3,%ymm2,%ymm2
  30a4cc:	vpxor  %ymm3,%ymm1,%ymm1
  30a4d0:	vpcmpgtq %ymm1,%ymm2,%ymm1
  30a4d5:	vpxor  %ymm3,%ymm0,%ymm0
  30a4d9:	vpcmpgtq %ymm0,%ymm2,%ymm0
  30a4de:	vpackssdw %ymm0,%ymm1,%ymm0
  30a4e2:	vtestps %ymm0,%ymm0
  30a4e7:	setne  %r14b
  30a4eb:	or     %r10b,%r11b
  30a4ee:	or     %bpl,%r11b
  30a4f1:	or     %r15b,%r12b
  30a4f4:	or     %sil,%r12b
  30a4f7:	or     %r11b,%r12b
  30a4fa:	or     %bl,%r12b
  30a4fd:	or     %al,%r12b
  30a500:	or     %r14b,%r12b
  30a503:	test   $0x1,%r12b
  30a507:	je     30a520 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x160>
  30a509:	xor    %eax,%eax
  30a50b:	add    $0x1f8,%rsp
  30a512:	pop    %rbx
  30a513:	pop    %r12
  30a515:	pop    %r13
  30a517:	pop    %r14
  30a519:	pop    %r15
  30a51b:	pop    %rbp
  30a51c:	vzeroupper
  30a51f:	ret
  30a520:	test   %dil,%dil
  30a523:	je     30a640 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x280>
  30a529:	movzbl %dil,%eax
  30a52d:	cmp    $0x1,%eax
  30a530:	mov    0x230(%rsp),%rbx
  30a538:	mov    0x60(%rsp),%r15
  30a53d:	jne    30a6ce <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x30e>
  30a543:	test   %r15,%r15
  30a546:	mov    %r9,0x8(%rsp)
  30a54b:	je     30a702 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x342>
  30a551:	vmovdqa %xmm4,0x90(%rsp)
  30a55a:	mov    %rcx,%rbp
  30a55d:	mov    %r8,%r13
  30a560:	mov    %rdx,0x18(%rsp)
  30a565:	vmovq  %r15,%xmm0
  30a56a:	vpunpckldq -0x2de792(%rip),%xmm0,%xmm0        # 2bde0 <anon.2284309812649c8e966c3f1909a927a8.23.llvm.17146629557222593030+0x200>
  30a572:	vsubpd -0x2de9ca(%rip),%xmm0,%xmm0        # 2bbb0 <__abi_tag+0x2b8b4>
  30a57a:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  30a57f:	vaddsd %xmm0,%xmm1,%xmm0
  30a583:	vmovsd -0x2dd49b(%rip),%xmm1        # 2d0f0 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x920>
  30a58b:	vdivsd %xmm0,%xmm1,%xmm0
  30a58f:	vzeroupper
  30a592:	call   *0xb33a8(%rip)        # 3bd940 <exp@GLIBC_2.29>
  30a598:	mov    0x8(%rsp),%rcx
  30a59d:	test   $0x3,%cl
  30a5a0:	jne    30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30a5a6:	xor    %eax,%eax
  30a5a8:	mov    %r13,%rsi
  30a5ab:	test   $0x3,%sil
  30a5af:	setne  %al
  30a5b2:	lea    0x0(,%rax,4),%rax
  30a5ba:	add    %r13,%rax
  30a5bd:	movabs $0x1ffffffffffffffc,%rdx
  30a5c7:	and    %rax,%rdx
  30a5ca:	cmp    %rdx,%rcx
  30a5cd:	vmovapd 0x90(%rsp),%xmm1
  30a5d6:	jne    30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30a5dc:	test   $0x1,%r15b
  30a5e0:	je     30a5ea <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x22a>
  30a5e2:	vxorpd -0x2ddfea(%rip),%xmm1,%xmm1        # 2c600 <anon.2284309812649c8e966c3f1909a927a8.23.llvm.17146629557222593030+0xa20>
  30a5ea:	mov    %rbp,%rax
  30a5ed:	mov    0x70(%rbx),%r14
  30a5f1:	mov    0x20(%rbx),%rdx
  30a5f5:	mov    %rdx,0x10(%rsp)
  30a5fa:	mov    0x30(%rbx),%rdx
  30a5fe:	mov    %rdx,0x28(%rsp)
  30a603:	mov    0x40(%rbx),%rdx
  30a607:	mov    %rdx,0x50(%rsp)
  30a60c:	mov    0x50(%rbx),%rdx
  30a610:	mov    %rdx,0x40(%rsp)
  30a615:	sub    %rsi,%rcx
  30a618:	jne    30acbc <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x8fc>
  30a61e:	mov    0x90(%rbx),%rdx
  30a625:	mov    0xa0(%rbx),%r8
  30a62c:	sub    $0x8,%rsp
  30a630:	mov    %rax,%rdi
  30a633:	mov    %rsi,%rcx
  30a636:	mov    %rsi,%r9
  30a639:	push   %r15
  30a63b:	jmp    30aeda <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0xb1a>
  30a640:	mov    0x60(%rsp),%r12
  30a645:	test   %r12,%r12
  30a648:	mov    0x230(%rsp),%rbx
  30a650:	je     30a799 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3d9>
  30a656:	cmp    %r8,%r9
  30a659:	jne    30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30a65f:	vmovdqa %xmm4,0x90(%rsp)
  30a668:	mov    %rcx,%r15
  30a66b:	mov    %r8,(%rsp)
  30a66f:	mov    %rdx,0x18(%rsp)
  30a674:	vmovq  %r12,%xmm0
  30a679:	vpunpckldq -0x2de8a1(%rip),%xmm0,%xmm0        # 2bde0 <anon.2284309812649c8e966c3f1909a927a8.23.llvm.17146629557222593030+0x200>
  30a681:	vsubpd -0x2dead9(%rip),%xmm0,%xmm0        # 2bbb0 <__abi_tag+0x2b8b4>
  30a689:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  30a68e:	vaddsd %xmm0,%xmm1,%xmm0
  30a692:	vmovsd -0x2dd5aa(%rip),%xmm1        # 2d0f0 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x920>
  30a69a:	vdivsd %xmm0,%xmm1,%xmm0
  30a69e:	vzeroupper
  30a6a1:	call   *0xb3299(%rip)        # 3bd940 <exp@GLIBC_2.29>
  30a6a7:	test   $0x1,%r12b
  30a6ab:	je     30aa43 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x683>
  30a6b1:	vmovapd 0x90(%rsp),%xmm1
  30a6ba:	vxorpd -0x2de0c2(%rip),%xmm1,%xmm1        # 2c600 <anon.2284309812649c8e966c3f1909a927a8.23.llvm.17146629557222593030+0xa20>
  30a6c2:	mov    (%rsp),%rcx
  30a6c6:	mov    %r15,%rdi
  30a6c9:	jmp    30aa53 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x693>
  30a6ce:	vmovq  %xmm4,%rax
  30a6d3:	sub    $0x8,%rsp
  30a6d7:	mov    %rcx,%rdi
  30a6da:	mov    %r8,%rsi
  30a6dd:	mov    %rdx,%r8
  30a6e0:	mov    %rbx,%rdx
  30a6e3:	mov    %r15,%rcx
  30a6e6:	mov    %r9,%r10
  30a6e9:	mov    %rax,%r9
  30a6ec:	push   %r10
  30a6ee:	vzeroupper
  30a6f1:	call   307fb0 <<pulp::x86::v4::V4>::vectorize::imp_fastcall::<<pulp::x86::v4::V4 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_ordered::kernel::PreparedComponentBatch>>>
  30a6f6:	add    $0x208,%rsp
  30a6fd:	jmp    30a512 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x152>
  30a702:	test   $0x3,%r9b
  30a706:	jne    30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30a70c:	xor    %eax,%eax
  30a70e:	test   $0x3,%r8b
  30a712:	setne  %al
  30a715:	lea    (%r8,%rax,4),%rax
  30a719:	movabs $0x1ffffffffffffffc,%rsi
  30a723:	and    %rax,%rsi
  30a726:	cmp    %rsi,%r9
  30a729:	jne    30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30a72f:	mov    0x70(%rbx),%rax
  30a733:	mov    %rax,0x60(%rsp)
  30a738:	mov    0x20(%rbx),%rax
  30a73c:	mov    %rax,0x20(%rsp)
  30a741:	mov    0x30(%rbx),%rax
  30a745:	mov    %rax,0x10(%rsp)
  30a74a:	mov    0x40(%rbx),%rax
  30a74e:	mov    %rax,0x28(%rsp)
  30a753:	mov    0x50(%rbx),%rax
  30a757:	mov    %rax,0x50(%rsp)
  30a75c:	mov    %r9,%r13
  30a75f:	sub    %r8,%r13
  30a762:	jne    30ad62 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x9a2>
  30a768:	mov    %rdx,%r12
  30a76b:	mov    0x90(%rbx),%rdx
  30a772:	mov    0xa0(%rbx),%rax
  30a779:	sub    $0x8,%rsp
  30a77d:	vpxor  %xmm0,%xmm0,%xmm0
  30a781:	mov    %rcx,%rdi
  30a784:	mov    %r8,%rsi
  30a787:	mov    %r8,%rcx
  30a78a:	mov    %r8,%r9
  30a78d:	mov    %rax,%r8
  30a790:	vmovdqa %xmm4,%xmm1
  30a794:	jmp    30b633 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1273>
  30a799:	cmp    %r8,%r9
  30a79c:	jne    30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30a7a2:	mov    %rdx,0x18(%rsp)
  30a7a7:	mov    0x70(%rbx),%rbp
  30a7ab:	mov    0x20(%rbx),%r15
  30a7af:	mov    0x30(%rbx),%r13
  30a7b3:	mov    0x40(%rbx),%r12
  30a7b7:	mov    0x50(%rbx),%r14
  30a7bb:	mov    0x90(%rbx),%rdx
  30a7c2:	mov    0xa0(%rbx),%rax
  30a7c9:	sub    $0x8,%rsp
  30a7cd:	vxorps %xmm0,%xmm0,%xmm0
  30a7d1:	mov    %rcx,%rdi
  30a7d4:	mov    %r8,%rsi
  30a7d7:	mov    %r8,%rcx
  30a7da:	mov    %r8,%r9
  30a7dd:	mov    %rax,%r8
  30a7e0:	mov    %r9,0x8(%rsp)
  30a7e5:	vmovdqa %xmm4,%xmm1
  30a7e9:	push   $0x0
  30a7eb:	vzeroupper
  30a7ee:	call   300a40 <rustsht::legendre::scalar_ordered::kernel::initialize_sectoral_batch::<pulp::Scalar>>
  30a7f3:	add    $0x10,%rsp
  30a7f7:	test   %al,%al
  30a7f9:	je     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30a7ff:	mov    %r13,0x60(%rsp)
  30a804:	mov    0x88(%rbx),%rdx
  30a80b:	mov    (%rsp),%rax
  30a80f:	cmp    %rdx,%rax
  30a812:	ja     30e12d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3d6d>
  30a818:	lea    0x0(,%rax,8),%r13
  30a820:	test   %rax,%rax
  30a823:	je     30a8e9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x529>
  30a829:	mov    %r15,0x20(%rsp)
  30a82e:	mov    %rbp,%r15
  30a831:	mov    %r14,%rbp
  30a834:	mov    0x80(%rbx),%rdi
  30a83b:	xor    %esi,%esi
  30a83d:	mov    %r13,%rdx
  30a840:	mov    %rbx,%r14
  30a843:	mov    %rax,%rbx
  30a846:	call   *0xb2884(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30a84c:	mov    0xc8(%r14),%rdx
  30a853:	cmp    %rdx,%rbx
  30a856:	ja     30e1de <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e1e>
  30a85c:	mov    0xc0(%r14),%rdi
  30a863:	xor    %esi,%esi
  30a865:	mov    %r13,%rdx
  30a868:	call   *0xb2862(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30a86e:	mov    0xd8(%r14),%rdx
  30a875:	cmp    %rdx,(%rsp)
  30a879:	ja     30e1f1 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e31>
  30a87f:	mov    %r14,%rbx
  30a882:	mov    0xd0(%r14),%rdi
  30a889:	xor    %esi,%esi
  30a88b:	mov    %r13,%rdx
  30a88e:	call   *0xb283c(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30a894:	mov    0xe8(%r14),%rdx
  30a89b:	cmp    %rdx,(%rsp)
  30a89f:	ja     30e204 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e44>
  30a8a5:	mov    %rbp,%r14
  30a8a8:	mov    0xe0(%rbx),%rdi
  30a8af:	xor    %esi,%esi
  30a8b1:	mov    %r13,%rdx
  30a8b4:	call   *0xb2816(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30a8ba:	mov    0xf8(%rbx),%rdx
  30a8c1:	cmp    %rdx,(%rsp)
  30a8c5:	ja     30e217 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e57>
  30a8cb:	mov    %r15,%rbp
  30a8ce:	mov    0xf0(%rbx),%rdi
  30a8d5:	xor    %esi,%esi
  30a8d7:	mov    %r13,%rdx
  30a8da:	call   *0xb27f0(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30a8e0:	mov    (%rsp),%rax
  30a8e4:	mov    0x20(%rsp),%r15
  30a8e9:	mov    0x88(%rbx),%rdx
  30a8f0:	cmp    %rdx,%rax
  30a8f3:	ja     30e13f <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3d7f>
  30a8f9:	mov    %r12,0x90(%rsp)
  30a901:	mov    0x80(%rbx),%rcx
  30a908:	mov    %rcx,0x8(%rsp)
  30a90d:	mov    %rcx,0xd0(%rsp)
  30a915:	mov    %rax,0xd8(%rsp)
  30a91d:	mov    0x98(%rbx),%rdx
  30a924:	cmp    %rdx,%rax
  30a927:	mov    0x18(%rsp),%rcx
  30a92c:	ja     30e151 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3d91>
  30a932:	mov    0x90(%rbx),%r12
  30a939:	mov    %r12,0xe0(%rsp)
  30a941:	mov    %rax,0xe8(%rsp)
  30a949:	mov    0xa8(%rbx),%rdx
  30a950:	cmp    %rdx,%rax
  30a953:	ja     30e163 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3da3>
  30a959:	sub    $0x8,%rsp
  30a95d:	lea    0xe8(%rsp),%r10
  30a965:	lea    0xd8(%rsp),%r11
  30a96d:	lea    0xf8(%rsp),%rdi
  30a975:	xor    %esi,%esi
  30a977:	mov    %rcx,%rdx
  30a97a:	mov    %rbp,%rcx
  30a97d:	mov    %rax,%r8
  30a980:	mov    %r15,%r9
  30a983:	push   %rax
  30a984:	push   0xa0(%rbx)
  30a98a:	push   %r10
  30a98c:	push   %r11
  30a98e:	push   0x58(%rsp)
  30a992:	push   0x90(%rsp)
  30a999:	push   0x148(%rsp)
  30a9a0:	call   2fb3f0 <rustsht::legendre::scalar_ordered::kernel::iter_to_ieee::<pulp::Scalar>>
  30a9a5:	add    $0x40,%rsp
  30a9a9:	movzbl 0x100(%rsp),%eax
  30a9b1:	cmp    $0x2,%al
  30a9b3:	je     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30a9b9:	mov    0xf0(%rsp),%r11
  30a9c1:	mov    0x18(%rsp),%rcx
  30a9c6:	cmp    %rcx,%r11
  30a9c9:	seta   %dl
  30a9cc:	or     %al,%dl
  30a9ce:	mov    $0x1,%al
  30a9d0:	test   $0x1,%dl
  30a9d3:	jne    30a50b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x14b>
  30a9d9:	mov    0xa8(%rbx),%rdx
  30a9e0:	mov    (%rsp),%rsi
  30a9e4:	cmp    %rdx,%rsi
  30a9e7:	ja     30e2cc <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f0c>
  30a9ed:	mov    %r15,0x20(%rsp)
  30a9f2:	mov    0xb8(%rbx),%rax
  30a9f9:	cmp    %rax,%rsi
  30a9fc:	ja     30e2f0 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f30>
  30aa02:	lea    0x2(%rcx),%rax
  30aa06:	shr    $1,%rax
  30aa09:	mov    %rax,0x28(%rsp)
  30aa0e:	mov    0xf8(%rsp),%r15
  30aa16:	test   %rsi,%rsi
  30aa19:	mov    %r11,0x10(%rsp)
  30aa1e:	je     30bcec <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x192c>
  30aa24:	mov    0xa0(%rbx),%rax
  30aa2b:	mov    0xb0(%rbx),%rcx
  30aa32:	cmp    $0x4,%rsi
  30aa36:	jae    30bcf8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1938>
  30aa3c:	xor    %edx,%edx
  30aa3e:	jmp    30c89f <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x24df>
  30aa43:	mov    (%rsp),%rcx
  30aa47:	mov    %r15,%rdi
  30aa4a:	vmovapd 0x90(%rsp),%xmm1
  30aa53:	mov    0x70(%rbx),%rax
  30aa57:	mov    %rax,0x48(%rsp)
  30aa5c:	mov    0x20(%rbx),%r15
  30aa60:	mov    0x30(%rbx),%r14
  30aa64:	mov    0x40(%rbx),%rax
  30aa68:	mov    %rax,0x38(%rsp)
  30aa6d:	mov    0x50(%rbx),%rax
  30aa71:	mov    %rax,0x8(%rsp)
  30aa76:	mov    0x90(%rbx),%rdx
  30aa7d:	mov    0xa0(%rbx),%r8
  30aa84:	sub    $0x8,%rsp
  30aa88:	mov    %rcx,%rsi
  30aa8b:	mov    %rcx,%r9
  30aa8e:	push   %r12
  30aa90:	call   300a40 <rustsht::legendre::scalar_ordered::kernel::initialize_sectoral_batch::<pulp::Scalar>>
  30aa95:	add    $0x10,%rsp
  30aa99:	test   %al,%al
  30aa9b:	je     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30aaa1:	mov    0x88(%rbx),%rdx
  30aaa8:	mov    (%rsp),%rax
  30aaac:	cmp    %rdx,%rax
  30aaaf:	ja     30e12d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3d6d>
  30aab5:	lea    0x0(,%rax,8),%r12
  30aabd:	test   %rax,%rax
  30aac0:	je     30ab76 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x7b6>
  30aac6:	mov    %r14,%rbp
  30aac9:	mov    0x80(%rbx),%rdi
  30aad0:	xor    %esi,%esi
  30aad2:	mov    %r12,%rdx
  30aad5:	mov    %rbx,%r14
  30aad8:	mov    %rax,%rbx
  30aadb:	call   *0xb25ef(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30aae1:	mov    0xc8(%r14),%rdx
  30aae8:	cmp    %rdx,%rbx
  30aaeb:	ja     30e1de <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e1e>
  30aaf1:	mov    0xc0(%r14),%rdi
  30aaf8:	xor    %esi,%esi
  30aafa:	mov    %r12,%rdx
  30aafd:	call   *0xb25cd(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30ab03:	mov    0xd8(%r14),%rdx
  30ab0a:	cmp    %rdx,(%rsp)
  30ab0e:	ja     30e1f1 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e31>
  30ab14:	mov    %r14,%rbx
  30ab17:	mov    0xd0(%r14),%rdi
  30ab1e:	xor    %esi,%esi
  30ab20:	mov    %r12,%rdx
  30ab23:	call   *0xb25a7(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30ab29:	mov    0xe8(%r14),%rdx
  30ab30:	cmp    %rdx,(%rsp)
  30ab34:	ja     30e204 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e44>
  30ab3a:	mov    %rbp,%r14
  30ab3d:	mov    0xe0(%rbx),%rdi
  30ab44:	xor    %esi,%esi
  30ab46:	mov    %r12,%rdx
  30ab49:	call   *0xb2581(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30ab4f:	mov    0xf8(%rbx),%rdx
  30ab56:	cmp    %rdx,(%rsp)
  30ab5a:	ja     30e217 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e57>
  30ab60:	mov    0xf0(%rbx),%rdi
  30ab67:	xor    %esi,%esi
  30ab69:	mov    %r12,%rdx
  30ab6c:	call   *0xb255e(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30ab72:	mov    (%rsp),%rax
  30ab76:	mov    0x88(%rbx),%rdx
  30ab7d:	cmp    %rdx,%rax
  30ab80:	ja     30e13f <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3d7f>
  30ab86:	mov    %r12,0x10(%rsp)
  30ab8b:	mov    0x80(%rbx),%rcx
  30ab92:	mov    %rcx,0x90(%rsp)
  30ab9a:	mov    %rcx,0xd0(%rsp)
  30aba2:	mov    %rax,0xd8(%rsp)
  30abaa:	mov    0x98(%rbx),%rdx
  30abb1:	cmp    %rdx,%rax
  30abb4:	mov    0x18(%rsp),%rcx
  30abb9:	ja     30e151 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3d91>
  30abbf:	mov    0x90(%rbx),%rbp
  30abc6:	mov    %rbp,0xe0(%rsp)
  30abce:	mov    %rax,0xe8(%rsp)
  30abd6:	mov    0xa8(%rbx),%rdx
  30abdd:	cmp    %rdx,%rax
  30abe0:	mov    0x60(%rsp),%rsi
  30abe5:	ja     30e163 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3da3>
  30abeb:	sub    $0x8,%rsp
  30abef:	lea    0xe8(%rsp),%r10
  30abf7:	lea    0xd8(%rsp),%r11
  30abff:	lea    0xf8(%rsp),%rdi
  30ac07:	mov    %rcx,%rdx
  30ac0a:	mov    0x50(%rsp),%rcx
  30ac0f:	mov    %rax,%r8
  30ac12:	mov    %r15,%r9
  30ac15:	push   %rax
  30ac16:	push   0xa0(%rbx)
  30ac1c:	push   %r10
  30ac1e:	push   %r11
  30ac20:	push   0x58(%rsp)
  30ac24:	push   %r14
  30ac26:	push   0x148(%rsp)
  30ac2d:	call   2fb3f0 <rustsht::legendre::scalar_ordered::kernel::iter_to_ieee::<pulp::Scalar>>
  30ac32:	add    $0x40,%rsp
  30ac36:	movzbl 0x100(%rsp),%eax
  30ac3e:	cmp    $0x2,%al
  30ac40:	je     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30ac46:	mov    0xf0(%rsp),%rcx
  30ac4e:	mov    %rcx,0x60(%rsp)
  30ac53:	cmp    0x18(%rsp),%rcx
  30ac58:	seta   %cl
  30ac5b:	or     %al,%cl
  30ac5d:	mov    $0x1,%al
  30ac5f:	test   $0x1,%cl
  30ac62:	jne    30a50b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x14b>
  30ac68:	mov    0xa8(%rbx),%rdx
  30ac6f:	mov    (%rsp),%rsi
  30ac73:	cmp    %rdx,%rsi
  30ac76:	ja     30e2cc <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f0c>
  30ac7c:	mov    0xb8(%rbx),%rax
  30ac83:	cmp    %rax,%rsi
  30ac86:	ja     30e2f0 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f30>
  30ac8c:	mov    0xf8(%rsp),%r13
  30ac94:	test   %rsi,%rsi
  30ac97:	je     30b543 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1183>
  30ac9d:	mov    0xa0(%rbx),%rax
  30aca4:	mov    0xb0(%rbx),%rcx
  30acab:	cmp    $0x4,%rsi
  30acaf:	jae    30b54f <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x118f>
  30acb5:	xor    %edx,%edx
  30acb7:	jmp    30bf1d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1b5d>
  30acbc:	vmovsd %xmm0,0x130(%rsp)
  30acc5:	vmovapd %xmm1,0x90(%rsp)
  30acce:	mov    (%rsp),%rdx
  30acd2:	cmp    %rdx,%rsi
  30acd5:	ja     30e302 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f42>
  30acdb:	mov    %rcx,%r12
  30acde:	mov    0x60(%rbx),%rdi
  30ace2:	lea    0x0(,%rsi,8),%r15
  30acea:	mov    %rax,%rsi
  30aced:	mov    %r15,%rdx
  30acf0:	call   *0xb236a(%rip)        # 3bd060 <memcpy@GLIBC_2.14>
  30acf6:	mov    0x68(%rbx),%rdx
  30acfa:	mov    0x8(%rsp),%rsi
  30acff:	cmp    %rdx,%rsi
  30ad02:	ja     30e311 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f51>
  30ad08:	mov    0x60(%rbx),%r9
  30ad0c:	lea    (%r9,%r13,8),%rax
  30ad10:	vmovq  -0x8(%rbp,%r13,8),%xmm0
  30ad17:	lea    0x0(,%rsi,8),%r8
  30ad1f:	sub    %r15,%r8
  30ad22:	add    $0xfffffffffffffff8,%r8
  30ad26:	mov    %rax,%rdx
  30ad29:	cmp    $0x18,%r8
  30ad2d:	vmovapd 0x90(%rsp),%xmm1
  30ad36:	jb     30ae73 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0xab3>
  30ad3c:	mov    %r8,%rcx
  30ad3f:	shr    $0x3,%rcx
  30ad43:	inc    %rcx
  30ad46:	movabs $0x3ffffffffffffff0,%rdi
  30ad50:	cmp    $0x78,%r8
  30ad54:	jae    30ae08 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0xa48>
  30ad5a:	xor    %r8d,%r8d
  30ad5d:	jmp    30ae4f <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0xa8f>
  30ad62:	vmovdqa %xmm4,0x90(%rsp)
  30ad6b:	mov    %rdx,%r12
  30ad6e:	mov    (%rsp),%rdx
  30ad72:	cmp    %rdx,%r8
  30ad75:	ja     30e3bf <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3fff>
  30ad7b:	mov    0x60(%rbx),%rdi
  30ad7f:	mov    %r8,%r15
  30ad82:	lea    0x0(,%r8,8),%r14
  30ad8a:	mov    %rcx,%rbp
  30ad8d:	mov    %rcx,%rsi
  30ad90:	mov    %r14,%rdx
  30ad93:	vzeroupper
  30ad96:	call   *0xb22c4(%rip)        # 3bd060 <memcpy@GLIBC_2.14>
  30ad9c:	mov    0x68(%rbx),%rdx
  30ada0:	mov    0x8(%rsp),%rsi
  30ada5:	cmp    %rdx,%rsi
  30ada8:	ja     30e3d4 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4014>
  30adae:	mov    0x60(%rbx),%r9
  30adb2:	lea    (%r9,%r15,8),%rax
  30adb6:	vmovq  -0x8(%rbp,%r15,8),%xmm0
  30adbd:	lea    0x0(,%rsi,8),%r8
  30adc5:	sub    %r14,%r8
  30adc8:	add    $0xfffffffffffffff8,%r8
  30adcc:	mov    %rax,%rdx
  30adcf:	cmp    $0x18,%r8
  30add3:	vmovapd 0x90(%rsp),%xmm1
  30addc:	jb     30b5d5 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1215>
  30ade2:	mov    %r8,%rcx
  30ade5:	shr    $0x3,%rcx
  30ade9:	inc    %rcx
  30adec:	movabs $0x3ffffffffffffff0,%rdi
  30adf6:	cmp    $0x78,%r8
  30adfa:	jae    30b56a <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x11aa>
  30ae00:	xor    %r8d,%r8d
  30ae03:	jmp    30b5b1 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x11f1>
  30ae08:	mov    %rcx,%r8
  30ae0b:	and    %rdi,%r8
  30ae0e:	lea    (%rax,%r8,8),%rdx
  30ae12:	vpbroadcastq %xmm0,%ymm2
  30ae17:	add    %r15,%r9
  30ae1a:	add    $0x60,%r9
  30ae1e:	xor    %r10d,%r10d
  30ae21:	vmovdqu %ymm2,-0x60(%r9,%r10,8)
  30ae28:	vmovdqu %ymm2,-0x40(%r9,%r10,8)
  30ae2f:	vmovdqu %ymm2,-0x20(%r9,%r10,8)
  30ae36:	vmovdqu %ymm2,(%r9,%r10,8)
  30ae3c:	add    $0x10,%r10
  30ae40:	cmp    %r10,%r8
  30ae43:	jne    30ae21 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0xa61>
  30ae45:	cmp    %r8,%rcx
  30ae48:	je     30ae84 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0xac4>
  30ae4a:	test   $0xc,%cl
  30ae4d:	je     30ae73 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0xab3>
  30ae4f:	add    $0xc,%rdi
  30ae53:	and    %rcx,%rdi
  30ae56:	lea    (%rax,%rdi,8),%rdx
  30ae5a:	vpbroadcastq %xmm0,%ymm2
  30ae5f:	vmovdqu %ymm2,(%rax,%r8,8)
  30ae65:	add    $0x4,%r8
  30ae69:	cmp    %r8,%rdi
  30ae6c:	jne    30ae5f <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0xa9f>
  30ae6e:	cmp    %rdi,%rcx
  30ae71:	je     30ae84 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0xac4>
  30ae73:	lea    (%rax,%r12,8),%rax
  30ae77:	vmovq  %xmm0,(%rdx)
  30ae7b:	add    $0x8,%rdx
  30ae7f:	cmp    %rax,%rdx
  30ae82:	jne    30ae77 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0xab7>
  30ae84:	mov    0x68(%rbx),%rdx
  30ae88:	cmp    %rdx,%rsi
  30ae8b:	ja     30e24e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e8e>
  30ae91:	mov    0x98(%rbx),%rdx
  30ae98:	cmp    %rdx,%rsi
  30ae9b:	vmovsd 0x130(%rsp),%xmm0
  30aea4:	ja     30e272 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3eb2>
  30aeaa:	mov    0xa8(%rbx),%rdx
  30aeb1:	cmp    %rdx,%rsi
  30aeb4:	ja     30e284 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3ec4>
  30aeba:	mov    0x60(%rbx),%rdi
  30aebe:	mov    0x90(%rbx),%rdx
  30aec5:	mov    0xa0(%rbx),%r8
  30aecc:	sub    $0x8,%rsp
  30aed0:	mov    %rsi,%rcx
  30aed3:	mov    %rsi,%r9
  30aed6:	push   0x68(%rsp)
  30aeda:	vzeroupper
  30aedd:	call   300ea0 <rustsht::legendre::scalar_ordered::kernel::initialize_sectoral_batch::<pulp::x86::v3::V3>>
  30aee2:	add    $0x10,%rsp
  30aee6:	test   %al,%al
  30aee8:	je     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30aeee:	mov    0x88(%rbx),%rdx
  30aef5:	mov    0x8(%rsp),%r8
  30aefa:	cmp    %rdx,%r8
  30aefd:	ja     30e260 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3ea0>
  30af03:	lea    0x0(,%r8,8),%r13
  30af0b:	test   %r8,%r8
  30af0e:	je     30afc8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0xc08>
  30af14:	mov    %r14,%r15
  30af17:	mov    0x80(%rbx),%rdi
  30af1e:	xor    %esi,%esi
  30af20:	mov    %r13,%rdx
  30af23:	mov    %rbx,%r14
  30af26:	mov    %r8,%rbx
  30af29:	call   *0xb21a1(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30af2f:	mov    0xc8(%r14),%rdx
  30af36:	cmp    %rdx,%rbx
  30af39:	ja     30e321 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f61>
  30af3f:	mov    0xc0(%r14),%rdi
  30af46:	xor    %esi,%esi
  30af48:	mov    %r13,%rdx
  30af4b:	call   *0xb217f(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30af51:	mov    0xd8(%r14),%rdx
  30af58:	cmp    %rdx,0x8(%rsp)
  30af5d:	ja     30e335 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f75>
  30af63:	mov    %r14,%rbx
  30af66:	mov    0xd0(%r14),%rdi
  30af6d:	xor    %esi,%esi
  30af6f:	mov    %r13,%rdx
  30af72:	call   *0xb2158(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30af78:	mov    0xe8(%r14),%rdx
  30af7f:	cmp    %rdx,0x8(%rsp)
  30af84:	ja     30e349 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f89>
  30af8a:	mov    %r15,%r14
  30af8d:	mov    0xe0(%rbx),%rdi
  30af94:	xor    %esi,%esi
  30af96:	mov    %r13,%rdx
  30af99:	call   *0xb2131(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30af9f:	mov    0xf8(%rbx),%rdx
  30afa6:	cmp    %rdx,0x8(%rsp)
  30afab:	ja     30e35d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f9d>
  30afb1:	mov    0xf0(%rbx),%rdi
  30afb8:	xor    %esi,%esi
  30afba:	mov    %r13,%rdx
  30afbd:	call   *0xb210d(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30afc3:	mov    0x8(%rsp),%r8
  30afc8:	mov    0x88(%rbx),%rdx
  30afcf:	cmp    %rdx,%r8
  30afd2:	ja     30e296 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3ed6>
  30afd8:	mov    0x80(%rbx),%rax
  30afdf:	mov    %rax,(%rsp)
  30afe3:	mov    %rax,0xd0(%rsp)
  30afeb:	mov    %r8,0xd8(%rsp)
  30aff3:	mov    0x98(%rbx),%rdx
  30affa:	cmp    %rdx,%r8
  30affd:	mov    0x18(%rsp),%rax
  30b002:	ja     30e2a8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3ee8>
  30b008:	mov    0x90(%rbx),%r15
  30b00f:	mov    %r15,0xe0(%rsp)
  30b017:	mov    %r8,0xe8(%rsp)
  30b01f:	mov    0xa8(%rbx),%rdx
  30b026:	cmp    %rdx,%r8
  30b029:	ja     30e2ba <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3efa>
  30b02f:	sub    $0x8,%rsp
  30b033:	lea    0xe8(%rsp),%r10
  30b03b:	lea    0xd8(%rsp),%r11
  30b043:	lea    0xf8(%rsp),%rdi
  30b04b:	mov    0x68(%rsp),%rsi
  30b050:	mov    %rax,%rdx
  30b053:	mov    %r14,%rcx
  30b056:	mov    0x18(%rsp),%r9
  30b05b:	push   %r8
  30b05d:	push   0xa0(%rbx)
  30b063:	push   %r10
  30b065:	push   %r11
  30b067:	push   0x58(%rsp)
  30b06b:	push   0x58(%rsp)
  30b06f:	push   0x148(%rsp)
  30b076:	call   2fbb60 <rustsht::legendre::scalar_ordered::kernel::iter_to_ieee::<pulp::x86::v3::V3>>
  30b07b:	add    $0x40,%rsp
  30b07f:	movzbl 0x100(%rsp),%eax
  30b087:	cmp    $0x2,%al
  30b089:	je     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30b08f:	mov    0xf0(%rsp),%rbp
  30b097:	cmp    0x18(%rsp),%rbp
  30b09c:	seta   %cl
  30b09f:	or     %al,%cl
  30b0a1:	mov    $0x1,%al
  30b0a3:	test   $0x1,%cl
  30b0a6:	jne    30a50b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x14b>
  30b0ac:	mov    0xa8(%rbx),%rdx
  30b0b3:	mov    0x8(%rsp),%rsi
  30b0b8:	cmp    %rdx,%rsi
  30b0bb:	ja     30e2cc <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f0c>
  30b0c1:	mov    %r14,0x130(%rsp)
  30b0c9:	mov    0xb8(%rbx),%rdx
  30b0d0:	cmp    %rdx,%rsi
  30b0d3:	ja     30e3e4 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4024>
  30b0d9:	mov    %r13,0x60(%rsp)
  30b0de:	mov    0xf8(%rsp),%r12
  30b0e6:	mov    0xa0(%rbx),%rdi
  30b0ed:	mov    0xb0(%rbx),%rdx
  30b0f4:	mov    %rsi,%rcx
  30b0f7:	call   300480 <rustsht::legendre::scalar_ordered::kernel::set_correction_factors::<pulp::x86::v3::V3>>
  30b0fc:	mov    0x8(%rsp),%rsi
  30b101:	mov    0xa8(%rbx),%r14
  30b108:	cmp    %r14,%rsi
  30b10b:	ja     30e42f <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x406f>
  30b111:	mov    0xa0(%rbx),%rdi
  30b118:	mov    %rdi,0x90(%rsp)
  30b120:	call   3000f0 <rustsht::legendre::scalar_ordered::kernel::all_scale_nonnegative::<pulp::x86::v3::V3>>
  30b125:	mov    %eax,%r13d
  30b128:	not    %al
  30b12a:	cmp    0x20(%rsp),%r12
  30b12f:	setb   %dl
  30b132:	and    %dl,%al
  30b134:	cmp    $0x1,%al
  30b136:	mov    %r12,%r10
  30b139:	jne    30bd13 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1953>
  30b13f:	mov    0x8(%rsp),%rsi
  30b144:	mov    %rsi,%rax
  30b147:	shr    $0x2,%rax
  30b14b:	xor    %r13d,%r13d
  30b14e:	cmp    $0x1,%rax
  30b152:	sbb    %rax,%r13
  30b155:	mov    0x60(%rsp),%rax
  30b15a:	add    $0xffffffffffffffe0,%rax
  30b15e:	mov    %rax,0x60(%rsp)
  30b163:	shr    $0x5,%rax
  30b167:	inc    %rax
  30b16a:	movabs $0xffffffffffffff0,%rcx
  30b174:	or     $0xe,%rcx
  30b178:	and    %rax,%rcx
  30b17b:	mov    %rcx,0x170(%rsp)
  30b183:	vbroadcastsd -0x2de46c(%rip),%ymm4        # 2cd20 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x550>
  30b18c:	vpbroadcastq -0x2de47d(%rip),%ymm7        # 2cd18 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x548>
  30b195:	mov    0x20(%rsp),%r12
  30b19a:	vmovupd %ymm4,0x150(%rsp)
  30b1a3:	vmovdqu %ymm7,0x90(%rsp)
  30b1ac:	mov    0xb8(%rbx),%rdx
  30b1b3:	cmp    %rdx,%rsi
  30b1b6:	ja     30e175 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3db5>
  30b1bc:	cmp    0x110(%rsp),%r10
  30b1c4:	mov    0x130(%rsp),%rcx
  30b1cc:	je     30e7f9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4439>
  30b1d2:	cmp    0x30(%rsp),%r10
  30b1d7:	je     30e7b1 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x43f1>
  30b1dd:	cmp    0x48(%rsp),%r10
  30b1e2:	je     30e7c9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4409>
  30b1e8:	cmp    0x38(%rsp),%r10
  30b1ed:	je     30e7e1 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4421>
  30b1f3:	mov    0xc8(%rbx),%rdx
  30b1fa:	cmp    %rdx,%rsi
  30b1fd:	ja     30e187 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3dc7>
  30b203:	mov    0xd8(%rbx),%rdx
  30b20a:	cmp    %rdx,%rsi
  30b20d:	ja     30e199 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3dd9>
  30b213:	mov    0xe8(%rbx),%rdx
  30b21a:	cmp    %rdx,%rsi
  30b21d:	ja     30e1ab <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3deb>
  30b223:	mov    0xf8(%rbx),%rdx
  30b22a:	cmp    %rdx,%rsi
  30b22d:	ja     30e1bd <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3dfd>
  30b233:	mov    0xb0(%rbx),%rdi
  30b23a:	mov    0x10(%rsp),%rax
  30b23f:	vmovsd (%rax,%r10,8),%xmm0
  30b245:	mov    0x28(%rsp),%rax
  30b24a:	vmovsd (%rax,%r10,8),%xmm1
  30b250:	mov    %r10,%rax
  30b253:	shl    $0x4,%rax
  30b257:	mov    0x50(%rsp),%rdx
  30b25c:	vmovsd (%rdx,%rax,1),%xmm2
  30b261:	vmovsd 0x8(%rdx,%rax,1),%xmm3
  30b267:	mov    0x40(%rsp),%rdx
  30b26c:	vmovsd (%rdx,%rax,1),%xmm4
  30b271:	vmovsd 0x8(%rdx,%rax,1),%xmm5
  30b277:	mov    %rcx,%rdx
  30b27a:	mov    %rsi,%rcx
  30b27d:	mov    (%rsp),%r8
  30b281:	mov    0x8(%rsp),%r9
  30b286:	push   0x8(%rsp)
  30b28a:	push   0xf0(%rbx)
  30b290:	push   0x18(%rsp)
  30b294:	push   0xe0(%rbx)
  30b29a:	push   0x28(%rsp)
  30b29e:	push   0xd0(%rbx)
  30b2a4:	push   0x38(%rsp)
  30b2a8:	push   0xc0(%rbx)
  30b2ae:	push   0x48(%rsp)
  30b2b2:	push   %r15
  30b2b4:	mov    %r10,%r14
  30b2b7:	vzeroupper
  30b2ba:	call   2fe9d0 <rustsht::legendre::scalar_ordered::kernel::scaled_pair_step::<pulp::x86::v3::V3>>
  30b2bf:	mov    0x58(%rsp),%rsi
  30b2c4:	add    $0x50,%rsp
  30b2c8:	mov    0xa8(%rbx),%rdx
  30b2cf:	cmp    %rdx,%rsi
  30b2d2:	ja     30e1cf <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e0f>
  30b2d8:	add    $0x2,%rbp
  30b2dc:	inc    %r14
  30b2df:	mov    0xa0(%rbx),%rcx
  30b2e6:	xor    %r8d,%r8d
  30b2e9:	xor    %edx,%edx
  30b2eb:	mov    0x18(%rsp),%rax
  30b2f0:	mov    %r14,%r10
  30b2f3:	vmovupd 0x150(%rsp),%ymm4
  30b2fc:	vbroadcastsd -0x2de07d(%rip),%ymm5        # 2d288 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0xab8>
  30b305:	vpxor  %xmm6,%xmm6,%xmm6
  30b309:	vmovdqu 0x90(%rsp),%ymm7
  30b312:	vxorpd %xmm8,%xmm8,%xmm8
  30b317:	mov    %rdx,%rdi
  30b31a:	shl    $0x5,%rdi
  30b31e:	inc    %rdx
  30b321:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  30b330:	vandpd (%r15,%rdi,1),%ymm4,%ymm0
  30b336:	vcmpgt_oqpd %ymm5,%ymm0,%ymm0
  30b33b:	vpcmpgtq %ymm0,%ymm6,%ymm1
  30b340:	vpand  %ymm7,%ymm1,%ymm2
  30b344:	vextracti128 $0x1,%ymm2,%xmm3
  30b34a:	vmaxpd %xmm3,%xmm2,%xmm2
  30b34e:	vshufpd $0x1,%xmm2,%xmm2,%xmm3
  30b353:	vmaxsd %xmm3,%xmm2,%xmm2
  30b357:	vucomisd %xmm8,%xmm2
  30b35c:	ja     30b374 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0xfb4>
  30b35e:	add    $0x20,%rdi
  30b362:	lea    (%rdx,%r13,1),%r9
  30b366:	inc    %r9
  30b369:	inc    %rdx
  30b36c:	cmp    $0x1,%r9
  30b370:	jne    30b330 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0xf70>
  30b372:	jmp    30b3ec <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x102c>
  30b374:	vpcmpeqq (%rcx,%rdi,1),%ymm4,%ymm2
  30b37a:	vpand  %ymm7,%ymm2,%ymm2
  30b37e:	vpand  %ymm1,%ymm2,%ymm1
  30b382:	vextracti128 $0x1,%ymm1,%xmm2
  30b388:	vmaxpd %xmm2,%xmm1,%xmm1
  30b38c:	vshufpd $0x1,%xmm1,%xmm1,%xmm2
  30b391:	vmaxsd %xmm2,%xmm1,%xmm1
  30b395:	vucomisd %xmm8,%xmm1
  30b39a:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30b3a0:	mov    (%rsp),%r8
  30b3a4:	vbroadcastsd -0x2de25d(%rip),%ymm2        # 2d150 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x980>
  30b3ad:	vmulpd (%r8,%rdi,1),%ymm2,%ymm1
  30b3b3:	vmaskmovpd %ymm1,%ymm0,(%r8,%rdi,1)
  30b3b9:	vmulpd (%r15,%rdi,1),%ymm2,%ymm1
  30b3bf:	vmaskmovpd %ymm1,%ymm0,(%r15,%rdi,1)
  30b3c5:	mov    %r13,%r9
  30b3c8:	vpsrlq $0x3f,%ymm0,%ymm0
  30b3cd:	vpaddq (%rcx,%rdi,1),%ymm0,%ymm0
  30b3d2:	vmovdqu %ymm0,(%rcx,%rdi,1)
  30b3d7:	mov    $0x1,%r8b
  30b3da:	add    %rdx,%r9
  30b3dd:	jne    30b317 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0xf57>
  30b3e3:	mov    0xa8(%rbx),%r14
  30b3ea:	jmp    30b3f9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1039>
  30b3ec:	mov    0xa8(%rbx),%r14
  30b3f3:	test   $0x1,%r8b
  30b3f7:	je     30b455 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1095>
  30b3f9:	cmp    %r14,%rsi
  30b3fc:	ja     30e3aa <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3fea>
  30b402:	mov    0xb8(%rbx),%rdx
  30b409:	cmp    %rdx,%rsi
  30b40c:	ja     30e22a <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e6a>
  30b412:	mov    %r10,%r12
  30b415:	mov    0xa0(%rbx),%rdi
  30b41c:	mov    0xb0(%rbx),%rdx
  30b423:	mov    %rsi,%rcx
  30b426:	vzeroupper
  30b429:	call   300480 <rustsht::legendre::scalar_ordered::kernel::set_correction_factors::<pulp::x86::v3::V3>>
  30b42e:	mov    0x8(%rsp),%rsi
  30b433:	mov    0xa8(%rbx),%r14
  30b43a:	mov    0x18(%rsp),%rax
  30b43f:	mov    %r12,%r10
  30b442:	mov    0x20(%rsp),%r12
  30b447:	vmovdqu 0x90(%rsp),%ymm7
  30b450:	vxorpd %xmm8,%xmm8,%xmm8
  30b455:	cmp    %r14,%rsi
  30b458:	vpcmpeqd %ymm3,%ymm3,%ymm3
  30b45c:	ja     30e2db <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f1b>
  30b462:	mov    0xa0(%rbx),%r11
  30b469:	cmpq   $0x0,0x60(%rsp)
  30b46f:	je     30b4ec <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x112c>
  30b471:	mov    $0x1,%cl
  30b473:	mov    0x170(%rsp),%rdi
  30b47b:	mov    %r11,%rdx
  30b47e:	vmovdqu (%rdx),%ymm0
  30b482:	vmovdqu 0x20(%rdx),%ymm1
  30b487:	vpcmpgtq %ymm3,%ymm0,%ymm0
  30b48c:	vpand  %ymm7,%ymm0,%ymm0
  30b490:	vextracti128 $0x1,%ymm0,%xmm2
  30b496:	vminpd %xmm2,%xmm0,%xmm0
  30b49a:	vshufpd $0x1,%xmm0,%xmm0,%xmm2
  30b49f:	vminsd %xmm2,%xmm0,%xmm0
  30b4a3:	vucomisd %xmm8,%xmm0
  30b4a8:	seta   %r8b
  30b4ac:	mov    %ecx,%r9d
  30b4af:	and    %r8b,%r9b
  30b4b2:	add    $0x40,%rdx
  30b4b6:	vpcmpgtq %ymm3,%ymm1,%ymm0
  30b4bb:	vpand  %ymm7,%ymm0,%ymm0
  30b4bf:	vextracti128 $0x1,%ymm0,%xmm1
  30b4c5:	vminpd %xmm1,%xmm0,%xmm0
  30b4c9:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  30b4ce:	vminsd %xmm1,%xmm0,%xmm0
  30b4d2:	vucomisd %xmm8,%xmm0
  30b4d7:	seta   %cl
  30b4da:	and    %r9b,%cl
  30b4dd:	add    $0xfffffffffffffffe,%rdi
  30b4e1:	jne    30b47e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x10be>
  30b4e3:	testb  $0x20,0x60(%rsp)
  30b4e8:	je     30b4f1 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1131>
  30b4ea:	jmp    30b51e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x115e>
  30b4ec:	mov    $0x1,%cl
  30b4ee:	mov    %r11,%rdx
  30b4f1:	mov    %ecx,%edi
  30b4f3:	vmovdqu (%rdx),%ymm0
  30b4f7:	vpcmpgtq %ymm3,%ymm0,%ymm0
  30b4fc:	vpand  %ymm7,%ymm0,%ymm0
  30b500:	vextracti128 $0x1,%ymm0,%xmm1
  30b506:	vminpd %xmm1,%xmm0,%xmm0
  30b50a:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  30b50f:	vminsd %xmm1,%xmm0,%xmm0
  30b513:	vucomisd %xmm8,%xmm0
  30b518:	seta   %cl
  30b51b:	and    %dil,%cl
  30b51e:	cmp    %r12,%r10
  30b521:	setb   %dl
  30b524:	test   %cl,%cl
  30b526:	jne    30d0dc <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2d1c>
  30b52c:	cmp    %rax,%rbp
  30b52f:	ja     30da8d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x36cd>
  30b535:	cmp    %r12,%r10
  30b538:	jb     30b1ac <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0xdec>
  30b53e:	jmp    30da8d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x36cd>
  30b543:	mov    0xa0(%rbx),%r10
  30b54a:	jmp    30c08b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1ccb>
  30b54f:	movabs $0xffffffffffffff0,%rdi
  30b559:	cmp    $0x10,%rsi
  30b55d:	jae    30bdae <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x19ee>
  30b563:	xor    %edx,%edx
  30b565:	jmp    30be7b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1abb>
  30b56a:	mov    %rcx,%r8
  30b56d:	and    %rdi,%r8
  30b570:	lea    (%rax,%r8,8),%rdx
  30b574:	vpbroadcastq %xmm0,%ymm2
  30b579:	add    %r14,%r9
  30b57c:	add    $0x60,%r9
  30b580:	xor    %r10d,%r10d
  30b583:	vmovdqu %ymm2,-0x60(%r9,%r10,8)
  30b58a:	vmovdqu %ymm2,-0x40(%r9,%r10,8)
  30b591:	vmovdqu %ymm2,-0x20(%r9,%r10,8)
  30b598:	vmovdqu %ymm2,(%r9,%r10,8)
  30b59e:	add    $0x10,%r10
  30b5a2:	cmp    %r10,%r8
  30b5a5:	jne    30b583 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x11c3>
  30b5a7:	cmp    %r8,%rcx
  30b5aa:	je     30b5e6 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1226>
  30b5ac:	test   $0xc,%cl
  30b5af:	je     30b5d5 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1215>
  30b5b1:	add    $0xc,%rdi
  30b5b5:	and    %rcx,%rdi
  30b5b8:	lea    (%rax,%rdi,8),%rdx
  30b5bc:	vpbroadcastq %xmm0,%ymm2
  30b5c1:	vmovdqu %ymm2,(%rax,%r8,8)
  30b5c7:	add    $0x4,%r8
  30b5cb:	cmp    %r8,%rdi
  30b5ce:	jne    30b5c1 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1201>
  30b5d0:	cmp    %rdi,%rcx
  30b5d3:	je     30b5e6 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1226>
  30b5d5:	lea    (%rax,%r13,8),%rax
  30b5d9:	vmovq  %xmm0,(%rdx)
  30b5dd:	add    $0x8,%rdx
  30b5e1:	cmp    %rax,%rdx
  30b5e4:	jne    30b5d9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1219>
  30b5e6:	mov    0x68(%rbx),%rdx
  30b5ea:	cmp    %rdx,%rsi
  30b5ed:	ja     30e24e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e8e>
  30b5f3:	mov    0x98(%rbx),%rdx
  30b5fa:	cmp    %rdx,%rsi
  30b5fd:	ja     30e272 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3eb2>
  30b603:	mov    0xa8(%rbx),%rdx
  30b60a:	cmp    %rdx,%rsi
  30b60d:	ja     30e284 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3ec4>
  30b613:	mov    0x60(%rbx),%rdi
  30b617:	mov    0x90(%rbx),%rdx
  30b61e:	mov    0xa0(%rbx),%r8
  30b625:	sub    $0x8,%rsp
  30b629:	vpxor  %xmm0,%xmm0,%xmm0
  30b62d:	mov    %rsi,%rcx
  30b630:	mov    %rsi,%r9
  30b633:	push   $0x0
  30b635:	vzeroupper
  30b638:	call   300ea0 <rustsht::legendre::scalar_ordered::kernel::initialize_sectoral_batch::<pulp::x86::v3::V3>>
  30b63d:	add    $0x10,%rsp
  30b641:	test   %al,%al
  30b643:	je     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30b649:	mov    0x88(%rbx),%rdx
  30b650:	mov    0x8(%rsp),%r8
  30b655:	cmp    %rdx,%r8
  30b658:	ja     30e260 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3ea0>
  30b65e:	lea    0x0(,%r8,8),%r15
  30b666:	test   %r8,%r8
  30b669:	je     30b71d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x135d>
  30b66f:	mov    0x80(%rbx),%rdi
  30b676:	xor    %esi,%esi
  30b678:	mov    %r15,%rdx
  30b67b:	mov    %rbx,%r14
  30b67e:	mov    %r8,%rbx
  30b681:	call   *0xb1a49(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30b687:	mov    0xc8(%r14),%rdx
  30b68e:	cmp    %rdx,%rbx
  30b691:	ja     30e321 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f61>
  30b697:	mov    0xc0(%r14),%rdi
  30b69e:	xor    %esi,%esi
  30b6a0:	mov    %r15,%rdx
  30b6a3:	call   *0xb1a27(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30b6a9:	mov    0xd8(%r14),%rdx
  30b6b0:	cmp    %rdx,0x8(%rsp)
  30b6b5:	ja     30e335 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f75>
  30b6bb:	mov    %r14,%rbx
  30b6be:	mov    0xd0(%r14),%rdi
  30b6c5:	xor    %esi,%esi
  30b6c7:	mov    %r15,%rdx
  30b6ca:	call   *0xb1a00(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30b6d0:	mov    0xe8(%r14),%rdx
  30b6d7:	cmp    %rdx,0x8(%rsp)
  30b6dc:	ja     30e349 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f89>
  30b6e2:	mov    0xe0(%rbx),%rdi
  30b6e9:	xor    %esi,%esi
  30b6eb:	mov    %r15,%rdx
  30b6ee:	call   *0xb19dc(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30b6f4:	mov    0xf8(%rbx),%rdx
  30b6fb:	cmp    %rdx,0x8(%rsp)
  30b700:	ja     30e35d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f9d>
  30b706:	mov    0xf0(%rbx),%rdi
  30b70d:	xor    %esi,%esi
  30b70f:	mov    %r15,%rdx
  30b712:	call   *0xb19b8(%rip)        # 3bd0d0 <memset@GLIBC_2.2.5>
  30b718:	mov    0x8(%rsp),%r8
  30b71d:	mov    0x88(%rbx),%rdx
  30b724:	cmp    %rdx,%r8
  30b727:	ja     30e296 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3ed6>
  30b72d:	mov    0x80(%rbx),%rax
  30b734:	mov    %rax,(%rsp)
  30b738:	mov    %rax,0xd0(%rsp)
  30b740:	mov    %r8,0xd8(%rsp)
  30b748:	mov    0x98(%rbx),%rdx
  30b74f:	cmp    %rdx,%r8
  30b752:	ja     30e2a8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3ee8>
  30b758:	mov    0x90(%rbx),%r14
  30b75f:	mov    %r14,0xe0(%rsp)
  30b767:	mov    %r8,0xe8(%rsp)
  30b76f:	mov    0xa8(%rbx),%rdx
  30b776:	cmp    %rdx,%r8
  30b779:	ja     30e2ba <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3efa>
  30b77f:	sub    $0x8,%rsp
  30b783:	lea    0xe8(%rsp),%rax
  30b78b:	lea    0xd8(%rsp),%r10
  30b793:	lea    0xf8(%rsp),%rdi
  30b79b:	xor    %esi,%esi
  30b79d:	mov    %r12,0x20(%rsp)
  30b7a2:	mov    %r12,%rdx
  30b7a5:	mov    0x68(%rsp),%rcx
  30b7aa:	mov    0x28(%rsp),%r9
  30b7af:	push   %r8
  30b7b1:	push   0xa0(%rbx)
  30b7b7:	push   %rax
  30b7b8:	push   %r10
  30b7ba:	push   0x58(%rsp)
  30b7be:	push   0x40(%rsp)
  30b7c2:	push   0x148(%rsp)
  30b7c9:	call   2fbb60 <rustsht::legendre::scalar_ordered::kernel::iter_to_ieee::<pulp::x86::v3::V3>>
  30b7ce:	add    $0x40,%rsp
  30b7d2:	movzbl 0x100(%rsp),%eax
  30b7da:	cmp    $0x2,%al
  30b7dc:	je     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30b7e2:	mov    0xf0(%rsp),%rcx
  30b7ea:	mov    %rcx,0x90(%rsp)
  30b7f2:	cmp    0x18(%rsp),%rcx
  30b7f7:	seta   %cl
  30b7fa:	or     %al,%cl
  30b7fc:	mov    $0x1,%al
  30b7fe:	test   $0x1,%cl
  30b801:	jne    30a50b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x14b>
  30b807:	mov    0xa8(%rbx),%rdx
  30b80e:	mov    0x8(%rsp),%rsi
  30b813:	cmp    %rdx,%rsi
  30b816:	ja     30e2cc <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3f0c>
  30b81c:	mov    0xb8(%rbx),%rdx
  30b823:	cmp    %rdx,%rsi
  30b826:	ja     30e3e4 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4024>
  30b82c:	mov    %r15,0x40(%rsp)
  30b831:	mov    0xf8(%rsp),%rbp
  30b839:	mov    0xa0(%rbx),%rdi
  30b840:	mov    0xb0(%rbx),%rdx
  30b847:	mov    %rsi,%rcx
  30b84a:	call   300480 <rustsht::legendre::scalar_ordered::kernel::set_correction_factors::<pulp::x86::v3::V3>>
  30b84f:	mov    0x8(%rsp),%rsi
  30b854:	mov    0xa8(%rbx),%r15
  30b85b:	cmp    %r15,%rsi
  30b85e:	ja     30e441 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4081>
  30b864:	mov    0x18(%rsp),%rax
  30b869:	lea    0x2(%rax),%r13
  30b86d:	shr    $1,%r13
  30b870:	mov    0xa0(%rbx),%r12
  30b877:	mov    %r12,%rdi
  30b87a:	call   3000f0 <rustsht::legendre::scalar_ordered::kernel::all_scale_nonnegative::<pulp::x86::v3::V3>>
  30b87f:	mov    %eax,%ecx
  30b881:	not    %cl
  30b883:	mov    %r13,0x80(%rsp)
  30b88b:	cmp    %r13,%rbp
  30b88e:	setb   %dl
  30b891:	and    %dl,%cl
  30b893:	cmp    $0x1,%cl
  30b896:	mov    %rbp,%r10
  30b899:	jne    30c696 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x22d6>
  30b89f:	mov    0x8(%rsp),%rsi
  30b8a4:	mov    %rsi,%rax
  30b8a7:	shr    $0x2,%rax
  30b8ab:	xor    %r13d,%r13d
  30b8ae:	cmp    $0x1,%rax
  30b8b2:	sbb    %rax,%r13
  30b8b5:	mov    0x110(%rsp),%rax
  30b8bd:	cmp    %rax,%r10
  30b8c0:	cmova  %r10,%rax
  30b8c4:	mov    %rax,0x150(%rsp)
  30b8cc:	mov    0x30(%rsp),%rax
  30b8d1:	cmp    %rax,%r10
  30b8d4:	cmova  %r10,%rax
  30b8d8:	mov    %rax,0x170(%rsp)
  30b8e0:	mov    0x48(%rsp),%rax
  30b8e5:	cmp    %rax,%r10
  30b8e8:	cmova  %r10,%rax
  30b8ec:	mov    %rax,0x1b0(%rsp)
  30b8f4:	mov    0x38(%rsp),%rax
  30b8f9:	cmp    %rax,%r10
  30b8fc:	cmova  %r10,%rax
  30b900:	mov    %rax,0x58(%rsp)
  30b905:	mov    0x40(%rsp),%rax
  30b90a:	add    $0xffffffffffffffe0,%rax
  30b90e:	mov    %rax,0x40(%rsp)
  30b913:	shr    $0x5,%rax
  30b917:	inc    %rax
  30b91a:	movabs $0xffffffffffffff0,%rcx
  30b924:	or     $0xe,%rcx
  30b928:	and    %rax,%rcx
  30b92b:	mov    %rcx,0x88(%rsp)
  30b933:	vbroadcastsd -0x2dec1c(%rip),%ymm4        # 2cd20 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x550>
  30b93c:	vpbroadcastq -0x2dec2d(%rip),%ymm7        # 2cd18 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x548>
  30b945:	mov    0x80(%rsp),%rbp
  30b94d:	vmovupd %ymm4,0x190(%rsp)
  30b956:	vmovdqu %ymm7,0x130(%rsp)
  30b95f:	mov    0xb8(%rbx),%rdx
  30b966:	cmp    %rdx,%rsi
  30b969:	ja     30e175 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3db5>
  30b96f:	cmp    0x150(%rsp),%r10
  30b977:	je     30e868 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x44a8>
  30b97d:	cmp    0x170(%rsp),%r10
  30b985:	je     30e814 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4454>
  30b98b:	cmp    0x1b0(%rsp),%r10
  30b993:	je     30e831 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4471>
  30b999:	cmp    0x58(%rsp),%r10
  30b99e:	je     30e84e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x448e>
  30b9a4:	mov    0xc8(%rbx),%rdx
  30b9ab:	cmp    %rdx,%rsi
  30b9ae:	ja     30e187 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3dc7>
  30b9b4:	mov    0xd8(%rbx),%rdx
  30b9bb:	cmp    %rdx,%rsi
  30b9be:	ja     30e199 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3dd9>
  30b9c4:	mov    0xe8(%rbx),%rdx
  30b9cb:	cmp    %rdx,%rsi
  30b9ce:	ja     30e1ab <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3deb>
  30b9d4:	mov    0xf8(%rbx),%rdx
  30b9db:	cmp    %rdx,%rsi
  30b9de:	ja     30e1bd <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3dfd>
  30b9e4:	mov    0xb0(%rbx),%rdi
  30b9eb:	mov    0x20(%rsp),%rax
  30b9f0:	vmovsd (%rax,%r10,8),%xmm0
  30b9f6:	mov    0x10(%rsp),%rax
  30b9fb:	vmovsd (%rax,%r10,8),%xmm1
  30ba01:	mov    %r10,%rax
  30ba04:	shl    $0x4,%rax
  30ba08:	mov    0x28(%rsp),%rcx
  30ba0d:	vmovsd (%rcx,%rax,1),%xmm2
  30ba12:	vmovsd 0x8(%rcx,%rax,1),%xmm3
  30ba18:	mov    0x50(%rsp),%rcx
  30ba1d:	vmovsd (%rcx,%rax,1),%xmm4
  30ba22:	vmovsd 0x8(%rcx,%rax,1),%xmm5
  30ba28:	mov    0x60(%rsp),%rdx
  30ba2d:	mov    %rsi,%rcx
  30ba30:	mov    (%rsp),%r8
  30ba34:	mov    0x8(%rsp),%r9
  30ba39:	push   0x8(%rsp)
  30ba3d:	push   0xf0(%rbx)
  30ba43:	push   0x18(%rsp)
  30ba47:	push   0xe0(%rbx)
  30ba4d:	push   0x28(%rsp)
  30ba51:	push   0xd0(%rbx)
  30ba57:	push   0x38(%rsp)
  30ba5b:	push   0xc0(%rbx)
  30ba61:	push   0x48(%rsp)
  30ba65:	push   %r14
  30ba67:	mov    %r10,%r15
  30ba6a:	vzeroupper
  30ba6d:	call   2fe9d0 <rustsht::legendre::scalar_ordered::kernel::scaled_pair_step::<pulp::x86::v3::V3>>
  30ba72:	mov    0x58(%rsp),%rsi
  30ba77:	add    $0x50,%rsp
  30ba7b:	mov    0xa8(%rbx),%rdx
  30ba82:	cmp    %rdx,%rsi
  30ba85:	ja     30e1cf <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e0f>
  30ba8b:	addq   $0x2,0x90(%rsp)
  30ba94:	inc    %r15
  30ba97:	mov    0xa0(%rbx),%rcx
  30ba9e:	xor    %r8d,%r8d
  30baa1:	xor    %edx,%edx
  30baa3:	mov    0x18(%rsp),%r11
  30baa8:	mov    %r15,%r10
  30baab:	vmovupd 0x190(%rsp),%ymm4
  30bab4:	vbroadcastsd -0x2de835(%rip),%ymm5        # 2d288 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0xab8>
  30babd:	vpxor  %xmm6,%xmm6,%xmm6
  30bac1:	vmovdqu 0x130(%rsp),%ymm7
  30baca:	vxorpd %xmm8,%xmm8,%xmm8
  30bacf:	mov    %rdx,%rdi
  30bad2:	shl    $0x5,%rdi
  30bad6:	inc    %rdx
  30bad9:	vandpd (%r14,%rdi,1),%ymm4,%ymm0
  30badf:	vcmpgt_oqpd %ymm5,%ymm0,%ymm0
  30bae4:	vpcmpgtq %ymm0,%ymm6,%ymm1
  30bae9:	vpand  %ymm7,%ymm1,%ymm2
  30baed:	vextracti128 $0x1,%ymm2,%xmm3
  30baf3:	vmaxpd %xmm3,%xmm2,%xmm2
  30baf7:	vshufpd $0x1,%xmm2,%xmm2,%xmm3
  30bafc:	vmaxsd %xmm3,%xmm2,%xmm2
  30bb00:	vucomisd %xmm8,%xmm2
  30bb05:	ja     30bb1d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x175d>
  30bb07:	add    $0x20,%rdi
  30bb0b:	lea    (%rdx,%r13,1),%r9
  30bb0f:	inc    %r9
  30bb12:	inc    %rdx
  30bb15:	cmp    $0x1,%r9
  30bb19:	jne    30bad9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1719>
  30bb1b:	jmp    30bb95 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x17d5>
  30bb1d:	vpcmpeqq (%rcx,%rdi,1),%ymm4,%ymm2
  30bb23:	vpand  %ymm7,%ymm2,%ymm2
  30bb27:	vpand  %ymm1,%ymm2,%ymm1
  30bb2b:	vextracti128 $0x1,%ymm1,%xmm2
  30bb31:	vmaxpd %xmm2,%xmm1,%xmm1
  30bb35:	vshufpd $0x1,%xmm1,%xmm1,%xmm2
  30bb3a:	vmaxsd %xmm2,%xmm1,%xmm1
  30bb3e:	vucomisd %xmm8,%xmm1
  30bb43:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30bb49:	mov    (%rsp),%r8
  30bb4d:	vbroadcastsd -0x2dea06(%rip),%ymm2        # 2d150 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x980>
  30bb56:	vmulpd (%r8,%rdi,1),%ymm2,%ymm1
  30bb5c:	vmaskmovpd %ymm1,%ymm0,(%r8,%rdi,1)
  30bb62:	vmulpd (%r14,%rdi,1),%ymm2,%ymm1
  30bb68:	vmaskmovpd %ymm1,%ymm0,(%r14,%rdi,1)
  30bb6e:	mov    %r13,%r9
  30bb71:	vpsrlq $0x3f,%ymm0,%ymm0
  30bb76:	vpaddq (%rcx,%rdi,1),%ymm0,%ymm0
  30bb7b:	vmovdqu %ymm0,(%rcx,%rdi,1)
  30bb80:	mov    $0x1,%r8b
  30bb83:	add    %rdx,%r9
  30bb86:	jne    30bacf <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x170f>
  30bb8c:	mov    0xa8(%rbx),%r15
  30bb93:	jmp    30bba2 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x17e2>
  30bb95:	mov    0xa8(%rbx),%r15
  30bb9c:	test   $0x1,%r8b
  30bba0:	je     30bbf9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1839>
  30bba2:	cmp    %r15,%rsi
  30bba5:	ja     30e3f3 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4033>
  30bbab:	mov    0xb8(%rbx),%rdx
  30bbb2:	cmp    %rdx,%rsi
  30bbb5:	ja     30e22a <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e6a>
  30bbbb:	mov    %r10,%r12
  30bbbe:	mov    0xa0(%rbx),%rdi
  30bbc5:	mov    0xb0(%rbx),%rdx
  30bbcc:	mov    %rsi,%rcx
  30bbcf:	vzeroupper
  30bbd2:	call   300480 <rustsht::legendre::scalar_ordered::kernel::set_correction_factors::<pulp::x86::v3::V3>>
  30bbd7:	mov    0x8(%rsp),%rsi
  30bbdc:	mov    0xa8(%rbx),%r15
  30bbe3:	mov    0x18(%rsp),%r11
  30bbe8:	mov    %r12,%r10
  30bbeb:	vmovdqu 0x130(%rsp),%ymm7
  30bbf4:	vxorpd %xmm8,%xmm8,%xmm8
  30bbf9:	cmp    %r15,%rsi
  30bbfc:	vpcmpeqd %ymm3,%ymm3,%ymm3
  30bc00:	ja     30e383 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3fc3>
  30bc06:	mov    0xa0(%rbx),%r12
  30bc0d:	cmpq   $0x0,0x40(%rsp)
  30bc13:	je     30bc90 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x18d0>
  30bc15:	mov    $0x1,%cl
  30bc17:	mov    0x88(%rsp),%rdi
  30bc1f:	mov    %r12,%rdx
  30bc22:	vmovdqu (%rdx),%ymm0
  30bc26:	vmovdqu 0x20(%rdx),%ymm1
  30bc2b:	vpcmpgtq %ymm3,%ymm0,%ymm0
  30bc30:	vpand  %ymm7,%ymm0,%ymm0
  30bc34:	vextracti128 $0x1,%ymm0,%xmm2
  30bc3a:	vminpd %xmm2,%xmm0,%xmm0
  30bc3e:	vshufpd $0x1,%xmm0,%xmm0,%xmm2
  30bc43:	vminsd %xmm2,%xmm0,%xmm0
  30bc47:	vucomisd %xmm8,%xmm0
  30bc4c:	seta   %r8b
  30bc50:	mov    %ecx,%r9d
  30bc53:	and    %r8b,%r9b
  30bc56:	add    $0x40,%rdx
  30bc5a:	vpcmpgtq %ymm3,%ymm1,%ymm0
  30bc5f:	vpand  %ymm7,%ymm0,%ymm0
  30bc63:	vextracti128 $0x1,%ymm0,%xmm1
  30bc69:	vminpd %xmm1,%xmm0,%xmm0
  30bc6d:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  30bc72:	vminsd %xmm1,%xmm0,%xmm0
  30bc76:	vucomisd %xmm8,%xmm0
  30bc7b:	seta   %cl
  30bc7e:	and    %r9b,%cl
  30bc81:	add    $0xfffffffffffffffe,%rdi
  30bc85:	jne    30bc22 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1862>
  30bc87:	testb  $0x20,0x40(%rsp)
  30bc8c:	je     30bc95 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x18d5>
  30bc8e:	jmp    30bcc2 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1902>
  30bc90:	mov    $0x1,%cl
  30bc92:	mov    %r12,%rdx
  30bc95:	mov    %ecx,%edi
  30bc97:	vmovdqu (%rdx),%ymm0
  30bc9b:	vpcmpgtq %ymm3,%ymm0,%ymm0
  30bca0:	vpand  %ymm7,%ymm0,%ymm0
  30bca4:	vextracti128 $0x1,%ymm0,%xmm1
  30bcaa:	vminpd %xmm1,%xmm0,%xmm0
  30bcae:	vshufpd $0x1,%xmm0,%xmm0,%xmm1
  30bcb3:	vminsd %xmm1,%xmm0,%xmm0
  30bcb7:	vucomisd %xmm8,%xmm0
  30bcbc:	seta   %cl
  30bcbf:	and    %dil,%cl
  30bcc2:	cmp    %rbp,%r10
  30bcc5:	setb   %dl
  30bcc8:	test   %cl,%cl
  30bcca:	jne    30d773 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x33b3>
  30bcd0:	cmp    %r11,0x90(%rsp)
  30bcd8:	ja     30dc38 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3878>
  30bcde:	cmp    %rbp,%r10
  30bce1:	jb     30b95f <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x159f>
  30bce7:	jmp    30dc38 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3878>
  30bcec:	mov    0xa0(%rbx),%r10
  30bcf3:	jmp    30ca09 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2649>
  30bcf8:	movabs $0xffffffffffffff0,%rdi
  30bd02:	cmp    $0x10,%rsi
  30bd06:	jae    30c72e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x236e>
  30bd0c:	xor    %edx,%edx
  30bd0e:	jmp    30c7f9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2439>
  30bd13:	mov    0x18(%rsp),%rax
  30bd18:	mov    0x8(%rsp),%rsi
  30bd1d:	mov    0x20(%rsp),%r12
  30bd22:	mov    0x90(%rsp),%r11
  30bd2a:	test   %r13b,%dl
  30bd2d:	je     30bd87 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x19c7>
  30bd2f:	mov    0xb8(%rbx),%rdx
  30bd36:	cmp    %rdx,%rsi
  30bd39:	ja     30e453 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4093>
  30bd3f:	cmp    %r14,%rsi
  30bd42:	ja     30e465 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x40a5>
  30bd48:	mov    %r10,%r12
  30bd4b:	mov    0xb0(%rbx),%r8
  30bd52:	mov    (%rsp),%rdi
  30bd56:	mov    %r15,%rdx
  30bd59:	mov    %rsi,%rcx
  30bd5c:	mov    0x8(%rsp),%r9
  30bd61:	push   0x8(%rsp)
  30bd65:	push   %r11
  30bd67:	vzeroupper
  30bd6a:	call   305f10 <rustsht::legendre::scalar_ordered::kernel::apply_correction_and_clear_scale::<pulp::x86::v3::V3>>
  30bd6f:	mov    0x18(%rsp),%rsi
  30bd74:	add    $0x10,%rsp
  30bd78:	mov    $0x1,%dl
  30bd7a:	mov    0x18(%rsp),%rax
  30bd7f:	mov    %r12,%r10
  30bd82:	mov    0x20(%rsp),%r12
  30bd87:	and    %dl,%r13b
  30bd8a:	cmp    $0x1,%r13b
  30bd8e:	jne    30da8d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x36cd>
  30bd94:	cmp    $0x8,%rsi
  30bd98:	mov    %r10,0x110(%rsp)
  30bda0:	jae    30d0ed <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2d2d>
  30bda6:	xor    %r9d,%r9d
  30bda9:	jmp    30da53 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3693>
  30bdae:	mov    %rsi,%rdx
  30bdb1:	and    %rdi,%rdx
  30bdb4:	mov    0x10(%rsp),%r8
  30bdb9:	and    $0xffffffffffffff80,%r8
  30bdbd:	xor    %r9d,%r9d
  30bdc0:	vxorpd %xmm0,%xmm0,%xmm0
  30bdc4:	vbroadcastsd -0x2df0b5(%rip),%ymm1        # 2cd18 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x548>
  30bdcd:	vbroadcastsd -0x2deafe(%rip),%ymm2        # 2d2d8 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0xb08>
  30bdd6:	vmovdqu (%rax,%r9,1),%ymm3
  30bddc:	vmovdqu 0x20(%rax,%r9,1),%ymm4
  30bde3:	vmovdqu 0x40(%rax,%r9,1),%ymm5
  30bdea:	vmovdqu 0x60(%rax,%r9,1),%ymm6
  30bdf1:	vpcmpeqq %ymm0,%ymm3,%ymm7
  30bdf6:	vpcmpeqq %ymm0,%ymm4,%ymm8
  30bdfb:	vpcmpeqq %ymm0,%ymm5,%ymm9
  30be00:	vpcmpeqq %ymm0,%ymm6,%ymm10
  30be05:	vblendvpd %ymm7,%ymm1,%ymm2,%ymm7
  30be0b:	vblendvpd %ymm8,%ymm1,%ymm2,%ymm8
  30be11:	vblendvpd %ymm9,%ymm1,%ymm2,%ymm9
  30be17:	vblendvpd %ymm10,%ymm1,%ymm2,%ymm10
  30be1d:	vpcmpgtq %ymm3,%ymm0,%ymm3
  30be22:	vpandn %ymm7,%ymm3,%ymm3
  30be26:	vpcmpgtq %ymm4,%ymm0,%ymm4
  30be2b:	vpandn %ymm8,%ymm4,%ymm4
  30be30:	vpcmpgtq %ymm5,%ymm0,%ymm5
  30be35:	vpandn %ymm9,%ymm5,%ymm5
  30be3a:	vpcmpgtq %ymm6,%ymm0,%ymm6
  30be3f:	vpandn %ymm10,%ymm6,%ymm6
  30be44:	vmovdqu %ymm3,(%rcx,%r9,1)
  30be4a:	vmovdqu %ymm4,0x20(%rcx,%r9,1)
  30be51:	vmovdqu %ymm5,0x40(%rcx,%r9,1)
  30be58:	vmovdqu %ymm6,0x60(%rcx,%r9,1)
  30be5f:	sub    $0xffffffffffffff80,%r9
  30be63:	cmp    %r9,%r8
  30be66:	jne    30bdd6 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1a16>
  30be6c:	cmp    %rdx,%rsi
  30be6f:	je     30becc <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1b0c>
  30be71:	test   $0xc,%sil
  30be75:	je     30bf1d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1b5d>
  30be7b:	mov    %rdx,%r8
  30be7e:	add    $0xc,%rdi
  30be82:	mov    %rdi,%rdx
  30be85:	and    %rsi,%rdx
  30be88:	vpxor  %xmm0,%xmm0,%xmm0
  30be8c:	vbroadcastsd -0x2df17d(%rip),%ymm1        # 2cd18 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x548>
  30be95:	vbroadcastsd -0x2debc6(%rip),%ymm2        # 2d2d8 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0xb08>
  30be9e:	vmovdqu (%rax,%r8,8),%ymm3
  30bea4:	vpcmpeqq %ymm0,%ymm3,%ymm4
  30bea9:	vblendvpd %ymm4,%ymm1,%ymm2,%ymm4
  30beaf:	vpcmpgtq %ymm3,%ymm0,%ymm3
  30beb4:	vpandn %ymm4,%ymm3,%ymm3
  30beb8:	vmovdqu %ymm3,(%rcx,%r8,8)
  30bebe:	add    $0x4,%r8
  30bec2:	cmp    %r8,%rdx
  30bec5:	jne    30be9e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1ade>
  30bec7:	cmp    %rdx,%rsi
  30beca:	jne    30bf1d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1b5d>
  30becc:	mov    0xa8(%rbx),%rdx
  30bed3:	cmp    %rdx,%rsi
  30bed6:	ja     30e398 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3fd8>
  30bedc:	mov    0xa0(%rbx),%r10
  30bee3:	mov    0x10(%rsp),%rax
  30bee8:	lea    -0x8(%rax),%r11
  30beec:	mov    %r11,%r12
  30beef:	shr    $0x3,%r12
  30bef3:	inc    %r12
  30bef6:	mov    $0x1,%r8b
  30bef9:	mov    %r10,%rax
  30befc:	cmp    $0x18,%r11
  30bf00:	jb     30c066 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1ca6>
  30bf06:	movabs $0x3ffffffffffffff0,%rcx
  30bf10:	cmp    $0x78,%r11
  30bf14:	jae    30bf50 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1b90>
  30bf16:	xor    %edi,%edi
  30bf18:	jmp    30c010 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1c50>
  30bf1d:	lea    -0x2dfca4(%rip),%rdi        # 2c280 <anon.2284309812649c8e966c3f1909a927a8.23.llvm.17146629557222593030+0x6a0>
  30bf24:	jmp    30bf33 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1b73>
  30bf26:	vmovsd %xmm0,(%rcx,%rdx,8)
  30bf2b:	inc    %rdx
  30bf2e:	cmp    %rdx,%rsi
  30bf31:	je     30becc <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1b0c>
  30bf33:	xor    %r8d,%r8d
  30bf36:	cmpq   $0x0,(%rax,%rdx,8)
  30bf3b:	sete   %r9b
  30bf3f:	vxorpd %xmm0,%xmm0,%xmm0
  30bf43:	js     30bf26 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1b66>
  30bf45:	mov    %r9b,%r8b
  30bf48:	vmovsd (%rdi,%r8,8),%xmm0
  30bf4e:	jmp    30bf26 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1b66>
  30bf50:	mov    %r12,%rdi
  30bf53:	and    %rcx,%rdi
  30bf56:	lea    (%r10,%rdi,8),%rax
  30bf5a:	vpbroadcastd -0x2dcfdb(%rip),%xmm0        # 2ef88 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x27b8>
  30bf63:	xor    %r8d,%r8d
  30bf66:	vpcmpeqd %ymm1,%ymm1,%ymm1
  30bf6a:	vmovdqa %xmm0,%xmm2
  30bf6e:	vmovdqa %xmm0,%xmm3
  30bf72:	vmovdqa %xmm0,%xmm4
  30bf76:	vmovdqu (%r10,%r8,8),%ymm5
  30bf7c:	vmovdqu 0x20(%r10,%r8,8),%ymm6
  30bf83:	vmovdqu 0x40(%r10,%r8,8),%ymm7
  30bf8a:	vmovdqu 0x60(%r10,%r8,8),%ymm8
  30bf91:	vpcmpgtq %ymm1,%ymm5,%ymm5
  30bf96:	vextracti128 $0x1,%ymm5,%xmm9
  30bf9c:	vpackssdw %xmm9,%xmm5,%xmm5
  30bfa1:	vpand  %xmm5,%xmm0,%xmm0
  30bfa5:	vpcmpgtq %ymm1,%ymm6,%ymm5
  30bfaa:	vextracti128 $0x1,%ymm5,%xmm6
  30bfb0:	vpackssdw %xmm6,%xmm5,%xmm5
  30bfb4:	vpand  %xmm5,%xmm2,%xmm2
  30bfb8:	vpcmpgtq %ymm1,%ymm7,%ymm5
  30bfbd:	vextracti128 $0x1,%ymm5,%xmm6
  30bfc3:	vpackssdw %xmm6,%xmm5,%xmm5
  30bfc7:	vpand  %xmm5,%xmm3,%xmm3
  30bfcb:	vpcmpgtq %ymm1,%ymm8,%ymm5
  30bfd0:	vextracti128 $0x1,%ymm5,%xmm6
  30bfd6:	vpackssdw %xmm6,%xmm5,%xmm5
  30bfda:	vpand  %xmm5,%xmm4,%xmm4
  30bfde:	add    $0x10,%r8
  30bfe2:	cmp    %r8,%rdi
  30bfe5:	jne    30bf76 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1bb6>
  30bfe7:	vpand  %xmm0,%xmm2,%xmm0
  30bfeb:	vpand  %xmm0,%xmm3,%xmm0
  30bfef:	vpand  %xmm0,%xmm4,%xmm0
  30bff3:	vpslld $0x1f,%xmm0,%xmm0
  30bff8:	vpcmpeqd %xmm1,%xmm1,%xmm1
  30bffc:	vtestps %xmm1,%xmm0
  30c001:	setb   %r8b
  30c005:	cmp    %rdi,%r12
  30c008:	je     30c082 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1cc2>
  30c00a:	test   $0xc,%r12b
  30c00e:	je     30c066 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1ca6>
  30c010:	add    $0xc,%rcx
  30c014:	and    %r12,%rcx
  30c017:	lea    (%r10,%rcx,8),%rax
  30c01b:	movzbl %r8b,%r8d
  30c01f:	vpbroadcastd -0x2dd4c0(%rip),%xmm0        # 2eb68 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x2398>
  30c028:	vpinsrd $0x0,%r8d,%xmm0,%xmm0
  30c02e:	vpcmpeqd %ymm1,%ymm1,%ymm1
  30c032:	vmovdqu (%r10,%rdi,8),%ymm2
  30c038:	vpcmpgtq %ymm1,%ymm2,%ymm2
  30c03d:	vextracti128 $0x1,%ymm2,%xmm3
  30c043:	vpackssdw %xmm3,%xmm2,%xmm2
  30c047:	vpand  %xmm2,%xmm0,%xmm0
  30c04b:	add    $0x4,%rdi
  30c04f:	cmp    %rdi,%rcx
  30c052:	jne    30c032 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1c72>
  30c054:	vptest -0x2dffad(%rip),%xmm0        # 2c0b0 <anon.2284309812649c8e966c3f1909a927a8.23.llvm.17146629557222593030+0x4d0>
  30c05d:	setb   %r8b
  30c061:	cmp    %rcx,%r12
  30c064:	je     30c082 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1cc2>
  30c066:	mov    0x10(%rsp),%rcx
  30c06b:	add    %r10,%rcx
  30c06e:	cmpq   $0x0,(%rax)
  30c072:	lea    0x8(%rax),%rax
  30c076:	setns  %dil
  30c07a:	and    %dil,%r8b
  30c07d:	cmp    %rcx,%rax
  30c080:	jne    30c06e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1cae>
  30c082:	test   %r8b,%r8b
  30c085:	je     30c130 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1d70>
  30c08b:	cmp    0x20(%rsp),%r13
  30c090:	jae    30d274 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2eb4>
  30c096:	mov    0xb8(%rbx),%rax
  30c09d:	cmp    %rax,%rsi
  30c0a0:	ja     30e408 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4048>
  30c0a6:	cmp    %rdx,%rsi
  30c0a9:	ja     30e41d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x405d>
  30c0af:	mov    0xb0(%rbx),%r8
  30c0b6:	mov    0x90(%rsp),%rdi
  30c0be:	mov    %rbp,%rdx
  30c0c1:	mov    %rsi,%rcx
  30c0c4:	mov    (%rsp),%r9
  30c0c8:	push   (%rsp)
  30c0cb:	push   %r10
  30c0cd:	vzeroupper
  30c0d0:	call   305dd0 <rustsht::legendre::scalar_ordered::kernel::apply_correction_and_clear_scale::<pulp::Scalar>>
  30c0d5:	mov    0x10(%rsp),%rsi
  30c0da:	add    $0x10,%rsp
  30c0de:	test   %rsi,%rsi
  30c0e1:	mov    0x20(%rsp),%r15
  30c0e6:	mov    0x60(%rsp),%r12
  30c0eb:	je     30d274 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2eb4>
  30c0f1:	xor    %r14d,%r14d
  30c0f4:	mov    %r14,%r9
  30c0f7:	inc    %r14
  30c0fa:	sub    $0x8,%rsp
  30c0fe:	mov    %rbx,%rdi
  30c101:	mov    0x20(%rsp),%rsi
  30c106:	mov    %r15,%rdx
  30c109:	mov    %r12,%rcx
  30c10c:	mov    %r13,%r8
  30c10f:	push   %r14
  30c111:	call   306540 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::Scalar>>
  30c116:	add    $0x10,%rsp
  30c11a:	test   %al,%al
  30c11c:	je     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30c122:	mov    (%rsp),%rsi
  30c126:	cmp    %r14,%rsi
  30c129:	jne    30c0f4 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1d34>
  30c12b:	jmp    30d274 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2eb4>
  30c130:	mov    %r14,0x30(%rsp)
  30c135:	mov    %r15,0x110(%rsp)
  30c13d:	cmp    0x20(%rsp),%r13
  30c142:	jae    30d274 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2eb4>
  30c148:	movabs $0x7ffffffffffffffe,%rax
  30c152:	movabs $0xffffffffffffff0,%r14
  30c15c:	mov    %rsi,%rcx
  30c15f:	and    %r14,%rcx
  30c162:	mov    %rcx,0x58(%rsp)
  30c167:	or     $0xc,%r14
  30c16b:	and    %rsi,%r14
  30c16e:	mov    %r12,%rcx
  30c171:	and    $0xfffffffffffffff0,%rcx
  30c175:	lea    0x0(,%rcx,8),%rdx
  30c17d:	mov    %rdx,0x170(%rsp)
  30c185:	movabs $0x3ffffffffffffff0,%rdi
  30c18f:	or     $0xc,%rdi
  30c193:	and    %r12,%rdi
  30c196:	lea    0x0(,%rdi,8),%rdx
  30c19e:	mov    %rdx,0x130(%rsp)
  30c1a6:	mov    %rsi,%r15
  30c1a9:	neg    %r15
  30c1ac:	mov    0x10(%rsp),%r8
  30c1b1:	and    $0xffffffffffffff80,%r8
  30c1b5:	inc    %rax
  30c1b8:	mov    %rax,0x50(%rsp)
  30c1bd:	vpbroadcastd -0x2dd23e(%rip),%xmm0        # 2ef88 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x27b8>
  30c1c6:	vmovdqa %xmm0,0x1b0(%rsp)
  30c1cf:	mov    %r14,0x28(%rsp)
  30c1d4:	mov    %rcx,0x150(%rsp)
  30c1dc:	mov    %rdi,0x40(%rsp)
  30c1e1:	mov    %r8,0x190(%rsp)
  30c1e9:	mov    0xb8(%rbx),%rdx
  30c1f0:	cmp    %rdx,%rsi
  30c1f3:	ja     30e175 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3db5>
  30c1f9:	mov    0xc8(%rbx),%rdx
  30c200:	cmp    %rdx,%rsi
  30c203:	ja     30e187 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3dc7>
  30c209:	mov    0xd8(%rbx),%rdx
  30c210:	cmp    %rdx,%rsi
  30c213:	ja     30e199 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3dd9>
  30c219:	mov    0xe8(%rbx),%rdx
  30c220:	cmp    %rdx,%rsi
  30c223:	ja     30e1ab <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3deb>
  30c229:	mov    0xf8(%rbx),%rdx
  30c230:	cmp    %rdx,%rsi
  30c233:	ja     30e1bd <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3dfd>
  30c239:	mov    %r12,%r14
  30c23c:	mov    %r11,%r12
  30c23f:	mov    0xb0(%rbx),%rdi
  30c246:	mov    0x110(%rsp),%rax
  30c24e:	vmovsd (%rax,%r13,8),%xmm0
  30c254:	mov    0x30(%rsp),%rax
  30c259:	vmovsd (%rax,%r13,8),%xmm1
  30c25f:	mov    %r13,%rax
  30c262:	shl    $0x4,%rax
  30c266:	mov    0x38(%rsp),%rcx
  30c26b:	vmovsd (%rcx,%rax,1),%xmm2
  30c270:	vmovq  0x8(%rcx,%rax,1),%xmm3
  30c276:	mov    0x8(%rsp),%rcx
  30c27b:	vmovsd (%rcx,%rax,1),%xmm4
  30c280:	vmovsd 0x8(%rcx,%rax,1),%xmm5
  30c286:	mov    0x48(%rsp),%rdx
  30c28b:	mov    %rsi,%rcx
  30c28e:	mov    0x90(%rsp),%r8
  30c296:	mov    (%rsp),%r9
  30c29a:	push   (%rsp)
  30c29d:	push   0xf0(%rbx)
  30c2a3:	push   0x10(%rsp)
  30c2a7:	push   0xe0(%rbx)
  30c2ad:	push   0x20(%rsp)
  30c2b1:	push   0xd0(%rbx)
  30c2b7:	push   0x30(%rsp)
  30c2bb:	push   0xc0(%rbx)
  30c2c1:	push   0x40(%rsp)
  30c2c5:	push   %rbp
  30c2c6:	vzeroupper
  30c2c9:	call   2fe650 <rustsht::legendre::scalar_ordered::kernel::scaled_pair_step::<pulp::Scalar>>
  30c2ce:	mov    0x50(%rsp),%rsi
  30c2d3:	add    $0x50,%rsp
  30c2d7:	mov    0xa8(%rbx),%rdx
  30c2de:	cmp    %rdx,%rsi
  30c2e1:	ja     30e1cf <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e0f>
  30c2e7:	addq   $0x2,0x60(%rsp)
  30c2ed:	inc    %r13
  30c2f0:	mov    0xa0(%rbx),%rcx
  30c2f7:	xor    %edi,%edi
  30c2f9:	xor    %edx,%edx
  30c2fb:	mov    0x18(%rsp),%rax
  30c300:	mov    %r12,%r11
  30c303:	mov    %r14,%r12
  30c306:	mov    0x28(%rsp),%r14
  30c30b:	mov    $0x3f,%r9b
  30c30e:	vmovsd -0x2df08e(%rip),%xmm1        # 2d288 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0xab8>
  30c316:	lea    -0x2e009d(%rip),%r10        # 2c280 <anon.2284309812649c8e966c3f1909a927a8.23.llvm.17146629557222593030+0x6a0>
  30c31d:	vpxor  %xmm8,%xmm8,%xmm8
  30c322:	vbroadcastsd -0x2df613(%rip),%ymm9        # 2cd18 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x548>
  30c32b:	vbroadcastsd -0x2df05c(%rip),%ymm10        # 2d2d8 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0xb08>
  30c334:	inc    %rdx
  30c337:	bzhi   %r9,-0x8(%rbp,%rdx,8),%r8
  30c33e:	vmovq  %r8,%xmm0
  30c343:	vucomisd %xmm1,%xmm0
  30c347:	ja     30c35b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1f9b>
  30c349:	lea    (%r15,%rdx,1),%r8
  30c34d:	inc    %r8
  30c350:	inc    %rdx
  30c353:	cmp    $0x1,%r8
  30c357:	jne    30c337 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1f77>
  30c359:	jmp    30c3a9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1fe9>
  30c35b:	mov    0x50(%rsp),%rdi
  30c360:	cmp    %rdi,-0x8(%rcx,%rdx,8)
  30c365:	je     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30c36b:	mov    0x90(%rsp),%rdi
  30c373:	vmovsd -0x2df22b(%rip),%xmm2        # 2d150 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x980>
  30c37b:	vmulsd -0x8(%rdi,%rdx,8),%xmm2,%xmm0
  30c381:	vmovsd %xmm0,-0x8(%rdi,%rdx,8)
  30c387:	vmulsd -0x8(%rbp,%rdx,8),%xmm2,%xmm0
  30c38d:	vmovsd %xmm0,-0x8(%rbp,%rdx,8)
  30c393:	incq   -0x8(%rcx,%rdx,8)
  30c398:	mov    $0x1,%dil
  30c39b:	cmp    %rdx,%rsi
  30c39e:	jne    30c334 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1f74>
  30c3a0:	mov    0xa8(%rbx),%rdx
  30c3a7:	jmp    30c3ba <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1ffa>
  30c3a9:	mov    0xa8(%rbx),%rdx
  30c3b0:	test   $0x1,%dil
  30c3b4:	je     30c4de <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x211e>
  30c3ba:	cmp    %rdx,%rsi
  30c3bd:	ja     30e371 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3fb1>
  30c3c3:	mov    0xb8(%rbx),%rdx
  30c3ca:	cmp    %rdx,%rsi
  30c3cd:	ja     30e22a <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e6a>
  30c3d3:	mov    0xa0(%rbx),%rcx
  30c3da:	mov    0xb0(%rbx),%rdx
  30c3e1:	cmp    $0x4,%rsi
  30c3e5:	jae    30c3ee <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x202e>
  30c3e7:	xor    %edi,%edi
  30c3e9:	jmp    30c51e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x215e>
  30c3ee:	cmp    $0x10,%rsi
  30c3f2:	jae    30c3fc <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x203c>
  30c3f4:	xor    %r8d,%r8d
  30c3f7:	jmp    30c4a6 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x20e6>
  30c3fc:	xor    %edi,%edi
  30c3fe:	mov    0x190(%rsp),%r8
  30c406:	vmovdqu (%rcx,%rdi,1),%ymm0
  30c40b:	vmovdqu 0x20(%rcx,%rdi,1),%ymm1
  30c411:	vmovdqu 0x40(%rcx,%rdi,1),%ymm2
  30c417:	vmovdqu 0x60(%rcx,%rdi,1),%ymm3
  30c41d:	vpcmpeqq %ymm8,%ymm0,%ymm4
  30c422:	vpcmpeqq %ymm8,%ymm1,%ymm5
  30c427:	vpcmpeqq %ymm8,%ymm2,%ymm6
  30c42c:	vpcmpeqq %ymm8,%ymm3,%ymm7
  30c431:	vblendvpd %ymm4,%ymm9,%ymm10,%ymm4
  30c437:	vblendvpd %ymm5,%ymm9,%ymm10,%ymm5
  30c43d:	vblendvpd %ymm6,%ymm9,%ymm10,%ymm6
  30c443:	vblendvpd %ymm7,%ymm9,%ymm10,%ymm7
  30c449:	vpcmpgtq %ymm0,%ymm8,%ymm0
  30c44e:	vpandn %ymm4,%ymm0,%ymm0
  30c452:	vpcmpgtq %ymm1,%ymm8,%ymm1
  30c457:	vpandn %ymm5,%ymm1,%ymm1
  30c45b:	vpcmpgtq %ymm2,%ymm8,%ymm2
  30c460:	vpandn %ymm6,%ymm2,%ymm2
  30c464:	vpcmpgtq %ymm3,%ymm8,%ymm3
  30c469:	vpandn %ymm7,%ymm3,%ymm3
  30c46d:	vmovdqu %ymm0,(%rdx,%rdi,1)
  30c472:	vmovdqu %ymm1,0x20(%rdx,%rdi,1)
  30c478:	vmovdqu %ymm2,0x40(%rdx,%rdi,1)
  30c47e:	vmovdqu %ymm3,0x60(%rdx,%rdi,1)
  30c484:	sub    $0xffffffffffffff80,%rdi
  30c488:	cmp    %rdi,%r8
  30c48b:	jne    30c406 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2046>
  30c491:	cmp    0x58(%rsp),%rsi
  30c496:	je     30c4d7 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2117>
  30c498:	mov    0x58(%rsp),%rdi
  30c49d:	mov    %rdi,%r8
  30c4a0:	test   $0xc,%sil
  30c4a4:	je     30c51e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x215e>
  30c4a6:	vmovdqu (%rcx,%r8,8),%ymm0
  30c4ac:	vpcmpeqq %ymm8,%ymm0,%ymm1
  30c4b1:	vblendvpd %ymm1,%ymm9,%ymm10,%ymm1
  30c4b7:	vpcmpgtq %ymm0,%ymm8,%ymm0
  30c4bc:	vpandn %ymm1,%ymm0,%ymm0
  30c4c0:	vmovdqu %ymm0,(%rdx,%r8,8)
  30c4c6:	add    $0x4,%r8
  30c4ca:	cmp    %r8,%r14
  30c4cd:	jne    30c4a6 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x20e6>
  30c4cf:	mov    %r14,%rdi
  30c4d2:	cmp    %r14,%rsi
  30c4d5:	jne    30c51e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x215e>
  30c4d7:	mov    0xa8(%rbx),%rdx
  30c4de:	cmp    %rdx,%rsi
  30c4e1:	ja     30e23c <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e7c>
  30c4e7:	mov    0xa0(%rbx),%r10
  30c4ee:	mov    $0x1,%dil
  30c4f1:	mov    %r10,%rcx
  30c4f4:	cmp    $0x18,%r11
  30c4f8:	vpcmpeqd %ymm9,%ymm9,%ymm9
  30c4fd:	jb     30c656 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2296>
  30c503:	cmp    $0x78,%r11
  30c507:	jae    30c53b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x217b>
  30c509:	xor    %r8d,%r8d
  30c50c:	jmp    30c5ff <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x223f>
  30c511:	vmovq  %xmm0,(%rdx,%rdi,8)
  30c516:	inc    %rdi
  30c519:	cmp    %rdi,%rsi
  30c51c:	je     30c4d7 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2117>
  30c51e:	xor    %r8d,%r8d
  30c521:	cmpq   $0x0,(%rcx,%rdi,8)
  30c526:	sete   %r9b
  30c52a:	vpxor  %xmm0,%xmm0,%xmm0
  30c52e:	js     30c511 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2151>
  30c530:	mov    %r9b,%r8b
  30c533:	vmovq  (%r10,%r8,8),%xmm0
  30c539:	jmp    30c511 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2151>
  30c53b:	mov    0x170(%rsp),%rcx
  30c543:	add    %r10,%rcx
  30c546:	xor    %edi,%edi
  30c548:	vmovdqa 0x1b0(%rsp),%xmm3
  30c551:	vmovdqa %xmm3,%xmm0
  30c555:	vmovdqa %xmm3,%xmm1
  30c559:	vmovdqa %xmm3,%xmm2
  30c55d:	mov    0x150(%rsp),%r8
  30c565:	vmovdqu (%r10,%rdi,8),%ymm4
  30c56b:	vmovdqu 0x20(%r10,%rdi,8),%ymm5
  30c572:	vmovdqu 0x40(%r10,%rdi,8),%ymm6
  30c579:	vmovdqu 0x60(%r10,%rdi,8),%ymm7
  30c580:	vpcmpgtq %ymm9,%ymm4,%ymm4
  30c585:	vextracti128 $0x1,%ymm4,%xmm8
  30c58b:	vpackssdw %xmm8,%xmm4,%xmm4
  30c590:	vpand  %xmm4,%xmm0,%xmm0
  30c594:	vpcmpgtq %ymm9,%ymm5,%ymm4
  30c599:	vextracti128 $0x1,%ymm4,%xmm5
  30c59f:	vpackssdw %xmm5,%xmm4,%xmm4
  30c5a3:	vpand  %xmm4,%xmm1,%xmm1
  30c5a7:	vpcmpgtq %ymm9,%ymm6,%ymm4
  30c5ac:	vextracti128 $0x1,%ymm4,%xmm5
  30c5b2:	vpackssdw %xmm5,%xmm4,%xmm4
  30c5b6:	vpand  %xmm4,%xmm2,%xmm2
  30c5ba:	vpcmpgtq %ymm9,%ymm7,%ymm4
  30c5bf:	vextracti128 $0x1,%ymm4,%xmm5
  30c5c5:	vpackssdw %xmm5,%xmm4,%xmm4
  30c5c9:	vpand  %xmm4,%xmm3,%xmm3
  30c5cd:	add    $0x10,%rdi
  30c5d1:	cmp    %rdi,%r8
  30c5d4:	jne    30c565 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x21a5>
  30c5d6:	vpand  %xmm0,%xmm1,%xmm0
  30c5da:	vpand  %xmm0,%xmm2,%xmm0
  30c5de:	vpand  %xmm0,%xmm3,%xmm0
  30c5e2:	vpslld $0x1f,%xmm0,%xmm0
  30c5e7:	vpcmpeqd %xmm1,%xmm1,%xmm1
  30c5eb:	vtestps %xmm1,%xmm0
  30c5f0:	setb   %dil
  30c5f4:	cmp    %r8,%r12
  30c5f7:	je     30c672 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x22b2>
  30c5f9:	test   $0xc,%r12b
  30c5fd:	je     30c656 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2296>
  30c5ff:	mov    0x130(%rsp),%rcx
  30c607:	add    %r10,%rcx
  30c60a:	movzbl %dil,%edi
  30c60e:	vpbroadcastd -0x2ddaaf(%rip),%xmm0        # 2eb68 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x2398>
  30c617:	vpinsrd $0x0,%edi,%xmm0,%xmm0
  30c61d:	mov    0x40(%rsp),%r9
  30c622:	vmovdqu (%r10,%r8,8),%ymm1
  30c628:	vpcmpgtq %ymm9,%ymm1,%ymm1
  30c62d:	vextracti128 $0x1,%ymm1,%xmm2
  30c633:	vpackssdw %xmm2,%xmm1,%xmm1
  30c637:	vpand  %xmm1,%xmm0,%xmm0
  30c63b:	add    $0x4,%r8
  30c63f:	cmp    %r8,%r9
  30c642:	jne    30c622 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2262>
  30c644:	vptest -0x2e059d(%rip),%xmm0        # 2c0b0 <anon.2284309812649c8e966c3f1909a927a8.23.llvm.17146629557222593030+0x4d0>
  30c64d:	setb   %dil
  30c651:	cmp    %r9,%r12
  30c654:	je     30c672 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x22b2>
  30c656:	mov    0x10(%rsp),%r8
  30c65b:	add    %r10,%r8
  30c65e:	cmpq   $0x0,(%rcx)
  30c662:	lea    0x8(%rcx),%rcx
  30c666:	setns  %r9b
  30c66a:	and    %r9b,%dil
  30c66d:	cmp    %r8,%rcx
  30c670:	jne    30c65e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x229e>
  30c672:	test   %dil,%dil
  30c675:	jne    30d269 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2ea9>
  30c67b:	cmp    %rax,0x60(%rsp)
  30c680:	ja     30d274 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2eb4>
  30c686:	cmp    0x20(%rsp),%r13
  30c68b:	jb     30c1e9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1e29>
  30c691:	jmp    30d274 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2eb4>
  30c696:	mov    0x18(%rsp),%r11
  30c69b:	mov    0x8(%rsp),%rsi
  30c6a0:	mov    0x80(%rsp),%rbp
  30c6a8:	test   %al,%dl
  30c6aa:	je     30c70d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x234d>
  30c6ac:	mov    0xb8(%rbx),%rdx
  30c6b3:	cmp    %rdx,%rsi
  30c6b6:	ja     30e453 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4093>
  30c6bc:	cmp    %r15,%rsi
  30c6bf:	ja     30e4a3 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x40e3>
  30c6c5:	mov    %eax,%r13d
  30c6c8:	mov    %r10,%rbp
  30c6cb:	mov    0xb0(%rbx),%r8
  30c6d2:	mov    (%rsp),%rdi
  30c6d6:	mov    %r14,%rdx
  30c6d9:	mov    %rsi,%rcx
  30c6dc:	mov    0x8(%rsp),%r9
  30c6e1:	push   0x8(%rsp)
  30c6e5:	push   %r12
  30c6e7:	vzeroupper
  30c6ea:	call   305f10 <rustsht::legendre::scalar_ordered::kernel::apply_correction_and_clear_scale::<pulp::x86::v3::V3>>
  30c6ef:	mov    0x18(%rsp),%rsi
  30c6f4:	add    $0x10,%rsp
  30c6f8:	mov    $0x1,%dl
  30c6fa:	mov    0x18(%rsp),%r11
  30c6ff:	mov    %rbp,%r10
  30c702:	mov    0x80(%rsp),%rbp
  30c70a:	mov    %r13d,%eax
  30c70d:	and    %dl,%al
  30c70f:	cmp    $0x1,%al
  30c711:	jne    30dc38 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3878>
  30c717:	cmp    $0x8,%rsi
  30c71b:	mov    %r10,0x30(%rsp)
  30c720:	jae    30d788 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x33c8>
  30c726:	xor    %r9d,%r9d
  30c729:	jmp    30dbf7 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3837>
  30c72e:	mov    %rsi,%rdx
  30c731:	and    %rdi,%rdx
  30c734:	mov    %r13,%r8
  30c737:	and    $0xffffffffffffff80,%r8
  30c73b:	xor    %r9d,%r9d
  30c73e:	vxorps %xmm0,%xmm0,%xmm0
  30c742:	vbroadcastsd -0x2dfa33(%rip),%ymm1        # 2cd18 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x548>
  30c74b:	vbroadcastsd -0x2df47c(%rip),%ymm2        # 2d2d8 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0xb08>
  30c754:	vmovdqu (%rax,%r9,1),%ymm3
  30c75a:	vmovdqu 0x20(%rax,%r9,1),%ymm4
  30c761:	vmovdqu 0x40(%rax,%r9,1),%ymm5
  30c768:	vmovdqu 0x60(%rax,%r9,1),%ymm6
  30c76f:	vpcmpeqq %ymm0,%ymm3,%ymm7
  30c774:	vpcmpeqq %ymm0,%ymm4,%ymm8
  30c779:	vpcmpeqq %ymm0,%ymm5,%ymm9
  30c77e:	vpcmpeqq %ymm0,%ymm6,%ymm10
  30c783:	vblendvpd %ymm7,%ymm1,%ymm2,%ymm7
  30c789:	vblendvpd %ymm8,%ymm1,%ymm2,%ymm8
  30c78f:	vblendvpd %ymm9,%ymm1,%ymm2,%ymm9
  30c795:	vblendvpd %ymm10,%ymm1,%ymm2,%ymm10
  30c79b:	vpcmpgtq %ymm3,%ymm0,%ymm3
  30c7a0:	vpandn %ymm7,%ymm3,%ymm3
  30c7a4:	vpcmpgtq %ymm4,%ymm0,%ymm4
  30c7a9:	vpandn %ymm8,%ymm4,%ymm4
  30c7ae:	vpcmpgtq %ymm5,%ymm0,%ymm5
  30c7b3:	vpandn %ymm9,%ymm5,%ymm5
  30c7b8:	vpcmpgtq %ymm6,%ymm0,%ymm6
  30c7bd:	vpandn %ymm10,%ymm6,%ymm6
  30c7c2:	vmovdqu %ymm3,(%rcx,%r9,1)
  30c7c8:	vmovdqu %ymm4,0x20(%rcx,%r9,1)
  30c7cf:	vmovdqu %ymm5,0x40(%rcx,%r9,1)
  30c7d6:	vmovdqu %ymm6,0x60(%rcx,%r9,1)
  30c7dd:	sub    $0xffffffffffffff80,%r9
  30c7e1:	cmp    %r9,%r8
  30c7e4:	jne    30c754 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2394>
  30c7ea:	cmp    %rdx,%rsi
  30c7ed:	je     30c84a <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x248a>
  30c7ef:	test   $0xc,%sil
  30c7f3:	je     30c89f <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x24df>
  30c7f9:	mov    %rdx,%r8
  30c7fc:	add    $0xc,%rdi
  30c800:	mov    %rdi,%rdx
  30c803:	and    %rsi,%rdx
  30c806:	vpxor  %xmm0,%xmm0,%xmm0
  30c80a:	vbroadcastsd -0x2dfafb(%rip),%ymm1        # 2cd18 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x548>
  30c813:	vbroadcastsd -0x2df544(%rip),%ymm2        # 2d2d8 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0xb08>
  30c81c:	vmovdqu (%rax,%r8,8),%ymm3
  30c822:	vpcmpeqq %ymm0,%ymm3,%ymm4
  30c827:	vblendvpd %ymm4,%ymm1,%ymm2,%ymm4
  30c82d:	vpcmpgtq %ymm3,%ymm0,%ymm3
  30c832:	vpandn %ymm4,%ymm3,%ymm3
  30c836:	vmovdqu %ymm3,(%rcx,%r8,8)
  30c83c:	add    $0x4,%r8
  30c840:	cmp    %r8,%rdx
  30c843:	jne    30c81c <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x245c>
  30c845:	cmp    %rdx,%rsi
  30c848:	jne    30c89f <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x24df>
  30c84a:	mov    0xa8(%rbx),%rdx
  30c851:	cmp    %rdx,%rsi
  30c854:	ja     30e398 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3fd8>
  30c85a:	mov    0xa0(%rbx),%r10
  30c861:	lea    -0x8(%r13),%rcx
  30c865:	mov    %rcx,%r9
  30c868:	shr    $0x3,%r9
  30c86c:	inc    %r9
  30c86f:	mov    $0x1,%r8b
  30c872:	mov    %r10,%rax
  30c875:	mov    %rcx,0x50(%rsp)
  30c87a:	cmp    $0x18,%rcx
  30c87e:	jb     30c9e8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2628>
  30c884:	movabs $0x3ffffffffffffff0,%rcx
  30c88e:	lea    -0x8(%r13),%rax
  30c892:	cmp    $0x78,%rax
  30c896:	jae    30c8d2 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2512>
  30c898:	xor    %edi,%edi
  30c89a:	jmp    30c992 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x25d2>
  30c89f:	lea    -0x2e0626(%rip),%rdi        # 2c280 <anon.2284309812649c8e966c3f1909a927a8.23.llvm.17146629557222593030+0x6a0>
  30c8a6:	jmp    30c8b5 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x24f5>
  30c8a8:	vmovsd %xmm0,(%rcx,%rdx,8)
  30c8ad:	inc    %rdx
  30c8b0:	cmp    %rdx,%rsi
  30c8b3:	je     30c84a <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x248a>
  30c8b5:	xor    %r8d,%r8d
  30c8b8:	cmpq   $0x0,(%rax,%rdx,8)
  30c8bd:	sete   %r9b
  30c8c1:	vxorps %xmm0,%xmm0,%xmm0
  30c8c5:	js     30c8a8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x24e8>
  30c8c7:	mov    %r9b,%r8b
  30c8ca:	vmovsd (%rdi,%r8,8),%xmm0
  30c8d0:	jmp    30c8a8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x24e8>
  30c8d2:	mov    %r9,%rdi
  30c8d5:	and    %rcx,%rdi
  30c8d8:	lea    (%r10,%rdi,8),%rax
  30c8dc:	vpbroadcastd -0x2dd95d(%rip),%xmm0        # 2ef88 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x27b8>
  30c8e5:	xor    %r8d,%r8d
  30c8e8:	vpcmpeqd %ymm1,%ymm1,%ymm1
  30c8ec:	vmovdqa %xmm0,%xmm2
  30c8f0:	vmovdqa %xmm0,%xmm3
  30c8f4:	vmovdqa %xmm0,%xmm4
  30c8f8:	vmovdqu (%r10,%r8,8),%ymm5
  30c8fe:	vmovdqu 0x20(%r10,%r8,8),%ymm6
  30c905:	vmovdqu 0x40(%r10,%r8,8),%ymm7
  30c90c:	vmovdqu 0x60(%r10,%r8,8),%ymm8
  30c913:	vpcmpgtq %ymm1,%ymm5,%ymm5
  30c918:	vextracti128 $0x1,%ymm5,%xmm9
  30c91e:	vpackssdw %xmm9,%xmm5,%xmm5
  30c923:	vpand  %xmm5,%xmm0,%xmm0
  30c927:	vpcmpgtq %ymm1,%ymm6,%ymm5
  30c92c:	vextracti128 $0x1,%ymm5,%xmm6
  30c932:	vpackssdw %xmm6,%xmm5,%xmm5
  30c936:	vpand  %xmm5,%xmm2,%xmm2
  30c93a:	vpcmpgtq %ymm1,%ymm7,%ymm5
  30c93f:	vextracti128 $0x1,%ymm5,%xmm6
  30c945:	vpackssdw %xmm6,%xmm5,%xmm5
  30c949:	vpand  %xmm5,%xmm3,%xmm3
  30c94d:	vpcmpgtq %ymm1,%ymm8,%ymm5
  30c952:	vextracti128 $0x1,%ymm5,%xmm6
  30c958:	vpackssdw %xmm6,%xmm5,%xmm5
  30c95c:	vpand  %xmm5,%xmm4,%xmm4
  30c960:	add    $0x10,%r8
  30c964:	cmp    %r8,%rdi
  30c967:	jne    30c8f8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2538>
  30c969:	vpand  %xmm0,%xmm2,%xmm0
  30c96d:	vpand  %xmm0,%xmm3,%xmm0
  30c971:	vpand  %xmm0,%xmm4,%xmm0
  30c975:	vpslld $0x1f,%xmm0,%xmm0
  30c97a:	vpcmpeqd %xmm1,%xmm1,%xmm1
  30c97e:	vtestps %xmm1,%xmm0
  30c983:	setb   %r8b
  30c987:	cmp    %rdi,%r9
  30c98a:	je     30ca00 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2640>
  30c98c:	test   $0xc,%r9b
  30c990:	je     30c9e8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2628>
  30c992:	add    $0xc,%rcx
  30c996:	and    %r9,%rcx
  30c999:	lea    (%r10,%rcx,8),%rax
  30c99d:	movzbl %r8b,%r8d
  30c9a1:	vpbroadcastd -0x2dde42(%rip),%xmm0        # 2eb68 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x2398>
  30c9aa:	vpinsrd $0x0,%r8d,%xmm0,%xmm0
  30c9b0:	vpcmpeqd %ymm1,%ymm1,%ymm1
  30c9b4:	vmovdqu (%r10,%rdi,8),%ymm2
  30c9ba:	vpcmpgtq %ymm1,%ymm2,%ymm2
  30c9bf:	vextracti128 $0x1,%ymm2,%xmm3
  30c9c5:	vpackssdw %xmm3,%xmm2,%xmm2
  30c9c9:	vpand  %xmm2,%xmm0,%xmm0
  30c9cd:	add    $0x4,%rdi
  30c9d1:	cmp    %rdi,%rcx
  30c9d4:	jne    30c9b4 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x25f4>
  30c9d6:	vptest -0x2e092f(%rip),%xmm0        # 2c0b0 <anon.2284309812649c8e966c3f1909a927a8.23.llvm.17146629557222593030+0x4d0>
  30c9df:	setb   %r8b
  30c9e3:	cmp    %rcx,%r9
  30c9e6:	je     30ca00 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2640>
  30c9e8:	lea    (%r10,%r13,1),%rcx
  30c9ec:	cmpq   $0x0,(%rax)
  30c9f0:	lea    0x8(%rax),%rax
  30c9f4:	setns  %dil
  30c9f8:	and    %dil,%r8b
  30c9fb:	cmp    %rcx,%rax
  30c9fe:	jne    30c9ec <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x262c>
  30ca00:	test   %r8b,%r8b
  30ca03:	je     30cab1 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x26f1>
  30ca09:	mov    %r15,%r11
  30ca0c:	cmp    0x28(%rsp),%r11
  30ca11:	jae    30d8e9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3529>
  30ca17:	mov    0xb8(%rbx),%rax
  30ca1e:	cmp    %rax,%rsi
  30ca21:	ja     30e408 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4048>
  30ca27:	cmp    %rdx,%rsi
  30ca2a:	mov    0x10(%rsp),%r15
  30ca2f:	ja     30e41d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x405d>
  30ca35:	mov    %r11,%r13
  30ca38:	mov    0xb0(%rbx),%r8
  30ca3f:	mov    0x8(%rsp),%rdi
  30ca44:	mov    %r12,%rdx
  30ca47:	mov    %rsi,%rcx
  30ca4a:	mov    (%rsp),%r9
  30ca4e:	push   (%rsp)
  30ca51:	push   %r10
  30ca53:	vzeroupper
  30ca56:	call   305dd0 <rustsht::legendre::scalar_ordered::kernel::apply_correction_and_clear_scale::<pulp::Scalar>>
  30ca5b:	mov    0x10(%rsp),%rsi
  30ca60:	add    $0x10,%rsp
  30ca64:	test   %rsi,%rsi
  30ca67:	mov    0x28(%rsp),%r12
  30ca6c:	je     30d8e9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3529>
  30ca72:	xor    %r14d,%r14d
  30ca75:	mov    %r14,%r9
  30ca78:	inc    %r14
  30ca7b:	sub    $0x8,%rsp
  30ca7f:	mov    %rbx,%rdi
  30ca82:	mov    0x20(%rsp),%rsi
  30ca87:	mov    %r12,%rdx
  30ca8a:	mov    %r15,%rcx
  30ca8d:	mov    %r13,%r8
  30ca90:	push   %r14
  30ca92:	call   306540 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::Scalar>>
  30ca97:	add    $0x10,%rsp
  30ca9b:	test   %al,%al
  30ca9d:	je     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30caa3:	mov    (%rsp),%rsi
  30caa7:	cmp    %r14,%rsi
  30caaa:	jne    30ca75 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x26b5>
  30caac:	jmp    30d8e9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3529>
  30cab1:	mov    %r13,0x190(%rsp)
  30cab9:	mov    %r14,0x40(%rsp)
  30cabe:	cmp    0x28(%rsp),%r15
  30cac3:	jae    30d8e9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3529>
  30cac9:	mov    %r15,%r11
  30cacc:	movabs $0x7ffffffffffffffe,%rcx
  30cad6:	mov    0x110(%rsp),%rax
  30cade:	cmp    %rax,%r15
  30cae1:	cmova  %r15,%rax
  30cae5:	mov    %rax,0x130(%rsp)
  30caed:	mov    0x30(%rsp),%rax
  30caf2:	cmp    %rax,%r15
  30caf5:	cmova  %r15,%rax
  30caf9:	mov    %rax,0x150(%rsp)
  30cb01:	mov    0x48(%rsp),%rax
  30cb06:	cmp    %rax,%r15
  30cb09:	cmova  %r15,%rax
  30cb0d:	mov    %rax,0x170(%rsp)
  30cb15:	mov    0x38(%rsp),%rax
  30cb1a:	cmp    %rax,%r15
  30cb1d:	cmova  %r15,%rax
  30cb21:	mov    %rax,0x1b0(%rsp)
  30cb29:	movabs $0xffffffffffffff0,%rax
  30cb33:	mov    %rsi,%rdx
  30cb36:	and    %rax,%rdx
  30cb39:	mov    %rdx,0x108(%rsp)
  30cb41:	or     $0xc,%rax
  30cb45:	and    %rsi,%rax
  30cb48:	mov    %rax,0x1f0(%rsp)
  30cb50:	mov    %r9,%rax
  30cb53:	and    $0xfffffffffffffff0,%rax
  30cb57:	mov    %rax,0xc0(%rsp)
  30cb5f:	lea    0x0(,%rax,8),%rax
  30cb67:	mov    %rax,0xb8(%rsp)
  30cb6f:	movabs $0x3ffffffffffffff0,%rax
  30cb79:	or     $0xc,%rax
  30cb7d:	and    %r9,%rax
  30cb80:	mov    %rax,0x80(%rsp)
  30cb88:	lea    0x0(,%rax,8),%rax
  30cb90:	mov    %rax,0xc8(%rsp)
  30cb98:	mov    %rsi,%r13
  30cb9b:	neg    %r13
  30cb9e:	mov    0x190(%rsp),%rax
  30cba6:	and    $0xffffffffffffff80,%rax
  30cbaa:	mov    %rax,0x1e8(%rsp)
  30cbb2:	inc    %rcx
  30cbb5:	mov    %rcx,0x58(%rsp)
  30cbba:	lea    -0x2e0941(%rip),%r14        # 2c280 <anon.2284309812649c8e966c3f1909a927a8.23.llvm.17146629557222593030+0x6a0>
  30cbc1:	vpbroadcastd -0x2ddc42(%rip),%xmm0        # 2ef88 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x27b8>
  30cbca:	vmovdqa %xmm0,0x1d0(%rsp)
  30cbd3:	mov    %r9,0x88(%rsp)
  30cbdb:	mov    0xb8(%rbx),%rdx
  30cbe2:	cmp    %rdx,%rsi
  30cbe5:	ja     30e175 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3db5>
  30cbeb:	cmp    0x130(%rsp),%r11
  30cbf3:	je     30e8a5 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x44e5>
  30cbf9:	cmp    0x150(%rsp),%r11
  30cc01:	je     30e8e2 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4522>
  30cc07:	cmp    0x170(%rsp),%r11
  30cc0f:	je     30e888 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x44c8>
  30cc15:	cmp    0x1b0(%rsp),%r11
  30cc1d:	je     30e8c5 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4505>
  30cc23:	mov    0xc8(%rbx),%rdx
  30cc2a:	cmp    %rdx,%rsi
  30cc2d:	ja     30e187 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3dc7>
  30cc33:	mov    0xd8(%rbx),%rdx
  30cc3a:	cmp    %rdx,%rsi
  30cc3d:	ja     30e199 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3dd9>
  30cc43:	mov    0xe8(%rbx),%rdx
  30cc4a:	cmp    %rdx,%rsi
  30cc4d:	ja     30e1ab <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3deb>
  30cc53:	mov    0xf8(%rbx),%rdx
  30cc5a:	cmp    %rdx,%rsi
  30cc5d:	ja     30e1bd <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3dfd>
  30cc63:	mov    0xb0(%rbx),%rdi
  30cc6a:	mov    0x20(%rsp),%rax
  30cc6f:	vmovsd (%rax,%r11,8),%xmm0
  30cc75:	mov    0x60(%rsp),%rax
  30cc7a:	vmovsd (%rax,%r11,8),%xmm1
  30cc80:	mov    %r11,%rax
  30cc83:	shl    $0x4,%rax
  30cc87:	mov    0x90(%rsp),%rcx
  30cc8f:	vmovsd (%rcx,%rax,1),%xmm2
  30cc94:	vmovq  0x8(%rcx,%rax,1),%xmm3
  30cc9a:	mov    0x40(%rsp),%rcx
  30cc9f:	vmovsd (%rcx,%rax,1),%xmm4
  30cca4:	vmovsd 0x8(%rcx,%rax,1),%xmm5
  30ccaa:	mov    %rbp,%r15
  30ccad:	mov    %rbp,%rdx
  30ccb0:	mov    %rsi,%rcx
  30ccb3:	mov    0x8(%rsp),%r8
  30ccb8:	mov    (%rsp),%r9
  30ccbc:	push   (%rsp)
  30ccbf:	push   0xf0(%rbx)
  30ccc5:	push   0x10(%rsp)
  30ccc9:	push   0xe0(%rbx)
  30cccf:	push   0x20(%rsp)
  30ccd3:	push   0xd0(%rbx)
  30ccd9:	push   0x30(%rsp)
  30ccdd:	push   0xc0(%rbx)
  30cce3:	push   0x40(%rsp)
  30cce7:	push   %r12
  30cce9:	mov    %r11,%rbp
  30ccec:	vzeroupper
  30ccef:	call   2fe650 <rustsht::legendre::scalar_ordered::kernel::scaled_pair_step::<pulp::Scalar>>
  30ccf4:	mov    0x50(%rsp),%rsi
  30ccf9:	add    $0x50,%rsp
  30ccfd:	mov    0xa8(%rbx),%rdx
  30cd04:	cmp    %rdx,%rsi
  30cd07:	ja     30e1cf <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e0f>
  30cd0d:	addq   $0x2,0x10(%rsp)
  30cd13:	inc    %rbp
  30cd16:	mov    0xa0(%rbx),%rcx
  30cd1d:	xor    %edi,%edi
  30cd1f:	xor    %edx,%edx
  30cd21:	mov    0x18(%rsp),%rax
  30cd26:	mov    %rbp,%r11
  30cd29:	mov    %r15,%rbp
  30cd2c:	vmovsd -0x2dfaac(%rip),%xmm1        # 2d288 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0xab8>
  30cd34:	mov    $0x3f,%r9b
  30cd37:	vpxor  %xmm8,%xmm8,%xmm8
  30cd3c:	vbroadcastsd -0x2e002d(%rip),%ymm9        # 2cd18 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x548>
  30cd45:	vbroadcastsd -0x2dfa76(%rip),%ymm10        # 2d2d8 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0xb08>
  30cd4e:	inc    %rdx
  30cd51:	bzhi   %r9,-0x8(%r12,%rdx,8),%r8
  30cd58:	vmovq  %r8,%xmm0
  30cd5d:	vucomisd %xmm1,%xmm0
  30cd61:	ja     30cd75 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x29b5>
  30cd63:	lea    (%rdx,%r13,1),%r8
  30cd67:	inc    %r8
  30cd6a:	inc    %rdx
  30cd6d:	cmp    $0x1,%r8
  30cd71:	jne    30cd51 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2991>
  30cd73:	jmp    30cdc2 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2a02>
  30cd75:	mov    0x58(%rsp),%rdi
  30cd7a:	cmp    %rdi,-0x8(%rcx,%rdx,8)
  30cd7f:	je     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30cd85:	mov    0x8(%rsp),%rdi
  30cd8a:	vmovsd -0x2dfc42(%rip),%xmm2        # 2d150 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x980>
  30cd92:	vmulsd -0x8(%rdi,%rdx,8),%xmm2,%xmm0
  30cd98:	vmovsd %xmm0,-0x8(%rdi,%rdx,8)
  30cd9e:	vmulsd -0x8(%r12,%rdx,8),%xmm2,%xmm0
  30cda5:	vmovsd %xmm0,-0x8(%r12,%rdx,8)
  30cdac:	incq   -0x8(%rcx,%rdx,8)
  30cdb1:	mov    $0x1,%dil
  30cdb4:	cmp    %rdx,%rsi
  30cdb7:	jne    30cd4e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x298e>
  30cdb9:	mov    0xa8(%rbx),%rdx
  30cdc0:	jmp    30cdd3 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2a13>
  30cdc2:	mov    0xa8(%rbx),%rdx
  30cdc9:	test   $0x1,%dil
  30cdcd:	je     30cf09 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2b49>
  30cdd3:	cmp    %rdx,%rsi
  30cdd6:	ja     30e371 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3fb1>
  30cddc:	mov    0xb8(%rbx),%rdx
  30cde3:	cmp    %rdx,%rsi
  30cde6:	ja     30e22a <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e6a>
  30cdec:	mov    0xa0(%rbx),%rcx
  30cdf3:	mov    0xb0(%rbx),%rdx
  30cdfa:	cmp    $0x4,%rsi
  30cdfe:	jae    30ce07 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2a47>
  30ce00:	xor    %edi,%edi
  30ce02:	jmp    30cf4d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2b8d>
  30ce07:	cmp    $0x10,%rsi
  30ce0b:	jae    30ce15 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2a55>
  30ce0d:	xor    %r8d,%r8d
  30ce10:	jmp    30cec9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2b09>
  30ce15:	xor    %edi,%edi
  30ce17:	mov    0x1e8(%rsp),%r8
  30ce1f:	vmovdqu (%rcx,%rdi,1),%ymm0
  30ce24:	vmovdqu 0x20(%rcx,%rdi,1),%ymm1
  30ce2a:	vmovdqu 0x40(%rcx,%rdi,1),%ymm2
  30ce30:	vmovdqu 0x60(%rcx,%rdi,1),%ymm3
  30ce36:	vpcmpeqq %ymm8,%ymm0,%ymm4
  30ce3b:	vpcmpeqq %ymm8,%ymm1,%ymm5
  30ce40:	vpcmpeqq %ymm8,%ymm2,%ymm6
  30ce45:	vpcmpeqq %ymm8,%ymm3,%ymm7
  30ce4a:	vblendvpd %ymm4,%ymm9,%ymm10,%ymm4
  30ce50:	vblendvpd %ymm5,%ymm9,%ymm10,%ymm5
  30ce56:	vblendvpd %ymm6,%ymm9,%ymm10,%ymm6
  30ce5c:	vblendvpd %ymm7,%ymm9,%ymm10,%ymm7
  30ce62:	vpcmpgtq %ymm0,%ymm8,%ymm0
  30ce67:	vpandn %ymm4,%ymm0,%ymm0
  30ce6b:	vpcmpgtq %ymm1,%ymm8,%ymm1
  30ce70:	vpandn %ymm5,%ymm1,%ymm1
  30ce74:	vpcmpgtq %ymm2,%ymm8,%ymm2
  30ce79:	vpandn %ymm6,%ymm2,%ymm2
  30ce7d:	vpcmpgtq %ymm3,%ymm8,%ymm3
  30ce82:	vpandn %ymm7,%ymm3,%ymm3
  30ce86:	vmovdqu %ymm0,(%rdx,%rdi,1)
  30ce8b:	vmovdqu %ymm1,0x20(%rdx,%rdi,1)
  30ce91:	vmovdqu %ymm2,0x40(%rdx,%rdi,1)
  30ce97:	vmovdqu %ymm3,0x60(%rdx,%rdi,1)
  30ce9d:	sub    $0xffffffffffffff80,%rdi
  30cea1:	cmp    %rdi,%r8
  30cea4:	jne    30ce1f <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2a5f>
  30ceaa:	cmp    0x108(%rsp),%rsi
  30ceb2:	je     30cf02 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2b42>
  30ceb4:	mov    0x108(%rsp),%rdi
  30cebc:	mov    %rdi,%r8
  30cebf:	test   $0xc,%sil
  30cec3:	je     30cf4d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2b8d>
  30cec9:	mov    0x1f0(%rsp),%r9
  30ced1:	vmovdqu (%rcx,%r8,8),%ymm0
  30ced7:	vpcmpeqq %ymm8,%ymm0,%ymm1
  30cedc:	vblendvpd %ymm1,%ymm9,%ymm10,%ymm1
  30cee2:	vpcmpgtq %ymm0,%ymm8,%ymm0
  30cee7:	vpandn %ymm1,%ymm0,%ymm0
  30ceeb:	vmovdqu %ymm0,(%rdx,%r8,8)
  30cef1:	add    $0x4,%r8
  30cef5:	cmp    %r8,%r9
  30cef8:	jne    30ced1 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2b11>
  30cefa:	mov    %r9,%rdi
  30cefd:	cmp    %r9,%rsi
  30cf00:	jne    30cf4d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2b8d>
  30cf02:	mov    0xa8(%rbx),%rdx
  30cf09:	cmp    %rdx,%rsi
  30cf0c:	ja     30e23c <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3e7c>
  30cf12:	mov    0xa0(%rbx),%r10
  30cf19:	mov    $0x1,%dil
  30cf1c:	mov    %r10,%rcx
  30cf1f:	cmpq   $0x18,0x50(%rsp)
  30cf25:	vpcmpeqd %ymm9,%ymm9,%ymm9
  30cf2a:	jb     30d099 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2cd9>
  30cf30:	cmpq   $0x78,0x50(%rsp)
  30cf36:	jae    30cf6a <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2baa>
  30cf38:	xor    %r8d,%r8d
  30cf3b:	jmp    30d03a <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2c7a>
  30cf40:	vmovq  %xmm0,(%rdx,%rdi,8)
  30cf45:	inc    %rdi
  30cf48:	cmp    %rdi,%rsi
  30cf4b:	je     30cf02 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2b42>
  30cf4d:	xor    %r8d,%r8d
  30cf50:	cmpq   $0x0,(%rcx,%rdi,8)
  30cf55:	sete   %r9b
  30cf59:	vpxor  %xmm0,%xmm0,%xmm0
  30cf5d:	js     30cf40 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2b80>
  30cf5f:	mov    %r9b,%r8b
  30cf62:	vmovq  (%r14,%r8,8),%xmm0
  30cf68:	jmp    30cf40 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2b80>
  30cf6a:	mov    0xb8(%rsp),%rcx
  30cf72:	add    %r10,%rcx
  30cf75:	xor    %edi,%edi
  30cf77:	vmovdqa 0x1d0(%rsp),%xmm3
  30cf80:	vmovdqa %xmm3,%xmm0
  30cf84:	vmovdqa %xmm3,%xmm1
  30cf88:	vmovdqa %xmm3,%xmm2
  30cf8c:	mov    0xc0(%rsp),%r8
  30cf94:	vmovdqu (%r10,%rdi,8),%ymm4
  30cf9a:	vmovdqu 0x20(%r10,%rdi,8),%ymm5
  30cfa1:	vmovdqu 0x40(%r10,%rdi,8),%ymm6
  30cfa8:	vmovdqu 0x60(%r10,%rdi,8),%ymm7
  30cfaf:	vpcmpgtq %ymm9,%ymm4,%ymm4
  30cfb4:	vextracti128 $0x1,%ymm4,%xmm8
  30cfba:	vpackssdw %xmm8,%xmm4,%xmm4
  30cfbf:	vpand  %xmm4,%xmm0,%xmm0
  30cfc3:	vpcmpgtq %ymm9,%ymm5,%ymm4
  30cfc8:	vextracti128 $0x1,%ymm4,%xmm5
  30cfce:	vpackssdw %xmm5,%xmm4,%xmm4
  30cfd2:	vpand  %xmm4,%xmm1,%xmm1
  30cfd6:	vpcmpgtq %ymm9,%ymm6,%ymm4
  30cfdb:	vextracti128 $0x1,%ymm4,%xmm5
  30cfe1:	vpackssdw %xmm5,%xmm4,%xmm4
  30cfe5:	vpand  %xmm4,%xmm2,%xmm2
  30cfe9:	vpcmpgtq %ymm9,%ymm7,%ymm4
  30cfee:	vextracti128 $0x1,%ymm4,%xmm5
  30cff4:	vpackssdw %xmm5,%xmm4,%xmm4
  30cff8:	vpand  %xmm4,%xmm3,%xmm3
  30cffc:	add    $0x10,%rdi
  30d000:	cmp    %rdi,%r8
  30d003:	jne    30cf94 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2bd4>
  30d005:	vpand  %xmm0,%xmm1,%xmm0
  30d009:	vpand  %xmm0,%xmm2,%xmm0
  30d00d:	vpand  %xmm0,%xmm3,%xmm0
  30d011:	vpslld $0x1f,%xmm0,%xmm0
  30d016:	vpcmpeqd %xmm1,%xmm1,%xmm1
  30d01a:	vtestps %xmm1,%xmm0
  30d01f:	setb   %dil
  30d023:	mov    0x88(%rsp),%r9
  30d02b:	cmp    %r8,%r9
  30d02e:	je     30d0b8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2cf8>
  30d034:	test   $0xc,%r9b
  30d038:	je     30d099 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2cd9>
  30d03a:	mov    0xc8(%rsp),%rcx
  30d042:	add    %r10,%rcx
  30d045:	movzbl %dil,%edi
  30d049:	vpbroadcastd -0x2de4ea(%rip),%xmm0        # 2eb68 <anon.50b69747d574dc72ade27ed3c31d5ad9.135.llvm.15225965886487471349+0x2398>
  30d052:	vpinsrd $0x0,%edi,%xmm0,%xmm0
  30d058:	mov    0x80(%rsp),%r9
  30d060:	vmovdqu (%r10,%r8,8),%ymm1
  30d066:	vpcmpgtq %ymm9,%ymm1,%ymm1
  30d06b:	vextracti128 $0x1,%ymm1,%xmm2
  30d071:	vpackssdw %xmm2,%xmm1,%xmm1
  30d075:	vpand  %xmm1,%xmm0,%xmm0
  30d079:	add    $0x4,%r8
  30d07d:	cmp    %r8,%r9
  30d080:	jne    30d060 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2ca0>
  30d082:	vptest -0x2e0fdb(%rip),%xmm0        # 2c0b0 <anon.2284309812649c8e966c3f1909a927a8.23.llvm.17146629557222593030+0x4d0>
  30d08b:	setb   %dil
  30d08f:	cmp    %r9,0x88(%rsp)
  30d097:	je     30d0b8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2cf8>
  30d099:	mov    0x190(%rsp),%r8
  30d0a1:	add    %r10,%r8
  30d0a4:	cmpq   $0x0,(%rcx)
  30d0a8:	lea    0x8(%rcx),%rcx
  30d0ac:	setns  %r9b
  30d0b0:	and    %r9b,%dil
  30d0b3:	cmp    %r8,%rcx
  30d0b6:	jne    30d0a4 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2ce4>
  30d0b8:	test   %dil,%dil
  30d0bb:	jne    30d8de <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x351e>
  30d0c1:	cmp    %rax,0x10(%rsp)
  30d0c6:	ja     30d8e9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3529>
  30d0cc:	cmp    0x28(%rsp),%r11
  30d0d1:	jb     30cbdb <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x281b>
  30d0d7:	jmp    30d8e9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3529>
  30d0dc:	mov    $0x1,%r13b
  30d0df:	cmp    %rax,%rbp
  30d0e2:	jbe    30bd2a <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x196a>
  30d0e8:	jmp    30da8d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x36cd>
  30d0ed:	mov    %r12,%rdx
  30d0f0:	sub    %r10,%rdx
  30d0f3:	mov    %r12,%rcx
  30d0f6:	sub    %r10,%rcx
  30d0f9:	mov    %rcx,0x48(%rsp)
  30d0fe:	jbe    30da41 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3681>
  30d104:	mov    %rbp,0x58(%rsp)
  30d109:	cmp    0x28(%rbx),%r12
  30d10d:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d113:	cmp    0x38(%rbx),%r12
  30d117:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d11d:	cmp    0x48(%rbx),%r12
  30d121:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d127:	cmp    0x58(%rbx),%r12
  30d12b:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d131:	mov    %rdx,%rcx
  30d134:	shr    $1,%rcx
  30d137:	movabs $0x7ffffffffffffffe,%rax
  30d141:	and    %rdx,%rax
  30d144:	mov    0x110(%rsp),%r14
  30d14c:	lea    0x0(,%r14,8),%r10
  30d154:	mov    0x20(%rbx),%r11
  30d158:	add    %r10,%r11
  30d15b:	add    0x30(%rbx),%r10
  30d15f:	shl    $0x4,%r14
  30d163:	mov    0x40(%rbx),%r13
  30d167:	add    %r14,%r13
  30d16a:	mov    %rax,0x190(%rsp)
  30d172:	mov    %rax,%rdx
  30d175:	shl    $0x4,%rdx
  30d179:	lea    (%rdx,%r13,1),%rax
  30d17d:	mov    %rax,0x108(%rsp)
  30d185:	add    0x50(%rbx),%r14
  30d189:	mov    0x70(%rbx),%rax
  30d18d:	mov    %rax,0xb8(%rsp)
  30d195:	mov    0x78(%rbx),%rax
  30d199:	mov    %rax,0x88(%rsp)
  30d1a1:	add    %r14,%rdx
  30d1a4:	mov    %rdx,0x1d0(%rsp)
  30d1ac:	mov    0x88(%rbx),%rax
  30d1b3:	mov    %rax,0xc8(%rsp)
  30d1bb:	mov    0x80(%rbx),%rax
  30d1c2:	mov    %rax,0x50(%rsp)
  30d1c7:	mov    0x98(%rbx),%rax
  30d1ce:	mov    %rax,0x80(%rsp)
  30d1d6:	mov    0x90(%rbx),%rax
  30d1dd:	mov    %rax,(%rsp)
  30d1e1:	mov    0xc8(%rbx),%rax
  30d1e8:	mov    %rax,0x38(%rsp)
  30d1ed:	mov    0xc0(%rbx),%rax
  30d1f4:	mov    %rax,0x40(%rsp)
  30d1f9:	mov    0xd8(%rbx),%rax
  30d200:	mov    %rax,0x90(%rsp)
  30d208:	mov    0xd0(%rbx),%rax
  30d20f:	mov    %rax,0x130(%rsp)
  30d217:	mov    0xe8(%rbx),%rax
  30d21e:	mov    %rax,0x10(%rsp)
  30d223:	mov    0xe0(%rbx),%rax
  30d22a:	mov    %rax,0x30(%rsp)
  30d22f:	mov    0xf8(%rbx),%rax
  30d236:	mov    %rax,0x28(%rsp)
  30d23b:	mov    0xf0(%rbx),%rax
  30d242:	mov    %rax,0x150(%rsp)
  30d24a:	mov    $0x8,%r8d
  30d250:	xor    %edi,%edi
  30d252:	mov    0x18(%rsp),%rax
  30d257:	mov    0x8(%rsp),%rsi
  30d25c:	mov    %rcx,0xc0(%rsp)
  30d264:	jmp    30d45d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x309d>
  30d269:	cmp    %rax,0x60(%rsp)
  30d26e:	jbe    30c08b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x1ccb>
  30d274:	mov    $0x1,%al
  30d276:	test   %rsi,%rsi
  30d279:	je     30a50b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x14b>
  30d27f:	mov    0xc8(%rbx),%rdi
  30d286:	mov    0xc0(%rbx),%rdx
  30d28d:	mov    0xd8(%rbx),%rcx
  30d294:	mov    0xd0(%rbx),%r14
  30d29b:	mov    0xe8(%rbx),%r11
  30d2a2:	mov    0xe0(%rbx),%r15
  30d2a9:	mov    0xf8(%rbx),%r8
  30d2b0:	mov    0xf0(%rbx),%r12
  30d2b7:	mov    0x80(%rbx),%r13
  30d2be:	mov    0x88(%rbx),%r9
  30d2c5:	mov    0x98(%rbx),%r10
  30d2cc:	mov    %r10,0x60(%rsp)
  30d2d1:	mov    0x90(%rbx),%rbx
  30d2d8:	xor    %ebp,%ebp
  30d2da:	cmp    %rbp,%rdi
  30d2dd:	je     30e72e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x436e>
  30d2e3:	mov    (%rdx,%rbp,8),%r10
  30d2e7:	shr    $0x34,%r10
  30d2eb:	and    $0x7ff,%r10d
  30d2f2:	cmp    $0x7fe,%r10d
  30d2f9:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d2ff:	cmp    %rbp,%rcx
  30d302:	je     30e741 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4381>
  30d308:	mov    (%r14,%rbp,8),%r10
  30d30c:	shr    $0x34,%r10
  30d310:	and    $0x7ff,%r10d
  30d317:	cmp    $0x7fe,%r10d
  30d31e:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d324:	cmp    %rbp,%r11
  30d327:	je     30e757 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4397>
  30d32d:	mov    (%r15,%rbp,8),%r10
  30d331:	shr    $0x34,%r10
  30d335:	and    $0x7ff,%r10d
  30d33c:	cmp    $0x7fe,%r10d
  30d343:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d349:	cmp    %rbp,%r8
  30d34c:	je     30e76d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x43ad>
  30d352:	mov    (%r12,%rbp,8),%r10
  30d356:	shr    $0x34,%r10
  30d35a:	and    $0x7ff,%r10d
  30d361:	cmp    $0x7fe,%r10d
  30d368:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d36e:	cmp    %rbp,%r9
  30d371:	je     30e783 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x43c3>
  30d377:	mov    0x0(%r13,%rbp,8),%r10
  30d37c:	shr    $0x34,%r10
  30d380:	and    $0x7ff,%r10d
  30d387:	cmp    $0x7fe,%r10d
  30d38e:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d394:	cmp    %rbp,0x60(%rsp)
  30d399:	je     30e799 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x43d9>
  30d39f:	mov    (%rbx,%rbp,8),%r10
  30d3a3:	shr    $0x34,%r10
  30d3a7:	and    $0x7ff,%r10d
  30d3ae:	cmp    $0x7fe,%r10d
  30d3b5:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d3bb:	inc    %rbp
  30d3be:	cmp    %rbp,%rsi
  30d3c1:	jne    30d2da <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x2f1a>
  30d3c7:	jmp    30a50b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x14b>
  30d3cc:	mov    0x20(%rsp),%r12
  30d3d1:	mov    0x58(%rsp),%rbp
  30d3d6:	mov    0x50(%rsp),%rdx
  30d3db:	vmovupd %ymm9,(%rdx,%rcx,8)
  30d3e0:	mov    (%rsp),%rdi
  30d3e4:	vmovupd %ymm12,(%rdi,%rcx,8)
  30d3e9:	mov    0x40(%rsp),%r15
  30d3ee:	vmovupd %ymm3,(%r15,%rcx,8)
  30d3f4:	mov    0x130(%rsp),%r8
  30d3fc:	vmovupd %ymm2,(%r8,%rcx,8)
  30d402:	mov    0x30(%rsp),%rdi
  30d407:	vmovupd %ymm1,(%rdi,%rcx,8)
  30d40c:	mov    0x150(%rsp),%rdi
  30d414:	vmovupd %ymm0,(%rdi,%rcx,8)
  30d419:	mov    %rdi,%rcx
  30d41c:	mov    0x170(%rsp),%rdi
  30d424:	vmovupd %ymm8,(%rdx,%rdi,8)
  30d429:	mov    (%rsp),%rdx
  30d42d:	vmovupd %ymm13,(%rdx,%rdi,8)
  30d432:	vmovupd %ymm5,(%r15,%rdi,8)
  30d438:	vmovupd %ymm4,(%r8,%rdi,8)
  30d43e:	mov    0x30(%rsp),%rdx
  30d443:	vmovupd %ymm7,(%rdx,%rdi,8)
  30d448:	vmovupd %ymm6,(%rcx,%rdi,8)
  30d44d:	lea    0x8(%r9),%r8
  30d451:	mov    %r9,%rdi
  30d454:	cmp    %rsi,%r8
  30d457:	ja     30da53 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3693>
  30d45d:	mov    %r8,%r9
  30d460:	lea    0x4(%rdi),%r8
  30d464:	mov    0x88(%rsp),%rdx
  30d46c:	cmp    %rdx,%r8
  30d46f:	ja     30e47a <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x40ba>
  30d475:	lea    0x8(%rdi),%rbp
  30d479:	lea    0x7(%rdi),%rbx
  30d47d:	cmp    %rdx,%rbx
  30d480:	mov    0x80(%rsp),%r12
  30d488:	jae    30e48d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x40cd>
  30d48e:	mov    0xc8(%rsp),%rdx
  30d496:	cmp    %rdx,%r8
  30d499:	ja     30e4e6 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4126>
  30d49f:	cmp    %r12,%r8
  30d4a2:	mov    0x230(%rsp),%rbx
  30d4aa:	ja     30e4f9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4139>
  30d4b0:	cmp    0x38(%rsp),%r8
  30d4b5:	ja     30e50f <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x414f>
  30d4bb:	cmp    0x90(%rsp),%r8
  30d4c3:	ja     30e527 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4167>
  30d4c9:	cmp    0x10(%rsp),%r8
  30d4ce:	ja     30e542 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4182>
  30d4d4:	cmp    0x28(%rsp),%r8
  30d4d9:	ja     30e55a <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x419a>
  30d4df:	cmp    %rdx,%rbp
  30d4e2:	ja     30e572 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x41b2>
  30d4e8:	cmp    %r12,%rbp
  30d4eb:	ja     30e588 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x41c8>
  30d4f1:	cmp    0x38(%rsp),%rbp
  30d4f6:	ja     30e5a1 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x41e1>
  30d4fc:	cmp    0x90(%rsp),%rbp
  30d504:	ja     30e5bc <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x41fc>
  30d50a:	cmp    0x10(%rsp),%rbp
  30d50f:	ja     30e5da <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x421a>
  30d515:	cmp    0x28(%rsp),%rbp
  30d51a:	ja     30e5f5 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4235>
  30d520:	mov    0xb8(%rsp),%rdx
  30d528:	vmovups (%rdx,%rdi,8),%ymm0
  30d52d:	vmovups %ymm0,0x60(%rsp)
  30d533:	vmovupd (%rdx,%r8,8),%ymm15
  30d539:	mov    0x50(%rsp),%rdx
  30d53e:	vmovupd (%rdx,%rdi,8),%ymm9
  30d543:	mov    (%rsp),%r12
  30d547:	vmovupd (%r12,%rdi,8),%ymm12
  30d54d:	mov    0x40(%rsp),%rbp
  30d552:	vmovupd 0x0(%rbp,%rdi,8),%ymm3
  30d558:	mov    0x130(%rsp),%r15
  30d560:	vmovupd (%r15,%rdi,8),%ymm2
  30d566:	mov    0x30(%rsp),%rcx
  30d56b:	vmovupd (%rcx,%rdi,8),%ymm1
  30d570:	mov    0x150(%rsp),%rcx
  30d578:	mov    %rdi,0x1b0(%rsp)
  30d580:	vmovupd (%rcx,%rdi,8),%ymm0
  30d585:	vmovupd (%rdx,%r8,8),%ymm8
  30d58b:	vmovupd (%r12,%r8,8),%ymm13
  30d591:	vmovupd 0x0(%rbp,%r8,8),%ymm5
  30d598:	vmovupd (%r15,%r8,8),%ymm4
  30d59e:	mov    0x30(%rsp),%rdx
  30d5a3:	vmovupd (%rdx,%r8,8),%ymm7
  30d5a9:	vmovupd (%rcx,%r8,8),%ymm6
  30d5af:	mov    0xc0(%rsp),%r15
  30d5b7:	test   %r15,%r15
  30d5ba:	je     30d6bb <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x32fb>
  30d5c0:	mov    $0x8,%ebp
  30d5c5:	vmovapd %ymm13,%ymm14
  30d5ca:	vmovapd %ymm15,%ymm11
  30d5cf:	vmovapd %ymm12,%ymm15
  30d5d4:	vbroadcastsd -0x10(%r13,%rbp,2),%ymm12
  30d5db:	vfmadd231pd %ymm12,%ymm15,%ymm3
  30d5e0:	vfmadd231pd %ymm12,%ymm13,%ymm5
  30d5e5:	vbroadcastsd -0x8(%r13,%rbp,2),%ymm12
  30d5ec:	vfmadd231pd %ymm12,%ymm15,%ymm2
  30d5f1:	vfmadd231pd %ymm12,%ymm13,%ymm4
  30d5f6:	vbroadcastsd -0x10(%r14,%rbp,2),%ymm12
  30d5fd:	vfmadd231pd %ymm12,%ymm15,%ymm1
  30d602:	vfmadd231pd %ymm12,%ymm13,%ymm7
  30d607:	vbroadcastsd -0x8(%r14,%rbp,2),%ymm12
  30d60e:	vfmadd231pd %ymm12,%ymm15,%ymm0
  30d613:	vfmadd231pd %ymm12,%ymm13,%ymm6
  30d618:	vbroadcastsd -0x8(%r11,%rbp,1),%ymm12
  30d61f:	vbroadcastsd -0x8(%r10,%rbp,1),%ymm13
  30d626:	vmovupd 0x60(%rsp),%ymm10
  30d62c:	vfmadd213pd %ymm13,%ymm12,%ymm10
  30d631:	vfmadd231pd %ymm10,%ymm15,%ymm9
  30d636:	vfmadd213pd %ymm13,%ymm11,%ymm12
  30d63b:	vfmadd231pd %ymm12,%ymm14,%ymm8
  30d640:	vbroadcastsd 0x0(%r13,%rbp,2),%ymm10
  30d647:	vfmadd231pd %ymm10,%ymm9,%ymm3
  30d64c:	vfmadd231pd %ymm10,%ymm8,%ymm5
  30d651:	vbroadcastsd 0x8(%r13,%rbp,2),%ymm10
  30d658:	vfmadd231pd %ymm10,%ymm9,%ymm2
  30d65d:	vfmadd231pd %ymm10,%ymm8,%ymm4
  30d662:	vbroadcastsd (%r14,%rbp,2),%ymm10
  30d668:	vfmadd231pd %ymm10,%ymm9,%ymm1
  30d66d:	vfmadd231pd %ymm10,%ymm8,%ymm7
  30d672:	vbroadcastsd 0x8(%r14,%rbp,2),%ymm10
  30d679:	vfmadd231pd %ymm10,%ymm9,%ymm0
  30d67e:	vfmadd231pd %ymm10,%ymm8,%ymm6
  30d683:	vbroadcastsd (%r11,%rbp,1),%ymm13
  30d689:	vbroadcastsd (%r10,%rbp,1),%ymm10
  30d68f:	vmovupd 0x60(%rsp),%ymm12
  30d695:	vfmadd213pd %ymm10,%ymm13,%ymm12
  30d69a:	vfmadd213pd %ymm15,%ymm9,%ymm12
  30d69f:	vmovapd %ymm11,%ymm15
  30d6a4:	vfmadd213pd %ymm10,%ymm11,%ymm13
  30d6a9:	vfmadd213pd %ymm14,%ymm8,%ymm13
  30d6ae:	add    $0x10,%rbp
  30d6b2:	dec    %r15
  30d6b5:	jne    30d5c5 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3205>
  30d6bb:	mov    0x48(%rsp),%rcx
  30d6c0:	cmp    %rcx,0x190(%rsp)
  30d6c8:	mov    0x1b0(%rsp),%rcx
  30d6d0:	mov    %r8,0x170(%rsp)
  30d6d8:	je     30d3cc <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x300c>
  30d6de:	mov    0x190(%rsp),%r15
  30d6e6:	vbroadcastsd (%r11,%r15,8),%ymm10
  30d6ec:	vbroadcastsd (%r10,%r15,8),%ymm14
  30d6f2:	vmovupd 0x60(%rsp),%ymm11
  30d6f8:	vfmadd213pd %ymm14,%ymm10,%ymm11
  30d6fd:	vfmadd213pd %ymm14,%ymm10,%ymm15
  30d702:	vfmadd213pd %ymm9,%ymm12,%ymm11
  30d707:	mov    0x108(%rsp),%rdx
  30d70f:	vbroadcastsd (%rdx),%ymm9
  30d714:	vfmadd231pd %ymm9,%ymm12,%ymm3
  30d719:	vfmadd231pd %ymm9,%ymm13,%ymm5
  30d71e:	vbroadcastsd 0x8(%rdx),%ymm9
  30d724:	vfmadd231pd %ymm9,%ymm12,%ymm2
  30d729:	vfmadd231pd %ymm9,%ymm13,%ymm4
  30d72e:	mov    0x1d0(%rsp),%rdx
  30d736:	vbroadcastsd (%rdx),%ymm9
  30d73b:	vfmadd231pd %ymm9,%ymm12,%ymm1
  30d740:	vfmadd231pd %ymm9,%ymm13,%ymm7
  30d745:	vbroadcastsd 0x8(%rdx),%ymm9
  30d74b:	vfmadd231pd %ymm9,%ymm12,%ymm0
  30d750:	vfmadd231pd %ymm9,%ymm13,%ymm6
  30d755:	vfmadd213pd %ymm8,%ymm13,%ymm15
  30d75a:	vmovapd %ymm13,%ymm8
  30d75f:	vmovapd %ymm15,%ymm13
  30d764:	vmovapd %ymm12,%ymm9
  30d769:	vmovapd %ymm11,%ymm12
  30d76e:	jmp    30d3cc <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x300c>
  30d773:	mov    $0x1,%al
  30d775:	cmp    %r11,0x90(%rsp)
  30d77d:	jbe    30c6a8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x22e8>
  30d783:	jmp    30dc38 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3878>
  30d788:	mov    %rbp,%rdx
  30d78b:	sub    %r10,%rdx
  30d78e:	mov    %rbp,%rcx
  30d791:	sub    %r10,%rcx
  30d794:	jbe    30dbe5 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3825>
  30d79a:	mov    0x80(%rsp),%rax
  30d7a2:	cmp    0x28(%rbx),%rax
  30d7a6:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d7ac:	cmp    0x38(%rbx),%rax
  30d7b0:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d7b6:	cmp    0x48(%rbx),%rax
  30d7ba:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d7c0:	cmp    0x58(%rbx),%rax
  30d7c4:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d7ca:	mov    %rdx,%rax
  30d7cd:	shr    $1,%rax
  30d7d0:	mov    %rax,0x58(%rsp)
  30d7d5:	movabs $0x7ffffffffffffffe,%rax
  30d7df:	and    %rdx,%rax
  30d7e2:	mov    0x30(%rsp),%r12
  30d7e7:	lea    0x0(,%r12,8),%r13
  30d7ef:	mov    0x20(%rbx),%r15
  30d7f3:	add    %r13,%r15
  30d7f6:	add    0x30(%rbx),%r13
  30d7fa:	shl    $0x4,%r12
  30d7fe:	mov    0x40(%rbx),%r8
  30d802:	add    %r12,%r8
  30d805:	mov    %rax,0x190(%rsp)
  30d80d:	mov    %rax,%rdx
  30d810:	shl    $0x4,%rdx
  30d814:	lea    (%r8,%rdx,1),%rax
  30d818:	mov    %rax,0xb8(%rsp)
  30d820:	add    0x50(%rbx),%r12
  30d824:	mov    0x70(%rbx),%rax
  30d828:	mov    %rax,0xc8(%rsp)
  30d830:	mov    0x78(%rbx),%rax
  30d834:	mov    %rax,0x88(%rsp)
  30d83c:	add    %r12,%rdx
  30d83f:	mov    %rdx,0xc0(%rsp)
  30d847:	mov    0x88(%rbx),%rax
  30d84e:	mov    %rax,0x20(%rsp)
  30d853:	mov    0x80(%rbx),%rax
  30d85a:	mov    %rax,0x50(%rsp)
  30d85f:	mov    0x98(%rbx),%rax
  30d866:	mov    %rax,(%rsp)
  30d86a:	mov    0x90(%rbx),%rax
  30d871:	mov    %rax,0x40(%rsp)
  30d876:	mov    0xc8(%rbx),%rax
  30d87d:	mov    %rax,0x48(%rsp)
  30d882:	mov    0xc0(%rbx),%rax
  30d889:	mov    %rax,0x130(%rsp)
  30d891:	mov    0xd8(%rbx),%rax
  30d898:	mov    %rax,0x38(%rsp)
  30d89d:	mov    0xd0(%rbx),%rax
  30d8a4:	mov    %rax,0x150(%rsp)
  30d8ac:	mov    0xe8(%rbx),%rax
  30d8b3:	mov    %rax,0x10(%rsp)
  30d8b8:	mov    0xe0(%rbx),%r14
  30d8bf:	mov    0xf8(%rbx),%rax
  30d8c6:	mov    %rax,0x28(%rsp)
  30d8cb:	mov    0xf0(%rbx),%r10
  30d8d2:	mov    $0x8,%ebp
  30d8d7:	xor    %edi,%edi
  30d8d9:	jmp    30deb9 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3af9>
  30d8de:	cmp    %rax,0x10(%rsp)
  30d8e3:	jbe    30ca0c <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x264c>
  30d8e9:	mov    $0x1,%al
  30d8eb:	test   %rsi,%rsi
  30d8ee:	je     30a50b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x14b>
  30d8f4:	mov    0xc8(%rbx),%rdi
  30d8fb:	mov    0xc0(%rbx),%rdx
  30d902:	mov    0xd8(%rbx),%rcx
  30d909:	mov    0xd0(%rbx),%r14
  30d910:	mov    0xe8(%rbx),%r11
  30d917:	mov    0xe0(%rbx),%r15
  30d91e:	mov    0xf8(%rbx),%r8
  30d925:	mov    0xf0(%rbx),%r12
  30d92c:	mov    0x80(%rbx),%r13
  30d933:	mov    0x88(%rbx),%r9
  30d93a:	mov    0x98(%rbx),%r10
  30d941:	mov    %r10,0x60(%rsp)
  30d946:	mov    0x90(%rbx),%rbx
  30d94d:	xor    %ebp,%ebp
  30d94f:	cmp    %rbp,%rdi
  30d952:	je     30e72e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x436e>
  30d958:	mov    (%rdx,%rbp,8),%r10
  30d95c:	shr    $0x34,%r10
  30d960:	and    $0x7ff,%r10d
  30d967:	cmp    $0x7fe,%r10d
  30d96e:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d974:	cmp    %rbp,%rcx
  30d977:	je     30e741 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4381>
  30d97d:	mov    (%r14,%rbp,8),%r10
  30d981:	shr    $0x34,%r10
  30d985:	and    $0x7ff,%r10d
  30d98c:	cmp    $0x7fe,%r10d
  30d993:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d999:	cmp    %rbp,%r11
  30d99c:	je     30e757 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4397>
  30d9a2:	mov    (%r15,%rbp,8),%r10
  30d9a6:	shr    $0x34,%r10
  30d9aa:	and    $0x7ff,%r10d
  30d9b1:	cmp    $0x7fe,%r10d
  30d9b8:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d9be:	cmp    %rbp,%r8
  30d9c1:	je     30e76d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x43ad>
  30d9c7:	mov    (%r12,%rbp,8),%r10
  30d9cb:	shr    $0x34,%r10
  30d9cf:	and    $0x7ff,%r10d
  30d9d6:	cmp    $0x7fe,%r10d
  30d9dd:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30d9e3:	cmp    %rbp,%r9
  30d9e6:	je     30e783 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x43c3>
  30d9ec:	mov    0x0(%r13,%rbp,8),%r10
  30d9f1:	shr    $0x34,%r10
  30d9f5:	and    $0x7ff,%r10d
  30d9fc:	cmp    $0x7fe,%r10d
  30da03:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30da09:	cmp    %rbp,0x60(%rsp)
  30da0e:	je     30e799 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x43d9>
  30da14:	mov    (%rbx,%rbp,8),%r10
  30da18:	shr    $0x34,%r10
  30da1c:	and    $0x7ff,%r10d
  30da23:	cmp    $0x7fe,%r10d
  30da2a:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30da30:	inc    %rbp
  30da33:	cmp    %rbp,%rsi
  30da36:	jne    30d94f <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x358f>
  30da3c:	jmp    30a50b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x14b>
  30da41:	xor    %ecx,%ecx
  30da43:	lea    0x8(%rcx),%r9
  30da47:	add    $0x10,%rcx
  30da4b:	cmp    %rsi,%rcx
  30da4e:	mov    %r9,%rcx
  30da51:	jbe    30da43 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3683>
  30da53:	cmp    %rsi,%r9
  30da56:	mov    0x110(%rsp),%r8
  30da5e:	jae    30da8d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x36cd>
  30da60:	sub    $0x8,%rsp
  30da64:	mov    %rbx,%rdi
  30da67:	mov    %rax,%rsi
  30da6a:	mov    %r12,%rdx
  30da6d:	mov    %rbp,%rcx
  30da70:	push   0x10(%rsp)
  30da74:	vzeroupper
  30da77:	call   3069c0 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>>
  30da7c:	mov    0x18(%rsp),%rsi
  30da81:	add    $0x10,%rsp
  30da85:	test   %al,%al
  30da87:	je     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30da8d:	mov    $0x1,%al
  30da8f:	test   %rsi,%rsi
  30da92:	je     30a50b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x14b>
  30da98:	mov    0xc8(%rbx),%rdi
  30da9f:	mov    0xc0(%rbx),%rdx
  30daa6:	mov    0xd8(%rbx),%rcx
  30daad:	mov    0xd0(%rbx),%r14
  30dab4:	mov    0xe8(%rbx),%r11
  30dabb:	mov    0xe0(%rbx),%r15
  30dac2:	mov    0xf8(%rbx),%r8
  30dac9:	mov    0xf0(%rbx),%r12
  30dad0:	mov    0x80(%rbx),%r13
  30dad7:	mov    0x88(%rbx),%r9
  30dade:	mov    0x98(%rbx),%r10
  30dae5:	mov    %r10,0x60(%rsp)
  30daea:	mov    0x90(%rbx),%rbx
  30daf1:	xor    %ebp,%ebp
  30daf3:	cmp    %rbp,%rdi
  30daf6:	je     30e72e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x436e>
  30dafc:	mov    (%rdx,%rbp,8),%r10
  30db00:	shr    $0x34,%r10
  30db04:	and    $0x7ff,%r10d
  30db0b:	cmp    $0x7fe,%r10d
  30db12:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30db18:	cmp    %rbp,%rcx
  30db1b:	je     30e741 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4381>
  30db21:	mov    (%r14,%rbp,8),%r10
  30db25:	shr    $0x34,%r10
  30db29:	and    $0x7ff,%r10d
  30db30:	cmp    $0x7fe,%r10d
  30db37:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30db3d:	cmp    %rbp,%r11
  30db40:	je     30e757 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4397>
  30db46:	mov    (%r15,%rbp,8),%r10
  30db4a:	shr    $0x34,%r10
  30db4e:	and    $0x7ff,%r10d
  30db55:	cmp    $0x7fe,%r10d
  30db5c:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30db62:	cmp    %rbp,%r8
  30db65:	je     30e76d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x43ad>
  30db6b:	mov    (%r12,%rbp,8),%r10
  30db6f:	shr    $0x34,%r10
  30db73:	and    $0x7ff,%r10d
  30db7a:	cmp    $0x7fe,%r10d
  30db81:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30db87:	cmp    %rbp,%r9
  30db8a:	je     30e783 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x43c3>
  30db90:	mov    0x0(%r13,%rbp,8),%r10
  30db95:	shr    $0x34,%r10
  30db99:	and    $0x7ff,%r10d
  30dba0:	cmp    $0x7fe,%r10d
  30dba7:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30dbad:	cmp    %rbp,0x60(%rsp)
  30dbb2:	je     30e799 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x43d9>
  30dbb8:	mov    (%rbx,%rbp,8),%r10
  30dbbc:	shr    $0x34,%r10
  30dbc0:	and    $0x7ff,%r10d
  30dbc7:	cmp    $0x7fe,%r10d
  30dbce:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30dbd4:	inc    %rbp
  30dbd7:	cmp    %rbp,%rsi
  30dbda:	jne    30daf3 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3733>
  30dbe0:	jmp    30a50b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x14b>
  30dbe5:	xor    %ecx,%ecx
  30dbe7:	lea    0x8(%rcx),%r9
  30dbeb:	add    $0x10,%rcx
  30dbef:	cmp    %rsi,%rcx
  30dbf2:	mov    %r9,%rcx
  30dbf5:	jbe    30dbe7 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3827>
  30dbf7:	cmp    %rsi,%r9
  30dbfa:	mov    0x90(%rsp),%rcx
  30dc02:	mov    0x30(%rsp),%r8
  30dc07:	mov    0x80(%rsp),%rdx
  30dc0f:	jae    30dc38 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3878>
  30dc11:	sub    $0x8,%rsp
  30dc15:	mov    %rbx,%rdi
  30dc18:	mov    %r11,%rsi
  30dc1b:	push   0x10(%rsp)
  30dc1f:	vzeroupper
  30dc22:	call   3069c0 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>>
  30dc27:	mov    0x18(%rsp),%rsi
  30dc2c:	add    $0x10,%rsp
  30dc30:	test   %al,%al
  30dc32:	je     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30dc38:	mov    $0x1,%al
  30dc3a:	test   %rsi,%rsi
  30dc3d:	je     30a50b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x14b>
  30dc43:	mov    0xc8(%rbx),%rdi
  30dc4a:	mov    0xc0(%rbx),%rdx
  30dc51:	mov    0xd8(%rbx),%rcx
  30dc58:	mov    0xd0(%rbx),%r14
  30dc5f:	mov    0xe8(%rbx),%r11
  30dc66:	mov    0xe0(%rbx),%r15
  30dc6d:	mov    0xf8(%rbx),%r8
  30dc74:	mov    0xf0(%rbx),%r12
  30dc7b:	mov    0x80(%rbx),%r13
  30dc82:	mov    0x88(%rbx),%r9
  30dc89:	mov    0x98(%rbx),%r10
  30dc90:	mov    %r10,0x60(%rsp)
  30dc95:	mov    0x90(%rbx),%rbx
  30dc9c:	xor    %ebp,%ebp
  30dc9e:	cmp    %rbp,%rdi
  30dca1:	je     30e72e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x436e>
  30dca7:	mov    (%rdx,%rbp,8),%r10
  30dcab:	shr    $0x34,%r10
  30dcaf:	and    $0x7ff,%r10d
  30dcb6:	cmp    $0x7fe,%r10d
  30dcbd:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30dcc3:	cmp    %rbp,%rcx
  30dcc6:	je     30e741 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4381>
  30dccc:	mov    (%r14,%rbp,8),%r10
  30dcd0:	shr    $0x34,%r10
  30dcd4:	and    $0x7ff,%r10d
  30dcdb:	cmp    $0x7fe,%r10d
  30dce2:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30dce8:	cmp    %rbp,%r11
  30dceb:	je     30e757 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4397>
  30dcf1:	mov    (%r15,%rbp,8),%r10
  30dcf5:	shr    $0x34,%r10
  30dcf9:	and    $0x7ff,%r10d
  30dd00:	cmp    $0x7fe,%r10d
  30dd07:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30dd0d:	cmp    %rbp,%r8
  30dd10:	je     30e76d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x43ad>
  30dd16:	mov    (%r12,%rbp,8),%r10
  30dd1a:	shr    $0x34,%r10
  30dd1e:	and    $0x7ff,%r10d
  30dd25:	cmp    $0x7fe,%r10d
  30dd2c:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30dd32:	cmp    %rbp,%r9
  30dd35:	je     30e783 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x43c3>
  30dd3b:	mov    0x0(%r13,%rbp,8),%r10
  30dd40:	shr    $0x34,%r10
  30dd44:	and    $0x7ff,%r10d
  30dd4b:	cmp    $0x7fe,%r10d
  30dd52:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30dd58:	cmp    %rbp,0x60(%rsp)
  30dd5d:	je     30e799 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x43d9>
  30dd63:	mov    (%rbx,%rbp,8),%r10
  30dd67:	shr    $0x34,%r10
  30dd6b:	and    $0x7ff,%r10d
  30dd72:	cmp    $0x7fe,%r10d
  30dd79:	ja     30a509 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x149>
  30dd7f:	inc    %rbp
  30dd82:	cmp    %rbp,%rsi
  30dd85:	jne    30dc9e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x38de>
  30dd8b:	jmp    30a50b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x14b>
  30dd90:	mov    0x190(%rsp),%rax
  30dd98:	vbroadcastsd (%r15,%rax,8),%ymm10
  30dd9e:	vbroadcastsd 0x0(%r13,%rax,8),%ymm14
  30dda5:	vmovupd 0x110(%rsp),%ymm11
  30ddae:	vfmadd213pd %ymm14,%ymm10,%ymm11
  30ddb3:	vmovupd 0x60(%rsp),%ymm15
  30ddb9:	vfmadd213pd %ymm14,%ymm10,%ymm15
  30ddbe:	vfmadd213pd %ymm6,%ymm12,%ymm11
  30ddc3:	mov    0xb8(%rsp),%rax
  30ddcb:	vbroadcastsd (%rax),%ymm9
  30ddd0:	vfmadd231pd %ymm9,%ymm12,%ymm4
  30ddd5:	vmovupd 0x170(%rsp),%ymm10
  30ddde:	vfmadd231pd %ymm9,%ymm13,%ymm10
  30dde3:	vbroadcastsd 0x8(%rax),%ymm9
  30dde9:	vfmadd231pd %ymm9,%ymm12,%ymm3
  30ddee:	vfmadd231pd %ymm9,%ymm13,%ymm5
  30ddf3:	mov    0xc0(%rsp),%rax
  30ddfb:	vbroadcastsd (%rax),%ymm9
  30de00:	vfmadd231pd %ymm9,%ymm12,%ymm2
  30de05:	vmovupd 0x1b0(%rsp),%ymm6
  30de0e:	vfmadd231pd %ymm9,%ymm13,%ymm6
  30de13:	vbroadcastsd 0x8(%rax),%ymm9
  30de19:	vfmadd231pd %ymm9,%ymm12,%ymm1
  30de1e:	vfmadd231pd %ymm9,%ymm13,%ymm7
  30de23:	vfmadd213pd %ymm0,%ymm13,%ymm15
  30de28:	vmovapd %ymm13,%ymm8
  30de2d:	vmovapd %ymm15,%ymm13
  30de32:	vmovapd %ymm12,%ymm0
  30de36:	vmovapd %ymm11,%ymm12
  30de3b:	mov    0x50(%rsp),%rax
  30de40:	vmovupd %ymm0,(%rax,%rdi,8)
  30de45:	mov    0x40(%rsp),%rdx
  30de4a:	vmovupd %ymm12,(%rdx,%rdi,8)
  30de4f:	mov    0x130(%rsp),%rbx
  30de57:	vmovupd %ymm4,(%rbx,%rdi,8)
  30de5c:	mov    0x150(%rsp),%r11
  30de64:	vmovupd %ymm3,(%r11,%rdi,8)
  30de6a:	vmovupd %ymm2,(%r14,%rdi,8)
  30de70:	vmovupd %ymm1,(%r10,%rdi,8)
  30de76:	vmovupd %ymm8,(%rax,%rsi,8)
  30de7b:	vmovupd %ymm13,(%rdx,%rsi,8)
  30de80:	vmovupd %ymm10,(%rbx,%rsi,8)
  30de85:	vmovupd %ymm5,(%r11,%rsi,8)
  30de8b:	vmovupd %ymm6,(%r14,%rsi,8)
  30de91:	vmovupd %ymm7,(%r10,%rsi,8)
  30de97:	lea    0x8(%r9),%rbp
  30de9b:	mov    %r9,%rdi
  30de9e:	mov    0x8(%rsp),%rsi
  30dea3:	cmp    %rsi,%rbp
  30dea6:	mov    0x18(%rsp),%r11
  30deab:	mov    0x230(%rsp),%rbx
  30deb3:	ja     30dbf7 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3837>
  30deb9:	lea    0x4(%rdi),%rsi
  30debd:	mov    0x88(%rsp),%rdx
  30dec5:	cmp    %rdx,%rsi
  30dec8:	ja     30e4b8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x40f8>
  30dece:	lea    0x8(%rdi),%rax
  30ded2:	lea    0x7(%rdi),%rbx
  30ded6:	cmp    %rdx,%rbx
  30ded9:	jae    30e4c8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4108>
  30dedf:	cmp    0x20(%rsp),%rsi
  30dee4:	ja     30e610 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4250>
  30deea:	cmp    (%rsp),%rsi
  30deee:	ja     30e625 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4265>
  30def4:	cmp    0x48(%rsp),%rsi
  30def9:	ja     30e639 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4279>
  30deff:	cmp    0x38(%rsp),%rsi
  30df04:	ja     30e64e <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x428e>
  30df0a:	cmp    0x10(%rsp),%rsi
  30df0f:	ja     30e663 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x42a3>
  30df15:	cmp    0x28(%rsp),%rsi
  30df1a:	ja     30e678 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x42b8>
  30df20:	cmp    0x20(%rsp),%rax
  30df25:	ja     30e68d <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x42cd>
  30df2b:	cmp    (%rsp),%rax
  30df2f:	ja     30e6a8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x42e8>
  30df35:	cmp    0x48(%rsp),%rax
  30df3a:	ja     30e6c2 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4302>
  30df40:	cmp    0x38(%rsp),%rax
  30df45:	ja     30e6dd <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x431d>
  30df4b:	cmp    0x10(%rsp),%rax
  30df50:	ja     30e6f8 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4338>
  30df56:	cmp    0x28(%rsp),%rax
  30df5b:	ja     30e713 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x4353>
  30df61:	mov    %rbp,%r9
  30df64:	mov    0xc8(%rsp),%rax
  30df6c:	vmovups (%rax,%rdi,8),%ymm0
  30df71:	vmovups %ymm0,0x110(%rsp)
  30df7a:	vmovups (%rax,%rsi,8),%ymm0
  30df7f:	vmovups %ymm0,0x60(%rsp)
  30df85:	mov    0x50(%rsp),%rax
  30df8a:	vmovupd (%rax,%rdi,8),%ymm6
  30df8f:	mov    0x40(%rsp),%rdx
  30df94:	vmovupd (%rdx,%rdi,8),%ymm12
  30df99:	mov    0x130(%rsp),%rbx
  30dfa1:	vmovupd (%rbx,%rdi,8),%ymm4
  30dfa6:	mov    0x150(%rsp),%r11
  30dfae:	vmovupd (%r11,%rdi,8),%ymm3
  30dfb4:	vmovupd (%r14,%rdi,8),%ymm2
  30dfba:	vmovupd (%r10,%rdi,8),%ymm1
  30dfc0:	vmovupd (%rax,%rsi,8),%ymm0
  30dfc5:	vmovupd (%rdx,%rsi,8),%ymm13
  30dfca:	vmovupd (%rbx,%rsi,8),%ymm9
  30dfcf:	vmovupd (%r11,%rsi,8),%ymm5
  30dfd5:	vmovupd (%r14,%rsi,8),%ymm8
  30dfdb:	vmovupd (%r10,%rsi,8),%ymm7
  30dfe1:	cmpq   $0x0,0x58(%rsp)
  30dfe7:	je     30e0ee <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3d2e>
  30dfed:	mov    $0x8,%eax
  30dff2:	mov    0x58(%rsp),%rbp
  30dff7:	vmovapd %ymm13,%ymm14
  30dffc:	vmovapd %ymm12,%ymm15
  30e001:	vbroadcastsd -0x10(%r8,%rax,2),%ymm12
  30e008:	vfmadd231pd %ymm12,%ymm15,%ymm4
  30e00d:	vfmadd231pd %ymm12,%ymm13,%ymm9
  30e012:	vbroadcastsd -0x8(%r8,%rax,2),%ymm12
  30e019:	vfmadd231pd %ymm12,%ymm15,%ymm3
  30e01e:	vfmadd231pd %ymm12,%ymm13,%ymm5
  30e023:	vbroadcastsd -0x10(%r12,%rax,2),%ymm12
  30e02a:	vfmadd231pd %ymm12,%ymm15,%ymm2
  30e02f:	vfmadd231pd %ymm12,%ymm13,%ymm8
  30e034:	vbroadcastsd -0x8(%r12,%rax,2),%ymm12
  30e03b:	vfmadd231pd %ymm12,%ymm15,%ymm1
  30e040:	vfmadd231pd %ymm12,%ymm13,%ymm7
  30e045:	vbroadcastsd -0x8(%r15,%rax,1),%ymm12
  30e04c:	vbroadcastsd -0x8(%r13,%rax,1),%ymm13
  30e053:	vmovupd 0x110(%rsp),%ymm11
  30e05c:	vmovapd %ymm11,%ymm10
  30e061:	vfmadd213pd %ymm13,%ymm12,%ymm10
  30e066:	vfmadd231pd %ymm10,%ymm15,%ymm6
  30e06b:	vfmadd132pd 0x60(%rsp),%ymm13,%ymm12
  30e072:	vfmadd231pd %ymm12,%ymm14,%ymm0
  30e077:	vbroadcastsd (%r8,%rax,2),%ymm10
  30e07d:	vfmadd231pd %ymm10,%ymm6,%ymm4
  30e082:	vfmadd231pd %ymm10,%ymm0,%ymm9
  30e087:	vbroadcastsd 0x8(%r8,%rax,2),%ymm10
  30e08e:	vfmadd231pd %ymm10,%ymm6,%ymm3
  30e093:	vfmadd231pd %ymm10,%ymm0,%ymm5
  30e098:	vbroadcastsd (%r12,%rax,2),%ymm10
  30e09e:	vfmadd231pd %ymm10,%ymm6,%ymm2
  30e0a3:	vfmadd231pd %ymm10,%ymm0,%ymm8
  30e0a8:	vbroadcastsd 0x8(%r12,%rax,2),%ymm10
  30e0af:	vfmadd231pd %ymm10,%ymm6,%ymm1
  30e0b4:	vfmadd231pd %ymm10,%ymm0,%ymm7
  30e0b9:	vbroadcastsd (%r15,%rax,1),%ymm13
  30e0bf:	vbroadcastsd 0x0(%r13,%rax,1),%ymm10
  30e0c6:	vmovapd %ymm11,%ymm12
  30e0cb:	vfmadd213pd %ymm10,%ymm13,%ymm12
  30e0d0:	vfmadd213pd %ymm15,%ymm6,%ymm12
  30e0d5:	vfmadd132pd 0x60(%rsp),%ymm10,%ymm13
  30e0dc:	vfmadd213pd %ymm14,%ymm0,%ymm13
  30e0e1:	add    $0x10,%rax
  30e0e5:	dec    %rbp
  30e0e8:	jne    30dff7 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3c37>
  30e0ee:	vmovupd %ymm8,0x1b0(%rsp)
  30e0f7:	vmovupd %ymm9,0x170(%rsp)
  30e100:	cmp    %rcx,0x190(%rsp)
  30e108:	jne    30dd90 <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x39d0>
  30e10e:	vmovapd %ymm0,%ymm8
  30e112:	vmovupd 0x170(%rsp),%ymm10
  30e11b:	vmovapd %ymm6,%ymm0
  30e11f:	vmovupd 0x1b0(%rsp),%ymm6
  30e128:	jmp    30de3b <rustsht::legendre::scalar_ordered::kernel::synthesize_prepared_component_batch_dispatched+0x3a7b>
  30e12d:	lea    0xa721c(%rip),%rcx        # 3b5350 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0xc0>
  30e134:	xor    %edi,%edi
  30e136:	mov    %rax,%rsi
  30e139:	call   *0xaefa1(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e13f:	lea    0xa7282(%rip),%rcx        # 3b53c8 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x138>
  30e146:	xor    %edi,%edi
  30e148:	mov    %rax,%rsi
  30e14b:	call   *0xaef8f(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e151:	lea    0xa7288(%rip),%rcx        # 3b53e0 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x150>
  30e158:	xor    %edi,%edi
  30e15a:	mov    %rax,%rsi
  30e15d:	call   *0xaef7d(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e163:	lea    0xa728e(%rip),%rcx        # 3b53f8 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x168>
  30e16a:	xor    %edi,%edi
  30e16c:	mov    %rax,%rsi
  30e16f:	call   *0xaef6b(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e175:	lea    0xa72dc(%rip),%rcx        # 3b5458 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x1c8>
  30e17c:	xor    %edi,%edi
  30e17e:	vzeroupper
  30e181:	call   *0xaef59(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e187:	lea    0xa7342(%rip),%rcx        # 3b54d0 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x240>
  30e18e:	xor    %edi,%edi
  30e190:	vzeroupper
  30e193:	call   *0xaef47(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e199:	lea    0xa7348(%rip),%rcx        # 3b54e8 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x258>
  30e1a0:	xor    %edi,%edi
  30e1a2:	vzeroupper
  30e1a5:	call   *0xaef35(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e1ab:	lea    0xa734e(%rip),%rcx        # 3b5500 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x270>
  30e1b2:	xor    %edi,%edi
  30e1b4:	vzeroupper
  30e1b7:	call   *0xaef23(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e1bd:	lea    0xa7354(%rip),%rcx        # 3b5518 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x288>
  30e1c4:	xor    %edi,%edi
  30e1c6:	vzeroupper
  30e1c9:	call   *0xaef11(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e1cf:	lea    0xa735a(%rip),%rcx        # 3b5530 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x2a0>
  30e1d6:	xor    %edi,%edi
  30e1d8:	call   *0xaef02(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e1de:	lea    0xa7183(%rip),%rcx        # 3b5368 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0xd8>
  30e1e5:	xor    %edi,%edi
  30e1e7:	mov    (%rsp),%rsi
  30e1eb:	call   *0xaeeef(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e1f1:	lea    0xa7188(%rip),%rcx        # 3b5380 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0xf0>
  30e1f8:	xor    %edi,%edi
  30e1fa:	mov    (%rsp),%rsi
  30e1fe:	call   *0xaeedc(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e204:	lea    0xa718d(%rip),%rcx        # 3b5398 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x108>
  30e20b:	xor    %edi,%edi
  30e20d:	mov    (%rsp),%rsi
  30e211:	call   *0xaeec9(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e217:	lea    0xa7192(%rip),%rcx        # 3b53b0 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x120>
  30e21e:	xor    %edi,%edi
  30e220:	mov    (%rsp),%rsi
  30e224:	call   *0xaeeb6(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e22a:	lea    0xa732f(%rip),%rcx        # 3b5560 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x2d0>
  30e231:	xor    %edi,%edi
  30e233:	vzeroupper
  30e236:	call   *0xaeea4(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e23c:	lea    0xa7335(%rip),%rcx        # 3b5578 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x2e8>
  30e243:	xor    %edi,%edi
  30e245:	vzeroupper
  30e248:	call   *0xaee92(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e24e:	lea    0xa706b(%rip),%rcx        # 3b52c0 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x30>
  30e255:	xor    %edi,%edi
  30e257:	vzeroupper
  30e25a:	call   *0xaee80(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e260:	lea    0xa70e9(%rip),%rcx        # 3b5350 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0xc0>
  30e267:	xor    %edi,%edi
  30e269:	mov    %r8,%rsi
  30e26c:	call   *0xaee6e(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e272:	lea    0xa705f(%rip),%rcx        # 3b52d8 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x48>
  30e279:	xor    %edi,%edi
  30e27b:	vzeroupper
  30e27e:	call   *0xaee5c(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e284:	lea    0xa7065(%rip),%rcx        # 3b52f0 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x60>
  30e28b:	xor    %edi,%edi
  30e28d:	vzeroupper
  30e290:	call   *0xaee4a(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e296:	lea    0xa712b(%rip),%rcx        # 3b53c8 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x138>
  30e29d:	xor    %edi,%edi
  30e29f:	mov    %r8,%rsi
  30e2a2:	call   *0xaee38(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e2a8:	lea    0xa7131(%rip),%rcx        # 3b53e0 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x150>
  30e2af:	xor    %edi,%edi
  30e2b1:	mov    %r8,%rsi
  30e2b4:	call   *0xaee26(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e2ba:	lea    0xa7137(%rip),%rcx        # 3b53f8 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x168>
  30e2c1:	xor    %edi,%edi
  30e2c3:	mov    %r8,%rsi
  30e2c6:	call   *0xaee14(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e2cc:	lea    0xa713d(%rip),%rcx        # 3b5410 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x180>
  30e2d3:	xor    %edi,%edi
  30e2d5:	call   *0xaee05(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e2db:	lea    0xa7296(%rip),%rcx        # 3b5578 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x2e8>
  30e2e2:	xor    %edi,%edi
  30e2e4:	mov    %r14,%rdx
  30e2e7:	vzeroupper
  30e2ea:	call   *0xaedf0(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e2f0:	lea    0xa7131(%rip),%rcx        # 3b5428 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x198>
  30e2f7:	xor    %edi,%edi
  30e2f9:	mov    %rax,%rdx
  30e2fc:	call   *0xaedde(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e302:	lea    0xa6fff(%rip),%rcx        # 3b5308 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x78>
  30e309:	xor    %edi,%edi
  30e30b:	call   *0xaedcf(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e311:	lea    0xa6f90(%rip),%rcx        # 3b52a8 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x18>
  30e318:	mov    %r13,%rdi
  30e31b:	call   *0xaedbf(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e321:	lea    0xa7040(%rip),%rcx        # 3b5368 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0xd8>
  30e328:	xor    %edi,%edi
  30e32a:	mov    0x8(%rsp),%rsi
  30e32f:	call   *0xaedab(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e335:	lea    0xa7044(%rip),%rcx        # 3b5380 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0xf0>
  30e33c:	xor    %edi,%edi
  30e33e:	mov    0x8(%rsp),%rsi
  30e343:	call   *0xaed97(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e349:	lea    0xa7048(%rip),%rcx        # 3b5398 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x108>
  30e350:	xor    %edi,%edi
  30e352:	mov    0x8(%rsp),%rsi
  30e357:	call   *0xaed83(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e35d:	lea    0xa704c(%rip),%rcx        # 3b53b0 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x120>
  30e364:	xor    %edi,%edi
  30e366:	mov    0x8(%rsp),%rsi
  30e36b:	call   *0xaed6f(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e371:	lea    0xa71d0(%rip),%rcx        # 3b5548 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x2b8>
  30e378:	xor    %edi,%edi
  30e37a:	vzeroupper
  30e37d:	call   *0xaed5d(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e383:	lea    0xa71ee(%rip),%rcx        # 3b5578 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x2e8>
  30e38a:	xor    %edi,%edi
  30e38c:	mov    %r15,%rdx
  30e38f:	vzeroupper
  30e392:	call   *0xaed48(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e398:	lea    0xa70a1(%rip),%rcx        # 3b5440 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x1b0>
  30e39f:	xor    %edi,%edi
  30e3a1:	vzeroupper
  30e3a4:	call   *0xaed36(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e3aa:	lea    0xa7197(%rip),%rcx        # 3b5548 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x2b8>
  30e3b1:	xor    %edi,%edi
  30e3b3:	mov    %r14,%rdx
  30e3b6:	vzeroupper
  30e3b9:	call   *0xaed21(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e3bf:	lea    0xa6f42(%rip),%rcx        # 3b5308 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x78>
  30e3c6:	xor    %edi,%edi
  30e3c8:	mov    %r8,%rsi
  30e3cb:	vzeroupper
  30e3ce:	call   *0xaed0c(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e3d4:	lea    0xa6ecd(%rip),%rcx        # 3b52a8 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x18>
  30e3db:	mov    %r15,%rdi
  30e3de:	call   *0xaecfc(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e3e4:	lea    0xa703d(%rip),%rcx        # 3b5428 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x198>
  30e3eb:	xor    %edi,%edi
  30e3ed:	call   *0xaeced(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e3f3:	lea    0xa714e(%rip),%rcx        # 3b5548 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x2b8>
  30e3fa:	xor    %edi,%edi
  30e3fc:	mov    %r15,%rdx
  30e3ff:	vzeroupper
  30e402:	call   *0xaecd8(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e408:	lea    0xa7181(%rip),%rcx        # 3b5590 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x300>
  30e40f:	xor    %edi,%edi
  30e411:	mov    %rax,%rdx
  30e414:	vzeroupper
  30e417:	call   *0xaecc3(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e41d:	lea    0xa7184(%rip),%rcx        # 3b55a8 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x318>
  30e424:	xor    %edi,%edi
  30e426:	vzeroupper
  30e429:	call   *0xaecb1(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e42f:	lea    0xa700a(%rip),%rcx        # 3b5440 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x1b0>
  30e436:	xor    %edi,%edi
  30e438:	mov    %r14,%rdx
  30e43b:	call   *0xaec9f(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e441:	lea    0xa6ff8(%rip),%rcx        # 3b5440 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x1b0>
  30e448:	xor    %edi,%edi
  30e44a:	mov    %r15,%rdx
  30e44d:	call   *0xaec8d(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e453:	lea    0xa7136(%rip),%rcx        # 3b5590 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x300>
  30e45a:	xor    %edi,%edi
  30e45c:	vzeroupper
  30e45f:	call   *0xaec7b(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e465:	lea    0xa713c(%rip),%rcx        # 3b55a8 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x318>
  30e46c:	xor    %edi,%edi
  30e46e:	mov    %r14,%rdx
  30e471:	vzeroupper
  30e474:	call   *0xaec66(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e47a:	lea    0xa75d7(%rip),%rcx        # 3b5a58 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x318>
  30e481:	mov    %r8,%rsi
  30e484:	vzeroupper
  30e487:	call   *0xaec53(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e48d:	lea    0xa75ac(%rip),%rcx        # 3b5a40 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x300>
  30e494:	mov    %r8,%rdi
  30e497:	mov    %rbp,%rsi
  30e49a:	vzeroupper
  30e49d:	call   *0xaec3d(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e4a3:	lea    0xa70fe(%rip),%rcx        # 3b55a8 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x318>
  30e4aa:	xor    %edi,%edi
  30e4ac:	mov    %r15,%rdx
  30e4af:	vzeroupper
  30e4b2:	call   *0xaec28(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e4b8:	lea    0xa7599(%rip),%rcx        # 3b5a58 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x318>
  30e4bf:	vzeroupper
  30e4c2:	call   *0xaec18(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e4c8:	lea    0xa7571(%rip),%rcx        # 3b5a40 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x300>
  30e4cf:	mov    %rsi,%rdi
  30e4d2:	mov    %rax,%rsi
  30e4d5:	mov    0x88(%rsp),%rdx
  30e4dd:	vzeroupper
  30e4e0:	call   *0xaebfa(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e4e6:	lea    0xa7433(%rip),%rcx        # 3b5920 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x1e0>
  30e4ed:	mov    %r8,%rsi
  30e4f0:	vzeroupper
  30e4f3:	call   *0xaebe7(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e4f9:	lea    0xa7438(%rip),%rcx        # 3b5938 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x1f8>
  30e500:	mov    %r8,%rsi
  30e503:	mov    %r12,%rdx
  30e506:	vzeroupper
  30e509:	call   *0xaebd1(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e50f:	lea    0xa743a(%rip),%rcx        # 3b5950 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x210>
  30e516:	mov    %r8,%rsi
  30e519:	mov    0x38(%rsp),%rdx
  30e51e:	vzeroupper
  30e521:	call   *0xaebb9(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e527:	lea    0xa743a(%rip),%rcx        # 3b5968 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x228>
  30e52e:	mov    %r8,%rsi
  30e531:	mov    0x90(%rsp),%rdx
  30e539:	vzeroupper
  30e53c:	call   *0xaeb9e(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e542:	lea    0xa7437(%rip),%rcx        # 3b5980 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x240>
  30e549:	mov    %r8,%rsi
  30e54c:	mov    0x10(%rsp),%rdx
  30e551:	vzeroupper
  30e554:	call   *0xaeb86(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e55a:	lea    0xa7437(%rip),%rcx        # 3b5998 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x258>
  30e561:	mov    %r8,%rsi
  30e564:	mov    0x28(%rsp),%rdx
  30e569:	vzeroupper
  30e56c:	call   *0xaeb6e(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e572:	lea    0xa7437(%rip),%rcx        # 3b59b0 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x270>
  30e579:	mov    %r8,%rdi
  30e57c:	mov    %rbp,%rsi
  30e57f:	vzeroupper
  30e582:	call   *0xaeb58(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e588:	lea    0xa7439(%rip),%rcx        # 3b59c8 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x288>
  30e58f:	mov    %r8,%rdi
  30e592:	mov    %rbp,%rsi
  30e595:	mov    %r12,%rdx
  30e598:	vzeroupper
  30e59b:	call   *0xaeb3f(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e5a1:	lea    0xa7438(%rip),%rcx        # 3b59e0 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x2a0>
  30e5a8:	mov    %r8,%rdi
  30e5ab:	mov    %rbp,%rsi
  30e5ae:	mov    0x38(%rsp),%rdx
  30e5b3:	vzeroupper
  30e5b6:	call   *0xaeb24(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e5bc:	lea    0xa7435(%rip),%rcx        # 3b59f8 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x2b8>
  30e5c3:	mov    %r8,%rdi
  30e5c6:	mov    %rbp,%rsi
  30e5c9:	mov    0x90(%rsp),%rdx
  30e5d1:	vzeroupper
  30e5d4:	call   *0xaeb06(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e5da:	lea    0xa742f(%rip),%rcx        # 3b5a10 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x2d0>
  30e5e1:	mov    %r8,%rdi
  30e5e4:	mov    %rbp,%rsi
  30e5e7:	mov    0x10(%rsp),%rdx
  30e5ec:	vzeroupper
  30e5ef:	call   *0xaeaeb(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e5f5:	lea    0xa742c(%rip),%rcx        # 3b5a28 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x2e8>
  30e5fc:	mov    %r8,%rdi
  30e5ff:	mov    %rbp,%rsi
  30e602:	mov    0x28(%rsp),%rdx
  30e607:	vzeroupper
  30e60a:	call   *0xaead0(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e610:	lea    0xa7309(%rip),%rcx        # 3b5920 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x1e0>
  30e617:	mov    0x20(%rsp),%rdx
  30e61c:	vzeroupper
  30e61f:	call   *0xaeabb(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e625:	lea    0xa730c(%rip),%rcx        # 3b5938 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x1f8>
  30e62c:	mov    (%rsp),%rdx
  30e630:	vzeroupper
  30e633:	call   *0xaeaa7(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e639:	lea    0xa7310(%rip),%rcx        # 3b5950 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x210>
  30e640:	mov    0x48(%rsp),%rdx
  30e645:	vzeroupper
  30e648:	call   *0xaea92(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e64e:	lea    0xa7313(%rip),%rcx        # 3b5968 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x228>
  30e655:	mov    0x38(%rsp),%rdx
  30e65a:	vzeroupper
  30e65d:	call   *0xaea7d(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e663:	lea    0xa7316(%rip),%rcx        # 3b5980 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x240>
  30e66a:	mov    0x10(%rsp),%rdx
  30e66f:	vzeroupper
  30e672:	call   *0xaea68(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e678:	lea    0xa7319(%rip),%rcx        # 3b5998 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x258>
  30e67f:	mov    0x28(%rsp),%rdx
  30e684:	vzeroupper
  30e687:	call   *0xaea53(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e68d:	lea    0xa731c(%rip),%rcx        # 3b59b0 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x270>
  30e694:	mov    %rsi,%rdi
  30e697:	mov    %rax,%rsi
  30e69a:	mov    0x20(%rsp),%rdx
  30e69f:	vzeroupper
  30e6a2:	call   *0xaea38(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e6a8:	lea    0xa7319(%rip),%rcx        # 3b59c8 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x288>
  30e6af:	mov    %rsi,%rdi
  30e6b2:	mov    %rax,%rsi
  30e6b5:	mov    (%rsp),%rdx
  30e6b9:	vzeroupper
  30e6bc:	call   *0xaea1e(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e6c2:	lea    0xa7317(%rip),%rcx        # 3b59e0 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x2a0>
  30e6c9:	mov    %rsi,%rdi
  30e6cc:	mov    %rax,%rsi
  30e6cf:	mov    0x48(%rsp),%rdx
  30e6d4:	vzeroupper
  30e6d7:	call   *0xaea03(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e6dd:	lea    0xa7314(%rip),%rcx        # 3b59f8 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x2b8>
  30e6e4:	mov    %rsi,%rdi
  30e6e7:	mov    %rax,%rsi
  30e6ea:	mov    0x38(%rsp),%rdx
  30e6ef:	vzeroupper
  30e6f2:	call   *0xae9e8(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e6f8:	lea    0xa7311(%rip),%rcx        # 3b5a10 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x2d0>
  30e6ff:	mov    %rsi,%rdi
  30e702:	mov    %rax,%rsi
  30e705:	mov    0x10(%rsp),%rdx
  30e70a:	vzeroupper
  30e70d:	call   *0xae9cd(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e713:	lea    0xa730e(%rip),%rcx        # 3b5a28 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x2e8>
  30e71a:	mov    %rsi,%rdi
  30e71d:	mov    %rax,%rsi
  30e720:	mov    0x28(%rsp),%rdx
  30e725:	vzeroupper
  30e728:	call   *0xae9b2(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  30e72e:	lea    0xa6e8b(%rip),%rdx        # 3b55c0 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x330>
  30e735:	mov    %rdi,%rsi
  30e738:	vzeroupper
  30e73b:	call   *0xae90f(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e741:	lea    0xa6e90(%rip),%rdx        # 3b55d8 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x348>
  30e748:	mov    %rcx,%rdi
  30e74b:	mov    %rcx,%rsi
  30e74e:	vzeroupper
  30e751:	call   *0xae8f9(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e757:	lea    0xa6e92(%rip),%rdx        # 3b55f0 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x360>
  30e75e:	mov    %r11,%rdi
  30e761:	mov    %r11,%rsi
  30e764:	vzeroupper
  30e767:	call   *0xae8e3(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e76d:	lea    0xa6e94(%rip),%rdx        # 3b5608 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x378>
  30e774:	mov    %r8,%rdi
  30e777:	mov    %r8,%rsi
  30e77a:	vzeroupper
  30e77d:	call   *0xae8cd(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e783:	lea    0xa6e96(%rip),%rdx        # 3b5620 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x390>
  30e78a:	mov    %r9,%rdi
  30e78d:	mov    %r9,%rsi
  30e790:	vzeroupper
  30e793:	call   *0xae8b7(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e799:	lea    0xa6e98(%rip),%rdx        # 3b5638 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x3a8>
  30e7a0:	mov    0x60(%rsp),%rdi
  30e7a5:	mov    %rdi,%rsi
  30e7a8:	vzeroupper
  30e7ab:	call   *0xae89f(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e7b1:	lea    0xa6cd0(%rip),%rdx        # 3b5488 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x1f8>
  30e7b8:	mov    0x30(%rsp),%rdi
  30e7bd:	mov    %rdi,%rsi
  30e7c0:	vzeroupper
  30e7c3:	call   *0xae887(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e7c9:	lea    0xa6cd0(%rip),%rdx        # 3b54a0 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x210>
  30e7d0:	mov    0x48(%rsp),%rdi
  30e7d5:	mov    %rdi,%rsi
  30e7d8:	vzeroupper
  30e7db:	call   *0xae86f(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e7e1:	lea    0xa6cd0(%rip),%rdx        # 3b54b8 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x228>
  30e7e8:	mov    0x38(%rsp),%rdi
  30e7ed:	mov    %rdi,%rsi
  30e7f0:	vzeroupper
  30e7f3:	call   *0xae857(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e7f9:	lea    0xa6c70(%rip),%rdx        # 3b5470 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x1e0>
  30e800:	mov    0x110(%rsp),%rdi
  30e808:	mov    %rdi,%rsi
  30e80b:	vzeroupper
  30e80e:	call   *0xae83c(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e814:	lea    0xa6c6d(%rip),%rdx        # 3b5488 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x1f8>
  30e81b:	mov    0x170(%rsp),%rdi
  30e823:	mov    0x30(%rsp),%rsi
  30e828:	vzeroupper
  30e82b:	call   *0xae81f(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e831:	lea    0xa6c68(%rip),%rdx        # 3b54a0 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x210>
  30e838:	mov    0x1b0(%rsp),%rdi
  30e840:	mov    0x48(%rsp),%rsi
  30e845:	vzeroupper
  30e848:	call   *0xae802(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e84e:	lea    0xa6c63(%rip),%rdx        # 3b54b8 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x228>
  30e855:	mov    0x58(%rsp),%rdi
  30e85a:	mov    0x38(%rsp),%rsi
  30e85f:	vzeroupper
  30e862:	call   *0xae7e8(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e868:	lea    0xa6c01(%rip),%rdx        # 3b5470 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x1e0>
  30e86f:	mov    0x150(%rsp),%rdi
  30e877:	mov    0x110(%rsp),%rsi
  30e87f:	vzeroupper
  30e882:	call   *0xae7c8(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e888:	lea    0xa6c11(%rip),%rdx        # 3b54a0 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x210>
  30e88f:	mov    0x170(%rsp),%rdi
  30e897:	mov    0x48(%rsp),%rsi
  30e89c:	vzeroupper
  30e89f:	call   *0xae7ab(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e8a5:	lea    0xa6bc4(%rip),%rdx        # 3b5470 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x1e0>
  30e8ac:	mov    0x130(%rsp),%rdi
  30e8b4:	mov    0x110(%rsp),%rsi
  30e8bc:	vzeroupper
  30e8bf:	call   *0xae78b(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e8c5:	lea    0xa6bec(%rip),%rdx        # 3b54b8 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x228>
  30e8cc:	mov    0x1b0(%rsp),%rdi
  30e8d4:	mov    0x38(%rsp),%rsi
  30e8d9:	vzeroupper
  30e8dc:	call   *0xae76e(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e8e2:	lea    0xa6b9f(%rip),%rdx        # 3b5488 <anon.57e367dc796540cb2490dff35027e128.18.llvm.9400485801228579583+0x1f8>
  30e8e9:	mov    0x150(%rsp),%rdi
  30e8f1:	mov    0x30(%rsp),%rsi
  30e8f6:	vzeroupper
  30e8f9:	call   *0xae751(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  30e8ff:	int3


00000000003069c0 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>>:
  3069c0:	push   %rbp
  3069c1:	push   %r15
  3069c3:	push   %r14
  3069c5:	push   %r13
  3069c7:	push   %r12
  3069c9:	push   %rbx
  3069ca:	sub    $0x48,%rsp
  3069ce:	cmp    %rsi,%rcx
  3069d1:	seta   %al
  3069d4:	cmp    %rdx,%r8
  3069d7:	setae  %cl
  3069da:	or     %al,%cl
  3069dc:	mov    $0x1,%al
  3069de:	jne    306d42 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x382>
  3069e4:	mov    0x80(%rsp),%rsi
  3069ec:	mov    0x78(%rdi),%r10
  3069f0:	mov    %rsi,%rcx
  3069f3:	sub    %r9,%rcx
  3069f6:	jb     306d54 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x394>
  3069fc:	cmp    %r10,%rsi
  3069ff:	ja     306d54 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x394>
  306a05:	cmp    $0x4,%rcx
  306a09:	jne    306c74 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x2b4>
  306a0f:	mov    0x88(%rdi),%r10
  306a16:	cmp    %r10,%rsi
  306a19:	ja     306d67 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x3a7>
  306a1f:	mov    0x98(%rdi),%r10
  306a26:	cmp    %r10,%rsi
  306a29:	ja     306d7a <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x3ba>
  306a2f:	mov    0xc8(%rdi),%r10
  306a36:	cmp    %r10,%rsi
  306a39:	ja     306d8d <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x3cd>
  306a3f:	mov    0xd8(%rdi),%r10
  306a46:	cmp    %r10,%rsi
  306a49:	ja     306da0 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x3e0>
  306a4f:	mov    0xe8(%rdi),%r10
  306a56:	cmp    %r10,%rsi
  306a59:	ja     306db3 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x3f3>
  306a5f:	mov    0xf8(%rdi),%r10
  306a66:	cmp    %r10,%rsi
  306a69:	ja     306dc6 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x406>
  306a6f:	mov    0x70(%rdi),%rbx
  306a73:	mov    0x20(%rdi),%r15
  306a77:	mov    0x28(%rdi),%r11
  306a7b:	mov    0x30(%rdi),%r12
  306a7f:	mov    0x38(%rdi),%r10
  306a83:	mov    0x40(%rdi),%r13
  306a87:	mov    0x48(%rdi),%rcx
  306a8b:	mov    0x50(%rdi),%rax
  306a8f:	mov    %rax,0x10(%rsp)
  306a94:	mov    0x58(%rdi),%rsi
  306a98:	vmovupd (%rbx,%r9,8),%ymm6
  306a9e:	mov    0x80(%rdi),%rax
  306aa5:	vmovupd (%rax,%r9,8),%ymm0
  306aab:	mov    0x90(%rdi),%rbp
  306ab2:	vmovupd 0x0(%rbp,%r9,8),%ymm2
  306ab9:	mov    0xc0(%rdi),%rbx
  306ac0:	vmovupd (%rbx,%r9,8),%ymm1
  306ac6:	mov    0xd0(%rdi),%r14
  306acd:	mov    %r14,0x8(%rsp)
  306ad2:	vmovupd (%r14,%r9,8),%ymm3
  306ad8:	mov    0xe0(%rdi),%r14
  306adf:	mov    %r14,0x40(%rsp)
  306ae4:	vmovupd (%r14,%r9,8),%ymm4
  306aea:	mov    0xf0(%rdi),%r14
  306af1:	vmovupd (%r14,%r9,8),%ymm5
  306af7:	lea    0x1(%r8),%rdi
  306afb:	cmp    %rdx,%rdi
  306afe:	mov    %r13,0x30(%rsp)
  306b03:	mov    %r14,0x38(%rsp)
  306b08:	jae    306c7b <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x2bb>
  306b0e:	mov    %rbx,0x18(%rsp)
  306b13:	mov    %rbp,0x20(%rsp)
  306b18:	mov    %rax,0x28(%rsp)
  306b1d:	shl    $0x4,%r8
  306b21:	add    %r8,%r13
  306b24:	mov    0x10(%rsp),%rax
  306b29:	add    %rax,%r8
  306b2c:	mov    $0x8,%ebp
  306b31:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  306b40:	lea    -0x1(%rdi),%rbx
  306b44:	cmp    %r11,%rbx
  306b47:	jae    306e61 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x4a1>
  306b4d:	cmp    %r10,%rbx
  306b50:	jae    306e4b <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x48b>
  306b56:	cmp    %r11,%rdi
  306b59:	jae    306e38 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x478>
  306b5f:	cmp    %r10,%rdi
  306b62:	jae    306e25 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x465>
  306b68:	cmp    %rcx,%rbx
  306b6b:	jae    306e0f <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x44f>
  306b71:	cmp    %rsi,%rbx
  306b74:	jae    306dfc <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x43c>
  306b7a:	cmp    %rcx,%rdi
  306b7d:	jae    306de9 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x429>
  306b83:	cmp    %rsi,%rdi
  306b86:	jae    306dd9 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x419>
  306b8c:	vmovsd -0x8(%r15,%rdi,8),%xmm7
  306b93:	vmovsd -0x10(%r13,%rbp,2),%xmm8
  306b9a:	vbroadcastsd %xmm8,%ymm8
  306b9f:	vfmadd231pd %ymm8,%ymm2,%ymm1
  306ba4:	vmovsd -0x8(%r13,%rbp,2),%xmm8
  306bab:	vbroadcastsd %xmm8,%ymm8
  306bb0:	vfmadd231pd %ymm8,%ymm2,%ymm3
  306bb5:	vmovsd -0x10(%r8,%rbp,2),%xmm8
  306bbc:	vbroadcastsd %xmm8,%ymm8
  306bc1:	vfmadd231pd %ymm8,%ymm2,%ymm4
  306bc6:	vmovsd -0x8(%r8,%rbp,2),%xmm8
  306bcd:	vbroadcastsd %xmm8,%ymm8
  306bd2:	vfmadd231pd %ymm8,%ymm2,%ymm5
  306bd7:	vmovsd -0x8(%r12,%rdi,8),%xmm8
  306bde:	vbroadcastsd %xmm7,%ymm7
  306be3:	vbroadcastsd %xmm8,%ymm8
  306be8:	vfmadd231pd %ymm7,%ymm6,%ymm8
  306bed:	vmovsd (%r15,%rdi,8),%xmm7
  306bf3:	vfmadd231pd %ymm8,%ymm2,%ymm0
  306bf8:	vbroadcastsd 0x0(%r13,%rbp,2),%ymm8
  306bff:	vfmadd231pd %ymm8,%ymm0,%ymm1
  306c04:	vbroadcastsd 0x8(%r13,%rbp,2),%ymm8
  306c0b:	vfmadd231pd %ymm8,%ymm0,%ymm3
  306c10:	vbroadcastsd (%r8,%rbp,2),%ymm8
  306c16:	vfmadd231pd %ymm8,%ymm0,%ymm4
  306c1b:	vbroadcastsd 0x8(%r8,%rbp,2),%ymm8
  306c22:	vfmadd231pd %ymm8,%ymm0,%ymm5
  306c27:	vmovsd (%r12,%rdi,8),%xmm8
  306c2d:	vbroadcastsd %xmm7,%ymm7
  306c32:	vbroadcastsd %xmm8,%ymm8
  306c37:	vfmadd231pd %ymm7,%ymm6,%ymm8
  306c3c:	vfmadd231pd %ymm8,%ymm0,%ymm2
  306c41:	add    $0x2,%rdi
  306c45:	add    $0x10,%rbp
  306c49:	cmp    %rdx,%rdi
  306c4c:	jb     306b40 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x180>
  306c52:	mov    %rax,%r14
  306c55:	dec    %rdi
  306c58:	mov    %rdi,%r8
  306c5b:	mov    0x28(%rsp),%rax
  306c60:	mov    0x20(%rsp),%rbp
  306c65:	mov    0x18(%rsp),%rbx
  306c6a:	cmp    %rdx,%r8
  306c6d:	jb     306c89 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x2c9>
  306c6f:	jmp    306d0c <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x34c>
  306c74:	xor    %eax,%eax
  306c76:	jmp    306d42 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x382>
  306c7b:	mov    0x10(%rsp),%r14
  306c80:	cmp    %rdx,%r8
  306c83:	jae    306d0c <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x34c>
  306c89:	cmp    %r11,%r8
  306c8c:	jae    306e77 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x4b7>
  306c92:	cmp    %r10,%r8
  306c95:	jae    306e8d <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x4cd>
  306c9b:	cmp    %rcx,%r8
  306c9e:	jae    306ea3 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x4e3>
  306ca4:	cmp    %rsi,%r8
  306ca7:	mov    0x30(%rsp),%rcx
  306cac:	jae    306eb9 <rustsht::legendre::scalar_ordered::kernel::synthesize_ordinary_suffix_vector::<pulp::x86::v3::V3>+0x4f9>
  306cb2:	vmovsd (%r15,%r8,8),%xmm7
  306cb8:	vmovsd (%r12,%r8,8),%xmm8
  306cbe:	shl    $0x4,%r8
  306cc2:	vbroadcastsd %xmm7,%ymm7
  306cc7:	vbroadcastsd %xmm8,%ymm8
  306ccc:	vbroadcastsd (%rcx,%r8,1),%ymm9
  306cd2:	vbroadcastsd 0x8(%rcx,%r8,1),%ymm10
  306cd9:	vbroadcastsd (%r14,%r8,1),%ymm11
  306cdf:	vbroadcastsd 0x8(%r14,%r8,1),%ymm12
  306ce6:	vfmadd231pd %ymm9,%ymm2,%ymm1
  306ceb:	vfmadd231pd %ymm10,%ymm2,%ymm3
  306cf0:	vfmadd231pd %ymm11,%ymm2,%ymm4
  306cf5:	vfmadd231pd %ymm12,%ymm2,%ymm5
  306cfa:	vfmadd213pd %ymm8,%ymm7,%ymm6
  306cff:	vfmadd213pd %ymm0,%ymm2,%ymm6
  306d04:	vmovapd %ymm2,%ymm0
  306d08:	vmovapd %ymm6,%ymm2
  306d0c:	mov    0x8(%rsp),%rcx
  306d11:	vmovupd %ymm0,(%rax,%r9,8)
  306d17:	vmovupd %ymm2,0x0(%rbp,%r9,8)
  306d1e:	vmovupd %ymm1,(%rbx,%r9,8)
  306d24:	vmovupd %ymm3,(%rcx,%r9,8)
  306d2a:	mov    0x40(%rsp),%rcx
  306d2f:	vmovupd %ymm4,(%rcx,%r9,8)
  306d35:	mov    0x38(%rsp),%rax
  306d3a:	vmovupd %ymm5,(%rax,%r9,8)
  306d40:	mov    $0x1,%al
  306d42:	add    $0x48,%rsp
  306d46:	pop    %rbx
  306d47:	pop    %r12
  306d49:	pop    %r13
  306d4b:	pop    %r14
  306d4d:	pop    %r15
  306d4f:	pop    %rbp
  306d50:	vzeroupper
  306d53:	ret
  306d54:	lea    0xaebad(%rip),%rcx        # 3b5908 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x1c8>
  306d5b:	mov    %r9,%rdi
  306d5e:	mov    %r10,%rdx
  306d61:	call   *0xb6379(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  306d67:	lea    0xae9ea(%rip),%rcx        # 3b5758 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x18>
  306d6e:	mov    %r9,%rdi
  306d71:	mov    %r10,%rdx
  306d74:	call   *0xb6366(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  306d7a:	lea    0xae9ef(%rip),%rcx        # 3b5770 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x30>
  306d81:	mov    %r9,%rdi
  306d84:	mov    %r10,%rdx
  306d87:	call   *0xb6353(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  306d8d:	lea    0xae9f4(%rip),%rcx        # 3b5788 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x48>
  306d94:	mov    %r9,%rdi
  306d97:	mov    %r10,%rdx
  306d9a:	call   *0xb6340(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  306da0:	lea    0xae9f9(%rip),%rcx        # 3b57a0 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x60>
  306da7:	mov    %r9,%rdi
  306daa:	mov    %r10,%rdx
  306dad:	call   *0xb632d(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  306db3:	lea    0xae9fe(%rip),%rcx        # 3b57b8 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x78>
  306dba:	mov    %r9,%rdi
  306dbd:	mov    %r10,%rdx
  306dc0:	call   *0xb631a(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  306dc6:	lea    0xaea03(%rip),%rcx        # 3b57d0 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x90>
  306dcd:	mov    %r9,%rdi
  306dd0:	mov    %r10,%rdx
  306dd3:	call   *0xb6307(%rip)        # 3bd0e0 <_DYNAMIC+0x348>
  306dd9:	lea    0xaeb10(%rip),%rdx        # 3b58f0 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x1b0>
  306de0:	vzeroupper
  306de3:	call   *0xb6267(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  306de9:	lea    0xaeae8(%rip),%rdx        # 3b58d8 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x198>
  306df0:	mov    %rcx,%rsi
  306df3:	vzeroupper
  306df6:	call   *0xb6254(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  306dfc:	lea    0xaeabd(%rip),%rdx        # 3b58c0 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x180>
  306e03:	mov    %rbx,%rdi
  306e06:	vzeroupper
  306e09:	call   *0xb6241(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  306e0f:	lea    0xaea92(%rip),%rdx        # 3b58a8 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x168>
  306e16:	mov    %rbx,%rdi
  306e19:	mov    %rcx,%rsi
  306e1c:	vzeroupper
  306e1f:	call   *0xb622b(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  306e25:	lea    0xaea64(%rip),%rdx        # 3b5890 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x150>
  306e2c:	mov    %r10,%rsi
  306e2f:	vzeroupper
  306e32:	call   *0xb6218(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  306e38:	lea    0xaea39(%rip),%rdx        # 3b5878 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x138>
  306e3f:	mov    %r11,%rsi
  306e42:	vzeroupper
  306e45:	call   *0xb6205(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  306e4b:	lea    0xaea0e(%rip),%rdx        # 3b5860 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x120>
  306e52:	mov    %rbx,%rdi
  306e55:	mov    %r10,%rsi
  306e58:	vzeroupper
  306e5b:	call   *0xb61ef(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  306e61:	lea    0xae9e0(%rip),%rdx        # 3b5848 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0x108>
  306e68:	mov    %rbx,%rdi
  306e6b:	mov    %r11,%rsi
  306e6e:	vzeroupper
  306e71:	call   *0xb61d9(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  306e77:	lea    0xae96a(%rip),%rdx        # 3b57e8 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0xa8>
  306e7e:	mov    %r8,%rdi
  306e81:	mov    %r11,%rsi
  306e84:	vzeroupper
  306e87:	call   *0xb61c3(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  306e8d:	lea    0xae96c(%rip),%rdx        # 3b5800 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0xc0>
  306e94:	mov    %r8,%rdi
  306e97:	mov    %r10,%rsi
  306e9a:	vzeroupper
  306e9d:	call   *0xb61ad(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  306ea3:	lea    0xae96e(%rip),%rdx        # 3b5818 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0xd8>
  306eaa:	mov    %r8,%rdi
  306ead:	mov    %rcx,%rsi
  306eb0:	vzeroupper
  306eb3:	call   *0xb6197(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  306eb9:	lea    0xae970(%rip),%rdx        # 3b5830 <anon.57e367dc796540cb2490dff35027e128.74.llvm.9400485801228579583+0xf0>
  306ec0:	mov    %r8,%rdi
  306ec3:	vzeroupper
  306ec6:	call   *0xb6184(%rip)        # 3bd050 <_DYNAMIC+0x2b8>
  306ecc:	int3
  306ecd:	int3
  306ece:	int3
  306ecf:	int3


