
/tmp/rustsht-m6-f32-spin-hemi.2CTgT1jM/target-candidate/release/examples/ducc_f32_full_transform_parity:     file format elf64-x86-64


Disassembly of section .text:

00000000002e59e0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>>:
  2e59e0:	push   %rbp
  2e59e1:	push   %r15
  2e59e3:	push   %r14
  2e59e5:	push   %r13
  2e59e7:	push   %r12
  2e59e9:	push   %rbx
  2e59ea:	sub    $0x408,%rsp
  2e59f1:	vmovss %xmm0,0x6c(%rsp)
  2e59f7:	mov    %r8,0x1f0(%rsp)
  2e59ff:	mov    %rdx,0x58(%rsp)
  2e5a04:	mov    %rdi,0x138(%rsp)
  2e5a0c:	mov    %r9,0x140(%rsp)
  2e5a14:	lea    0x3f(%r9),%rbx
  2e5a18:	shr    $0x6,%rbx
  2e5a1c:	je     2e8268 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2888>
  2e5a22:	mov    %rcx,%r15
  2e5a25:	mov    0x4a0(%rsp),%r10
  2e5a2d:	mov    0x480(%rsp),%r12
  2e5a35:	mov    0x470(%rsp),%rbp
  2e5a3d:	mov    0x440(%rsp),%rdx
  2e5a45:	lea    -0x2af6c6(%rip),%rax        # 36386 <anon.9445595c9a9da21797216ec9ea00a010.58.llvm.9720432591573140778+0x60>
  2e5a4c:	mov    %rax,%rcx
  2e5a4f:	shr    $0x20,%rcx
  2e5a53:	mov    %rcx,0x1e0(%rsp)
  2e5a5b:	shr    $0x8,%eax
  2e5a5e:	mov    %rax,0x1e8(%rsp)
  2e5a66:	mov    %rdx,%rax
  2e5a69:	not    %rax
  2e5a6c:	mov    %rax,0x1d8(%rsp)
  2e5a74:	mov    $0x40,%r13d
  2e5a7a:	movq   $0x0,0x110(%rsp)
  2e5a86:	movq   $0x0,0x108(%rsp)
  2e5a92:	xor    %ecx,%ecx
  2e5a94:	xor    %eax,%eax
  2e5a96:	mov    %r15,0x50(%rsp)
  2e5a9b:	mov    %esi,0x11c(%rsp)
  2e5aa2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  2e5ab0:	mov    %rax,%rdi
  2e5ab3:	mov    0x140(%rsp),%rax
  2e5abb:	cmp    %r13,%rax
  2e5abe:	mov    %r13,%r11
  2e5ac1:	cmovb  %rax,%r11
  2e5ac5:	lea    0x40(%rdi),%r9
  2e5ac9:	cmp    %r9,%rax
  2e5acc:	mov    %r9,0x208(%rsp)
  2e5ad4:	cmovb  %rax,%r9
  2e5ad8:	cmp    %rdi,%rax
  2e5adb:	jb     2e83c2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29e2>
  2e5ae1:	cmp    0x448(%rsp),%r9
  2e5ae9:	ja     2e840a <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2a2a>
  2e5aef:	mov    %r9,%r14
  2e5af2:	sub    %rdi,%r14
  2e5af5:	cmp    0x478(%rsp),%r14
  2e5afd:	ja     2e83dd <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29fd>
  2e5b03:	cmp    0x488(%rsp),%r14
  2e5b0b:	ja     2e8425 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2a45>
  2e5b11:	cmp    0x498(%rsp),%r14
  2e5b19:	ja     2e8442 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2a62>
  2e5b1f:	cmp    0x4a8(%rsp),%r14
  2e5b27:	ja     2e845f <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2a7f>
  2e5b2d:	mov    %rdx,0xb0(%rsp)
  2e5b35:	lea    (%r11,%rcx,1),%rax
  2e5b39:	mov    %rax,0x60(%rsp)
  2e5b3e:	mov    0x1f0(%rsp),%rax
  2e5b46:	lea    (%rax,%rdi,4),%rdx
  2e5b4a:	test   %sil,%sil
  2e5b4d:	mov    %r14,0x18(%rsp)
  2e5b52:	mov    %rdi,0x78(%rsp)
  2e5b57:	mov    %rbx,0x200(%rsp)
  2e5b5f:	mov    %r13,0x1f8(%rsp)
  2e5b67:	mov    %rcx,0x148(%rsp)
  2e5b6f:	je     2e5db0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x3d0>
  2e5b75:	mov    0x440(%rsp),%rax
  2e5b7d:	lea    (%rax,%rdi,4),%rcx
  2e5b81:	movzbl %sil,%eax
  2e5b85:	cmp    $0x1,%eax
  2e5b88:	jne    2e5e60 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x480>
  2e5b8e:	mov    %rcx,0x28(%rsp)
  2e5b93:	mov    %r9,0x90(%rsp)
  2e5b9b:	mov    %rbp,0x210(%rsp)
  2e5ba3:	mov    %r14,0x218(%rsp)
  2e5bab:	mov    %r12,0x220(%rsp)
  2e5bb3:	mov    %r14,0x228(%rsp)
  2e5bbb:	mov    %r10,0x230(%rsp)
  2e5bc3:	mov    %r14,0x238(%rsp)
  2e5bcb:	lea    0x2b8(%rsp),%rdi
  2e5bd3:	mov    0x58(%rsp),%rsi
  2e5bd8:	mov    %r14,%rcx
  2e5bdb:	vmovss 0x6c(%rsp),%xmm0
  2e5be1:	lea    0x210(%rsp),%r8
  2e5be9:	vzeroupper
  2e5bec:	call   2e85e0 <rustsht::legendre::numeric::initialize_scalar_recurrence_lanes::<f32, rustsht::legendre::scalar::scaled_power_f32, rustsht::legendre::scalar::normalize_value_f32>>
  2e5bf1:	cmpl   $0xffffffff,0x2b8(%rsp)
  2e5bf9:	jne    2e5e1c <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x43c>
  2e5bff:	test   %r14,%r14
  2e5c02:	vmovss -0x2b93c2(%rip),%xmm6        # 2c848 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x27d8>
  2e5c0a:	vmovss -0x2b9532(%rip),%xmm7        # 2c6e0 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x2670>
  2e5c12:	mov    %r14,%rdx
  2e5c15:	mov    $0x1,%bl
  2e5c17:	je     2e6165 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x785>
  2e5c1d:	xor    %eax,%eax
  2e5c1f:	mov    0x4a0(%rsp),%r10
  2e5c27:	mov    0x60(%rsp),%r11
  2e5c2c:	mov    0x28(%rsp),%r14
  2e5c31:	jmp    2e5c78 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x298>
  2e5c33:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  2e5c40:	mov    %rcx,%r8
  2e5c43:	inc    %rax
  2e5c46:	test   %r8,%r8
  2e5c49:	sete   %cl
  2e5c4c:	cmp    $0x53800001,%esi
  2e5c52:	setb   %dil
  2e5c56:	add    $0xd4800000,%esi
  2e5c5c:	cmp    $0xd4800001,%esi
  2e5c62:	setb   %sil
  2e5c66:	and    %cl,%dil
  2e5c69:	and    %sil,%dil
  2e5c6c:	and    %dil,%bl
  2e5c6f:	cmp    %rdx,%rax
  2e5c72:	je     2e6177 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x797>
  2e5c78:	mov    0x0(%rbp,%rax,4),%ecx
  2e5c7c:	mov    %ecx,%esi
  2e5c7e:	and    $0x7fffffff,%esi
  2e5c84:	mov    (%r12,%rax,4),%edi
  2e5c88:	mov    %edi,%r8d
  2e5c8b:	and    $0x7fffffff,%r8d
  2e5c92:	cmp    %esi,%r8d
  2e5c95:	cmovbe %esi,%r8d
  2e5c99:	vmovd  %ecx,%xmm1
  2e5c9d:	vmovd  %edi,%xmm0
  2e5ca1:	mov    (%r10,%rax,8),%rdi
  2e5ca5:	cmp    $0x53800001,%r8d
  2e5cac:	jb     2e5d00 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x320>
  2e5cae:	vmulss %xmm6,%xmm1,%xmm1
  2e5cb2:	vmulss %xmm6,%xmm0,%xmm0
  2e5cb6:	add    $0x50,%rdi
  2e5cba:	jo     2e828c <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28ac>
  2e5cc0:	vmovd  %r8d,%xmm2
  2e5cc5:	data16 cs nopw 0x0(%rax,%rax,1)
  2e5cd0:	mov    %rdi,%rcx
  2e5cd3:	vmulss %xmm6,%xmm2,%xmm2
  2e5cd7:	vmovd  %xmm2,%r8d
  2e5cdc:	mov    %r8d,%esi
  2e5cdf:	and    $0x7fffffff,%esi
  2e5ce5:	cmp    $0x53800000,%esi
  2e5ceb:	jbe    2e5d20 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x340>
  2e5ced:	vmulss %xmm6,%xmm1,%xmm1
  2e5cf1:	vmulss %xmm6,%xmm0,%xmm0
  2e5cf5:	add    $0x50,%rdi
  2e5cf9:	jno    2e5cd0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2f0>
  2e5cfb:	jmp    2e827c <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x289c>
  2e5d00:	mov    %rdi,%rcx
  2e5d03:	mov    %r8d,%esi
  2e5d06:	lea    -0x1(%rsi),%edi
  2e5d09:	cmp    $0x2b7ffffe,%edi
  2e5d0f:	ja     2e5c40 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x260>
  2e5d15:	jmp    2e5d3f <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x35f>
  2e5d17:	nopw   0x0(%rax,%rax,1)
  2e5d20:	mov    %rcx,(%r10,%rax,8)
  2e5d24:	vmovss %xmm1,0x0(%rbp,%rax,4)
  2e5d2a:	vmovss %xmm0,(%r12,%rax,4)
  2e5d30:	lea    -0x1(%rsi),%edi
  2e5d33:	cmp    $0x2b7ffffe,%edi
  2e5d39:	ja     2e5c40 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x260>
  2e5d3f:	vmulss %xmm7,%xmm1,%xmm1
  2e5d43:	vmulss %xmm7,%xmm0,%xmm0
  2e5d47:	add    $0xffffffffffffffb0,%rcx
  2e5d4b:	jo     2e828c <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28ac>
  2e5d51:	vmovd  %r8d,%xmm2
  2e5d56:	cs nopw 0x0(%rax,%rax,1)
  2e5d60:	mov    %rcx,%r8
  2e5d63:	vmulss %xmm7,%xmm2,%xmm2
  2e5d67:	vmovd  %xmm2,%esi
  2e5d6b:	and    $0x7fffffff,%esi
  2e5d71:	lea    -0x1(%rsi),%edi
  2e5d74:	cmp    $0x2b7fffff,%edi
  2e5d7a:	jae    2e5d90 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x3b0>
  2e5d7c:	vmulss %xmm7,%xmm1,%xmm1
  2e5d80:	vmulss %xmm7,%xmm0,%xmm0
  2e5d84:	add    $0xffffffffffffffb0,%rcx
  2e5d88:	jno    2e5d60 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x380>
  2e5d8a:	jmp    2e8282 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28a2>
  2e5d8f:	nop
  2e5d90:	mov    %r8,(%r10,%rax,8)
  2e5d94:	vmovss %xmm1,0x0(%rbp,%rax,4)
  2e5d9a:	vmovss %xmm0,(%r12,%rax,4)
  2e5da0:	jmp    2e5c43 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x263>
  2e5da5:	data16 cs nopw 0x0(%rax,%rax,1)
  2e5db0:	mov    %r11,0x300(%rsp)
  2e5db8:	mov    %rbp,0x210(%rsp)
  2e5dc0:	mov    %r14,0x218(%rsp)
  2e5dc8:	mov    %r12,0x220(%rsp)
  2e5dd0:	mov    %r14,0x228(%rsp)
  2e5dd8:	mov    %r10,0x230(%rsp)
  2e5de0:	mov    %r14,0x238(%rsp)
  2e5de8:	lea    0x2b8(%rsp),%rdi
  2e5df0:	mov    0x58(%rsp),%rsi
  2e5df5:	mov    %r14,%rcx
  2e5df8:	vmovss 0x6c(%rsp),%xmm0
  2e5dfe:	lea    0x210(%rsp),%r8
  2e5e06:	vzeroupper
  2e5e09:	call   2e85e0 <rustsht::legendre::numeric::initialize_scalar_recurrence_lanes::<f32, rustsht::legendre::scalar::scaled_power_f32, rustsht::legendre::scalar::normalize_value_f32>>
  2e5e0e:	cmpl   $0xffffffff,0x2b8(%rsp)
  2e5e16:	je     2e5fd6 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x5f6>
  2e5e1c:	mov    0x2d8(%rsp),%rax
  2e5e24:	mov    %rax,0xf0(%rsp)
  2e5e2c:	vmovups 0x2b8(%rsp),%ymm0
  2e5e35:	vmovups %ymm0,0xd0(%rsp)
  2e5e3e:	cmpq   $0xffffffffffffffff,0xd0(%rsp)
  2e5e47:	mov    0x4a0(%rsp),%r10
  2e5e4f:	je     2e5f73 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x593>
  2e5e55:	jmp    2e831a <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x293a>
  2e5e5a:	nopw   0x0(%rax,%rax,1)
  2e5e60:	mov    %rdx,0x210(%rsp)
  2e5e68:	mov    %r14,0x218(%rsp)
  2e5e70:	mov    %rcx,0x220(%rsp)
  2e5e78:	mov    %r14,0x228(%rsp)
  2e5e80:	mov    0x450(%rsp),%rax
  2e5e88:	mov    %rax,0x230(%rsp)
  2e5e90:	mov    0x458(%rsp),%rax
  2e5e98:	mov    %rax,0x238(%rsp)
  2e5ea0:	mov    0x460(%rsp),%rax
  2e5ea8:	mov    %rax,0x240(%rsp)
  2e5eb0:	mov    0x468(%rsp),%rax
  2e5eb8:	mov    %rax,0x248(%rsp)
  2e5ec0:	mov    %rbp,0x250(%rsp)
  2e5ec8:	mov    %r14,0x258(%rsp)
  2e5ed0:	mov    %r12,0x260(%rsp)
  2e5ed8:	mov    %r14,0x268(%rsp)
  2e5ee0:	mov    0x490(%rsp),%rax
  2e5ee8:	mov    %rax,0x270(%rsp)
  2e5ef0:	mov    %r14,0x278(%rsp)
  2e5ef8:	mov    %r10,0x280(%rsp)
  2e5f00:	mov    %r14,0x288(%rsp)
  2e5f08:	mov    0x4b0(%rsp),%rax
  2e5f10:	mov    %rax,0x290(%rsp)
  2e5f18:	mov    %rdi,0x298(%rsp)
  2e5f20:	mov    0x58(%rsp),%rax
  2e5f25:	mov    %rax,0x2a0(%rsp)
  2e5f2d:	mov    %r15,0x2a8(%rsp)
  2e5f35:	vmovss 0x6c(%rsp),%xmm0
  2e5f3b:	vmovss %xmm0,0x2b0(%rsp)
  2e5f44:	lea    0xd0(%rsp),%rdi
  2e5f4c:	lea    0x210(%rsp),%rsi
  2e5f54:	vzeroupper
  2e5f57:	call   2eb350 <<pulp::x86::v4::V4>::vectorize::imp::<<pulp::x86::v4::V4 as pulp::Simd>::vectorize::Impl<rustsht::legendre::scalar_paired::ForEachPairedYlm<f32, rustsht::legendre::scalar_paired::PairedScalarVisitorRef<rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>>>>>
  2e5f5c:	cmpq   $0xffffffffffffffff,0xd0(%rsp)
  2e5f65:	mov    0x4a0(%rsp),%r10
  2e5f6d:	jne    2e831a <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x293a>
  2e5f73:	mov    0x200(%rsp),%rbx
  2e5f7b:	dec    %rbx
  2e5f7e:	mov    0x1f8(%rsp),%r13
  2e5f86:	add    $0x40,%r13
  2e5f8a:	mov    0x148(%rsp),%rcx
  2e5f92:	add    $0xffffffffffffffc0,%rcx
  2e5f96:	incq   0x108(%rsp)
  2e5f9e:	addq   $0x100,0x110(%rsp)
  2e5faa:	mov    0xb0(%rsp),%rdx
  2e5fb2:	add    $0x100,%rdx
  2e5fb9:	test   %rbx,%rbx
  2e5fbc:	mov    0x11c(%rsp),%esi
  2e5fc3:	mov    0x208(%rsp),%rax
  2e5fcb:	jne    2e5ab0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0xd0>
  2e5fd1:	jmp    2e8268 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2888>
  2e5fd6:	test   %r14,%r14
  2e5fd9:	vmovss -0x2b9799(%rip),%xmm12        # 2c848 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x27d8>
  2e5fe1:	vmovss -0x2b9909(%rip),%xmm13        # 2c6e0 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x2670>
  2e5fe9:	mov    %r14,%r8
  2e5fec:	mov    $0x1,%r13b
  2e5fef:	je     2e6228 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x848>
  2e5ff5:	xor    %eax,%eax
  2e5ff7:	mov    0x4a0(%rsp),%r10
  2e5fff:	mov    0x78(%rsp),%r9
  2e6004:	mov    0x60(%rsp),%r11
  2e6009:	jmp    2e6046 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x666>
  2e600b:	nopl   0x0(%rax,%rax,1)
  2e6010:	mov    %rcx,%rdx
  2e6013:	inc    %rax
  2e6016:	test   %rdx,%rdx
  2e6019:	sete   %cl
  2e601c:	cmp    $0x53800001,%esi
  2e6022:	setb   %dl
  2e6025:	add    $0xd4800000,%esi
  2e602b:	cmp    $0xd4800001,%esi
  2e6031:	setb   %sil
  2e6035:	and    %cl,%dl
  2e6037:	and    %sil,%dl
  2e603a:	and    %dl,%r13b
  2e603d:	cmp    %r8,%rax
  2e6040:	jae    2e623a <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x85a>
  2e6046:	mov    0x0(%rbp,%rax,4),%ecx
  2e604a:	mov    %ecx,%esi
  2e604c:	and    $0x7fffffff,%esi
  2e6052:	mov    (%r12,%rax,4),%edi
  2e6056:	mov    %edi,%edx
  2e6058:	and    $0x7fffffff,%edx
  2e605e:	cmp    %esi,%edx
  2e6060:	cmovbe %esi,%edx
  2e6063:	vmovd  %ecx,%xmm1
  2e6067:	vmovd  %edi,%xmm0
  2e606b:	mov    (%r10,%rax,8),%rdi
  2e606f:	cmp    $0x53800001,%edx
  2e6075:	jb     2e60c0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x6e0>
  2e6077:	vmulss %xmm1,%xmm12,%xmm1
  2e607b:	vmulss %xmm0,%xmm12,%xmm0
  2e607f:	add    $0x50,%rdi
  2e6083:	jo     2e828c <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28ac>
  2e6089:	vmovd  %edx,%xmm2
  2e608d:	nopl   (%rax)
  2e6090:	mov    %rdi,%rcx
  2e6093:	vmulss %xmm2,%xmm12,%xmm2
  2e6097:	vmovd  %xmm2,%edx
  2e609b:	mov    %edx,%esi
  2e609d:	and    $0x7fffffff,%esi
  2e60a3:	cmp    $0x53800000,%esi
  2e60a9:	jbe    2e60e0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x700>
  2e60ab:	vmulss %xmm1,%xmm12,%xmm1
  2e60af:	vmulss %xmm0,%xmm12,%xmm0
  2e60b3:	add    $0x50,%rdi
  2e60b7:	jno    2e6090 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x6b0>
  2e60b9:	jmp    2e827c <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x289c>
  2e60be:	xchg   %ax,%ax
  2e60c0:	mov    %rdi,%rcx
  2e60c3:	mov    %edx,%esi
  2e60c5:	lea    -0x1(%rsi),%edi
  2e60c8:	cmp    $0x2b7ffffe,%edi
  2e60ce:	ja     2e6010 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x630>
  2e60d4:	jmp    2e60ff <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x71f>
  2e60d6:	cs nopw 0x0(%rax,%rax,1)
  2e60e0:	mov    %rcx,(%r10,%rax,8)
  2e60e4:	vmovss %xmm1,0x0(%rbp,%rax,4)
  2e60ea:	vmovss %xmm0,(%r12,%rax,4)
  2e60f0:	lea    -0x1(%rsi),%edi
  2e60f3:	cmp    $0x2b7ffffe,%edi
  2e60f9:	ja     2e6010 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x630>
  2e60ff:	vmulss %xmm1,%xmm13,%xmm1
  2e6103:	vmulss %xmm0,%xmm13,%xmm0
  2e6107:	add    $0xffffffffffffffb0,%rcx
  2e610b:	jo     2e828c <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28ac>
  2e6111:	vmovd  %edx,%xmm2
  2e6115:	data16 cs nopw 0x0(%rax,%rax,1)
  2e6120:	mov    %rcx,%rdx
  2e6123:	vmulss %xmm2,%xmm13,%xmm2
  2e6127:	vmovd  %xmm2,%esi
  2e612b:	and    $0x7fffffff,%esi
  2e6131:	lea    -0x1(%rsi),%edi
  2e6134:	cmp    $0x2b7fffff,%edi
  2e613a:	jae    2e6150 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x770>
  2e613c:	vmulss %xmm1,%xmm13,%xmm1
  2e6140:	vmulss %xmm0,%xmm13,%xmm0
  2e6144:	add    $0xffffffffffffffb0,%rcx
  2e6148:	jno    2e6120 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x740>
  2e614a:	jmp    2e8288 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28a8>
  2e614f:	nop
  2e6150:	mov    %rdx,(%r10,%rax,8)
  2e6154:	vmovss %xmm1,0x0(%rbp,%rax,4)
  2e615a:	vmovss %xmm0,(%r12,%rax,4)
  2e6160:	jmp    2e6013 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x633>
  2e6165:	mov    0x4a0(%rsp),%r10
  2e616d:	mov    0x60(%rsp),%r11
  2e6172:	mov    0x28(%rsp),%r14
  2e6177:	cmp    %r15,0x58(%rsp)
  2e617c:	ja     2e5f73 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x593>
  2e6182:	shr    $0x3,%r11
  2e6186:	mov    %r11,0x1b8(%rsp)
  2e618e:	and    $0xfffffffffffffffe,%r11
  2e6192:	mov    0x108(%rsp),%rax
  2e619a:	shl    $0x6,%rax
  2e619e:	mov    0x90(%rsp),%rcx
  2e61a6:	mov    %rcx,%rsi
  2e61a9:	sub    %rax,%rsi
  2e61ac:	shr    $0x3,%rsi
  2e61b0:	mov    %rsi,0x1d0(%rsp)
  2e61b8:	mov    %rdx,%rsi
  2e61bb:	shr    $0x3,%rsi
  2e61bf:	mov    %rdx,%rdi
  2e61c2:	movabs $0x1ffffffffffffff8,%rax
  2e61cc:	and    %rax,%rdi
  2e61cf:	mov    %rdi,0x8(%rsp)
  2e61d4:	xor    %eax,%eax
  2e61d6:	and    $0x7,%rcx
  2e61da:	mov    %rcx,0xb8(%rsp)
  2e61e2:	setne  %al
  2e61e5:	mov    %rsi,0x128(%rsp)
  2e61ed:	add    %rsi,%rax
  2e61f0:	mov    %rax,0x1c0(%rsp)
  2e61f8:	mov    %rbp,%rcx
  2e61fb:	mov    %r12,%r13
  2e61fe:	mov    0x490(%rsp),%rax
  2e6206:	mov    %rax,0x48(%rsp)
  2e620b:	movq   $0x0,0x130(%rsp)
  2e6217:	mov    0x58(%rsp),%rax
  2e621c:	xor    %esi,%esi
  2e621e:	mov    %r11,0x40(%rsp)
  2e6223:	jmp    2e6fa0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x15c0>
  2e6228:	mov    0x4a0(%rsp),%r10
  2e6230:	mov    0x78(%rsp),%r9
  2e6235:	mov    0x60(%rsp),%r11
  2e623a:	cmp    %r15,0x58(%rsp)
  2e623f:	ja     2e5f73 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x593>
  2e6245:	mov    0x300(%rsp),%rcx
  2e624d:	mov    %ecx,%eax
  2e624f:	and    $0x3,%eax
  2e6252:	mov    %r11,%rdx
  2e6255:	sub    %rax,%rdx
  2e6258:	mov    %rdx,0x180(%rsp)
  2e6260:	mov    %rcx,%rax
  2e6263:	and    $0xffffffffffffffe0,%rax
  2e6267:	add    0x148(%rsp),%rax
  2e626f:	mov    %rax,0x170(%rsp)
  2e6277:	mov    0x108(%rsp),%rax
  2e627f:	shl    $0x8,%rax
  2e6283:	neg    %rax
  2e6286:	add    0x1d8(%rsp),%rax
  2e628e:	mov    %rax,0x190(%rsp)
  2e6296:	mov    %ecx,%eax
  2e6298:	and    $0x1f,%eax
  2e629b:	mov    %r11,%rdx
  2e629e:	mov    %rax,0x150(%rsp)
  2e62a6:	sub    %rax,%rdx
  2e62a9:	mov    %rdx,0x160(%rsp)
  2e62b1:	and    $0x3,%ecx
  2e62b4:	mov    %r11,%rax
  2e62b7:	mov    %rcx,0x300(%rsp)
  2e62bf:	sub    %rcx,%rax
  2e62c2:	mov    %rax,0xc0(%rsp)
  2e62ca:	mov    %rbp,%rcx
  2e62cd:	mov    %r12,%r14
  2e62d0:	mov    0x490(%rsp),%rdi
  2e62d8:	xor    %edx,%edx
  2e62da:	mov    0x58(%rsp),%rax
  2e62df:	movq   $0x0,0x2e0(%rsp)
  2e62eb:	jmp    2e6318 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x938>
  2e62ed:	nopl   (%rax)
  2e62f0:	mov    0x80(%rsp),%rsi
  2e62f8:	lea    0x1(%rsi),%rax
  2e62fc:	incq   0x2e0(%rsp)
  2e6304:	mov    $0x1,%edx
  2e6309:	mov    %r14,%rcx
  2e630c:	mov    %rbx,%r14
  2e630f:	cmp    %r15,%rsi
  2e6312:	jae    2e5f73 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x593>
  2e6318:	add    %rax,%rdx
  2e631b:	jb     2e5f73 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x593>
  2e6321:	cmp    %r15,%rdx
  2e6324:	ja     2e5f73 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x593>
  2e632a:	mov    %rdx,0x80(%rsp)
  2e6332:	mov    %rcx,0x38(%rsp)
  2e6337:	mov    %rdi,0x3c0(%rsp)
  2e633f:	mov    0x4b0(%rsp),%rax
  2e6347:	mov    0x58(%rax),%rax
  2e634b:	mov    %rax,0x1a0(%rsp)
  2e6353:	cmpb   $0x1,(%rax)
  2e6356:	jne    2e6b0f <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x112f>
  2e635c:	mov    0x80(%rsp),%rdi
  2e6364:	mov    0x4b0(%rsp),%rax
  2e636c:	sub    0x60(%rax),%rdi
  2e6370:	shr    $1,%rdi
  2e6373:	mov    0x18(%rax),%rsi
  2e6377:	cmp    %rsi,%rdi
  2e637a:	jae    2e8593 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2bb3>
  2e6380:	mov    0x28(%rax),%rsi
  2e6384:	cmp    %rsi,%rdi
  2e6387:	jae    2e85a3 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2bc3>
  2e638d:	mov    0x38(%rax),%rsi
  2e6391:	cmp    %rsi,%rdi
  2e6394:	jae    2e85b3 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2bd3>
  2e639a:	mov    0x48(%rax),%rsi
  2e639e:	cmp    %rsi,%rdi
  2e63a1:	jae    2e85c3 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2be3>
  2e63a7:	test   %r8,%r8
  2e63aa:	je     2e6b0f <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x112f>
  2e63b0:	mov    0x4b0(%rsp),%rdx
  2e63b8:	mov    0x10(%rdx),%rax
  2e63bc:	vmovss (%rax,%rdi,8),%xmm0
  2e63c1:	vmovss %xmm0,0xa8(%rsp)
  2e63ca:	vmovss 0x4(%rax,%rdi,8),%xmm0
  2e63d0:	vmovss %xmm0,0x30(%rsp)
  2e63d6:	mov    0x20(%rdx),%rax
  2e63da:	vmovss (%rax,%rdi,8),%xmm0
  2e63df:	vmovss %xmm0,0x28(%rsp)
  2e63e5:	vmovss 0x4(%rax,%rdi,8),%xmm0
  2e63eb:	vmovss %xmm0,0xa0(%rsp)
  2e63f4:	mov    0x30(%rdx),%rax
  2e63f8:	mov    0x40(%rdx),%rcx
  2e63fc:	vmovss (%rax,%rdi,8),%xmm0
  2e6401:	vmovss %xmm0,0x98(%rsp)
  2e640a:	vmovss 0x4(%rax,%rdi,8),%xmm0
  2e6410:	vmovss %xmm0,0x90(%rsp)
  2e6419:	vmovss (%rcx,%rdi,8),%xmm0
  2e641e:	vmovss %xmm0,0x40(%rsp)
  2e6424:	vmovss 0x4(%rcx,%rdi,8),%xmm0
  2e642a:	vmovss %xmm0,0x88(%rsp)
  2e6433:	mov    (%rdx),%rax
  2e6436:	mov    %rax,0x3e0(%rsp)
  2e643e:	mov    0x8(%rdx),%rax
  2e6442:	mov    %rax,0x340(%rsp)
  2e644a:	mov    $0x1,%edx
  2e644f:	movq   $0x0,0x380(%rsp)
  2e645b:	mov    0x110(%rsp),%rdi
  2e6463:	mov    %r9,0xc8(%rsp)
  2e646b:	mov    %r14,0x20(%rsp)
  2e6470:	movq   $0x0,0x360(%rsp)
  2e647c:	mov    %r10,(%rsp)
  2e6480:	mov    %r8,%rcx
  2e6483:	xor    %eax,%eax
  2e6485:	data16 cs nopw 0x0(%rax,%rax,1)
  2e6490:	mov    %rcx,0x100(%rsp)
  2e6498:	cmp    %r11,%rdx
  2e649b:	mov    %r11,%rcx
  2e649e:	cmovb  %rdx,%rcx
  2e64a2:	mov    %rcx,0x70(%rsp)
  2e64a7:	mov    %r11,%rcx
  2e64aa:	cmovb  %rdx,%rcx
  2e64ae:	lea    0x1(%rax),%r15
  2e64b2:	cmp    %r15,%r8
  2e64b5:	mov    %r15,%rsi
  2e64b8:	cmovb  %r8,%rsi
  2e64bc:	cmp    %rax,%r8
  2e64bf:	jb     2e84ac <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2acc>
  2e64c5:	mov    %r15,0x48(%rsp)
  2e64ca:	mov    %rdx,0xf8(%rsp)
  2e64d2:	test   $0x1,%r13b
  2e64d6:	mov    %rdi,0x10(%rsp)
  2e64db:	jne    2e6530 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0xb50>
  2e64dd:	cmp    %rax,%r8
  2e64e0:	je     2e6530 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0xb50>
  2e64e2:	mov    0x70(%rsp),%rdx
  2e64e7:	add    0x380(%rsp),%rdx
  2e64ef:	mov    %rdx,0x70(%rsp)
  2e64f4:	mov    0x360(%rsp),%rdx
  2e64fc:	lea    (%rdx,%rcx,8),%rcx
  2e6500:	xor    %edx,%edx
  2e6502:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  2e6510:	mov    (%rsp),%r15
  2e6514:	cmpq   $0x0,(%r15,%rdx,1)
  2e6519:	jne    2e6729 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0xd49>
  2e651f:	add    $0x8,%rdx
  2e6523:	cmp    %rdx,%rcx
  2e6526:	jne    2e6510 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0xb30>
  2e6528:	nopl   0x0(%rax,%rax,1)
  2e6530:	lea    (%rax,%r9,1),%rdi
  2e6534:	add    %r9,%rsi
  2e6537:	cmp    0x340(%rsp),%rsi
  2e653f:	ja     2e847c <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2a9c>
  2e6545:	mov    0x4b0(%rsp),%rcx
  2e654d:	mov    0x50(%rcx),%rcx
  2e6551:	mov    0x8(%rcx),%rdx
  2e6555:	cmp    %rdx,%rsi
  2e6558:	ja     2e8392 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29b2>
  2e655e:	mov    0x18(%rcx),%rdx
  2e6562:	cmp    %rdx,%rsi
  2e6565:	ja     2e83a2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29c2>
  2e656b:	vmovss (%r14,%rax,4),%xmm0
  2e6571:	mov    0x3e0(%rsp),%rax
  2e6579:	vmovss (%rax,%rdi,4),%xmm1
  2e657e:	mov    (%rcx),%rax
  2e6581:	mov    0x10(%rcx),%rdx
  2e6585:	vmovss (%rax,%rdi,4),%xmm3
  2e658a:	vfmadd231ss 0xa8(%rsp),%xmm0,%xmm3
  2e6594:	vmovss (%rdx,%rdi,4),%xmm2
  2e6599:	vmovss %xmm3,(%rax,%rdi,4)
  2e659e:	mov    0x18(%rcx),%rdx
  2e65a2:	cmp    %rdx,%rsi
  2e65a5:	ja     2e83b2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29d2>
  2e65ab:	vfmadd231ss 0x30(%rsp),%xmm0,%xmm2
  2e65b2:	mov    0x10(%rcx),%rax
  2e65b6:	vmovss %xmm2,(%rax,%rdi,4)
  2e65bb:	mov    0x28(%rcx),%rdx
  2e65bf:	cmp    %rdx,%rsi
  2e65c2:	ja     2e8392 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29b2>
  2e65c8:	mov    0x38(%rcx),%rdx
  2e65cc:	cmp    %rdx,%rsi
  2e65cf:	ja     2e83a2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29c2>
  2e65d5:	vmulss 0x28(%rsp),%xmm1,%xmm3
  2e65db:	mov    0x20(%rcx),%rax
  2e65df:	mov    0x30(%rcx),%rdx
  2e65e3:	vfmadd213ss (%rax,%rdi,4),%xmm0,%xmm3
  2e65e9:	vmovss (%rdx,%rdi,4),%xmm2
  2e65ee:	vmovss %xmm3,(%rax,%rdi,4)
  2e65f3:	mov    0x38(%rcx),%rdx
  2e65f7:	cmp    %rdx,%rsi
  2e65fa:	ja     2e83b2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29d2>
  2e6600:	vmulss 0xa0(%rsp),%xmm1,%xmm3
  2e6609:	vfmadd213ss %xmm2,%xmm0,%xmm3
  2e660e:	mov    0x30(%rcx),%rax
  2e6612:	vmovss %xmm3,(%rax,%rdi,4)
  2e6617:	mov    0x48(%rcx),%rdx
  2e661b:	cmp    %rdx,%rsi
  2e661e:	ja     2e8392 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29b2>
  2e6624:	mov    0x58(%rcx),%rdx
  2e6628:	cmp    %rdx,%rsi
  2e662b:	ja     2e83a2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29c2>
  2e6631:	mov    0x40(%rcx),%rax
  2e6635:	mov    0x50(%rcx),%rdx
  2e6639:	vmovss (%rax,%rdi,4),%xmm3
  2e663e:	vfmadd231ss 0x98(%rsp),%xmm0,%xmm3
  2e6648:	vmovss (%rdx,%rdi,4),%xmm2
  2e664d:	vmovss %xmm3,(%rax,%rdi,4)
  2e6652:	mov    0x58(%rcx),%rdx
  2e6656:	cmp    %rdx,%rsi
  2e6659:	ja     2e83b2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29d2>
  2e665f:	vfmadd231ss 0x90(%rsp),%xmm0,%xmm2
  2e6669:	mov    0x50(%rcx),%rax
  2e666d:	vmovss %xmm2,(%rax,%rdi,4)
  2e6672:	mov    0x68(%rcx),%rdx
  2e6676:	cmp    %rdx,%rsi
  2e6679:	ja     2e8392 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29b2>
  2e667f:	mov    0x78(%rcx),%rdx
  2e6683:	cmp    %rdx,%rsi
  2e6686:	ja     2e83a2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29c2>
  2e668c:	vmulss 0x40(%rsp),%xmm1,%xmm3
  2e6692:	mov    0x60(%rcx),%rax
  2e6696:	mov    0x70(%rcx),%rdx
  2e669a:	vfmadd213ss (%rax,%rdi,4),%xmm0,%xmm3
  2e66a0:	vmovss (%rdx,%rdi,4),%xmm2
  2e66a5:	vmovss %xmm3,(%rax,%rdi,4)
  2e66aa:	mov    0x78(%rcx),%rdx
  2e66ae:	cmp    %rdx,%rsi
  2e66b1:	ja     2e83b2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29d2>
  2e66b7:	vmulss 0x88(%rsp),%xmm1,%xmm1
  2e66c0:	vfmadd213ss %xmm2,%xmm0,%xmm1
  2e66c5:	mov    0x70(%rcx),%rax
  2e66c9:	vmovss %xmm1,(%rax,%rdi,4)
  2e66ce:	mov    0x10(%rsp),%rdi
  2e66d3:	mov    0x100(%rsp),%rcx
  2e66db:	dec    %rcx
  2e66de:	mov    0xf8(%rsp),%rdx
  2e66e6:	inc    %rdx
  2e66e9:	addq   $0x8,(%rsp)
  2e66ee:	addq   $0xfffffffffffffff8,0x360(%rsp)
  2e66f7:	addq   $0x4,0x20(%rsp)
  2e66fd:	incq   0xc8(%rsp)
  2e6705:	add    $0x4,%rdi
  2e6709:	decq   0x380(%rsp)
  2e6711:	mov    0x48(%rsp),%rax
  2e6716:	test   %rcx,%rcx
  2e6719:	mov    0x50(%rsp),%r15
  2e671e:	jne    2e6490 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0xab0>
  2e6724:	jmp    2e6b0f <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x112f>
  2e6729:	xor    %r15d,%r15d
  2e672c:	mov    %r14,0x320(%rsp)
  2e6734:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  2e6740:	mov    0xc8(%rsp),%rax
  2e6748:	lea    (%rax,%r15,1),%rbx
  2e674c:	mov    0x4b0(%rsp),%rax
  2e6754:	mov    0x8(%rax),%rbp
  2e6758:	mov    0x50(%rax),%r12
  2e675c:	mov    (%rax),%r14
  2e675f:	add    %rdi,%r14
  2e6762:	mov    0x20(%rsp),%rax
  2e6767:	vmovss (%rax,%r15,4),%xmm2
  2e676d:	mov    (%rsp),%rax
  2e6771:	mov    (%rax,%r15,8),%rdi
  2e6775:	vmovss 0xa8(%rsp),%xmm0
  2e677e:	vmovss 0x30(%rsp),%xmm1
  2e6784:	vzeroupper
  2e6787:	call   *0x9fb63(%rip)        # 3862f0 <_DYNAMIC+0xb48>
  2e678d:	mov    0x8(%r12),%rsi
  2e6792:	cmp    %rsi,%rbx
  2e6795:	jae    2e84e2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b02>
  2e679b:	mov    0x18(%r12),%rsi
  2e67a0:	cmp    %rsi,%rbx
  2e67a3:	jae    2e84d2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2af2>
  2e67a9:	mov    (%r12),%rax
  2e67ad:	mov    0x10(%rsp),%rdi
  2e67b2:	add    %rdi,%rax
  2e67b5:	vaddss (%rax,%r15,4),%xmm0,%xmm2
  2e67bb:	mov    0x10(%r12),%rcx
  2e67c0:	add    %rdi,%rcx
  2e67c3:	vaddss (%rcx,%r15,4),%xmm1,%xmm0
  2e67c9:	vmovd  %xmm0,%ecx
  2e67cd:	vmovd  %xmm2,%edx
  2e67d1:	add    %edx,%edx
  2e67d3:	add    %ecx,%ecx
  2e67d5:	cmp    $0xff000000,%ecx
  2e67db:	setb   %cl
  2e67de:	cmp    $0xfeffffff,%edx
  2e67e4:	mov    0x4a0(%rsp),%r10
  2e67ec:	vmovss -0x2b9fac(%rip),%xmm12        # 2c848 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x27d8>
  2e67f4:	vmovss -0x2ba11c(%rip),%xmm13        # 2c6e0 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x2670>
  2e67fc:	mov    0x18(%rsp),%r8
  2e6801:	ja     2e6add <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x10fd>
  2e6807:	test   %cl,%cl
  2e6809:	je     2e6add <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x10fd>
  2e680f:	vmovss %xmm2,(%rax,%r15,4)
  2e6815:	mov    0x18(%r12),%rsi
  2e681a:	cmp    %rsi,%rbx
  2e681d:	jae    2e84f2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b12>
  2e6823:	mov    0x10(%r12),%rax
  2e6828:	add    %rdi,%rax
  2e682b:	vmovss %xmm0,(%rax,%r15,4)
  2e6831:	cmp    %rbp,%rbx
  2e6834:	jae    2e8532 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b52>
  2e683a:	vmovss (%r14,%r15,4),%xmm0
  2e6840:	vmulss 0xa0(%rsp),%xmm0,%xmm1
  2e6849:	vmulss 0x28(%rsp),%xmm0,%xmm0
  2e684f:	mov    0x20(%rsp),%rax
  2e6854:	vmovss (%rax,%r15,4),%xmm2
  2e685a:	mov    (%rsp),%rax
  2e685e:	mov    (%rax,%r15,8),%rdi
  2e6862:	call   *0x9fa88(%rip)        # 3862f0 <_DYNAMIC+0xb48>
  2e6868:	mov    0x28(%r12),%rsi
  2e686d:	cmp    %rsi,%rbx
  2e6870:	jae    2e84e2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b02>
  2e6876:	mov    0x38(%r12),%rsi
  2e687b:	cmp    %rsi,%rbx
  2e687e:	jae    2e84d2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2af2>
  2e6884:	mov    0x20(%r12),%rax
  2e6889:	mov    0x10(%rsp),%rdi
  2e688e:	add    %rdi,%rax
  2e6891:	vaddss (%rax,%r15,4),%xmm0,%xmm2
  2e6897:	mov    0x30(%r12),%rcx
  2e689c:	add    %rdi,%rcx
  2e689f:	vaddss (%rcx,%r15,4),%xmm1,%xmm0
  2e68a5:	vmovd  %xmm0,%ecx
  2e68a9:	vmovd  %xmm2,%edx
  2e68ad:	add    %edx,%edx
  2e68af:	add    %ecx,%ecx
  2e68b1:	cmp    $0xff000000,%ecx
  2e68b7:	setb   %cl
  2e68ba:	cmp    $0xfeffffff,%edx
  2e68c0:	mov    0x4a0(%rsp),%r10
  2e68c8:	vmovss -0x2ba088(%rip),%xmm12        # 2c848 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x27d8>
  2e68d0:	vmovss -0x2ba1f8(%rip),%xmm13        # 2c6e0 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x2670>
  2e68d8:	mov    0x18(%rsp),%r8
  2e68dd:	ja     2e6add <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x10fd>
  2e68e3:	test   %cl,%cl
  2e68e5:	je     2e6add <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x10fd>
  2e68eb:	vmovss %xmm2,(%rax,%r15,4)
  2e68f1:	mov    0x38(%r12),%rsi
  2e68f6:	cmp    %rsi,%rbx
  2e68f9:	jae    2e84f2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b12>
  2e68ff:	mov    0x30(%r12),%rax
  2e6904:	add    %rdi,%rax
  2e6907:	vmovss %xmm0,(%rax,%r15,4)
  2e690d:	mov    0x20(%rsp),%rax
  2e6912:	vmovss (%rax,%r15,4),%xmm2
  2e6918:	mov    (%rsp),%rax
  2e691c:	mov    (%rax,%r15,8),%rdi
  2e6920:	vmovss 0x98(%rsp),%xmm0
  2e6929:	vmovss 0x90(%rsp),%xmm1
  2e6932:	call   *0x9f9b8(%rip)        # 3862f0 <_DYNAMIC+0xb48>
  2e6938:	mov    0x48(%r12),%rsi
  2e693d:	cmp    %rsi,%rbx
  2e6940:	jae    2e84e2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b02>
  2e6946:	mov    0x58(%r12),%rsi
  2e694b:	cmp    %rsi,%rbx
  2e694e:	jae    2e84d2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2af2>
  2e6954:	mov    0x40(%r12),%rax
  2e6959:	mov    0x10(%rsp),%rdi
  2e695e:	add    %rdi,%rax
  2e6961:	vaddss (%rax,%r15,4),%xmm0,%xmm2
  2e6967:	mov    0x50(%r12),%rcx
  2e696c:	add    %rdi,%rcx
  2e696f:	vaddss (%rcx,%r15,4),%xmm1,%xmm0
  2e6975:	vmovd  %xmm0,%ecx
  2e6979:	vmovd  %xmm2,%edx
  2e697d:	add    %edx,%edx
  2e697f:	add    %ecx,%ecx
  2e6981:	cmp    $0xff000000,%ecx
  2e6987:	setb   %cl
  2e698a:	cmp    $0xfeffffff,%edx
  2e6990:	mov    0x4a0(%rsp),%r10
  2e6998:	vmovss -0x2ba158(%rip),%xmm12        # 2c848 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x27d8>
  2e69a0:	vmovss -0x2ba2c8(%rip),%xmm13        # 2c6e0 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x2670>
  2e69a8:	mov    0x18(%rsp),%r8
  2e69ad:	ja     2e6add <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x10fd>
  2e69b3:	test   %cl,%cl
  2e69b5:	je     2e6add <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x10fd>
  2e69bb:	vmovss %xmm2,(%rax,%r15,4)
  2e69c1:	mov    0x58(%r12),%rsi
  2e69c6:	cmp    %rsi,%rbx
  2e69c9:	jae    2e84f2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b12>
  2e69cf:	mov    0x50(%r12),%rax
  2e69d4:	add    %rdi,%rax
  2e69d7:	vmovss %xmm0,(%rax,%r15,4)
  2e69dd:	vmovss (%r14,%r15,4),%xmm0
  2e69e3:	vmulss 0x88(%rsp),%xmm0,%xmm1
  2e69ec:	vmulss 0x40(%rsp),%xmm0,%xmm0
  2e69f2:	mov    0x20(%rsp),%rax
  2e69f7:	vmovss (%rax,%r15,4),%xmm2
  2e69fd:	mov    (%rsp),%rax
  2e6a01:	mov    (%rax,%r15,8),%rdi
  2e6a05:	call   *0x9f8e5(%rip)        # 3862f0 <_DYNAMIC+0xb48>
  2e6a0b:	mov    0x68(%r12),%rsi
  2e6a10:	cmp    %rsi,%rbx
  2e6a13:	jae    2e84e2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b02>
  2e6a19:	mov    0x78(%r12),%rsi
  2e6a1e:	cmp    %rsi,%rbx
  2e6a21:	jae    2e84d2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2af2>
  2e6a27:	mov    0x60(%r12),%rax
  2e6a2c:	mov    0x10(%rsp),%rdi
  2e6a31:	add    %rdi,%rax
  2e6a34:	vaddss (%rax,%r15,4),%xmm0,%xmm2
  2e6a3a:	mov    0x70(%r12),%rcx
  2e6a3f:	add    %rdi,%rcx
  2e6a42:	vaddss (%rcx,%r15,4),%xmm1,%xmm0
  2e6a48:	vmovd  %xmm0,%ecx
  2e6a4c:	vmovd  %xmm2,%edx
  2e6a50:	add    %edx,%edx
  2e6a52:	add    %ecx,%ecx
  2e6a54:	cmp    $0xff000000,%ecx
  2e6a5a:	setb   %cl
  2e6a5d:	cmp    $0xfeffffff,%edx
  2e6a63:	mov    0x4a0(%rsp),%r10
  2e6a6b:	vmovss -0x2ba22b(%rip),%xmm12        # 2c848 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x27d8>
  2e6a73:	vmovss -0x2ba39b(%rip),%xmm13        # 2c6e0 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x2670>
  2e6a7b:	mov    0x18(%rsp),%r8
  2e6a80:	ja     2e6add <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x10fd>
  2e6a82:	test   %cl,%cl
  2e6a84:	je     2e6add <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x10fd>
  2e6a86:	vmovss %xmm2,(%rax,%r15,4)
  2e6a8c:	mov    0x78(%r12),%rsi
  2e6a91:	cmp    %rsi,%rbx
  2e6a94:	jae    2e84f2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b12>
  2e6a9a:	mov    0x70(%r12),%rax
  2e6a9f:	add    %rdi,%rax
  2e6aa2:	vmovss %xmm0,(%rax,%r15,4)
  2e6aa8:	inc    %r15
  2e6aab:	cmp    %r15,0x70(%rsp)
  2e6ab0:	mov    0x480(%rsp),%r12
  2e6ab8:	mov    0x470(%rsp),%rbp
  2e6ac0:	mov    0x78(%rsp),%r9
  2e6ac5:	mov    0x60(%rsp),%r11
  2e6aca:	mov    0x320(%rsp),%r14
  2e6ad2:	jne    2e6740 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0xd60>
  2e6ad8:	jmp    2e66d3 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0xcf3>
  2e6add:	mov    0x1a0(%rsp),%rax
  2e6ae5:	movb   $0x0,(%rax)
  2e6ae8:	mov    0x480(%rsp),%r12
  2e6af0:	mov    0x470(%rsp),%rbp
  2e6af8:	mov    0x50(%rsp),%r15
  2e6afd:	mov    0x78(%rsp),%r9
  2e6b02:	mov    0x60(%rsp),%r11
  2e6b07:	mov    0x320(%rsp),%r14
  2e6b0f:	mov    0x80(%rsp),%rax
  2e6b17:	add    $0x2,%rax
  2e6b1b:	cmp    %r15,%rax
  2e6b1e:	mov    0x3c0(%rsp),%rbx
  2e6b26:	mov    0x38(%rsp),%rdi
  2e6b2b:	ja     2e5f73 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x593>
  2e6b31:	mov    0x2e0(%rsp),%rax
  2e6b39:	cmp    0x458(%rsp),%rax
  2e6b41:	je     2e8545 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b65>
  2e6b47:	cmp    0x468(%rsp),%rax
  2e6b4f:	mov    $0x7fffffff,%esi
  2e6b54:	je     2e8560 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b80>
  2e6b5a:	test   %r8,%r8
  2e6b5d:	mov    0xb0(%rsp),%rdx
  2e6b65:	je     2e6d47 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1367>
  2e6b6b:	mov    0x450(%rsp),%rax
  2e6b73:	mov    0x2e0(%rsp),%rcx
  2e6b7b:	vmovss (%rax,%rcx,4),%xmm0
  2e6b80:	mov    0x460(%rsp),%rax
  2e6b88:	vmovss (%rax,%rcx,4),%xmm1
  2e6b8d:	cmp    $0x4,%r11
  2e6b91:	jae    2e6b9a <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x11ba>
  2e6b93:	xor    %eax,%eax
  2e6b95:	jmp    2e6d20 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1340>
  2e6b9a:	mov    0x190(%rsp),%rax
  2e6ba2:	add    %rbx,%rax
  2e6ba5:	cmp    $0x7f,%rax
  2e6ba9:	setb   %al
  2e6bac:	mov    %r14,%rcx
  2e6baf:	sub    %rbx,%rcx
  2e6bb2:	cmp    $0xffffffffffffff81,%rcx
  2e6bb6:	setae  %cl
  2e6bb9:	mov    %rdi,%rdx
  2e6bbc:	sub    %rbx,%rdx
  2e6bbf:	cmp    $0xffffffffffffff81,%rdx
  2e6bc3:	setae  %dl
  2e6bc6:	or     %cl,%dl
  2e6bc8:	or     %al,%dl
  2e6bca:	je     2e6bdb <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x11fb>
  2e6bcc:	xor    %eax,%eax
  2e6bce:	mov    0xb0(%rsp),%rdx
  2e6bd6:	jmp    2e6d20 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1340>
  2e6bdb:	cmp    $0x20,%r11
  2e6bdf:	mov    0xb0(%rsp),%rdx
  2e6be7:	jae    2e6bf0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1210>
  2e6be9:	xor    %ecx,%ecx
  2e6beb:	jmp    2e6cc9 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x12e9>
  2e6bf0:	vbroadcastss %xmm0,%ymm2
  2e6bf5:	vbroadcastss %xmm1,%ymm3
  2e6bfa:	xor    %eax,%eax
  2e6bfc:	mov    0x170(%rsp),%rcx
  2e6c04:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  2e6c10:	vmovups (%rdx,%rax,4),%ymm4
  2e6c15:	vmovups 0x20(%rdx,%rax,4),%ymm5
  2e6c1b:	vmovups 0x40(%rdx,%rax,4),%ymm6
  2e6c21:	vmovups 0x60(%rdx,%rax,4),%ymm7
  2e6c27:	vmulps %ymm4,%ymm4,%ymm4
  2e6c2b:	vmulps %ymm5,%ymm5,%ymm5
  2e6c2f:	vmulps %ymm6,%ymm6,%ymm6
  2e6c33:	vmulps %ymm7,%ymm7,%ymm7
  2e6c37:	vfmadd213ps %ymm3,%ymm2,%ymm4
  2e6c3c:	vfmadd213ps %ymm3,%ymm2,%ymm5
  2e6c41:	vfmadd213ps %ymm3,%ymm2,%ymm6
  2e6c46:	vfmadd213ps %ymm3,%ymm2,%ymm7
  2e6c4b:	vmovups (%r14,%rax,4),%ymm8
  2e6c51:	vmovups 0x20(%r14,%rax,4),%ymm9
  2e6c58:	vmovups 0x40(%r14,%rax,4),%ymm10
  2e6c5f:	vmovups 0x60(%r14,%rax,4),%ymm11
  2e6c66:	vfmadd213ps (%rdi,%rax,4),%ymm4,%ymm8
  2e6c6c:	vfmadd213ps 0x20(%rdi,%rax,4),%ymm5,%ymm9
  2e6c73:	vfmadd213ps 0x40(%rdi,%rax,4),%ymm6,%ymm10
  2e6c7a:	vfmadd213ps 0x60(%rdi,%rax,4),%ymm7,%ymm11
  2e6c81:	vmovups %ymm8,(%rbx,%rax,4)
  2e6c86:	vmovups %ymm9,0x20(%rbx,%rax,4)
  2e6c8c:	vmovups %ymm10,0x40(%rbx,%rax,4)
  2e6c92:	vmovups %ymm11,0x60(%rbx,%rax,4)
  2e6c98:	add    $0x20,%rax
  2e6c9c:	cmp    %rax,%rcx
  2e6c9f:	jne    2e6c10 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1230>
  2e6ca5:	cmpq   $0x0,0x150(%rsp)
  2e6cae:	je     2e6d47 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1367>
  2e6cb4:	mov    0x160(%rsp),%rax
  2e6cbc:	mov    %rax,%rcx
  2e6cbf:	cmpl   $0x4,0x150(%rsp)
  2e6cc7:	jb     2e6d20 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1340>
  2e6cc9:	vbroadcastss %xmm0,%xmm2
  2e6cce:	vbroadcastss %xmm1,%xmm3
  2e6cd3:	mov    0x180(%rsp),%rax
  2e6cdb:	nopl   0x0(%rax,%rax,1)
  2e6ce0:	vmovups (%rdx,%rcx,4),%xmm4
  2e6ce5:	vmulps %xmm4,%xmm4,%xmm4
  2e6ce9:	vfmadd213ps %xmm3,%xmm2,%xmm4
  2e6cee:	vmovups (%r14,%rcx,4),%xmm5
  2e6cf4:	vfmadd213ps (%rdi,%rcx,4),%xmm4,%xmm5
  2e6cfa:	vmovups %xmm5,(%rbx,%rcx,4)
  2e6cff:	add    $0x4,%rcx
  2e6d03:	cmp    %rcx,%rax
  2e6d06:	jne    2e6ce0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1300>
  2e6d08:	mov    0xc0(%rsp),%rax
  2e6d10:	cmpq   $0x0,0x300(%rsp)
  2e6d19:	je     2e6d47 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1367>
  2e6d1b:	nopl   0x0(%rax,%rax,1)
  2e6d20:	vmovss (%rdx,%rax,4),%xmm2
  2e6d25:	vmulss %xmm2,%xmm2,%xmm2
  2e6d29:	vfmadd213ss %xmm1,%xmm0,%xmm2
  2e6d2e:	vmovss (%r14,%rax,4),%xmm3
  2e6d34:	vfmadd213ss (%rdi,%rax,4),%xmm2,%xmm3
  2e6d3a:	vmovss %xmm3,(%rbx,%rax,4)
  2e6d3f:	inc    %rax
  2e6d42:	cmp    %r8,%rax
  2e6d45:	jb     2e6d20 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1340>
  2e6d47:	test   $0x1,%r13b
  2e6d4b:	je     2e6de0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1400>
  2e6d51:	mov    $0x1,%r13b
  2e6d54:	test   %r11,%r11
  2e6d57:	je     2e62f0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x910>
  2e6d5d:	xor    %eax,%eax
  2e6d5f:	nop
  2e6d60:	mov    (%r14,%rax,4),%ecx
  2e6d64:	and    %esi,%ecx
  2e6d66:	vmovd  %ecx,%xmm0
  2e6d6a:	mov    (%rbx,%rax,4),%ecx
  2e6d6d:	and    %esi,%ecx
  2e6d6f:	vmovd  %ecx,%xmm1
  2e6d73:	vmaxss %xmm1,%xmm0,%xmm2
  2e6d77:	vcmpunordss %xmm1,%xmm1,%xmm3
  2e6d7c:	vblendvps %xmm3,%xmm0,%xmm2,%xmm2
  2e6d82:	vcmpordss %xmm1,%xmm1,%xmm3
  2e6d87:	vblendvps %xmm3,%xmm2,%xmm0,%xmm2
  2e6d8d:	vcmpordss %xmm0,%xmm0,%xmm0
  2e6d92:	vblendvps %xmm0,%xmm2,%xmm1,%xmm0
  2e6d98:	vmovss -0x2ba690(%rip),%xmm1        # 2c710 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x26a0>
  2e6da0:	vucomiss %xmm0,%xmm1
  2e6da4:	vcmpltss -0x2ba495(%rip),%xmm0,%xmm1        # 2c918 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28a8>
  2e6dad:	jb     2e6de0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1400>
  2e6daf:	vxorps %xmm2,%xmm2,%xmm2
  2e6db3:	vcmpneqss %xmm2,%xmm0,%xmm0
  2e6db8:	vandps %xmm1,%xmm0,%xmm0
  2e6dbc:	vmovd  %xmm0,%ecx
  2e6dc0:	test   $0x1,%cl
  2e6dc3:	jne    2e6de0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1400>
  2e6dc5:	inc    %rax
  2e6dc8:	cmp    %rax,%r11
  2e6dcb:	jne    2e6d60 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1380>
  2e6dcd:	jmp    2e62f0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x910>
  2e6dd2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  2e6de0:	mov    $0x1,%r13b
  2e6de3:	test   %r8,%r8
  2e6de6:	je     2e62f0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x910>
  2e6dec:	xor    %eax,%eax
  2e6dee:	jmp    2e6e3b <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x145b>
  2e6df0:	mov    %rcx,(%r10,%rax,8)
  2e6df4:	vmovss %xmm0,(%r14,%rax,4)
  2e6dfa:	vmovss %xmm1,(%rbx,%rax,4)
  2e6dff:	mov    0x38(%rsp),%rdi
  2e6e04:	cmpq   $0x0,(%r10,%rax,8)
  2e6e09:	lea    0x1(%rax),%rax
  2e6e0d:	sete   %cl
  2e6e10:	cmp    $0x53800001,%edx
  2e6e16:	setb   %sil
  2e6e1a:	add    $0xd4800000,%edx
  2e6e20:	cmp    $0xd4800001,%edx
  2e6e26:	setb   %dl
  2e6e29:	and    %cl,%sil
  2e6e2c:	and    %dl,%sil
  2e6e2f:	and    %sil,%r13b
  2e6e32:	cmp    %r8,%rax
  2e6e35:	jae    2e62f0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x910>
  2e6e3b:	mov    (%r14,%rax,4),%edx
  2e6e3f:	vmovd  %edx,%xmm0
  2e6e43:	and    $0x7fffffff,%edx
  2e6e49:	mov    (%rbx,%rax,4),%ecx
  2e6e4c:	vmovd  %ecx,%xmm1
  2e6e50:	and    $0x7fffffff,%ecx
  2e6e56:	cmp    %edx,%ecx
  2e6e58:	cmovbe %edx,%ecx
  2e6e5b:	cmp    $0x53800001,%ecx
  2e6e61:	jb     2e6eb0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x14d0>
  2e6e63:	mov    (%r10,%rax,8),%rsi
  2e6e67:	vmulss %xmm0,%xmm12,%xmm0
  2e6e6b:	vmulss %xmm1,%xmm12,%xmm1
  2e6e6f:	add    $0x50,%rsi
  2e6e73:	jo     2e82c0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28e0>
  2e6e79:	vmovd  %ecx,%xmm2
  2e6e7d:	nopl   (%rax)
  2e6e80:	mov    %rsi,%rdi
  2e6e83:	vmulss %xmm2,%xmm12,%xmm2
  2e6e87:	vmovd  %xmm2,%ecx
  2e6e8b:	mov    %ecx,%edx
  2e6e8d:	and    $0x7fffffff,%edx
  2e6e93:	cmp    $0x53800000,%edx
  2e6e99:	jbe    2e6ed0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x14f0>
  2e6e9b:	vmulss %xmm0,%xmm12,%xmm0
  2e6e9f:	vmulss %xmm1,%xmm12,%xmm1
  2e6ea3:	add    $0x50,%rsi
  2e6ea7:	jno    2e6e80 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x14a0>
  2e6ea9:	jmp    2e82b6 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28d6>
  2e6eae:	xchg   %ax,%ax
  2e6eb0:	mov    %ecx,%edx
  2e6eb2:	lea    -0x1(%rdx),%esi
  2e6eb5:	cmp    $0x2b7ffffe,%esi
  2e6ebb:	ja     2e6e04 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1424>
  2e6ec1:	jmp    2e6ef3 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1513>
  2e6ec3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  2e6ed0:	mov    %rdi,(%r10,%rax,8)
  2e6ed4:	vmovss %xmm0,(%r14,%rax,4)
  2e6eda:	vmovss %xmm1,(%rbx,%rax,4)
  2e6edf:	mov    0x38(%rsp),%rdi
  2e6ee4:	lea    -0x1(%rdx),%esi
  2e6ee7:	cmp    $0x2b7ffffe,%esi
  2e6eed:	ja     2e6e04 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1424>
  2e6ef3:	mov    (%r10,%rax,8),%rsi
  2e6ef7:	vmulss %xmm0,%xmm13,%xmm0
  2e6efb:	vmulss %xmm1,%xmm13,%xmm1
  2e6eff:	add    $0xffffffffffffffb0,%rsi
  2e6f03:	jo     2e82c0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28e0>
  2e6f09:	vmovd  %ecx,%xmm2
  2e6f0d:	nopl   (%rax)
  2e6f10:	mov    %rsi,%rcx
  2e6f13:	vmulss %xmm2,%xmm13,%xmm2
  2e6f17:	vmovd  %xmm2,%edx
  2e6f1b:	and    $0x7fffffff,%edx
  2e6f21:	lea    -0x1(%rdx),%edi
  2e6f24:	cmp    $0x2b7fffff,%edi
  2e6f2a:	jae    2e6df0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1410>
  2e6f30:	vmulss %xmm0,%xmm13,%xmm0
  2e6f34:	vmulss %xmm1,%xmm13,%xmm1
  2e6f38:	add    $0xffffffffffffffb0,%rsi
  2e6f3c:	jno    2e6f10 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1530>
  2e6f3e:	jmp    2e82bc <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28dc>
  2e6f43:	mov    0x470(%rsp),%rbp
  2e6f4b:	mov    0x50(%rsp),%r15
  2e6f50:	mov    0x4a0(%rsp),%r10
  2e6f58:	vmovss -0x2ba718(%rip),%xmm6        # 2c848 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x27d8>
  2e6f60:	vmovss -0x2ba888(%rip),%xmm7        # 2c6e0 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x2670>
  2e6f68:	mov    0x18(%rsp),%rdx
  2e6f6d:	mov    0x28(%rsp),%r14
  2e6f72:	mov    0x40(%rsp),%r11
  2e6f77:	mov    0x30(%rsp),%r13
  2e6f7c:	mov    (%rsp),%rdi
  2e6f80:	lea    0x1(%r9),%rax
  2e6f84:	incq   0x130(%rsp)
  2e6f8c:	mov    $0x1,%esi
  2e6f91:	mov    %r13,%rcx
  2e6f94:	mov    %rdi,%r13
  2e6f97:	cmp    %r15,%r9
  2e6f9a:	jae    2e5f73 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x593>
  2e6fa0:	mov    0x48(%rsp),%rdi
  2e6fa5:	mov    %rcx,0x48(%rsp)
  2e6faa:	mov    %rax,%r9
  2e6fad:	add    %rsi,%r9
  2e6fb0:	jb     2e5f73 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x593>
  2e6fb6:	cmp    %r15,%r9
  2e6fb9:	ja     2e5f73 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x593>
  2e6fbf:	mov    0x4b0(%rsp),%rax
  2e6fc7:	mov    0x58(%rax),%rsi
  2e6fcb:	cmpb   $0x1,(%rsi)
  2e6fce:	mov    %r13,0x30(%rsp)
  2e6fd3:	mov    %rdi,(%rsp)
  2e6fd7:	jne    2e79a4 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1fc4>
  2e6fdd:	mov    %rsi,0x1c8(%rsp)
  2e6fe5:	mov    %r9,%rdi
  2e6fe8:	sub    0x60(%rax),%rdi
  2e6fec:	shr    $1,%rdi
  2e6fef:	mov    0x18(%rax),%rsi
  2e6ff3:	cmp    %rsi,%rdi
  2e6ff6:	jae    2e8593 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2bb3>
  2e6ffc:	mov    0x28(%rax),%rsi
  2e7000:	cmp    %rsi,%rdi
  2e7003:	jae    2e85a3 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2bc3>
  2e7009:	mov    0x38(%rax),%rsi
  2e700d:	cmp    %rsi,%rdi
  2e7010:	jae    2e85b3 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2bd3>
  2e7016:	mov    0x48(%rax),%rsi
  2e701a:	cmp    %rsi,%rdi
  2e701d:	jae    2e85c3 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2be3>
  2e7023:	test   %rdx,%rdx
  2e7026:	je     2e7985 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1fa5>
  2e702c:	mov    %r9,0x120(%rsp)
  2e7034:	mov    %rax,%rsi
  2e7037:	mov    0x10(%rax),%rax
  2e703b:	vmovss (%rax,%rdi,8),%xmm0
  2e7040:	vmovss 0x4(%rax,%rdi,8),%xmm1
  2e7046:	mov    0x20(%rsi),%rax
  2e704a:	vmovss (%rax,%rdi,8),%xmm2
  2e704f:	vmovss 0x4(%rax,%rdi,8),%xmm3
  2e7055:	mov    0x30(%rsi),%rax
  2e7059:	mov    0x40(%rsi),%rcx
  2e705d:	vmovss (%rax,%rdi,8),%xmm4
  2e7062:	vmovss 0x4(%rax,%rdi,8),%xmm5
  2e7068:	vmovss (%rcx,%rdi,8),%xmm8
  2e706d:	vmovss 0x4(%rcx,%rdi,8),%xmm9
  2e7073:	vmovaps %xmm0,0x1a0(%rsp)
  2e707c:	vbroadcastss %xmm0,%ymm0
  2e7081:	vmovups %ymm0,0x380(%rsp)
  2e708a:	vmovaps %xmm1,0x190(%rsp)
  2e7093:	vbroadcastss %xmm1,%ymm0
  2e7098:	vmovups %ymm0,0x360(%rsp)
  2e70a1:	vmovaps %xmm2,0x150(%rsp)
  2e70aa:	vbroadcastss %xmm2,%ymm0
  2e70af:	vmovups %ymm0,0x300(%rsp)
  2e70b8:	vmovaps %xmm3,0x180(%rsp)
  2e70c1:	vbroadcastss %xmm3,%ymm0
  2e70c6:	vmovups %ymm0,0x2e0(%rsp)
  2e70cf:	vmovaps %xmm4,0x170(%rsp)
  2e70d8:	vbroadcastss %xmm4,%ymm0
  2e70dd:	vmovups %ymm0,0x340(%rsp)
  2e70e6:	vmovaps %xmm5,0x160(%rsp)
  2e70ef:	vbroadcastss %xmm5,%ymm0
  2e70f4:	vmovups %ymm0,0x3e0(%rsp)
  2e70fd:	vmovaps %xmm8,0x3b0(%rsp)
  2e7106:	vbroadcastss %xmm8,%ymm0
  2e710b:	vmovups %ymm0,0x320(%rsp)
  2e7114:	vmovaps %xmm9,0x3a0(%rsp)
  2e711d:	vbroadcastss %xmm9,%ymm0
  2e7122:	vmovups %ymm0,0x3c0(%rsp)
  2e712b:	mov    (%rsi),%rax
  2e712e:	mov    %rax,0x80(%rsp)
  2e7136:	mov    0x8(%rsi),%rax
  2e713a:	mov    %rax,0x88(%rsp)
  2e7142:	mov    0x50(%rsi),%r14
  2e7146:	mov    $0x8,%ecx
  2e714b:	movq   $0x0,0xa0(%rsp)
  2e7157:	mov    0x110(%rsp),%r8
  2e715f:	mov    0x78(%rsp),%rax
  2e7164:	mov    %rax,0x70(%rsp)
  2e7169:	mov    %r13,0x38(%rsp)
  2e716e:	movq   $0x0,0x98(%rsp)
  2e717a:	mov    %r10,0x10(%rsp)
  2e717f:	mov    0x1c0(%rsp),%rax
  2e7187:	xor    %edi,%edi
  2e7189:	nopl   0x0(%rax)
  2e7190:	mov    %rax,0xc8(%rsp)
  2e7198:	mov    0x60(%rsp),%rax
  2e719d:	cmp    %rax,%rcx
  2e71a0:	mov    %rax,%r12
  2e71a3:	cmovb  %rcx,%r12
  2e71a7:	cmovb  %rcx,%rax
  2e71ab:	lea    0x8(%rdi),%r11
  2e71af:	cmp    %r11,%rdx
  2e71b2:	mov    %r11,%rsi
  2e71b5:	cmovb  %rdx,%rsi
  2e71b9:	mov    %rsi,%r9
  2e71bc:	sub    %rdi,%r9
  2e71bf:	jb     2e84c2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2ae2>
  2e71c5:	mov    %r11,0xf8(%rsp)
  2e71cd:	mov    %rcx,0x100(%rsp)
  2e71d5:	test   $0x1,%bl
  2e71d8:	mov    %r8,0x20(%rsp)
  2e71dd:	jne    2e7220 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1840>
  2e71df:	cmp    %rdi,%rsi
  2e71e2:	je     2e7220 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1840>
  2e71e4:	add    0xa0(%rsp),%r12
  2e71ec:	mov    0x98(%rsp),%rcx
  2e71f4:	lea    (%rcx,%rax,8),%rax
  2e71f8:	xor    %ecx,%ecx
  2e71fa:	nopw   0x0(%rax,%rax,1)
  2e7200:	mov    0x10(%rsp),%rdx
  2e7205:	cmpq   $0x0,(%rdx,%rcx,1)
  2e720a:	jne    2e75a6 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1bc6>
  2e7210:	add    $0x8,%rcx
  2e7214:	cmp    %rcx,%rax
  2e7217:	jne    2e7200 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1820>
  2e7219:	nopl   0x0(%rax)
  2e7220:	lea    0x0(,%rdi,4),%rax
  2e7228:	add    %r13,%rax
  2e722b:	cmp    $0x8,%r9
  2e722f:	mov    $0x8,%ecx
  2e7234:	cmovae %rcx,%r9
  2e7238:	shl    $0x8,%r9d
  2e723c:	mov    0x9f0c5(%rip),%r11        # 386308 <_DYNAMIC+0xb60>
  2e7243:	mov    (%r11,%r9,1),%rdx
  2e7247:	lea    0x2(%rip),%rcx        # 2e7250 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1870>
  2e724e:	jmp    *%rdx
  2e7250:	mov    0x78(%rsp),%rax
  2e7255:	add    %rax,%rdi
  2e7258:	add    %rax,%rsi
  2e725b:	cmp    0x88(%rsp),%rsi
  2e7263:	ja     2e8494 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2ab4>
  2e7269:	vmovaps %ymm0,%ymm2
  2e726d:	mov    0x80(%rsp),%rax
  2e7275:	lea    (%rax,%rdi,4),%rax
  2e7279:	mov    (%r11,%r9,1),%rdx
  2e727d:	lea    0x2(%rip),%rcx        # 2e7286 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x18a6>
  2e7284:	jmp    *%rdx
  2e7286:	mov    0x8(%r14),%rdx
  2e728a:	cmp    %rdx,%rsi
  2e728d:	ja     2e8392 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29b2>
  2e7293:	vmovaps %ymm0,%ymm3
  2e7297:	lea    0x0(,%rdi,4),%r8
  2e729f:	mov    (%r14),%rax
  2e72a2:	add    %r8,%rax
  2e72a5:	mov    (%r11,%r9,1),%rdx
  2e72a9:	lea    0x2(%rip),%rcx        # 2e72b2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x18d2>
  2e72b0:	jmp    *%rdx
  2e72b2:	mov    0x18(%r14),%rdx
  2e72b6:	cmp    %rdx,%rsi
  2e72b9:	ja     2e83a2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29c2>
  2e72bf:	vmovaps %ymm0,%ymm4
  2e72c3:	mov    0x10(%r14),%rax
  2e72c7:	add    %r8,%rax
  2e72ca:	mov    (%r11,%r9,1),%rdx
  2e72ce:	lea    0x2(%rip),%rcx        # 2e72d7 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x18f7>
  2e72d5:	jmp    *%rdx
  2e72d7:	mov    0x8(%r14),%rdx
  2e72db:	cmp    %rdx,%rsi
  2e72de:	ja     2e83fa <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2a1a>
  2e72e4:	vmovaps %ymm0,%ymm5
  2e72e8:	vfmadd231ps 0x380(%rsp),%ymm2,%ymm4
  2e72f2:	mov    (%r14),%rax
  2e72f5:	add    %r8,%rax
  2e72f8:	mov    0x8(%r11,%r9,1),%rdx
  2e72fd:	vmovaps %ymm4,%ymm0
  2e7301:	lea    0x2(%rip),%rcx        # 2e730a <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x192a>
  2e7308:	jmp    *%rdx
  2e730a:	mov    0x18(%r14),%rdx
  2e730e:	cmp    %rdx,%rsi
  2e7311:	ja     2e83b2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29d2>
  2e7317:	vfmadd231ps 0x360(%rsp),%ymm2,%ymm5
  2e7321:	mov    0x10(%r14),%rax
  2e7325:	add    %r8,%rax
  2e7328:	mov    0x8(%r11,%r9,1),%rdx
  2e732d:	vmovaps %ymm5,%ymm0
  2e7331:	lea    0x2(%rip),%rcx        # 2e733a <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x195a>
  2e7338:	jmp    *%rdx
  2e733a:	mov    0x28(%r14),%rdx
  2e733e:	cmp    %rdx,%rsi
  2e7341:	ja     2e8392 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29b2>
  2e7347:	mov    0x20(%r14),%rax
  2e734b:	add    %r8,%rax
  2e734e:	mov    (%r11,%r9,1),%rdx
  2e7352:	lea    0x2(%rip),%rcx        # 2e735b <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x197b>
  2e7359:	jmp    *%rdx
  2e735b:	mov    0x38(%r14),%rdx
  2e735f:	cmp    %rdx,%rsi
  2e7362:	ja     2e83a2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29c2>
  2e7368:	vmovaps %ymm0,%ymm5
  2e736c:	mov    0x30(%r14),%rax
  2e7370:	add    %r8,%rax
  2e7373:	mov    (%r11,%r9,1),%rdx
  2e7377:	lea    0x2(%rip),%rcx        # 2e7380 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x19a0>
  2e737e:	jmp    *%rdx
  2e7380:	mov    0x28(%r14),%rdx
  2e7384:	cmp    %rdx,%rsi
  2e7387:	ja     2e83fa <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2a1a>
  2e738d:	vmovaps %ymm0,%ymm4
  2e7391:	vmulps 0x300(%rsp),%ymm3,%ymm0
  2e739a:	vfmadd213ps %ymm5,%ymm2,%ymm0
  2e739f:	mov    0x20(%r14),%rax
  2e73a3:	add    %r8,%rax
  2e73a6:	mov    0x8(%r11,%r9,1),%rdx
  2e73ab:	lea    0x2(%rip),%rcx        # 2e73b4 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x19d4>
  2e73b2:	jmp    *%rdx
  2e73b4:	mov    0x38(%r14),%rdx
  2e73b8:	cmp    %rdx,%rsi
  2e73bb:	ja     2e83b2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29d2>
  2e73c1:	vmulps 0x2e0(%rsp),%ymm3,%ymm0
  2e73ca:	vfmadd213ps %ymm4,%ymm2,%ymm0
  2e73cf:	mov    0x30(%r14),%rax
  2e73d3:	add    %r8,%rax
  2e73d6:	mov    0x8(%r11,%r9,1),%rdx
  2e73db:	lea    0x2(%rip),%rcx        # 2e73e4 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1a04>
  2e73e2:	jmp    *%rdx
  2e73e4:	mov    0x48(%r14),%rdx
  2e73e8:	cmp    %rdx,%rsi
  2e73eb:	ja     2e8392 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29b2>
  2e73f1:	mov    0x40(%r14),%rax
  2e73f5:	add    %r8,%rax
  2e73f8:	mov    (%r11,%r9,1),%rdx
  2e73fc:	lea    0x2(%rip),%rcx        # 2e7405 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1a25>
  2e7403:	jmp    *%rdx
  2e7405:	mov    0x58(%r14),%rdx
  2e7409:	cmp    %rdx,%rsi
  2e740c:	ja     2e83a2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29c2>
  2e7412:	vmovaps %ymm0,%ymm4
  2e7416:	mov    0x50(%r14),%rax
  2e741a:	add    %r8,%rax
  2e741d:	mov    (%r11,%r9,1),%rdx
  2e7421:	lea    0x2(%rip),%rcx        # 2e742a <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1a4a>
  2e7428:	jmp    *%rdx
  2e742a:	mov    0x48(%r14),%rdx
  2e742e:	cmp    %rdx,%rsi
  2e7431:	ja     2e83fa <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2a1a>
  2e7437:	vmovaps %ymm0,%ymm5
  2e743b:	vfmadd231ps 0x340(%rsp),%ymm2,%ymm4
  2e7445:	mov    0x40(%r14),%rax
  2e7449:	add    %r8,%rax
  2e744c:	mov    0x8(%r11,%r9,1),%rdx
  2e7451:	vmovaps %ymm4,%ymm0
  2e7455:	lea    0x2(%rip),%rcx        # 2e745e <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1a7e>
  2e745c:	jmp    *%rdx
  2e745e:	mov    0x58(%r14),%rdx
  2e7462:	cmp    %rdx,%rsi
  2e7465:	ja     2e83b2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29d2>
  2e746b:	vfmadd231ps 0x3e0(%rsp),%ymm2,%ymm5
  2e7475:	mov    0x50(%r14),%rax
  2e7479:	add    %r8,%rax
  2e747c:	mov    0x8(%r11,%r9,1),%rdx
  2e7481:	vmovaps %ymm5,%ymm0
  2e7485:	lea    0x2(%rip),%rcx        # 2e748e <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1aae>
  2e748c:	jmp    *%rdx
  2e748e:	mov    0x68(%r14),%rdx
  2e7492:	cmp    %rdx,%rsi
  2e7495:	ja     2e8392 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29b2>
  2e749b:	mov    0x60(%r14),%rax
  2e749f:	add    %r8,%rax
  2e74a2:	mov    (%r11,%r9,1),%rdx
  2e74a6:	lea    0x2(%rip),%rcx        # 2e74af <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1acf>
  2e74ad:	jmp    *%rdx
  2e74af:	mov    0x78(%r14),%rdx
  2e74b3:	cmp    %rdx,%rsi
  2e74b6:	ja     2e83a2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29c2>
  2e74bc:	vmovaps %ymm0,%ymm5
  2e74c0:	mov    0x70(%r14),%rax
  2e74c4:	add    %r8,%rax
  2e74c7:	mov    (%r11,%r9,1),%rdx
  2e74cb:	lea    0x2(%rip),%rcx        # 2e74d4 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1af4>
  2e74d2:	jmp    *%rdx
  2e74d4:	mov    0x68(%r14),%rdx
  2e74d8:	cmp    %rdx,%rsi
  2e74db:	ja     2e83fa <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2a1a>
  2e74e1:	vmovaps %ymm0,%ymm4
  2e74e5:	vmulps 0x320(%rsp),%ymm3,%ymm0
  2e74ee:	vfmadd213ps %ymm5,%ymm2,%ymm0
  2e74f3:	mov    0x60(%r14),%rax
  2e74f7:	add    %r8,%rax
  2e74fa:	mov    0x8(%r11,%r9,1),%rdx
  2e74ff:	lea    0x2(%rip),%rcx        # 2e7508 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1b28>
  2e7506:	jmp    *%rdx
  2e7508:	mov    0x78(%r14),%rdx
  2e750c:	cmp    %rdx,%rsi
  2e750f:	ja     2e83b2 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x29d2>
  2e7515:	vmulps 0x3c0(%rsp),%ymm3,%ymm0
  2e751e:	vfmadd213ps %ymm4,%ymm2,%ymm0
  2e7523:	add    0x70(%r14),%r8
  2e7527:	mov    0x8(%r11,%r9,1),%rdx
  2e752c:	mov    %r8,%rax
  2e752f:	lea    0x2(%rip),%rcx        # 2e7538 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1b58>
  2e7536:	jmp    *%rdx
  2e7538:	mov    0x20(%rsp),%r8
  2e753d:	mov    0xc8(%rsp),%rax
  2e7545:	dec    %rax
  2e7548:	mov    0x100(%rsp),%rcx
  2e7550:	add    $0x8,%rcx
  2e7554:	addq   $0x40,0x10(%rsp)
  2e755a:	addq   $0xffffffffffffffc0,0x98(%rsp)
  2e7563:	addq   $0x20,0x38(%rsp)
  2e7569:	addq   $0x8,0x70(%rsp)
  2e756f:	add    $0x20,%r8
  2e7573:	addq   $0xfffffffffffffff8,0xa0(%rsp)
  2e757c:	mov    0xf8(%rsp),%rdi
  2e7584:	test   %rax,%rax
  2e7587:	mov    0x50(%rsp),%r15
  2e758c:	mov    0x18(%rsp),%rdx
  2e7591:	mov    0x40(%rsp),%r11
  2e7596:	mov    0x30(%rsp),%r13
  2e759b:	jne    2e7190 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x17b0>
  2e75a1:	jmp    2e798b <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1fab>
  2e75a6:	mov    0x4b0(%rsp),%rax
  2e75ae:	mov    0x8(%rax),%rcx
  2e75b2:	mov    %rcx,0xc0(%rsp)
  2e75ba:	mov    0x50(%rax),%r15
  2e75be:	mov    (%rax),%rax
  2e75c1:	add    %r8,%rax
  2e75c4:	mov    %rax,0xa8(%rsp)
  2e75cc:	xor    %r13d,%r13d
  2e75cf:	nop
  2e75d0:	mov    0x70(%rsp),%rax
  2e75d5:	lea    (%rax,%r13,1),%rbp
  2e75d9:	mov    0x38(%rsp),%rax
  2e75de:	vmovss (%rax,%r13,4),%xmm2
  2e75e4:	mov    0x10(%rsp),%rax
  2e75e9:	mov    (%rax,%r13,8),%rdi
  2e75ed:	vmovaps 0x1a0(%rsp),%xmm0
  2e75f6:	vmovaps 0x190(%rsp),%xmm1
  2e75ff:	vzeroupper
  2e7602:	call   *0x9ece8(%rip)        # 3862f0 <_DYNAMIC+0xb48>
  2e7608:	mov    0x8(%r15),%rsi
  2e760c:	cmp    %rsi,%rbp
  2e760f:	jae    2e8502 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b22>
  2e7615:	mov    0x18(%r15),%rsi
  2e7619:	cmp    %rsi,%rbp
  2e761c:	vmovss -0x2baddc(%rip),%xmm6        # 2c848 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x27d8>
  2e7624:	vmovss -0x2baf4c(%rip),%xmm7        # 2c6e0 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x2670>
  2e762c:	mov    (%rsp),%rdi
  2e7630:	mov    0x20(%rsp),%r8
  2e7635:	jae    2e8512 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b32>
  2e763b:	mov    (%r15),%rax
  2e763e:	add    %r8,%rax
  2e7641:	vaddss (%rax,%r13,4),%xmm0,%xmm2
  2e7647:	mov    0x10(%r15),%rcx
  2e764b:	add    %r8,%rcx
  2e764e:	vaddss (%rcx,%r13,4),%xmm1,%xmm0
  2e7654:	vmovd  %xmm0,%ecx
  2e7658:	vmovd  %xmm2,%edx
  2e765c:	add    %edx,%edx
  2e765e:	add    %ecx,%ecx
  2e7660:	cmp    $0xff000000,%ecx
  2e7666:	setb   %cl
  2e7669:	cmp    $0xfeffffff,%edx
  2e766f:	mov    0x4a0(%rsp),%r10
  2e7677:	mov    0x18(%rsp),%rdx
  2e767c:	ja     2e7952 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1f72>
  2e7682:	test   %cl,%cl
  2e7684:	je     2e7952 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1f72>
  2e768a:	vmovss %xmm2,(%rax,%r13,4)
  2e7690:	mov    0x18(%r15),%rsi
  2e7694:	cmp    %rsi,%rbp
  2e7697:	jae    2e8522 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b42>
  2e769d:	mov    0x10(%r15),%rax
  2e76a1:	add    %r8,%rax
  2e76a4:	vmovss %xmm0,(%rax,%r13,4)
  2e76aa:	cmp    0xc0(%rsp),%rbp
  2e76b2:	jae    2e857b <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b9b>
  2e76b8:	mov    0xa8(%rsp),%rax
  2e76c0:	vmovss (%rax,%r13,4),%xmm0
  2e76c6:	vmulss 0x180(%rsp),%xmm0,%xmm1
  2e76cf:	vmulss 0x150(%rsp),%xmm0,%xmm0
  2e76d8:	mov    0x38(%rsp),%rax
  2e76dd:	vmovss (%rax,%r13,4),%xmm2
  2e76e3:	mov    0x10(%rsp),%rax
  2e76e8:	mov    (%rax,%r13,8),%rdi
  2e76ec:	call   *0x9ebfe(%rip)        # 3862f0 <_DYNAMIC+0xb48>
  2e76f2:	mov    0x28(%r15),%rsi
  2e76f6:	cmp    %rsi,%rbp
  2e76f9:	jae    2e8502 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b22>
  2e76ff:	mov    0x38(%r15),%rsi
  2e7703:	cmp    %rsi,%rbp
  2e7706:	vmovss -0x2baec6(%rip),%xmm6        # 2c848 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x27d8>
  2e770e:	vmovss -0x2bb036(%rip),%xmm7        # 2c6e0 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x2670>
  2e7716:	mov    (%rsp),%rdi
  2e771a:	mov    0x20(%rsp),%r8
  2e771f:	jae    2e8512 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b32>
  2e7725:	mov    0x20(%r15),%rax
  2e7729:	add    %r8,%rax
  2e772c:	vaddss (%rax,%r13,4),%xmm0,%xmm2
  2e7732:	mov    0x30(%r15),%rcx
  2e7736:	add    %r8,%rcx
  2e7739:	vaddss (%rcx,%r13,4),%xmm1,%xmm0
  2e773f:	vmovd  %xmm0,%ecx
  2e7743:	vmovd  %xmm2,%edx
  2e7747:	add    %edx,%edx
  2e7749:	add    %ecx,%ecx
  2e774b:	cmp    $0xff000000,%ecx
  2e7751:	setb   %cl
  2e7754:	cmp    $0xfeffffff,%edx
  2e775a:	mov    0x4a0(%rsp),%r10
  2e7762:	mov    0x18(%rsp),%rdx
  2e7767:	ja     2e7952 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1f72>
  2e776d:	test   %cl,%cl
  2e776f:	je     2e7952 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1f72>
  2e7775:	vmovss %xmm2,(%rax,%r13,4)
  2e777b:	mov    0x38(%r15),%rsi
  2e777f:	cmp    %rsi,%rbp
  2e7782:	jae    2e8522 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b42>
  2e7788:	mov    0x30(%r15),%rax
  2e778c:	add    %r8,%rax
  2e778f:	vmovss %xmm0,(%rax,%r13,4)
  2e7795:	mov    0x38(%rsp),%rax
  2e779a:	vmovss (%rax,%r13,4),%xmm2
  2e77a0:	mov    0x10(%rsp),%rax
  2e77a5:	mov    (%rax,%r13,8),%rdi
  2e77a9:	vmovaps 0x170(%rsp),%xmm0
  2e77b2:	vmovaps 0x160(%rsp),%xmm1
  2e77bb:	call   *0x9eb2f(%rip)        # 3862f0 <_DYNAMIC+0xb48>
  2e77c1:	mov    0x48(%r15),%rsi
  2e77c5:	cmp    %rsi,%rbp
  2e77c8:	jae    2e8502 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b22>
  2e77ce:	mov    0x58(%r15),%rsi
  2e77d2:	cmp    %rsi,%rbp
  2e77d5:	vmovss -0x2baf95(%rip),%xmm6        # 2c848 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x27d8>
  2e77dd:	vmovss -0x2bb105(%rip),%xmm7        # 2c6e0 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x2670>
  2e77e5:	mov    (%rsp),%rdi
  2e77e9:	mov    0x20(%rsp),%r8
  2e77ee:	jae    2e8512 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b32>
  2e77f4:	mov    0x40(%r15),%rax
  2e77f8:	add    %r8,%rax
  2e77fb:	vaddss (%rax,%r13,4),%xmm0,%xmm2
  2e7801:	mov    0x50(%r15),%rcx
  2e7805:	add    %r8,%rcx
  2e7808:	vaddss (%rcx,%r13,4),%xmm1,%xmm0
  2e780e:	vmovd  %xmm0,%ecx
  2e7812:	vmovd  %xmm2,%edx
  2e7816:	add    %edx,%edx
  2e7818:	add    %ecx,%ecx
  2e781a:	cmp    $0xff000000,%ecx
  2e7820:	setb   %cl
  2e7823:	cmp    $0xfeffffff,%edx
  2e7829:	mov    0x4a0(%rsp),%r10
  2e7831:	mov    0x18(%rsp),%rdx
  2e7836:	ja     2e7952 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1f72>
  2e783c:	test   %cl,%cl
  2e783e:	je     2e7952 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1f72>
  2e7844:	vmovss %xmm2,(%rax,%r13,4)
  2e784a:	mov    0x58(%r15),%rsi
  2e784e:	cmp    %rsi,%rbp
  2e7851:	jae    2e8522 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b42>
  2e7857:	mov    0x50(%r15),%rax
  2e785b:	add    %r8,%rax
  2e785e:	vmovss %xmm0,(%rax,%r13,4)
  2e7864:	mov    0xa8(%rsp),%rax
  2e786c:	vmovss (%rax,%r13,4),%xmm0
  2e7872:	vmulss 0x3a0(%rsp),%xmm0,%xmm1
  2e787b:	vmulss 0x3b0(%rsp),%xmm0,%xmm0
  2e7884:	mov    0x38(%rsp),%rax
  2e7889:	vmovss (%rax,%r13,4),%xmm2
  2e788f:	mov    0x10(%rsp),%rax
  2e7894:	mov    (%rax,%r13,8),%rdi
  2e7898:	call   *0x9ea52(%rip)        # 3862f0 <_DYNAMIC+0xb48>
  2e789e:	mov    0x68(%r15),%rsi
  2e78a2:	cmp    %rsi,%rbp
  2e78a5:	jae    2e8502 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b22>
  2e78ab:	mov    0x78(%r15),%rsi
  2e78af:	cmp    %rsi,%rbp
  2e78b2:	vmovss -0x2bb072(%rip),%xmm6        # 2c848 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x27d8>
  2e78ba:	vmovss -0x2bb1e2(%rip),%xmm7        # 2c6e0 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x2670>
  2e78c2:	mov    (%rsp),%rdi
  2e78c6:	mov    0x20(%rsp),%r8
  2e78cb:	jae    2e8512 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b32>
  2e78d1:	mov    0x60(%r15),%rax
  2e78d5:	add    %r8,%rax
  2e78d8:	vaddss (%rax,%r13,4),%xmm0,%xmm2
  2e78de:	mov    0x70(%r15),%rcx
  2e78e2:	add    %r8,%rcx
  2e78e5:	vaddss (%rcx,%r13,4),%xmm1,%xmm0
  2e78eb:	vmovd  %xmm0,%ecx
  2e78ef:	vmovd  %xmm2,%edx
  2e78f3:	add    %edx,%edx
  2e78f5:	add    %ecx,%ecx
  2e78f7:	cmp    $0xff000000,%ecx
  2e78fd:	setb   %cl
  2e7900:	cmp    $0xfeffffff,%edx
  2e7906:	mov    0x4a0(%rsp),%r10
  2e790e:	mov    0x18(%rsp),%rdx
  2e7913:	ja     2e7952 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1f72>
  2e7915:	test   %cl,%cl
  2e7917:	je     2e7952 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1f72>
  2e7919:	vmovss %xmm2,(%rax,%r13,4)
  2e791f:	mov    0x78(%r15),%rsi
  2e7923:	cmp    %rsi,%rbp
  2e7926:	jae    2e8522 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b42>
  2e792c:	mov    0x70(%r15),%rax
  2e7930:	add    %r8,%rax
  2e7933:	vmovss %xmm0,(%rax,%r13,4)
  2e7939:	inc    %r13
  2e793c:	cmp    %r13,%r12
  2e793f:	mov    0x470(%rsp),%rbp
  2e7947:	jne    2e75d0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1bf0>
  2e794d:	jmp    2e753d <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1b5d>
  2e7952:	mov    0x1c8(%rsp),%rax
  2e795a:	movb   $0x0,(%rax)
  2e795d:	xor    %ebx,%ebx
  2e795f:	mov    0x480(%rsp),%r12
  2e7967:	mov    0x470(%rsp),%rbp
  2e796f:	mov    0x50(%rsp),%r15
  2e7974:	mov    0x28(%rsp),%r14
  2e7979:	mov    0x40(%rsp),%r11
  2e797e:	mov    0x30(%rsp),%r13
  2e7983:	jmp    2e799c <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1fbc>
  2e7985:	mov    (%rsp),%rdi
  2e7989:	jmp    2e79a4 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1fc4>
  2e798b:	mov    0x480(%rsp),%r12
  2e7993:	mov    0x28(%rsp),%r14
  2e7998:	mov    (%rsp),%rdi
  2e799c:	mov    0x120(%rsp),%r9
  2e79a4:	lea    0x2(%r9),%rax
  2e79a8:	cmp    %r15,%rax
  2e79ab:	ja     2e5f73 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x593>
  2e79b1:	mov    0x130(%rsp),%rcx
  2e79b9:	cmp    0x458(%rsp),%rcx
  2e79c1:	je     2e8545 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b65>
  2e79c7:	cmp    0x468(%rsp),%rcx
  2e79cf:	je     2e8560 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2b80>
  2e79d5:	mov    0x450(%rsp),%rax
  2e79dd:	vbroadcastss (%rax,%rcx,4),%ymm0
  2e79e3:	mov    0x460(%rsp),%rax
  2e79eb:	vbroadcastss (%rax,%rcx,4),%ymm1
  2e79f1:	cmpq   $0x0,0x128(%rsp)
  2e79fa:	mov    0xb0(%rsp),%rsi
  2e7a02:	je     2e7ab4 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x20d4>
  2e7a08:	cmpq   $0x1,0x1d0(%rsp)
  2e7a11:	jne    2e7a17 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2037>
  2e7a13:	xor    %eax,%eax
  2e7a15:	jmp    2e7a8a <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x20aa>
  2e7a17:	mov    $0x20,%ecx
  2e7a1c:	xor    %eax,%eax
  2e7a1e:	mov    0x48(%rsp),%r8
  2e7a23:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  2e7a30:	vmovups -0x20(%rsi,%rcx,1),%ymm2
  2e7a36:	vmulps %ymm2,%ymm2,%ymm2
  2e7a3a:	vfmadd213ps %ymm1,%ymm0,%ymm2
  2e7a3f:	vmovups -0x20(%r13,%rcx,1),%ymm3
  2e7a46:	vfmadd213ps -0x20(%r8,%rcx,1),%ymm2,%ymm3
  2e7a4d:	vmovups %ymm3,-0x20(%rdi,%rcx,1)
  2e7a53:	add    $0x2,%rax
  2e7a57:	vmovups (%rsi,%rcx,1),%ymm2
  2e7a5c:	vmulps %ymm2,%ymm2,%ymm2
  2e7a60:	vfmadd213ps %ymm1,%ymm0,%ymm2
  2e7a65:	vmovups 0x0(%r13,%rcx,1),%ymm3
  2e7a6c:	vfmadd213ps (%r8,%rcx,1),%ymm2,%ymm3
  2e7a72:	vmovups %ymm3,(%rdi,%rcx,1)
  2e7a77:	add    $0x40,%rcx
  2e7a7b:	cmp    %rax,%r11
  2e7a7e:	jne    2e7a30 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2050>
  2e7a80:	testb  $0x8,0x90(%rsp)
  2e7a88:	je     2e7ab4 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x20d4>
  2e7a8a:	shl    $0x5,%rax
  2e7a8e:	vmovups (%r14,%rax,1),%ymm2
  2e7a94:	vmulps %ymm2,%ymm2,%ymm2
  2e7a98:	vfmadd213ps %ymm1,%ymm0,%ymm2
  2e7a9d:	vmovups 0x0(%r13,%rax,1),%ymm3
  2e7aa4:	mov    0x48(%rsp),%rcx
  2e7aa9:	vfmadd213ps (%rcx,%rax,1),%ymm2,%ymm3
  2e7aaf:	vmovups %ymm3,(%rdi,%rax,1)
  2e7ab4:	mov    0xb8(%rsp),%rcx
  2e7abc:	test   %rcx,%rcx
  2e7abf:	mov    0x48(%rsp),%rsi
  2e7ac4:	je     2e7c20 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2240>
  2e7aca:	mov    0x8(%rsp),%rax
  2e7acf:	vmovss (%r14,%rax,4),%xmm2
  2e7ad5:	vmulss %xmm2,%xmm2,%xmm2
  2e7ad9:	vfmadd213ss %xmm1,%xmm0,%xmm2
  2e7ade:	vmovss 0x0(%r13,%rax,4),%xmm3
  2e7ae5:	vfmadd213ss (%rsi,%rax,4),%xmm2,%xmm3
  2e7aeb:	vmovss %xmm3,(%rdi,%rax,4)
  2e7af0:	cmp    $0x1,%ecx
  2e7af3:	je     2e7c20 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2240>
  2e7af9:	mov    0x8(%rsp),%rax
  2e7afe:	vmovss 0x4(%r14,%rax,4),%xmm2
  2e7b05:	vmulss %xmm2,%xmm2,%xmm2
  2e7b09:	vfmadd213ss %xmm1,%xmm0,%xmm2
  2e7b0e:	vmovss 0x4(%r13,%rax,4),%xmm3
  2e7b15:	vfmadd213ss 0x4(%rsi,%rax,4),%xmm2,%xmm3
  2e7b1c:	vmovss %xmm3,0x4(%rdi,%rax,4)
  2e7b22:	cmp    $0x2,%ecx
  2e7b25:	je     2e7c20 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2240>
  2e7b2b:	mov    0x8(%rsp),%rax
  2e7b30:	vmovss 0x8(%r14,%rax,4),%xmm2
  2e7b37:	vmulss %xmm2,%xmm2,%xmm2
  2e7b3b:	vfmadd213ss %xmm1,%xmm0,%xmm2
  2e7b40:	vmovss 0x8(%r13,%rax,4),%xmm3
  2e7b47:	vfmadd213ss 0x8(%rsi,%rax,4),%xmm2,%xmm3
  2e7b4e:	vmovss %xmm3,0x8(%rdi,%rax,4)
  2e7b54:	cmp    $0x3,%ecx
  2e7b57:	je     2e7c20 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2240>
  2e7b5d:	mov    0x8(%rsp),%rax
  2e7b62:	vmovss 0xc(%r14,%rax,4),%xmm2
  2e7b69:	vmulss %xmm2,%xmm2,%xmm2
  2e7b6d:	vfmadd213ss %xmm1,%xmm0,%xmm2
  2e7b72:	vmovss 0xc(%r13,%rax,4),%xmm3
  2e7b79:	vfmadd213ss 0xc(%rsi,%rax,4),%xmm2,%xmm3
  2e7b80:	vmovss %xmm3,0xc(%rdi,%rax,4)
  2e7b86:	cmp    $0x4,%ecx
  2e7b89:	je     2e7c20 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2240>
  2e7b8f:	mov    0x8(%rsp),%rax
  2e7b94:	vmovss 0x10(%r14,%rax,4),%xmm2
  2e7b9b:	vmulss %xmm2,%xmm2,%xmm2
  2e7b9f:	vfmadd213ss %xmm1,%xmm0,%xmm2
  2e7ba4:	vmovss 0x10(%r13,%rax,4),%xmm3
  2e7bab:	vfmadd213ss 0x10(%rsi,%rax,4),%xmm2,%xmm3
  2e7bb2:	vmovss %xmm3,0x10(%rdi,%rax,4)
  2e7bb8:	cmp    $0x5,%ecx
  2e7bbb:	je     2e7c20 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2240>
  2e7bbd:	mov    0x8(%rsp),%rax
  2e7bc2:	vmovss 0x14(%r14,%rax,4),%xmm2
  2e7bc9:	vmulss %xmm2,%xmm2,%xmm2
  2e7bcd:	vfmadd213ss %xmm1,%xmm0,%xmm2
  2e7bd2:	vmovss 0x14(%r13,%rax,4),%xmm3
  2e7bd9:	vfmadd213ss 0x14(%rsi,%rax,4),%xmm2,%xmm3
  2e7be0:	vmovss %xmm3,0x14(%rdi,%rax,4)
  2e7be6:	cmp    $0x6,%ecx
  2e7be9:	je     2e7c20 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2240>
  2e7beb:	mov    0x8(%rsp),%rax
  2e7bf0:	vmovss 0x18(%r14,%rax,4),%xmm2
  2e7bf7:	vmulss %xmm2,%xmm2,%xmm2
  2e7bfb:	vfmadd213ss %xmm1,%xmm0,%xmm2
  2e7c00:	vmovss 0x18(%r13,%rax,4),%xmm0
  2e7c07:	vfmadd213ss 0x18(%rsi,%rax,4),%xmm2,%xmm0
  2e7c0e:	vmovss %xmm0,0x18(%rdi,%rax,4)
  2e7c14:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  2e7c20:	test   $0x1,%bl
  2e7c23:	je     2e8090 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26b0>
  2e7c29:	cmpq   $0x0,0x128(%rsp)
  2e7c32:	je     2e7cde <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x22fe>
  2e7c38:	mov    0x1b8(%rsp),%rax
  2e7c40:	xor    %ecx,%ecx
  2e7c42:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  2e7c50:	vbroadcastss -0x2bb311(%rip),%ymm0        # 2c948 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28d8>
  2e7c59:	vandps 0x0(%r13,%rcx,1),%ymm0,%ymm1
  2e7c60:	vandps (%rdi,%rcx,1),%ymm0,%ymm0
  2e7c65:	vcmpeqps %ymm0,%ymm0,%ymm2
  2e7c6a:	vmaxps %ymm0,%ymm1,%ymm3
  2e7c6e:	vblendvps %ymm2,%ymm3,%ymm1,%ymm2
  2e7c74:	vcmpeqps %ymm1,%ymm1,%ymm1
  2e7c79:	vblendvps %ymm1,%ymm2,%ymm0,%ymm0
  2e7c7f:	vbroadcastss -0x2bb578(%rip),%ymm4        # 2c710 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x26a0>
  2e7c88:	vcmple_oqps %ymm4,%ymm0,%ymm1
  2e7c8d:	vxorps %xmm3,%xmm3,%xmm3
  2e7c91:	vcmpeqps %ymm3,%ymm0,%ymm2
  2e7c96:	vblendvps %ymm2,%ymm4,%ymm0,%ymm0
  2e7c9c:	vpcmpgtd %ymm1,%ymm3,%ymm1
  2e7ca0:	vpand  %ymm0,%ymm1,%ymm0
  2e7ca4:	vextracti128 $0x1,%ymm0,%xmm1
  2e7caa:	vminps %xmm1,%xmm0,%xmm0
  2e7cae:	vshufpd $0x3,%xmm0,%xmm0,%xmm1
  2e7cb3:	vminps %xmm1,%xmm0,%xmm0
  2e7cb7:	vmovshdup %xmm0,%xmm1
  2e7cbb:	vminss %xmm1,%xmm0,%xmm0
  2e7cbf:	vmovss -0x2bb3af(%rip),%xmm1        # 2c918 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28a8>
  2e7cc7:	vucomiss %xmm0,%xmm1
  2e7ccb:	ja     2e8090 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26b0>
  2e7cd1:	add    $0x20,%rcx
  2e7cd5:	dec    %rax
  2e7cd8:	jne    2e7c50 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2270>
  2e7cde:	mov    $0x1,%bl
  2e7ce0:	mov    0xb8(%rsp),%rsi
  2e7ce8:	test   %rsi,%rsi
  2e7ceb:	je     2e6f80 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x15a0>
  2e7cf1:	mov    0x8(%rsp),%rax
  2e7cf6:	vmovss 0x0(%r13,%rax,4),%xmm0
  2e7cfd:	vbroadcastss -0x2bb3be(%rip),%xmm2        # 2c948 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28d8>
  2e7d06:	vandps %xmm2,%xmm0,%xmm0
  2e7d0a:	vmovss (%rdi,%rax,4),%xmm1
  2e7d0f:	vandps %xmm2,%xmm1,%xmm1
  2e7d13:	vmaxss %xmm1,%xmm0,%xmm2
  2e7d17:	vcmpunordss %xmm1,%xmm1,%xmm1
  2e7d1c:	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  2e7d22:	vmovss -0x2bb61a(%rip),%xmm1        # 2c710 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x26a0>
  2e7d2a:	vucomiss %xmm0,%xmm1
  2e7d2e:	jb     2e8085 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26a5>
  2e7d34:	vmovss -0x2bb424(%rip),%xmm1        # 2c918 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28a8>
  2e7d3c:	vcmpnless %xmm0,%xmm1,%xmm1
  2e7d41:	vxorps %xmm2,%xmm2,%xmm2
  2e7d45:	vcmpneqss %xmm2,%xmm0,%xmm0
  2e7d4a:	vandps %xmm1,%xmm0,%xmm0
  2e7d4e:	vmovd  %xmm0,%ecx
  2e7d52:	mov    $0x0,%eax
  2e7d57:	test   $0x1,%cl
  2e7d5a:	jne    2e8087 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26a7>
  2e7d60:	cmp    $0x1,%esi
  2e7d63:	je     2e6f80 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x15a0>
  2e7d69:	mov    0x8(%rsp),%rax
  2e7d6e:	vmovss 0x4(%r13,%rax,4),%xmm0
  2e7d75:	vbroadcastss -0x2bb436(%rip),%xmm2        # 2c948 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28d8>
  2e7d7e:	vandps %xmm2,%xmm0,%xmm0
  2e7d82:	vmovss 0x4(%rdi,%rax,4),%xmm1
  2e7d88:	vandps %xmm2,%xmm1,%xmm1
  2e7d8c:	vmaxss %xmm1,%xmm0,%xmm2
  2e7d90:	vcmpunordss %xmm1,%xmm1,%xmm1
  2e7d95:	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  2e7d9b:	vmovss -0x2bb693(%rip),%xmm1        # 2c710 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x26a0>
  2e7da3:	vucomiss %xmm0,%xmm1
  2e7da7:	mov    $0x1,%eax
  2e7dac:	jb     2e8087 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26a7>
  2e7db2:	vmovss -0x2bb4a2(%rip),%xmm1        # 2c918 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28a8>
  2e7dba:	vcmpnless %xmm0,%xmm1,%xmm1
  2e7dbf:	vxorps %xmm2,%xmm2,%xmm2
  2e7dc3:	vcmpneqss %xmm2,%xmm0,%xmm0
  2e7dc8:	vandps %xmm1,%xmm0,%xmm0
  2e7dcc:	vmovd  %xmm0,%ecx
  2e7dd0:	test   $0x1,%cl
  2e7dd3:	jne    2e8087 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26a7>
  2e7dd9:	cmp    $0x2,%esi
  2e7ddc:	je     2e6f80 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x15a0>
  2e7de2:	mov    0x8(%rsp),%rax
  2e7de7:	vmovss 0x8(%r13,%rax,4),%xmm0
  2e7dee:	vbroadcastss -0x2bb4af(%rip),%xmm2        # 2c948 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28d8>
  2e7df7:	vandps %xmm2,%xmm0,%xmm0
  2e7dfb:	vmovss 0x8(%rdi,%rax,4),%xmm1
  2e7e01:	vandps %xmm2,%xmm1,%xmm1
  2e7e05:	vmaxss %xmm1,%xmm0,%xmm2
  2e7e09:	vcmpunordss %xmm1,%xmm1,%xmm1
  2e7e0e:	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  2e7e14:	vmovss -0x2bb70c(%rip),%xmm1        # 2c710 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x26a0>
  2e7e1c:	vucomiss %xmm0,%xmm1
  2e7e20:	mov    $0x2,%eax
  2e7e25:	jb     2e8087 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26a7>
  2e7e2b:	vmovss -0x2bb51b(%rip),%xmm1        # 2c918 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28a8>
  2e7e33:	vcmpnless %xmm0,%xmm1,%xmm1
  2e7e38:	vxorps %xmm2,%xmm2,%xmm2
  2e7e3c:	vcmpneqss %xmm2,%xmm0,%xmm0
  2e7e41:	vandps %xmm1,%xmm0,%xmm0
  2e7e45:	vmovd  %xmm0,%ecx
  2e7e49:	test   $0x1,%cl
  2e7e4c:	jne    2e8087 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26a7>
  2e7e52:	cmp    $0x3,%esi
  2e7e55:	je     2e6f80 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x15a0>
  2e7e5b:	mov    0x8(%rsp),%rax
  2e7e60:	vmovss 0xc(%r13,%rax,4),%xmm0
  2e7e67:	vbroadcastss -0x2bb528(%rip),%xmm2        # 2c948 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28d8>
  2e7e70:	vandps %xmm2,%xmm0,%xmm0
  2e7e74:	vmovss 0xc(%rdi,%rax,4),%xmm1
  2e7e7a:	vandps %xmm2,%xmm1,%xmm1
  2e7e7e:	vmaxss %xmm1,%xmm0,%xmm2
  2e7e82:	vcmpunordss %xmm1,%xmm1,%xmm1
  2e7e87:	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  2e7e8d:	vmovss -0x2bb785(%rip),%xmm1        # 2c710 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x26a0>
  2e7e95:	vucomiss %xmm0,%xmm1
  2e7e99:	mov    $0x3,%eax
  2e7e9e:	jb     2e8087 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26a7>
  2e7ea4:	vmovss -0x2bb594(%rip),%xmm1        # 2c918 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28a8>
  2e7eac:	vcmpnless %xmm0,%xmm1,%xmm1
  2e7eb1:	vxorps %xmm2,%xmm2,%xmm2
  2e7eb5:	vcmpneqss %xmm2,%xmm0,%xmm0
  2e7eba:	vandps %xmm1,%xmm0,%xmm0
  2e7ebe:	vmovd  %xmm0,%ecx
  2e7ec2:	test   $0x1,%cl
  2e7ec5:	jne    2e8087 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26a7>
  2e7ecb:	cmp    $0x4,%esi
  2e7ece:	je     2e6f80 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x15a0>
  2e7ed4:	mov    0x8(%rsp),%rax
  2e7ed9:	vmovss 0x10(%r13,%rax,4),%xmm0
  2e7ee0:	vbroadcastss -0x2bb5a1(%rip),%xmm2        # 2c948 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28d8>
  2e7ee9:	vandps %xmm2,%xmm0,%xmm0
  2e7eed:	vmovss 0x10(%rdi,%rax,4),%xmm1
  2e7ef3:	vandps %xmm2,%xmm1,%xmm1
  2e7ef7:	vmaxss %xmm1,%xmm0,%xmm2
  2e7efb:	vcmpunordss %xmm1,%xmm1,%xmm1
  2e7f00:	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  2e7f06:	vmovss -0x2bb7fe(%rip),%xmm1        # 2c710 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x26a0>
  2e7f0e:	vucomiss %xmm0,%xmm1
  2e7f12:	mov    $0x4,%eax
  2e7f17:	jb     2e8087 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26a7>
  2e7f1d:	vmovss -0x2bb60d(%rip),%xmm1        # 2c918 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28a8>
  2e7f25:	vcmpnless %xmm0,%xmm1,%xmm1
  2e7f2a:	vxorps %xmm2,%xmm2,%xmm2
  2e7f2e:	vcmpneqss %xmm2,%xmm0,%xmm0
  2e7f33:	vandps %xmm1,%xmm0,%xmm0
  2e7f37:	vmovd  %xmm0,%ecx
  2e7f3b:	test   $0x1,%cl
  2e7f3e:	jne    2e8087 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26a7>
  2e7f44:	cmp    $0x5,%esi
  2e7f47:	je     2e6f80 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x15a0>
  2e7f4d:	mov    0x8(%rsp),%rax
  2e7f52:	vmovss 0x14(%r13,%rax,4),%xmm0
  2e7f59:	vbroadcastss -0x2bb61a(%rip),%xmm2        # 2c948 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28d8>
  2e7f62:	vandps %xmm2,%xmm0,%xmm0
  2e7f66:	vmovss 0x14(%rdi,%rax,4),%xmm1
  2e7f6c:	vandps %xmm2,%xmm1,%xmm1
  2e7f70:	vmaxss %xmm1,%xmm0,%xmm2
  2e7f74:	vcmpunordss %xmm1,%xmm1,%xmm1
  2e7f79:	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  2e7f7f:	vmovss -0x2bb877(%rip),%xmm1        # 2c710 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x26a0>
  2e7f87:	vucomiss %xmm0,%xmm1
  2e7f8b:	mov    $0x5,%eax
  2e7f90:	jb     2e8087 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26a7>
  2e7f96:	vmovss -0x2bb686(%rip),%xmm1        # 2c918 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28a8>
  2e7f9e:	vcmpnless %xmm0,%xmm1,%xmm1
  2e7fa3:	vxorps %xmm2,%xmm2,%xmm2
  2e7fa7:	vcmpneqss %xmm2,%xmm0,%xmm0
  2e7fac:	vandps %xmm1,%xmm0,%xmm0
  2e7fb0:	vmovd  %xmm0,%ecx
  2e7fb4:	test   $0x1,%cl
  2e7fb7:	jne    2e8087 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26a7>
  2e7fbd:	cmp    $0x6,%esi
  2e7fc0:	je     2e6f43 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x1563>
  2e7fc6:	mov    0x30(%rsp),%rax
  2e7fcb:	mov    0x8(%rsp),%rcx
  2e7fd0:	vmovss 0x18(%rax,%rcx,4),%xmm0
  2e7fd6:	vbroadcastss -0x2bb697(%rip),%xmm2        # 2c948 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28d8>
  2e7fdf:	vandps %xmm2,%xmm0,%xmm0
  2e7fe3:	mov    (%rsp),%rax
  2e7fe7:	vmovss 0x18(%rax,%rcx,4),%xmm1
  2e7fed:	vandps %xmm2,%xmm1,%xmm1
  2e7ff1:	vmaxss %xmm1,%xmm0,%xmm2
  2e7ff5:	vcmpunordss %xmm1,%xmm1,%xmm1
  2e7ffa:	vblendvps %xmm1,%xmm0,%xmm2,%xmm0
  2e8000:	vmovss -0x2bb8f8(%rip),%xmm1        # 2c710 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x26a0>
  2e8008:	vucomiss %xmm0,%xmm1
  2e800c:	mov    $0x6,%eax
  2e8011:	jb     2e8216 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2836>
  2e8017:	vmovss -0x2bb707(%rip),%xmm1        # 2c918 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x28a8>
  2e801f:	vcmpnless %xmm0,%xmm1,%xmm1
  2e8024:	vxorps %xmm2,%xmm2,%xmm2
  2e8028:	vcmpneqss %xmm2,%xmm0,%xmm0
  2e802d:	vandps %xmm1,%xmm0,%xmm0
  2e8031:	vmovd  %xmm0,%ecx
  2e8035:	test   $0x1,%cl
  2e8038:	mov    0x470(%rsp),%rbp
  2e8040:	mov    0x50(%rsp),%r15
  2e8045:	mov    0x4a0(%rsp),%r10
  2e804d:	vmovss -0x2bb80d(%rip),%xmm6        # 2c848 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x27d8>
  2e8055:	vmovss -0x2bb97d(%rip),%xmm7        # 2c6e0 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x2670>
  2e805d:	mov    0x18(%rsp),%rdx
  2e8062:	mov    0x28(%rsp),%r14
  2e8067:	mov    0x40(%rsp),%r11
  2e806c:	mov    0x30(%rsp),%r13
  2e8071:	mov    0xb8(%rsp),%rsi
  2e8079:	mov    (%rsp),%rdi
  2e807d:	je     2e6f80 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x15a0>
  2e8083:	jmp    2e8087 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26a7>
  2e8085:	xor    %eax,%eax
  2e8087:	cmp    %esi,%eax
  2e8089:	jae    2e6f80 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x15a0>
  2e808f:	nop
  2e8090:	mov    $0x1,%bl
  2e8092:	test   %rdx,%rdx
  2e8095:	je     2e6f80 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x15a0>
  2e809b:	xor    %eax,%eax
  2e809d:	jmp    2e80f3 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2713>
  2e809f:	nop
  2e80a0:	mov    %rcx,(%r10,%rax,8)
  2e80a4:	vmovss %xmm0,0x0(%r13,%rax,4)
  2e80ab:	mov    (%rsp),%rcx
  2e80af:	vmovss %xmm1,(%rcx,%rax,4)
  2e80b4:	cmpq   $0x0,(%r10,%rax,8)
  2e80b9:	lea    0x1(%rax),%rax
  2e80bd:	sete   %cl
  2e80c0:	cmp    $0x53800001,%r8d
  2e80c7:	setb   %sil
  2e80cb:	add    $0xd4800000,%r8d
  2e80d2:	cmp    $0xd4800001,%r8d
  2e80d9:	setb   %dil
  2e80dd:	and    %cl,%sil
  2e80e0:	and    %dil,%sil
  2e80e3:	mov    (%rsp),%rdi
  2e80e7:	and    %sil,%bl
  2e80ea:	cmp    %rdx,%rax
  2e80ed:	je     2e6f80 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x15a0>
  2e80f3:	mov    0x0(%r13,%rax,4),%esi
  2e80f8:	vmovd  %esi,%xmm0
  2e80fc:	and    $0x7fffffff,%esi
  2e8102:	mov    (%rdi,%rax,4),%ecx
  2e8105:	vmovd  %ecx,%xmm1
  2e8109:	and    $0x7fffffff,%ecx
  2e810f:	cmp    %esi,%ecx
  2e8111:	cmovbe %esi,%ecx
  2e8114:	cmp    $0x53800001,%ecx
  2e811a:	jb     2e8180 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x27a0>
  2e811c:	mov    (%r10,%rax,8),%rsi
  2e8120:	vmulss %xmm6,%xmm0,%xmm0
  2e8124:	vmulss %xmm6,%xmm1,%xmm1
  2e8128:	add    $0x50,%rsi
  2e812c:	jo     2e82a8 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28c8>
  2e8132:	vmovd  %ecx,%xmm2
  2e8136:	cs nopw 0x0(%rax,%rax,1)
  2e8140:	mov    %rsi,%rdi
  2e8143:	vmulss %xmm6,%xmm2,%xmm2
  2e8147:	vmovd  %xmm2,%ecx
  2e814b:	mov    %ecx,%r8d
  2e814e:	and    $0x7fffffff,%r8d
  2e8155:	cmp    $0x53800000,%r8d
  2e815c:	jbe    2e81a0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x27c0>
  2e815e:	vmulss %xmm6,%xmm0,%xmm0
  2e8162:	vmulss %xmm6,%xmm1,%xmm1
  2e8166:	add    $0x50,%rsi
  2e816a:	jno    2e8140 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2760>
  2e816c:	jmp    2e829a <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28ba>
  2e8171:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  2e8180:	mov    %ecx,%r8d
  2e8183:	lea    -0x1(%r8),%esi
  2e8187:	cmp    $0x2b7ffffe,%esi
  2e818d:	ja     2e80b4 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26d4>
  2e8193:	jmp    2e81c4 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x27e4>
  2e8195:	data16 cs nopw 0x0(%rax,%rax,1)
  2e81a0:	mov    %rdi,(%r10,%rax,8)
  2e81a4:	vmovss %xmm0,0x0(%r13,%rax,4)
  2e81ab:	mov    (%rsp),%rdi
  2e81af:	vmovss %xmm1,(%rdi,%rax,4)
  2e81b4:	lea    -0x1(%r8),%esi
  2e81b8:	cmp    $0x2b7ffffe,%esi
  2e81be:	ja     2e80b4 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26d4>
  2e81c4:	mov    (%r10,%rax,8),%rsi
  2e81c8:	vmulss %xmm7,%xmm0,%xmm0
  2e81cc:	vmulss %xmm7,%xmm1,%xmm1
  2e81d0:	add    $0xffffffffffffffb0,%rsi
  2e81d4:	jo     2e82a8 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28c8>
  2e81da:	vmovd  %ecx,%xmm2
  2e81de:	xchg   %ax,%ax
  2e81e0:	mov    %rsi,%rcx
  2e81e3:	vmulss %xmm7,%xmm2,%xmm2
  2e81e7:	vmovd  %xmm2,%r8d
  2e81ec:	and    $0x7fffffff,%r8d
  2e81f3:	lea    -0x1(%r8),%edi
  2e81f7:	cmp    $0x2b7fffff,%edi
  2e81fd:	jae    2e80a0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26c0>
  2e8203:	vmulss %xmm7,%xmm0,%xmm0
  2e8207:	vmulss %xmm7,%xmm1,%xmm1
  2e820b:	add    $0xffffffffffffffb0,%rsi
  2e820f:	jno    2e81e0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x2800>
  2e8211:	jmp    2e82a0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28c0>
  2e8216:	mov    0x470(%rsp),%rbp
  2e821e:	mov    0x50(%rsp),%r15
  2e8223:	mov    0x4a0(%rsp),%r10
  2e822b:	vmovss -0x2bb9eb(%rip),%xmm6        # 2c848 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x27d8>
  2e8233:	vmovss -0x2bbb5b(%rip),%xmm7        # 2c6e0 <anon.806146056bf46a46ec2a0fe4da87e7f4.68.llvm.13166809928581664932+0x2670>
  2e823b:	mov    0x18(%rsp),%rdx
  2e8240:	mov    0x28(%rsp),%r14
  2e8245:	mov    0x40(%rsp),%r11
  2e824a:	mov    0x30(%rsp),%r13
  2e824f:	mov    0xb8(%rsp),%rsi
  2e8257:	mov    (%rsp),%rdi
  2e825b:	cmp    %esi,%eax
  2e825d:	jae    2e6f80 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x15a0>
  2e8263:	jmp    2e8090 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x26b0>
  2e8268:	mov    0x138(%rsp),%rax
  2e8270:	movq   $0xffffffffffffffff,(%rax)
  2e8277:	jmp    2e837d <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x299d>
  2e827c:	mov    %rcx,(%r10,%rax,8)
  2e8280:	jmp    2e828c <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28ac>
  2e8282:	mov    %r8,(%r10,%rax,8)
  2e8286:	jmp    2e828c <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28ac>
  2e8288:	mov    %rdx,(%r10,%rax,8)
  2e828c:	vmovss %xmm1,0x0(%rbp,%rax,4)
  2e8292:	vmovss %xmm0,(%r12,%rax,4)
  2e8298:	jmp    2e82cb <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28eb>
  2e829a:	mov    %rdi,(%r10,%rax,8)
  2e829e:	jmp    2e82a4 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28c4>
  2e82a0:	mov    %rcx,(%r10,%rax,8)
  2e82a4:	mov    (%rsp),%rdi
  2e82a8:	vmovss %xmm0,0x0(%r13,%rax,4)
  2e82af:	vmovss %xmm1,(%rdi,%rax,4)
  2e82b4:	jmp    2e82cb <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28eb>
  2e82b6:	mov    %rdi,(%r10,%rax,8)
  2e82ba:	jmp    2e82c0 <rustsht::legendre::scalar_paired::for_each_y_lm_paired_status_dispatched_typed::<f32, rustsht::legendre::scalar_paired::synthesis::F32HemispherePairAccumulator>+0x28e0>
  2e82bc:	mov    %rcx,(%r10,%rax,8)
  2e82c0:	vmovss %xmm0,(%r14,%rax,4)
  2e82c6:	vmovss %xmm1,(%rbx,%rax,4)
  2e82cb:	movq   $0x10,0xd0(%rsp)
  2e82d7:	lea    -0x2b1f58(%rip),%rax        # 36386 <anon.9445595c9a9da21797216ec9ea00a010.58.llvm.9720432591573140778+0x60>
  2e82de:	mov    %al,0xd8(%rsp)
  2e82e5:	mov    0x1e8(%rsp),%rax
  2e82ed:	mov    %ax,0xd9(%rsp)
  2e82f5:	shr    $0x10,%eax
  2e82f8:	mov    %al,0xdb(%rsp)
  2e82ff:	mov    0x1e0(%rsp),%rax
  2e8307:	mov    %eax,0xdc(%rsp)
  2e830e:	movq   $0x17,0xe0(%rsp)
  2e831a:	mov    0xf0(%rsp),%rcx
  2e8322:	mov    0x138(%rsp),%rax
  2e832a:	mov    %rcx,0x20(%rax)
  2e832e:	mov    0xd0(%rsp),%rcx
  2e8336:	mov    %rcx,(%rax)
  2e8339:	movzbl 0xd8(%rsp),%ecx
  2e8341:	mov    %cl,0x8(%rax)
  2e8344:	movzwl 0xd9(%rsp),%ecx
  2e834c:	mov    %cx,0x9(%rax)
  2e8350:	movzbl 0xdb(%rsp),%ecx
  2e8358:	mov    %cl,0xb(%rax)
  2e835b:	mov    0xdc(%rsp),%ecx
  2e8362:	mov    %ecx,0xc(%rax)
  2e8365:	mov    0xe0(%rsp),%rcx
  2e836d:	mov    %rcx,0x10(%rax)
  2e8371:	mov    0xe8(%rsp),%rcx
  2e8379:	mov    %rcx,0x18(%rax)
  2e837d:	add    $0x408,%rsp
  2e8384:	pop    %rbx
  2e8385:	pop    %r12
  2e8387:	pop    %r13
  2e8389:	pop    %r14
  2e838b:	pop    %r15
  2e838d:	pop    %rbp
  2e838e:	vzeroupper
  2e8391:	ret
  2e8392:	lea    0x986c7(%rip),%rcx        # 380a60 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x678>
  2e8399:	vzeroupper
  2e839c:	call   *0x9d74e(%rip)        # 385af0 <_DYNAMIC+0x348>
  2e83a2:	lea    0x986cf(%rip),%rcx        # 380a78 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x690>
  2e83a9:	vzeroupper
  2e83ac:	call   *0x9d73e(%rip)        # 385af0 <_DYNAMIC+0x348>
  2e83b2:	lea    0x986ef(%rip),%rcx        # 380aa8 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x6c0>
  2e83b9:	vzeroupper
  2e83bc:	call   *0x9d72e(%rip)        # 385af0 <_DYNAMIC+0x348>
  2e83c2:	lea    0x982ef(%rip),%rcx        # 3806b8 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x2d0>
  2e83c9:	mov    %r9,%rsi
  2e83cc:	mov    0x140(%rsp),%rdx
  2e83d4:	vzeroupper
  2e83d7:	call   *0x9d713(%rip)        # 385af0 <_DYNAMIC+0x348>
  2e83dd:	lea    0x982bc(%rip),%rcx        # 3806a0 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x2b8>
  2e83e4:	xor    %edi,%edi
  2e83e6:	mov    %r14,%rsi
  2e83e9:	mov    0x478(%rsp),%rdx
  2e83f1:	vzeroupper
  2e83f4:	call   *0x9d6f6(%rip)        # 385af0 <_DYNAMIC+0x348>
  2e83fa:	lea    0x9868f(%rip),%rcx        # 380a90 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x6a8>
  2e8401:	vzeroupper
  2e8404:	call   *0x9d6e6(%rip)        # 385af0 <_DYNAMIC+0x348>
  2e840a:	lea    0x9822f(%rip),%rcx        # 380640 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x258>
  2e8411:	mov    %r9,%rsi
  2e8414:	mov    0x448(%rsp),%rdx
  2e841c:	vzeroupper
  2e841f:	call   *0x9d6cb(%rip)        # 385af0 <_DYNAMIC+0x348>
  2e8425:	lea    0x9822c(%rip),%rcx        # 380658 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x270>
  2e842c:	xor    %edi,%edi
  2e842e:	mov    %r14,%rsi
  2e8431:	mov    0x488(%rsp),%rdx
  2e8439:	vzeroupper
  2e843c:	call   *0x9d6ae(%rip)        # 385af0 <_DYNAMIC+0x348>
  2e8442:	lea    0x98227(%rip),%rcx        # 380670 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x288>
  2e8449:	xor    %edi,%edi
  2e844b:	mov    %r14,%rsi
  2e844e:	mov    0x498(%rsp),%rdx
  2e8456:	vzeroupper
  2e8459:	call   *0x9d691(%rip)        # 385af0 <_DYNAMIC+0x348>
  2e845f:	lea    0x98222(%rip),%rcx        # 380688 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x2a0>
  2e8466:	xor    %edi,%edi
  2e8468:	mov    %r14,%rsi
  2e846b:	mov    0x4a8(%rsp),%rdx
  2e8473:	vzeroupper
  2e8476:	call   *0x9d674(%rip)        # 385af0 <_DYNAMIC+0x348>
  2e847c:	lea    0x9863d(%rip),%rcx        # 380ac0 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x6d8>
  2e8483:	mov    0x340(%rsp),%rdx
  2e848b:	vzeroupper
  2e848e:	call   *0x9d65c(%rip)        # 385af0 <_DYNAMIC+0x348>
  2e8494:	lea    0x98625(%rip),%rcx        # 380ac0 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x6d8>
  2e849b:	mov    0x88(%rsp),%rdx
  2e84a3:	vzeroupper
  2e84a6:	call   *0x9d644(%rip)        # 385af0 <_DYNAMIC+0x348>
  2e84ac:	lea    0x98625(%rip),%rcx        # 380ad8 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x6f0>
  2e84b3:	mov    %rax,%rdi
  2e84b6:	mov    %r8,%rdx
  2e84b9:	vzeroupper
  2e84bc:	call   *0x9d62e(%rip)        # 385af0 <_DYNAMIC+0x348>
  2e84c2:	lea    0x9860f(%rip),%rcx        # 380ad8 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x6f0>
  2e84c9:	vzeroupper
  2e84cc:	call   *0x9d61e(%rip)        # 385af0 <_DYNAMIC+0x348>
  2e84d2:	lea    0x98557(%rip),%rdx        # 380a30 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x648>
  2e84d9:	mov    %rbx,%rdi
  2e84dc:	call   *0x9d57e(%rip)        # 385a60 <_DYNAMIC+0x2b8>
  2e84e2:	lea    0x9852f(%rip),%rdx        # 380a18 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x630>
  2e84e9:	mov    %rbx,%rdi
  2e84ec:	call   *0x9d56e(%rip)        # 385a60 <_DYNAMIC+0x2b8>
  2e84f2:	lea    0x9854f(%rip),%rdx        # 380a48 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x660>
  2e84f9:	mov    %rbx,%rdi
  2e84fc:	call   *0x9d55e(%rip)        # 385a60 <_DYNAMIC+0x2b8>
  2e8502:	lea    0x9850f(%rip),%rdx        # 380a18 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x630>
  2e8509:	mov    %rbp,%rdi
  2e850c:	call   *0x9d54e(%rip)        # 385a60 <_DYNAMIC+0x2b8>
  2e8512:	lea    0x98517(%rip),%rdx        # 380a30 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x648>
  2e8519:	mov    %rbp,%rdi
  2e851c:	call   *0x9d53e(%rip)        # 385a60 <_DYNAMIC+0x2b8>
  2e8522:	lea    0x9851f(%rip),%rdx        # 380a48 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x660>
  2e8529:	mov    %rbp,%rdi
  2e852c:	call   *0x9d52e(%rip)        # 385a60 <_DYNAMIC+0x2b8>
  2e8532:	lea    0x984c7(%rip),%rdx        # 380a00 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x618>
  2e8539:	mov    %rbx,%rdi
  2e853c:	mov    %rbp,%rsi
  2e853f:	call   *0x9d51b(%rip)        # 385a60 <_DYNAMIC+0x2b8>
  2e8545:	lea    0x98424(%rip),%rdx        # 380970 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x588>
  2e854c:	mov    0x458(%rsp),%rdi
  2e8554:	mov    %rdi,%rsi
  2e8557:	vzeroupper
  2e855a:	call   *0x9d500(%rip)        # 385a60 <_DYNAMIC+0x2b8>
  2e8560:	lea    0x98421(%rip),%rdx        # 380988 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x5a0>
  2e8567:	mov    0x468(%rsp),%rdi
  2e856f:	mov    %rdi,%rsi
  2e8572:	vzeroupper
  2e8575:	call   *0x9d4e5(%rip)        # 385a60 <_DYNAMIC+0x2b8>
  2e857b:	lea    0x9847e(%rip),%rdx        # 380a00 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x618>
  2e8582:	mov    %rbp,%rdi
  2e8585:	mov    0xc0(%rsp),%rsi
  2e858d:	call   *0x9d4cd(%rip)        # 385a60 <_DYNAMIC+0x2b8>
  2e8593:	lea    0x98406(%rip),%rdx        # 3809a0 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x5b8>
  2e859a:	vzeroupper
  2e859d:	call   *0x9d4bd(%rip)        # 385a60 <_DYNAMIC+0x2b8>
  2e85a3:	lea    0x9840e(%rip),%rdx        # 3809b8 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x5d0>
  2e85aa:	vzeroupper
  2e85ad:	call   *0x9d4ad(%rip)        # 385a60 <_DYNAMIC+0x2b8>
  2e85b3:	lea    0x98416(%rip),%rdx        # 3809d0 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x5e8>
  2e85ba:	vzeroupper
  2e85bd:	call   *0x9d49d(%rip)        # 385a60 <_DYNAMIC+0x2b8>
  2e85c3:	lea    0x9841e(%rip),%rdx        # 3809e8 <anon.b98e330460b53006a5366f669745c6e7.92.llvm.2166861333189607233+0x600>
  2e85ca:	vzeroupper
  2e85cd:	call   *0x9d48d(%rip)        # 385a60 <_DYNAMIC+0x2b8>
