from __future__ import annotations

import hashlib
import json
import statistics
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path("/tmp/rustsht-exp-f32-fused-FsgPiGdK")
REPO = ROOT / "candidate"
sys.path.insert(0, str(REPO / "scripts"))
import benchmark_ducc_f32_native as bench

OUT = ROOT / "results" / "f32-adjacent-controls"
SCRATCH = ROOT / "results" / "f32-adjacent-worker-scratch"
BINARIES = {
    "parent": ROOT / "parent-target/release/examples/ducc_f32_full_transform_parity",
    "candidate": ROOT / "candidate-target/release/examples/ducc_f32_full_transform_parity",
    "ducc": ROOT / "ducc-build/ducc_f32_full_transform_parity",
}
ORDERS = [
    ("parent", "candidate", "ducc"),
    ("candidate", "ducc", "parent"),
    ("ducc", "parent", "candidate"),
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    SCRATCH.mkdir(parents=True, exist_ok=True)
    cases = [
        {
            "grid": "GL", "ntheta": 721, "nphi": 1458, "lmax": 720, "mmax": 720,
            "longitude": "even", "spin": 0, "operation": "analysis", "threads": 8,
        },
        {
            "grid": "GL", "ntheta": 721, "nphi": 1458, "lmax": 720, "mmax": 720,
            "longitude": "even", "spin": 1, "operation": "synthesis", "threads": 8,
        },
    ]
    all_cases = []
    for case in cases:
        case_id = f"GL-T720-M720-even-s{case['spin']}-{case['operation']}-q8"
        case_out = OUT / case_id
        case_out.mkdir(parents=True, exist_ok=True)
        fixture = bench.make_fixture(case, SCRATCH / case_id / "fixture")
        fixture_hashes = {name: sha256(path) for name, path in fixture.items()}
        triplets = []
        for triplet, order in enumerate(ORDERS, 1):
            results = {}
            for backend in order:
                result = bench.run_worker(
                    BINARIES[backend], backend, case, fixture,
                    SCRATCH / case_id / f"triplet-{triplet}" / backend,
                    target_ms=25.0, cpus="0,1,2,3,4,5,6,7",
                )
                result.update({"backend": backend, "triplet": triplet, **case})
                results[backend] = result
                (case_out / f"triplet-{triplet}-{backend}.json").write_text(
                    json.dumps(result, indent=2) + "\n"
                )
            ducc_paths = [Path(path) for path in results["ducc"]["outputs"]]
            errors = {
                backend: bench.error_metrics(
                    ducc_paths, [Path(path) for path in results[backend]["outputs"]]
                )
                for backend in ("parent", "candidate")
            }
            triplets.append({
                "triplet": triplet,
                "order": list(order),
                "parent_median_ms": statistics.median(results["parent"]["batch_ms"]),
                "candidate_median_ms": statistics.median(results["candidate"]["batch_ms"]),
                "ducc_median_ms": statistics.median(results["ducc"]["batch_ms"]),
                "candidate_over_parent": (
                    statistics.median(results["candidate"]["batch_ms"])
                    / statistics.median(results["parent"]["batch_ms"])
                ),
                "errors_vs_ducc": errors,
                "worker_details": {
                    backend: bench.timing_details(results[backend])
                    for backend in ("parent", "candidate", "ducc")
                },
            })
            print(f"completed {case_id} triplet {triplet}", flush=True)
        ratios = [item["candidate_over_parent"] for item in triplets]
        summary = {
            **case,
            "case_id": case_id,
            "fixture_sha256": fixture_hashes,
            "candidate_over_parent_triplet_ratios": ratios,
            "candidate_over_parent_median": statistics.median(ratios),
            "parent_over_ducc_median": statistics.median(
                item["parent_median_ms"] / item["ducc_median_ms"] for item in triplets
            ),
            "candidate_over_ducc_median": statistics.median(
                item["candidate_median_ms"] / item["ducc_median_ms"] for item in triplets
            ),
            "parent_vs_ducc_error_max_rel_l2": max(
                item["errors_vs_ducc"]["parent"]["relative_l2"] for item in triplets
            ),
            "candidate_vs_ducc_error_max_rel_l2": max(
                item["errors_vs_ducc"]["candidate"]["relative_l2"] for item in triplets
            ),
            "finite": all(
                item["errors_vs_ducc"][backend]["finite"]
                for item in triplets for backend in ("parent", "candidate")
            ),
            "triplets": triplets,
        }
        (case_out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
        all_cases.append(summary)
    manifest = {
        "source_commit_parent_and_candidate": "972bacdaef57388509738d1c2cdebbb7973b89be",
        "candidate_source_sha256": sha256(REPO / "src/legendre/scalar_paired/synthesis.rs"),
        "ducc_commit": bench.DUCC_SHA,
        "binary_sha256": {name: sha256(path) for name, path in BINARIES.items()},
        "benchmark_script_sha256": sha256(REPO / "scripts/benchmark_ducc_f32_native.py"),
        "runner_sha256": sha256(Path(__file__)),
        "target_ms": 25.0,
        "triplet_orders": [list(order) for order in ORDERS],
        "cases": all_cases,
    }
    (OUT / "summary.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({
        "output": str(OUT / "summary.json"),
        "cells": [
            {
                "case_id": item["case_id"],
                "candidate_over_parent_median": item["candidate_over_parent_median"],
                "parent_over_ducc_median": item["parent_over_ducc_median"],
                "candidate_over_ducc_median": item["candidate_over_ducc_median"],
                "relative_l2_parent_candidate_ducc": [
                    item["parent_vs_ducc_error_max_rel_l2"],
                    item["candidate_vs_ducc_error_max_rel_l2"],
                ],
            }
            for item in all_cases
        ],
    }, indent=2), flush=True)


if __name__ == "__main__":
    main()
