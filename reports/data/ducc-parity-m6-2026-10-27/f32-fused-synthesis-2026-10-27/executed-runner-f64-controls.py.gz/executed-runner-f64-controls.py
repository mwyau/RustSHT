from __future__ import annotations

import hashlib
import json
import statistics
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path("/tmp/rustsht-exp-f32-fused-FsgPiGdK")
REPO = ROOT / "candidate"
sys.path.insert(0, str(REPO / "scripts"))
import benchmark_ducc_full_transform_parity as bench
import numpy as np

OUT = ROOT / "results" / "f64-scalar-controls"
OUT.mkdir(parents=True, exist_ok=True)
BINARIES = {
    "parent": ROOT / "parent-target/release/examples/ducc_full_transform_parity",
    "candidate": ROOT / "candidate-target/release/examples/ducc_full_transform_parity",
    "ducc": ROOT / "ducc-f64-build/ducc_full_transform_parity",
}
ORDERS = [
    ("parent", "candidate", "ducc"),
    ("candidate", "ducc", "parent"),
    ("ducc", "parent", "candidate"),
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def output_values(path: Path):
    return np.fromfile(path, dtype="<f8")


def main():
    if any(not path.is_file() for path in BINARIES.values()):
        raise SystemExit("one or more f64 parent/candidate/DUCC binaries are missing")
    physical = bench.physical_cpus()
    if len(physical) < 9:
        raise SystemExit(f"need a separate monitor core; found {len(physical)} physical CPUs")
    monitor_cpu = physical[8]
    cases = bench.make_cases(
        smoke=False,
        fixed_mmax=720,
        selected_lmax={720},
        selected_longitude_modes={"even_smooth"},
        grid="GL",
    )
    if len(cases) != 1:
        raise SystemExit(f"expected one T720 full-mmax GL case, got {len(cases)}")
    template = cases[0]
    results = []
    for threads in (1, 8):
        case = dict(template)
        case["threads"] = threads
        case_id = f"GL-T720-M720-even-smooth-scalar-synthesis-q{threads}"
        fixture_dir = OUT / case_id / "fixture"
        fixture_dir.mkdir(parents=True, exist_ok=True)
        bench.make_fixture(case, fixture_dir)
        case_dir = OUT / case_id
        case_dir.mkdir(parents=True, exist_ok=True)
        cpus = physical[:1] if threads == 1 else physical[:8]
        pair_rows = []
        for pair_index, order in enumerate(ORDERS, 1):
            records = {}
            paths = {}
            for backend in order:
                output = case_dir / f"triplet-{pair_index}-{backend}.map"
                command = bench.worker_command(
                    BINARIES, backend, case, "synthesis", threads, output, 25.0, False
                )
                record, _diagnostics = bench.run_pinned(command, cpus, monitor_cpu)
                records[backend] = record
                paths[backend] = output
                (case_dir / f"triplet-{pair_index}-{backend}.json").write_text(
                    json.dumps(record, indent=2, allow_nan=False) + "\n"
                )
            ducc = output_values(paths["ducc"])
            errors = {
                backend: bench.error_metrics(output_values(paths[backend]), ducc)
                for backend in ("parent", "candidate")
            }
            errors["candidate_vs_parent"] = bench.error_metrics(
                output_values(paths["candidate"]), output_values(paths["parent"])
            )
            pair_rows.append({
                "triplet": pair_index,
                "order": list(order),
                "parent_median_ms": statistics.median(records["parent"]["batch_ms"]),
                "candidate_median_ms": statistics.median(records["candidate"]["batch_ms"]),
                "ducc_median_ms": statistics.median(records["ducc"]["batch_ms"]),
                "candidate_over_parent": (
                    statistics.median(records["candidate"]["batch_ms"])
                    / statistics.median(records["parent"]["batch_ms"])
                ),
                "parent_over_ducc": (
                    statistics.median(records["parent"]["batch_ms"])
                    / statistics.median(records["ducc"]["batch_ms"])
                ),
                "candidate_over_ducc": (
                    statistics.median(records["candidate"]["batch_ms"])
                    / statistics.median(records["ducc"]["batch_ms"])
                ),
                "errors": errors,
                "workers": {
                    backend: {
                        key: records[backend][key]
                        for key in (
                            "first_ms", "warmup_ms", "batch_ms", "output_checksum",
                            "reset_consistent", "arch", "lane_width_f64",
                        )
                        if key in records[backend]
                    }
                    for backend in ("parent", "candidate", "ducc")
                },
            })
            print(f"completed {case_id} triplet {pair_index}", flush=True)
        ratios = [item["candidate_over_parent"] for item in pair_rows]
        summary = {
            **{key: value for key, value in case.items() if key not in {"map_path", "alm_path"}},
            "case_id": case_id,
            "fixture_sha256": case["input_sha256"],
            "threads": threads,
            "affinity_cpus": cpus,
            "candidate_over_parent_triplet_ratios": ratios,
            "candidate_over_parent_median": statistics.median(ratios),
            "parent_over_ducc_median": statistics.median(x["parent_over_ducc"] for x in pair_rows),
            "candidate_over_ducc_median": statistics.median(x["candidate_over_ducc"] for x in pair_rows),
            "max_parent_vs_ducc_relative_l2": max(
                x["errors"]["parent"]["relative_l2"] for x in pair_rows
            ),
            "max_candidate_vs_ducc_relative_l2": max(
                x["errors"]["candidate"]["relative_l2"] for x in pair_rows
            ),
            "max_candidate_vs_parent_relative_l2": max(
                x["errors"]["candidate_vs_parent"]["relative_l2"] for x in pair_rows
            ),
            "all_finite": all(
                bool(x["errors"][backend]["metrics_finite"])
                for x in pair_rows for backend in ("parent", "candidate")
            ),
            "triplets": pair_rows,
        }
        (case_dir / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
        results.append(summary)
    manifest = {
        "source_commit_parent_and_candidate": "972bacdaef57388509738d1c2cdebbb7973b89be",
        "candidate_source_sha256": sha256(REPO / "src/legendre/scalar_paired/synthesis.rs"),
        "ducc_commit": "42ce8ab5c5d79e0e2fd9af4a09c2ea4693520e1b",
        "rust_flags": "-C target-cpu=x86-64-v3 -Aunexpected_cfgs",
        "ducc_flags": "DUCC sources: -O3 -ffast-math -ffp-contract=fast -march=x86-64-v3; driver: -O3 -fno-fast-math -ffp-contract=fast -march=x86-64-v3",
        "binary_sha256": {name: sha256(path) for name, path in BINARIES.items()},
        "benchmark_script_sha256": sha256(REPO / "scripts/benchmark_ducc_full_transform_parity.py"),
        "runner_sha256": sha256(Path(__file__)),
        "target_ms": 25.0,
        "triplet_orders": [list(order) for order in ORDERS],
        "cases": results,
    }
    (OUT / "summary.json").write_text(json.dumps(manifest, indent=2, allow_nan=False) + "\n")
    print(json.dumps({
        "output": str(OUT / "summary.json"),
        "cells": [
            {
                "case_id": item["case_id"],
                "candidate_over_parent_median": item["candidate_over_parent_median"],
                "parent_over_ducc_median": item["parent_over_ducc_median"],
                "candidate_over_ducc_median": item["candidate_over_ducc_median"],
                "max_parent_rel_l2": item["max_parent_vs_ducc_relative_l2"],
                "max_candidate_rel_l2": item["max_candidate_vs_ducc_relative_l2"],
            }
            for item in results
        ],
    }, indent=2), flush=True)


if __name__ == "__main__":
    main()
