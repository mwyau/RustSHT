from __future__ import annotations

import hashlib
import json
import statistics
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path("/tmp/rustsht-exp-f32-fused-FsgPiGdK")
REPO = ROOT / "candidate"
sys.path.insert(0, str(REPO / "scripts"))
import benchmark_ducc_f32_native as bench

OUT = ROOT / "results" / "matched-three-way"
SCRATCH = ROOT / "results" / "matched-worker-scratch"
PARENT_BIN = ROOT / "parent-target/release/examples/ducc_f32_full_transform_parity"
CANDIDATE_BIN = ROOT / "candidate-target/release/examples/ducc_f32_full_transform_parity"
DUCC_BIN = ROOT / "ducc-build/ducc_f32_full_transform_parity"
BINARIES = {"parent": PARENT_BIN, "candidate": CANDIDATE_BIN, "ducc": DUCC_BIN}
ORDERS = [
    ("parent", "candidate", "ducc"),
    ("candidate", "ducc", "parent"),
    ("ducc", "parent", "candidate"),
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def sanitize(obj):
    if isinstance(obj, dict):
        return {
            key: sanitize(value)
            for key, value in obj.items()
            if key != "cpu_pressure"
        }
    if isinstance(obj, list):
        return [sanitize(value) for value in obj]
    return obj


def main():
    if any(not path.is_file() for path in BINARIES.values()):
        raise SystemExit("one or more exact-parent/candidate/DUCC binaries are missing")
    OUT.mkdir(parents=True, exist_ok=True)
    SCRATCH.mkdir(parents=True, exist_ok=True)
    cases = []
    for mmax in (720, 180):
        nphi = bench.smooth_even_at_least(2 * mmax + 2)
        for threads in (1, 8):
            cases.append({
                "grid": "GL", "ntheta": 721, "nphi": nphi, "lmax": 720,
                "mmax": mmax, "longitude": "even", "spin": 0,
                "operation": "synthesis", "threads": threads,
            })

    summaries = []
    for case in cases:
        case_id = f"GL-T720-M{case['mmax']}-even-s0-synthesis-q{case['threads']}"
        case_out = OUT / case_id
        case_out.mkdir(parents=True, exist_ok=True)
        fixture = bench.make_fixture(case, SCRATCH / case_id / "fixture")
        fixture_hashes = {name: sha256(path) for name, path in fixture.items()}
        pair_details = []
        for pair_index, order in enumerate(ORDERS, 1):
            results = {}
            for backend in order:
                cpus = "0" if case["threads"] == 1 else "0,1,2,3,4,5,6,7"
                run_dir = SCRATCH / case_id / f"triplet-{pair_index}" / backend
                result = bench.run_worker(
                    BINARIES[backend], backend, case, fixture, run_dir,
                    target_ms=25.0, cpus=cpus,
                )
                result.update({"backend": backend, "triplet": pair_index, **case})
                results[backend] = result
                (case_out / f"triplet-{pair_index}-{backend}.json").write_text(
                    json.dumps(sanitize(result), indent=2) + "\n"
                )
            ducc_paths = [Path(path) for path in results["ducc"]["outputs"]]
            errors = {}
            for backend in ("parent", "candidate"):
                paths = [Path(path) for path in results[backend]["outputs"]]
                errors[backend] = bench.error_metrics(ducc_paths, paths)
            pair_details.append({
                "triplet": pair_index,
                "order": list(order),
                "rust_parent_median_ms": statistics.median(results["parent"]["batch_ms"]),
                "rust_candidate_median_ms": statistics.median(results["candidate"]["batch_ms"]),
                "ducc_median_ms": statistics.median(results["ducc"]["batch_ms"]),
                "candidate_over_parent": (
                    statistics.median(results["candidate"]["batch_ms"])
                    / statistics.median(results["parent"]["batch_ms"])
                ),
                "parent_over_ducc": (
                    statistics.median(results["parent"]["batch_ms"])
                    / statistics.median(results["ducc"]["batch_ms"])
                ),
                "candidate_over_ducc": (
                    statistics.median(results["candidate"]["batch_ms"])
                    / statistics.median(results["ducc"]["batch_ms"])
                ),
                "errors_vs_ducc": errors,
                "worker_details": {
                    backend: sanitize(bench.timing_details(results[backend]))
                    for backend in ("parent", "candidate", "ducc")
                },
            })
            print(f"completed {case_id} triplet {pair_index}", flush=True)

        ratios = [item["candidate_over_parent"] for item in pair_details]
        summary = {
            **case,
            "case_id": case_id,
            "fixture_sha256": fixture_hashes,
            "parent_batch_ms": [
                value
                for i in range(1, 4)
                for value in json.loads((case_out / f"triplet-{i}-parent.json").read_text())["batch_ms"]
            ],
            "candidate_batch_ms": [
                value
                for i in range(1, 4)
                for value in json.loads((case_out / f"triplet-{i}-candidate.json").read_text())["batch_ms"]
            ],
            "ducc_batch_ms": [
                value
                for i in range(1, 4)
                for value in json.loads((case_out / f"triplet-{i}-ducc.json").read_text())["batch_ms"]
            ],
            "candidate_over_parent_triplet_ratios": ratios,
            "candidate_over_parent_median": statistics.median(ratios),
            "parent_over_ducc_median": statistics.median(
                item["parent_over_ducc"] for item in pair_details
            ),
            "candidate_over_ducc_median": statistics.median(
                item["candidate_over_ducc"] for item in pair_details
            ),
            "parent_vs_ducc_error_max_rel_l2": max(
                item["errors_vs_ducc"]["parent"]["relative_l2"] for item in pair_details
            ),
            "candidate_vs_ducc_error_max_rel_l2": max(
                item["errors_vs_ducc"]["candidate"]["relative_l2"] for item in pair_details
            ),
            "parent_vs_ducc_error_max_abs": max(
                item["errors_vs_ducc"]["parent"]["max_absolute"] for item in pair_details
            ),
            "candidate_vs_ducc_error_max_abs": max(
                item["errors_vs_ducc"]["candidate"]["max_absolute"] for item in pair_details
            ),
            "finite": all(
                item["errors_vs_ducc"][backend]["finite"]
                for item in pair_details for backend in ("parent", "candidate")
            ),
            "triplets": pair_details,
        }
        (case_out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
        summaries.append(summary)

    manifest = {
        "source_commit_parent_and_candidate": "972bacdaef57388509738d1c2cdebbb7973b89be",
        "candidate_source_diff": sha256(REPO / "src/legendre/scalar_paired/synthesis.rs"),
        "ducc_commit": bench.DUCC_SHA,
        "binary_sha256": {name: sha256(path) for name, path in BINARIES.items()},
        "benchmark_script_sha256": sha256(REPO / "scripts/benchmark_ducc_f32_native.py"),
        "runner_sha256": sha256(Path(__file__)),
        "target_ms": 25.0,
        "triplet_orders": [list(order) for order in ORDERS],
        "cases": summaries,
    }
    (OUT / "summary.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({
        "output": str(OUT / "summary.json"),
        "cells": [
            {
                "case_id": row["case_id"],
                "candidate_over_parent_median": row["candidate_over_parent_median"],
                "parent_over_ducc_median": row["parent_over_ducc_median"],
                "candidate_over_ducc_median": row["candidate_over_ducc_median"],
                "relative_l2_parent_candidate_ducc": [
                    row["parent_vs_ducc_error_max_rel_l2"],
                    row["candidate_vs_ducc_error_max_rel_l2"],
                ],
            }
            for row in summaries
        ],
    }, indent=2), flush=True)


if __name__ == "__main__":
    main()
