#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, importlib.util, json, statistics, subprocess
from pathlib import Path
p = argparse.ArgumentParser()
p.add_argument('--repo', type=Path, required=True)
p.add_argument('--root', type=Path, required=True)
p.add_argument('--parent', type=Path, required=True)
p.add_argument('--candidate', type=Path, required=True)
p.add_argument('--ducc', type=Path, required=True)
a = p.parse_args()
spec = importlib.util.spec_from_file_location('bench', a.repo/'scripts/benchmark_ducc_f32_native.py')
bench = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(bench)
root=a.root.resolve()
binaries={'parent':a.parent.resolve(),'candidate':a.candidate.resolve(),'ducc':a.ducc.resolve()}
cases=[]
orders=[('candidate','parent','ducc'),('ducc','candidate','parent'),('parent','ducc','candidate')]
for q in (1,8):
    case={'grid':'GL','ntheta':721,'nphi':1458,'lmax':720,'mmax':720,'longitude':'even','spin':0,'operation':'synthesis','threads':q}
    case_id=f'GL-T720-M720-even-s0-synthesis-q{q}'
    fixture=bench.make_fixture(case,root/'fixtures'/case_id)
    fixture_hashes={k:hashlib.sha256(v.read_bytes()).hexdigest() for k,v in fixture.items()}
    pairs=[]
    for idx,order in enumerate(orders,1):
        workers={}
        for backend in order:
            cpus='0' if q==1 else '0,1,2,3,4,5,6,7'
            workers[backend]=bench.run_worker(binaries[backend],backend,case,fixture,
                root/'results'/case_id/f'pair-{idx}'/backend,25.0,cpus)
        assert all(w['finite_outputs'] and w['repeat_consistent'] and w['reset_consistent'] for w in workers.values())
        parent_err=bench.error_metrics([Path(x) for x in workers['parent']['outputs']], [Path(x) for x in workers['candidate']['outputs']])
        ducc_err=bench.error_metrics([Path(x) for x in workers['ducc']['outputs']], [Path(x) for x in workers['candidate']['outputs']])
        med={k:statistics.median(workers[k]['batch_ms']) for k in workers}
        hashes={k:[hashlib.sha256(Path(path).read_bytes()).hexdigest() for path in workers[k]['outputs']] for k in workers}
        row={'pair':idx,'order':list(order),'median_ms':med,'candidate_parent_ratio':med['candidate']/med['parent'],
             'candidate_ducc_ratio':med['candidate']/med['ducc'],'parent_candidate_error':parent_err,
             'candidate_ducc_error':ducc_err,'output_sha256':hashes,
             'output_guards':{k:{'finite':v['finite_outputs'],'repeat_consistent':v['repeat_consistent'],'reset_consistent':v['reset_consistent']} for k,v in workers.items()}}
        pairs.append(row)
        print(f'{case_id} pair={idx} C/P={row["candidate_parent_ratio"]:.6f} C/D={row["candidate_ducc_ratio"]:.6f} parent-L2={parent_err["relative_l2"]:.6g} ducc-L2={ducc_err["relative_l2"]:.6g}',flush=True)
    ratios=[x['candidate_parent_ratio'] for x in pairs]
    ducc_ratios=[x['candidate_ducc_ratio'] for x in pairs]
    summaries={f'{k}_median_ms':statistics.median([x['median_ms'][k] for x in pairs]) for k in ('parent','candidate','ducc')}
    summary={**summaries,'candidate_parent_pair_ratio_median':statistics.median(ratios),'candidate_parent_pair_ratio_min':min(ratios),'candidate_parent_pair_ratio_max':max(ratios),
       'candidate_ducc_pair_ratio_median':statistics.median(ducc_ratios),'max_parent_candidate_relative_l2':max(x['parent_candidate_error']['relative_l2'] for x in pairs),
       'max_candidate_ducc_relative_l2':max(x['candidate_ducc_error']['relative_l2'] for x in pairs),
       'parent_candidate_outputs_bitwise_equal':all(x['output_sha256']['parent']==x['output_sha256']['candidate'] for x in pairs),
       'all_outputs_passed_finite_repeat_reset':all(all(g['finite'] and g['repeat_consistent'] and g['reset_consistent'] for g in x['output_guards'].values()) for x in pairs)}
    cases.append({'case_id':case_id,'workload':case,'fixture_sha256':fixture_hashes,'summary':summary,'pairs':pairs})
prov=json.loads((root/'provenance.raw.json').read_text())
metadata={**prov,'rustc_version':subprocess.check_output(['rustc','--version'],text=True).strip(),
 'gxx_version':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],
 'rust_build':'release, parallel feature, default release flags, runtime Pulp dispatch',
 'ducc_build':'CMake Release, -O3 -ffast-math -ffp-contract=fast -march=x86-64-v3',
 'triplets_per_q':3,'target_ms':25.0,'q1_cpu':'0','q8_cpus':'0,1,2,3,4,5,6,7',
 'method':'sequential fresh processes, alternating parent/candidate/DUCC on deterministic fixtures'}
(root/'screen-results.raw.json').write_text(json.dumps({'metadata':metadata,'cases':cases},indent=2,sort_keys=True)+'\n')
with (root/'triplets.raw.csv').open('w',newline='') as f:
    fields=['case_id','q','pair','order','parent_ms','candidate_ms','ducc_ms','candidate_parent_ratio','candidate_ducc_ratio','parent_candidate_relative_l2','parent_candidate_max_abs','candidate_ducc_relative_l2','candidate_ducc_max_abs','parent_map0_sha256','parent_map1_sha256','candidate_map0_sha256','candidate_map1_sha256','ducc_map0_sha256','ducc_map1_sha256']
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
    for c in cases:
      for pair in c['pairs']:
        pc=pair['parent_candidate_error'];cd=pair['candidate_ducc_error'];m=pair['median_ms'];h=pair['output_sha256']
        w.writerow({'case_id':c['case_id'],'q':c['workload']['threads'],'pair':pair['pair'],'order':','.join(pair['order']),
          'parent_ms':m['parent'],'candidate_ms':m['candidate'],'ducc_ms':m['ducc'],'candidate_parent_ratio':pair['candidate_parent_ratio'],'candidate_ducc_ratio':pair['candidate_ducc_ratio'],
          'parent_candidate_relative_l2':pc['relative_l2'],'parent_candidate_max_abs':pc['max_absolute'],'candidate_ducc_relative_l2':cd['relative_l2'],'candidate_ducc_max_abs':cd['max_absolute'],
          'parent_map0_sha256':h['parent'][0],'parent_map1_sha256':h['parent'][1],'candidate_map0_sha256':h['candidate'][0],'candidate_map1_sha256':h['candidate'][1],'ducc_map0_sha256':h['ducc'][0],'ducc_map1_sha256':h['ducc'][1]})
print('Wrote pair-level results and triplet table.',flush=True)
