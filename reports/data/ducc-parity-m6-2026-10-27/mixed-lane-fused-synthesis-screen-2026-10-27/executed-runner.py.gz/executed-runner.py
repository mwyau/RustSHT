#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import importlib.util
import json
import statistics
import subprocess
from pathlib import Path

REPO = Path("/home/albert/RustSHT")
ROOT = Path(__file__).resolve().parent
PARENT_SHA = "a30537bdcfa0fc5273985abfd592998325a608de"
DUCC_SHA = "42ce8ab5c5d79e0e2fd9af4a09c2ea4693520e1b"
spec = importlib.util.spec_from_file_location(
    "benchmark_ducc_f32_native", REPO / "scripts/benchmark_ducc_f32_native.py"
)
bench = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(bench)

binaries = {
    "parent": ROOT / "targets/bench-parent/release/examples/ducc_f32_full_transform_parity",
    "candidate": ROOT / "targets/bench-current/release/examples/ducc_f32_full_transform_parity",
    "ducc": ROOT / "ducc-build/ducc_f32_full_transform_parity",
}
assert all(path.is_file() for path in binaries.values())
outdir = ROOT / "results"
scratch = ROOT / "fixtures"
outdir.mkdir(exist_ok=True)
scratch.mkdir(exist_ok=True)
cases = [
    {"grid": "GL", "ntheta": 721, "nphi": 1458, "lmax": 720, "mmax": 720,
     "longitude": "even", "spin": 0, "operation": "synthesis", "threads": q}
    for q in (1, 8)
]
orders = [
    ("candidate", "parent", "ducc"),
    ("ducc", "candidate", "parent"),
    ("parent", "ducc", "candidate"),
]
rows = []
pair_details = []
for case in cases:
    q = case["threads"]
    case_id = f"GL-T720-M720-even-s0-synthesis-q{q}"
    fixture = bench.make_fixture(case, scratch / case_id)
    fixture_hashes = {
        name: hashlib.sha256(path.read_bytes()).hexdigest()
        for name, path in fixture.items()
    }
    case_pairs = []
    for pair_index, order in enumerate(orders, 1):
        outputs = {}
        for backend in order:
            cpus = "0" if q == 1 else "0,1,2,3,4,5,6,7"
            result = bench.run_worker(
                binaries[backend], backend, case, fixture,
                ROOT / "results" / case_id / f"pair-{pair_index}" / backend,
                25.0, cpus,
            )
            outputs[backend] = result
        for backend, result in outputs.items():
            assert result["finite_outputs"], (case_id, pair_index, backend, "nonfinite")
            assert result["repeat_consistent"], (case_id, pair_index, backend, "repeat")
            assert result["reset_consistent"], (case_id, pair_index, backend, "reset")
        parent_error = bench.error_metrics([Path(path) for path in outputs["parent"]["outputs"]], [Path(path) for path in outputs["candidate"]["outputs"]])
        ducc_error = bench.error_metrics([Path(path) for path in outputs["ducc"]["outputs"]], [Path(path) for path in outputs["candidate"]["outputs"]])
        candidate_ms = statistics.median(outputs["candidate"]["batch_ms"])
        parent_ms = statistics.median(outputs["parent"]["batch_ms"])
        ducc_ms = statistics.median(outputs["ducc"]["batch_ms"])
        detail = {
            "case": case,
            "pair": pair_index,
            "order": order,
            "median_ms": {"candidate": candidate_ms, "parent": parent_ms, "ducc": ducc_ms},
            "candidate_parent_ratio": candidate_ms / parent_ms,
            "candidate_ducc_ratio": candidate_ms / ducc_ms,
            "parent_candidate_error": parent_error,
            "candidate_ducc_error": ducc_error,
            "workers": outputs,
        }
        case_pairs.append(detail)
        pair_details.append(detail)
        print(
            f"{case_id} pair={pair_index} order={','.join(order)} "
            f"candidate/parent={candidate_ms / parent_ms:.6f} "
            f"candidate/DUCC={candidate_ms / ducc_ms:.6f} "
            f"parent-error={parent_error['relative_l2']:.6g} "
            f"DUCC-error={ducc_error['relative_l2']:.6g}",
            flush=True,
        )
    c_p = [item["candidate_parent_ratio"] for item in case_pairs]
    c_d = [item["candidate_ducc_ratio"] for item in case_pairs]
    summaries = {}
    for backend in ("parent", "candidate", "ducc"):
        values = [item["median_ms"][backend] for item in case_pairs]
        summaries[f"{backend}_median_ms"] = statistics.median(values)
    summaries["candidate_parent_pair_ratio_median"] = statistics.median(c_p)
    summaries["candidate_parent_pair_ratio_min"] = min(c_p)
    summaries["candidate_parent_pair_ratio_max"] = max(c_p)
    summaries["candidate_ducc_pair_ratio_median"] = statistics.median(c_d)
    summaries["max_parent_candidate_relative_l2"] = max(
        item["parent_candidate_error"]["relative_l2"] for item in case_pairs
    )
    summaries["max_candidate_ducc_relative_l2"] = max(
        item["candidate_ducc_error"]["relative_l2"] for item in case_pairs
    )
    rows.append({
        "case_id": case_id,
        **case,
        **summaries,
        "fixture_sha256": fixture_hashes,
        "pairs": [
            {
                "pair": item["pair"],
                "order": item["order"],
                "median_ms": item["median_ms"],
                "candidate_parent_ratio": item["candidate_parent_ratio"],
                "candidate_ducc_ratio": item["candidate_ducc_ratio"],
                "parent_candidate_error": item["parent_candidate_error"],
                "candidate_ducc_error": item["candidate_ducc_error"],
            }
            for item in case_pairs
        ],
    })

diff = subprocess.check_output(
    ["git", "diff", "--binary", PARENT_SHA, "--",
     "src/legendre/scalar_paired/synthesis.rs", "src/legendre/scalar/tests/f32.rs"],
    cwd=REPO,
)
source_files = {
    name: hashlib.sha256((REPO / name).read_bytes()).hexdigest()
    for name in ("src/legendre/scalar_paired/synthesis.rs", "src/legendre/scalar/tests/f32.rs")
}
metadata = {
    "exact_parent": PARENT_SHA,
    "candidate_base_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
    "candidate_source_patch_sha256": hashlib.sha256(diff).hexdigest(),
    "candidate_source_sha256": source_files,
    "ducc_commit": DUCC_SHA,
    "ducc_actual_commit": subprocess.check_output(["git", "-C", str(ROOT / "ducc-source"), "rev-parse", "HEAD"], text=True).strip(),
    "binary_sha256": {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in binaries.items()},
    "rustc_vv": subprocess.check_output(["rustc", "-Vv"], cwd=REPO, text=True),
    "gxx": subprocess.check_output(["g++", "--version"], text=True).splitlines()[0],
    "rust_flags": "<unset; Cargo release defaults; runtime Pulp dispatch>",
    "ducc_flags": "-O3 -ffast-math -ffp-contract=fast -march=x86-64-v3",
    "process_pairs": 3,
    "target_ms": 25.0,
    "q1_affinity": "0",
    "q8_affinity": "0,1,2,3,4,5,6,7",
    "method": "sequential fresh processes, alternating parent/candidate/DUCC, same deterministic fixtures",
}
result = {"metadata": metadata, "cases": rows, "pair_details": pair_details}
(outdir / "results.json").write_text(json.dumps(result, indent=2) + "\n")
with (outdir / "results.csv").open("w", newline="") as stream:
    fields = [
        "case_id", "threads", "parent_median_ms", "candidate_median_ms", "ducc_median_ms",
        "candidate_parent_pair_ratio_median", "candidate_parent_pair_ratio_min",
        "candidate_parent_pair_ratio_max", "candidate_ducc_pair_ratio_median",
        "max_parent_candidate_relative_l2", "max_candidate_ducc_relative_l2",
    ]
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    for row in rows:
        writer.writerow({field: row.get(field) for field in fields})
print("Wrote", outdir / "results.json", flush=True)

